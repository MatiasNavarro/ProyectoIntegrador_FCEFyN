/*    */ package charlie.ds.sm;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class LinkedByteArray implements LinkedArray {
/*    */   Vector arrays;
/*    */   int arraySize;
/*  8 */   int size = 0;
/*  9 */   int resized = 0;
/* 10 */   final int INCREASE = 10;
/*    */   
/*    */   public LinkedByteArray(int arraySize, int size) {
/* 13 */     this.arrays = new Vector(size);
/* 14 */     this.arraySize = arraySize;
/* 15 */     this.arrays.add(new byte[arraySize]);
/* 16 */     this.size++;
/*    */   }
/*    */   
/*    */   public void set(int index, int value) {
/*    */     try {
/* 21 */       if (value > 127 || value < -128) {
/* 22 */         System.out.println("values to large for byte");
/* 23 */         System.exit(1);
/*    */       } 
/* 25 */       int vectorIndex = index / this.arraySize;
/* 26 */       ((byte[])this.arrays.get(vectorIndex))[index % this.arraySize] = (byte)value;
/* 27 */     } catch (Exception e) {
/* 28 */       increasing();
/* 29 */       set(index, value);
/*    */     } 
/*    */   }
/*    */   
/*    */   public int get(int index) {
/*    */     try {
/* 35 */       int vectorIndex = index / this.arraySize;
/* 36 */       return ((byte[])this.arrays.get(vectorIndex))[index % this.arraySize];
/* 37 */     } catch (Exception e) {
/* 38 */       increasing();
/* 39 */       return get(index);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void increasing() {
/* 44 */     for (int i = 0; i < 10; i++) {
/* 45 */       this.arrays.add(new byte[this.arraySize]);
/*    */     }
/* 47 */     this.size += 10;
/* 48 */     this.resized++;
/* 49 */     if (this.resized % 10000 == 0)
/* 50 */       System.out.println("size ByteArray: " + this.size); 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/sm/LinkedByteArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */