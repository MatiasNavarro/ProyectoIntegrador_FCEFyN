/*    */ package charlie.ds.sm;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class LinkedIntArray implements LinkedArray {
/*    */   Vector arrays;
/*    */   int arraySize;
/*  8 */   int size = 0;
/*  9 */   int resized = 0;
/* 10 */   final int INCREASE = 10;
/*    */ 
/*    */ 
/*    */   
/*    */   public LinkedIntArray(int arraySize, int size) {
/* 15 */     this.arrays = new Vector(size);
/* 16 */     this.arraySize = arraySize;
/* 17 */     this.arrays.add(new int[arraySize]);
/* 18 */     this.size++;
/*    */   }
/*    */   
/*    */   public void set(int index, int value) {
/* 22 */     if (value > Integer.MAX_VALUE || value < Integer.MIN_VALUE) {
/* 23 */       System.out.println("type Integer to small, long needed");
/* 24 */       System.exit(0);
/*    */     } 
/*    */     
/*    */     try {
/* 28 */       int vectorIndex = index / this.arraySize;
/* 29 */       ((int[])this.arrays.get(vectorIndex))[index % this.arraySize] = value;
/* 30 */     } catch (Exception e) {
/*    */ 
/*    */       
/* 33 */       increasing();
/* 34 */       set(index, value);
/*    */     } 
/*    */   }
/*    */   
/*    */   public int get(int index) {
/*    */     try {
/* 40 */       int vectorIndex = index / this.arraySize;
/* 41 */       return ((int[])this.arrays.get(vectorIndex))[index % this.arraySize];
/* 42 */     } catch (Exception e) {
/*    */ 
/*    */       
/* 45 */       increasing();
/* 46 */       return get(index);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void doubling() {
/* 51 */     for (int i = 0; i < this.size; i++) {
/* 52 */       this.arrays.add(new int[this.arraySize]);
/*    */     }
/* 54 */     this.size *= 2;
/*    */     
/* 56 */     this.resized++;
/* 57 */     if (this.resized % 1000 == 0) System.out.println("size: " + this.size); 
/*    */   }
/*    */   
/*    */   private void increasing() {
/* 61 */     for (int i = 0; i < 10; i++) {
/* 62 */       this.arrays.add(new int[this.arraySize]);
/*    */     }
/* 64 */     this.size += 10;
/* 65 */     this.resized++;
/* 66 */     if (this.resized % 1000 == 0) System.out.println("size: " + this.size); 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/sm/LinkedIntArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */