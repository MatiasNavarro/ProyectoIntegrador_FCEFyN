/*     */ package charlie.ds.sm;
/*     */ 
/*     */ import charlie.ds.BitSet;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SparseMatrix
/*     */   implements SMatrix
/*     */ {
/*  17 */   private static final Log LOG = LogFactory.getLog(SparseMatrix.class);
/*     */   
/*     */   public LinkedArray values;
/*     */   public LinkedArray colIndices;
/*     */   public LinkedArray rows;
/*  22 */   public int deletedRows = 0;
/*  23 */   public int deletedColumns = 0;
/*     */   
/*     */   public int rowLength;
/*     */   
/*     */   public int[] minimum;
/*     */   public int[] elements;
/*     */   public int[] negElements;
/*     */   public int[] negativs;
/*  31 */   protected static int VAL = 10000;
/*  32 */   protected static int COL = 10000;
/*  33 */   protected static int ROW = 1000;
/*     */ 
/*     */ 
/*     */   
/*  37 */   public int lastRow = 0;
/*  38 */   public int lastCol = 0;
/*     */   
/*     */   private void init() {
/*  41 */     this.values = new LinkedIntArray(VAL, 100);
/*  42 */     this.colIndices = new LinkedIntArray(COL, 100);
/*  43 */     this.rows = new LinkedIntArray(ROW, 100);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SparseMatrix() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public SparseMatrix(int rowLength) {
/*  53 */     init();
/*  54 */     this.rowLength = rowLength;
/*     */   }
/*     */   
/*     */   public SparseMatrix(int[][] m) {
/*  58 */     init();
/*  59 */     for (int i = 0; i < m.length; i++)
/*     */     {
/*     */       
/*  62 */       addRow(m[i]);
/*     */     }
/*     */     
/*     */     try {
/*  66 */       this.rowLength = (m[0]).length;
/*  67 */     } catch (Exception e) {
/*  68 */       LOG.error("error initializing sparsematrix", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFirstColumnIndex(int rowIndex) {
/*  74 */     if (this.colIndices.get(this.rows.get(rowIndex)) == -1) return Integer.MIN_VALUE; 
/*  75 */     return this.colIndices.get(this.rows.get(rowIndex));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValue(int colIndex) {
/*  81 */     return this.values.get(colIndex);
/*     */   }
/*     */   
/*     */   public int containsColumnIndex(int rowIndex, int colIndex) {
/*     */     try {
/*  86 */       if (this.colIndices.get(this.rows.get(rowIndex)) == -1) return Integer.MIN_VALUE; 
/*  87 */       int first = this.rows.get(rowIndex);
/*  88 */       int u = 0;
/*  89 */       int o = elementsInRow(rowIndex) - 1;
/*     */       
/*  91 */       if (this.colIndices.get(first + u) == colIndex) return this.rows.get(rowIndex) + u; 
/*  92 */       if (this.colIndices.get(first + o) == colIndex) return this.rows.get(rowIndex) + o; 
/*  93 */       int mid = 0;
/*  94 */       while (u != o) {
/*  95 */         if (this.colIndices.get(first + u) == colIndex) return this.rows.get(rowIndex) + u; 
/*  96 */         if (this.colIndices.get(first + o) == colIndex) return this.rows.get(rowIndex) + o; 
/*  97 */         mid = (u + o) / 2;
/*  98 */         if (this.colIndices.get(first + mid) == colIndex) return this.rows.get(rowIndex) + mid; 
/*  99 */         if (this.colIndices.get(first + mid) < colIndex) {
/* 100 */           u = mid;
/*     */         } else {
/* 102 */           o = mid;
/*     */         } 
/* 104 */         if (mid == (u + o) / 2)
/*     */           break; 
/* 106 */       }  if (this.colIndices.get(first + u) == colIndex) return this.rows.get(rowIndex) + u; 
/* 107 */     } catch (Exception e) {
/* 108 */       e.printStackTrace();
/*     */     } 
/* 110 */     return Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */   public boolean equalRows(int row1, int row2) {
/*     */     try {
/* 115 */       if (elementsInRow(row1) != elementsInRow(row2)) {
/* 116 */         return false;
/*     */       }
/* 118 */       for (int i = 0; i < elementsInRow(row1); i++) {
/* 119 */         int col1 = this.rows.get(row1) + i;
/* 120 */         int col2 = this.rows.get(row2) + i;
/* 121 */         if (this.colIndices.get(col1) != this.colIndices.get(col2)) {
/* 122 */           return false;
/*     */         }
/* 124 */         if (this.values.get(col1) != this.values.get(col2)) {
/* 125 */           return false;
/*     */         }
/*     */       } 
/* 128 */       return true;
/* 129 */     } catch (Exception e) {
/* 130 */       LOG.error(e.getMessage(), e);
/*     */       
/* 132 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getFirstColumnValue(int rowIndex) {
/* 137 */     if (getFirstColumnIndex(rowIndex) == -1) return Integer.MIN_VALUE; 
/* 138 */     return this.values.get(this.rows.get(rowIndex));
/*     */   }
/*     */   
/*     */   public void deleteLastRow() {
/*     */     try {
/* 143 */       int elements = elementsInRow(this.lastRow - 1);
/* 144 */       this.lastRow--;
/* 145 */       this.deletedRows++;
/* 146 */       this.lastCol -= elements;
/* 147 */     } catch (Exception e) {
/* 148 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIthColumnValueInRow(int rowIndex, int i) {
/* 154 */     int col = Integer.MIN_VALUE;
/*     */     try {
/* 156 */       if (i > elementsInRow(rowIndex))
/* 157 */         return col; 
/* 158 */       return this.values.get(this.rows.get(rowIndex) + i);
/* 159 */     } catch (Exception e) {
/* 160 */       LOG.error(e.getMessage(), e);
/*     */       
/* 162 */       return col;
/*     */     } 
/*     */   }
/*     */   public int getIthColumnIndexInRow(int rowIndex, int i) {
/* 166 */     int col = Integer.MIN_VALUE;
/*     */     try {
/* 168 */       if (i > elementsInRow(rowIndex)) return col; 
/* 169 */       return this.colIndices.get(this.rows.get(rowIndex) + i);
/* 170 */     } catch (Exception e) {
/* 171 */       LOG.error(e.getMessage(), e);
/*     */       
/* 173 */       return col;
/*     */     } 
/*     */   }
/*     */   public void addRow(int[] row) {
/*     */     try {
/* 178 */       int elements = 0;
/*     */ 
/*     */       
/* 181 */       for (int i = 0; i < row.length; i++) {
/* 182 */         if (row[i] != 0) {
/* 183 */           elements++;
/* 184 */           this.colIndices.set(this.lastCol, i);
/* 185 */           this.values.set(this.lastCol, row[i]);
/* 186 */           this.lastCol++;
/*     */         } 
/*     */       } 
/* 189 */       this.rows.set(++this.lastRow, this.rows.get(this.lastRow - 1) + elements);
/* 190 */     } catch (Exception e) {
/* 191 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void deleteRow(int rowIndex) throws Exception {
/* 196 */     int elementsInRow = elementsInRow(rowIndex);
/*     */     int i;
/* 198 */     for (i = this.rows.get(rowIndex); i <= this.lastCol - elementsInRow; i++) {
/* 199 */       this.colIndices.set(i, this.colIndices.get(i + elementsInRow));
/* 200 */       this.values.set(i, this.values.get(i + elementsInRow));
/*     */     } 
/* 202 */     this.lastCol -= elementsInRow;
/* 203 */     for (i = rowIndex; i <= this.lastRow; i++) {
/* 204 */       this.rows.set(i, this.rows.get(i + 1) - elementsInRow);
/*     */     }
/* 206 */     this.lastRow--;
/* 207 */     this.deletedRows++;
/*     */   }
/*     */   
/*     */   public void deleteRows(Vector<Integer> toDelete) throws Exception {
/* 211 */     int holeSize = 0;
/* 212 */     int hopSize = 0;
/* 213 */     while (!toDelete.isEmpty()) {
/* 214 */       int rowIndex = ((Integer)toDelete.get(0)).intValue();
/* 215 */       toDelete.remove(0);
/*     */       
/* 217 */       int nextRowIndex = this.lastRow;
/* 218 */       if (!toDelete.isEmpty()) {
/* 219 */         nextRowIndex = ((Integer)toDelete.get(0)).intValue();
/*     */       }
/*     */       
/* 222 */       if (rowIndex > nextRowIndex) {
/* 223 */         throw new Exception("rowIndex must not be greater than nextRowIndex");
/*     */       }
/*     */       
/* 226 */       int elementsInRow = elementsInRow(rowIndex);
/*     */       
/* 228 */       int nextCol = this.lastCol;
/* 229 */       if (nextRowIndex < this.lastRow) {
/* 230 */         nextCol = this.rows.get(nextRowIndex);
/*     */       }
/*     */       
/* 233 */       int copyDistance = holeSize + elementsInRow; int i;
/* 234 */       for (i = this.rows.get(rowIndex) - holeSize; i <= nextCol - copyDistance; i++) {
/* 235 */         this.colIndices.set(i, this.colIndices.get(i + copyDistance));
/* 236 */         this.values.set(i, this.values.get(i + copyDistance));
/*     */       } 
/* 238 */       holeSize += elementsInRow;
/* 239 */       for (i = rowIndex - hopSize; i <= nextRowIndex - hopSize - 1; i++) {
/* 240 */         this.rows.set(i, this.rows.get(i + hopSize + 1) - holeSize);
/*     */       }
/*     */       
/* 243 */       hopSize++;
/* 244 */       this.deletedRows++;
/*     */     } 
/* 246 */     this.lastRow -= hopSize;
/* 247 */     this.lastCol -= holeSize;
/*     */   }
/*     */   
/*     */   public int getRowIndex(int[] row) {
/*     */     try {
/* 252 */       boolean found = true;
/* 253 */       for (int i = 0; i < rows(); i++) {
/* 254 */         int[] currentRow = getRow(i);
/* 255 */         if (LOG.isDebugEnabled()) {
/* 256 */           LOG.debug("r:\t" + printRow(row));
/* 257 */           LOG.debug("cr:\t" + printRow(currentRow));
/*     */         } 
/* 259 */         for (int j = 0; j < row.length; j++) {
/* 260 */           if (row[j] != currentRow[j]) {
/* 261 */             found = false;
/*     */           }
/*     */         } 
/* 264 */         if (found == true) {
/* 265 */           return i;
/*     */         }
/*     */       } 
/* 268 */     } catch (Exception e) {
/* 269 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 271 */     return -1;
/*     */   }
/*     */   
/*     */   public int getRowIndex(BitSet support) {
/*     */     try {
/* 276 */       for (int i = 0; i < rows(); i++) {
/* 277 */         if (support.equals(getSupport(i))) {
/* 278 */           return i;
/*     */         }
/*     */       } 
/* 281 */     } catch (Exception e) {
/* 282 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 284 */     return -1;
/*     */   }
/*     */   
/*     */   public void addSumOfRows(int rowIndex1, int rowIndex2) throws Exception {
/* 288 */     int elements = 0;
/* 289 */     int elementsInRow1 = elementsInRow(rowIndex1);
/* 290 */     int elementsInRow2 = elementsInRow(rowIndex2);
/* 291 */     int j = 0;
/* 292 */     int k = 0;
/* 293 */     int col1 = this.rows.get(rowIndex1);
/* 294 */     int col2 = this.rows.get(rowIndex2);
/* 295 */     while (j < elementsInRow2 && k < elementsInRow1) {
/* 296 */       if (this.colIndices.get(col1 + k) < this.colIndices.get(col2 + j)) {
/* 297 */         this.colIndices.set(this.lastCol, this.colIndices.get(col1 + k));
/* 298 */         this.values.set(this.lastCol, this.values.get(col1 + k));
/* 299 */         this.lastCol++;
/* 300 */         k++;
/* 301 */         elements++; continue;
/* 302 */       }  if (this.colIndices.get(col1 + k) > this.colIndices.get(col2 + j)) {
/* 303 */         this.colIndices.set(this.lastCol, this.colIndices.get(col2 + j));
/* 304 */         this.values.set(this.lastCol, this.values.get(col2 + j));
/* 305 */         this.lastCol++;
/* 306 */         j++;
/* 307 */         elements++; continue;
/*     */       } 
/* 309 */       if (this.values.get(col1 + k) == this.values.get(col2 + j) * -1) {
/* 310 */         k++;
/* 311 */         j++;
/*     */         continue;
/*     */       } 
/* 314 */       elements++;
/* 315 */       this.colIndices.set(this.lastCol, this.colIndices.get(col2 + j));
/* 316 */       int val = this.values.get(col2 + j) + this.values.get(col1 + k);
/* 317 */       this.values.set(this.lastCol, val);
/*     */       
/* 319 */       this.lastCol++;
/* 320 */       k++;
/* 321 */       j++;
/*     */     } 
/*     */     
/* 324 */     while (j < elementsInRow2) {
/* 325 */       this.colIndices.set(this.lastCol, this.colIndices.get(col2 + j));
/* 326 */       this.values.set(this.lastCol, this.values.get(col2 + j));
/* 327 */       elements++;
/* 328 */       this.lastCol++;
/* 329 */       j++;
/*     */     } 
/* 331 */     while (k < elementsInRow1) {
/* 332 */       this.colIndices.set(this.lastCol, this.colIndices.get(col1 + k));
/* 333 */       this.values.set(this.lastCol, this.values.get(col1 + k));
/* 334 */       elements++;
/* 335 */       this.lastCol++;
/* 336 */       k++;
/*     */     } 
/*     */     
/* 339 */     this.rows.set(++this.lastRow, this.rows.get(this.lastRow - 1) + elements);
/*     */   }
/*     */   
/*     */   public void addSumOfRows(int rowIndex1, int factor2, int rowIndex2, int factor1) throws Exception {
/* 343 */     int elements = 0;
/* 344 */     int elementsInRow1 = elementsInRow(rowIndex1);
/* 345 */     int elementsInRow2 = elementsInRow(rowIndex2);
/* 346 */     int j = 0;
/* 347 */     int k = 0;
/* 348 */     int col1 = this.rows.get(rowIndex1);
/* 349 */     int col2 = this.rows.get(rowIndex2);
/* 350 */     while (j < elementsInRow2 && k < elementsInRow1) {
/* 351 */       if (this.colIndices.get(col1 + k) < this.colIndices.get(col2 + j)) {
/* 352 */         this.colIndices.set(this.lastCol, this.colIndices.get(col1 + k));
/* 353 */         check((this.values.get(col1 + k) * factor1));
/* 354 */         this.values.set(this.lastCol, this.values.get(col1 + k) * factor1);
/* 355 */         this.lastCol++;
/* 356 */         k++;
/* 357 */         elements++; continue;
/* 358 */       }  if (this.colIndices.get(col1 + k) > this.colIndices.get(col2 + j)) {
/* 359 */         this.colIndices.set(this.lastCol, this.colIndices.get(col2 + j));
/* 360 */         check((this.values.get(col2 + j) * factor2));
/* 361 */         this.values.set(this.lastCol, this.values.get(col2 + j) * factor2);
/* 362 */         this.lastCol++;
/* 363 */         j++;
/* 364 */         elements++; continue;
/*     */       } 
/* 366 */       if (this.values.get(col1 + k) * factor1 == this.values.get(col2 + j) * -1 * factor2) {
/* 367 */         k++;
/* 368 */         j++;
/*     */         continue;
/*     */       } 
/* 371 */       elements++;
/* 372 */       this.colIndices.set(this.lastCol, this.colIndices.get(col2 + j));
/* 373 */       int val = this.values.get(col2 + j) * factor2 + this.values.get(col1 + k) * factor1;
/* 374 */       check(val);
/* 375 */       this.values.set(this.lastCol, val);
/*     */       
/* 377 */       this.lastCol++;
/* 378 */       k++;
/* 379 */       j++;
/*     */     } 
/*     */     
/* 382 */     while (j < elementsInRow2) {
/* 383 */       this.colIndices.set(this.lastCol, this.colIndices.get(col2 + j));
/* 384 */       check((this.values.get(col2 + j) * factor2));
/* 385 */       this.values.set(this.lastCol, this.values.get(col2 + j) * factor2);
/* 386 */       elements++;
/*     */       
/* 388 */       this.lastCol++;
/* 389 */       j++;
/*     */     } 
/* 391 */     while (k < elementsInRow1) {
/* 392 */       this.colIndices.set(this.lastCol, this.colIndices.get(col1 + k));
/* 393 */       this.values.set(this.lastCol, this.values.get(col1 + k) * factor1);
/* 394 */       elements++;
/* 395 */       this.lastCol++;
/* 396 */       k++;
/*     */     } 
/*     */     
/* 399 */     this.rows.set(++this.lastRow, this.rows.get(this.lastRow - 1) + elements);
/*     */   }
/*     */   
/*     */   private void check(long toCheck) {
/* 403 */     if (this.values instanceof LinkedByteArray && (
/* 404 */       toCheck > 127L || toCheck < -128L)) {
/* 405 */       LOG.error("values too large for byte");
/* 406 */       System.exit(1);
/*     */     } 
/*     */     
/* 409 */     if (this.values instanceof LinkedShortArray && (
/* 410 */       toCheck > 127L || toCheck < -128L)) {
/* 411 */       LOG.error("values too large for short");
/* 412 */       System.exit(1);
/*     */     } 
/*     */     
/* 415 */     if (this.values instanceof LinkedIntArray && (
/* 416 */       toCheck > 2147483647L || toCheck < -2147483648L)) {
/* 417 */       LOG.error("values too large for int");
/* 418 */       System.exit(1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int elementsInRow(int row) throws Exception {
/* 424 */     if (getFirstColumnIndex(row) == -1) {
/* 425 */       return -1;
/*     */     }
/* 427 */     return this.rows.get(row + 1) - this.rows.get(row);
/*     */   }
/*     */   
/*     */   public int getRowIndex(int colIndex) {
/* 431 */     for (int i = 0; i < this.lastRow; i++) {
/* 432 */       if (this.rows.get(i) == this.lastRow) {
/* 433 */         return i;
/*     */       }
/* 435 */       if (this.rows.get(i) < this.lastRow) {
/* 436 */         return i - 1;
/*     */       }
/*     */     } 
/* 439 */     return -1;
/*     */   }
/*     */   
/*     */   public int[] addRows(int rowIndex1, int rowIndex2) throws Exception {
/* 443 */     int[] result = new int[this.rowLength];
/* 444 */     int elementsInRow1 = elementsInRow(rowIndex1);
/* 445 */     int elementsInRow2 = elementsInRow(rowIndex2);
/*     */     
/* 447 */     int col1 = this.rows.get(rowIndex1);
/* 448 */     int col2 = this.rows.get(rowIndex2);
/* 449 */     for (int i = 0; i < elementsInRow1 || i < elementsInRow2; i++) {
/* 450 */       if (i < elementsInRow1) {
/* 451 */         result[this.colIndices.get(col1 + i)] = result[this.colIndices.get(col1 + i)] + this.values.get(col1 + i);
/*     */       }
/* 453 */       if (i < elementsInRow2) {
/* 454 */         result[this.colIndices.get(col2 + i)] = result[this.colIndices.get(col2 + i)] + this.values.get(col2 + i);
/*     */       }
/*     */     } 
/* 457 */     return result;
/*     */   }
/*     */   public BitSet getSupport(int rowIndex) throws Exception {
/*     */     int elementsInRow1;
/* 461 */     BitSet result = new BitSet(this.rowLength);
/*     */     
/*     */     try {
/* 464 */       elementsInRow1 = elementsInRow(rowIndex);
/* 465 */     } catch (Exception e) {
/* 466 */       throw e;
/*     */     } 
/* 468 */     int col1 = this.rows.get(rowIndex);
/* 469 */     for (int i = 0; i < elementsInRow1; i++) {
/* 470 */       result.insert(this.colIndices.get(col1 + i));
/*     */     }
/* 472 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void multRow(int rowIndex, int factor) {
/*     */     try {
/* 479 */       int elementsInRow1 = elementsInRow(rowIndex);
/*     */       
/* 481 */       int col1 = this.rows.get(rowIndex);
/* 482 */       for (int i = 0; i < elementsInRow1; i++) {
/* 483 */         this.values.set(col1 + i, this.values.get(col1 + i) * factor);
/*     */       }
/* 485 */     } catch (Exception e) {
/* 486 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void divRow(int rowIndex, int factor) {
/*     */     try {
/* 492 */       int elementsInRow1 = elementsInRow(rowIndex);
/*     */       
/* 494 */       int col1 = this.rows.get(rowIndex);
/* 495 */       for (int i = 0; i < elementsInRow1; i++) {
/* 496 */         this.values.set(col1 + i, this.values.get(col1 + i) / factor);
/*     */       }
/* 498 */     } catch (Exception e) {
/* 499 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int rows() {
/* 504 */     return this.lastRow;
/*     */   }
/*     */   
/*     */   public int[] multiplyWithVector(int[] vector) {
/*     */     try {
/* 509 */       int[] result = new int[this.lastRow - 1];
/*     */       
/* 511 */       for (int i = 0; i < this.lastRow - 1; i++) {
/* 512 */         int[] row = getRow(i);
/* 513 */         if (row.length != vector.length) {
/* 514 */           System.out.println(row.length + "!=" + vector.length);
/* 515 */           return null;
/*     */         } 
/* 517 */         int sum = 0;
/* 518 */         for (int j = 0; j < vector.length; j++) {
/* 519 */           sum += row[j] * vector[j];
/*     */         }
/* 521 */         result[i] = sum;
/*     */       } 
/* 523 */       return result;
/* 524 */     } catch (Exception e) {
/* 525 */       LOG.error(e.getMessage(), e);
/*     */       
/* 527 */       return null;
/*     */     } 
/*     */   }
/*     */   public int getIndexofColumnInRow(int rowIndex, int colIndex) {
/*     */     try {
/* 532 */       int firstCol = this.rows.get(rowIndex);
/*     */       
/* 534 */       for (int i = 0; i < elementsInRow(rowIndex); i++) {
/* 535 */         if (this.colIndices.get(firstCol + i) == colIndex)
/* 536 */           return firstCol + i; 
/*     */       } 
/* 538 */     } catch (Exception e) {
/* 539 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 541 */     return -1;
/*     */   }
/*     */   
/*     */   public int[] multiplyToVector(int[] vector) {
/* 545 */     int[] result = new int[this.rowLength];
/*     */     try {
/* 547 */       if (vector.length != rows()) {
/* 548 */         System.out.println(rows() + "!=" + vector.length);
/* 549 */         return null;
/*     */       } 
/*     */       
/* 552 */       for (int i = 0; i < this.rowLength; i++) {
/* 553 */         int sum = 0;
/* 554 */         for (int j = 0; j < vector.length; j++) {
/*     */           
/* 556 */           int colIndex = getIndexofColumnInRow(j, i);
/* 557 */           if (colIndex >= 0) {
/* 558 */             sum += getValue(colIndex) * vector[j];
/*     */           }
/*     */         } 
/*     */         
/* 562 */         result[i] = sum;
/*     */       } 
/* 564 */     } catch (Exception e) {
/* 565 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 567 */     return result;
/*     */   }
/*     */   
/*     */   public int[] getRow(int rowIndex1) throws Exception {
/* 571 */     if (getFirstColumnIndex(rowIndex1) < 0)
/* 572 */       return null; 
/* 573 */     int[] result = new int[this.rowLength];
/* 574 */     int elementsInRow1 = elementsInRow(rowIndex1);
/*     */     
/* 576 */     int col1 = this.rows.get(rowIndex1);
/* 577 */     for (int i = 0; i < elementsInRow1; i++) {
/* 578 */       if (i < elementsInRow1) {
/* 579 */         result[this.colIndices.get(col1 + i)] = result[this.colIndices.get(col1 + i)] + this.values.get(col1 + i);
/*     */       }
/*     */     } 
/* 582 */     return result;
/*     */   }
/*     */   
/*     */   public static String printRow(int[] row) {
/* 586 */     if (row == null) {
/* 587 */       return "";
/*     */     }
/*     */     
/* 590 */     StringBuffer buf = new StringBuffer();
/* 591 */     for (int i = 0; i < row.length; i++) {
/* 592 */       buf.append(" ");
/* 593 */       if (row[i] >= 0)
/* 594 */         buf.append(" "); 
/* 595 */       buf.append(row[i]);
/*     */     } 
/* 597 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String printMatrix() {
/* 601 */     StringBuffer buf = new StringBuffer();
/*     */     try {
/* 603 */       for (int i = 0; i < this.lastRow; i++) {
/* 604 */         buf.append(i + 1).append(" - ").append(printRow(getRow(i))).append("\n");
/*     */       }
/* 606 */     } catch (Exception e) {
/* 607 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 610 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private int gcd(int a, int b) {
/* 615 */     while (b != 0) {
/* 616 */       a %= b;
/* 617 */       int c = b;
/* 618 */       b = a;
/* 619 */       a = c;
/* 620 */     }  return a;
/*     */   }
/*     */   
/*     */   public void applyGcdDevidingOnRow(int rowIndex) {
/*     */     try {
/* 625 */       int gcd = 1;
/*     */       
/* 627 */       if (elementsInRow(rowIndex) < 2) {
/* 628 */         gcd = getIthColumnValueInRow(rowIndex, 0);
/*     */       } else {
/*     */         
/* 631 */         gcd = gcd(getIthColumnValueInRow(rowIndex, 0), getIthColumnValueInRow(rowIndex, 1));
/*     */       } 
/*     */       
/* 634 */       for (int j = 1; j < elementsInRow(rowIndex); j++) {
/* 635 */         gcd = gcd(gcd, getIthColumnValueInRow(rowIndex, j));
/*     */         
/* 637 */         if (gcd == 1) {
/*     */           break;
/*     */         }
/*     */       } 
/* 641 */       if (gcd > 1) {
/* 642 */         divRow(rowIndex, gcd);
/*     */       }
/* 644 */     } catch (Exception e) {
/* 645 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void applyGcdDeviding() {
/* 650 */     for (int i = 0; i < rows(); i++) {
/* 651 */       applyGcdDevidingOnRow(i);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 657 */     StringBuffer str = new StringBuffer();
/* 658 */     str.append("Sparse Matrix\n"); int i;
/* 659 */     for (i = 0; i < this.lastRow - 1; i++) {
/* 660 */       str.append(this.rows.get(i)).append(" ");
/*     */     }
/* 662 */     str.append("\n");
/* 663 */     for (i = 0; i < this.lastCol; i++) {
/* 664 */       str.append(this.colIndices.get(i)).append(" ");
/*     */     }
/* 666 */     str.append("\n");
/* 667 */     for (i = 0; i < this.lastCol; i++) {
/* 668 */       str.append(this.values.get(i)).append(" ");
/*     */     }
/* 670 */     str.append("\n");
/*     */     
/* 672 */     return str.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/sm/SparseMatrix.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */