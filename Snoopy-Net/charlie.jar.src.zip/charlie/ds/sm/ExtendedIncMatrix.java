/*     */ package charlie.ds.sm;
/*     */ 
/*     */ import charlie.ds.BitSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Stack;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ public class ExtendedIncMatrix
/*     */   extends SparseMatrix
/*     */ {
/*  15 */   private final Vector<Integer> toDelete = new Vector<>();
/*     */   
/*  17 */   private static final Log LOG = LogFactory.getLog(ExtendedIncMatrix.class);
/*     */   
/*     */   public int identity;
/*  20 */   private HashMap<?, Integer> inv = new HashMap<>();
/*     */   
/*  22 */   private int nextCol = -1;
/*     */   
/*     */   public int realCols;
/*     */   
/*  26 */   double minRatio = 2.147483647E9D;
/*  27 */   long minRows = 2147483647L;
/*  28 */   long minElements = 2147483647L;
/*  29 */   int positiv = 0;
/*  30 */   long newRows = 2147483647L;
/*     */   
/*  32 */   long curElements = 2147483647L;
/*     */   
/*     */   public boolean colRemaining = false;
/*     */   
/*     */   public ExtendedIncMatrix(int rowLength, int identity) {
/*  37 */     super(rowLength);
/*  38 */     this.identity = identity;
/*  39 */     this.minimum = new int[rowLength - identity];
/*  40 */     this.realCols = rowLength - identity;
/*  41 */     this.negativs = new int[rowLength - identity];
/*  42 */     this.elements = new int[rowLength - identity];
/*  43 */     this.negElements = new int[rowLength - identity];
/*     */   }
/*     */   
/*     */   public ExtendedIncMatrix(int[][] m, int identity) {
/*  47 */     super(m);
/*  48 */     this.identity = identity;
/*  49 */     this.minimum = new int[this.rowLength - identity];
/*  50 */     this.negativs = new int[this.rowLength - identity];
/*  51 */     this.realCols = this.rowLength - identity;
/*  52 */     this.negElements = new int[this.rowLength - identity];
/*  53 */     this.elements = new int[this.rowLength - identity];
/*     */   }
/*     */ 
/*     */   
/*     */   public void actualizeTablesAdd(int rowIndex) {
/*     */     try {
/*  59 */       int firstCol = this.rows.get(rowIndex);
/*  60 */       int neg = 0; int k;
/*  61 */       for (k = 0; k < elementsInRow(rowIndex); k++) {
/*  62 */         if (this.values.get(firstCol + k) < 0) {
/*  63 */           neg++;
/*     */         }
/*     */       } 
/*  66 */       for (k = 0; k < elementsInRow(rowIndex); k++) {
/*  67 */         if (this.colIndices.get(firstCol + k) < this.realCols && this.minimum[this.colIndices.get(firstCol + k)] != Integer.MAX_VALUE) {
/*  68 */           this.minimum[this.colIndices.get(firstCol + k)] = this.minimum[this.colIndices.get(firstCol + k)] + 1;
/*     */           
/*  70 */           this.elements[this.colIndices.get(firstCol + k)] = this.elements[this.colIndices.get(firstCol + k)] + elementsInRow(rowIndex);
/*  71 */           this.negElements[this.colIndices.get(firstCol + k)] = this.negElements[this.colIndices.get(firstCol + k)] + neg;
/*  72 */           if (this.values.get(firstCol + k) < 0) {
/*  73 */             this.negativs[this.colIndices.get(firstCol + k)] = this.negativs[this.colIndices.get(firstCol + k)] + 1;
/*     */           }
/*     */         } 
/*     */       } 
/*  77 */     } catch (Exception e) {
/*  78 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void actualizeTablesDelete(int rowIndex) {
/*     */     try {
/*  85 */       int firstCol = this.rows.get(rowIndex);
/*  86 */       int neg = 0; int k;
/*  87 */       for (k = 0; k < elementsInRow(rowIndex); k++) {
/*  88 */         if (this.values.get(firstCol + k) < 0) {
/*  89 */           neg++;
/*     */         }
/*     */       } 
/*  92 */       for (k = 0; k < elementsInRow(rowIndex); k++) {
/*  93 */         if (this.colIndices.get(firstCol + k) < this.realCols && this.minimum[this.colIndices.get(firstCol + k)] != Integer.MAX_VALUE) {
/*  94 */           this.minimum[this.colIndices.get(firstCol + k)] = this.minimum[this.colIndices.get(firstCol + k)] - 1;
/*  95 */           if (this.minimum[this.colIndices.get(firstCol + k)] == 0) {
/*  96 */             this.minimum[this.colIndices.get(firstCol + k)] = Integer.MAX_VALUE;
/*     */           }
/*  98 */           this.elements[this.colIndices.get(firstCol + k)] = this.elements[this.colIndices.get(firstCol + k)] - elementsInRow(rowIndex);
/*  99 */           this.negElements[this.colIndices.get(firstCol + k)] = this.negElements[this.colIndices.get(firstCol + k)] - neg;
/* 100 */           if (this.values.get(firstCol + k) < 0) {
/* 101 */             this.negativs[this.colIndices.get(firstCol + k)] = this.negativs[this.colIndices.get(firstCol + k)] - 1;
/*     */           }
/*     */         } 
/*     */       } 
/* 105 */     } catch (Exception e) {
/* 106 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean homogenousRow(int rowIndex) throws Exception {
/*     */     int elementsInRow;
/*     */     try {
/* 113 */       elementsInRow = elementsInRow(rowIndex);
/* 114 */     } catch (Exception e) {
/* 115 */       throw e;
/*     */     } 
/* 117 */     int col1 = this.rows.get(rowIndex);
/* 118 */     boolean value = (getFirstColumnValue(rowIndex) > 0);
/* 119 */     for (int i = 1; i < elementsInRow; i++) {
/* 120 */       if (i < elementsInRow && 
/* 121 */         value != ((this.values.get(col1 + i) > 0))) {
/* 122 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int minCol() {
/* 131 */     if (this.nextCol > -1) {
/* 132 */       int ret = this.nextCol;
/* 133 */       this.nextCol++;
/* 134 */       return ret;
/*     */     } 
/*     */     
/* 137 */     this.minRatio = -2.147483648E9D;
/* 138 */     this.minRows = 2147483647L;
/* 139 */     this.newRows = 2147483647L;
/* 140 */     this.curElements = 2147483647L;
/* 141 */     this.minElements = 2147483647L;
/* 142 */     int id = -1;
/*     */     
/* 144 */     for (int i = 0; i < this.minimum.length; i++) {
/* 145 */       if (this.minimum[i] != Integer.MAX_VALUE && this.minimum[i] >= 0) {
/* 146 */         this.newRows = ((this.minimum[i] - this.negativs[i]) * this.negativs[i] - this.minimum[i]);
/* 147 */         if (this.newRows > Long.MAX_VALUE) {
/* 148 */           this.newRows = Long.MAX_VALUE;
/*     */         }
/* 150 */         if (this.newRows < this.minRows) {
/* 151 */           if (this.newRows == this.minRows) {
/* 152 */             if (this.elements[i] > this.elements[id]) {
/* 153 */               id = i;
/*     */             }
/*     */           } else {
/* 156 */             id = i;
/*     */           } 
/*     */           
/* 159 */           this.minRows = this.newRows;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 164 */     if (id < 0) {
/* 165 */       return id;
/*     */     }
/*     */     
/* 168 */     this.minimum[id] = Integer.MAX_VALUE;
/*     */     
/* 170 */     return id;
/*     */   }
/*     */   
/*     */   public Stack<Integer> getZero() {
/* 174 */     Stack<Integer> st = new Stack<>();
/* 175 */     for (int i = 0; i < this.minimum.length; i++) {
/* 176 */       if (this.minimum[i] == 0) {
/* 177 */         st.add(new Integer(i));
/* 178 */         this.minimum[i] = Integer.MAX_VALUE;
/*     */       } 
/*     */     } 
/* 181 */     return st;
/*     */   }
/*     */   
/*     */   public int max() {
/* 185 */     int res = 0;
/* 186 */     for (int i = 0; i < this.minimum.length; i++) {
/*     */       
/* 188 */       if (this.minimum[i] != Integer.MAX_VALUE) {
/* 189 */         res++;
/*     */       }
/*     */     } 
/*     */     
/* 193 */     return res;
/*     */   }
/*     */   
/*     */   public String printMinTable() {
/* 197 */     StringBuffer str = new StringBuffer(); int i;
/* 198 */     for (i = 0; i < this.minimum.length; i++) {
/* 199 */       if (this.minimum[i] == Integer.MAX_VALUE) {
/* 200 */         str.append("R\t");
/*     */       } else {
/* 202 */         str.append(this.minimum[i] + "\t");
/*     */       } 
/*     */     } 
/* 205 */     str.append("\n");
/* 206 */     for (i = 0; i < this.minimum.length; i++) {
/* 207 */       if (this.minimum[i] == Integer.MAX_VALUE)
/* 208 */       { str.append("R\t"); }
/*     */       else
/* 210 */       { str.append(this.negativs[i] + "\t"); } 
/* 211 */     }  str.append("\n");
/* 212 */     return str.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void insert(int elem) {
/* 217 */     int i = 0;
/* 218 */     while (i < this.toDelete.size() && ((Integer)this.toDelete.get(i)).intValue() < elem) {
/* 219 */       i++;
/*     */     }
/* 221 */     if (i < this.toDelete.size() && ((Integer)this.toDelete.get(i)).intValue() == elem)
/* 222 */       return;  if (i == this.toDelete.size()) {
/* 223 */       this.toDelete.add(new Integer(elem));
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 228 */       this.toDelete.insertElementAt(new Integer(elem), i);
/* 229 */     } catch (Exception e) {
/* 230 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int deleteMarkedRows() {
/* 235 */     int size = this.toDelete.size();
/*     */     try {
/* 237 */       while (!this.toDelete.isEmpty()) {
/* 238 */         int delete = ((Integer)this.toDelete.get(this.toDelete.size() - 1)).intValue();
/* 239 */         deleteRow(delete);
/* 240 */         this.toDelete.remove(this.toDelete.size() - 1);
/*     */       } 
/* 242 */     } catch (Exception e) {
/* 243 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 245 */     return size;
/*     */   }
/*     */   
/*     */   public int deleteMarkedRows2() {
/* 249 */     int size = this.toDelete.size();
/*     */     try {
/* 251 */       for (Iterator<Integer> it = this.toDelete.iterator(); it.hasNext(); ) {
/* 252 */         int i = ((Integer)it.next()).intValue();
/* 253 */         actualizeTablesDelete(i);
/*     */       } 
/* 255 */       deleteRows(this.toDelete);
/* 256 */     } catch (Exception e) {
/* 257 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 260 */     return size;
/*     */   }
/*     */   
/*     */   public BitSet getSupport(int rowIndex) throws Exception {
/*     */     int elementsInRow1;
/* 265 */     BitSet result = new BitSet(this.identity);
/*     */     
/*     */     try {
/* 268 */       elementsInRow1 = elementsInRow(rowIndex);
/* 269 */     } catch (Exception e) {
/* 270 */       throw e;
/*     */     } 
/* 272 */     int col1 = this.rows.get(rowIndex);
/* 273 */     for (int i = 0; i < elementsInRow1; i++) {
/* 274 */       if (this.colIndices.get(col1 + i) >= this.rowLength - this.identity) {
/* 275 */         result.insert(this.colIndices.get(col1 + i) - this.rowLength + this.identity);
/*     */       }
/*     */     } 
/* 278 */     return result;
/*     */   }
/*     */   public void getSupport(int rowIndex, BitSet result) throws Exception {
/*     */     int elementsInRow1;
/* 282 */     result.clear();
/*     */     
/*     */     try {
/* 285 */       elementsInRow1 = elementsInRow(rowIndex);
/* 286 */     } catch (Exception e) {
/* 287 */       throw e;
/*     */     } 
/* 289 */     int col1 = this.rows.get(rowIndex);
/* 290 */     for (int i = 0; i < elementsInRow1; i++) {
/* 291 */       if (this.colIndices.get(col1 + i) >= this.rowLength - this.identity) {
/* 292 */         result.insert(this.colIndices.get(col1 + i) - this.rowLength + this.identity);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int invariants() {
/* 300 */     return rows();
/*     */   }
/*     */   
/*     */   public int[] getInvariant(int index) {
/* 304 */     int[] result = new int[this.identity];
/*     */     try {
/* 306 */       for (int i = 0; i < elementsInRow(index); i++) {
/*     */         
/* 308 */         if (this.colIndices.get(this.rows.get(index) + i) >= this.rowLength - this.identity) {
/* 309 */           result[this.colIndices.get(this.rows.get(index) + i) - this.rowLength - this.identity] = this.values.get(this.rows.get(index) + i);
/*     */         }
/*     */       } 
/* 312 */     } catch (Exception e) {
/* 313 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 315 */     return result;
/*     */   }
/*     */   
/*     */   public void printInv() {
/*     */     try {
/* 320 */       System.out.println("Invariants: " + this.inv.size());
/* 321 */       int i = 0;
/* 322 */       for (Iterator<Integer> it = this.inv.values().iterator(); it.hasNext(); ) {
/* 323 */         System.out.print(i + ". ");
/* 324 */         int rowIndex = ((Integer)it.next()).intValue();
/* 325 */         System.out.println(printRow(getRow(rowIndex)));
/* 326 */         i++;
/*     */       } 
/* 328 */     } catch (Exception e) {
/* 329 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/sm/ExtendedIncMatrix.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */