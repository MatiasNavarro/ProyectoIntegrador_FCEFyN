/*     */ package charlie.ds.sm;
/*     */ 
/*     */ import charlie.ds.BitSet;
/*     */ import charlie.ds.bdd.BDD;
/*     */ import charlie.ds.bdd.SharedBDD;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SupportCheck
/*     */ {
/*  16 */   private static final Log LOG = LogFactory.getLog(SupportCheck.class);
/*     */   
/*  18 */   private long ms_add = 0L;
/*  19 */   private long ms_min = 0L;
/*  20 */   private long ms = 0L;
/*     */   
/*  22 */   private final HashMap<BitSet, BitSet> min = new HashMap<>();
/*     */   
/*  24 */   private int tries = 0;
/*     */   
/*  26 */   BDD bdd = (BDD)SharedBDD.Zero;
/*     */   
/*     */   public int sizeOfMin() {
/*  29 */     return this.min.size();
/*     */   }
/*     */   
/*     */   public boolean add2Bdd(BitSet bs) {
/*  33 */     if (min2Bdd(bs)) {
/*  34 */       return false;
/*     */     }
/*     */     
/*  37 */     long start = System.currentTimeMillis();
/*  38 */     int[] path = new int[bs.size()];
/*  39 */     int i = 0;
/*  40 */     for (Iterator<Integer> it = bs.iterator(); it.hasNext(); ) {
/*  41 */       path[i] = ((Integer)it.next()).intValue();
/*  42 */       i++;
/*     */     } 
/*     */     
/*  45 */     SharedBDD add = new SharedBDD(bs);
/*     */     
/*  47 */     if (this.bdd.isEqual((BDD)SharedBDD.Zero)) {
/*  48 */       this.bdd = (BDD)add;
/*     */       
/*  50 */       return true;
/*     */     } 
/*  52 */     BDD remainingPaths = this.bdd.notContainsSubPath(path);
/*     */     
/*  54 */     this.bdd.free();
/*  55 */     this.bdd = remainingPaths.or((BDD)add);
/*  56 */     remainingPaths.free();
/*     */     
/*  58 */     add.free();
/*  59 */     this.ms_add += System.currentTimeMillis() - start;
/*     */     
/*  61 */     return true;
/*     */   }
/*     */   
/*     */   public boolean add2Bdd(ExtendedIncMatrix sm, int row) {
/*  65 */     SharedBDD add = null;
/*  66 */     int cur = 0;
/*  67 */     long start = System.currentTimeMillis();
/*     */     try {
/*  69 */       if (min2Bdd(sm, row)) {
/*  70 */         return false;
/*     */       }
/*     */       
/*  73 */       add = new SharedBDD(sm, row);
/*     */       
/*  75 */       if (this.bdd.isEqual((BDD)SharedBDD.Zero)) {
/*  76 */         this.bdd = (BDD)add;
/*     */         
/*  78 */         return true;
/*     */       } 
/*     */       
/*  81 */       for (int i = 0; i < sm.elementsInRow(row) && 
/*  82 */         sm.getIthColumnIndexInRow(row, i) < sm.rowLength - sm.identity; i++) {
/*  83 */         cur++;
/*     */ 
/*     */       
/*     */       }
/*     */     
/*     */     }
/*  89 */     catch (Exception e) {
/*  90 */       System.out.println("error");
/*  91 */       System.exit(1);
/*     */     } 
/*  93 */     BDD remainingPaths = ((SharedBDD)this.bdd).notContainsSubPath(sm, row, cur);
/*     */     
/*  95 */     this.bdd.free();
/*  96 */     this.bdd = remainingPaths.or((BDD)add);
/*  97 */     remainingPaths.free();
/*     */     
/*  99 */     add.free();
/* 100 */     this.ms_add += System.currentTimeMillis() - start;
/*     */     
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public long bddSize() {
/* 107 */     return this.bdd.paths();
/*     */   }
/*     */   
/*     */   public long bddNodes() {
/* 111 */     return this.bdd.nodes();
/*     */   }
/*     */   
/*     */   public boolean min2Bdd(BitSet bs) {
/* 115 */     long start = System.currentTimeMillis();
/* 116 */     int[] path = new int[bs.size()];
/*     */     
/* 118 */     int i = 0;
/* 119 */     for (Iterator<Integer> it = bs.iterator(); it.hasNext(); ) {
/* 120 */       path[i] = ((Integer)it.next()).intValue();
/* 121 */       i++;
/*     */     } 
/* 123 */     this.ms_min += System.currentTimeMillis() - start;
/*     */     
/* 125 */     return this.bdd.containsSubPathOf(path);
/*     */   }
/*     */   
/*     */   public boolean min2Bdd(ExtendedIncMatrix sm, int row) {
/* 129 */     int cur = 0;
/*     */     
/* 131 */     long start = System.currentTimeMillis();
/*     */     try {
/* 133 */       this.ms_min += System.currentTimeMillis() - start;
/* 134 */       for (int i = 0; i < sm.elementsInRow(row) && 
/* 135 */         sm.getIthColumnIndexInRow(row, i) < sm.rowLength - sm.identity; i++) {
/* 136 */         cur++;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 141 */       return ((SharedBDD)this.bdd).containsSubPathOf(sm, row, cur);
/* 142 */     } catch (Exception e) {
/* 143 */       LOG.error(e.getMessage(), e);
/*     */ 
/*     */       
/* 146 */       return false;
/*     */     } 
/*     */   }
/*     */   public boolean add2(BitSet bs) {
/* 150 */     long start = System.currentTimeMillis();
/*     */     
/* 152 */     this.tries++;
/*     */     
/* 154 */     HashSet<BitSet> del = new HashSet<>();
/* 155 */     for (Iterator<BitSet> keyIt = this.min.keySet().iterator(); keyIt.hasNext(); ) {
/* 156 */       BitSet inMap = keyIt.next();
/*     */       
/* 158 */       if (inMap.subSet(bs)) {
/* 159 */         this.ms += System.currentTimeMillis() - start;
/* 160 */         return false;
/*     */       } 
/* 162 */       if (bs.subSet(inMap)) {
/* 163 */         del.add(inMap);
/*     */       }
/*     */     } 
/*     */     
/* 167 */     BitSet b = bs.copy();
/* 168 */     this.min.put(b, b);
/*     */     
/* 170 */     for (Iterator<BitSet> it = del.iterator(); it.hasNext(); ) {
/* 171 */       BitSet o = it.next();
/* 172 */       this.min.remove(o);
/*     */     } 
/*     */     
/* 175 */     this.ms += System.currentTimeMillis() - start;
/*     */     
/* 177 */     return true;
/*     */   }
/*     */   
/*     */   public boolean checkRemaining(BitSet bs, HashSet<BitSet> deleted, BitSet info) {
/* 181 */     this.tries++;
/*     */     
/* 183 */     HashSet<BitSet> del = new HashSet<>();
/* 184 */     for (Iterator<BitSet> keyIt = this.min.keySet().iterator(); keyIt.hasNext(); ) {
/* 185 */       BitSet inMap = keyIt.next();
/* 186 */       if (inMap.subSet(bs)) {
/* 187 */         del.add(bs);
/* 188 */         deleted.add(info);
/* 189 */         return false;
/* 190 */       }  if (bs.subSet(inMap)) {
/* 191 */         del.add(inMap);
/* 192 */         deleted.add(this.min.get(inMap));
/*     */       } 
/*     */     } 
/*     */     
/* 196 */     this.min.put(bs, info);
/*     */     
/* 198 */     for (Iterator<BitSet> it = del.iterator(); it.hasNext(); ) {
/* 199 */       BitSet o = it.next();
/* 200 */       LOG.info("not minimal: " + o);
/* 201 */       this.min.remove(o);
/*     */     } 
/*     */     
/* 204 */     return true;
/*     */   }
/*     */   
/*     */   public boolean checkMin(BitSet bs) {
/* 208 */     long start = System.currentTimeMillis();
/* 209 */     for (Iterator<BitSet> keyIt = this.min.keySet().iterator(); keyIt.hasNext(); ) {
/* 210 */       BitSet inMap = keyIt.next();
/* 211 */       if (inMap.subSet(bs)) {
/* 212 */         this.ms += System.currentTimeMillis() - start;
/* 213 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 217 */     this.ms += System.currentTimeMillis() - start;
/*     */     
/* 219 */     return false;
/*     */   }
/*     */   
/*     */   public boolean checkMin2(BitSet bs) {
/* 223 */     long start = System.currentTimeMillis();
/* 224 */     for (Iterator<BitSet> keyIt = this.min.keySet().iterator(); keyIt.hasNext(); ) {
/* 225 */       BitSet inMap = keyIt.next();
/* 226 */       if (inMap.subSet(bs) && !inMap.equals(bs)) {
/* 227 */         this.ms += System.currentTimeMillis() - start;
/* 228 */         return true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 233 */     this.ms += System.currentTimeMillis() - start;
/*     */     
/* 235 */     return false;
/*     */   }
/*     */   
/*     */   public int supports() {
/* 239 */     return this.min.size();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/sm/SupportCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */