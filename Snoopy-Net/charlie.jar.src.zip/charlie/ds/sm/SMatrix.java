package charlie.ds.sm;

public interface SMatrix {}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/sm/SMatrix.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */