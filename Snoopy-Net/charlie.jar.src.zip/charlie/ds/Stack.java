/*    */ package charlie.ds;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class Stack<E>
/*    */ {
/*    */   private StackEntry top;
/*    */   private int size;
/*    */   private StackEntry garbage;
/*    */   private StackEntry h;
/*    */   
/*    */   class StackEntry {
/*    */     E val;
/*    */     StackEntry next;
/*    */   }
/*    */   
/*    */   public E peek() {
/* 18 */     return this.top.val;
/*    */   }
/*    */   
/*    */   public E pop() {
/* 22 */     this.size--;
/* 23 */     E o = peek();
/* 24 */     this.h = this.garbage;
/* 25 */     this.garbage = this.top;
/* 26 */     this.top = this.top.next;
/* 27 */     this.garbage.next = this.h;
/*    */     
/* 29 */     return o;
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 33 */     return (this.size == 0);
/*    */   }
/*    */   
/*    */   public int size() {
/* 37 */     return this.size;
/*    */   }
/*    */   
/*    */   public void push(E o) {
/*    */     StackEntry e;
/* 42 */     if (this.garbage == null) {
/* 43 */       e = new StackEntry();
/*    */     } else {
/* 45 */       e = this.garbage;
/* 46 */       this.garbage = this.garbage.next;
/*    */     } 
/* 48 */     e.val = o;
/* 49 */     e.next = this.top;
/* 50 */     this.top = e;
/* 51 */     this.size++;
/*    */   }
/*    */   
/*    */   public Iterator<E> iterator() {
/* 55 */     StackIterator it = new StackIterator();
/* 56 */     it.cur = this.top;
/*    */     
/* 58 */     return it;
/*    */   }
/*    */   
/*    */   class StackIterator implements Iterator<E> {
/*    */     Stack<E>.StackEntry cur;
/*    */     
/*    */     public E next() {
/* 65 */       E o = this.cur.val;
/* 66 */       this.cur = this.cur.next;
/* 67 */       return o;
/*    */     }
/*    */     
/*    */     public boolean hasNext() {
/* 71 */       return (this.cur != null);
/*    */     }
/*    */ 
/*    */     
/*    */     public void remove() {}
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 80 */     StringBuffer res = new StringBuffer();
/* 81 */     Iterator<E> it = iterator();
/* 82 */     while (it.hasNext()) {
/* 83 */       res.append(it.next());
/*    */     }
/* 85 */     return res.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/Stack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */