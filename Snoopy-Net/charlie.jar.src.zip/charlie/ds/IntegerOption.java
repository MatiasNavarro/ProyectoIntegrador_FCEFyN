/*    */ package charlie.ds;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ public class IntegerOption
/*    */   implements Option
/*    */ {
/*    */   private HashSet dependencies;
/*    */   private HashSet listeners;
/*    */   Integer value;
/*    */   
/*    */   private void init() {
/* 15 */     this.listeners = new HashSet();
/* 16 */     this.dependencies = new HashSet();
/*    */   }
/*    */ 
/*    */   
/*    */   public IntegerOption(Integer value) {
/* 21 */     init();
/* 22 */     setValue(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public IntegerOption(int value) {
/* 27 */     init();
/* 28 */     setValue(new Integer(value));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addDependency(OptionChangeAction oca) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void addOptionListener(OptionListener ol) {
/* 39 */     this.listeners.add(ol);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 44 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 52 */     return this.value.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int intValue() {
/* 61 */     return this.value.intValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeDependcy(OptionChangeAction oca) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeOptionListener(OptionListener ol) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(Object value) {
/* 77 */     this.value = (Integer)value;
/* 78 */     for (Iterator<OptionListener> it = this.listeners.iterator(); it.hasNext();) {
/* 79 */       ((OptionListener)it.next()).reactOnChange(this);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(int value) {
/* 85 */     this.value = new Integer(value);
/* 86 */     for (Iterator<OptionListener> it = this.listeners.iterator(); it.hasNext();)
/* 87 */       ((OptionListener)it.next()).reactOnChange(this); 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/IntegerOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */