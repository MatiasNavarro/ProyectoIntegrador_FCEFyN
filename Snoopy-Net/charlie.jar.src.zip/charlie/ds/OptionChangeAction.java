/*    */ package charlie.ds;
/*    */ 
/*    */ public class OptionChangeAction {
/*    */   protected Object value1;
/*    */   protected Object value2;
/*    */   protected Option o;
/*    */   
/*    */   public OptionChangeAction(Option o, Object v1, Object v2) {
/*  9 */     this.value1 = v1;
/* 10 */     this.value2 = v2;
/* 11 */     this.o = o;
/*    */   }
/*    */   
/*    */   public boolean checkValue(Object value) {
/* 15 */     if (this.value1.equals(value)) {
/* 16 */       doAction();
/*    */     }
/* 18 */     return false;
/*    */   }
/*    */   
/*    */   public void doAction() {
/* 22 */     this.o.setValue(this.value2);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/OptionChangeAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */