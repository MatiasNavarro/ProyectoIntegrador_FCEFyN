/*     */ package charlie.ds;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class HashStack {
/*     */   private Entry anchor;
/*   8 */   private final HashMap<Entry, Entry> map = new HashMap<>();
/*     */   private int size;
/*     */   
/*     */   class Entry {
/*     */     Object elem;
/*     */     Entry next;
/*     */     int count;
/*     */     
/*     */     Entry(Object e, Entry n) {
/*  17 */       this.elem = e;
/*  18 */       this.next = n;
/*  19 */       this.count = 1;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*  23 */       return this.elem.hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj) {
/*  27 */       if (!(obj instanceof Entry)) return false; 
/*  28 */       return this.elem.equals(((Entry)obj).elem);
/*     */     }
/*     */     
/*     */     public String toString() {
/*  32 */       return this.elem.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public HashStack() {
/*  38 */     this.anchor = null;
/*  39 */     this.size = 0;
/*     */   }
/*     */   
/*     */   public int size() {
/*  43 */     return this.size;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  47 */     this.anchor = null;
/*  48 */     this.size = 0;
/*  49 */     this.map.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object obj) {
/*  54 */     return this.map.containsKey(new Entry(obj, null));
/*     */   }
/*     */   
/*     */   public int commoness(Object obj) {
/*  58 */     if (!contains(obj)) return 0; 
/*  59 */     Entry e = this.map.get(new Entry(obj, null));
/*  60 */     return e.count;
/*     */   }
/*     */   
/*     */   public void push(Object obj) {
/*  64 */     Entry e = this.map.get(new Entry(obj, null));
/*  65 */     this.anchor = new Entry(obj, this.anchor);
/*  66 */     if (e == null) {
/*  67 */       this.map.put(this.anchor, this.anchor);
/*     */     } else {
/*  69 */       e.count++;
/*     */     } 
/*     */     
/*  72 */     this.size++;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  76 */     return (this.size == 0);
/*     */   }
/*     */   public Object peek() {
/*  79 */     if (isEmpty()) return null; 
/*  80 */     return this.anchor.elem;
/*     */   }
/*     */   
/*     */   public Object pop() {
/*  84 */     if (isEmpty()) return null; 
/*  85 */     Object ret = this.anchor.elem;
/*  86 */     Entry e = this.map.get(this.anchor);
/*  87 */     e.count--;
/*  88 */     if (e.count == 0) {
/*  89 */       this.map.remove(this.anchor);
/*     */     }
/*  91 */     this.anchor = this.anchor.next;
/*  92 */     this.size--;
/*  93 */     return ret;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  97 */     String ret = "content: \n";
/*  98 */     Entry h = this.anchor;
/*  99 */     while (h != null) {
/* 100 */       ret = ret + h.toString() + "\n";
/* 101 */       h = h.next;
/*     */     } 
/* 103 */     return ret;
/*     */   }
/*     */   
/*     */   public Iterator<Object> iterator() {
/* 107 */     return new HashStackIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   class HashStackIterator
/*     */     implements Iterator<Object>
/*     */   {
/* 114 */     HashStack.Entry current = HashStack.this.anchor;
/*     */ 
/*     */     
/*     */     public Object next() {
/* 118 */       Object ret = this.current.elem;
/* 119 */       this.current = this.current.next;
/* 120 */       return ret;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 124 */       return (this.current != null);
/*     */     }
/*     */     
/*     */     public void remove() {}
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/HashStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */