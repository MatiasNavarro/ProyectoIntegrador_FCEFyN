/*    */ package charlie.ds.bdd;
/*    */ 
/*    */ class BddNode {
/*    */   protected int var;
/*    */   protected int low;
/*    */   protected int high;
/*    */   boolean marked;
/*    */   int references;
/*    */   int hc;
/*    */   
/*    */   public BddNode(int var, int low, int high) {
/* 12 */     init(var, low, high);
/*    */   }
/*    */ 
/*    */   
/*    */   public void init(int var, int low, int high) {
/* 17 */     this.var = var;
/* 18 */     this.high = high;
/* 19 */     this.low = low;
/* 20 */     this.references = 0;
/* 21 */     this.marked = false;
/* 22 */     this.hc = 0;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 26 */     if (!(obj instanceof BddNode)) return false; 
/* 27 */     BddNode toCompare = (BddNode)obj;
/* 28 */     return (this.var == toCompare.var && this.high == toCompare.high && this.low == toCompare.low);
/*    */   }
/*    */   
/* 31 */   static StringBuffer s = new StringBuffer();
/* 32 */   static int hashBitNr = 5;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 49 */     int h = this.hc;
/* 50 */     if (h == 0) {
/*    */       
/* 52 */       this.hc = 31 * this.var;
/* 53 */       this.hc = 31 * this.hc + this.low;
/* 54 */       this.hc = 32 * this.hc + this.high;
/* 55 */       h = this.hc;
/*    */     } 
/*    */     
/* 58 */     return h;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 62 */     return "var: " + this.var + " low: " + this.low + " heigh: " + this.high + " ref: " + this.references;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/bdd/BddNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */