/*      */ package charlie.ds.bdd;
/*      */ 
/*      */ import charlie.ds.BitSet;
/*      */ import charlie.ds.sm.ExtendedIncMatrix;
/*      */ import charlie.pn.Marking;
/*      */ import charlie.pn.UnsignedByte;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SharedBDDMS
/*      */   implements BDD
/*      */ {
/*   19 */   public static BddNode dummy = new BddNode(-2147483648, 2147483647, -2147483648);
/*      */   private boolean instantiated = false;
/*      */   private boolean active;
/*   22 */   public static Operation and = new And();
/*   23 */   public static Operation subset0 = new Operation() {
/*      */       public int op(int r1, int r2) {
/*   25 */         return -1;
/*      */       }
/*      */     };
/*      */   
/*   29 */   public static Operation andNot = new Operation() {
/*      */       public int op(int r1, int r2) {
/*   31 */         if (r1 == 0) return 0; 
/*   32 */         if (r2 == 1) return 0; 
/*   33 */         return 1;
/*      */       }
/*      */     };
/*      */   
/*   37 */   public static Operation subset1 = new Operation() {
/*      */       public int op(int r1, int r2) {
/*   39 */         return -1;
/*      */       }
/*      */     };
/*   42 */   public static Operation or = new Or();
/*   43 */   public static Operation change = new Operation() {
/*      */       public int op(int r1, int r2) {
/*   45 */         return -1;
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*   51 */   long timeOrg = 0L;
/*   52 */   private static HashSet pool = new HashSet(1000);
/*   53 */   private static HashMap freeRoots = new HashMap<>(10000);
/*   54 */   private static HashMap instancedBdds = new HashMap<>(100);
/*      */   
/*   56 */   public static int instances = 0;
/*   57 */   protected static BddNode[] nodes = new BddNode[1000];
/*   58 */   private static int size = 0;
/*   59 */   private static HashSet freeNodeIndices = new HashSet();
/*   60 */   private static HashMap uniqueTable = new HashMap<>(20000);
/*   61 */   public static SharedBDDMS Zero = new SharedBDDMS(makeNode(100, -1, -1));
/*   62 */   public static SharedBDDMS One = new SharedBDDMS(makeNode(100, -1, -1));
/*      */   
/*      */   public int root;
/*      */   
/*      */   public String toString_(int root) {
/*   67 */     String res = "";
/*   68 */     if (root < 2) return res + "(" + root + ")"; 
/*   69 */     Integer i = new Integer(root);
/*   70 */     if (this.resultCount.get(i) != null) return "[ r: " + root + " v: " + (nodes[root]).var + "]"; 
/*   71 */     this.resultCount.put(i, i);
/*   72 */     return "(" + toString_((nodes[root]).low) + ") r: " + root + " v: " + (nodes[root]).var + "(" + toString_((nodes[root]).high) + ")";
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*   77 */     this.resultCount.clear();
/*   78 */     return toString_(this.root);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void insert(SharedBDDMS b) {
/*   84 */     Object key = new Integer(b.root());
/*   85 */     Int occ = (Int)instancedBdds.get(key);
/*   86 */     if (occ == null) {
/*      */       
/*   88 */       occ = new Int(1);
/*   89 */       instancedBdds.put(key, occ);
/*      */     } else {
/*      */       
/*   92 */       occ.value++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static void remove(SharedBDDMS b) {
/*   99 */     Object key = new Integer(b.root());
/*  100 */     Int occ = (Int)instancedBdds.get(key);
/*  101 */     if (occ != null) {
/*      */ 
/*      */       
/*  104 */       occ.value--;
/*  105 */       if (occ.value == 0) {
/*  106 */         instancedBdds.remove(key);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void paths_(int root1, String str) {
/*  116 */     String res = new String(str);
/*  117 */     if (root1 == 1) { System.out.println(str);
/*      */       
/*      */       return; }
/*      */     
/*  121 */     if ((nodes[root1]).var < 0) {
/*  122 */       System.out.println("!!!!!!!!!!!!");
/*      */     }
/*      */     
/*  125 */     if (root1 == 0)
/*  126 */       return;  paths_((nodes[root1]).low, str + "");
/*  127 */     paths_((nodes[root1]).high, str + " " + (nodes[root1]).var);
/*      */   }
/*      */   
/*      */   public void printPaths() {
/*  131 */     paths_(this.root, "");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int freeNodes() {
/*  137 */     return freeNodeIndices.size() + nodes.length - size;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void printNodesInfo() {
/*  142 */     for (int i = 0; i < nodes.length; i++) {
/*  143 */       if (nodes[i] != null) {
/*  144 */         System.out.println(i + " -- " + nodes[i]);
/*      */       } else {
/*  146 */         System.out.println(i + " -- null");
/*      */       } 
/*  148 */     }  System.out.println("instances " + instances);
/*      */   }
/*      */ 
/*      */   
/*      */   public void assign(SharedBDDMS bdd) {
/*  153 */     assign(bdd.root);
/*      */   }
/*      */   
/*      */   public void assign(int root) {
/*  157 */     if (this.instantiated) free(); 
/*  158 */     setRoot(root);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setRoot(int root) {
/*  212 */     this.root = root;
/*      */     
/*  214 */     insert(this);
/*  215 */     this.instantiated = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD notContainsSubPath(int[] subPath) {
/*  235 */     resultPathTable.clear();
/*  236 */     return new SharedBDDMS(notContainsSubPath_(this.root, subPath, 0, true));
/*      */   }
/*      */   public int notContainsSubPath_(int root, int[] path, int current, boolean isPath) {
/*      */     int res;
/*  240 */     PathKey pKey = new PathKey(root, path, current, isPath);
/*  241 */     Integer i = (Integer)resultPathTable.get(pKey);
/*  242 */     if (i != null && i != null)
/*      */     {
/*  244 */       return i.intValue();
/*      */     }
/*      */     
/*  247 */     if (root == 1 && current == path.length && !isPath) return 1; 
/*  248 */     if (root == 1 && current == path.length && isPath) return 0; 
/*  249 */     if (root == 1 && current < path.length) return 1; 
/*  250 */     if (root == 0) return 0;
/*      */ 
/*      */     
/*  253 */     if (current == path.length && isPath) return 0; 
/*  254 */     if (current == path.length && !isPath) { res = makeNode((nodes[root]).var, notContainsSubPath_((nodes[root]).low, path, current, isPath), notContainsSubPath_((nodes[root]).high, path, current, isPath)); }
/*  255 */     else if ((nodes[root]).var == path[current])
/*  256 */     { int v0 = notContainsSubPath_((nodes[root]).low, path, current + 1, false);
/*  257 */       int v1 = notContainsSubPath_((nodes[root]).high, path, current + 1, isPath);
/*  258 */       if (v1 == 0) {
/*  259 */         res = v0;
/*      */       } else {
/*  261 */         res = makeNode((nodes[root]).var, v0, v1);
/*      */       }
/*      */        }
/*  264 */     else if ((nodes[root]).var < path[current])
/*  265 */     { res = makeNode((nodes[root]).var, notContainsSubPath_((nodes[root]).low, path, current, isPath), notContainsSubPath_((nodes[root]).high, path, current, isPath)); }
/*      */     else
/*  267 */     { res = makeNode((nodes[root]).var, notContainsSubPath_(root, path, current + 1, false), notContainsSubPath_(root, path, current + 1, false)); }
/*  268 */      resultPathTable.put(pKey, new Integer(res));
/*  269 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD notContainsSubPath(ExtendedIncMatrix sm, int row, int cur) {
/*  279 */     resultPathTable.clear();
/*  280 */     return new SharedBDDMS(notContainsSubPath_(this.root, sm, row, cur, true));
/*      */   } public int notContainsSubPath_(int root, ExtendedIncMatrix sm, int row, int current, boolean isPath) {
/*      */     try {
/*      */       int res;
/*  284 */       PathKey pKey = new PathKey(root, sm, current, isPath);
/*  285 */       Integer i = (Integer)resultPathTable.get(pKey);
/*  286 */       if (i != null && i != null)
/*      */       {
/*  288 */         return i.intValue();
/*      */       }
/*      */       
/*  291 */       if (root == 1 && current == sm.elementsInRow(row) && !isPath) return 1; 
/*  292 */       if (root == 1 && current == sm.elementsInRow(row) && isPath) return 0; 
/*  293 */       if (root == 1 && current < sm.elementsInRow(row)) return 1; 
/*  294 */       if (root == 0) return 0;
/*      */ 
/*      */       
/*  297 */       if (current == sm.elementsInRow(row) && isPath) return 0; 
/*  298 */       if (current == sm.elementsInRow(row) && !isPath) { res = makeNode((nodes[root]).var, notContainsSubPath_((nodes[root]).low, sm, row, current, isPath), notContainsSubPath_((nodes[root]).high, sm, row, current, isPath)); }
/*  299 */       else if ((nodes[root]).var == sm.getIthColumnIndexInRow(row, current) - sm.realCols)
/*  300 */       { int v0 = notContainsSubPath_((nodes[root]).low, sm, row, current + 1, false);
/*  301 */         int v1 = notContainsSubPath_((nodes[root]).high, sm, row, current + 1, isPath);
/*  302 */         if (v1 == 0) {
/*  303 */           res = v0;
/*      */         } else {
/*  305 */           res = makeNode((nodes[root]).var, v0, v1);
/*      */         }
/*      */          }
/*  308 */       else if ((nodes[root]).var < sm.getIthColumnIndexInRow(row, current) - sm.realCols)
/*  309 */       { res = makeNode((nodes[root]).var, notContainsSubPath_((nodes[root]).low, sm, row, current, isPath), notContainsSubPath_((nodes[root]).high, sm, row, current, isPath)); }
/*      */       else
/*  311 */       { res = makeNode((nodes[root]).var, notContainsSubPath_(root, sm, row, current + 1, false), notContainsSubPath_(root, sm, row, current + 1, false)); }
/*  312 */        resultPathTable.put(pKey, new Integer(res));
/*  313 */       return res;
/*  314 */     } catch (Exception e) {
/*  315 */       System.out.println("Error in notContainsSubPath- should not be possible");
/*  316 */       System.exit(1);
/*      */       
/*  318 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsSubPathOf(int[] path) {
/*  329 */     return subPathOf_(this.root, path, 0);
/*      */   }
/*      */   
/*      */   public boolean subPathOf_(int root, int[] path, int current) {
/*  333 */     if (root == 1) return true; 
/*  334 */     if (root == 0) return false; 
/*  335 */     if (current == path.length) return subPathOf_((nodes[root]).low, path, current); 
/*  336 */     if ((nodes[root]).var == path[current]) return (subPathOf_((nodes[root]).low, path, current + 1) || subPathOf_((nodes[root]).high, path, current + 1)); 
/*  337 */     if ((nodes[root]).var > path[current]) return subPathOf_(root, path, current + 1); 
/*  338 */     return subPathOf_((nodes[root]).low, path, current);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsSubPathOf(ExtendedIncMatrix sm, int row, int current) {
/*  346 */     return subPathOf_(this.root, sm, row, current);
/*      */   }
/*      */   
/*      */   public boolean subPathOf_(int root, ExtendedIncMatrix sm, int row, int current) {
/*      */     try {
/*  351 */       if (root == 1) return true; 
/*  352 */       if (root == 0) return false; 
/*  353 */       if (current == sm.elementsInRow(row)) return subPathOf_((nodes[root]).low, sm, row, current); 
/*  354 */       if ((nodes[root]).var == sm.getIthColumnIndexInRow(row, current) - sm.realCols) return (subPathOf_((nodes[root]).low, sm, row, current + 1) || subPathOf_((nodes[root]).high, sm, row, current + 1)); 
/*  355 */       if ((nodes[root]).var > sm.getIthColumnIndexInRow(row, current) - sm.realCols) return subPathOf_(root, sm, row, current + 1); 
/*  356 */       return subPathOf_((nodes[root]).low, sm, row, current);
/*  357 */     } catch (Exception e) {
/*  358 */       System.out.println("Error in subPathOf- should not be possible");
/*  359 */       System.exit(1);
/*      */       
/*  361 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD containsSubPath(int[] subPath) {
/*  375 */     return new SharedBDDMS(containsSubPath_(this.root, subPath, 0));
/*      */   }
/*      */   public int containsSubPath_(int root, int[] path, int current) {
/*      */     int res;
/*  379 */     PathKey pKey = new PathKey(root, path, current);
/*  380 */     Integer i = (Integer)resultPathTable.get(pKey);
/*  381 */     if (i != null)
/*      */     {
/*  383 */       return i.intValue();
/*      */     }
/*  385 */     if (root == 1 && current == path.length) return 1; 
/*  386 */     if (root == 1 && current < path.length) return 0; 
/*  387 */     if (root == 0) return 0;
/*      */     
/*  389 */     if (current == path.length) { res = makeNode((nodes[root]).var, containsSubPath_((nodes[root]).low, path, current), containsSubPath_((nodes[root]).high, path, current)); }
/*  390 */     else if ((nodes[root]).var == path[current]) { res = makeNode((nodes[root]).var, 0, containsSubPath_((nodes[root]).high, path, current + 1)); }
/*  391 */     else if ((nodes[root]).var < path[current]) { res = makeNode((nodes[root]).var, containsSubPath_((nodes[root]).low, path, current), containsSubPath_((nodes[root]).high, path, current)); }
/*  392 */     else { return 0; }
/*      */     
/*  394 */     resultPathTable.put(pKey, new Integer(res));
/*  395 */     return res;
/*      */   }
/*      */ 
/*      */   
/*      */   private int increment(int max, int val) {
/*  400 */     if (val < max) return val + 1; 
/*  401 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int fire(Marking prePost) {
/*  413 */     resultFireTable.clear();
/*  414 */     pool.clear();
/*  415 */     return fire_(this.root, prePost, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  420 */   public static int fireCacheHits = 0;
/*  421 */   public static int fireCacheMisses = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int fire_(int root1, Marking prePost, int cur) {
/*  427 */     FireKey fk = new FireKey(root1, prePost, cur);
/*      */     
/*  429 */     if (cur == prePost.size() || root1 == 0) return root1; 
/*  430 */     int val = prePost.getToken(cur);
/*  431 */     Integer i = (Integer)resultFireTable.get(fk);
/*  432 */     if (i != null) {
/*      */       
/*  434 */       fireCacheHits++;
/*  435 */       return i.intValue();
/*      */     } 
/*  437 */     fireCacheMisses++;
/*      */     
/*  439 */     int id = UnsignedByte.unsign(prePost.getId(cur));
/*      */     
/*  441 */     int res = 0;
/*      */     
/*  443 */     if ((nodes[root1]).var == id) {
/*      */ 
/*      */       
/*  446 */       switch (val) {
/*      */         
/*      */         case 1:
/*  449 */           res = fire_((nodes[root1]).high, prePost, increment(prePost.size(), cur));
/*      */           break;
/*      */         case 2:
/*  452 */           res = makeNode((nodes[root1]).var, 0, fire_((nodes[root1]).low, prePost, increment(prePost.size(), cur)));
/*      */           break;
/*      */         case 3:
/*  455 */           res = makeNode((nodes[root1]).var, 0, fire_((nodes[root1]).high, prePost, increment(prePost.size(), cur)));
/*      */           break;
/*      */       } 
/*  458 */     } else if ((nodes[root1]).var > id) {
/*      */       int v1;
/*  460 */       switch (val) {
/*      */         
/*      */         case 1:
/*  463 */           return 0;
/*      */         case 2:
/*  465 */           v1 = fire_(root1, prePost, increment(prePost.size(), cur));
/*      */           
/*  467 */           res = makeNode(id, 0, v1);
/*      */           break;
/*      */         case 3:
/*  470 */           return 0;
/*      */       } 
/*      */ 
/*      */     
/*      */     } else {
/*  475 */       int v0 = fire_((nodes[root1]).low, prePost, cur);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  483 */       int v1 = fire_((nodes[root1]).high, prePost, cur);
/*      */       
/*  485 */       res = makeNode((nodes[root1]).var, v0, v1);
/*      */     } 
/*      */     
/*  488 */     resultFireTable.put(fk, Integer.valueOf(res));
/*      */     
/*  490 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD fireUnio(BDD arg, Marking prePost) {
/*  505 */     if (resultFireTable.size() > 500)
/*  506 */       resultFireTable.clear(); 
/*  507 */     return new SharedBDDMS(fireUnio_(this.root, arg.root(), prePost, 0));
/*      */   }
/*      */   
/*      */   private int fireUnio_(int root1, int root2, Marking prePost, int cur) {
/*  511 */     FireUnioKey fk = new FireUnioKey(root1, root2, prePost, cur);
/*  512 */     int res = 0;
/*  513 */     int val = 0;
/*  514 */     int id = (nodes[1]).var;
/*  515 */     if (root1 == 0) return root2; 
/*  516 */     if (cur == prePost.size()) {
/*      */       
/*  518 */       if (root1 < 2 && root2 < 2) {
/*  519 */         return or.op(root1, root2);
/*      */       }
/*      */       
/*  522 */       if (root1 == root2 || root2 == 0) {
/*  523 */         return root1;
/*      */       }
/*  525 */       if (root1 > root2) {
/*  526 */         int r = root1;
/*  527 */         root1 = root2;
/*  528 */         root2 = r;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  533 */       return or_(root1, root2);
/*      */     } 
/*      */ 
/*      */     
/*  537 */     val = prePost.getToken(cur);
/*  538 */     id = UnsignedByte.unsign(prePost.getId(cur));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  544 */     Integer i = (Integer)resultFireTable.get(fk);
/*  545 */     if (i != null) return i.intValue();
/*      */ 
/*      */ 
/*      */     
/*  549 */     if ((nodes[root1]).var < id) {
/*      */       
/*  551 */       if ((nodes[root1]).var == (nodes[root2]).var) {
/*      */         
/*  553 */         res = makeNode((nodes[root1]).var, fireUnio_((nodes[root1]).low, (nodes[root2]).low, prePost, cur), fireUnio_((nodes[root1]).high, (nodes[root2]).high, prePost, cur));
/*  554 */       } else if ((nodes[root1]).var < (nodes[root2]).var) {
/*      */         
/*  556 */         res = makeNode((nodes[root1]).var, fireUnio_((nodes[root1]).low, root2, prePost, cur), fireUnio_((nodes[root1]).high, 0, prePost, cur));
/*      */       } else {
/*      */         
/*  559 */         res = makeNode((nodes[root2]).var, fireUnio_(root1, (nodes[root2]).low, prePost, cur), (nodes[root2]).high);
/*      */       }
/*      */     
/*  562 */     } else if ((nodes[root1]).var == id) {
/*      */       
/*  564 */       if ((nodes[root1]).var == (nodes[root2]).var) {
/*  565 */         switch (val) {
/*      */           case 1:
/*  567 */             res = makeNode(id, fireUnio_((nodes[root1]).high, (nodes[root2]).low, prePost, increment(prePost.size(), cur)), (nodes[root2]).high);
/*      */             break;
/*      */           case 2:
/*  570 */             res = makeNode(id, (nodes[root2]).low, fireUnio_((nodes[root1]).low, (nodes[root2]).high, prePost, increment(prePost.size(), cur)));
/*      */             break;
/*      */           case 3:
/*  573 */             res = makeNode(id, (nodes[root2]).low, fireUnio_((nodes[root1]).high, (nodes[root2]).high, prePost, increment(prePost.size(), cur)));
/*      */             break;
/*      */         } 
/*  576 */       } else if ((nodes[root1]).var < (nodes[root2]).var) {
/*  577 */         switch (val) {
/*      */           case 1:
/*  579 */             res = fireUnio_((nodes[root1]).high, root2, prePost, increment(prePost.size(), cur));
/*      */             break;
/*      */           case 2:
/*  582 */             res = makeNode(id, root2, fireUnio_((nodes[root1]).low, 0, prePost, increment(prePost.size(), cur)));
/*      */             break;
/*      */           case 3:
/*  585 */             res = makeNode(id, root2, fireUnio_((nodes[root1]).high, 0, prePost, increment(prePost.size(), cur)));
/*      */             break;
/*      */         } 
/*      */       } else {
/*  589 */         res = makeNode((nodes[root2]).var, fireUnio_(root1, (nodes[root2]).low, prePost, cur), (nodes[root2]).high);
/*      */       }
/*      */     
/*      */     }
/*  593 */     else if (id < (nodes[root2]).var) {
/*  594 */       switch (val) {
/*      */         case 1:
/*  596 */           return root2;
/*      */         case 2:
/*  598 */           res = makeNode(id, root2, fireUnio_(root1, 0, prePost, increment(prePost.size(), cur)));
/*      */           break;
/*      */         
/*      */         case 3:
/*  602 */           return root2;
/*      */       } 
/*  604 */     } else if (id == (nodes[root2]).var) {
/*  605 */       switch (val) { case 1:
/*  606 */           return root2;
/*      */         case 2:
/*  608 */           res = makeNode(id, (nodes[root2]).low, fireUnio_(root1, (nodes[root2]).high, prePost, increment(prePost.size(), cur)));
/*      */           break;
/*      */         
/*      */         case 3:
/*  612 */           return root2; }
/*      */     
/*      */     } else {
/*  615 */       res = makeNode((nodes[root2]).var, fireUnio_(root1, (nodes[root2]).low, prePost, cur), (nodes[root2]).high);
/*      */     } 
/*      */     
/*  618 */     resultFireTable.put(fk, Integer.valueOf(res));
/*  619 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  626 */   private static HashMap resultTable = new HashMap<>(2000);
/*  627 */   private static HashMap resultFireTable = new HashMap<>(500);
/*  628 */   private static HashMap resultPathTable = new HashMap<>(500);
/*      */   private HashMap resultCount;
/*      */   
/*      */   class OpKey { int hc;
/*      */     int r1;
/*      */     int r2;
/*      */     Operation op;
/*      */     
/*      */     OpKey(Operation op, int r1, int r2) {
/*  637 */       this.op = op;
/*  638 */       this.r1 = r1;
/*  639 */       this.r2 = r2;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  644 */       int h = this.hc;
/*  645 */       if (h == 0) {
/*  646 */         this.hc = 31 * this.op.hashCode();
/*  647 */         this.hc = 31 * this.hc + SharedBDDMS.nodes[this.r1].hashCode();
/*  648 */         this.hc = 32 * this.hc + SharedBDDMS.nodes[this.r2].hashCode();
/*  649 */         h = this.hc;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  656 */       return h;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/*  660 */       if (obj instanceof OpKey) {
/*  661 */         OpKey ok = (OpKey)obj;
/*  662 */         return (this.op.equals(ok.op) && this.r1 == ok.r1 && this.r2 == ok.r2);
/*      */       } 
/*  664 */       return false;
/*      */     } }
/*      */   
/*      */   class FireKey {
/*      */     int hc;
/*      */     Object prePost;
/*      */     int root;
/*      */     int cur;
/*      */     
/*      */     FireKey(int root, Object prePost, int cur) {
/*  674 */       this.root = root;
/*  675 */       this.cur = cur;
/*  676 */       this.prePost = prePost;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  681 */       int h = this.hc;
/*  682 */       if (h == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  687 */         this.hc = this.prePost.hashCode();
/*  688 */         this.hc = 31 * this.hc + this.root;
/*  689 */         this.hc = 31 * this.hc * (this.cur + 1);
/*      */         
/*  691 */         h = this.hc;
/*      */       } 
/*  693 */       return h;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/*  697 */       if (obj instanceof FireKey) {
/*  698 */         FireKey ok = (FireKey)obj;
/*  699 */         return (this.root == this.root && this.cur == this.cur && this.prePost.equals(this.prePost));
/*      */       } 
/*  701 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */   class FireUnioKey { int hc;
/*      */     Object prePost;
/*      */     int root1;
/*      */     int cur;
/*      */     int root2;
/*      */     
/*      */     FireUnioKey(int root1, int root2, Object prePost, int cur) {
/*  712 */       this.root1 = root1;
/*  713 */       this.cur = cur;
/*  714 */       this.root2 = root2;
/*  715 */       this.prePost = prePost;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  720 */       int h = this.hc;
/*  721 */       if (h == 0) {
/*  722 */         String s = "" + this.root1 + this.root2 + this.cur + this.prePost;
/*  723 */         this.hc = s.hashCode();
/*  724 */         h = this.hc;
/*      */       } 
/*  726 */       return h;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/*  730 */       if (obj instanceof SharedBDDMS.FireKey) {
/*  731 */         SharedBDDMS.FireKey ok = (SharedBDDMS.FireKey)obj;
/*  732 */         return (this.root1 == this.root1 && this.root2 == this.root2 && this.cur == this.cur && this.prePost.equals(this.prePost));
/*      */       } 
/*  734 */       return false;
/*      */     } }
/*      */   
/*      */   class PathKey {
/*      */     int hc;
/*      */     int root;
/*      */     int cur;
/*      */     Object path;
/*      */     boolean isPath;
/*      */     Operation op;
/*      */     
/*      */     PathKey(int r, Object path, int cur, boolean isPath) {
/*  746 */       this.root = r;
/*  747 */       this.cur = cur;
/*  748 */       this.path = path;
/*  749 */       this.isPath = isPath;
/*      */     }
/*      */ 
/*      */     
/*      */     PathKey(int r, int[] path, int cur) {
/*  754 */       this.root = r;
/*  755 */       this.cur = cur;
/*  756 */       this.path = path;
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*  760 */       int h = this.hc;
/*  761 */       if (h == 0) {
/*  762 */         String s = "" + this.root + this.cur;
/*  763 */         this.hc = this.path.hashCode() * s.hashCode();
/*  764 */         h = this.hc;
/*      */       } 
/*  766 */       return h;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/*  770 */       if (obj instanceof PathKey) {
/*  771 */         PathKey ok = (PathKey)obj;
/*  772 */         return (this.path.equals(ok.path) && this.root == ok.root && this.cur == ok.cur && this.isPath == ok.isPath);
/*      */       } 
/*  774 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int change__(int var) {
/*  781 */     resultTable.clear();
/*  782 */     pool.clear();
/*  783 */     return change_(this.root, var);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD change(int var) {
/*  789 */     resultTable.clear();
/*  790 */     pool.clear();
/*  791 */     return new SharedBDDMS(change_(this.root, var));
/*      */   }
/*      */   
/*      */   private int change_(int root1, int var) {
/*      */     int res;
/*  796 */     OpKey opKey = new OpKey(change, root1, var);
/*  797 */     Integer i = (Integer)resultTable.get(opKey);
/*  798 */     if (i != null) {
/*  799 */       return i.intValue();
/*      */     }
/*  801 */     if ((nodes[root1]).var == var) {
/*      */       
/*  803 */       res = makeNode((nodes[root1]).var, (nodes[root1]).high, (nodes[root1]).low);
/*  804 */     } else if ((nodes[root1]).var > var) {
/*  805 */       res = makeNode(var, 0, root1);
/*      */     } else {
/*  807 */       res = makeNode((nodes[root1]).var, change_((nodes[root1]).low, var), change_((nodes[root1]).high, var));
/*      */     } 
/*      */     
/*  810 */     resultTable.put(opKey, new Integer(res));
/*  811 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD subset0(int var) {
/*  817 */     resultTable.clear();
/*  818 */     pool.clear();
/*  819 */     return new SharedBDDMS(subset0_(this.root, var));
/*      */   }
/*      */ 
/*      */   
/*      */   private int subset0_(int root1, int var) {
/*  824 */     OpKey opKey = new OpKey(subset0, root1, var);
/*  825 */     Integer i = (Integer)resultTable.get(opKey);
/*  826 */     if (i != null) {
/*  827 */       return i.intValue();
/*      */     }
/*  829 */     if ((nodes[root1]).var == var)
/*      */     {
/*  831 */       return (nodes[root1]).low; } 
/*  832 */     if ((nodes[root1]).var > var) {
/*  833 */       return root1;
/*      */     }
/*  835 */     int res = makeNode((nodes[root1]).var, subset0_((nodes[root1]).low, var), subset0_((nodes[root1]).high, var));
/*      */ 
/*      */     
/*  838 */     resultTable.put(opKey, new Integer(res));
/*  839 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD subset1(int var) {
/*  845 */     resultTable.clear();
/*  846 */     pool.clear();
/*  847 */     return new SharedBDDMS(subset1_(this.root, var));
/*      */   }
/*      */   
/*      */   private int subset1_(int root1, int var) {
/*      */     int res;
/*  852 */     OpKey opKey = new OpKey(subset1, root1, var);
/*  853 */     Integer i = (Integer)resultTable.get(opKey);
/*  854 */     if (i != null) {
/*  855 */       return i.intValue();
/*      */     }
/*      */     
/*  858 */     if ((nodes[root1]).var == var) {
/*      */       
/*  860 */       res = makeNode((nodes[root1]).var, 0, (nodes[root1]).high);
/*      */     } else {
/*  862 */       if ((nodes[root1]).var > var) {
/*  863 */         return 0;
/*      */       }
/*  865 */       res = makeNode((nodes[root1]).var, subset1_((nodes[root1]).low, var), subset1_((nodes[root1]).high, var));
/*      */     } 
/*      */     
/*  868 */     resultTable.put(opKey, new Integer(res));
/*  869 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int or__(BDD arg) {
/*  878 */     resultTable.clear();
/*  879 */     pool.clear();
/*  880 */     return or_(this.root, arg.root());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD or(BDD arg) {
/*  886 */     pool.clear();
/*  887 */     return new SharedBDDMS(or_(this.root, arg.root()));
/*      */   }
/*      */   private int or_(int root1, int root2) {
/*      */     int res;
/*  891 */     if (root1 == 0)
/*      */     {
/*  893 */       return root2;
/*      */     }
/*      */     
/*  896 */     if (root2 == 0)
/*      */     {
/*  898 */       return root1;
/*      */     }
/*  900 */     if (root1 == root2) return root1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  906 */     if (root1 < 2 && root2 < 2)
/*      */     {
/*  908 */       return or.op(root1, root2);
/*      */     }
/*  910 */     OpKey opKey = new OpKey(or, root1, root2);
/*  911 */     Integer i = (Integer)resultTable.get(opKey);
/*  912 */     if (i != null) {
/*  913 */       return i.intValue();
/*      */     }
/*      */     
/*  916 */     if ((nodes[root1]).var == (nodes[root2]).var) {
/*  917 */       int v0 = or_((nodes[root1]).low, (nodes[root2]).low);
/*  918 */       int v1 = or_((nodes[root1]).high, (nodes[root2]).high);
/*  919 */       res = makeNode((nodes[root1]).var, v0, v1);
/*      */     }
/*  921 */     else if ((nodes[root1]).var > (nodes[root2]).var) {
/*  922 */       res = makeNode((nodes[root2]).var, or_((nodes[root2]).low, root1), (nodes[root2]).high);
/*      */     } else {
/*      */       
/*  925 */       res = makeNode((nodes[root1]).var, or_((nodes[root1]).low, root2), (nodes[root1]).high);
/*      */     } 
/*      */     
/*  928 */     resultTable.put(opKey, new Integer(res));
/*  929 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD and(BDD arg) {
/*  937 */     resultTable.clear();
/*  938 */     pool.clear();
/*  939 */     return new SharedBDDMS(and_(this.root, arg.root()));
/*      */   }
/*      */ 
/*      */   
/*      */   public int and__(BDD arg) {
/*  944 */     resultTable.clear();
/*  945 */     pool.clear();
/*  946 */     return and_(this.root, arg.root());
/*      */   }
/*      */   private int and_(int root1, int root2) {
/*      */     int res;
/*  950 */     if (root1 == 0)
/*  951 */       return 0; 
/*  952 */     if (root2 == 0) {
/*  953 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  960 */     if (root1 < 2 && root2 < 2)
/*      */     {
/*  962 */       return and.op(root1, root2);
/*      */     }
/*  964 */     OpKey opKey = new OpKey(and, root1, root2);
/*  965 */     Integer i = (Integer)resultTable.get(opKey);
/*  966 */     if (i != null) {
/*  967 */       return i.intValue();
/*      */     }
/*      */     
/*  970 */     if ((nodes[root1]).var == (nodes[root2]).var) {
/*      */       
/*  972 */       int v0 = and_((nodes[root1]).low, (nodes[root2]).low);
/*  973 */       int v1 = and_((nodes[root1]).high, (nodes[root2]).high);
/*  974 */       res = makeNode((nodes[root1]).var, v0, v1);
/*  975 */     } else if ((nodes[root1]).var > (nodes[root2]).var) {
/*      */       
/*  977 */       res = and_((nodes[root2]).low, root1);
/*      */     } else {
/*      */       
/*  980 */       res = and_((nodes[root1]).low, root2);
/*      */     } 
/*  982 */     resultTable.put(opKey, new Integer(res));
/*      */     
/*  984 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD andNot(BDD arg) {
/*  991 */     resultTable.clear();
/*  992 */     pool.clear();
/*  993 */     return new SharedBDDMS(andNot_(this.root, arg.root()));
/*      */   }
/*      */ 
/*      */   
/*      */   public int andNot__(BDD arg) {
/*  998 */     resultTable.clear();
/*  999 */     pool.clear();
/* 1000 */     return andNot_(this.root, arg.root());
/*      */   }
/*      */   private int andNot_(int root1, int root2) {
/*      */     int res;
/* 1004 */     if (root1 == 0)
/* 1005 */       return 0; 
/* 1006 */     if (root2 == 0) {
/* 1007 */       return root1;
/*      */     }
/* 1009 */     if (root1 == root2) {
/* 1010 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1015 */     if (root1 < 2 && root2 < 2)
/*      */     {
/* 1017 */       return andNot.op(root1, root2);
/*      */     }
/* 1019 */     OpKey opKey = new OpKey(andNot, root1, root2);
/* 1020 */     Integer i = (Integer)resultTable.get(opKey);
/* 1021 */     if (i != null) {
/* 1022 */       return i.intValue();
/*      */     }
/*      */     
/* 1025 */     if ((nodes[root1]).var == (nodes[root2]).var) {
/*      */       
/* 1027 */       int v0 = andNot_((nodes[root1]).low, (nodes[root2]).low);
/* 1028 */       int v1 = andNot_((nodes[root1]).high, (nodes[root2]).high);
/* 1029 */       res = makeNode((nodes[root1]).var, v0, v1);
/* 1030 */     } else if ((nodes[root1]).var > (nodes[root2]).var) {
/*      */ 
/*      */       
/* 1033 */       res = andNot_(root1, (nodes[root2]).low);
/*      */     } else {
/*      */       
/* 1036 */       res = makeNode((nodes[root1]).var, andNot_((nodes[root1]).low, root2), (nodes[root1]).high);
/*      */     } 
/*      */     
/* 1039 */     resultTable.put(opKey, new Integer(res));
/*      */     
/* 1041 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int makeNode(int var, int low, int high) {
/* 1055 */     if (freeNodes() < nodes.length / 15) {
/* 1056 */       gc();
/*      */     }
/*      */     
/*      */     try {
/* 1060 */       if (high == 0) return low; 
/* 1061 */       if (low >= 0 && low == high) {
/* 1062 */         return low;
/*      */       }
/* 1064 */       if (low < 0) {
/* 1065 */         BddNode node = new BddNode(var, low, high);
/* 1066 */         nodes[size] = node;
/* 1067 */         size++;
/* 1068 */         pool.add(new Integer(size));
/* 1069 */         return size - 1;
/*      */       } 
/*      */ 
/*      */       
/* 1073 */       dummy.init(var, low, high);
/* 1074 */       Integer index = (Integer)uniqueTable.get(dummy);
/* 1075 */       if (index == null) {
/*      */         
/* 1077 */         if (!freeNodeIndices.isEmpty()) {
/* 1078 */           Integer integer = freeNodeIndices.iterator().next();
/* 1079 */           freeNodeIndices.remove(integer);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1084 */           nodes[integer.intValue()].init(var, low, high);
/* 1085 */           uniqueTable.put(nodes[integer.intValue()], integer);
/* 1086 */           pool.add(new Integer(integer.intValue()));
/* 1087 */           return integer.intValue();
/*      */         } 
/* 1089 */         BddNode node = new BddNode(var, low, high);
/* 1090 */         nodes[size] = node;
/* 1091 */         size++;
/* 1092 */         uniqueTable.put(node, new Integer(size - 1));
/* 1093 */         pool.add(new Integer(size - 1));
/* 1094 */         return size - 1;
/*      */       } 
/* 1096 */       int i = index.intValue();
/* 1097 */       (nodes[i]).marked = false;
/* 1098 */       pool.add(new Integer(i));
/* 1099 */       return i;
/*      */     }
/* 1101 */     catch (Exception e) {
/*      */ 
/*      */       
/* 1104 */       System.out.println("exit");
/* 1105 */       System.exit(1);
/*      */ 
/*      */ 
/*      */       
/* 1109 */       return -1;
/*      */     } 
/*      */   }
/*      */   public int root() {
/* 1113 */     return this.root;
/*      */   }
/*      */   
/* 1116 */   public SharedBDDMS(SharedBDDMS b) { this.resultCount = new HashMap<>(); assign(b); } public SharedBDDMS(int root) { this.resultCount = new HashMap<>(); instances++; assign(root); } public SharedBDDMS(BitSet bs) { this.resultCount = new HashMap<>(); instances++; this.root = 1; for (int i = (nodes[1]).var - 1; i >= 0; i--) { if (bs.member(i)) this.root = makeNode(i, 0, this.root);  }  insert(this); this.instantiated = true; } public SharedBDDMS(ExtendedIncMatrix sm, int row) { this.resultCount = new HashMap<>(); try { instances++; this.root = 1; int j = 1; int elements = sm.elementsInRow(row); for (int i = 0; i < elements && sm.getIthColumnIndexInRow(row, elements - j) >= sm.realCols; i++) { this.root = makeNode(sm.getIthColumnIndexInRow(row, elements - j) - sm.realCols, 0, this.root); j++; }  insert(this); } catch (Exception e) { e.printStackTrace(); System.exit(1); }  this.instantiated = true; } public SharedBDDMS(int var, boolean neg) { this.resultCount = new HashMap<>(); instances++; if (neg) {
/*      */       setRoot(makeNode(var, 0, 1));
/*      */     } else {
/*      */       setRoot(makeNode(var, 1, 0));
/* 1120 */     }  } public long paths() { this.resultCount = new HashMap<>();
/* 1121 */     return countPaths_(this.root); }
/*      */ 
/*      */   
/*      */   private long countPaths_(int root) {
/* 1125 */     if (root == 1) return 1L; 
/* 1126 */     if (root == 0) return 0L; 
/* 1127 */     Long i = (Long)this.resultCount.get(nodes[root]);
/* 1128 */     if (i != null) return i.longValue(); 
/* 1129 */     long c1 = countPaths_((nodes[root]).low);
/* 1130 */     long c2 = countPaths_((nodes[root]).high);
/* 1131 */     this.resultCount.put(nodes[root], new Long(c1 + c2));
/* 1132 */     return c1 + c2;
/*      */   }
/*      */   
/*      */   public long nodes() {
/* 1136 */     this.resultCount = new HashMap<>();
/* 1137 */     long n = countNodes_(this.root);
/*      */     
/* 1139 */     return n;
/*      */   }
/*      */ 
/*      */   
/*      */   private long countNodes_(int root) {
/* 1144 */     if (root == 1 || root == 0) return 0L;
/*      */ 
/*      */     
/* 1147 */     Long i = (Long)this.resultCount.get(nodes[root]);
/* 1148 */     if (i != null) return 0L;
/*      */     
/* 1150 */     long res = countNodes_((nodes[root]).high) + countNodes_((nodes[root]).low) + 1L;
/* 1151 */     this.resultCount.put(nodes[root], new Long(res));
/* 1152 */     return res;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEqual(BDD obj) {
/* 1157 */     if (!(obj instanceof SharedBDDMS)) return false; 
/* 1158 */     return (this.root == ((SharedBDDMS)obj).root);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void init(int nodeSize, int variables) {
/* 1170 */     nodes = new BddNode[nodeSize];
/* 1171 */     size = 0;
/* 1172 */     uniqueTable.clear();
/* 1173 */     Zero = new SharedBDDMS(makeNode(variables, -1, -1));
/* 1174 */     One = new SharedBDDMS(makeNode(variables, -1, -1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD complement() {
/* 1181 */     return new SharedBDDMS(complement_(this.root));
/*      */   }
/*      */   
/*      */   public int complement_(int root) {
/* 1185 */     if (root == 1) return 0; 
/* 1186 */     if (root == 0) return 1; 
/* 1187 */     return makeNode((nodes[root]).var, complement_((nodes[root]).low), complement_((nodes[root]).high));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BDD copy() {
/* 1194 */     return new SharedBDDMS(this.root);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unmark() {
/* 1202 */     unmark_(this.root);
/*      */   }
/*      */   
/*      */   public static void unmark_(int root) {
/* 1206 */     if (root < 2) {
/* 1207 */       (nodes[root]).marked = false;
/*      */       return;
/*      */     } 
/* 1210 */     if (nodes[root] == null) {
/* 1211 */       System.out.println("error " + root);
/*      */     }
/* 1213 */     if (!(nodes[root]).marked) {
/*      */       return;
/*      */     }
/*      */     
/* 1217 */     unmark_((nodes[root]).low);
/* 1218 */     unmark_((nodes[root]).high);
/* 1219 */     (nodes[root]).marked = false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void mark() {
/* 1224 */     mark_(this.root);
/*      */   }
/*      */   public static void mark_(int root) {
/* 1227 */     if (root < 2) {
/* 1228 */       (nodes[root]).marked = true; return;
/*      */     } 
/* 1230 */     if ((nodes[root]).marked) {
/*      */       return;
/*      */     }
/* 1233 */     (nodes[root]).marked = true;
/* 1234 */     mark_((nodes[root]).low);
/* 1235 */     mark_((nodes[root]).high);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void finalize() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void gc() {
/* 1255 */     System.out.println("size: " + size);
/* 1256 */     System.out.print("gc: " + freeNodes());
/*      */     
/* 1258 */     for (Iterator<Integer> it = instancedBdds.keySet().iterator(); it.hasNext(); ) {
/* 1259 */       Integer b = it.next();
/* 1260 */       mark_(b.intValue());
/*      */     } 
/*      */     
/* 1263 */     freeNodeIndices.clear();
/* 1264 */     int c = 0;
/* 1265 */     for (int i = 2; i < size; i++) {
/*      */       
/* 1267 */       if (!pool.contains(new Integer(i)) && !(nodes[i]).marked) {
/* 1268 */         c++;
/* 1269 */         freeNodeIndices.add(new Integer(i));
/*      */       } 
/*      */     } 
/*      */     
/* 1273 */     System.out.println("not marked: " + c);
/* 1274 */     HashSet<Object> del = new HashSet();
/*      */     Iterator<Integer> iterator1;
/* 1276 */     for (iterator1 = uniqueTable.keySet().iterator(); iterator1.hasNext(); ) {
/* 1277 */       Object o = iterator1.next();
/* 1278 */       Integer integer = (Integer)uniqueTable.get(o);
/* 1279 */       if (!pool.contains(new Integer(integer.intValue())) && !(nodes[integer.intValue()]).marked) {
/* 1280 */         del.add(o);
/*      */       }
/*      */     } 
/* 1283 */     for (iterator1 = del.iterator(); iterator1.hasNext(); uniqueTable.remove(iterator1.next()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1289 */     for (iterator1 = instancedBdds.keySet().iterator(); iterator1.hasNext(); ) {
/* 1290 */       Integer b = iterator1.next();
/* 1291 */       unmark_(b.intValue());
/*      */     } 
/*      */     
/* 1294 */     clearAllTables();
/* 1295 */     System.out.println("->" + freeNodes());
/*      */   }
/*      */ 
/*      */   
/*      */   protected static void clearAllTables() {
/* 1300 */     resultTable.clear();
/* 1301 */     resultFireTable.clear();
/* 1302 */     resultPathTable.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void free() {
/*      */     try {
/* 1309 */       this.instantiated = false;
/*      */ 
/*      */       
/* 1312 */       instances--;
/*      */       
/* 1314 */       if (this.root < 2) {
/*      */         return;
/*      */       }
/* 1317 */       Object key = new Integer(this.root);
/* 1318 */       Int occ = (Int)instancedBdds.get(key);
/* 1319 */       instancedBdds.remove(key);
/* 1320 */       if (occ.value > 1) {
/* 1321 */         occ.value--;
/* 1322 */         instancedBdds.put(key, occ);
/*      */       }
/*      */     
/* 1325 */     } catch (Exception e) {
/* 1326 */       System.out.println("---");
/* 1327 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void main(String[] args) {}
/*      */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/bdd/SharedBDDMS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */