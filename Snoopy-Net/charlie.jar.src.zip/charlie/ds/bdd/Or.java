/*   */ package charlie.ds.bdd;
/*   */ 
/*   */ public class Or
/*   */   implements Operation
/*   */ {
/*   */   public int op(int op1, int op2) {
/* 7 */     if (op1 == 1) return 1;
/*   */     
/* 9 */     return op2;
/*   */   }
/*   */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/bdd/Or.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */