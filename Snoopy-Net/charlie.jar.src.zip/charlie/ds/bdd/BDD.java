package charlie.ds.bdd;

public interface BDD {
  public static final int ZERO = 0;
  
  public static final int ONE = 1;
  
  int root();
  
  BDD and(BDD paramBDD);
  
  void free();
  
  BDD or(BDD paramBDD);
  
  boolean containsSubPathOf(int[] paramArrayOfint);
  
  long nodes();
  
  BDD notContainsSubPath(int[] paramArrayOfint);
  
  boolean isEqual(BDD paramBDD);
  
  long paths();
  
  BDD change(int paramInt);
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/bdd/BDD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */