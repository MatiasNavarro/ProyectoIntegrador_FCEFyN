/*   */ package charlie.ds.bdd;
/*   */ 
/*   */ public class Int
/*   */ {
/*   */   protected int value;
/*   */   
/*   */   public Int(int val) {
/* 8 */     this.value = val;
/*   */   }
/*   */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/bdd/Int.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */