/*      */ package charlie.ds.bdd;
/*      */ 
/*      */ import charlie.ds.BitSet;
/*      */ import charlie.ds.sm.ExtendedIncMatrix;
/*      */ import charlie.pn.Marking;
/*      */ import charlie.pn.UnsignedByte;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ 
/*      */ public class SharedBDD implements BDD {
/*   12 */   public static Operation and = new And();
/*   13 */   public static Operation or = new Or();
/*   14 */   public static Operation change = new Operation() {
/*      */       public int op(int r1, int r2) {
/*   16 */         return -1;
/*      */       }
/*      */     };
/*      */   
/*   20 */   long timeOrg = 0L;
/*      */   
/*   22 */   private static HashMap freeRoots = new HashMap<>();
/*      */ 
/*      */   
/*      */   public void setRoot(int root) {}
/*      */   
/*   27 */   public static int instances = 0;
/*   28 */   protected static BddNode[] nodes = new BddNode[1000];
/*   29 */   private static int size = 0;
/*   30 */   private static HashSet freeNodeIndices = new HashSet();
/*   31 */   private static HashMap uniqueTable = new HashMap<>();
/*   32 */   public static SharedBDD Zero = new SharedBDD(makeNode(100, -1, -1));
/*   33 */   public static SharedBDD One = new SharedBDD(makeNode(100, -1, -1));
/*      */   
/*      */   private int root;
/*      */   
/*      */   public String toString_(int root) {
/*   38 */     String res = "";
/*   39 */     if (root < 2) return res + "(" + root + ")"; 
/*   40 */     Integer i = new Integer(root);
/*   41 */     if (this.resultCount.get(i) != null) return "[ r: " + root + " v: " + (nodes[root]).var + "]"; 
/*   42 */     this.resultCount.put(i, i);
/*   43 */     return "(" + toString_((nodes[root]).low) + ") r: " + root + " v: " + (nodes[root]).var + "(" + toString_((nodes[root]).high) + ")";
/*      */   }
/*      */   
/*      */   public String toString() {
/*   47 */     this.resultCount.clear();
/*   48 */     return toString_(this.root);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void paths_(int root1, String str) {
/*   56 */     String res = new String(str);
/*   57 */     if (root1 == 1) { System.out.println(str);
/*      */       
/*      */       return; }
/*      */     
/*   61 */     if ((nodes[root1]).var < 0) {
/*   62 */       System.out.println("!!!!!!!!!!!!");
/*      */     }
/*      */     
/*   65 */     if (root1 == 0)
/*   66 */       return;  paths_((nodes[root1]).low, str + "");
/*   67 */     paths_((nodes[root1]).high, str + " " + (nodes[root1]).var);
/*      */   }
/*      */   
/*      */   public void printPaths() {
/*   71 */     paths_(this.root, "");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static int freeNodes() {
/*   77 */     return freeNodeIndices.size() + nodes.length - size;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void printNodesInfo() {
/*   82 */     for (int i = 0; i < nodes.length; i++) {
/*   83 */       if (!freeNodeIndices.contains(new Integer(i)) && nodes[i] != null)
/*   84 */         System.out.println(i + " -- " + nodes[i]); 
/*      */     } 
/*   86 */     System.out.println("instances " + instances);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD notContainsSubPath(int[] subPath) {
/*  148 */     resultPathTable.clear();
/*  149 */     return new SharedBDD(notContainsSubPath_(this.root, subPath, 0, true));
/*      */   }
/*      */   public int notContainsSubPath_(int root, int[] path, int current, boolean isPath) {
/*      */     int res;
/*  153 */     PathKey pKey = new PathKey(root, path, current, isPath);
/*  154 */     Integer i = (Integer)resultPathTable.get(pKey);
/*  155 */     if (i != null && i != null)
/*      */     {
/*  157 */       return i.intValue();
/*      */     }
/*      */     
/*  160 */     if (root == 1 && current == path.length && !isPath) return 1; 
/*  161 */     if (root == 1 && current == path.length && isPath) return 0; 
/*  162 */     if (root == 1 && current < path.length) return 1; 
/*  163 */     if (root == 0) return 0;
/*      */ 
/*      */     
/*  166 */     if (current == path.length && isPath) return 0; 
/*  167 */     if (current == path.length && !isPath) { res = makeNode((nodes[root]).var, notContainsSubPath_((nodes[root]).low, path, current, isPath), notContainsSubPath_((nodes[root]).high, path, current, isPath)); }
/*  168 */     else if ((nodes[root]).var == path[current])
/*  169 */     { int v0 = notContainsSubPath_((nodes[root]).low, path, current + 1, false);
/*  170 */       int v1 = notContainsSubPath_((nodes[root]).high, path, current + 1, isPath);
/*  171 */       if (v1 == 0) {
/*  172 */         res = v0;
/*      */       } else {
/*  174 */         res = makeNode((nodes[root]).var, v0, v1);
/*      */       }
/*      */        }
/*  177 */     else if ((nodes[root]).var < path[current])
/*  178 */     { res = makeNode((nodes[root]).var, notContainsSubPath_((nodes[root]).low, path, current, isPath), notContainsSubPath_((nodes[root]).high, path, current, isPath)); }
/*      */     else
/*  180 */     { res = makeNode((nodes[root]).var, notContainsSubPath_(root, path, current + 1, false), notContainsSubPath_(root, path, current + 1, false)); }
/*  181 */      resultPathTable.put(pKey, new Integer(res));
/*  182 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD notContainsSubPath(ExtendedIncMatrix sm, int row, int cur) {
/*  192 */     resultPathTable.clear();
/*  193 */     return new SharedBDD(notContainsSubPath_(this.root, sm, row, cur, true));
/*      */   } public int notContainsSubPath_(int root, ExtendedIncMatrix sm, int row, int current, boolean isPath) {
/*      */     try {
/*      */       int res;
/*  197 */       PathKey pKey = new PathKey(root, sm, current, isPath);
/*  198 */       Integer i = (Integer)resultPathTable.get(pKey);
/*  199 */       if (i != null && i != null)
/*      */       {
/*  201 */         return i.intValue();
/*      */       }
/*      */       
/*  204 */       if (root == 1 && current == sm.elementsInRow(row) && !isPath) return 1; 
/*  205 */       if (root == 1 && current == sm.elementsInRow(row) && isPath) return 0; 
/*  206 */       if (root == 1 && current < sm.elementsInRow(row)) return 1; 
/*  207 */       if (root == 0) return 0;
/*      */ 
/*      */       
/*  210 */       if (current == sm.elementsInRow(row) && isPath) return 0; 
/*  211 */       if (current == sm.elementsInRow(row) && !isPath) { res = makeNode((nodes[root]).var, notContainsSubPath_((nodes[root]).low, sm, row, current, isPath), notContainsSubPath_((nodes[root]).high, sm, row, current, isPath)); }
/*  212 */       else if ((nodes[root]).var == sm.getIthColumnIndexInRow(row, current) - sm.realCols)
/*  213 */       { int v0 = notContainsSubPath_((nodes[root]).low, sm, row, current + 1, false);
/*  214 */         int v1 = notContainsSubPath_((nodes[root]).high, sm, row, current + 1, isPath);
/*  215 */         if (v1 == 0) {
/*  216 */           res = v0;
/*      */         } else {
/*  218 */           res = makeNode((nodes[root]).var, v0, v1);
/*      */         }
/*      */          }
/*  221 */       else if ((nodes[root]).var < sm.getIthColumnIndexInRow(row, current) - sm.realCols)
/*  222 */       { res = makeNode((nodes[root]).var, notContainsSubPath_((nodes[root]).low, sm, row, current, isPath), notContainsSubPath_((nodes[root]).high, sm, row, current, isPath)); }
/*      */       else
/*  224 */       { res = makeNode((nodes[root]).var, notContainsSubPath_(root, sm, row, current + 1, false), notContainsSubPath_(root, sm, row, current + 1, false)); }
/*  225 */        resultPathTable.put(pKey, new Integer(res));
/*  226 */       return res;
/*  227 */     } catch (Exception e) {
/*  228 */       System.out.println("Error in notContainsSubPath- should not be possible");
/*  229 */       System.exit(1);
/*      */       
/*  231 */       return -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsSubPathOf(int[] path) {
/*  242 */     return subPathOf_(this.root, path, 0);
/*      */   }
/*      */   
/*      */   public boolean subPathOf_(int root, int[] path, int current) {
/*  246 */     if (root == 1) return true; 
/*  247 */     if (root == 0) return false; 
/*  248 */     if (current == path.length) return subPathOf_((nodes[root]).low, path, current); 
/*  249 */     if ((nodes[root]).var == path[current]) return (subPathOf_((nodes[root]).low, path, current + 1) || subPathOf_((nodes[root]).high, path, current + 1)); 
/*  250 */     if ((nodes[root]).var > path[current]) return subPathOf_(root, path, current + 1); 
/*  251 */     return subPathOf_((nodes[root]).low, path, current);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsSubPathOf(ExtendedIncMatrix sm, int row, int current) {
/*  259 */     return subPathOf_(this.root, sm, row, current);
/*      */   }
/*      */   
/*      */   public boolean subPathOf_(int root, ExtendedIncMatrix sm, int row, int current) {
/*      */     try {
/*  264 */       if (root == 1) return true; 
/*  265 */       if (root == 0) return false; 
/*  266 */       if (current == sm.elementsInRow(row)) return subPathOf_((nodes[root]).low, sm, row, current); 
/*  267 */       if ((nodes[root]).var == sm.getIthColumnIndexInRow(row, current) - sm.realCols) return (subPathOf_((nodes[root]).low, sm, row, current + 1) || subPathOf_((nodes[root]).high, sm, row, current + 1)); 
/*  268 */       if ((nodes[root]).var > sm.getIthColumnIndexInRow(row, current) - sm.realCols) return subPathOf_(root, sm, row, current + 1); 
/*  269 */       return subPathOf_((nodes[root]).low, sm, row, current);
/*  270 */     } catch (Exception e) {
/*  271 */       System.out.println("Error in subPathOf- should not be possible");
/*  272 */       System.exit(1);
/*      */       
/*  274 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD containsSubPath(int[] subPath) {
/*  288 */     return new SharedBDD(containsSubPath_(this.root, subPath, 0));
/*      */   }
/*      */   public int containsSubPath_(int root, int[] path, int current) {
/*      */     int res;
/*  292 */     PathKey pKey = new PathKey(root, path, current);
/*  293 */     Integer i = (Integer)resultPathTable.get(pKey);
/*  294 */     if (i != null)
/*      */     {
/*  296 */       return i.intValue();
/*      */     }
/*  298 */     if (root == 1 && current == path.length) return 1; 
/*  299 */     if (root == 1 && current < path.length) return 0; 
/*  300 */     if (root == 0) return 0;
/*      */     
/*  302 */     if (current == path.length) { res = makeNode((nodes[root]).var, containsSubPath_((nodes[root]).low, path, current), containsSubPath_((nodes[root]).high, path, current)); }
/*  303 */     else if ((nodes[root]).var == path[current]) { res = makeNode((nodes[root]).var, 0, containsSubPath_((nodes[root]).high, path, current + 1)); }
/*  304 */     else if ((nodes[root]).var < path[current]) { res = makeNode((nodes[root]).var, containsSubPath_((nodes[root]).low, path, current), containsSubPath_((nodes[root]).high, path, current)); }
/*  305 */     else { return 0; }
/*  306 */      resultPathTable.put(pKey, new Integer(res));
/*  307 */     return res;
/*      */   }
/*      */ 
/*      */   
/*      */   private int increment(int max, int val) {
/*  312 */     if (val < max) return val + 1; 
/*  313 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD fire(Marking prePost) {
/*  325 */     resultFireTable.clear();
/*  326 */     return new SharedBDD(fire_(this.root, prePost, 0));
/*      */   }
/*  328 */   public static int fireCacheHits = 0;
/*  329 */   public static int fireCacheMisses = 0;
/*      */ 
/*      */   
/*      */   private int fire_(int root1, Marking prePost, int cur) {
/*  333 */     FireKey fk = new FireKey(root1, prePost, cur);
/*      */     
/*  335 */     if (cur == prePost.size() || root1 == 0) return root1; 
/*  336 */     int val = prePost.getToken(cur);
/*  337 */     Integer i = (Integer)resultFireTable.get(fk);
/*  338 */     if (i != null) {
/*  339 */       fireCacheHits++;
/*  340 */       return i.intValue();
/*      */     } 
/*  342 */     fireCacheMisses++;
/*      */     
/*  344 */     int id = UnsignedByte.unsign(prePost.getId(cur));
/*      */     
/*  346 */     int res = 0;
/*  347 */     if ((nodes[root1]).var == id) {
/*      */ 
/*      */       
/*  350 */       switch (val) {
/*      */         
/*      */         case 1:
/*  353 */           res = fire_((nodes[root1]).high, prePost, increment(prePost.size(), cur));
/*      */           break;
/*      */         case 2:
/*  356 */           res = makeNode((nodes[root1]).var, 0, fire_((nodes[root1]).low, prePost, increment(prePost.size(), cur)));
/*      */           break;
/*      */         case 3:
/*  359 */           res = makeNode((nodes[root1]).var, 0, fire_((nodes[root1]).high, prePost, increment(prePost.size(), cur)));
/*      */           break;
/*      */       } 
/*  362 */     } else if ((nodes[root1]).var > id) {
/*      */       int v1;
/*  364 */       switch (val) {
/*      */         
/*      */         case 1:
/*  367 */           return 0;
/*      */         case 2:
/*  369 */           v1 = fire_(root1, prePost, increment(prePost.size(), cur));
/*      */           
/*  371 */           res = makeNode(id, 0, v1);
/*      */           break;
/*      */         case 3:
/*  374 */           return 0;
/*      */       } 
/*      */ 
/*      */     
/*      */     } else {
/*  379 */       int v0 = fire_((nodes[root1]).low, prePost, cur);
/*  380 */       int v1 = fire_((nodes[root1]).high, prePost, cur);
/*  381 */       res = makeNode((nodes[root1]).var, v0, v1);
/*      */     } 
/*  383 */     resultFireTable.put(fk, Integer.valueOf(res));
/*  384 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD fireUnio(BDD arg, Marking prePost) {
/*  399 */     if (resultFireTable.size() > 500)
/*  400 */       resultFireTable.clear(); 
/*  401 */     return new SharedBDD(fireUnio_(this.root, arg.root(), prePost, 0));
/*      */   }
/*      */   
/*      */   private int fireUnio_(int root1, int root2, Marking prePost, int cur) {
/*  405 */     FireUnioKey fk = new FireUnioKey(root1, root2, prePost, cur);
/*  406 */     int res = 0;
/*  407 */     int val = 0;
/*  408 */     int id = (nodes[1]).var;
/*  409 */     if (root1 == 0) return root2; 
/*  410 */     if (cur == prePost.size()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  416 */       if (root1 == root2 || root2 == 0) {
/*  417 */         return root1;
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  431 */       val = prePost.getToken(cur);
/*  432 */       id = UnsignedByte.unsign(prePost.getId(cur));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  438 */     Integer i = (Integer)resultFireTable.get(fk);
/*  439 */     if (i != null) return i.intValue();
/*      */ 
/*      */ 
/*      */     
/*  443 */     if ((nodes[root1]).var < id) {
/*      */       
/*  445 */       if ((nodes[root1]).var == (nodes[root2]).var) {
/*      */         
/*  447 */         res = makeNode((nodes[root1]).var, fireUnio_((nodes[root1]).low, (nodes[root2]).low, prePost, cur), fireUnio_((nodes[root1]).high, (nodes[root2]).high, prePost, cur));
/*  448 */       } else if ((nodes[root1]).var < (nodes[root2]).var) {
/*      */         
/*  450 */         res = makeNode((nodes[root1]).var, fireUnio_((nodes[root1]).low, root2, prePost, cur), fireUnio_((nodes[root1]).high, 0, prePost, cur));
/*      */       } else {
/*      */         
/*  453 */         res = makeNode((nodes[root2]).var, fireUnio_(root1, (nodes[root2]).low, prePost, cur), (nodes[root2]).high);
/*      */       }
/*      */     
/*  456 */     } else if ((nodes[root1]).var == id) {
/*      */       
/*  458 */       if ((nodes[root1]).var == (nodes[root2]).var) {
/*  459 */         switch (val) {
/*      */           case 1:
/*  461 */             res = makeNode(id, fireUnio_((nodes[root1]).high, (nodes[root2]).low, prePost, increment(prePost.size(), cur)), (nodes[root2]).high);
/*      */             break;
/*      */           case 2:
/*  464 */             res = makeNode(id, (nodes[root2]).low, fireUnio_((nodes[root1]).low, (nodes[root2]).high, prePost, increment(prePost.size(), cur)));
/*      */             break;
/*      */           case 3:
/*  467 */             res = makeNode(id, (nodes[root2]).low, fireUnio_((nodes[root1]).high, (nodes[root2]).high, prePost, increment(prePost.size(), cur)));
/*      */             break;
/*      */         } 
/*  470 */       } else if ((nodes[root1]).var < (nodes[root2]).var) {
/*  471 */         switch (val) {
/*      */           case 1:
/*  473 */             res = fireUnio_((nodes[root1]).high, root2, prePost, increment(prePost.size(), cur));
/*      */             break;
/*      */           case 2:
/*  476 */             res = makeNode(id, root2, fireUnio_((nodes[root1]).low, 0, prePost, increment(prePost.size(), cur)));
/*      */             break;
/*      */           case 3:
/*  479 */             res = makeNode(id, root2, fireUnio_((nodes[root1]).high, 0, prePost, increment(prePost.size(), cur)));
/*      */             break;
/*      */         } 
/*      */       } else {
/*  483 */         res = makeNode((nodes[root2]).var, fireUnio_(root1, (nodes[root2]).low, prePost, cur), (nodes[root2]).high);
/*      */       }
/*      */     
/*      */     }
/*  487 */     else if (id < (nodes[root2]).var) {
/*  488 */       switch (val) {
/*      */         case 1:
/*  490 */           return root2;
/*      */         case 2:
/*  492 */           res = makeNode(id, root2, fireUnio_(root1, 0, prePost, increment(prePost.size(), cur)));
/*      */           break;
/*      */         
/*      */         case 3:
/*  496 */           return root2;
/*      */       } 
/*  498 */     } else if (id == (nodes[root2]).var) {
/*  499 */       switch (val) { case 1:
/*  500 */           return root2;
/*      */         case 2:
/*  502 */           res = makeNode(id, (nodes[root2]).low, fireUnio_(root1, (nodes[root2]).high, prePost, increment(prePost.size(), cur)));
/*      */           break;
/*      */         
/*      */         case 3:
/*  506 */           return root2; }
/*      */     
/*      */     } else {
/*  509 */       res = makeNode((nodes[root2]).var, fireUnio_(root1, (nodes[root2]).low, prePost, cur), (nodes[root2]).high);
/*      */     } 
/*      */     
/*  512 */     resultFireTable.put(fk, Integer.valueOf(res));
/*  513 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  520 */   private static HashMap resultTable = new HashMap<>();
/*  521 */   private static HashMap resultFireTable = new HashMap<>();
/*  522 */   private static HashMap resultPathTable = new HashMap<>();
/*      */   private HashMap resultCount;
/*      */   
/*      */   class OpKey { int hc;
/*      */     int r1;
/*      */     int r2;
/*      */     Operation op;
/*      */     
/*      */     OpKey(Operation op, int r1, int r2) {
/*  531 */       this.op = op;
/*  532 */       this.r1 = r1;
/*  533 */       this.r2 = r2;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  538 */       int h = this.hc;
/*  539 */       if (h == 0) {
/*  540 */         String s = "" + this.r1 + this.r2;
/*  541 */         this.hc = this.op.hashCode() * s.hashCode();
/*  542 */         h = this.hc;
/*      */       } 
/*  544 */       return h;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/*  548 */       if (obj instanceof OpKey) {
/*  549 */         OpKey ok = (OpKey)obj;
/*  550 */         return (this.op.equals(ok.op) && this.r1 == ok.r1 && this.r2 == ok.r2);
/*      */       } 
/*  552 */       return false;
/*      */     } }
/*      */   
/*      */   class FireKey {
/*      */     int hc;
/*      */     Object prePost;
/*      */     int root;
/*      */     int cur;
/*      */     
/*      */     FireKey(int root, Object prePost, int cur) {
/*  562 */       this.root = root;
/*  563 */       this.cur = cur;
/*  564 */       this.prePost = prePost;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  569 */       int h = this.hc;
/*  570 */       if (h == 0) {
/*  571 */         String s = "" + this.root + this.cur + this.prePost;
/*  572 */         this.hc = s.hashCode();
/*  573 */         h = this.hc;
/*      */       } 
/*  575 */       return h;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/*  579 */       if (this == obj) {
/*  580 */         return true;
/*      */       }
/*      */       
/*  583 */       if (obj == null) {
/*  584 */         return false;
/*      */       }
/*      */       
/*  587 */       if (obj.getClass() == getClass()) {
/*  588 */         FireKey ok = (FireKey)obj;
/*  589 */         return (this.root == ok.root && this.cur == ok.cur && ok.prePost.equals(this.prePost));
/*      */       } 
/*      */       
/*  592 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */   class FireUnioKey {
/*      */     int hc;
/*      */     Object prePost;
/*      */     int root1;
/*      */     int cur;
/*      */     int root2;
/*      */     
/*      */     FireUnioKey(int root1, int root2, Object prePost, int cur) {
/*  604 */       this.root1 = root1;
/*  605 */       this.cur = cur;
/*  606 */       this.root2 = root2;
/*  607 */       this.prePost = prePost;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  612 */       int h = this.hc;
/*  613 */       if (h == 0) {
/*  614 */         String s = "" + this.root1 + this.root2 + this.cur + this.prePost;
/*  615 */         this.hc = s.hashCode();
/*  616 */         h = this.hc;
/*      */       } 
/*  618 */       return h;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/*  622 */       if (obj instanceof SharedBDD.FireKey) {
/*      */         
/*  624 */         SharedBDD.FireKey ok = (SharedBDD.FireKey)obj;
/*  625 */         return (this.root1 == this.root1 && this.root2 == this.root2 && this.cur == this.cur && this.prePost.equals(this.prePost));
/*      */       } 
/*  627 */       return false;
/*      */     } }
/*      */   
/*      */   class PathKey {
/*      */     int hc;
/*      */     int root;
/*      */     int cur;
/*      */     Object path;
/*      */     boolean isPath;
/*      */     Operation op;
/*      */     
/*      */     PathKey(int r, Object path, int cur, boolean isPath) {
/*  639 */       this.root = r;
/*  640 */       this.cur = cur;
/*  641 */       this.path = path;
/*  642 */       this.isPath = isPath;
/*      */     }
/*      */ 
/*      */     
/*      */     PathKey(int r, int[] path, int cur) {
/*  647 */       this.root = r;
/*  648 */       this.cur = cur;
/*  649 */       this.path = path;
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*  653 */       int h = this.hc;
/*  654 */       if (h == 0) {
/*  655 */         String s = "" + this.root + this.cur;
/*  656 */         this.hc = this.path.hashCode() * s.hashCode();
/*  657 */         h = this.hc;
/*      */       } 
/*  659 */       return h;
/*      */     }
/*      */     
/*      */     public boolean equals(Object obj) {
/*  663 */       if (obj instanceof PathKey) {
/*  664 */         PathKey ok = (PathKey)obj;
/*  665 */         return (this.path.equals(ok.path) && this.root == ok.root && this.cur == ok.cur && this.isPath == ok.isPath);
/*      */       } 
/*  667 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */   public BDD change(int var) {
/*  672 */     if (resultTable.size() > 500)
/*  673 */       resultTable.clear(); 
/*  674 */     return new SharedBDD(change_(this.root, var));
/*      */   }
/*      */   
/*      */   private int change_(int root1, int var) {
/*      */     int res;
/*  679 */     OpKey opKey = new OpKey(change, root1, var);
/*  680 */     Integer i = (Integer)resultTable.get(opKey);
/*  681 */     if (i != null) {
/*  682 */       return i.intValue();
/*      */     }
/*  684 */     if ((nodes[root1]).var == var) {
/*      */       
/*  686 */       res = makeNode((nodes[root1]).var, (nodes[root1]).high, (nodes[root1]).low);
/*  687 */     } else if ((nodes[root1]).var > var) {
/*  688 */       res = makeNode(var, 0, root1);
/*      */     } else {
/*  690 */       res = makeNode((nodes[root1]).var, change_((nodes[root1]).low, var), change_((nodes[root1]).high, var));
/*      */     } 
/*      */     
/*  693 */     resultTable.put(opKey, new Integer(res));
/*  694 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD or(BDD arg) {
/*  705 */     resultTable.clear();
/*  706 */     return new SharedBDD(or_(this.root, arg.root()));
/*      */   }
/*      */   private int or_(int root1, int root2) {
/*      */     int res;
/*  710 */     if (root1 == 0)
/*      */     {
/*  712 */       return root2;
/*      */     }
/*      */     
/*  715 */     if (root2 == 0)
/*      */     {
/*  717 */       return root1;
/*      */     }
/*  719 */     if (root1 == root2) return root1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  725 */     if (root1 < 2 && root2 < 2)
/*      */     {
/*  727 */       return or.op(root1, root2);
/*      */     }
/*  729 */     OpKey opKey = new OpKey(or, root1, root2);
/*  730 */     Integer i = (Integer)resultTable.get(opKey);
/*  731 */     if (i != null) {
/*  732 */       return i.intValue();
/*      */     }
/*      */     
/*  735 */     if ((nodes[root1]).var == (nodes[root2]).var) {
/*  736 */       int v0 = or_((nodes[root1]).low, (nodes[root2]).low);
/*  737 */       int v1 = or_((nodes[root1]).high, (nodes[root2]).high);
/*  738 */       res = makeNode((nodes[root1]).var, v0, v1);
/*      */     }
/*  740 */     else if ((nodes[root1]).var > (nodes[root2]).var) {
/*  741 */       res = makeNode((nodes[root2]).var, or_((nodes[root2]).low, root1), (nodes[root2]).high);
/*      */     } else {
/*      */       
/*  744 */       res = makeNode((nodes[root1]).var, or_((nodes[root1]).low, root2), (nodes[root1]).high);
/*      */     } 
/*      */     
/*  747 */     resultTable.put(opKey, new Integer(res));
/*  748 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD and(BDD arg) {
/*  755 */     if (resultTable.size() > 500) resultTable.clear(); 
/*  756 */     return new SharedBDD(and_(this.root, arg.root()));
/*      */   }
/*      */   
/*      */   private int and_(int root1, int root2) {
/*      */     int res;
/*  761 */     if (root1 == 0)
/*  762 */       return 0; 
/*  763 */     if (root2 == 0) {
/*  764 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*  768 */     if (root1 < 2 && root2 < 2)
/*      */     {
/*  770 */       return and.op(root1, root2);
/*      */     }
/*  772 */     OpKey opKey = new OpKey(and, root1, root2);
/*  773 */     Integer i = (Integer)resultTable.get(opKey);
/*  774 */     if (i != null) {
/*  775 */       return i.intValue();
/*      */     }
/*      */     
/*  778 */     if ((nodes[root1]).var == (nodes[root2]).var) {
/*  779 */       int v0 = and_((nodes[root1]).low, (nodes[root2]).low);
/*  780 */       int v1 = and_((nodes[root1]).high, (nodes[root2]).high);
/*  781 */       res = makeNode((nodes[root1]).var, v0, v1);
/*  782 */     } else if ((nodes[root1]).var > (nodes[root2]).var) {
/*  783 */       res = and_((nodes[root2]).low, root1);
/*      */     } else {
/*  785 */       res = and_((nodes[root1]).low, root2);
/*      */     } 
/*  787 */     resultTable.put(opKey, new Integer(res));
/*  788 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEqual(BDD arg) {
/*  797 */     return equals(arg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int makeNode(int var, int low, int high) {
/*      */     try {
/*  806 */       if (high == 0) return low; 
/*  807 */       if (low >= 0 && low == high) {
/*  808 */         return low;
/*      */       }
/*  810 */       if (low < 0) {
/*  811 */         BddNode bddNode = new BddNode(var, low, high);
/*  812 */         nodes[size++] = bddNode;
/*      */         
/*  814 */         return size - 1;
/*      */       } 
/*  816 */       BddNode node = new BddNode(var, low, high);
/*  817 */       Integer index = (Integer)uniqueTable.get(node);
/*  818 */       if (index == null) {
/*  819 */         if (!freeNodeIndices.isEmpty()) {
/*  820 */           Integer integer = freeNodeIndices.iterator().next();
/*  821 */           freeNodeIndices.remove(integer);
/*  822 */           nodes[integer.intValue()] = node;
/*  823 */           uniqueTable.put(node, integer);
/*  824 */           return integer.intValue();
/*      */         } 
/*  826 */         nodes[size] = node;
/*  827 */         size++;
/*  828 */         uniqueTable.put(node, new Integer(size - 1));
/*  829 */         return size - 1;
/*      */       } 
/*  831 */       int i = index.intValue();
/*  832 */       return i;
/*      */     }
/*  834 */     catch (Exception e) {
/*  835 */       System.out.println("gc -" + freeNodeIndices.size());
/*  836 */       gc();
/*  837 */       System.out.println("after gc -" + freeNodeIndices.size());
/*  838 */       if (freeNodeIndices.size() == 0) {
/*  839 */         printNodesInfo();
/*  840 */         System.out.println("exit");
/*  841 */         System.exit(1);
/*      */       } 
/*      */       
/*  844 */       return makeNode(var, low, high);
/*      */     } 
/*      */   }
/*      */   
/*      */   public int root() {
/*  849 */     return this.root;
/*      */   }
/*      */   
/*  852 */   public SharedBDD(int root) { this.resultCount = new HashMap<>(); instances++; this.root = root; incReferences(); } public SharedBDD(BitSet bs) { this.resultCount = new HashMap<>(); instances++; this.root = 1; for (int i = (nodes[1]).var - 1; i >= 0; i--) { if (bs.member(i)) this.root = makeNode(i, 0, this.root);  }  incReferences(); } public SharedBDD(ExtendedIncMatrix sm, int row) { this.resultCount = new HashMap<>(); try { instances++; this.root = 1; int j = 1; int elements = sm.elementsInRow(row); for (int i = 0; i < elements && sm.getIthColumnIndexInRow(row, elements - j) >= sm.realCols; i++) { this.root = makeNode(sm.getIthColumnIndexInRow(row, elements - j) - sm.realCols, 0, this.root); j++; }  incReferences(); } catch (Exception e) { e.printStackTrace(); System.exit(1); }  } public SharedBDD(int var, boolean neg) { this.resultCount = new HashMap<>(); instances++; if (neg) {
/*      */       this.root = makeNode(var, 0, 1);
/*      */     } else {
/*      */       this.root = makeNode(var, 1, 0);
/*  856 */     }  incReferences(); } public long paths() { this.resultCount = new HashMap<>();
/*  857 */     return countPaths_(this.root); }
/*      */ 
/*      */   
/*      */   private long countPaths_(int root) {
/*  861 */     if (root == 1) return 1L; 
/*  862 */     if (root == 0) return 0L; 
/*  863 */     Long i = (Long)this.resultCount.get(nodes[root]);
/*  864 */     if (i != null) return i.longValue(); 
/*  865 */     long c1 = countPaths_((nodes[root]).low);
/*  866 */     long c2 = countPaths_((nodes[root]).high);
/*  867 */     this.resultCount.put(nodes[root], new Long(c1 + c2));
/*  868 */     return c1 + c2;
/*      */   }
/*      */   
/*      */   public long nodes() {
/*  872 */     this.resultCount = new HashMap<>();
/*  873 */     long n = countNodes_(this.root);
/*      */     
/*  875 */     return n;
/*      */   }
/*      */ 
/*      */   
/*      */   private long countNodes_(int root) {
/*  880 */     if (root == 1 || root == 0) return 0L;
/*      */ 
/*      */     
/*  883 */     Long i = (Long)this.resultCount.get(nodes[root]);
/*  884 */     if (i != null) return 0L;
/*      */     
/*  886 */     long res = countNodes_((nodes[root]).high) + countNodes_((nodes[root]).low) + 1L;
/*  887 */     this.resultCount.put(nodes[root], new Long(res));
/*  888 */     return res;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/*  893 */     if (!(obj instanceof SharedBDD)) return false; 
/*  894 */     return (this.root == ((SharedBDD)obj).root);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void init(int nodeSize, int variables) {
/*  901 */     nodes = new BddNode[nodeSize];
/*  902 */     size = 0;
/*  903 */     uniqueTable.clear();
/*  904 */     Zero = new SharedBDD(makeNode(variables, -1, -1));
/*  905 */     One = new SharedBDD(makeNode(variables, -1, -1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BDD complement() {
/*  912 */     return new SharedBDD(complement_(this.root));
/*      */   }
/*      */   
/*      */   public int complement_(int root) {
/*  916 */     if (root == 1) return 0; 
/*  917 */     if (root == 0) return 1; 
/*  918 */     return makeNode((nodes[root]).var, complement_((nodes[root]).low), complement_((nodes[root]).high));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BDD copy() {
/*  925 */     return new SharedBDD(this.root);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void incr_unmark(int root) {
/*  931 */     incr_(root); unmark_(root);
/*      */   }
/*      */ 
/*      */   
/*      */   public void unmark() {
/*  936 */     unmark_(this.root);
/*      */   }
/*      */   
/*      */   public static void unmark_(int root) {
/*  940 */     if (root < 2)
/*  941 */       return;  if (!(nodes[root]).marked) {
/*      */       return;
/*      */     }
/*      */     
/*  945 */     (nodes[root]).marked = false;
/*  946 */     unmark_((nodes[root]).low);
/*  947 */     unmark_((nodes[root]).high);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void decrReferences(int v) {
/*      */     try {
/*  954 */       decr_(this.root, v);
/*  955 */     } catch (Exception e) {
/*  956 */       System.out.println("decrement for: " + this.root + "var: " + (nodes[this.root]).var);
/*  957 */       System.exit(1);
/*      */     } 
/*  959 */     unmark();
/*      */   }
/*      */ 
/*      */   
/*      */   private static void decr_(int root, int v) throws NullPointerException {
/*  964 */     if (root == 1 || root == 0)
/*      */       return; 
/*  966 */     if ((nodes[root]).marked) {
/*      */       return;
/*      */     }
/*      */     
/*  970 */     (nodes[root]).marked = true;
/*      */     
/*  972 */     if ((nodes[root]).references == 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  977 */     decr_((nodes[root]).high, v);
/*  978 */     decr_((nodes[root]).low, v);
/*  979 */     (nodes[root]).references -= v;
/*  980 */     if ((nodes[root]).references == 0) {
/*      */       
/*  982 */       freeNodeIndices.add(new Integer(root));
/*  983 */       uniqueTable.remove(nodes[root]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void incReferences() {
/*  991 */     if ((nodes[this.root]).marked) {
/*  992 */       System.out.println("darf nicht sein: " + (nodes[this.root]).var);
/*  993 */       System.exit(1);
/*      */     } 
/*  995 */     incr_unmark(this.root);
/*      */   }
/*      */ 
/*      */   
/*      */   private static void incr_(int root) {
/* 1000 */     if (root == 1 || root == 0)
/* 1001 */       return;  if ((nodes[root]).marked)
/* 1002 */       return;  (nodes[root]).marked = true;
/* 1003 */     (nodes[root]).references++;
/* 1004 */     incr_((nodes[root]).high);
/* 1005 */     incr_((nodes[root]).low);
/*      */   }
/*      */ 
/*      */   
/*      */   public void finalize() {
/* 1010 */     instances--;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void test() {
/* 1016 */     init(16, 6);
/* 1017 */     BitSet bs = new BitSet(198);
/* 1018 */     for (int i = 2; i < 5; i += 2) {
/* 1019 */       bs.insert(i);
/*      */     }
/* 1021 */     BDD test = new SharedBDD(bs);
/*      */     
/* 1023 */     System.out.println("test: " + test);
/* 1024 */     System.out.println("size:" + test.paths());
/*      */     
/* 1026 */     bs = new BitSet(198);
/* 1027 */     for (int j = 4; j < 6; j += 4)
/* 1028 */       bs.insert(j); 
/* 1029 */     BDD test2 = new SharedBDD(bs);
/*      */     
/* 1031 */     bs.clear();
/* 1032 */     bs.insert(2);
/* 1033 */     bs.insert(3);
/* 1034 */     BDD test2a = new SharedBDD(bs);
/* 1035 */     System.out.println("test2: " + test2);
/* 1036 */     BDD test3 = test.or(test2);
/* 1037 */     test3 = test.or(test2a);
/* 1038 */     System.out.println("test4: " + test3);
/* 1039 */     int[] path3 = new int[10];
/* 1040 */     for (int k = 0; k < 10; k++) {
/*      */       
/* 1042 */       if (k == 5) { k++; }
/* 1043 */       else { path3[k] = k; }
/*      */     
/* 1045 */     }  System.out.println("size3:" + test3.paths());
/* 1046 */     int[] path = { 3 };
/* 1047 */     BDD three = test3.notContainsSubPath(path);
/* 1048 */     System.out.println("contains [3]: " + three);
/* 1049 */     BDD bla = new SharedBDD(3, true);
/* 1050 */     three = three.or(bla);
/* 1051 */     System.out.println("test3 or [3]" + three);
/* 1052 */     bs.clear();
/* 1053 */     bs.insert(4);
/* 1054 */     bs.insert(5);
/*      */     
/* 1056 */     System.out.println("test3 or [4,5]" + (SharedBDD)three.or(new SharedBDD(bs)));
/* 1057 */     int[] path2 = { 2, 3, 4 };
/*      */ 
/*      */     
/* 1060 */     System.out.println("contains 0-100: " + test2.containsSubPathOf(path3));
/* 1061 */     System.out.println("nodes " + freeNodes() + "instances " + instances);
/*      */   }
/*      */   public static void test2() {
/* 1064 */     System.out.println("starting test");
/* 1065 */     BitSet bs = new BitSet(10);
/* 1066 */     bs.insert(2);
/* 1067 */     bs.insert(4);
/* 1068 */     System.out.println(bs);
/* 1069 */     BDD b1 = new SharedBDD(bs);
/* 1070 */     bs.insert(6);
/* 1071 */     System.out.println(bs);
/* 1072 */     BDD b2 = new SharedBDD(bs);
/* 1073 */     bs.clear();
/* 1074 */     bs.insert(3);
/* 1075 */     bs.insert(4);
/* 1076 */     bs.insert(7);
/* 1077 */     bs.insert(8);
/* 1078 */     System.out.println(bs);
/*      */     
/* 1080 */     BDD b3 = new SharedBDD(bs);
/* 1081 */     BDD b4 = b3.or(b2);
/* 1082 */     bs.clear();
/* 1083 */     bs.insert(2);
/* 1084 */     bs.insert(4);
/* 1085 */     bs.insert(5);
/*      */     
/* 1087 */     System.out.println(bs);
/* 1088 */     b3 = new SharedBDD(bs);
/* 1089 */     BDD b6 = b4.or(b3);
/*      */     
/* 1091 */     int[] path = { 2, 4 };
/* 1092 */     BDD b5 = b6.notContainsSubPath(path);
/* 1093 */     System.out.println("all paths");
/*      */     
/* 1095 */     ((SharedBDD)b6).printPaths();
/* 1096 */     bs.clear();
/* 1097 */     bs.insert(2);
/* 1098 */     bs.insert(4);
/*      */     
/* 1100 */     System.out.println("paths not containing {2,4}");
/* 1101 */     ((SharedBDD)b5).printPaths();
/*      */     
/* 1103 */     BDD b7 = b5.or(new SharedBDD(bs));
/*      */     
/* 1105 */     System.out.println("all paths");
/* 1106 */     ((SharedBDD)b7).printPaths();
/* 1107 */     bs.clear();
/* 1108 */     bs.insert(2);
/* 1109 */     bs.insert(4);
/* 1110 */     bs.insert(7);
/* 1111 */     int[] path2 = { 2, 4, 7 };
/* 1112 */     System.out.println("containsSubPath" + bs + " " + b7.containsSubPathOf(path2));
/* 1113 */     b3.free();
/* 1114 */     b1.free();
/* 1115 */     b2.free();
/* 1116 */     b4.free();
/* 1117 */     b5.free();
/* 1118 */     b6.free();
/* 1119 */     b7.free();
/*      */     
/* 1121 */     printNodesInfo();
/*      */   }
/*      */ 
/*      */   
/*      */   public static void gc() {
/* 1126 */     for (Iterator<Integer> it = freeRoots.keySet().iterator(); it.hasNext(); ) {
/* 1127 */       Integer key = it.next();
/* 1128 */       int k = key.intValue();
/* 1129 */       int v = ((Integer)freeRoots.get(key)).intValue();
/*      */       
/* 1131 */       decr_(k, v);
/* 1132 */       unmark_(k);
/*      */     } 
/*      */     
/* 1135 */     resultFireTable.clear();
/* 1136 */     resultPathTable.clear();
/* 1137 */     freeRoots.clear();
/*      */   }
/*      */   
/*      */   public void free() {
/* 1141 */     Integer key = new Integer(this.root);
/* 1142 */     Integer v = (Integer)freeRoots.get(key);
/* 1143 */     int val = 0;
/* 1144 */     if (v != null) {
/* 1145 */       val = v.intValue();
/*      */       
/* 1147 */       freeRoots.remove(key);
/*      */     } 
/* 1149 */     val++;
/* 1150 */     freeRoots.put(key, new Integer(val));
/*      */ 
/*      */     
/* 1153 */     if (freeNodes() < nodes.length / 15)
/*      */     {
/*      */       
/* 1156 */       gc();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] args) {
/* 1166 */     init(20, 10);
/* 1167 */     printNodesInfo();
/* 1168 */     test2();
/*      */     
/* 1170 */     gc();
/* 1171 */     System.out.println("free: " + freeNodeIndices.size());
/* 1172 */     printNodesInfo();
/*      */   }
/*      */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/bdd/SharedBDD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */