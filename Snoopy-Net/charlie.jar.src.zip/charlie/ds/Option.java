package charlie.ds;

public interface Option {
  void setValue(Object paramObject);
  
  Object getValue();
  
  void addOptionListener(OptionListener paramOptionListener);
  
  void removeOptionListener(OptionListener paramOptionListener);
  
  void addDependency(OptionChangeAction paramOptionChangeAction);
  
  void removeDependcy(OptionChangeAction paramOptionChangeAction);
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/Option.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */