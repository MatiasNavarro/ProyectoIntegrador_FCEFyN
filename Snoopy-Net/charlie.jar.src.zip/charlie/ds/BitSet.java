/*     */ package charlie.ds;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class BitSet
/*     */   implements Iterable<Integer>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 436660943059291504L;
/*  15 */   private static long instances = 0L;
/*     */   
/*     */   private static final byte BIT0 = -128;
/*     */   
/*     */   private static final byte BIT1 = 64;
/*     */   private static final byte BIT2 = 32;
/*     */   private static final byte BIT3 = 16;
/*     */   private static final byte BIT4 = 8;
/*     */   private static final byte BIT5 = 4;
/*     */   private static final byte BIT6 = 2;
/*     */   private static final byte BIT7 = 1;
/*     */   private transient byte[] vector;
/*     */   private int fieldLength;
/*     */   
/*     */   public BitSet(int max) {
/*  30 */     instances++;
/*  31 */     this.fieldLength = max / 8;
/*  32 */     if (max % 8 != 0) {
/*  33 */       this.fieldLength++;
/*     */     }
/*  35 */     this.vector = new byte[this.fieldLength];
/*     */   }
/*     */   
/*     */   public BitSet(int max, int filledTo) {
/*  39 */     instances++;
/*  40 */     this.fieldLength = max / 8;
/*  41 */     if (max % 8 != 0) {
/*  42 */       this.fieldLength++;
/*     */     }
/*  44 */     this.vector = new byte[this.fieldLength];
/*     */ 
/*     */ 
/*     */     
/*  48 */     for (int i = 0; i < this.fieldLength * 8; i++) {
/*  49 */       if (i < filledTo) {
/*  50 */         insert(i);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public int capacity() {
/*  56 */     return this.fieldLength * 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void finalize() {
/*  64 */     instances--;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean member(int v) {
/*  69 */     int index = v / 8;
/*  70 */     byte b = this.vector[index];
/*  71 */     byte res = getRest(v);
/*     */     
/*  73 */     return (and(res, b) == res);
/*     */   }
/*     */ 
/*     */   
/*     */   private byte getRest(int v) {
/*  78 */     byte res = 0;
/*  79 */     switch (v % 8) { case 0:
/*  80 */         return Byte.MIN_VALUE;
/*  81 */       case 1: return 64;
/*  82 */       case 2: return 32;
/*  83 */       case 3: return 16;
/*  84 */       case 4: return 8;
/*  85 */       case 5: return 4;
/*  86 */       case 6: return 2;
/*  87 */       case 7: return 1; }
/*     */     
/*  89 */     return res;
/*     */   }
/*     */   
/*     */   public void insert(int v) {
/*  93 */     int index = v / 8;
/*  94 */     byte b = this.vector[index];
/*  95 */     byte res = getRest(v);
/*  96 */     if (and(res, b) == res) {
/*     */       return;
/*     */     }
/*  99 */     this.vector[index] = or(b, res);
/*     */   }
/*     */   
/*     */   private byte and(int res, int b) {
/* 103 */     return (byte)(res & b);
/*     */   }
/*     */   
/*     */   private byte or(int res, int b) {
/* 107 */     return (byte)(res | b);
/*     */   }
/*     */   
/*     */   private byte xor(int res, int b) {
/* 111 */     return (byte)(res ^ b);
/*     */   }
/*     */   
/*     */   public void clear() {
/* 115 */     for (int i = 0; i < this.fieldLength; i++) {
/* 116 */       this.vector[i] = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 121 */     for (int i = 0; i < this.fieldLength; i++) {
/* 122 */       if (this.vector[i] != 0) {
/* 123 */         return false;
/*     */       }
/*     */     } 
/* 126 */     return true;
/*     */   }
/*     */   
/*     */   public int size() {
/* 130 */     int size = 0;
/* 131 */     for (int i = 0; i < this.fieldLength * 8; i++) {
/* 132 */       if (member(i)) {
/* 133 */         size++;
/*     */       }
/*     */     } 
/* 136 */     return size;
/*     */   }
/*     */   
/*     */   public boolean equals(BitSet bs) {
/* 140 */     if (this.fieldLength != bs.fieldLength) {
/* 141 */       return false;
/*     */     }
/* 143 */     for (int i = 0; i < this.fieldLength; i++) {
/* 144 */       if (this.vector[i] != bs.vector[i]) {
/* 145 */         return false;
/*     */       }
/*     */     } 
/* 148 */     return true;
/*     */   }
/*     */   
/*     */   public int first() {
/* 152 */     for (int i = 0; i < this.fieldLength * 8; i++) {
/* 153 */       if (member(i)) {
/* 154 */         delete(i);
/* 155 */         return i;
/*     */       } 
/*     */     } 
/* 158 */     return -1;
/*     */   }
/*     */   
/*     */   public void delete(int v) {
/* 162 */     int index = v / 8;
/* 163 */     byte b = this.vector[index];
/* 164 */     byte res = getRest(v);
/* 165 */     if (and(res, b) != res) {
/*     */       return;
/*     */     }
/*     */     
/* 169 */     this.vector[index] = xor(b, res);
/*     */   }
/*     */   
/*     */   public int hashCurrentSupport() {
/* 173 */     int res = 0;
/* 174 */     for (int i = 0; i < this.fieldLength; i++) {
/* 175 */       res += this.vector[i];
/*     */     }
/* 177 */     return res;
/*     */   }
/*     */   
/*     */   public BitSet intersection(BitSet bs) {
/* 181 */     int newLength = this.fieldLength;
/* 182 */     if (this.fieldLength > bs.fieldLength) {
/* 183 */       newLength = bs.fieldLength;
/*     */     }
/* 185 */     BitSet inter = new BitSet(newLength * 8);
/* 186 */     for (int i = 0; i < newLength; i++)
/*     */     {
/* 188 */       inter.vector[i] = (byte)(this.vector[i] & bs.vector[i]);
/*     */     }
/*     */     
/* 191 */     return inter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(BitSet _bs) {
/* 205 */     if (this == _bs) {
/* 206 */       return true;
/*     */     }
/*     */     
/* 209 */     if (_bs == null) {
/* 210 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     return intersection(_bs).equals(_bs);
/*     */   }
/*     */   
/*     */   public int getElementAt(int pos) {
/* 220 */     int j = 0;
/* 221 */     for (int i = 0; i < this.fieldLength * 8; i++) {
/* 222 */       if (member(i)) {
/* 223 */         if (j == pos) {
/* 224 */           return i;
/*     */         }
/* 226 */         j++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 231 */     return -1;
/*     */   }
/*     */   
/*     */   public void union(BitSet bs) {
/* 235 */     for (int i = 0; i < this.fieldLength; i++) {
/* 236 */       this.vector[i] = or(this.vector[i], bs.vector[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void unionAndDiff(BitSet bs, BitSet bs2) {
/* 241 */     for (int i = 0; i < this.fieldLength; i++) {
/* 242 */       this.vector[i] = or(this.vector[i], bs.vector[i]);
/* 243 */       this.vector[i] = xor(this.vector[i], and(this.vector[i], bs2.vector[i]));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean subSet(BitSet fs) {
/* 249 */     for (int i = 0; i < this.fieldLength; i++) {
/* 250 */       if (this.vector[i] != and(fs.vector[i], this.vector[i])) {
/* 251 */         return false;
/*     */       }
/*     */     } 
/* 254 */     return true;
/*     */   }
/*     */   
/*     */   public void diff(BitSet fs) {
/* 258 */     for (int i = 0; i < this.fieldLength; i++) {
/* 259 */       this.vector[i] = xor(this.vector[i], and(this.vector[i], fs.vector[i]));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 265 */     StringBuffer ret = new StringBuffer();
/* 266 */     ret.append("(");
/* 267 */     for (int i = 0; i < this.fieldLength * 8; i++) {
/* 268 */       if (member(i)) {
/* 269 */         ret.append(i);
/* 270 */         ret.append("; ");
/*     */       } 
/*     */     } 
/* 273 */     ret.append(") ");
/* 274 */     return ret.toString();
/*     */   }
/*     */   
/*     */   public BitSet copy() {
/* 278 */     BitSet ret = new BitSet(this.fieldLength * 8);
/* 279 */     for (int i = 0; i < this.fieldLength; i++) {
/* 280 */       ret.vector[i] = this.vector[i];
/*     */     }
/* 282 */     return ret;
/*     */   }
/*     */   
/*     */   public Iterator<Integer> iterator() {
/* 286 */     return new BitIterator();
/*     */   }
/*     */   
/*     */   class BitIterator implements Iterator<Integer> {
/* 290 */     int index = BitSet.this.fieldLength * 8;
/*     */     
/*     */     public BitIterator() {
/* 293 */       this.index = 0;
/* 294 */       while (this.index < BitSet.this.fieldLength * 8 && 
/* 295 */         !BitSet.this.member(this.index))
/*     */       {
/*     */         
/* 298 */         this.index++;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 304 */       return (this.index < BitSet.this.fieldLength * 8);
/*     */     }
/*     */     
/*     */     public Integer next() {
/* 308 */       if (!hasNext()) {
/* 309 */         return null;
/*     */       }
/* 311 */       int ret = this.index;
/* 312 */       this.index++;
/* 313 */       while (this.index < BitSet.this.fieldLength * 8 && 
/* 314 */         !BitSet.this.member(this.index))
/*     */       {
/*     */         
/* 317 */         this.index++;
/*     */       }
/* 319 */       return new Integer(ret);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */   }
/*     */ 
/*     */   
/*     */   public BitSet translate(Vector<Integer> translationTable) {
/* 329 */     BitSet bs = new BitSet(capacity());
/* 330 */     for (int i = 0; i < translationTable.size(); i++) {
/* 331 */       if (member(((Integer)translationTable.get(i)).intValue())) {
/* 332 */         bs.insert(i);
/*     */       }
/*     */     } 
/* 335 */     return bs;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 340 */     int prime = 31;
/* 341 */     int result = 1;
/* 342 */     result = 31 * result + this.fieldLength;
/* 343 */     result = 31 * result + Arrays.hashCode(this.vector);
/* 344 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 349 */     if (this == obj) {
/* 350 */       return true;
/*     */     }
/* 352 */     if (obj == null) {
/* 353 */       return false;
/*     */     }
/* 355 */     if (getClass() != obj.getClass()) {
/* 356 */       return false;
/*     */     }
/* 358 */     BitSet other = (BitSet)obj;
/* 359 */     if (this.fieldLength != other.fieldLength) {
/* 360 */       return false;
/*     */     }
/* 362 */     if (!Arrays.equals(this.vector, other.vector)) {
/* 363 */       return false;
/*     */     }
/* 365 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream s) throws IOException {
/* 370 */     s.defaultWriteObject();
/*     */ 
/*     */     
/* 373 */     s.writeInt(this.vector.length);
/*     */ 
/*     */     
/* 376 */     for (int i = 0; i < this.vector.length; i++) {
/* 377 */       s.writeByte(this.vector[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/* 383 */     s.defaultReadObject();
/*     */ 
/*     */     
/* 386 */     int vectorLength = s.readInt();
/* 387 */     this.vector = new byte[vectorLength];
/*     */ 
/*     */     
/* 390 */     for (int i = 0; i < this.vector.length; i++)
/* 391 */       this.vector[i] = s.readByte(); 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/BitSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */