/*    */ package charlie.ds;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class BooleanOption
/*    */   implements Option {
/*    */   private Boolean v;
/*    */   private HashSet dependencies;
/*    */   private HashSet listeners;
/*    */   
/*    */   public BooleanOption(boolean v) {
/* 13 */     this.dependencies = new HashSet();
/* 14 */     this.listeners = new HashSet();
/* 15 */     setValue(new Boolean(v));
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 20 */     return this.v;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(Object value) {
/* 25 */     this.v = (Boolean)value;
/* 26 */     for (Iterator<OptionListener> iterator = this.listeners.iterator(); iterator.hasNext();) {
/* 27 */       ((OptionListener)iterator.next()).reactOnChange(this);
/*    */     }
/* 29 */     for (Iterator<OptionChangeAction> it = this.dependencies.iterator(); it.hasNext();) {
/* 30 */       ((OptionChangeAction)it.next()).checkValue(this.v);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addOptionListener(OptionListener ol) {
/* 37 */     this.listeners.add(ol);
/*    */   }
/*    */   
/*    */   public void removeOptionListener(OptionListener ol) {
/* 41 */     this.listeners.remove(ol);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addDependency(OptionChangeAction oca) {
/* 46 */     this.dependencies.add(oca);
/*    */   }
/*    */   public void removeDependcy(OptionChangeAction oca) {
/* 49 */     this.dependencies.remove(oca);
/*    */   }
/*    */   
/*    */   public boolean booleanValue() {
/* 53 */     return this.v.booleanValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 58 */     if (o instanceof Boolean) return this.v.equals(o); 
/* 59 */     if (o instanceof BooleanOption) return super.equals(o);
/*    */     
/* 61 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ds/BooleanOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */