/*      */ package charlie.pn;
/*      */ 
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Vector;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PlaceTransitionNet
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   28 */   private static final Log LOG = LogFactory.getLog(PlaceTransitionNet.class);
/*      */   
/*      */   public static final byte INTERVAL = 0;
/*      */   
/*      */   public static final byte CONSTANT = 1;
/*      */   
/*      */   public static final byte REACTION = 2;
/*      */   public static final byte DURATION = 3;
/*      */   public static final byte NO_TIMED_NET = 4;
/*   37 */   public static int EDGE = 7;
/*   38 */   public static int INHIBITOR_EDGE = 8;
/*   39 */   public static int READ_EDGE = 9;
/*   40 */   public static int EQUAL_EDGE = 10;
/*   41 */   public static int RESET_EDGE = 11;
/*   42 */   public static int UNDIRECTED_EDGE = 12;
/*   43 */   public static int MODIFIER_EDGE = 13;
/*      */   
/*      */   public static final int FC = 2;
/*      */   public static final int EFC = 3;
/*      */   public static final int ES = 4;
/*      */   public static final int SM = 0;
/*      */   public static final int MG = 1;
/*      */   public static final int NES = 5;
/*   51 */   public byte TIME_DESIGNATION = -1;
/*   52 */   public byte TIMED_NET_TYPE = -1;
/*      */   
/*   54 */   private final Map<PNNode, Integer> hom = new HashMap<>();
/*   55 */   private final Map<String, PNNode> allNodes = new HashMap<>();
/*   56 */   private final Map<PNNode, String> identifier = new HashMap<>();
/*      */   
/*      */   boolean isExtendedPN = false;
/*      */   
/*      */   private boolean TimedNet = false;
/*   61 */   private static PlaceTransitionNet selfReference = null;
/*      */   public DiGraph structure;
/*      */   public boolean boundednessChecked = false;
/*   64 */   private NodeList nl = new NodeList(200);
/*   65 */   public SortedElementsDynamic placesM0 = new SortedElementsDynamic(true);
/*      */   private Marking m0Places;
/*   67 */   private SortedElementsDynamic transitionsM0 = new SortedElementsDynamic(false);
/*      */   
/*      */   private State m0State;
/*   70 */   private String netName = "petrinet";
/*      */   
/*      */   private boolean bounded = true;
/*      */   
/*      */   protected NodeSet ft0;
/*      */   
/*      */   protected NodeSet tf0;
/*      */   
/*      */   protected NodeSet fp0;
/*      */   
/*      */   protected NodeSet pf0;
/*      */   protected NodeSet transitionsRead;
/*      */   protected NodeSet transitionsReset;
/*      */   protected NodeSet transitionsInhibitor;
/*      */   protected NodeSet deadTransitions;
/*      */   protected NodeSet notLive;
/*   86 */   private List<Place> places = new Vector<>();
/*      */ 
/*      */ 
/*      */   
/*   90 */   private List<String> placeNames = new Vector<>();
/*      */ 
/*      */ 
/*      */   
/*   94 */   private List<Integer> placeIds = new Vector<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   99 */   private List<Transition> trans = new Vector<>();
/*      */ 
/*      */ 
/*      */   
/*  103 */   private List<String> transitionNames = new Vector<>();
/*      */ 
/*      */ 
/*      */   
/*  107 */   private List<Integer> transitionIds = new Vector<>();
/*      */   
/*  109 */   public List<Integer> translationTableTransitions = new Vector<>();
/*  110 */   public static Map<?, ?> translationMapTransitions = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*  114 */   HashSet<Object> visited = new HashSet();
/*  115 */   HashSet<PNNode> inLin = new HashSet<>();
/*      */ 
/*      */   
/*  118 */   HashSet<PNNode> ddl = new HashSet<>();
/*  119 */   HashSet<PNNode> old = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ord;
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean homogenous;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static PlaceTransitionNet getReference() {
/*  134 */     return selfReference;
/*      */   }
/*      */   
/*      */   public void init() {
/*  138 */     this.TIME_DESIGNATION = 0;
/*  139 */     this.TIMED_NET_TYPE = 4;
/*      */     
/*  141 */     this.places.clear();
/*  142 */     this.trans.clear();
/*  143 */     this.allNodes.clear();
/*  144 */     this.identifier.clear();
/*  145 */     this.placeNames.clear();
/*  146 */     this.transitionNames.clear();
/*  147 */     this.placeIds.clear();
/*  148 */     this.transitionIds.clear();
/*      */     
/*  150 */     this.translationTableTransitions.clear();
/*  151 */     translationMapTransitions.clear();
/*      */     
/*  153 */     this.structure = new DiGraph();
/*  154 */     this.placesM0 = new SortedElementsDynamic(true);
/*  155 */     this.placesM0.name += " PlaceTransitionNet placesM0";
/*      */   }
/*      */   
/*      */   public NodeSet getNotLive() {
/*  159 */     return this.notLive;
/*      */   }
/*      */   
/*      */   public void setNotLive(NodeSet notLive) {
/*  163 */     this.notLive = notLive;
/*      */   }
/*      */   
/*      */   public void setTransitionsRead(NodeSet transitionsRead) {
/*  167 */     this.transitionsRead = transitionsRead;
/*      */   }
/*      */   
/*      */   public void setTransitionsReset(NodeSet transitionsReset) {
/*  171 */     this.transitionsReset = transitionsReset;
/*      */   }
/*      */   
/*      */   public void setTransitionsInhibitor(NodeSet transitionsInhibitor) {
/*  175 */     this.transitionsInhibitor = transitionsInhibitor;
/*      */   }
/*      */   
/*      */   public void setDeadTransitions(NodeSet deadTransitions) {
/*  179 */     this.deadTransitions = deadTransitions;
/*      */   }
/*      */   
/*      */   public void setTimedNet(boolean timedNet) {
/*  183 */     this.TimedNet = timedNet;
/*      */   }
/*      */   
/*      */   public boolean isTimedNet() {
/*  187 */     return this.TimedNet;
/*      */   }
/*      */   
/*      */   public Map<String, PNNode> allNodes() {
/*  191 */     return this.allNodes;
/*      */   }
/*      */   
/*      */   public Map<PNNode, String> identifier() {
/*  195 */     return this.identifier;
/*      */   }
/*      */   
/*      */   public PNNode lookUp(String identifier) {
/*  199 */     return this.allNodes.get(identifier);
/*      */   }
/*      */   
/*      */   public void setUnbounded() {
/*  203 */     this.bounded = false;
/*      */   }
/*      */   
/*      */   public void setBoundedness(boolean b) {
/*  207 */     this.bounded = b;
/*      */   }
/*      */   
/*      */   public boolean isBounded() {
/*  211 */     return this.bounded;
/*      */   }
/*      */   
/*      */   public void removeDeadTransition(int id) {
/*  215 */     this.deadTransitions.delete(id);
/*      */   }
/*      */   
/*      */   public boolean isExtendedPN() {
/*  219 */     return this.isExtendedPN;
/*      */   }
/*      */   
/*      */   public boolean containsInhibitorArcs() {
/*  223 */     return !this.transitionsInhibitor.isEmpty();
/*      */   }
/*      */   
/*      */   public boolean containsResetArcs() {
/*  227 */     return !this.transitionsReset.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean containsNonSandardArcs() {
/*  235 */     return containsNonStandardArcs();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsNonStandardArcs() {
/*  244 */     return (!this.transitionsReset.isEmpty() || !this.transitionsInhibitor.isEmpty());
/*      */   }
/*      */   
/*      */   public NodeSet getNotLiveTransitions() {
/*  248 */     return this.notLive;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int changesTokenOn(Place p, Transition t) {
/*  261 */     Marking post = t.getPost();
/*  262 */     Marking pre = t.getPre();
/*  263 */     int change = 0; int j;
/*  264 */     for (j = 0; j < post.size(); j++) {
/*  265 */       if (getPlaceById(post.getId(j)) == p) {
/*  266 */         change = post.getToken(j);
/*      */         break;
/*      */       } 
/*      */     } 
/*  270 */     for (j = 0; j < pre.size(); j++) {
/*  271 */       if (getPlaceById(pre.getId(j)) == p) {
/*  272 */         change -= pre.getToken(j);
/*      */         break;
/*      */       } 
/*      */     } 
/*  276 */     return change;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int takesTokenFrom(Place p, Transition t) {
/*  289 */     Marking pre = t.getPre();
/*  290 */     int change = 0;
/*      */     
/*  292 */     for (int j = 0; j < pre.size(); j++) {
/*  293 */       if (getPlaceById(pre.getId(j)) == p) {
/*  294 */         change += pre.getToken(j);
/*      */         break;
/*      */       } 
/*      */     } 
/*  298 */     return change;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int putsTokenOn(Place p, Transition t) {
/*  311 */     Marking post = t.getPost();
/*      */     
/*  313 */     int change = 0;
/*      */     
/*  315 */     for (int j = 0; j < post.size(); j++) {
/*  316 */       if (getPlaceById(post.getId(j)) == p) {
/*  317 */         change += post.getToken(j);
/*      */         break;
/*      */       } 
/*      */     } 
/*  321 */     return change;
/*      */   }
/*      */   
/*      */   public boolean isPrePostPlace(Transition t, Place p) {
/*  325 */     Marking post = t.getPost();
/*  326 */     Marking pre = t.getPre(); int j;
/*  327 */     for (j = 0; j < post.size() && 
/*  328 */       getPlaceById(post.getId(j)) != p; j++) {
/*      */ 
/*      */       
/*  331 */       if (j == post.size() - 1) {
/*  332 */         return false;
/*      */       }
/*      */     } 
/*  335 */     for (j = 0; j < pre.size(); j++) {
/*  336 */       if (getPlaceById(pre.getId(j)) == p) {
/*  337 */         return true;
/*      */       }
/*      */     } 
/*  340 */     return false;
/*      */   }
/*      */   
/*      */   public int extendTransition(Transition t) {
/*  344 */     int index = getIndexofTransition(t);
/*      */     
/*  346 */     TransitionExtended tex = new TransitionExtended(t.getName(), t.getId(), t.getPre(), t.getPost());
/*  347 */     replaceTransitionAt(index, tex);
/*  348 */     this.structure.replaceVertex(t.getIdentifier(), tex);
/*  349 */     return index;
/*      */   }
/*      */   
/*      */   public void replaceTransitionAt(int index, Transition toReplace) {
/*  353 */     this.trans.remove(index);
/*  354 */     this.trans.add(index, toReplace);
/*      */   }
/*      */   
/*      */   public void setName(String name) {
/*  358 */     this.netName = name;
/*      */   }
/*      */   
/*      */   public String getName() {
/*  362 */     return this.netName;
/*      */   }
/*      */   
/*      */   public Marking getM0() {
/*  366 */     return getM0Places();
/*      */   }
/*      */   
/*      */   public Marking getM0Places() {
/*  370 */     return this.m0Places;
/*      */   }
/*      */   
/*      */   public State getM0State() {
/*  374 */     return this.m0State;
/*      */   }
/*      */   
/*      */   public void setM0(List<Integer> placesVector) {
/*  378 */     this.placesM0 = new SortedElementsDynamic(true);
/*  379 */     this.placesM0.name = "PlaceTransitionNet placesM0 ";
/*      */ 
/*      */     
/*  382 */     for (int i = 0; i < placesVector.size(); i += 2) {
/*  383 */       if (((Integer)placesVector.get(i + 1)).intValue() > 0) {
/*  384 */         this.placesM0.addPlace(((Integer)placesVector.get(i)).intValue(), ((Integer)placesVector
/*  385 */             .get(i + 1)).intValue());
/*      */       }
/*      */       
/*  388 */       Place p = getPlaceById(((Integer)placesVector.get(i)).intValue());
/*  389 */       p.setToken(((Integer)placesVector.get(i + 1)).intValue());
/*      */     } 
/*      */     try {
/*  392 */       createM0();
/*  393 */     } catch (SafetyException e) {
/*  394 */       LOG.error(e.getMessage(), e);
/*  395 */     } catch (ExceedsByteException e) {
/*  396 */       LOG.error(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public State getTimedM0State(byte clockHandling, byte netType, byte timeDesignation) {
/*  401 */     if (LOG.isDebugEnabled()) {
/*  402 */       LOG.debug("PlaceTransitionNet.getTimedM0State() called.");
/*      */     }
/*      */     
/*  405 */     State s = null;
/*  406 */     SortedElementsDynamic transitionsM0 = new SortedElementsDynamic(false);
/*  407 */     transitionsM0.name = " PlaceTransitionNet getTimedM0State transitionsM0";
/*  408 */     if (LOG.isDebugEnabled()) {
/*  409 */       LOG.debug("isTimedNet()" + isTimedNet() + " TIMED_NET_TYPE ==" + netType);
/*      */     }
/*      */     
/*      */     try {
/*  413 */       if (isTimedNet() && netType != 4) {
/*  414 */         s = new TimedState(clockHandling, netType, timeDesignation);
/*  415 */         orderTransitions(new OrderTransitionByName(this));
/*  416 */         s.setPlaceMarking(this.placesM0.toArray());
/*  417 */         if (clockHandling == 5 && netType == 3) {
/*  418 */           if (LOG.isDebugEnabled()) {
/*  419 */             LOG.debug("getTimedM0State(): clockHandling Duration");
/*      */           }
/*      */         } else {
/*  422 */           for (Transition o : this.trans) {
/*  423 */             Transition t = o;
/*  424 */             if (t.pre.isSubSet(this.m0Places)) {
/*  425 */               transitionsM0.addPlace(t.getId(), 1);
/*      */             }
/*      */           } 
/*      */         } 
/*  429 */         s.setTransitionMarking(transitionsM0.toArray());
/*  430 */         return s;
/*      */       } 
/*  432 */       return null;
/*      */     }
/*  434 */     catch (Exception e) {
/*  435 */       LOG.error(e.getMessage(), e);
/*  436 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Marking getNonTimedM0State() {
/*      */     try {
/*  442 */       Marking s = new SortedElementsDynamic(true);
/*  443 */       s.name += "PlaceTransitionNet nonTimedM0State";
/*  444 */       s = this.placesM0.toArray();
/*  445 */       s.setPlaceMarking(this.placesM0.toArray());
/*  446 */       s.setTransitionMarking(new SortedElementsDynamic(false));
/*  447 */       return s;
/*  448 */     } catch (Exception e) {
/*  449 */       LOG.error(e.getMessage(), e);
/*  450 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void createM0() throws SafetyException, ExceedsByteException {
/*  455 */     this.transitionsM0 = new SortedElementsDynamic(false);
/*  456 */     this.transitionsM0.name = "PlaceTransitionNet transitionsM0";
/*  457 */     this.m0Places = this.placesM0.toArray();
/*  458 */     this.m0State = this.placesM0.toArray();
/*  459 */     this.m0State.setTransitionMarking(this.transitionsM0.toArray());
/*      */   }
/*      */   
/*      */   public NodeList getNL() {
/*  463 */     return this.nl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int edges() {
/*  472 */     return this.structure.getNumberOfEdges();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int places() {
/*  481 */     return this.places.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int transitions() {
/*  490 */     return this.trans.size();
/*      */   }
/*      */   
/*      */   public List<Place> getPlaces() {
/*  494 */     return this.places;
/*      */   }
/*      */   
/*      */   public List<Transition> getTransitions() {
/*  498 */     return this.trans;
/*      */   }
/*      */   
/*      */   public void addPlace(Place p) {
/*  502 */     this.places.add(p);
/*  503 */     this.placeNames.add(p.getName());
/*  504 */     this.placeIds.add(new Integer(p.getId()));
/*  505 */     this.structure.addVertex(p.getIdentifier(), p);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addEdge(PNNode from, PNNode to, int weight, int type) {
/*  510 */     if (type == MODIFIER_EDGE) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  518 */       if (weight != 1) {
/*  519 */         this.ord = false;
/*      */       }
/*      */       
/*  522 */       if (from instanceof Place) {
/*      */         
/*  524 */         int placeId = ((Place)from).getId();
/*  525 */         this.pf0.delete(UnsignedByte.unsign(placeId));
/*  526 */         this.ft0.delete(((Transition)to).getId());
/*  527 */         Transition t = (Transition)to;
/*      */         
/*  529 */         if (type == INHIBITOR_EDGE || type == READ_EDGE || type == EQUAL_EDGE || type == RESET_EDGE) {
/*      */           
/*  531 */           int index = 0;
/*  532 */           if (!(t instanceof TransitionExtended)) {
/*  533 */             this.isExtendedPN = true;
/*  534 */             index = extendTransition(t);
/*  535 */             String id = this.identifier.get(t);
/*  536 */             this.allNodes.remove(id);
/*  537 */             this.identifier.remove(t);
/*  538 */             t = getTransition((short)index);
/*      */             
/*  540 */             this.allNodes.put(id, t);
/*  541 */             this.identifier.put(t, id);
/*  542 */             to = t;
/*      */           } 
/*  544 */           if (type == INHIBITOR_EDGE) {
/*  545 */             this.transitionsInhibitor.insert(index);
/*  546 */             ((TransitionExtended)to).addInhibitorConnectedPlaceId(placeId, weight);
/*      */           } 
/*      */           
/*  549 */           if (type == READ_EDGE) {
/*  550 */             this.transitionsRead.insert(index);
/*  551 */             ((TransitionExtended)to).addReadConnectedPlaceId(placeId, weight);
/*      */ 
/*      */             
/*  554 */             ((Place)from).addPre((Transition)to, weight);
/*  555 */             this.structure.addEdge(to, from);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  560 */             this.fp0.delete(UnsignedByte.unsign(placeId));
/*  561 */             this.tf0.delete(((Transition)to).getId());
/*      */           } 
/*  563 */           if (type == RESET_EDGE) {
/*  564 */             this.transitionsReset.insert(index);
/*  565 */             ((TransitionExtended)to)
/*  566 */               .addResetConnectedPlaceId(placeId);
/*      */           } 
/*  568 */           if (type == EQUAL_EDGE) {
/*  569 */             this.transitionsInhibitor.insert(index);
/*  570 */             Out.println("equal edge from " + from.getName() + " to " + to
/*  571 */                 .getName() + " with weight " + weight);
/*      */             
/*  573 */             Out.println("will be simulated by an read edge with weight " + weight + " and an inihibitor edge with weight " + (weight + 1));
/*      */ 
/*      */ 
/*      */             
/*  577 */             ((TransitionExtended)to).addInhibitorConnectedPlaceId(placeId, weight + 1);
/*      */             
/*  579 */             ((TransitionExtended)to).addReadConnectedPlaceId(placeId, weight);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  584 */           t.addPrePlace(placeId, weight);
/*      */         } 
/*      */         
/*  587 */         ((Place)from).addPost((Transition)to, weight);
/*      */         
/*  589 */         if (this.homogenous) {
/*  590 */           if (this.hom.get(from) == null) {
/*  591 */             this.hom.put(from, new Integer(weight));
/*      */           }
/*  593 */           else if (((Integer)this.hom.get(from)).intValue() != weight) {
/*  594 */             Out.println("not HOM :" + from.getName());
/*  595 */             this.homogenous = false;
/*      */           }
/*      */         
/*      */         }
/*  599 */       } else if (to instanceof Place) {
/*      */         
/*  601 */         int placeId = ((Place)to).getId();
/*      */         
/*  603 */         ((Transition)from).addPostPlace(placeId, weight);
/*      */         
/*  605 */         ((Place)to).addPre((Transition)from, weight);
/*  606 */         this.fp0.delete(UnsignedByte.unsign(placeId));
/*  607 */         this.tf0.delete(((Transition)from).getId());
/*      */       } 
/*  609 */       this.structure.addEdge(from, to);
/*  610 */     } catch (Exception e) {
/*  611 */       LOG.error(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void orderTransitions(OrderingFunction of) {
/*  616 */     if (LOG.isDebugEnabled()) {
/*  617 */       LOG.debug("PlaceTransitionNet.orderTransitions() called with " + of.getClass().getName());
/*      */     }
/*      */     
/*  620 */     Vector<Transition> newTrans = new Vector<>(transitions());
/*  621 */     Vector<Integer> translationTable = of.getTranslationTable();
/*  622 */     if (translationTable == null || translationTable.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/*  626 */     for (int index = 0; index < translationTable.size(); index++) {
/*      */       
/*  628 */       int oldIndex = ((Integer)translationTable.get(index)).intValue();
/*  629 */       Transition t = this.trans.get(oldIndex);
/*  630 */       t.setId((short)index);
/*  631 */       newTrans.add(t);
/*      */     } 
/*      */     
/*  634 */     for (Place p : this.places) {
/*  635 */       p.updatePrePost(translationTable);
/*      */     }
/*      */ 
/*      */     
/*  639 */     this.trans = newTrans;
/*  640 */     for (Transition o : this.trans) {
/*  641 */       ((Transition)o).orderConflicts();
/*      */     }
/*  643 */     this.transitionIds.clear();
/*  644 */     this.transitionNames.clear();
/*  645 */     for (Transition t : this.trans) {
/*  646 */       this.transitionIds.add(new Integer(t.getId()));
/*  647 */       this.transitionNames.add(t.getName());
/*      */     } 
/*      */   }
/*      */   
/*      */   public void orderPlaces(OrderingFunction of) {
/*  652 */     if (LOG.isDebugEnabled()) {
/*  653 */       LOG.debug("PlaceTransitionNet.orderPlaces() called with " + of.getClass().getName());
/*      */     }
/*      */     
/*  656 */     Vector<Place> newPlaces = new Vector<>(places());
/*  657 */     Vector<Integer> translationTable = of.getTranslationTable();
/*  658 */     if (translationTable == null || translationTable.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/*  662 */     for (int index = 0; index < translationTable.size(); index++) {
/*      */       
/*  664 */       int oldIndex = ((Integer)translationTable.get(index)).intValue();
/*  665 */       Place p = this.places.get(oldIndex);
/*  666 */       p.setId((byte)UnsignedByte.sign(index));
/*  667 */       newPlaces.add(p);
/*      */     } 
/*  669 */     for (Iterator<Transition> it = this.trans.iterator(); it.hasNext(); ) {
/*  670 */       PNNode p = it.next();
/*  671 */       p.updatePrePost(translationTable);
/*      */     } 
/*      */     try {
/*  674 */       this.m0Places = this.m0Places.translate(translationTable);
/*  675 */     } catch (Exception e) {
/*  676 */       LOG.error(e.getMessage(), e);
/*      */     } 
/*      */     
/*  679 */     this.placesM0 = new SortedElementsDynamic(true);
/*  680 */     this.placesM0.name += " PlaceTransitionNet placesM0";
/*  681 */     for (int i = 0; i < this.m0Places.size(); i++) {
/*  682 */       this.placesM0.addPlace(this.m0Places.getId(i), this.m0Places.getToken(i));
/*      */     }
/*      */     
/*  685 */     this.places = newPlaces;
/*  686 */     this.placeIds.clear();
/*  687 */     this.placeNames.clear();
/*  688 */     for (Place p : this.places) {
/*  689 */       this.placeIds.add(new Integer(p.getId()));
/*  690 */       this.placeNames.add(p.getName());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTransition(Transition t) {
/*  705 */     int i = 0;
/*  706 */     while (i < this.translationTableTransitions.size() && ((Transition)this.trans
/*  707 */       .get(((Integer)this.translationTableTransitions.get(i)).shortValue())).getName()
/*  708 */       .compareTo(t.getName()) < 0) {
/*  709 */       i++;
/*      */     }
/*  711 */     this.translationTableTransitions.add(i, new Integer(t.getId()));
/*  712 */     this.trans.add(t);
/*  713 */     this.transitionNames.add(t.getName());
/*  714 */     this.transitionIds.add(new Integer(t.getId()));
/*      */     
/*  716 */     this.structure.addVertex(t.getIdentifier(), t);
/*      */   }
/*      */   
/*      */   public Transition translateTransition(int i) {
/*  720 */     return this.trans.get(((Integer)this.translationTableTransitions.get(i)).intValue());
/*      */   }
/*      */   
/*      */   public int translateBackTransition(int i) {
/*  724 */     for (int j = 0; j < this.translationTableTransitions.size(); j++) {
/*      */ 
/*      */       
/*  727 */       if (((Integer)this.translationTableTransitions.get(j)).equals(Integer.valueOf(i))) {
/*  728 */         return j;
/*      */       }
/*      */     } 
/*  731 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lookUpPlaceIDbyName(String name) {
/*  738 */     for (int i = 0; i < this.placeNames.size(); i++) {
/*  739 */       if (((String)this.placeNames.get(i)).equals(name)) {
/*  740 */         return ((Integer)this.placeIds.get(i)).intValue();
/*      */       }
/*      */     } 
/*  743 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lookUpTransitionIndexbyName(String name) {
/*  750 */     for (int i = 0; i < this.transitionNames.size(); i++) {
/*  751 */       if (((String)this.transitionNames.get(i)).equals(name)) {
/*  752 */         return ((Integer)this.transitionIds.get(i)).intValue();
/*      */       }
/*      */     } 
/*  755 */     return -1;
/*      */   }
/*      */   
/*      */   public int getIndexofTransition(Transition t) {
/*  759 */     for (int i = 0; i < this.trans.size(); i++) {
/*  760 */       if (t.equals(this.trans.get(i))) {
/*  761 */         return i;
/*      */       }
/*      */     } 
/*  764 */     return -1;
/*      */   }
/*      */   
/*      */   public int getIndexofPlace(Place p) {
/*  768 */     for (int i = 0; i < this.places.size(); i++) {
/*  769 */       if (p.equals(this.places.get(i))) {
/*  770 */         return i;
/*      */       }
/*      */     } 
/*  773 */     return -1;
/*      */   }
/*      */   
/*      */   public int lookUpPlaceIndexbyName(String name) {
/*  777 */     for (Place p : this.places) {
/*  778 */       if (p.getName().equals(name)) {
/*  779 */         return this.places.indexOf(p);
/*      */       }
/*      */     } 
/*  782 */     return -1;
/*      */   }
/*      */   
/*      */   public short lookUpTransitionID(String name) {
/*  786 */     for (short i = 0; i < this.trans.size(); i = (short)(i + 1)) {
/*  787 */       if (((Transition)this.trans.get(i)).getName().equals(name)) {
/*  788 */         return i;
/*      */       }
/*      */     } 
/*      */     
/*  792 */     return -1;
/*      */   }
/*      */   
/*      */   public String[] placesNamesToArray() {
/*  796 */     return toNamesArray((List)this.places);
/*      */   }
/*      */   
/*      */   public String[] transitionsNamesToArray() {
/*  800 */     return toNamesArray((List)this.trans);
/*      */   }
/*      */   
/*      */   private String[] toNamesArray(List<? extends PNNode> v) {
/*  804 */     String[] res = new String[v.size()];
/*  805 */     int i = 0;
/*  806 */     for (Iterator<? extends PNNode> it = v.iterator(); it.hasNext(); ) {
/*  807 */       PNNode n = it.next();
/*  808 */       res[i++] = n.getName();
/*      */     } 
/*  810 */     return res;
/*      */   }
/*      */   
/*      */   public synchronized Place getPlaceById(int id) {
/*  814 */     Place ret = null;
/*  815 */     for (Place o : this.places) {
/*  816 */       Place p = o;
/*  817 */       if (p.getId() == id) {
/*  818 */         ret = p;
/*      */         break;
/*      */       } 
/*      */     } 
/*  822 */     return ret;
/*      */   }
/*      */   
/*      */   public synchronized Place getPlaceByOrigId(int id) {
/*  826 */     Place ret = null;
/*  827 */     for (Place o : this.places) {
/*  828 */       Place p = o;
/*  829 */       if (p.getOrgId() == id) {
/*  830 */         ret = p;
/*      */         break;
/*      */       } 
/*      */     } 
/*  834 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Place getPlaceByIndex(int index) {
/*  843 */     return this.places.get(index);
/*      */   }
/*      */   
/*      */   public synchronized Transition getTransition(int index) {
/*  847 */     if (index == 32767) {
/*  848 */       return null;
/*      */     }
/*  850 */     if (index < 0) {
/*  851 */       return null;
/*      */     }
/*  853 */     return this.trans.get(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public synchronized Transition getTransitionById(short id) {
/*  868 */     if (id < this.trans.size() && ((Transition)this.trans.get(id)).getId() == id) {
/*  869 */       return this.trans.get(id);
/*      */     }
/*      */     
/*  872 */     for (Transition t : this.trans) {
/*  873 */       if (t.getId() == id) {
/*  874 */         return t;
/*      */       }
/*      */     } 
/*  877 */     return null;
/*      */   }
/*      */   
/*      */   private void visit(Vector<Integer> v, PNNode n, int id, boolean place) {
/*  881 */     if (this.visited.contains(n)) {
/*      */       return;
/*      */     }
/*  884 */     this.visited.add(n);
/*  885 */     if (!this.inLin.contains(n) && n instanceof Place == place) {
/*  886 */       v.add(new Integer(id));
/*  887 */       this.inLin.add(n);
/*      */     } 
/*  889 */     Vector<Integer> post = new Vector<>();
/*      */     Iterator<Integer> it;
/*  891 */     for (it = n.postNodes().iterator(); it.hasNext(); ) {
/*  892 */       PNNode next; Integer i = it.next();
/*      */       
/*  894 */       PNNode next2 = null;
/*  895 */       if (n instanceof Place) {
/*  896 */         next = getTransition(i.shortValue());
/*      */       } else {
/*  898 */         next = getPlaceByIndex(i.intValue());
/*      */       } 
/*  900 */       for (Iterator<Integer> it2 = next.postNodes().iterator(); it2.hasNext(); ) {
/*  901 */         Integer i2 = it2.next();
/*  902 */         if (n instanceof Place) {
/*  903 */           next2 = getPlaceByIndex(i2.intValue());
/*      */         } else {
/*  905 */           next2 = getTransition(i2.shortValue());
/*      */         } 
/*  907 */         NodeSet ns = next2.postNodes();
/*  908 */         ns.intersection(n.preNodes());
/*  909 */         if (ns.size() > 0) {
/*  910 */           post.insertElementAt(i2, 0); continue;
/*      */         } 
/*  912 */         post.add(i2);
/*      */       } 
/*      */     } 
/*      */     
/*  916 */     for (it = post.iterator(); it.hasNext(); ) {
/*  917 */       Integer i = it.next();
/*  918 */       if (n instanceof Place) {
/*  919 */         visit(v, getPlaceByIndex(i.intValue()), i.intValue(), place); continue;
/*      */       } 
/*  921 */       visit(v, getTransition(i.shortValue()), i.shortValue(), place);
/*      */     } 
/*      */   }
/*      */   
/*      */   public Vector<Integer> dfsLin(boolean place, int first) {
/*      */     PNNode n;
/*  927 */     Vector<Integer> v = new Vector<>();
/*  928 */     int size = places();
/*  929 */     if (!place) {
/*  930 */       size = transitions();
/*      */     }
/*      */     
/*  933 */     if (place) {
/*  934 */       n = this.places.get(first);
/*      */     } else {
/*  936 */       n = this.trans.get(first);
/*      */     } 
/*      */     
/*  939 */     visit(v, n, first, place);
/*  940 */     while (this.visited.size() < size) {
/*  941 */       for (int i = 0; i < size; i++) {
/*  942 */         if (place) {
/*  943 */           n = this.places.get(i);
/*      */         } else {
/*  945 */           n = this.trans.get(i);
/*      */         } 
/*  947 */         if (!this.visited.contains(n)) {
/*  948 */           visit(v, n, i, place);
/*      */         }
/*      */       } 
/*      */     } 
/*  952 */     this.visited.clear();
/*  953 */     return v;
/*      */   }
/*      */   
/*      */   public Vector<Integer> bfsLin(boolean places) {
/*  957 */     Vector<Integer> v = new Vector<>();
/*  958 */     Vector<Integer> st = new Vector<>();
/*  959 */     int size = places();
/*  960 */     if (!places) {
/*  961 */       size = transitions();
/*      */     }
/*      */     
/*  964 */     while (this.visited.size() < size) {
/*  965 */       for (int i = 0; i < size; i++) {
/*  966 */         Integer index = new Integer(i);
/*  967 */         if (!this.visited.contains(index)) {
/*  968 */           st.add(index);
/*  969 */           v.add(index);
/*  970 */           int j = 0;
/*  971 */           while (!st.isEmpty()) {
/*      */             PNNode n;
/*  973 */             j = ((Integer)st.get(0)).intValue();
/*  974 */             st.remove(0);
/*  975 */             if (this.visited.contains(Integer.valueOf(j))) {
/*      */               continue;
/*      */             }
/*  978 */             this.visited.add(Integer.valueOf(j));
/*  979 */             if (places) {
/*  980 */               n = getPlaceByIndex(j);
/*  981 */               index = Integer.valueOf(j);
/*      */             } else {
/*  983 */               n = getTransition((short)j);
/*  984 */               index = Integer.valueOf(j);
/*      */             } 
/*  986 */             NodeSet ns = n.postNodes();
/*  987 */             for (Iterator<Integer> it = ns.iterator(); it.hasNext(); ) {
/*  988 */               PNNode p; index = it.next();
/*      */               
/*  990 */               if (!places) {
/*  991 */                 p = getPlaceByIndex(index.intValue());
/*      */               } else {
/*  993 */                 p = getTransition((short)index.intValue());
/*      */               } 
/*  995 */               for (Iterator<Integer> it2 = p.postNodes().iterator(); it2.hasNext(); ) {
/*  996 */                 int h = ((Integer)it2.next()).intValue();
/*  997 */                 if (!this.visited.contains(Integer.valueOf(h))) {
/*  998 */                   st.add(Integer.valueOf(h));
/*  999 */                   this.visited.add(Integer.valueOf(h));
/* 1000 */                   v.add(Integer.valueOf(h));
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1008 */     this.visited.clear();
/* 1009 */     return v;
/*      */   }
/*      */   
/*      */   public String toLabel(State m) {
/* 1013 */     StringBuffer buf = new StringBuffer();
/* 1014 */     buf.append("("); int i;
/* 1015 */     for (i = 0; i < m.getPlaceMarking().size(); i++) {
/* 1016 */       Marking placeMarking = m.getPlaceMarking();
/* 1017 */       Place p = getPlaceById(placeMarking.getId(i));
/* 1018 */       buf.append(p.getName());
/*      */       
/* 1020 */       if (m.getPlaceMarking().getToken(i) > 1) {
/* 1021 */         if (m.getPlaceMarking().getToken(i) == Integer.MAX_VALUE) {
/* 1022 */           buf.append(": oo");
/*      */         } else {
/* 1024 */           buf.append(": " + m.getPlaceMarking().getToken(i));
/*      */         } 
/*      */       }
/* 1027 */       if (i < m.getPlaceMarking().size() - 1) {
/* 1028 */         buf.append(" | ");
/*      */       }
/*      */     } 
/* 1031 */     buf.append(")");
/* 1032 */     if (m instanceof TimedState) {
/* 1033 */       buf.append("(");
/* 1034 */       for (i = 0; i < m.getTransitionMarking().size(); i++) {
/* 1035 */         buf.append(getTransition(
/* 1036 */               (byte)m.getTransitionMarking().getId(i)).getName());
/* 1037 */         if (m.clockHandling == 5 && m.timedNetType == 3) {
/*      */           
/* 1039 */           buf.append(": " + m.getTransitionMarking().getToken(i));
/*      */         } else {
/* 1041 */           buf.append(": " + (m
/* 1042 */               .getTransitionMarking().getToken(i) - 1));
/*      */         } 
/* 1044 */         if (i < m.getTransitionMarking().size() - 1) {
/* 1045 */           buf.append(" | ");
/*      */         }
/*      */       } 
/* 1048 */       buf.append(")");
/*      */     } 
/* 1050 */     return buf.toString();
/*      */   }
/*      */   
/*      */   public String toFilter(Marking m) {
/* 1054 */     StringBuffer buf = new StringBuffer();
/* 1055 */     buf.append("");
/* 1056 */     for (int i = 0; i < m.size(); i++) {
/* 1057 */       buf.append(getPlaceById((byte)m.getId(i)).getName());
/* 1058 */       if (m.getToken(i) > 1) {
/* 1059 */         if (m.getToken(i) == Integer.MAX_VALUE) {
/*      */           
/* 1061 */           buf.append(": oo");
/*      */         } else {
/* 1063 */           buf.append("== " + m.getToken(i));
/*      */         } 
/*      */       }
/* 1066 */       if (i < m.size() - 1) {
/* 1067 */         buf.append(" * ");
/*      */       }
/*      */     } 
/* 1070 */     buf.append("");
/* 1071 */     return buf.toString();
/*      */   }
/*      */   
/*      */   public String getSequence(Vector<Short> v) {
/* 1075 */     String ret = "";
/* 1076 */     for (Iterator<Short> it = v.iterator(); it.hasNext(); ) {
/* 1077 */       Transition t = this.trans.get(((Short)it.next()).shortValue());
/* 1078 */       ret = ret + t.getName() + " ";
/* 1079 */       if (it.hasNext()) {
/* 1080 */         ret = ret + "; ";
/*      */       }
/*      */     } 
/*      */     
/* 1084 */     return ret;
/*      */   }
/*      */   
/*      */   public void getSequence(Vector<Short> v, Vector<Short> ids) {
/* 1088 */     for (Iterator<Short> it = v.iterator(); it.hasNext(); ) {
/* 1089 */       Transition t = getTransition(((Short)it.next()).shortValue());
/* 1090 */       if (t != null) {
/*      */         
/* 1092 */         ids.add(Short.valueOf(t.getId())); continue;
/*      */       } 
/* 1094 */       System.out.println("null-transition");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void conflicts() {
/* 1100 */     for (Iterator<Transition> it = this.trans.iterator(); it.hasNext(); ) {
/* 1101 */       Transition t = it.next();
/* 1102 */       for (Iterator<Transition> it2 = this.trans.iterator(); it2.hasNext(); ) {
/* 1103 */         Transition t2 = it2.next();
/* 1104 */         if (t.getId() != t2.getId() && t.getPre().retains(t2.getPre())) {
/* 1105 */           t.addConflict(t2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public PlaceTransitionNet() {
/* 1112 */     this.ord = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1256 */     this.homogenous = true; selfReference = this; init(); } public PlaceTransitionNet(String name) { this.ord = true; this.homogenous = true; this.netName = name; selfReference = this; init(); }
/*      */   public Boolean isOrdinary() { return new Boolean(this.ord); }
/*      */   public Boolean isPure() { if (!this.transitionsRead.isEmpty()) return new Boolean(false);  for (Iterator<Transition> it = this.trans.iterator(); it.hasNext(); ) { Transition t = it.next(); NodeSet ns = t.preNodes(); ns.intersection(t.postNodes()); if (!ns.intersection(t.postNodes()).isEmpty()) return new Boolean(false);  }  return new Boolean(true); }
/* 1259 */   public Boolean isConservative() { int in = 0; int out = 0; for (Iterator<Transition> it = this.trans.iterator(); it.hasNext(); ) { in = 0; out = 0; Transition t = it.next(); int i; for (i = 0; i < t.getPre().size(); i++) in += t.getPre().getToken(i);  for (i = 0; i < t.getPost().size(); i++) out += t.getPost().getToken(i);  if (in != out) return new Boolean(false);  }  return new Boolean(true); } public boolean isFC() { for (Iterator<Place> it = this.places.iterator(); it.hasNext(); ) {
/* 1260 */       Place p = it.next();
/* 1261 */       NodeSet pf = p.postNodes();
/* 1262 */       if (pf.size() > 1) {
/* 1263 */         pf = pf.getPre();
/* 1264 */         if (pf.size() > 1) {
/* 1265 */           return false;
/*      */         }
/* 1267 */         int id = pf.first();
/* 1268 */         if (!getPlaceByIndex((short)id).equals(p)) {
/* 1269 */           return false;
/*      */         }
/*      */       } 
/*      */     } 
/* 1273 */     return true; }
/*      */   public Collection<Place> bndPlaces() { Collection<Place> c = new Vector<>(); for (Iterator<Place> it = this.places.iterator(); it.hasNext(); ) { Place p = it.next(); if (p.preNodes().isEmpty() || p.postNodes().isEmpty()) c.add(p);  }  return c; }
/*      */   public Collection<Transition> bndTransitions() { Collection<Transition> c = new Vector<>(); for (Iterator<Transition> it = this.trans.iterator(); it.hasNext(); ) { Transition t = it.next(); if (t.getPre().size() == 0 || t.getPost().size() == 0) c.add(t);  }  return c; }
/*      */   private void extractConnectComponents(HashSet<Set<PNNode>> components, HashSet<PNNode> remainingNodes) { if (remainingNodes.isEmpty()) return;  HashSet<PNNode> nodes = new HashSet<>(); HashSet<PNNode> considered = new HashSet<>(); HashSet<PNNode> finalNodes = new HashSet<>(); PNNode pnn = remainingNodes.iterator().next(); nodes.add(pnn); while (!nodes.isEmpty()) { Iterator<PNNode> it = nodes.iterator(); pnn = it.next(); finalNodes.add(pnn); if (pnn instanceof Place) { Iterator<Integer> it2; for (it2 = pnn.postNodes().iterator(); it2.hasNext(); ) { Transition t = getTransition((short)((Integer)it2.next()).intValue()); if (!finalNodes.contains(t)) nodes.add(t);  }  for (it2 = ((Place)pnn).preNodes().iterator(); it2.hasNext(); ) { Transition t = getTransition((short)((Integer)it2.next()).intValue()); if (!finalNodes.contains(t)) nodes.add(t);  }  }  if (pnn instanceof Transition) { Iterator<Integer> it2; for (it2 = pnn.postNodes().iterator(); it2.hasNext(); ) { Place p = getPlaceByIndex(((Integer)it2.next()).intValue()); if (!finalNodes.contains(p)) nodes.add(p);  }  for (it2 = pnn.preNodes().iterator(); it2.hasNext(); ) { Place p = getPlaceByIndex(((Integer)it2.next()).intValue()); if (!finalNodes.contains(p)) nodes.add(p);  }  }  nodes.remove(pnn); considered.add(pnn); }  remainingNodes.removeAll(considered); components.add(finalNodes); extractConnectComponents(components, remainingNodes); }
/* 1277 */   public HashSet<Set<PNNode>> isConnected() { HashSet<PNNode> nodes = new HashSet<>(); HashSet<Set<PNNode>> components = new HashSet<>(); int i; for (i = 0; i < this.places.size(); i++) nodes.add(this.places.get(i));  for (i = 0; i < this.trans.size(); i++) nodes.add(this.trans.get(i));  extractConnectComponents(components, nodes); return components; } public boolean hasNBM() { boolean ret = true;
/* 1278 */     for (Iterator<Place> it = this.places.iterator(); it.hasNext(); ) {
/* 1279 */       Place p = it.next();
/*      */       
/* 1281 */       if (!p.hasNBM()) {
/* 1282 */         return false;
/*      */       }
/*      */     } 
/* 1285 */     return ret; }
/*      */ 
/*      */   
/*      */   public int determineNetClass() {
/* 1289 */     boolean fc = true;
/* 1290 */     boolean efc = true;
/* 1291 */     boolean es = true; Iterator<Place> it;
/* 1292 */     label42: for (it = this.places.iterator(); it.hasNext(); ) {
/* 1293 */       Place p = it.next();
/* 1294 */       NodeSet pf = p.postNodes();
/* 1295 */       Place p2 = null;
/* 1296 */       for (Iterator<Integer> it2 = pf.iterator(); it2.hasNext(); ) {
/* 1297 */         Transition t = getTransition((short)((Integer)it2.next()).intValue());
/*      */         
/* 1299 */         for (Iterator<Integer> it3 = pf.iterator(); it3.hasNext(); ) {
/* 1300 */           Transition t2 = getTransition((short)((Integer)it3.next()).intValue());
/* 1301 */           if (t.getId() == t2.getId()) {
/*      */             continue;
/*      */           }
/* 1304 */           if (fc && t.getPre().size() == 1 && t2.getPre().size() == 1) {
/*      */             continue;
/*      */           }
/* 1307 */           fc = false;
/*      */           
/* 1309 */           if (efc && t.preNodes().equals(t2.preNodes())) {
/*      */             continue;
/*      */           }
/* 1312 */           efc = false;
/*      */           
/* 1314 */           if (es) {
/* 1315 */             for (Iterator<Integer> it4 = t2.preNodes().iterator(); it4.hasNext(); ) {
/* 1316 */               p2 = getPlaceByIndex(((Integer)it4.next()).intValue());
/* 1317 */               if (p2.postNodes().subSet(p.postNodes()) || p
/* 1318 */                 .postNodes().subSet(p2.postNodes()))
/*      */                 continue; 
/* 1320 */               es = false;
/*      */               
/*      */               break label42;
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1329 */     if (fc) {
/* 1330 */       return 2;
/*      */     }
/* 1332 */     if (efc) {
/* 1333 */       return 3;
/*      */     }
/* 1335 */     if (es) {
/* 1336 */       return 4;
/*      */     }
/* 1338 */     return 5;
/*      */   }
/*      */ 
/*      */   
/*      */   public NodeSet getDeadTransitions() {
/* 1343 */     return this.deadTransitions;
/*      */   }
/*      */   
/*      */   public NodeSet getTransitionsRead() {
/* 1347 */     return this.transitionsRead;
/*      */   }
/*      */   
/*      */   public NodeSet getTransitionsInhibitor() {
/* 1351 */     return this.transitionsInhibitor;
/*      */   }
/*      */   
/*      */   public NodeSet getTransitionsReset() {
/* 1355 */     return this.transitionsReset;
/*      */   }
/*      */   
/*      */   public NodeSet getFT0() {
/* 1359 */     return this.ft0;
/*      */   }
/*      */   
/*      */   public void setFT0(NodeSet _ft0) {
/* 1363 */     this.ft0 = _ft0;
/*      */   }
/*      */   
/*      */   public NodeSet getTF0() {
/* 1367 */     return this.tf0;
/*      */   }
/*      */   
/*      */   public void setTF0(NodeSet _tf0) {
/* 1371 */     this.tf0 = _tf0;
/*      */   }
/*      */   
/*      */   public NodeSet getPF0() {
/* 1375 */     return this.pf0;
/*      */   }
/*      */   
/*      */   public void setPF0(NodeSet _pf0) {
/* 1379 */     this.pf0 = _pf0;
/*      */   }
/*      */   
/*      */   public NodeSet getFP0() {
/* 1383 */     return this.fp0;
/*      */   }
/*      */   
/*      */   public void setFP0(NodeSet _fp0) {
/* 1387 */     this.fp0 = _fp0;
/*      */   }
/*      */   
/*      */   public boolean isStronglyConnected() {
/* 1391 */     return this.structure.scc();
/*      */   }
/*      */   
/*      */   public boolean isSCF() {
/* 1395 */     for (Iterator<Transition> it = getTransitions().iterator(); it.hasNext(); ) {
/* 1396 */       Transition t = it.next();
/* 1397 */       if (!t.getConflicts().isEmpty()) {
/* 1398 */         return (new Boolean(false)).booleanValue();
/*      */       }
/*      */     } 
/* 1401 */     return (new Boolean(true)).booleanValue();
/*      */   }
/*      */   
/*      */   public boolean isSM() {
/* 1405 */     for (Iterator<Transition> it = this.trans.iterator(); it.hasNext(); ) {
/* 1406 */       Transition t = it.next();
/* 1407 */       if (t.postNodes().size() > 1 || t.preNodes().size() > 1) {
/* 1408 */         return false;
/*      */       }
/*      */     } 
/* 1411 */     return true;
/*      */   }
/*      */   
/*      */   public boolean isMG() {
/* 1415 */     for (Iterator<Place> it = this.places.iterator(); it.hasNext(); ) {
/* 1416 */       Place p = it.next();
/* 1417 */       if (p.postNodes().size() > 1 || p.preNodes().size() > 1) {
/* 1418 */         return false;
/*      */       }
/*      */     } 
/* 1421 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1426 */     String retString = "";
/* 1427 */     return retString;
/*      */   }
/*      */   
/*      */   public void resetPN() {
/* 1431 */     this
/* 1432 */       .deadTransitions = new TransitionSet(getTransitions().size(), getTransitions().size());
/* 1433 */     this.notLive = new TransitionSet(getTransitions().size());
/* 1434 */     for (Iterator<Transition> it = getTransitions().iterator(); it.hasNext(); ) {
/* 1435 */       Transition t = it.next();
/* 1436 */       t.szk().removeAllElements();
/*      */     } 
/* 1438 */     this.boundednessChecked = false;
/* 1439 */     this.bounded = true;
/*      */   }
/*      */   
/*      */   public TransitionSet getEmptyTransitionSet() {
/* 1443 */     return new TransitionSet(this.trans.size());
/*      */   }
/*      */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/PlaceTransitionNet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */