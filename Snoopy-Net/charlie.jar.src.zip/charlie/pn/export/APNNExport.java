/*     */ package charlie.pn.export;
/*     */ 
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.Place;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Transition;
/*     */ import charlie.pn.TransitionSet;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ public class APNNExport
/*     */   extends Export
/*     */ {
/*     */   private static final String PLACE = "\\place";
/*     */   private static final String TRANS = "\\transition";
/*     */   private static final String ARC = "\\arc";
/*     */   private static final String WEIGHT = "\\weight";
/*     */   private static final String INIT = "\\init";
/*     */   private static final String FROM = "\\from";
/*     */   private static final String TO = "\\to";
/*     */   private static final String LIKE = "\\like";
/*     */   private static final String NAME = "\\name";
/*     */   private static final String TYPE = "\\type";
/*     */   private static final String CAP = "\\capacity";
/*  29 */   private static String lastLine = new String("\\endnet");
/*     */   
/*  31 */   PlaceTransitionNet pn = null;
/*  32 */   File file = null;
/*     */   
/*     */   public APNNExport(PlaceTransitionNet pn, File file) {
/*  35 */     this.pn = pn;
/*  36 */     this.file = file;
/*     */   }
/*     */   
/*     */   public void doExport() {
/*  40 */     writeNet(this.pn, this.file);
/*     */   }
/*     */   
/*     */   public void writeNet(PlaceTransitionNet pn, File file) {
/*  44 */     StringBuffer buf = new StringBuffer();
/*  45 */     writeBeginning(pn, buf);
/*  46 */     buf.append("\n");
/*  47 */     writePlaces(pn, buf);
/*  48 */     buf.append("\n");
/*  49 */     writeTransitions(pn, buf);
/*  50 */     buf.append("\n");
/*  51 */     writeArcs(pn, buf);
/*  52 */     buf.append("\n");
/*  53 */     writeEnding(pn, buf);
/*     */ 
/*     */     
/*     */     try {
/*  57 */       FileWriter writer = new FileWriter(file);
/*  58 */       writer.write(buf.toString(), 0, buf.toString().length());
/*  59 */       writer.flush();
/*  60 */       writer.close();
/*  61 */     } catch (IOException ex) {
/*  62 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeBeginning(PlaceTransitionNet pn, StringBuffer buf) {
/*  67 */     buf.append("\n\\beginnet{" + pn.getName() + "}\n");
/*     */   }
/*     */   
/*     */   private void writePlaces(PlaceTransitionNet pn, StringBuffer buf) {
/*  71 */     List<Place> places = pn.getPlaces();
/*  72 */     Marking m = pn.getM0();
/*     */     
/*  74 */     for (Place p : places) {
/*     */       
/*  76 */       Integer token = null;
/*     */       int i;
/*  78 */       for (i = 0; i < m.size(); i++) {
/*  79 */         if (p.getId() == m.getId(i))
/*  80 */           token = new Integer(m.getToken(i)); 
/*     */       } 
/*  82 */       if (token == null)
/*  83 */         token = new Integer(0); 
/*  84 */       if (p == null) System.out.printf("I= %d p == null\n", new Object[] { Integer.valueOf(i) }); 
/*  85 */       writePlace(p, token, buf);
/*  86 */       buf.append("\n");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writePlace(Place p, Integer token, StringBuffer buf) {
/*  91 */     buf.append("\\place");
/*  92 */     buf.append("{");
/*  93 */     buf.append("P_" + Integer.toString(p.getOrgId()));
/*  94 */     buf.append("}");
/*  95 */     buf.append("{\\name{");
/*  96 */     buf.append(p.getName());
/*  97 */     buf.append("}\\capacity{");
/*  98 */     buf.append(Integer.toString(p.getCapacity()));
/*  99 */     buf.append("}\\init{");
/*     */     
/* 101 */     buf.append(Integer.toString(token.intValue()));
/* 102 */     buf.append("}}");
/* 103 */     buf.append("");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeTransitions(PlaceTransitionNet pn, StringBuffer buf) {
/* 108 */     List<Transition> transitions = pn.getTransitions();
/* 109 */     for (int i = 0; i < transitions.size(); i++) {
/* 110 */       writeTransition(transitions.get(i), buf);
/* 111 */       buf.append("\n");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeTransition(Transition t, StringBuffer buf) {
/* 116 */     buf.append("\\transition");
/* 117 */     buf.append("{");
/* 118 */     buf.append("T_" + Short.toString(t.getId()));
/* 119 */     buf.append("}");
/* 120 */     buf.append("{\\name{");
/* 121 */     buf.append(t.getName());
/* 122 */     buf.append("}}");
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeArcs(PlaceTransitionNet pn, StringBuffer buf) {
/* 127 */     int arcCount = 0;
/*     */     
/* 129 */     List<Place> places = pn.getPlaces();
/* 130 */     for (int i = 0; i < pn.places(); i++) {
/* 131 */       Place p = places.get(i);
/* 132 */       TransitionSet preTransitions = (TransitionSet)p.preNodes();
/* 133 */       TransitionSet postTransitions = (TransitionSet)p.postNodes();
/*     */       
/* 135 */       Iterator<Integer> it = preTransitions.iterator();
/* 136 */       while (it.hasNext()) {
/* 137 */         Transition t = (Transition)preTransitions.getNode(((Integer)it.next()).intValue(), true);
/*     */         
/* 139 */         buf.append("\\arc{A_" + Integer.toString(arcCount++) + "}{" + "\\from" + "{T_" + Short.toString(t.getId()) + "}");
/* 140 */         buf.append(" \\to{P_" + Integer.toString(p.getOrgId()) + "} " + "\\weight" + "{1} \\type{ordinary}}\n");
/*     */       } 
/* 142 */       it = postTransitions.iterator();
/*     */       
/* 144 */       while (it.hasNext()) {
/* 145 */         Transition t = (Transition)postTransitions.getNode(((Integer)it.next()).intValue(), true);
/* 146 */         buf.append("\\arc{A_" + Integer.toString(arcCount++) + "}{" + "\\from" + "{P_" + Integer.toString(p.getOrgId()) + "}");
/* 147 */         buf.append(" \\to{T_" + Short.toString(t.getId()) + "} " + "\\weight" + "{1} \\type{ordinary}}\n");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeEnding(PlaceTransitionNet pn, StringBuffer buf) {
/* 153 */     buf.append("\n" + lastLine + "\n");
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/export/APNNExport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */