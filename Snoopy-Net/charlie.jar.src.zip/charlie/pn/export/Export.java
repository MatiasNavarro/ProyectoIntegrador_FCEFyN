/*    */ package charlie.pn.export;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Export
/*    */ {
/*    */   public abstract void doExport();
/*    */   
/*    */   public static String rSpCh(String str) {
/* 11 */     StringBuffer sb = new StringBuffer();
/* 12 */     for (int i = 0; i < str.length(); i++) {
/* 13 */       if (Character.isLetterOrDigit(str.charAt(i))) {
/* 14 */         sb.append(str.charAt(i));
/*    */       } else {
/* 16 */         sb.append('_');
/*    */       } 
/*    */     } 
/* 19 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/export/Export.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */