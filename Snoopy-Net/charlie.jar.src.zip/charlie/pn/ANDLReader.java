/*    */ package charlie.pn;
/*    */ import java.io.InputStream;
/*    */ import org.antlr.runtime.ANTLRInputStream;
/*    */ import org.antlr.runtime.CharStream;
/*    */ import org.antlr.runtime.CommonTokenStream;
/*    */ import org.antlr.runtime.TokenSource;
/*    */ import org.antlr.runtime.TokenStream;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class ANDLReader extends PetriNetReader {
/* 12 */   private static final Log LOG = LogFactory.getLog(ANDLReader.class);
/*    */ 
/*    */   
/* 15 */   private int places = 0;
/* 16 */   private int transitions = 0;
/*    */   
/*    */   public ANDLReader() {
/* 19 */     PetriNetReaderFactory.registerReader(".andl", this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected int countPlaces() {
/*    */     try {
/* 25 */       InputStream fileInput = getInputStream(this.file);
/* 26 */       ANTLRInputStream input = new ANTLRInputStream(fileInput);
/*    */       
/* 28 */       ANDLLexer lexer = new ANDLLexer((CharStream)input);
/* 29 */       CommonTokenStream tokens = new CommonTokenStream((TokenSource)lexer);
/* 30 */       ANDLParser parser = new ANDLParser((TokenStream)tokens);
/*    */ 
/*    */       
/* 33 */       parser.setMode(ANDLParser.Mode.COUNT);
/*    */       
/* 35 */       parser.start();
/* 36 */       this.places = parser.nrPlaces;
/* 37 */       System.out.println("nrPlaces " + parser.nrPlaces);
/* 38 */     } catch (Exception e) {
/* 39 */       LOG.fatal(e.getMessage(), e);
/*    */     } 
/* 41 */     return this.places;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int countTransitions() {
/*    */     try {
/* 47 */       InputStream fileInput = getInputStream(this.file);
/* 48 */       ANTLRInputStream input = new ANTLRInputStream(fileInput);
/*    */       
/* 50 */       ANDLLexer lexer = new ANDLLexer((CharStream)input);
/* 51 */       CommonTokenStream tokens = new CommonTokenStream((TokenSource)lexer);
/* 52 */       ANDLParser parser = new ANDLParser((TokenStream)tokens);
/* 53 */       parser.setConstantRegistry(this.constantRegistry);
/* 54 */       parser.setMode(ANDLParser.Mode.COUNT);
/*    */       
/* 56 */       parser.start();
/* 57 */       this.transitions = parser.nrTransitions;
/* 58 */       System.out.println("nrTransitions " + parser.nrTransitions);
/*    */     }
/* 60 */     catch (Exception e) {
/* 61 */       LOG.fatal(e.getMessage(), e);
/*    */     } 
/*    */     
/* 64 */     return this.transitions;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void readNet() throws Exception {
/* 71 */     InputStream fileInput = getInputStream(this.file);
/* 72 */     ANTLRInputStream input = new ANTLRInputStream(fileInput);
/* 73 */     ANDLLexer lexer = new ANDLLexer((CharStream)input);
/* 74 */     CommonTokenStream tokens = new CommonTokenStream((TokenSource)lexer);
/* 75 */     ANDLParser parser = new ANDLParser((TokenStream)tokens);
/* 76 */     parser.setMode(ANDLParser.Mode.PARSE);
/* 77 */     parser.setNet(this.pn);
/*    */     
/* 79 */     parser.setConstantRegistry(this.constantRegistry);
/* 80 */     parser.currentPlaceId = this.currentPlaceId;
/*    */     
/*    */     try {
/* 83 */       parser.start();
/* 84 */     } catch (Exception e) {
/* 85 */       LOG.fatal(e.getMessage(), e);
/*    */       
/* 87 */       throw new IllegalArgumentException("Parse Error! See the Log for more details! ");
/*    */     } 
/*    */     
/* 90 */     this.initialMarking.clear();
/* 91 */     this.initialMarking.addAll(parser.initialMarking);
/*    */     
/* 93 */     System.out.println("successfully parsed");
/*    */     
/* 95 */     initNet();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/ANDLReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */