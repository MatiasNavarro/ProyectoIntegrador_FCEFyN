/*    */ package charlie.pn;
/*    */ 
/*    */ import charlie.ds.BitSet;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class OrderTransitionByName
/*    */   implements OrderingFunction {
/*    */   public OrderTransitionByName(PlaceTransitionNet pn) {
/*  9 */     BitSet ready = new BitSet(pn.transitions());
/* 10 */     this.translationTable = new Vector(pn.transitions());
/* 11 */     String min = null;
/* 12 */     while (ready.size() < pn.transitions()) {
/* 13 */       int nextIndex = -1;
/* 14 */       min = null;
/* 15 */       for (int index = 0; index < pn.transitions(); index++) {
/* 16 */         if (!ready.member(index)) {
/* 17 */           PNNode n = pn.getTransition((short)index);
/* 18 */           if (min == null) {
/* 19 */             nextIndex = index;
/* 20 */             min = n.getName();
/*    */           
/*    */           }
/* 23 */           else if (n.getName().compareTo(min) < 0) {
/* 24 */             nextIndex = index;
/* 25 */             min = n.getName();
/*    */           } 
/*    */         } 
/*    */       } 
/*    */ 
/*    */       
/* 31 */       this.translationTable.add(new Integer(nextIndex));
/* 32 */       ready.insert(nextIndex);
/*    */     } 
/* 34 */     System.out.println(this.translationTable);
/*    */   }
/*    */   Vector translationTable;
/*    */   public Vector getTranslationTable() {
/* 38 */     return this.translationTable;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/OrderTransitionByName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */