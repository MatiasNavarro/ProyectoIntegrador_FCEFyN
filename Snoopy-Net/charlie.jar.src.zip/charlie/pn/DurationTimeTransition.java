package charlie.pn;

public interface DurationTimeTransition {
  boolean durationCanFire(State paramState);
  
  State durationFire(State paramState) throws SafetyException, ExceedsByteException;
  
  State produce(State paramState) throws SafetyException, ExceedsByteException;
  
  int getLft(byte paramByte1, byte paramByte2);
  
  int getEft(byte paramByte1, byte paramByte2);
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/DurationTimeTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */