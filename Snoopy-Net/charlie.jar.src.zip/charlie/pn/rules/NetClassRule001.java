/*     */ package charlie.pn.rules;
/*     */ 
/*     */ import charlie.pn.Place;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NetClassRule001
/*     */   extends ExtendedRule
/*     */ {
/*     */   public void initialize() {
/*  22 */     this.mainDescription = "MG & ORD : [SC & exactly one token <=> LIV & 1-B]";
/*     */     
/*  24 */     Rule r = new Rule();
/*     */     
/*  26 */     r.setDescription("LIV & 1-B => SC");
/*  27 */     r.addPreResult(1, 0, true);
/*  28 */     r.addPreResult(10, 0, true);
/*  29 */     r.addPreResult(24, 0, true);
/*  30 */     r.addPreResult(20, 0, true);
/*  31 */     r.addPostResult(11, true);
/*  32 */     addRule(r);
/*     */ 
/*     */     
/*  35 */     r = new Rule();
/*     */     
/*  37 */     r.setDescription("SC => LIV & 1-B");
/*  38 */     r.addPreResult(1, 0, true);
/*  39 */     r.addPreResult(11, 0, true);
/*  40 */     r.addPostResult(24, true);
/*  41 */     r.addPostResult(20, true);
/*  42 */     addRule(r);
/*     */ 
/*     */     
/*  45 */     r = new Rule();
/*     */     
/*  47 */     r.setDescription("!LIV & 1-B => !SC");
/*  48 */     r.addPreResult(1, 0, true);
/*  49 */     r.addPreResult(10, 0, true);
/*  50 */     r.addPreResult(24, 0, false);
/*  51 */     r.addPreResult(20, 0, true);
/*  52 */     r.addPostResult(11, false);
/*  53 */     addRule(r);
/*     */ 
/*     */     
/*  56 */     r = new Rule();
/*     */     
/*  58 */     r.setDescription("LIV & !1-B => !SC");
/*  59 */     r.addPreResult(1, 0, true);
/*  60 */     r.addPreResult(10, 0, true);
/*  61 */     r.addPreResult(24, 0, true);
/*  62 */     r.addPreResult(20, 0, false);
/*  63 */     r.addPostResult(11, false);
/*  64 */     addRule(r);
/*     */ 
/*     */     
/*  67 */     r = new Rule();
/*     */     
/*  69 */     r.setDescription("!LIV & !1-B => !SC");
/*  70 */     r.addPreResult(1, 0, true);
/*  71 */     r.addPreResult(10, 0, true);
/*  72 */     r.addPreResult(24, 0, false);
/*  73 */     r.addPreResult(20, 0, false);
/*  74 */     r.addPostResult(11, false);
/*  75 */     addRule(r);
/*     */   }
/*     */   
/*     */   public boolean checkSpecialProperties(Object object) {
/*  79 */     if (!(object instanceof PlaceTransitionNet)) {
/*  80 */       return false;
/*     */     }
/*     */     
/*  83 */     PlaceTransitionNet pn = (PlaceTransitionNet)object;
/*  84 */     if (pn.isMG()) {
/*  85 */       List<Place> v = pn.getPlaces();
/*  86 */       int tokenCount = 0;
/*  87 */       for (Place p : v) {
/*  88 */         tokenCount += p.getToken();
/*     */ 
/*     */         
/*  91 */         if (tokenCount > 1)
/*     */         {
/*  93 */           return false;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  99 */       return (tokenCount == 1);
/*     */     } 
/* 101 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/rules/NetClassRule001.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */