/*     */ package charlie.pn.rules;
/*     */ 
/*     */ import charlie.pn.Results;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ public abstract class ExtendedRule
/*     */   extends Rule
/*     */ {
/*  12 */   protected List<Rule> ruleList = new ArrayList<>();
/*  13 */   protected String mainDescription = null;
/*  14 */   protected Results originalPreResults = null;
/*  15 */   protected Results originalPostResults = null;
/*  16 */   protected int[] originalRelationArray = null;
/*     */   
/*     */   public ExtendedRule() {
/*  19 */     initialize();
/*     */     
/*  21 */     this.originalPreResults = this.preResults.copy();
/*  22 */     this.originalPostResults = this.postResults.copy();
/*  23 */     this.originalRelationArray = Arrays.copyOfRange(this.relationArray, 0, this.relationArray.length);
/*  24 */     if (this.mainDescription != null && this.description != null) {
/*  25 */       setDescription(this.description + this.mainDescription);
/*  26 */     } else if (this.description != null && this.mainDescription == null) {
/*  27 */       this.mainDescription = getDescription();
/*  28 */     } else if (this.description == null && this.mainDescription != null) {
/*  29 */       setDescription(this.mainDescription);
/*     */     } else {
/*  31 */       setDescription("no description provided!");
/*  32 */       this.mainDescription = "no description provided!";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void initialize();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean checkSpecialProperties(Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkRule(Results results, Object object) {
/*  60 */     if (this.ruleList.size() > 0) {
/*  61 */       Rule rs = findFirstRule(results);
/*     */ 
/*     */       
/*  64 */       if (rs != null) {
/*  65 */         setDescription(this.mainDescription + ":\n->" + rs.getDescription());
/*     */       } else {
/*     */         
/*  68 */         this.preResults = this.originalPreResults.copy();
/*  69 */         this.postResults = this.originalPostResults.copy();
/*  70 */         this.relationArray = Arrays.copyOfRange(this.originalRelationArray, 0, this.originalRelationArray.length);
/*  71 */         if (this.mainDescription != null && this.mainDescription.length() > 0) {
/*  72 */           setDescription(this.mainDescription);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  77 */     if (checkRule(results)) {
/*  78 */       if (checkSpecialProperties(object)) {
/*  79 */         return true;
/*     */       }
/*  81 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rule findFirstRule(Results results) {
/*  96 */     for (Rule rule : this.ruleList) {
/*  97 */       this.preResults = this.originalPreResults.copy();
/*  98 */       this.preResults.mergeWith(rule.preResults);
/*  99 */       this.postResults = this.originalPostResults.copy();
/* 100 */       this.postResults.mergeWith(rule.postResults);
/*     */       try {
/* 102 */         this.relationArray = mergeRelationArrays(this.originalRelationArray, rule.relationArray);
/*     */         
/* 104 */         if (checkRule(results))
/* 105 */           return rule; 
/* 106 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */     
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int[] mergeRelationArrays(int[] r1, int[] r2) throws Exception {
/* 119 */     int size = r1.length;
/* 120 */     if (r1.length < r2.length) return new int[0]; 
/* 121 */     int[] returnArray = new int[size];
/* 122 */     Arrays.fill(this.relationArray, -1);
/* 123 */     int index = 0;
/* 124 */     for (index = 0; index < size; index++) {
/* 125 */       if (r1[index] != -1 && r2[index] != -1 && r1[index] != r2[index])
/*     */       {
/*     */ 
/*     */         
/* 129 */         throw new Exception("mergeRelationArrays, conflicting arrays, both values of relations array are set!"); } 
/* 130 */       if (r1[index] != -1) {
/* 131 */         returnArray[index] = r1[index];
/* 132 */       } else if (r2[index] != -1) {
/* 133 */         returnArray[index] = r2[index];
/*     */       } 
/*     */     } 
/* 136 */     return returnArray;
/*     */   }
/*     */   
/*     */   public void addRule(Rule r) {
/* 140 */     this.ruleList.add(r);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/rules/ExtendedRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */