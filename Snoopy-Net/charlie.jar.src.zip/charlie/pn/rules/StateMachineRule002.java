/*     */ package charlie.pn.rules;
/*     */ 
/*     */ import charlie.pn.Place;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StateMachineRule002
/*     */   extends ExtendedRule
/*     */ {
/*     */   public void initialize() {
/*  20 */     this.mainDescription = "SM & ORD =>[SC & exactly one token <=> LIV & 1-B & REV]";
/*     */     
/*  22 */     Rule r = new Rule();
/*  23 */     r.setDescription("SC => LIV & 1-B & REV");
/*  24 */     r.addPreResult(1, 0, true);
/*  25 */     r.addPreResult(11, 0, true);
/*  26 */     r.addPostResult(24, true);
/*  27 */     r.addPostResult(20, true);
/*  28 */     r.addPostResult(25, true);
/*  29 */     addRule(r);
/*     */ 
/*     */     
/*  32 */     r = new Rule();
/*  33 */     r.setDescription("LIV & 1-B & REV => SC");
/*  34 */     r.addPreResult(1, 0, true);
/*  35 */     r.addPreResult(10, 0, true);
/*  36 */     r.addPreResult(24, 0, true);
/*  37 */     r.addPreResult(20, 0, true);
/*  38 */     r.addPreResult(25, 0, true);
/*  39 */     r.addPostResult(11, true);
/*  40 */     addRule(r);
/*     */ 
/*     */     
/*  43 */     r = new Rule();
/*  44 */     r.setDescription("!LIV & 1-B & REV => !SC");
/*  45 */     r.addPreResult(1, 0, true);
/*  46 */     r.addPreResult(10, 0, true);
/*  47 */     r.addPreResult(24, 0, false);
/*  48 */     r.addPreResult(20, 0, true);
/*  49 */     r.addPreResult(25, 0, true);
/*  50 */     r.addPostResult(11, false);
/*  51 */     addRule(r);
/*     */ 
/*     */     
/*  54 */     r = new Rule();
/*  55 */     r.setDescription("LIV & !1-B & REV => SC");
/*  56 */     r.addPreResult(1, 0, true);
/*  57 */     r.addPreResult(10, 0, true);
/*  58 */     r.addPreResult(24, 0, true);
/*  59 */     r.addPreResult(20, 0, false);
/*  60 */     r.addPreResult(25, 0, true);
/*  61 */     r.addPostResult(11, false);
/*  62 */     addRule(r);
/*     */ 
/*     */     
/*  65 */     r = new Rule();
/*  66 */     r.setDescription("LIV & 1-B & !REV => SC");
/*  67 */     r.addPreResult(1, 0, true);
/*  68 */     r.addPreResult(10, 0, true);
/*  69 */     r.addPreResult(24, 0, true);
/*  70 */     r.addPreResult(20, 0, true);
/*  71 */     r.addPreResult(25, 0, false);
/*  72 */     r.addPostResult(11, false);
/*  73 */     addRule(r);
/*     */ 
/*     */     
/*  76 */     r = new Rule();
/*  77 */     r.setDescription("!SC & LIV & 1-B => !REV");
/*  78 */     r.addPreResult(1, 0, true);
/*  79 */     r.addPreResult(10, 0, true);
/*  80 */     r.addPreResult(11, 0, false);
/*  81 */     r.addPreResult(24, 0, true);
/*  82 */     r.addPreResult(20, 0, true);
/*  83 */     r.addPostResult(25, false);
/*  84 */     addRule(r);
/*     */ 
/*     */     
/*  87 */     r = new Rule();
/*  88 */     r.setDescription("!SC & REV & 1-B => !LIV");
/*  89 */     r.addPreResult(1, 0, true);
/*  90 */     r.addPreResult(10, 0, true);
/*  91 */     r.addPreResult(11, 0, false);
/*  92 */     r.addPreResult(25, 0, true);
/*  93 */     r.addPreResult(20, 0, true);
/*  94 */     r.addPostResult(24, false);
/*  95 */     addRule(r);
/*     */ 
/*     */     
/*  98 */     r = new Rule();
/*  99 */     r.setDescription("!SC & LIV & REV => !1-B");
/* 100 */     r.addPreResult(1, 0, true);
/* 101 */     r.addPreResult(10, 0, true);
/* 102 */     r.addPreResult(11, 0, false);
/* 103 */     r.addPreResult(24, 0, true);
/* 104 */     r.addPreResult(25, 0, true);
/* 105 */     r.addPostResult(20, false);
/* 106 */     addRule(r);
/*     */   }
/*     */   
/*     */   public boolean checkSpecialProperties(Object object) {
/* 110 */     if (!(object instanceof PlaceTransitionNet)) {
/* 111 */       return false;
/*     */     }
/*     */     
/* 114 */     PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 115 */     if (pn.isSM()) {
/* 116 */       List<Place> v = pn.getPlaces();
/* 117 */       int tokenCount = 0;
/* 118 */       for (Place p : v) {
/* 119 */         tokenCount += p.getToken();
/*     */ 
/*     */         
/* 122 */         if (tokenCount > 1)
/*     */         {
/* 124 */           return false;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 130 */       return (tokenCount == 1);
/*     */     } 
/*     */     
/* 133 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/rules/StateMachineRule002.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */