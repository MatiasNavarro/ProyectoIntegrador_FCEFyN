/*    */ package charlie.pn.rules;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ 
/*    */ public class Rule012
/*    */   extends ExtendedRule {
/*  7 */   PlaceTransitionNet pn = null;
/*    */ 
/*    */   
/*    */   public void initialize() {
/* 11 */     addPreResult(11, 0, true);
/* 12 */     addPostResult(24, true);
/* 13 */     addPostResult(19, true);
/* 14 */     addPostResult(25, true);
/* 15 */     setDescription("net is marked graph and strongly connected and each\telementary circle contains at least one token => live, bounded, reversible");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean checkSpecialProperties(Object object) {
/* 24 */     if (object instanceof PlaceTransitionNet) {
/* 25 */       this.pn = (PlaceTransitionNet)object;
/*    */     } else {
/* 27 */       return false;
/*    */     } 
/* 29 */     return this.pn.isMG();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/rules/Rule012.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */