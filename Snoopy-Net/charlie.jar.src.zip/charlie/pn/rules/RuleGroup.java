/*     */ package charlie.pn.rules;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuleGroup
/*     */ {
/*  17 */   public static final RuleGroup SEPARATOR_GROUP = new RuleGroup("--------");
/*     */   
/*  19 */   private final List<Rule> ruleList = new ArrayList<>();
/*     */   
/*  21 */   private String description = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleGroup() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleGroup(String _description) {
/*  33 */     this.description = _description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String _description) {
/*  42 */     this.description = _description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  51 */     if (this.description == null) {
/*  52 */       return "";
/*     */     }
/*  54 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRule(Rule _rule) {
/*  63 */     this.ruleList.add(_rule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rule getRule(int _index) {
/*  76 */     return this.ruleList.get(_index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Rule> getRuleList() {
/*  85 */     return this.ruleList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  92 */     this.ruleList.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 101 */     return this.ruleList.size();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/rules/RuleGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */