/*    */ package charlie.pn.rules;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ 
/*    */ public class Rule013 extends ExtendedRule {
/*  6 */   PlaceTransitionNet pn = null;
/*    */   
/*    */   public void initialize() {
/*  9 */     System.out.printf("Rule013:initialize called...\n", new Object[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean checkSpecialProperties(Object object) {
/* 18 */     if (object instanceof PlaceTransitionNet) {
/* 19 */       this.pn = (PlaceTransitionNet)object;
/*    */     } else {
/* 21 */       return false;
/*    */     } 
/* 23 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/rules/Rule013.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */