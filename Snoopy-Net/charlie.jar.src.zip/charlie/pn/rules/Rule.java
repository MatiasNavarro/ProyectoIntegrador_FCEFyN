/*     */ package charlie.pn.rules;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.pn.Result;
/*     */ import charlie.pn.Results;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Rule
/*     */ {
/*     */   public static final int NOTSET = -1;
/*     */   public static final int EQ = 0;
/*     */   public static final int NEQ = 1;
/*     */   public static final int GT = 2;
/*     */   public static final int LT = 3;
/*     */   public static final int GTEQ = 4;
/*     */   public static final int LTEQ = 5;
/*     */   public static final int VAR_EQ_MINUS_ONE = 6;
/*  55 */   public Results preResults = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public Results postResults = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public int[] relationArray = new int[Results.RESULTCOUNT];
/*     */   
/*  69 */   private final Map<Integer, Integer> furtherRelations = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   protected String description = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rule() {
/*  80 */     this.preResults = new Results();
/*  81 */     this.postResults = new Results();
/*  82 */     Arrays.fill(this.relationArray, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rule(String _description) {
/*  91 */     this();
/*     */     
/*  93 */     this.description = _description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rule(int[] relations, Results pre, Results post) {
/* 104 */     this.preResults = pre;
/* 105 */     this.postResults = post;
/* 106 */     this.relationArray = relations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String s) {
/* 116 */     this.description = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 125 */     if (this.description == null) {
/* 126 */       return "";
/*     */     }
/* 128 */     return this.description;
/*     */   }
/*     */   
/*     */   public void resetObjects() {
/* 132 */     this.preResults = new Results();
/* 133 */     this.postResults = new Results();
/* 134 */     this.relationArray = new int[Results.RESULTCOUNT];
/* 135 */     Arrays.fill(this.relationArray, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkRule(Results results) {
/* 142 */     boolean incPre = checkPreConditions(results);
/*     */     
/* 144 */     return incPre;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkPreConditions(Results r) {
/* 154 */     if (this.preResults.isEmpty()) {
/* 155 */       return false;
/*     */     }
/*     */     
/* 158 */     int i = 0;
/* 159 */     boolean returnValue = true;
/*     */     
/* 161 */     while (returnValue == true && i < Results.RESULTCOUNT) {
/* 162 */       Result r1 = this.preResults.getResult(i);
/* 163 */       Result r2 = r.getResult(i);
/* 164 */       if (r1 != null && r2 != null) {
/*     */         
/* 166 */         switch (this.relationArray[i]) {
/*     */           case 0:
/* 168 */             returnValue = r1.equals(r2);
/*     */             break;
/*     */           case 1:
/* 171 */             returnValue = r1.nequals(r2);
/*     */             break;
/*     */           case 2:
/* 174 */             returnValue = r1.gt(r2);
/*     */             break;
/*     */           case 3:
/* 177 */             returnValue = r1.lt(r2);
/*     */             break;
/*     */           case 4:
/* 180 */             returnValue = r1.gteq(r2);
/*     */             break;
/*     */           case 5:
/* 183 */             returnValue = r1.lteq(r2);
/*     */             break;
/*     */           case -1:
/* 186 */             returnValue = false;
/*     */             break;
/*     */ 
/*     */           
/*     */           default:
/* 191 */             returnValue = false;
/*     */             break;
/*     */         } 
/*     */ 
/*     */       
/* 196 */       } else if (r1 != null && r2 == null) {
/*     */         
/* 198 */         returnValue = false;
/*     */       } 
/* 200 */       i++;
/*     */     } 
/* 202 */     for (Iterator<Integer> it = this.furtherRelations.keySet().iterator(); it.hasNext(); ) {
/* 203 */       Integer key = it.next();
/* 204 */       i = key.intValue();
/* 205 */       int relation = ((Integer)this.furtherRelations.get(key)).intValue();
/* 206 */       Result r1 = this.preResults.getResult(i);
/* 207 */       Result r2 = r.getResult(i);
/*     */       
/* 209 */       if (r1 != null && r2 != null) {
/*     */ 
/*     */         
/* 212 */         switch (relation) {
/*     */           case 0:
/* 214 */             returnValue = r1.equals(r2);
/*     */             continue;
/*     */           case 1:
/* 217 */             returnValue = r1.nequals(r2);
/*     */             continue;
/*     */           case 2:
/* 220 */             returnValue = r1.gt(r2);
/*     */             continue;
/*     */           case 3:
/* 223 */             returnValue = r1.lt(r2);
/*     */             continue;
/*     */           case 4:
/* 226 */             returnValue = r1.gteq(r2);
/*     */             continue;
/*     */           case 5:
/* 229 */             returnValue = r1.lteq(r2);
/*     */             continue;
/*     */           case -1:
/* 232 */             returnValue = false;
/*     */             continue;
/*     */         } 
/*     */ 
/*     */         
/* 237 */         returnValue = false;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 242 */       if (r1 != null && r2 == null)
/*     */       {
/* 244 */         returnValue = false;
/*     */       }
/*     */     } 
/* 247 */     return returnValue;
/*     */   }
/*     */   
/*     */   public Results applyRule(Results results) {
/* 251 */     Results r = new Results();
/* 252 */     r.mergeWith(this.postResults);
/*     */     
/* 254 */     r.appendOutput("Applying rule:\n");
/* 255 */     r.appendOutput(this.description);
/* 256 */     return r;
/*     */   }
/*     */   
/*     */   public boolean addPreResult(int propIndex, int relation, Object value) throws IndexOutOfBoundsException {
/* 260 */     if (relation == 0 || relation == 1 || relation == 2 || relation == 3 || relation == 4 || relation == 5) {
/*     */ 
/*     */       
/* 263 */       if ((relation == 2 || relation == 3 || relation == 4 || relation == 5) && !(value instanceof Integer)) {
/* 264 */         DebugCounter.inc("Relation does not match Object type!");
/* 265 */         return false;
/*     */       } 
/*     */       
/* 268 */       this.preResults.addResult(propIndex, new Result(value));
/* 269 */       if (propIndex < Results.RESULTCOUNT && propIndex >= 0) {
/* 270 */         this.relationArray[propIndex] = relation;
/*     */       } else {
/* 272 */         this.furtherRelations.put(new Integer(propIndex), new Integer(relation));
/*     */       } 
/* 274 */       return true;
/*     */     } 
/* 276 */     return false;
/*     */   }
/*     */   
/*     */   public void addPreResult(String _key, int _relation, boolean _b) {
/* 280 */     int propIndex = Results.getIndexForKey(_key);
/* 281 */     if (propIndex > 0) {
/* 282 */       addPreResult(propIndex, _relation, _b);
/*     */     } else {
/* 284 */       throw new IllegalArgumentException(String.format("The key '%s' is unknown in the results.", new Object[] { _key }));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addPreResult(int propIndex, int relation, boolean b) {
/* 289 */     addPreResult(propIndex, relation, new Boolean(b));
/*     */   }
/*     */   
/*     */   public void addPreResult(int propIndex, int relation, int i) {
/* 293 */     addPreResult(propIndex, relation, new Integer(i));
/*     */   }
/*     */   
/*     */   public int getRelation(int index) throws IndexOutOfBoundsException {
/* 297 */     if (index < Results.RESULTCOUNT && index >= 0) {
/* 298 */       return this.relationArray[index];
/*     */     }
/*     */     
/* 301 */     Integer relation = this.furtherRelations.get(Integer.valueOf(index));
/* 302 */     if (relation != null) {
/* 303 */       return relation.intValue();
/*     */     }
/* 305 */     throw new IndexOutOfBoundsException("Rule.java::getRelation() : The specified Index index = " + Integer.toString(index) + " exceeds the allowed Bounds!");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addPostResult(int propIndex, Object value) {
/* 311 */     if (propIndex < Results.RESULTCOUNT && propIndex >= 0) {
/* 312 */       this.postResults.addResult(propIndex, new Result(value));
/* 313 */       return true;
/*     */     } 
/* 315 */     throw new IndexOutOfBoundsException("Rule.java::addPostResult(int,int,Object) : The specified Index propIndex = " + Integer.toString(propIndex) + " exceeds the allowed Bounds!");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addPostResult(int propIndex, boolean b) {
/* 321 */     return addPostResult(propIndex, new Boolean(b));
/*     */   }
/*     */   
/*     */   public boolean addPostResult(int propIndex, int i) {
/* 325 */     return addPostResult(propIndex, new Integer(i));
/*     */   }
/*     */   
/*     */   public void addPostResult(String _key, boolean _b) {
/* 329 */     int propIndex = Results.getIndexForKey(_key);
/* 330 */     if (propIndex > 0) {
/* 331 */       addPostResult(propIndex, _b);
/*     */     } else {
/* 333 */       throw new IllegalArgumentException(String.format("The key '%s' is unknown in the result set.", new Object[] { _key }));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addPostResult(String _key, Object _value) {
/* 338 */     int propIndex = Results.getIndexForKey(_key);
/* 339 */     if (propIndex > 0) {
/* 340 */       addPostResult(propIndex, _value);
/*     */     } else {
/* 342 */       throw new IllegalArgumentException(String.format("The key '%s' is unknown in the result set.", new Object[] { _key }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 348 */     return "Rule: " + this.description;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 353 */     int prime = 31;
/* 354 */     int result = 1;
/* 355 */     result = 31 * result + ((this.description == null) ? 0 : this.description.hashCode());
/* 356 */     result = 31 * result + ((this.furtherRelations == null) ? 0 : this.furtherRelations.hashCode());
/* 357 */     result = 31 * result + ((this.postResults == null) ? 0 : this.postResults.hashCode());
/* 358 */     result = 31 * result + ((this.preResults == null) ? 0 : this.preResults.hashCode());
/* 359 */     result = 31 * result + Arrays.hashCode(this.relationArray);
/* 360 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 365 */     if (this == obj) {
/* 366 */       return true;
/*     */     }
/* 368 */     if (obj == null) {
/* 369 */       return false;
/*     */     }
/* 371 */     if (getClass() != obj.getClass()) {
/* 372 */       return false;
/*     */     }
/* 374 */     Rule other = (Rule)obj;
/* 375 */     if (this.description == null) {
/* 376 */       if (other.description != null) {
/* 377 */         return false;
/*     */       }
/* 379 */     } else if (!this.description.equals(other.description)) {
/* 380 */       return false;
/*     */     } 
/* 382 */     if (this.furtherRelations == null) {
/* 383 */       if (other.furtherRelations != null) {
/* 384 */         return false;
/*     */       }
/* 386 */     } else if (!this.furtherRelations.equals(other.furtherRelations)) {
/* 387 */       return false;
/*     */     } 
/* 389 */     if (this.postResults == null) {
/* 390 */       if (other.postResults != null) {
/* 391 */         return false;
/*     */       }
/* 393 */     } else if (!this.postResults.equals(other.postResults)) {
/* 394 */       return false;
/*     */     } 
/* 396 */     if (this.preResults == null) {
/* 397 */       if (other.preResults != null) {
/* 398 */         return false;
/*     */       }
/* 400 */     } else if (!this.preResults.equals(other.preResults)) {
/* 401 */       return false;
/*     */     } 
/* 403 */     if (!Arrays.equals(this.relationArray, other.relationArray)) {
/* 404 */       return false;
/*     */     }
/* 406 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/rules/Rule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */