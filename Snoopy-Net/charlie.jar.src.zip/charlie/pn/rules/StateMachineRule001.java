/*     */ package charlie.pn.rules;
/*     */ 
/*     */ import charlie.pn.Place;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StateMachineRule001
/*     */   extends ExtendedRule
/*     */ {
/*     */   public void initialize() {
/*  19 */     this.mainDescription = "SM & ORD => [SC & at least one token <=> LIV & k-B & REV]";
/*  20 */     Rule r = new Rule();
/*  21 */     r.setDescription("SC => LIV & k-B & REV");
/*  22 */     r.addPreResult(1, 0, true);
/*  23 */     r.addPreResult(11, 0, true);
/*  24 */     r.addPostResult(24, true);
/*  25 */     r.addPostResult(19, true);
/*  26 */     r.addPostResult(25, true);
/*  27 */     addRule(r);
/*     */ 
/*     */     
/*  30 */     r = new Rule();
/*  31 */     r.setDescription("LIV & k-B & REV => SC");
/*  32 */     r.addPreResult(1, 0, true);
/*  33 */     r.addPreResult(10, 0, true);
/*  34 */     r.addPreResult(24, 0, true);
/*  35 */     r.addPreResult(19, 0, true);
/*  36 */     r.addPreResult(25, 0, true);
/*  37 */     r.addPostResult(11, true);
/*  38 */     addRule(r);
/*     */ 
/*     */     
/*  41 */     r = new Rule();
/*  42 */     r.setDescription("!LIV & k-B & REV => !SC");
/*  43 */     r.addPreResult(1, 0, true);
/*  44 */     r.addPreResult(10, 0, true);
/*  45 */     r.addPreResult(24, 0, false);
/*  46 */     r.addPreResult(19, 0, true);
/*  47 */     r.addPreResult(25, 0, true);
/*  48 */     r.addPostResult(11, false);
/*  49 */     addRule(r);
/*     */ 
/*     */     
/*  52 */     r = new Rule();
/*  53 */     r.setDescription("LIV & !k-B & REV => SC");
/*  54 */     r.addPreResult(1, 0, true);
/*  55 */     r.addPreResult(10, 0, true);
/*  56 */     r.addPreResult(24, 0, true);
/*  57 */     r.addPreResult(19, 0, false);
/*  58 */     r.addPreResult(25, 0, true);
/*  59 */     r.addPostResult(11, false);
/*  60 */     addRule(r);
/*     */ 
/*     */     
/*  63 */     r = new Rule();
/*  64 */     r.setDescription("LIV & k-B & !REV => SC");
/*  65 */     r.addPreResult(1, 0, true);
/*  66 */     r.addPreResult(10, 0, true);
/*  67 */     r.addPreResult(24, 0, true);
/*  68 */     r.addPreResult(19, 0, true);
/*  69 */     r.addPreResult(25, 0, false);
/*  70 */     r.addPostResult(11, false);
/*  71 */     addRule(r);
/*     */ 
/*     */     
/*  74 */     r = new Rule();
/*  75 */     r.setDescription("!SC & LIV & k-B => !REV");
/*  76 */     r.addPreResult(1, 0, true);
/*  77 */     r.addPreResult(10, 0, true);
/*  78 */     r.addPreResult(11, 0, false);
/*  79 */     r.addPreResult(24, 0, true);
/*  80 */     r.addPreResult(19, 0, true);
/*  81 */     r.addPostResult(25, false);
/*  82 */     addRule(r);
/*     */ 
/*     */     
/*  85 */     r = new Rule();
/*  86 */     r.setDescription("!SC & REV & k-B => !LIV");
/*  87 */     r.addPreResult(1, 0, true);
/*  88 */     r.addPreResult(10, 0, true);
/*  89 */     r.addPreResult(11, 0, false);
/*  90 */     r.addPreResult(25, 0, true);
/*  91 */     r.addPreResult(19, 0, true);
/*  92 */     r.addPostResult(24, false);
/*  93 */     addRule(r);
/*     */ 
/*     */     
/*  96 */     r = new Rule();
/*  97 */     r.setDescription("!SC & LIV & REV => !k-B");
/*  98 */     r.addPreResult(1, 0, true);
/*  99 */     r.addPreResult(10, 0, true);
/* 100 */     r.addPreResult(11, 0, false);
/* 101 */     r.addPreResult(24, 0, true);
/* 102 */     r.addPreResult(25, 0, true);
/* 103 */     r.addPostResult(19, false);
/* 104 */     addRule(r);
/*     */   }
/*     */   
/*     */   public boolean checkSpecialProperties(Object object) {
/* 108 */     if (!(object instanceof PlaceTransitionNet)) {
/* 109 */       return false;
/*     */     }
/*     */     
/* 112 */     PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 113 */     if (pn.isSM()) {
/* 114 */       List<Place> v = pn.getPlaces();
/* 115 */       for (Place p : v) {
/* 116 */         if (p.getToken() > 0) {
/* 117 */           return true;
/*     */         }
/*     */       } 
/*     */       
/* 121 */       return false;
/*     */     } 
/* 123 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/rules/StateMachineRule001.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */