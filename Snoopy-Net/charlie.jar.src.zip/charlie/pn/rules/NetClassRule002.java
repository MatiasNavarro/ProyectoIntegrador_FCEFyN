/*    */ package charlie.pn.rules;
/*    */ 
/*    */ import charlie.pn.Place;
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NetClassRule002
/*    */   extends ExtendedRule
/*    */ {
/*    */   public void initialize() {
/* 19 */     this.mainDescription = "MG & ORD : [SC & at least one token <=> LIV & k-B]";
/*    */     
/* 21 */     Rule r = new Rule();
/*    */     
/* 23 */     r.setDescription("LIV & k-B => SC");
/* 24 */     r.addPreResult(1, 0, true);
/* 25 */     r.addPreResult(10, 0, true);
/* 26 */     r.addPreResult(24, 0, true);
/* 27 */     r.addPreResult(19, 0, true);
/* 28 */     r.addPostResult(11, true);
/* 29 */     addRule(r);
/*    */ 
/*    */     
/* 32 */     r = new Rule();
/*    */     
/* 34 */     r.setDescription("SC => LIV & k-B");
/* 35 */     r.addPreResult(1, 0, true);
/* 36 */     r.addPreResult(11, 0, true);
/* 37 */     r.addPostResult(24, true);
/* 38 */     r.addPostResult(19, true);
/* 39 */     addRule(r);
/*    */ 
/*    */     
/* 42 */     r = new Rule();
/*    */     
/* 44 */     r.setDescription("!LIV & k-B => !SC");
/* 45 */     r.addPreResult(1, 0, true);
/* 46 */     r.addPreResult(10, 0, true);
/* 47 */     r.addPreResult(24, 0, false);
/* 48 */     r.addPreResult(19, 0, true);
/* 49 */     r.addPostResult(11, false);
/* 50 */     addRule(r);
/*    */ 
/*    */     
/* 53 */     r = new Rule();
/*    */     
/* 55 */     r.setDescription("LIV & !k-B => !SC");
/* 56 */     r.addPreResult(1, 0, true);
/* 57 */     r.addPreResult(10, 0, true);
/* 58 */     r.addPreResult(24, 0, true);
/* 59 */     r.addPreResult(19, 0, false);
/* 60 */     r.addPostResult(11, false);
/* 61 */     addRule(r);
/*    */ 
/*    */     
/* 64 */     r = new Rule();
/*    */     
/* 66 */     r.setDescription("!LIV & !k-B => !SC");
/* 67 */     r.addPreResult(1, 0, true);
/* 68 */     r.addPreResult(10, 0, true);
/* 69 */     r.addPreResult(24, 0, false);
/* 70 */     r.addPreResult(19, 0, false);
/* 71 */     r.addPostResult(11, false);
/* 72 */     addRule(r);
/*    */   }
/*    */   
/*    */   public boolean checkSpecialProperties(Object object) {
/* 76 */     if (!(object instanceof PlaceTransitionNet)) {
/* 77 */       return false;
/*    */     }
/*    */     
/* 80 */     PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 81 */     if (pn.isMG()) {
/* 82 */       List<Place> v = pn.getPlaces();
/* 83 */       for (Place p : v) {
/*    */ 
/*    */         
/* 86 */         if (p.getToken() > 0)
/*    */         {
/* 88 */           return true;
/*    */         }
/*    */       } 
/*    */ 
/*    */       
/* 93 */       return false;
/*    */     } 
/* 95 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/rules/NetClassRule002.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */