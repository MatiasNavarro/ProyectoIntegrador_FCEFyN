/*    */ package charlie.pn;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultipleMarkingsPlaceTransitionNet
/*    */   extends PlaceTransitionNet
/*    */ {
/* 18 */   private final Map<String, List<Integer>> markingMap = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 23 */   private final List<String> markingNameList = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MultipleMarkingsPlaceTransitionNet() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MultipleMarkingsPlaceTransitionNet(String _name) {
/* 38 */     super(_name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addMarking(String _name, List<Integer> _marking) {
/* 49 */     this.markingMap.put(_name, _marking);
/* 50 */     this.markingNameList.add(_name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getMarkingNameList() {
/* 59 */     return this.markingNameList;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Integer> getMarking(String _name) {
/* 70 */     return this.markingMap.get(_name);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/MultipleMarkingsPlaceTransitionNet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */