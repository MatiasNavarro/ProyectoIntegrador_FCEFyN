/*    */ package charlie.pn;
/*    */ 
/*    */ import charlie.ds.BitSet;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class OrderPlacesByName
/*    */   implements OrderingFunction {
/*    */   public OrderPlacesByName(PlaceTransitionNet pn) {
/*  9 */     BitSet ready = new BitSet(pn.places());
/* 10 */     this.translationTable = new Vector(pn.places());
/* 11 */     String min = null;
/* 12 */     while (ready.size() < pn.places()) {
/* 13 */       int nextIndex = -1;
/* 14 */       min = null;
/* 15 */       for (int index = 0; index < pn.places(); index++) {
/* 16 */         if (!ready.member(index)) {
/* 17 */           PNNode n = pn.getPlaceByIndex(index);
/* 18 */           if (min == null) {
/* 19 */             nextIndex = index;
/* 20 */             min = n.getName();
/*    */           
/*    */           }
/* 23 */           else if (n.getName().compareTo(min) < 0) {
/* 24 */             nextIndex = index;
/* 25 */             min = n.getName();
/*    */           } 
/*    */         } 
/*    */       } 
/*    */       
/* 30 */       this.translationTable.add(new Integer(nextIndex));
/* 31 */       ready.insert(nextIndex);
/*    */     } 
/*    */   }
/*    */   Vector translationTable;
/*    */   
/*    */   public Vector getTranslationTable() {
/* 37 */     return this.translationTable;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/OrderPlacesByName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */