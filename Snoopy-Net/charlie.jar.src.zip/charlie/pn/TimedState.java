/*     */ package charlie.pn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimedState
/*     */   extends State
/*     */ {
/*     */   private Marking placeSet;
/*     */   Marking transitionSet;
/*     */   
/*     */   public TimedState(byte clockHandling, byte timedNetType, byte timeDesignation) {
/*  17 */     this.clockHandling = clockHandling;
/*  18 */     this.timedNetType = timedNetType;
/*  19 */     this.timeDesignation = timeDesignation;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TimedState copy() throws SafetyException, ExceedsByteException {
/*  25 */     TimedState state = new TimedState(this.clockHandling, this.timedNetType, this.timeDesignation);
/*     */     try {
/*  27 */       state.placeSet = this.placeSet.copy();
/*  28 */     } catch (SafetyException e) {
/*  29 */       SortedElementsFactory.safeMode(false);
/*  30 */       state.placeSet = this.placeSet.copy();
/*  31 */       SortedElementsFactory.safeMode(true);
/*  32 */     } catch (ExceedsByteException e) {
/*  33 */       SortedElementsFactory.byteMode(false);
/*  34 */       state.placeSet = this.placeSet.copy();
/*  35 */       SortedElementsFactory.byteMode(true);
/*     */     } 
/*     */     
/*     */     try {
/*  39 */       state.transitionSet = this.transitionSet.copy();
/*  40 */     } catch (SafetyException e) {
/*  41 */       SortedElementsFactory.safeMode(false);
/*  42 */       state.transitionSet = this.transitionSet.copy();
/*  43 */       SortedElementsFactory.safeMode(true);
/*  44 */     } catch (ExceedsByteException e) {
/*  45 */       SortedElementsFactory.byteMode(false);
/*  46 */       state.transitionSet = this.transitionSet.copy();
/*  47 */       SortedElementsFactory.byteMode(true);
/*     */     } 
/*  49 */     return state;
/*     */   }
/*     */ 
/*     */   
/*     */   public Marking getPlaceMarking() {
/*  54 */     return this.placeSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public Marking getTransitionMarking() {
/*  59 */     return this.transitionSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPlaceMarking(Marking placeSet) {
/*  64 */     this.placeSet = placeSet;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransitionMarking(Marking transitionSet) {
/*  70 */     this.transitionSet = transitionSet;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int addPlace(int id, int token) throws SafetyException, ExceedsByteException {
/*  76 */     return this.placeSet.addPlace(id, token);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*  80 */     if (obj instanceof TimedState) {
/*  81 */       TimedState state = (TimedState)obj;
/*  82 */       if (this.placeSet.size() != state.getPlaceMarking().size() || this.transitionSet.size() != state.getTransitionMarking().size())
/*  83 */         return false; 
/*  84 */       if (!this.placeSet.equals(state.getPlaceMarking()))
/*  85 */         return false; 
/*  86 */       if (!this.transitionSet.equals(state.getTransitionMarking()))
/*  87 */         return false; 
/*     */     } else {
/*  89 */       return false;
/*  90 */     }  return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  94 */     return toString().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     String newString = "Places: "; int i;
/* 100 */     for (i = 0; i < this.placeSet.size(); i++)
/* 101 */       newString = newString + this.placeSet.get(i).toString(); 
/* 102 */     newString = newString + "\nTransitions: ";
/* 103 */     if (this.clockHandling == 5) {
/* 104 */       for (i = 0; i < this.transitionSet.size(); i++)
/* 105 */         newString = newString + this.transitionSet.getId(i) + " " + this.transitionSet.getToken(i) + " "; 
/*     */     } else {
/* 107 */       for (i = 0; i < this.transitionSet.size(); i++)
/* 108 */         newString = newString + this.transitionSet.getId(i) + " " + (this.transitionSet.getToken(i) - 1) + " "; 
/* 109 */     }  return newString;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/TimedState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */