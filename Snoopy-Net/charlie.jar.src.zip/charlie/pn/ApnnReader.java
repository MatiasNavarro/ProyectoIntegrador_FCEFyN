/*     */ package charlie.pn;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ public class ApnnReader
/*     */   extends PetriNetReader
/*     */ {
/*     */   private static final int PNODE = 1;
/*     */   private static final int TNODE = 2;
/*     */   private static final int ANODE = 3;
/*     */   private static String last;
/*     */   private static String currentLine;
/*     */   private static final String PLACE = "\\place";
/*     */   private static final String TRANS = "\\transition";
/*     */   private static final String ARC = "\\arc";
/*     */   private static final String WEIGHT = "\\weight";
/*     */   private static final String INIT = "\\init";
/*     */   private static final String FROM = "\\from";
/*     */   private static final String TO = "\\to";
/*     */   private static final String LIKE = "\\like";
/*     */   private static final String NAME = "\\name";
/*     */   private static final String TYPE = "\\type";
/*     */   private static final String CAP = "\\capacity";
/*     */   private static final String FUNCTION = "\\function";
/*     */   private static final String CONSTANT = "\\const";
/*     */   private static final String VALUE = "\\value";
/*  31 */   private static String lastLine = new String("\\endnet");
/*     */   private static int lineCounter;
/*     */   
/*     */   public ApnnReader(String filename, PlaceTransitionNet pn, ConstantInterface cI) throws Exception {
/*  35 */     this.file = filename;
/*     */     
/*  37 */     this.pn = pn;
/*  38 */     if (pn.getName().endsWith(".apnn")) {
/*  39 */       pn.setName(pn.getName().substring(0, pn.getName().length() - 5));
/*     */     }
/*  41 */     initReader(cI);
/*     */   }
/*     */   
/*     */   public ApnnReader() {
/*  45 */     PetriNetReaderFactory.registerReader(".apnn", this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void readNet() throws Exception {
/*  51 */     read();
/*  52 */     this.pn.TIMED_NET_TYPE = 4;
/*  53 */     this.pn.setTimedNet(false);
/*     */     
/*  55 */     initNet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int countPlaces() {
/*  61 */     currentLine = "";
/*  62 */     lineCounter = 0;
/*     */     
/*  64 */     UnsignedByte.setMin(0);
/*  65 */     int places = 0;
/*     */     try {
/*  67 */       InputStream fileInput = getInputStream(this.file);
/*  68 */       BufferedReader br = new BufferedReader(new InputStreamReader(fileInput));
/*     */       
/*  70 */       while (currentLine != null) {
/*     */         
/*  72 */         if (currentLine.indexOf("\\place") != -1) {
/*  73 */           places++;
/*     */         }
/*  75 */         readLine(br);
/*     */       } 
/*  77 */     } catch (Exception e) {
/*  78 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  81 */     return places;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int countTransitions() {
/*  87 */     currentLine = "";
/*  88 */     lineCounter = 0;
/*  89 */     int trans = 0;
/*     */     try {
/*  91 */       InputStream fileInput = getInputStream(this.file);
/*  92 */       BufferedReader br = new BufferedReader(new InputStreamReader(fileInput));
/*  93 */       br.readLine();
/*     */       
/*  95 */       while (currentLine != null) {
/*     */         
/*  97 */         if (currentLine.indexOf("\\transition") != -1) {
/*  98 */           trans++;
/*     */         }
/* 100 */         readLine(br);
/*     */       } 
/* 102 */     } catch (Exception e) {
/* 103 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 106 */     return trans;
/*     */   }
/*     */ 
/*     */   
/*     */   private void readLine(BufferedReader br) {
/*     */     try {
/* 112 */       last = currentLine;
/* 113 */       currentLine = br.readLine();
/* 114 */       lineCounter++;
/* 115 */     } catch (Exception e) {
/* 116 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void read() throws UnknownArcException, SafetyException, Exception {
/*     */     try {
/* 123 */       InputStream fileInput = getInputStream(this.file);
/* 124 */       BufferedReader br = new BufferedReader(new InputStreamReader(fileInput));
/* 125 */       br.mark(10000000);
/* 126 */       lineCounter = 0;
/*     */ 
/*     */       
/* 129 */       readLine(br);
/*     */       
/* 131 */       while (currentLine != null)
/*     */       {
/* 133 */         if (currentLine.equals("")) {
/*     */           
/* 135 */           readLine(br);
/*     */           continue;
/*     */         } 
/* 138 */         if (currentLine.indexOf("\\place") != -1) {
/* 139 */           Place p = loadPlace();
/* 140 */           if (p == null) {
/* 141 */             throw new Exception("error while parsing place: " + currentLine);
/*     */           }
/*     */           
/* 144 */           if (p.getToken() > 0) {
/*     */             
/* 146 */             this.initialMarking.add(p);
/* 147 */             this.initialMarking.add(new Integer(p.getToken()));
/*     */           } 
/* 149 */           this.pn.addPlace(p);
/* 150 */         } else if (currentLine.indexOf("\\transition") != -1) {
/* 151 */           Transition t = loadTransition();
/*     */           
/* 153 */           this.pn.addTransition(t);
/*     */ 
/*     */         
/*     */         }
/* 157 */         else if (currentLine.indexOf("\\arc") != -1) {
/* 158 */           loadArc(this.pn);
/* 159 */         } else if (currentLine.indexOf("\\const") != -1) {
/* 160 */           loadConstant(this.pn);
/*     */         } 
/*     */         
/* 163 */         readLine(br);
/*     */       }
/*     */     
/* 166 */     } catch (SafetyException sx) {
/* 167 */       sx.printStackTrace();
/* 168 */       throw sx;
/* 169 */     } catch (Exception e) {
/* 170 */       e.printStackTrace();
/* 171 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String nextToken(StringTokenizer stk) {
/* 177 */     String ret = null;
/* 178 */     while (stk.hasMoreTokens()) {
/* 179 */       ret = stk.nextToken();
/* 180 */       if (ret.equals("")) {
/* 181 */         ret = null;
/*     */         continue;
/*     */       } 
/* 184 */       return ret.trim();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 189 */     return ret;
/*     */   }
/*     */   
/*     */   private Place loadPlace() throws Exception {
/* 193 */     Place p = null;
/* 194 */     String identifier = null;
/* 195 */     String name = null;
/* 196 */     String init = null;
/* 197 */     String cap = null;
/* 198 */     int token = 0;
/* 199 */     int capacity = 0;
/*     */     
/* 201 */     StringTokenizer lineTokenizer = null;
/* 202 */     StringTokenizer itemTokenizer = null;
/*     */ 
/*     */     
/* 205 */     itemTokenizer = new StringTokenizer(currentLine, "{} ");
/*     */     
/* 207 */     String currentToken = nextToken(itemTokenizer);
/*     */     
/* 209 */     identifier = evalProp("\\place", currentToken, itemTokenizer);
/*     */     
/* 211 */     if (identifier == null || identifier.equals("")) {
/* 212 */       return null;
/*     */     }
/* 214 */     currentToken = nextToken(itemTokenizer);
/* 215 */     String like = evalLike(currentToken, itemTokenizer);
/* 216 */     if (like == null) {
/* 217 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     name = evalProp("\\name", currentToken, itemTokenizer);
/*     */ 
/*     */     
/* 226 */     if (!name.equals("")) {
/* 227 */       currentToken = nextToken(itemTokenizer);
/*     */     } else {
/* 229 */       Out.println("place" + identifier + ": no NAME given, got " + identifier);
/*     */       
/* 231 */       name = identifier;
/*     */     } 
/*     */     
/* 234 */     while (itemTokenizer.hasMoreTokens()) {
/* 235 */       init = evalProp("\\init", currentToken, itemTokenizer);
/* 236 */       if (init == null) {
/* 237 */         return null;
/*     */       }
/* 239 */       if (init.equals("")) {
/*     */         
/* 241 */         token = 0;
/*     */       } else {
/*     */         try {
/* 244 */           token = Integer.parseInt(init);
/* 245 */         } catch (NumberFormatException nfe) {
/*     */           try {
/* 247 */             token = this.constantRegistry.lookUpIntConstant(init);
/* 248 */           } catch (Exception e) {
/* 249 */             throw new Exception("Parse error in line " + lineCounter + " : " + e
/* 250 */                 .getMessage());
/*     */           } 
/*     */         } 
/* 253 */         currentToken = nextToken(itemTokenizer);
/*     */       } 
/*     */       
/* 256 */       cap = evalProp("\\capacity", currentToken, itemTokenizer);
/* 257 */       if (cap == null) {
/* 258 */         return null;
/*     */       }
/* 260 */       if (cap.equals("")) {
/* 261 */         capacity = 0; continue;
/*     */       } 
/* 263 */       capacity = Integer.parseInt(cap);
/* 264 */       currentToken = nextToken(itemTokenizer);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 269 */     Place ret = new Place(identifier, name, token, this.currentPlaceId++, this.placeCounter++, capacity);
/*     */ 
/*     */     
/* 272 */     this.pn.allNodes().put(identifier, ret);
/* 273 */     this.pn.identifier().put(ret, identifier);
/* 274 */     return ret;
/*     */   }
/*     */   
/*     */   private Transition loadTransition() throws Exception {
/* 278 */     Transition t = null;
/* 279 */     String identifier = null;
/* 280 */     String name = null;
/* 281 */     String function = null;
/*     */     
/* 283 */     StringTokenizer lineTokenizer = null;
/* 284 */     StringTokenizer itemTokenizer = new StringTokenizer(currentLine, "{} ");
/* 285 */     String currentToken = nextToken(itemTokenizer);
/*     */     
/* 287 */     identifier = evalProp("\\transition", currentToken, itemTokenizer);
/*     */     
/* 289 */     if (identifier == null || identifier.equals("")) {
/* 290 */       return null;
/*     */     }
/* 292 */     currentToken = nextToken(itemTokenizer);
/* 293 */     name = evalProp("\\name", currentToken, itemTokenizer);
/*     */     
/* 295 */     if (!name.equals("")) {
/* 296 */       currentToken = nextToken(itemTokenizer);
/*     */     } else {
/* 298 */       Out.println("transition" + identifier + ": no NAME given, got " + identifier);
/*     */       
/* 300 */       name = identifier;
/*     */     } 
/*     */     
/* 303 */     this.currentTransId = (short)(this.currentTransId + 1); Transition ret = new Transition(identifier, name, this.currentTransId);
/* 304 */     if (itemTokenizer.hasMoreTokens()) {
/* 305 */       function = evalProp("\\function", currentToken, itemTokenizer);
/* 306 */       if (function != null) {
/* 307 */         ret.function = function;
/*     */       }
/*     */     } 
/*     */     
/* 311 */     this.pn.allNodes().put(identifier, ret);
/* 312 */     this.pn.identifier().put(ret, identifier);
/* 313 */     return ret;
/*     */   }
/*     */   
/*     */   private String evalLike(String token, StringTokenizer stk) {
/* 317 */     String prop = null;
/* 318 */     if ("\\like".equals(token)) {
/* 319 */       prop = nextToken(stk);
/* 320 */       if (stk.hasMoreTokens()) {
/* 321 */         return null;
/*     */       }
/*     */     } else {
/* 324 */       return "";
/*     */     } 
/* 326 */     return prop;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkOther(String token) {
/* 331 */     if ("\\like".equals(token)) {
/* 332 */       return true;
/*     */     }
/* 334 */     if ("\\init".equals(token)) {
/* 335 */       return true;
/*     */     }
/* 337 */     if ("\\capacity".equals(token)) {
/* 338 */       return true;
/*     */     }
/* 340 */     if ("\\name".equals(token)) {
/* 341 */       return true;
/*     */     }
/* 343 */     if ("\\value".equals(token)) {
/* 344 */       return true;
/*     */     }
/* 346 */     if ("\\type".equals(token)) {
/* 347 */       return true;
/*     */     }
/* 349 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private String evalProp(String property, String token, StringTokenizer stk) throws Exception {
/* 354 */     String prop = null;
/*     */     
/* 356 */     if (property.equals(token)) {
/* 357 */       prop = nextToken(stk);
/*     */     } else {
/* 359 */       return "";
/*     */     } 
/* 361 */     if (prop == null || checkOther(prop)) {
/* 362 */       throw new Exception("parsing error in line " + lineCounter + ": missing value for " + property);
/*     */     }
/*     */     
/* 365 */     return prop;
/*     */   }
/*     */   
/*     */   private String evalName(String token, StringTokenizer stk) throws Exception {
/*     */     String prop;
/* 370 */     if ("\\name".equals(token)) {
/* 371 */       prop = nextToken(stk);
/*     */     } else {
/* 373 */       return "";
/*     */     } 
/* 375 */     if (checkOther(prop)) {
/* 376 */       throw new Exception("parsing error in line " + lineCounter + ": missing name");
/*     */     }
/*     */     
/* 379 */     return prop;
/*     */   }
/*     */   
/*     */   private String evalInit(String token, StringTokenizer stk) throws Exception {
/*     */     String prop;
/* 384 */     if ("\\init".equals(token)) {
/* 385 */       prop = nextToken(stk);
/*     */     } else {
/* 387 */       return "";
/*     */     } 
/* 389 */     if (checkOther(prop)) {
/* 390 */       throw new Exception("parsing error in line " + lineCounter + ": missing value for INIT");
/*     */     }
/*     */     
/* 393 */     return prop;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object loadConstant(PlaceTransitionNet pn) throws SafetyException, UnknownArcException, Exception {
/* 399 */     StringTokenizer lineTokenizer = null;
/* 400 */     StringTokenizer itemTokenizer = new StringTokenizer(currentLine, "{} ");
/* 401 */     String currentToken = nextToken(itemTokenizer);
/*     */     
/* 403 */     currentToken = nextToken(itemTokenizer);
/*     */     
/* 405 */     String type = evalProp("\\type", currentToken, itemTokenizer);
/*     */     
/* 407 */     if (type == null || type.equals("")) {
/* 408 */       return null;
/*     */     }
/*     */     
/* 411 */     currentToken = nextToken(itemTokenizer);
/*     */     
/* 413 */     String name = evalProp("\\name", currentToken, itemTokenizer);
/*     */     
/* 415 */     if (!name.equals("")) {
/* 416 */       currentToken = nextToken(itemTokenizer);
/*     */     }
/*     */     
/* 419 */     String value = evalProp("\\value", currentToken, itemTokenizer);
/*     */     
/* 421 */     if (!name.equals("")) {
/* 422 */       currentToken = nextToken(itemTokenizer);
/*     */     }
/*     */     
/* 425 */     Constant c = null;
/* 426 */     if (type.equals("int")) {
/* 427 */       c = new IntConstant(name, value);
/* 428 */     } else if (type.equals("double")) {
/* 429 */       c = new DoubleConstant(name, value);
/*     */     } 
/* 431 */     Out.println("Cosntant of type " + type + " with name " + name + " and " + value);
/*     */     
/* 433 */     this.constantRegistry.register(name, c);
/*     */ 
/*     */     
/* 436 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object loadArc(PlaceTransitionNet pn) throws SafetyException, UnknownArcException, Exception {
/* 447 */     int weight = 0;
/* 448 */     PNNode from = null;
/* 449 */     PNNode to = null;
/*     */     
/* 451 */     StringTokenizer itemTokenizer = new StringTokenizer(currentLine, "{} ");
/*     */     
/* 453 */     String currentToken = nextToken(itemTokenizer);
/* 454 */     String identifier = evalProp("\\arc", currentToken, itemTokenizer);
/*     */ 
/*     */     
/* 457 */     currentToken = nextToken(itemTokenizer);
/* 458 */     String fromString = evalProp("\\from", currentToken, itemTokenizer);
/*     */     
/* 460 */     if (!fromString.equals("")) {
/* 461 */       currentToken = nextToken(itemTokenizer);
/* 462 */       from = pn.lookUp(fromString);
/* 463 */       if (from == null) {
/* 464 */         throw new Exception("node " + fromString + " not specified");
/*     */       }
/*     */     } else {
/* 467 */       throw new Exception("parsing error in line " + lineCounter + ": \\from was not specified!");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 472 */     String toString = evalProp("\\to", currentToken, itemTokenizer);
/* 473 */     if (!toString.equals("")) {
/* 474 */       currentToken = nextToken(itemTokenizer);
/* 475 */       to = pn.lookUp(toString);
/* 476 */       if (to == null) {
/* 477 */         throw new Exception("node " + toString + " not specified");
/*     */       }
/*     */     } else {
/* 480 */       throw new Exception("parsing error in line " + lineCounter + ": \\to was not specified!");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 485 */     String w = evalProp("\\weight", currentToken, itemTokenizer);
/*     */     
/* 487 */     if (!w.equals("")) {
/* 488 */       currentToken = nextToken(itemTokenizer);
/*     */       try {
/* 490 */         weight = Integer.parseInt(w);
/* 491 */       } catch (NumberFormatException nfe) {
/*     */         try {
/* 493 */           weight = this.constantRegistry.lookUpIntConstant(w);
/* 494 */         } catch (Exception e) {
/* 495 */           throw new Exception("Parse error in line " + currentLine + " : " + e
/* 496 */               .getMessage());
/*     */         } 
/*     */       } 
/*     */       
/* 500 */       if (weight > 1) {
/* 501 */         pn.ord = false;
/*     */       }
/*     */     } else {
/* 504 */       weight = 1;
/*     */     } 
/*     */     
/* 507 */     String type = evalProp("\\type", currentToken, itemTokenizer);
/* 508 */     if (!type.equals("")) {
/* 509 */       int edgeType; currentToken = nextToken(itemTokenizer);
/*     */ 
/*     */       
/* 512 */       if (type.equals("ordinary")) {
/* 513 */         edgeType = PlaceTransitionNet.EDGE;
/* 514 */       } else if (type.equals("readarc")) {
/* 515 */         edgeType = PlaceTransitionNet.READ_EDGE;
/* 516 */       } else if (type.equals("inhibitor")) {
/* 517 */         edgeType = PlaceTransitionNet.INHIBITOR_EDGE;
/* 518 */         System.out.println("Inhibitor edge found, weight " + w);
/* 519 */       } else if (type.equals("equalarc")) {
/* 520 */         edgeType = PlaceTransitionNet.EQUAL_EDGE;
/* 521 */       } else if (type.equals("resetarc")) {
/* 522 */         edgeType = PlaceTransitionNet.RESET_EDGE;
/* 523 */       } else if (type.equals("modifierarc")) {
/* 524 */         edgeType = PlaceTransitionNet.MODIFIER_EDGE;
/*     */       } else {
/* 526 */         throw new Exception("error:  arc type (" + type + ")  is unknown. Charlie supports only ordinary,read,inhibitor,equal and reset arcs and modifier arcs!");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 532 */       pn.addEdge(from, to, weight, edgeType);
/*     */     } 
/* 534 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/ApnnReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */