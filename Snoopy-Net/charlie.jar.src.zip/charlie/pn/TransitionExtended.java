/*     */ package charlie.pn;
/*     */ 
/*     */ import charlie.ds.BitSet;
/*     */ 
/*     */ public class TransitionExtended
/*     */   extends Transition {
/*     */   public Marking read;
/*     */   
/*     */   public TransitionExtended(String name, short id, Marking pre, Marking post) {
/*  10 */     super(name, id);
/*  11 */     this.post = post;
/*  12 */     this.pre = pre;
/*  13 */     this.read = new SortedElementsDynamic(true);
/*  14 */     this.read.name = "TransitionExtended read";
/*  15 */     this.inhibitor = new SortedElementsDynamic(true);
/*  16 */     this.reset = new SortedElementsDynamic(true);
/*  17 */     this.reset.name = "TransitionExtended reset";
/*     */   }
/*     */   public Marking inhibitor; public Marking reset;
/*     */   public void addReadConnectedPlaceId(int id, int weight) {
/*     */     try {
/*  22 */       this.read.addPlace(id, weight);
/*  23 */     } catch (Exception e) {
/*  24 */       e.printStackTrace();
/*  25 */       System.exit(1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addInhibitorConnectedPlaceId(int id, int weight) {
/*     */     try {
/*  33 */       this.inhibitor.addPlace(id, weight);
/*  34 */     } catch (Exception e) {
/*  35 */       e.printStackTrace();
/*  36 */       System.exit(1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addResetConnectedPlaceId(int id) {
/*     */     try {
/*  42 */       this.reset.addPlace(id, 1);
/*  43 */     } catch (Exception e) {
/*  44 */       e.printStackTrace();
/*  45 */       System.exit(1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transformSortedPlaces() throws SafetyException, ExceedsByteException {
/*  53 */     this.read = this.read.toArray();
/*  54 */     this.inhibitor = this.inhibitor.toArray();
/*  55 */     this.reset = this.reset.toArray();
/*  56 */     super.transformSortedPlaces();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canFire(State s) {
/*  61 */     boolean b = false;
/*  62 */     if (this.read.isSubSet(s.getPlaceMarking()) && this.inhibitor.allLess(s.getPlaceMarking()))
/*  63 */       b = super.canFire(s); 
/*  64 */     return b;
/*     */   }
/*     */   
/*     */   public NodeSet getReadConnectPlaces() {
/*  68 */     BitSet bs = new BitSet(LookUpTable.places());
/*  69 */     for (int i = 0; i < this.read.size(); i++) {
/*  70 */       bs.insert(UnsignedByte.unsign(this.read.getId(i)));
/*     */     }
/*  72 */     return new PlaceSet(bs);
/*     */   }
/*     */   
/*     */   public NodeSet getInhibitorConnectPlaces() {
/*  76 */     BitSet bs = new BitSet(LookUpTable.places());
/*  77 */     for (int i = 0; i < this.inhibitor.size(); i++) {
/*  78 */       bs.insert(UnsignedByte.unsign(this.inhibitor.getId(i)));
/*     */     }
/*  80 */     return new PlaceSet(bs);
/*     */   }
/*     */   
/*     */   public String toString() {
/*  84 */     return getName() + "  " + this.read.toString() + " pre " + preNodes() + " post " + postNodes();
/*     */   }
/*     */   
/*     */   public Marking fire(Marking state) throws SafetyException, ExceedsByteException {
/*     */     Marking newState;
/*  89 */     firstCall = (byte)((firstCall + 1) % 2);
/*  90 */     if (firstCall > 0) {
/*  91 */       SortedElementsFactory.safeMode(true);
/*  92 */       if (!(state instanceof SortedElementsBitSet)) {
/*  93 */         SortedElementsFactory.safeMode(false);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/*  99 */       if (state == null) return null; 
/* 100 */       int p = 0;
/* 101 */       p = this.pre.isSubSet2(state);
/*     */       
/* 103 */       if (p < 0) return null;
/*     */       
/* 105 */       newState = SortedElementsFactory.getSortedPlaces(p + this.post.size());
/* 106 */       newState.name = "TransitionExtended.fire newState";
/* 107 */       int i = 0;
/* 108 */       int r = 0;
/* 109 */       int ipre = 0;
/* 110 */       int ipost = 0;
/* 111 */       Weight currentPre = this.pre.get(ipre);
/* 112 */       Weight currentPost = this.post.get(ipost);
/* 113 */       while (ipre < this.pre.size()) {
/* 114 */         int curId = currentPre.getId();
/* 115 */         while (i < state.size() && state.get(i).getId() != curId) {
/* 116 */           Weight place = state.get(i);
/* 117 */           newState.addPlace(place.getId(), place.getToken());
/* 118 */           while (ipost < this.post.size() && currentPost.getId() < curId) {
/* 119 */             newState.addPlace(currentPost.getId(), currentPost.getToken());
/* 120 */             currentPost = this.post.get(++ipost);
/*     */           } 
/* 122 */           i++;
/*     */         } 
/*     */ 
/*     */         
/* 126 */         if (i == state.size() || currentPre.less(state.get(i)) < 0) {
/* 127 */           return null;
/*     */         }
/*     */         
/* 130 */         if (state.get(i).getToken() == Integer.MAX_VALUE) {
/* 131 */           newState.addPlace(curId, 2147483647);
/*     */         }
/*     */         else {
/*     */           
/* 135 */           int token = state.get(i).getToken() - currentPre.getToken();
/*     */           
/* 137 */           while (r < this.reset.size() && this.reset.getId(r) < curId) {
/* 138 */             r++;
/*     */           }
/*     */           
/* 141 */           if ((r == this.reset.size() || this.reset.getId(r) > curId) && 
/* 142 */             token > 0) {
/* 143 */             newState.addPlace(curId, token);
/*     */           }
/*     */         } 
/* 146 */         currentPre = this.pre.get(++ipre);
/* 147 */         i++;
/*     */       } 
/*     */       
/* 150 */       while (i < state.size()) {
/* 151 */         Weight place = state.get(i);
/* 152 */         while (r < this.reset.size() && this.reset.getId(r) < place.getId()) {
/* 153 */           r++;
/*     */         }
/* 155 */         if (r == this.reset.size() || this.reset.getId(r) > place.getId())
/* 156 */           newState.addPlace(place.getId(), place.getToken()); 
/* 157 */         while (ipost < this.post.size() && currentPost.getId() < place.getId()) {
/* 158 */           newState.addPlace(currentPost.getId(), currentPost.getToken());
/* 159 */           currentPost = this.post.get(++ipost);
/*     */         } 
/* 161 */         i++;
/*     */       } 
/* 163 */       while (ipost < this.post.size()) {
/* 164 */         newState.addPlace(currentPost.getId(), currentPost.getToken());
/* 165 */         currentPost = this.post.get(++ipost);
/*     */       } 
/* 167 */     } catch (SafetyException e) {
/*     */       
/*     */       try {
/* 170 */         SortedElementsFactory.safeMode(false);
/* 171 */         newState = fire(state);
/* 172 */       } catch (ExceedsByteException eb) {
/* 173 */         SortedElementsFactory.byteMode(false);
/* 174 */         newState = fire(state);
/*     */       } 
/*     */     } 
/*     */     
/* 178 */     firstCall = 0;
/* 179 */     return newState;
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeSet preNodes() {
/* 184 */     NodeSet pre = super.preNodes();
/* 185 */     pre.union(getReadConnectPlaces());
/* 186 */     return pre;
/*     */   }
/*     */   
/*     */   public NodeSet postNodes() {
/* 190 */     NodeSet post = super.postNodes();
/* 191 */     post.union(getReadConnectPlaces());
/* 192 */     return post;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/TransitionExtended.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */