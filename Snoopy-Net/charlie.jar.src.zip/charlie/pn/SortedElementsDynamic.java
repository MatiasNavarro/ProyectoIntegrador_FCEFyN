/*     */ package charlie.pn;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import java.util.Collection;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SortedElementsDynamic
/*     */   extends Marking
/*     */ {
/*     */   private boolean isPlaceMarking;
/*     */   private int size;
/*     */   private NodeT first;
/*     */   private LookUpTable lt;
/*     */   
/*     */   public int getTokenById(int id) {
/*  20 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedElementsDynamic(boolean isPlaceMarking) {
/*  26 */     this.size = 0;
/*  27 */     this.first = new NodeT();
/*  28 */     this.first.prev = null;
/*  29 */     this.isPlaceMarking = isPlaceMarking;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addPlace(int id, int token) {
/*  36 */     int ret = addToken(id, token);
/*  37 */     return ret;
/*     */   }
/*     */   
/*     */   public NodeT getFirst() {
/*  41 */     return this.first;
/*     */   }
/*     */   
/*     */   public NodeT getFirstNode() {
/*  45 */     return this.first.next;
/*     */   }
/*     */ 
/*     */   
/*     */   public int addToken(int id, int token) {
/*  50 */     NodeT current = getNode(id);
/*  51 */     if (current.next == null || (current.next != null && current.next.place.getId() > id)) {
/*  52 */       NodeT newNode = new NodeT(LookUpTable.addPlace(id, token));
/*  53 */       newNode.place = LookUpTable.addPlace(id, token);
/*  54 */       newNode.next = current.next;
/*  55 */       newNode.prev = current;
/*  56 */       current.next = newNode;
/*  57 */       this.size++;
/*  58 */       return token;
/*     */     } 
/*  60 */     token += current.next.place.getToken();
/*  61 */     current.next.place = LookUpTable.addPlace(id, token);
/*  62 */     return token;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private NodeT getNode(int id) {
/*  68 */     NodeT current = this.first;
/*  69 */     while (current.next != null && current.next.place.getId() < id) {
/*  70 */       current = current.next;
/*     */     }
/*  72 */     return current;
/*     */   }
/*     */   
/*     */   public int size() {
/*  76 */     return this.size;
/*     */   }
/*     */   
/*     */   public int getId(int index) {
/*  80 */     Weight w = get(index);
/*  81 */     if (w != null) return w.getId(); 
/*  82 */     return UnsignedByte.min - 1;
/*     */   }
/*     */   
/*     */   public int getToken(int index) {
/*  86 */     Weight w = get(index);
/*  87 */     if (w != null) return w.getToken(); 
/*  88 */     return UnsignedByte.min - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Weight get(int index) {
/*  94 */     NodeT node = getFirstNode();
/*  95 */     int i = 0;
/*  96 */     while (i < index && node != null) {
/*  97 */       node = node.next;
/*  98 */       i++;
/*     */     } 
/* 100 */     if (node != null) return node.place; 
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void deleteNext(NodeT node) {
/* 106 */     NodeT h = node.next;
/* 107 */     node.next = node.next.next;
/*     */     
/* 109 */     this.size--;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 114 */     return isEqual(obj);
/*     */   }
/*     */   
/*     */   public Marking copy() {
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqual2(Marking sp) {
/* 123 */     if (sp.size() != size()) return false; 
/* 124 */     for (int i = 0; i < this.size; i++) {
/* 125 */       if (!get(i).equals(sp.get(i))) return false; 
/*     */     } 
/* 127 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isEqual(Object obj) {
/* 131 */     if (!(obj instanceof SortedElementsDynamic)) return false; 
/* 132 */     SortedElementsDynamic sps = (SortedElementsDynamic)obj;
/* 133 */     if (this.size != sps.size()) return false;
/*     */     
/* 135 */     NodeT current = this.first.next;
/* 136 */     NodeT current2 = sps.first.next;
/* 137 */     while (current != null) {
/* 138 */       if (!current.place.isEqual(current2.place))
/*     */       {
/* 140 */         return false;
/*     */       }
/* 142 */       current = current.next;
/* 143 */       current2 = current2.next;
/*     */     } 
/*     */     
/* 146 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection scapeGoats(Marking sp) {
/* 151 */     if (!(sp instanceof SortedElementsByteArray)) return null; 
/* 152 */     SortedElementsByteArray spa = (SortedElementsByteArray)sp;
/* 153 */     Collection<Integer> c = new Vector();
/* 154 */     NodeT current = this.first.next;
/* 155 */     int i = 0;
/* 156 */     while (current != null) {
/* 157 */       int curId = current.place.getId();
/* 158 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 159 */         i++;
/*     */       }
/* 161 */       if (i == spa.size() || current.place.less(spa.get(i)) < 0) {
/* 162 */         c.add(new Integer(curId));
/* 163 */         i = 0;
/* 164 */         current = current.next;
/*     */         
/*     */         continue;
/*     */       } 
/* 168 */       current = current.next;
/* 169 */       i++;
/*     */     } 
/* 171 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int fSG(Marking sp) {
/* 178 */     if (!(sp instanceof SortedElementsByteArray)) return UnsignedByte.min - 1; 
/* 179 */     SortedElementsByteArray spa = (SortedElementsByteArray)sp;
/*     */     
/* 181 */     NodeT current = this.first.next;
/* 182 */     int i = 0;
/* 183 */     while (current != null) {
/* 184 */       int curId = current.place.getId();
/* 185 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 186 */         i++;
/*     */       }
/* 188 */       if (i == spa.size() || current.place.less(spa.get(i)) < 0) return curId; 
/* 189 */       current = current.next;
/* 190 */       i++;
/*     */     } 
/* 192 */     return UnsignedByte.min - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int isSubSet2(Marking sp) {
/* 200 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean retains(Marking sp) {
/* 204 */     if (!(sp instanceof SortedElementsDynamic)) return false; 
/* 205 */     SortedElementsDynamic s = (SortedElementsDynamic)sp;
/* 206 */     NodeT current = this.first.next;
/*     */     
/* 208 */     while (current != null) {
/* 209 */       NodeT current2 = s.first.next;
/* 210 */       int curId = current.place.getId();
/* 211 */       while (current2 != null && current2.place.getId() < curId) {
/* 212 */         current2 = current2.next;
/*     */       }
/* 214 */       if (current2 != null && curId == current2.place.getId()) return true; 
/* 215 */       current2 = s.first.next;
/* 216 */       current = current.next;
/*     */     } 
/* 218 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 222 */     StringBuffer buf = new StringBuffer();
/* 223 */     NodeT current = this.first.next;
/*     */     
/* 225 */     while (current != null) {
/* 226 */       buf.append(current.place.getId());
/* 227 */       buf.append(" ");
/* 228 */       buf.append(current.place.getToken());
/* 229 */       buf.append(" ");
/* 230 */       NodeT h = current.next;
/*     */       
/* 232 */       current = h;
/*     */     } 
/* 234 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Marking toArray() throws SafetyException, ExceedsByteException {
/*     */     Marking ret;
/* 240 */     if (this.isPlaceMarking) {
/* 241 */       ret = SortedElementsFactory.getSortedPlaces(size());
/* 242 */       ret.name += " SEDynamic.toArray() places ->" + this.name;
/*     */     } else {
/* 244 */       ret = SortedElementsFactory.getSortedPlacesForTransition(size());
/* 245 */       ret.name += " SEDynamic.toArray() transitions->" + this.name;
/*     */     } 
/*     */     
/*     */     try {
/* 249 */       int i = 0;
/* 250 */       NodeT nodeT = this.first.next;
/*     */       
/* 252 */       while (nodeT != null) {
/* 253 */         ret.addPlace(nodeT.place.getId(), nodeT.place.getToken());
/* 254 */         NodeT h = nodeT.next;
/*     */         
/* 256 */         nodeT = h;
/*     */       } 
/* 258 */     } catch (SafetyException e) {
/*     */       
/* 260 */       SortedElementsFactory.safeMode(false);
/*     */       
/*     */       try {
/* 263 */         ret = toArray();
/* 264 */         SortedElementsFactory.safeMode(true);
/* 265 */         return ret;
/* 266 */       } catch (ExceedsByteException eb) {
/* 267 */         DebugCounter.inc("SortedElementsDynamic.toArray() SE/ExeedsByteException caught!");
/* 268 */         SortedElementsFactory.weightsMode(true);
/*     */         
/* 270 */         ret = toArray();
/* 271 */         SortedElementsFactory.safeMode(true);
/* 272 */         return ret;
/*     */       }
/*     */     
/*     */     }
/* 276 */     catch (ExceedsByteException eb) {
/* 277 */       DebugCounter.inc("SortedElementsDynamic.toArray() ExeedsByteException caught!");
/* 278 */       SortedElementsFactory.weightsMode(true);
/* 279 */       ret = toArray();
/* 280 */       SortedElementsFactory.safeMode(true);
/* 281 */       ret.name += " SED final ";
/* 282 */       return ret;
/*     */     } 
/* 284 */     NodeT current = this.first.next;
/*     */     
/* 286 */     while (current != null) {
/* 287 */       NodeT h = current.next;
/*     */       
/* 289 */       current = h;
/*     */     } 
/* 291 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection covers(Marking sp) {
/* 297 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SortedElementsDynamic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */