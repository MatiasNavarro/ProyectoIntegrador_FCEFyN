package charlie.pn;

public interface Weight {
  int getToken();
  
  int addToken(int paramInt);
  
  int reduceToken(int paramInt);
  
  int getId();
  
  int less(Weight paramWeight);
  
  boolean isEqual(Weight paramWeight);
  
  String toString();
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Weight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */