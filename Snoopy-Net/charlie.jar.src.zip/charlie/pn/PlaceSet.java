/*     */ package charlie.pn;
/*     */ 
/*     */ import charlie.ds.BitSet;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlaceSet
/*     */   extends NodeSet
/*     */ {
/*     */   private static final long serialVersionUID = -3714712535915685926L;
/*     */   
/*     */   public PlaceSet(int size) {
/*  16 */     super(size);
/*     */   }
/*     */   
/*     */   public PlaceSet(BitSet bs) {
/*  20 */     super(bs);
/*     */   }
/*     */   
/*     */   public PlaceSet(int size, int filledTo) {
/*  24 */     super(size, filledTo);
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeSet getEnvironment() {
/*  29 */     BitSet bs = new BitSet(LookUpTable.transitions()); int i;
/*  30 */     for (i = 0; i < LookUpTable.places(); i++) {
/*  31 */       if (this.nodes.member(i)) {
/*  32 */         bs.union((getNet().getPlaceByIndex((short)i).postNodes()).nodes);
/*     */       }
/*     */     } 
/*  35 */     for (i = 0; i < LookUpTable.places(); i++) {
/*  36 */       if (this.nodes.member(i)) {
/*  37 */         bs.union((getNet().getPlaceByIndex((short)i).preNodes()).nodes);
/*     */       }
/*     */     } 
/*  40 */     return new TransitionSet(bs);
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeSet getPre() {
/*  45 */     BitSet bs = new BitSet(LookUpTable.transitions());
/*  46 */     for (int i = 0; i < LookUpTable.places(); i++) {
/*  47 */       if (this.nodes.member(i)) {
/*  48 */         bs.union(getNet().getPlaceByIndex((short)i).getPreBit());
/*     */       }
/*     */     } 
/*  51 */     return new TransitionSet(bs);
/*     */   }
/*     */   
/*     */   public boolean isTrap() {
/*  55 */     return getPost().subSet(getPre());
/*     */   }
/*     */   
/*     */   public boolean isDeadlock() {
/*  59 */     return getPre().subSet(getPost());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NodeSet intersection(NodeSet ns) {
/*  65 */     if (!getClass().equals(ns.getClass())) {
/*  66 */       System.out.println("problem in intsec: " + getClass() + " : " + ns.getClass());
/*  67 */       System.exit(1);
/*     */     } 
/*  69 */     return new PlaceSet(this.nodes.intersection(ns.nodes));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPinvariant() {
/*  74 */     TransitionSet pre = (TransitionSet)getPre();
/*  75 */     if (!pre.equals(getPost())) {
/*  76 */       return false;
/*     */     }
/*  78 */     int in = 0;
/*  79 */     int out = 0;
/*  80 */     for (Iterator<Integer> it = pre.iterator(); it.hasNext(); ) {
/*  81 */       Transition t = getNet().getTransition((short)((Integer)it.next()).intValue());
/*     */       
/*     */       int i;
/*  84 */       for (i = 0; i < t.getPre().size(); i++) {
/*  85 */         if (member(t.getPre().getId(i))) {
/*  86 */           in += t.getPre().getToken(i);
/*     */         }
/*     */       } 
/*  89 */       for (i = 0; i < t.getPost().size(); i++) {
/*  90 */         if (member(t.getPost().getId(i))) {
/*  91 */           out += t.getPost().getToken(i);
/*     */         }
/*     */       } 
/*     */     } 
/*  95 */     if (out != in) {
/*  96 */       return false;
/*     */     }
/*  98 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NodeSet getPost() {
/* 104 */     BitSet bs = new BitSet(LookUpTable.transitions());
/* 105 */     for (int i = 0; i < LookUpTable.places(); i++) {
/* 106 */       if (this.nodes.member(i)) {
/* 107 */         bs.union(getNet().getPlaceByIndex((short)i).getPostBit());
/*     */       }
/*     */     } 
/* 110 */     return new TransitionSet(bs);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 115 */     if (isEmpty()) {
/* 116 */       return "\tempty set";
/*     */     }
/* 118 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 120 */     for (Iterator<Integer> it = iterator(); it.hasNext(); ) {
/* 121 */       Place p = getNet().getPlaceByIndex((short)((Integer)it.next()).intValue());
/* 122 */       sb.append("\t|");
/* 123 */       sb.append(p.getOrgId());
/* 124 */       sb.append(".");
/* 125 */       sb.append(p.getName());
/* 126 */       sb.append("\t:1");
/* 127 */       if (it.hasNext()) {
/* 128 */         sb.append(",\n");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 133 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public PlaceSet copy() {
/* 138 */     return new PlaceSet(this.nodes.copy());
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getNameArray() {
/* 143 */     String[] ret = new String[size()];
/* 144 */     int i = 0;
/* 145 */     for (Iterator<Integer> it = iterator(); it.hasNext(); ) {
/* 146 */       int j = ((Integer)it.next()).intValue();
/* 147 */       String name = getNet().getPlaceByIndex(j).getName();
/* 148 */       ret[i++] = name;
/*     */     } 
/* 150 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getIdArray() {
/* 155 */     String[] ret = new String[size()];
/* 156 */     int i = 0;
/* 157 */     for (Iterator<Integer> it = iterator(); it.hasNext(); ) {
/* 158 */       int id = ((Integer)it.next()).intValue();
/* 159 */       ret[i++] = Integer.toString(id);
/*     */     } 
/* 161 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getOrigIdArray() {
/* 166 */     String[] ret = new String[size()];
/* 167 */     int i = 0;
/* 168 */     for (Iterator<Integer> it = iterator(); it.hasNext(); ) {
/* 169 */       int j = ((Integer)it.next()).intValue();
/*     */       
/* 171 */       int id = getNet().getPlaceById(j).getOrgId();
/* 172 */       ret[i++] = Integer.toString(id);
/*     */     } 
/* 174 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean marksPlaceSetSufficient(Marking m) {
/* 178 */     for (Iterator<Integer> it = iterator(); it.hasNext(); ) {
/* 179 */       Place p = getNet().getPlaceByIndex(((Integer)it.next()).intValue());
/* 180 */       if (m.marksPlaceSufficient(p.getId(), p.vminus())) {
/* 181 */         return true;
/*     */       }
/*     */     } 
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public PlaceSet maxTrap() {
/* 189 */     PlaceSet placeSet = copy();
/* 190 */     PlaceSet q = new PlaceSet(getNet().places());
/* 191 */     while (!q.equals(placeSet)) {
/* 192 */       q = placeSet.copy();
/* 193 */       NodeSet qf = placeSet.getPost();
/*     */       
/* 195 */       NodeSet fq = placeSet.getPre();
/* 196 */       qf.diff(fq);
/* 197 */       placeSet.diff(qf.getPre());
/*     */     } 
/*     */ 
/*     */     
/* 201 */     return q;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PNNode getNode(int index, boolean ownNodeClass) {
/* 224 */     if (ownNodeClass) {
/* 225 */       return getNet().getPlaceByIndex(index);
/*     */     }
/* 227 */     return getNet().getTransition((short)index);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/PlaceSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */