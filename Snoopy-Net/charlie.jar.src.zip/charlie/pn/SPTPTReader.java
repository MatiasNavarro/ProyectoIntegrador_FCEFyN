/*     */ package charlie.pn;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import java.io.InputStream;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPTPTReader
/*     */   extends PetriNetReader
/*     */ {
/*  19 */   static int nc = -1;
/*     */   
/*  21 */   static int PLACE = 0;
/*     */   
/*  23 */   static int TRANSITION = 1;
/*  24 */   static int IGNORE = 4;
/*     */   
/*  26 */   private final int INTERVALL_TIME = 1;
/*  27 */   private final int CONSTANT_TIME = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   private int readingTime;
/*     */ 
/*     */ 
/*     */   
/*     */   public SPTPTReader() {
/*  36 */     if (evalVersion()) {
/*  37 */       PetriNetReaderFactory.registerReader(".sptpt", this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SPTPTReader(String filename, PlaceTransitionNet pn, ConstantInterface cI) throws Exception {
/*  51 */     this.file = filename;
/*     */     
/*  53 */     this.pn = pn;
/*  54 */     if (pn.getName().endsWith(".sptpt")) {
/*  55 */       pn.setName(pn.getName().substring(0, pn.getName().length() - 6));
/*     */     }
/*  57 */     this.pn.TIMED_NET_TYPE = 4;
/*  58 */     this.pn.setTimedNet(true);
/*  59 */     DebugCounter.inc("SPTPTReader: pn.isTimedNet() = " + pn.isTimedNet());
/*     */     
/*  61 */     initReader(cI);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void read() {
/*     */     try {
/*  75 */       this.placeCounter = 0;
/*  76 */       InputStream in = getInputStream(this.file);
/*  77 */       XMLInputFactory factory = XMLInputFactory.newInstance();
/*  78 */       XMLStreamReader parser = factory.createXMLStreamReader(in);
/*     */       
/*  80 */       StringBuilder spacer = new StringBuilder();
/*  81 */       while (parser.hasNext()) {
/*     */         String ln;
/*  83 */         int i, event = parser.next();
/*     */         
/*  85 */         switch (event) {
/*     */           case 7:
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 8:
/*  92 */             parser.close();
/*     */             break;
/*     */           case 13:
/*     */             break;
/*     */           case 1:
/*  97 */             spacer.append("  ");
/*  98 */             ln = parser.getLocalName();
/*  99 */             if (ln.equals("node") || ln.equals("edge")) {
/* 100 */               readNode(parser);
/*     */               break;
/*     */             } 
/* 103 */             for (i = 0; i < parser.getAttributeCount(); i++) {
/* 104 */               parser.getAttributeLocalName(i);
/* 105 */               String av = parser.getAttributeValue(i);
/* 106 */               if (ln.equals("nodeclass") || ln.equals("edgeclass")) {
/* 107 */                 eval(av);
/*     */               }
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 120 */     } catch (Exception e) {
/* 121 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Place readPlace(XMLStreamReader parser, String identifier) {
/*     */     try {
/* 138 */       String name = "";
/* 139 */       String init = "";
/* 140 */       String id = "";
/* 141 */       while (parser.hasNext()) {
/* 142 */         String ln; int event = parser.next();
/*     */         
/* 144 */         switch (event) {
/*     */           case 2:
/* 146 */             if (parser.getLocalName().equals("node")) {
/* 147 */               if (name.equals("")) {
/* 148 */                 name = "P_" + id;
/*     */               }
/* 150 */               Place ret = new Place(identifier, name, Byte.parseByte(init), this.currentPlaceId++, this.placeCounter++, 0);
/*     */               
/* 152 */               return ret;
/*     */             } 
/*     */           
/*     */           case 1:
/* 156 */             ln = parser.getLocalName();
/* 157 */             if (ln.equals("attribute")) {
/* 158 */               for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 159 */                 parser.getAttributeLocalName(i);
/* 160 */                 String av = parser.getAttributeValue(i);
/* 161 */                 if (av.equals("Name")) {
/* 162 */                   name = replaceSpace(readAttribute(parser)); break;
/*     */                 } 
/* 164 */                 if (av.equals("ID")) {
/* 165 */                   id = readAttribute(parser); break;
/*     */                 } 
/* 167 */                 if (av.equals("Marking")) {
/* 168 */                   init = readAttribute(parser);
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 176 */     } catch (Exception e) {
/* 177 */       e.printStackTrace();
/*     */     } 
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static boolean evalVersion() {
/* 184 */     String version = "";
/*     */     try {
/* 186 */       version = System.getProperty("java.version");
/*     */       
/* 188 */       if (version.startsWith("1.6")) {
/* 189 */         return true;
/*     */       }
/* 191 */     } catch (Exception exc) {
/* 192 */       exc.printStackTrace();
/* 193 */       return false;
/*     */     } 
/* 195 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readNode(XMLStreamReader parser) {
/* 205 */     String id = "";
/* 206 */     int net = -1;
/* 207 */     String source = "";
/* 208 */     String target = "";
/* 209 */     for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 210 */       String lv = parser.getAttributeLocalName(i);
/* 211 */       String av = parser.getAttributeValue(i);
/* 212 */       if (lv.equals("net")) {
/* 213 */         net = Integer.parseInt(av);
/* 214 */       } else if (lv.equals("id")) {
/* 215 */         id = av;
/* 216 */       } else if (lv.equals("source")) {
/* 217 */         source = av;
/* 218 */       } else if (lv.equals("target")) {
/* 219 */         target = av;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 224 */     if (nc == PLACE) {
/* 225 */       PNNode n = readPlace(parser, id);
/*     */       
/* 227 */       Place p = (Place)n;
/*     */       
/* 229 */       this.pn.allNodes().put(id, n);
/* 230 */       this.pn.identifier().put(n, id);
/* 231 */       this.pn.addPlace((Place)n);
/* 232 */       if (p.getToken() > 0)
/*     */       {
/*     */         
/* 235 */         this.initialMarking.add(p);
/* 236 */         this.initialMarking.add(new Integer(p.getToken()));
/*     */       }
/*     */     
/*     */     }
/* 240 */     else if (nc == TRANSITION) {
/* 241 */       PNNode n = readTransition(parser, id);
/* 242 */       this.pn.allNodes().put(id, n);
/* 243 */       this.pn.identifier().put(n, id);
/* 244 */       this.pn.addTransition((Transition)n);
/*     */     }
/* 246 */     else if (nc == PlaceTransitionNet.EDGE) {
/* 247 */       readEdge(parser, source, target, PlaceTransitionNet.EDGE);
/* 248 */     } else if (nc == PlaceTransitionNet.INHIBITOR_EDGE) {
/* 249 */       readEdge(parser, source, target, PlaceTransitionNet.INHIBITOR_EDGE);
/* 250 */     } else if (nc == PlaceTransitionNet.READ_EDGE) {
/* 251 */       readEdge(parser, source, target, PlaceTransitionNet.READ_EDGE);
/* 252 */     } else if (nc == PlaceTransitionNet.EQUAL_EDGE) {
/* 253 */       readEdge(parser, source, target, PlaceTransitionNet.EQUAL_EDGE);
/* 254 */     } else if (nc == PlaceTransitionNet.RESET_EDGE) {
/* 255 */       readEdge(parser, source, target, PlaceTransitionNet.RESET_EDGE);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readEdge(XMLStreamReader parser, String source, String target, int type) {
/*     */     try {
/* 274 */       String weight = "";
/* 275 */       while (parser.hasNext()) {
/* 276 */         String ln; int event = parser.next();
/*     */         
/* 278 */         switch (event) {
/*     */           case 2:
/* 280 */             if (parser.getLocalName().equals("edge")) {
/* 281 */               if (type == PlaceTransitionNet.RESET_EDGE) {
/* 282 */                 evalEdge(this.pn.lookUp(source), this.pn.lookUp(target), (byte)1, type);
/*     */               } else {
/* 284 */                 evalEdge(this.pn.lookUp(source), this.pn.lookUp(target), Byte.parseByte(weight), type);
/*     */               } 
/*     */               return;
/*     */             } 
/*     */           
/*     */           case 1:
/* 290 */             ln = parser.getLocalName();
/* 291 */             if (ln.equals("attribute")) {
/* 292 */               for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 293 */                 parser.getAttributeLocalName(i);
/* 294 */                 String av = parser.getAttributeValue(i);
/* 295 */                 if (av.equals("Multiplicity")) {
/* 296 */                   weight = readAttribute(parser);
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 304 */     } catch (Exception e) {
/* 305 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void evalEdge(PNNode from, PNNode to, byte weight, int type) {
/* 322 */     this.pn.addEdge(from, to, weight, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Transition readTransition(XMLStreamReader parser, String identifier) {
/*     */     try {
/* 336 */       TimingElement interval = new TimingElement(0, 0);
/* 337 */       TimingElement constant = new TimingElement(0, 0);
/*     */       
/* 339 */       String name = "";
/* 340 */       String id = "";
/* 341 */       while (parser.hasNext()) {
/* 342 */         String ln; int event = parser.next();
/* 343 */         switch (event) {
/*     */           case 2:
/* 345 */             if (parser.getLocalName().equals("node")) {
/* 346 */               if (name.equals("")) {
/* 347 */                 name = "T_" + id;
/*     */               }
/*     */               
/* 350 */               this.currentTransId = (short)(this.currentTransId + 1); Transition ret = new TimedTransition(identifier, name, this.currentTransId, interval, constant);
/* 351 */               return ret;
/*     */             } 
/*     */           
/*     */           case 1:
/* 355 */             ln = parser.getLocalName();
/* 356 */             if (ln.equals("attribute")) {
/* 357 */               for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 358 */                 parser.getAttributeLocalName(i);
/* 359 */                 String av = parser.getAttributeValue(i);
/* 360 */                 if (av.equals("Name")) {
/* 361 */                   name = replaceSpace(readAttribute(parser)); break;
/*     */                 } 
/* 363 */                 if (av.equals("ID")) {
/* 364 */                   id = readAttribute(parser); break;
/*     */                 } 
/* 366 */                 if (av.equals("Interval")) {
/* 367 */                   this.readingTime = 1;
/* 368 */                   interval = readColList(parser); break;
/*     */                 } 
/* 370 */                 if (av.equals("Duration")) {
/* 371 */                   this.readingTime = 2;
/* 372 */                   constant = readColList(parser);
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 380 */     } catch (Exception e) {
/* 381 */       e.printStackTrace();
/*     */     } 
/* 383 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimingElement readColList(XMLStreamReader parser) {
/* 395 */     int rowCount = -1;
/* 396 */     int colCount = -1;
/*     */     try {
/* 398 */       TimingElement tElement = null;
/* 399 */       while (parser.hasNext()) {
/* 400 */         String ln; int event = parser.next();
/* 401 */         switch (event) {
/*     */           case 2:
/* 403 */             ln = parser.getLocalName();
/* 404 */             if (ln.equals("attribute")) {
/* 405 */               return tElement;
/*     */             }
/*     */           
/*     */           case 1:
/* 409 */             ln = parser.getLocalName();
/* 410 */             if (ln.equals("colList_body")) {
/* 411 */               for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 412 */                 String av = parser.getAttributeLocalName(i);
/*     */                 
/* 414 */                 if (av.equals("row_count")) {
/* 415 */                   rowCount = Integer.parseInt(parser.getAttributeValue(i));
/* 416 */                 } else if (av.equals("col_count")) {
/* 417 */                   colCount = Integer.parseInt(parser.getAttributeValue(i));
/*     */                 } 
/*     */               } 
/* 420 */               tElement = readColBody(parser);
/*     */             } 
/*     */         } 
/*     */       
/*     */       } 
/* 425 */     } catch (Exception e) {
/* 426 */       e.printStackTrace();
/*     */     } 
/* 428 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readAttribute(XMLStreamReader parser) {
/* 439 */     String ret = "";
/*     */     try {
/* 441 */       while (parser.hasNext()) {
/* 442 */         int event = parser.next();
/* 443 */         switch (event) {
/*     */           case 2:
/* 445 */             if (parser.getLocalName().equals("attribute")) {
/* 446 */               return ret;
/*     */             }
/*     */           
/*     */           case 4:
/* 450 */             if (!parser.isWhiteSpace()) {
/* 451 */               ret = parser.getText();
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 456 */     } catch (Exception e) {
/* 457 */       e.printStackTrace();
/*     */     } 
/* 459 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimingElement readColBody(XMLStreamReader parser) {
/*     */     try {
/* 471 */       TimingElement tElement = null;
/* 472 */       while (parser.hasNext()) {
/* 473 */         int event = parser.next();
/* 474 */         switch (event) {
/*     */           case 2:
/* 476 */             if (parser.getLocalName().equals("colList_body")) {
/* 477 */               return tElement;
/*     */             }
/*     */           
/*     */           case 1:
/* 481 */             if (parser.getLocalName().equals("colList_row")) {
/* 482 */               if (tElement == null) {
/* 483 */                 tElement = readColListRow(parser); continue;
/*     */               } 
/* 485 */               tElement.append(readColListRow(parser));
/*     */             } 
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/* 491 */     } catch (Exception e) {
/*     */       
/* 493 */       e.printStackTrace();
/*     */     } 
/* 495 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimingElement readColListRow(XMLStreamReader parser) {
/*     */     try {
/* 507 */       TimingElement tElement = null;
/* 508 */       String name = "";
/* 509 */       int eft = -1;
/* 510 */       int lft = -1;
/* 511 */       int counter = 0;
/* 512 */       while (parser.hasNext()) {
/* 513 */         int event = parser.next();
/* 514 */         switch (event) {
/*     */           case 2:
/* 516 */             if (parser.getLocalName().equals("colList_row")) {
/* 517 */               if (this.readingTime == 1) {
/* 518 */                 if (eft < 0 && eft != -1) {
/* 519 */                   eft = 0;
/*     */                 }
/* 521 */                 if (lft < 0 && lft != -1) {
/* 522 */                   lft = 0;
/*     */                 }
/* 524 */                 if (eft > lft && lft != -1) {
/* 525 */                   eft = lft;
/*     */                 }
/* 527 */                 tElement = new TimingElement(eft, lft);
/*     */               } 
/* 529 */               if (this.readingTime == 2) {
/*     */                 
/* 531 */                 if (eft < 0) {
/* 532 */                   eft = 0;
/*     */                 }
/* 534 */                 tElement = new TimingElement(eft, eft);
/*     */               } 
/* 536 */               tElement.setName(name);
/* 537 */               return tElement;
/*     */             } 
/*     */           
/*     */           case 1:
/* 541 */             if (parser.getLocalName().equals("colList_col")) {
/* 542 */               if (counter == 0) {
/* 543 */                 name = readTimeValue(parser);
/*     */               }
/* 545 */               if (counter == 1) {
/* 546 */                 String val = "";
/*     */                 try {
/* 548 */                   val = readTimeValue(parser);
/* 549 */                   eft = Integer.parseInt(val);
/* 550 */                 } catch (Exception e) {
/*     */                   
/* 552 */                   if (val.equals("oo")) {
/* 553 */                     eft = -1;
/*     */                   } else {
/* 555 */                     eft = 0;
/*     */                   } 
/*     */                 } 
/*     */               } 
/* 559 */               if (counter == 2) {
/* 560 */                 String val = readTimeValue(parser);
/*     */                 try {
/* 562 */                   lft = Integer.parseInt(val);
/* 563 */                 } catch (Exception e) {
/*     */                   
/* 565 */                   if (val.equals("oo")) {
/* 566 */                     lft = -1;
/*     */                   } else {
/* 568 */                     lft = 0;
/*     */                   } 
/*     */                 } 
/* 571 */                 counter = -1;
/*     */               } 
/* 573 */               counter++;
/*     */             } 
/*     */         } 
/*     */       
/*     */       } 
/* 578 */     } catch (Exception e) {
/*     */       
/* 580 */       e.printStackTrace();
/*     */     } 
/* 582 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readTimeValue(XMLStreamReader parser) {
/* 593 */     String ret = "";
/*     */     try {
/* 595 */       while (parser.hasNext()) {
/* 596 */         int event = parser.next();
/* 597 */         switch (event) {
/*     */           case 2:
/* 599 */             if (parser.getLocalName().equals("colList_col"))
/*     */             {
/* 601 */               return ret;
/*     */             }
/*     */           
/*     */           case 4:
/* 605 */             if (!parser.isWhiteSpace()) {
/* 606 */               ret = parser.getText();
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 611 */     } catch (Exception e) {
/* 612 */       e.printStackTrace();
/*     */     } 
/* 614 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int countPlaces() {
/* 622 */     UnsignedByte.setMin(0);
/* 623 */     int places = countNodesOfType("Place");
/* 624 */     if (places > 127)
/*     */     {
/* 626 */       if (places > 255) {
/* 627 */         DebugCounter.inc("SPTPTReader.countPlaces() before SEF.setByteMode(false)");
/* 628 */         SortedElementsFactory.byteMode(false);
/*     */       } else {
/* 630 */         UnsignedByte.setMin(-127);
/*     */       } 
/*     */     }
/*     */     
/* 634 */     return places;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int countTransitions() {
/* 642 */     return countNodesOfType("Transition");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readNet() throws Exception {
/* 650 */     read();
/* 651 */     this.pn.TIMED_NET_TYPE = 4;
/* 652 */     this.pn.setTimedNet(true);
/* 653 */     DebugCounter.inc("SPTPTReader: pn.isTimedNet() = " + this.pn.isTimedNet());
/* 654 */     initNet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int countNodesOfType(String type) {
/* 665 */     int counter = 0;
/*     */     try {
/* 667 */       InputStream in = getInputStream(this.file);
/* 668 */       XMLInputFactory factory = XMLInputFactory.newInstance();
/* 669 */       XMLStreamReader parser = factory.createXMLStreamReader(in);
/*     */       
/* 671 */       StringBuilder spacer = new StringBuilder();
/* 672 */       while (parser.hasNext()) {
/*     */         String ln;
/* 674 */         int i, event = parser.next();
/*     */         
/* 676 */         switch (event) {
/*     */           case 7:
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 8:
/* 683 */             parser.close();
/*     */             break;
/*     */           
/*     */           case 13:
/*     */             break;
/*     */           case 1:
/* 689 */             spacer.append("  ");
/*     */ 
/*     */             
/* 692 */             ln = parser.getLocalName();
/* 693 */             if (ln.equals("node")) {
/* 694 */               if ((nc == PLACE && type.equals("Place")) || (nc == TRANSITION && type
/* 695 */                 .equals("Transition"))) {
/* 696 */                 counter++;
/*     */               }
/*     */               break;
/*     */             } 
/* 700 */             for (i = 0; i < parser.getAttributeCount(); i++) {
/*     */ 
/*     */ 
/*     */               
/* 704 */               parser.getAttributeLocalName(i);
/* 705 */               String av = parser.getAttributeValue(i);
/* 706 */               if (ln.equals("nodeclass")) {
/* 707 */                 eval(av);
/*     */               }
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 718 */     } catch (Exception e) {
/* 719 */       e.printStackTrace();
/*     */     } 
/* 721 */     return counter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void eval(String val) {
/* 731 */     if (val.equals("Place")) {
/* 732 */       nc = PLACE;
/* 733 */     } else if (val.equals("Transition")) {
/* 734 */       nc = TRANSITION;
/* 735 */     } else if (val.equals("Edge")) {
/* 736 */       nc = PlaceTransitionNet.EDGE;
/* 737 */     } else if (val.equals("Read Edge")) {
/* 738 */       nc = PlaceTransitionNet.READ_EDGE;
/* 739 */     } else if (val.equals("Inhibitor Edge")) {
/* 740 */       nc = PlaceTransitionNet.INHIBITOR_EDGE;
/* 741 */     } else if (val.equals("Equal Edge")) {
/* 742 */       nc = PlaceTransitionNet.EQUAL_EDGE;
/* 743 */     } else if (val.equals("Reset Edge")) {
/* 744 */       nc = PlaceTransitionNet.RESET_EDGE;
/*     */     } else {
/* 746 */       nc = IGNORE;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SPTPTReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */