/*     */ package charlie.pn;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SnoopyPTNetReader
/*     */   extends PetriNetReader
/*     */ {
/*  20 */   private static final Log LOG = LogFactory.getLog(SnoopyPTNetReader.class);
/*     */   
/*  22 */   static int nc = -1;
/*  23 */   static int PLACE = 0;
/*  24 */   static int TRANSITION = 1;
/*  25 */   static int IGNORE = 4;
/*     */   
/*  27 */   private final Map<Place, MarkingList> markingMap = new HashMap<>();
/*  28 */   private List<String> markingNameList = new ArrayList<>();
/*  29 */   private List<Place> placeList = new ArrayList<>();
/*     */   
/*     */   public SnoopyPTNetReader(boolean register) {
/*  32 */     if (register) {
/*  33 */       register();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected PlaceTransitionNet initPlaceTransitionNet() {
/*  39 */     return new MultipleMarkingsPlaceTransitionNet();
/*     */   }
/*     */   
/*     */   public void register() {
/*  43 */     if (evalVersion()) {
/*     */       
/*  45 */       PetriNetReaderFactory.registerReader(".spm", this);
/*  46 */       PetriNetReaderFactory.registerReader(".spped", this);
/*  47 */       PetriNetReaderFactory.registerReader(".pn", this);
/*  48 */       PetriNetReaderFactory.registerReader(".spept", this);
/*  49 */       PetriNetReaderFactory.registerReader(".xpn", this);
/*  50 */       PetriNetReaderFactory.registerReader(".spstochpn", this);
/*  51 */       PetriNetReaderFactory.registerReader(".spn", this);
/*  52 */       PetriNetReaderFactory.registerReader(".spcontped", this);
/*  53 */       PetriNetReaderFactory.registerReader(".cpn", this);
/*  54 */       PetriNetReaderFactory.registerReader(".sphybrid", this);
/*  55 */       PetriNetReaderFactory.registerReader(".hpn", this);
/*  56 */       PetriNetReaderFactory.registerReader(".colpn", this);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected static boolean evalVersion() {
/*  61 */     String version = "";
/*     */     try {
/*  63 */       version = System.getProperty("java.version");
/*  64 */       if (version.startsWith("1.6")) {
/*  65 */         return true;
/*     */       }
/*  67 */     } catch (Exception e) {
/*  68 */       LOG.error(e.getMessage(), e);
/*  69 */       return false;
/*     */     } 
/*  71 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void eval(String val) {
/*  76 */     if (LOG.isDebugEnabled()) {
/*  77 */       LOG.debug("evaluating: " + val);
/*     */     }
/*     */     
/*  80 */     if (val.equals("Place")) {
/*  81 */       nc = PLACE;
/*  82 */     } else if (val.equals("Place, Continuous")) {
/*  83 */       nc = PLACE;
/*  84 */     } else if (val.equals("Transition")) {
/*  85 */       nc = TRANSITION;
/*  86 */     } else if (val.equals("Transition, Continuous")) {
/*  87 */       nc = TRANSITION;
/*  88 */     } else if (val.equals("Edge, Continuous")) {
/*  89 */       nc = PlaceTransitionNet.EDGE;
/*  90 */     } else if (val.equals("Deterministic Transition")) {
/*  91 */       nc = TRANSITION;
/*  92 */     } else if (val.equals("Immediate Transition")) {
/*  93 */       nc = TRANSITION;
/*  94 */     } else if (val.equals("Scheduled Transition")) {
/*  95 */       nc = TRANSITION;
/*  96 */     } else if (val.equals("Edge")) {
/*     */       
/*  98 */       if (val.contains("Undirected")) {
/*  99 */         Out.println("undirected edges will be ignored, connected places will be ignored, too!");
/* 100 */         nc = PlaceTransitionNet.UNDIRECTED_EDGE;
/*     */       } else {
/* 102 */         nc = PlaceTransitionNet.EDGE;
/*     */       } 
/* 104 */     } else if (val.contains("Read Edge") || val
/* 105 */       .equals("Test Edge, Continuous")) {
/* 106 */       nc = PlaceTransitionNet.READ_EDGE;
/* 107 */     } else if (val.contains("Inhibitor Edge") || val
/* 108 */       .equals("Inhibitor Edge, Continuous")) {
/* 109 */       nc = PlaceTransitionNet.INHIBITOR_EDGE;
/* 110 */     } else if (val.contains("Equal Edge")) {
/* 111 */       nc = PlaceTransitionNet.EQUAL_EDGE;
/* 112 */     } else if (val.contains("Reset Edge")) {
/* 113 */       nc = PlaceTransitionNet.RESET_EDGE;
/*     */     } else {
/* 115 */       nc = IGNORE;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int countPlaces() {
/* 121 */     UnsignedByte.setMin(0);
/*     */     
/* 123 */     return countNodesOfType("Place");
/*     */   }
/*     */ 
/*     */   
/*     */   protected int countTransitions() {
/* 128 */     return countNodesOfType("Transition");
/*     */   }
/*     */ 
/*     */   
/*     */   public void readNet() throws Exception {
/* 133 */     read();
/* 134 */     initNet();
/*     */     
/* 136 */     initMarkingList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initMarkingList() {
/* 143 */     for (int i = 0; i < this.markingNameList.size(); i++) {
/* 144 */       String name = this.markingNameList.get(i);
/*     */       
/* 146 */       List<Integer> marking = new ArrayList<>(this.pn.places());
/*     */       
/* 148 */       for (int j = 0; j < this.placeList.size(); j++) {
/* 149 */         Place p = this.placeList.get(j);
/* 150 */         List<String> valueList = ((MarkingList)this.markingMap.get(p)).getValueList();
/* 151 */         marking.add(Integer.valueOf(Double.valueOf(valueList.get(i)).intValue()));
/*     */       } 
/* 153 */       ((MultipleMarkingsPlaceTransitionNet)getPlaceTransitionNet())
/* 154 */         .addMarking(name, marking);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int countNodesOfType(String type) {
/* 159 */     int counter = 0;
/* 160 */     InputStream in = null;
/* 161 */     XMLStreamReader parser = null;
/*     */     try {
/* 163 */       in = getInputStream(this.file);
/* 164 */       XMLInputFactory factory = XMLInputFactory.newInstance();
/* 165 */       parser = factory.createXMLStreamReader(in);
/*     */       
/* 167 */       StringBuilder spacer = new StringBuilder();
/* 168 */       while (parser.hasNext()) {
/* 169 */         String ln; int i, event = parser.next();
/*     */         
/* 171 */         switch (event) {
/*     */           case 7:
/*     */             break;
/*     */ 
/*     */           
/*     */           case 8:
/* 177 */             parser.close();
/*     */             break;
/*     */           
/*     */           case 13:
/*     */             break;
/*     */           case 1:
/* 183 */             spacer.append("  ");
/*     */             
/* 185 */             ln = parser.getLocalName();
/* 186 */             if (ln.equals("node")) {
/* 187 */               if ((nc == PLACE && type.contains("Place")) || (nc == TRANSITION && type
/*     */                 
/* 189 */                 .contains("Transition"))) {
/* 190 */                 counter++;
/*     */               }
/*     */               
/*     */               break;
/*     */             } 
/* 195 */             for (i = 0; i < parser.getAttributeCount(); i++) {
/*     */               
/* 197 */               parser.getAttributeLocalName(i);
/* 198 */               String av = parser.getAttributeValue(i);
/* 199 */               if (ln.equals("nodeclass")) {
/* 200 */                 eval(av);
/*     */               }
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 210 */     } catch (Exception e) {
/* 211 */       LOG.error(e.getMessage(), e);
/*     */     } finally {
/*     */       try {
/* 214 */         in.close();
/* 215 */       } catch (IOException e) {
/* 216 */         e.printStackTrace();
/* 217 */       } catch (NullPointerException nullPointerException) {}
/*     */ 
/*     */       
/*     */       try {
/* 221 */         parser.close();
/* 222 */       } catch (XMLStreamException e) {
/* 223 */         e.printStackTrace();
/* 224 */       } catch (NullPointerException nullPointerException) {}
/*     */     } 
/*     */ 
/*     */     
/* 228 */     return counter;
/*     */   }
/*     */   
/*     */   private void read() {
/* 232 */     InputStream in = null;
/* 233 */     XMLStreamReader parser = null;
/*     */     try {
/* 235 */       this.placeCounter = 0;
/* 236 */       in = getInputStream(this.file);
/* 237 */       XMLInputFactory factory = XMLInputFactory.newInstance();
/* 238 */       parser = factory.createXMLStreamReader(in);
/*     */       
/* 240 */       while (parser.hasNext()) {
/* 241 */         String ln; int i, event = parser.next();
/*     */         
/* 243 */         switch (event) {
/*     */           case 7:
/*     */             break;
/*     */ 
/*     */           
/*     */           case 8:
/* 249 */             parser.close();
/*     */             break;
/*     */           case 13:
/*     */             break;
/*     */           case 1:
/* 254 */             ln = parser.getLocalName();
/* 255 */             if (ln.equals("node") || ln.equals("edge")) {
/* 256 */               readNode(parser);
/*     */               
/*     */               break;
/*     */             } 
/* 260 */             for (i = 0; i < parser.getAttributeCount(); i++) {
/* 261 */               parser.getAttributeLocalName(i);
/* 262 */               String av = parser.getAttributeValue(i);
/*     */               
/* 264 */               if (LOG.isDebugEnabled()) {
/* 265 */                 LOG.debug("attribute value: " + av);
/*     */               }
/*     */               
/* 268 */               if (ln.equals("nodeclass") || ln
/* 269 */                 .equals("edgeclass")) {
/* 270 */                 eval(av);
/*     */               }
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 279 */     } catch (Exception e) {
/* 280 */       LOG.error(e.getMessage(), e);
/*     */     } finally {
/*     */       try {
/* 283 */         in.close();
/* 284 */       } catch (IOException e) {
/* 285 */         e.printStackTrace();
/* 286 */       } catch (NullPointerException nullPointerException) {}
/*     */ 
/*     */       
/*     */       try {
/* 290 */         parser.close();
/* 291 */       } catch (XMLStreamException e) {
/* 292 */         e.printStackTrace();
/* 293 */       } catch (NullPointerException nullPointerException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readNode(XMLStreamReader parser) {
/* 301 */     String id = "";
/* 302 */     int net = -1;
/* 303 */     String source = "";
/* 304 */     String target = "";
/* 305 */     for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 306 */       String lv = parser.getAttributeLocalName(i);
/* 307 */       String av = parser.getAttributeValue(i);
/* 308 */       if (lv.equals("net")) {
/* 309 */         net = Integer.parseInt(av);
/* 310 */       } else if (lv.equals("id")) {
/* 311 */         id = av;
/* 312 */       } else if (lv.equals("source")) {
/* 313 */         source = av;
/* 314 */       } else if (lv.equals("target")) {
/* 315 */         target = av;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 320 */     if (nc == PLACE) {
/* 321 */       String Pid = id;
/* 322 */       PNNode n = readPlace(parser, Pid);
/* 323 */       if (n != null) {
/* 324 */         Place p = (Place)n;
/*     */         
/* 326 */         this.pn.allNodes().put(Pid, n);
/* 327 */         this.pn.identifier().put(n, Pid);
/* 328 */         this.pn.addPlace((Place)n);
/* 329 */         if (p.getToken() > 0) {
/* 330 */           this.initialMarking.add(p);
/* 331 */           this.initialMarking.add(new Integer(p.getToken()));
/*     */         }
/*     */       
/*     */       } 
/* 335 */     } else if (nc == TRANSITION) {
/* 336 */       String Tid = id;
/*     */       
/* 338 */       PNNode n = readTransition(parser, Tid);
/* 339 */       this.pn.allNodes().put(Tid, n);
/* 340 */       this.pn.identifier().put(n, Tid);
/* 341 */       this.pn.addTransition((Transition)n);
/*     */     }
/* 343 */     else if (nc == PlaceTransitionNet.EDGE) {
/* 344 */       readEdge(parser, source, target, PlaceTransitionNet.EDGE);
/* 345 */     } else if (nc == PlaceTransitionNet.INHIBITOR_EDGE) {
/* 346 */       readEdge(parser, source, target, PlaceTransitionNet.INHIBITOR_EDGE);
/* 347 */     } else if (nc == PlaceTransitionNet.READ_EDGE) {
/* 348 */       readEdge(parser, source, target, PlaceTransitionNet.READ_EDGE);
/* 349 */     } else if (nc == PlaceTransitionNet.EQUAL_EDGE) {
/* 350 */       readEdge(parser, source, target, PlaceTransitionNet.EQUAL_EDGE);
/* 351 */     } else if (nc == PlaceTransitionNet.RESET_EDGE) {
/* 352 */       readEdge(parser, source, target, PlaceTransitionNet.RESET_EDGE);
/* 353 */     } else if (nc == PlaceTransitionNet.UNDIRECTED_EDGE) {
/* 354 */       readEdge(parser, source, target, PlaceTransitionNet.UNDIRECTED_EDGE);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean ignoreNode(String id) {
/* 359 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private Place readPlace(XMLStreamReader parser, String identifier) {
/* 364 */     if (ignoreNode(identifier)) {
/* 365 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 369 */       String name = "";
/* 370 */       String init = "";
/* 371 */       String id = "";
/* 372 */       MarkingList markingList = null;
/* 373 */       while (parser.hasNext()) {
/* 374 */         String ln; int event = parser.next();
/*     */         
/* 376 */         switch (event) {
/*     */           case 2:
/* 378 */             if (parser.getLocalName().equals("node")) {
/* 379 */               Place ret; if (name.equals("")) {
/* 380 */                 name = "P_" + id;
/*     */               }
/*     */ 
/*     */ 
/*     */               
/*     */               try {
/* 386 */                 ret = new Place(identifier, name, Integer.parseInt(init), this.currentPlaceId++, this.placeCounter++, 0);
/*     */               }
/* 388 */               catch (NumberFormatException nfe) {
/*     */                 
/*     */                 try {
/* 391 */                   int value = (new Double(Double.parseDouble(init))).intValue();
/*     */                   
/* 393 */                   ret = new Place(identifier, name, value, this.currentPlaceId++, this.placeCounter++, 0);
/*     */                   
/* 395 */                   LOG.info("converting marking <" + init + "> to  " + value + "!!");
/* 396 */                 } catch (Exception e) {
/* 397 */                   Out.println("could not parse initial amount of token <" + init + "> , assuming 0!!");
/*     */                   
/* 399 */                   ret = new Place(identifier, name, 0, this.currentPlaceId++, this.placeCounter++, 0);
/*     */                 } 
/*     */               } 
/*     */ 
/*     */               
/* 404 */               if (markingList != null) {
/* 405 */                 this.markingMap.put(ret, markingList);
/* 406 */                 this.markingNameList = markingList.getNameList();
/* 407 */                 this.placeList.add(ret);
/*     */               } 
/*     */               
/* 410 */               return ret;
/*     */             } 
/*     */           
/*     */           case 1:
/* 414 */             ln = parser.getLocalName();
/* 415 */             if (ln.equals("attribute")) {
/* 416 */               for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 417 */                 parser.getAttributeLocalName(i);
/* 418 */                 String av = parser.getAttributeValue(i);
/* 419 */                 if (av.contains("Name")) {
/* 420 */                   name = replaceSpace(readAttribute(parser)); break;
/*     */                 } 
/* 422 */                 if (av.equals("ID")) {
/* 423 */                   id = readAttribute(parser); break;
/*     */                 } 
/* 425 */                 if (av.equals("Marking")) {
/* 426 */                   init = readAttribute(parser); break;
/*     */                 } 
/* 428 */                 if (av.equals("MarkingList")) {
/* 429 */                   markingList = readMarking(parser);
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 437 */     } catch (Exception e) {
/* 438 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 440 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private Transition readTransition(XMLStreamReader parser, String identifier) {
/*     */     try {
/* 446 */       String name = "";
/* 447 */       String id = "";
/* 448 */       while (parser.hasNext()) {
/* 449 */         String ln; int event = parser.next();
/*     */         
/* 451 */         switch (event) {
/*     */           case 2:
/* 453 */             if (parser.getLocalName().equals("node")) {
/* 454 */               if (name.equals("")) {
/* 455 */                 name = "T_" + id;
/*     */               }
/*     */               
/* 458 */               this.currentTransId = (short)(this.currentTransId + 1); Transition ret = new Transition(identifier, name, this.currentTransId);
/*     */ 
/*     */               
/* 461 */               return ret;
/*     */             } 
/*     */           
/*     */           case 1:
/* 465 */             ln = parser.getLocalName();
/*     */             
/* 467 */             if (ln.equals("attribute")) {
/* 468 */               for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 469 */                 parser.getAttributeLocalName(i);
/* 470 */                 String av = parser.getAttributeValue(i);
/*     */                 
/* 472 */                 if (av.contains("Name")) {
/* 473 */                   name = replaceSpace(readAttribute(parser));
/*     */                   break;
/*     */                 } 
/* 476 */                 if (av.equals("ID")) {
/* 477 */                   id = readAttribute(parser); break;
/*     */                 } 
/* 479 */                 if (av.equals("Interval"));
/*     */               } 
/*     */             }
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 487 */     } catch (Exception e) {
/* 488 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 490 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void readEdge(XMLStreamReader parser, String source, String target, int type) {
/*     */     try {
/* 497 */       String weight = "";
/* 498 */       while (parser.hasNext()) {
/* 499 */         String ln; int event = parser.next();
/*     */         
/* 501 */         switch (event) {
/*     */           case 2:
/* 503 */             if (parser.getLocalName().equals("edge")) {
/* 504 */               if (type == PlaceTransitionNet.RESET_EDGE) {
/* 505 */                 evalEdge(this.pn.lookUp(source), this.pn.lookUp(target), 1, type);
/*     */               }
/* 507 */               else if (type != PlaceTransitionNet.UNDIRECTED_EDGE) {
/*     */ 
/*     */                 
/*     */                 try {
/*     */ 
/*     */ 
/*     */                   
/* 514 */                   evalEdge(this.pn.lookUp(source), this.pn.lookUp(target), Integer.parseInt(weight), type);
/* 515 */                 } catch (NumberFormatException nfe) {
/*     */                   try {
/* 517 */                     int value = (new Double(Double.parseDouble(weight))).intValue();
/* 518 */                     LOG.info("converting mutliplicity <" + weight + "> to  " + value + "!!");
/* 519 */                     evalEdge(this.pn.lookUp(source), this.pn.lookUp(target), value, type);
/* 520 */                   } catch (NumberFormatException nfe2) {
/* 521 */                     LOG.info("could not parse edge multiplicity <" + weight + "> , assuming 1!!");
/* 522 */                     evalEdge(this.pn.lookUp(source), this.pn.lookUp(target), 1, type);
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */               return;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 1:
/* 533 */             ln = parser.getLocalName();
/* 534 */             if (ln.equals("attribute")) {
/* 535 */               for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 536 */                 parser.getAttributeLocalName(i);
/* 537 */                 String av = parser.getAttributeValue(i);
/* 538 */                 if (av.equals("Multiplicity")) {
/* 539 */                   weight = readAttribute(parser);
/*     */                   break;
/*     */                 } 
/* 542 */                 if (av.equals("Equation")) {
/* 543 */                   weight = readAttribute(parser);
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 551 */     } catch (Exception e) {
/* 552 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String readAttribute(XMLStreamReader parser) {
/* 557 */     String ret = "";
/*     */     try {
/* 559 */       while (parser.hasNext()) {
/* 560 */         int event = parser.next();
/* 561 */         switch (event) {
/*     */           case 2:
/* 563 */             if (parser.getLocalName().equals("attribute")) {
/* 564 */               return ret;
/*     */             }
/*     */           
/*     */           case 4:
/* 568 */             if (!parser.isWhiteSpace()) {
/* 569 */               ret = parser.getText();
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 574 */     } catch (Exception e) {
/* 575 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 577 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   private MarkingList readMarking(XMLStreamReader parser) {
/* 582 */     List<String> setNameList = new ArrayList<>();
/* 583 */     List<String> setValueList = new ArrayList<>();
/*     */     
/*     */     try {
/* 586 */       while (parser.hasNext()) {
/* 587 */         String name; int event = parser.next();
/*     */ 
/*     */         
/* 590 */         switch (event) {
/*     */           case 1:
/* 592 */             name = parser.getLocalName();
/*     */             
/* 594 */             if (LOG.isDebugEnabled()) {
/* 595 */               LOG.debug("start element: " + name);
/*     */             }
/*     */             
/* 598 */             if ("colList_col".equals(name)) {
/* 599 */               String col = parser.getAttributeValue(0);
/* 600 */               if ("0".equals(col)) {
/* 601 */                 if (parser.hasNext()) {
/* 602 */                   event = parser.next();
/*     */                   
/* 604 */                   while (event == 4 && parser
/* 605 */                     .isWhiteSpace())
/*     */                   {
/* 607 */                     parser.next();
/*     */                   }
/*     */                   
/* 610 */                   setNameList.add(parser.getText()); continue;
/*     */                 } 
/* 612 */                 throw new XMLStreamException("Unexpected EOF.");
/*     */               } 
/* 614 */               if ("1".equals(col)) {
/* 615 */                 if (parser.hasNext()) {
/* 616 */                   event = parser.next();
/*     */                   
/* 618 */                   while (event == 4 && parser
/* 619 */                     .isWhiteSpace())
/*     */                   {
/* 621 */                     parser.next();
/*     */                   }
/*     */                   
/* 624 */                   setValueList.add(parser.getText()); continue;
/*     */                 } 
/* 626 */                 throw new XMLStreamException("Unexpected EOF.");
/*     */               } 
/*     */             } 
/*     */ 
/*     */           
/*     */           case 2:
/* 632 */             name = parser.getLocalName();
/*     */             
/* 634 */             if (LOG.isDebugEnabled()) {
/* 635 */               LOG.debug("end element: " + name);
/*     */             }
/*     */             
/* 638 */             if ("colList".equals(name)) {
/*     */               
/* 640 */               if (setNameList.size() != setValueList.size()) {
/* 641 */                 throw new XMLStreamException("The size of the set of names is not equal to the size of the set of values.");
/*     */               }
/*     */ 
/*     */               
/* 645 */               MarkingList ml = new MarkingList(setNameList, setValueList);
/*     */ 
/*     */               
/* 648 */               return ml;
/*     */             } 
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 655 */     } catch (XMLStreamException e) {
/* 656 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 659 */     return null;
/*     */   }
/*     */   
/*     */   private void evalEdge(PNNode from, PNNode to, int weight, int type) {
/* 663 */     this.pn.addEdge(from, to, weight, type);
/*     */   }
/*     */   
/*     */   private class MarkingList
/*     */   {
/*     */     private final List<String> setNameList;
/*     */     private final List<String> setValueList;
/*     */     
/*     */     public MarkingList(List<String> _nameList, List<String> _valueList) {
/* 672 */       this.setNameList = _nameList;
/* 673 */       this.setValueList = _valueList;
/*     */     }
/*     */     
/*     */     public List<String> getNameList() {
/* 677 */       return this.setNameList;
/*     */     }
/*     */     
/*     */     public List<String> getValueList() {
/* 681 */       return this.setValueList;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SnoopyPTNetReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */