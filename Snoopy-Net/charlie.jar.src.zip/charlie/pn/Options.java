/*     */ package charlie.pn;
/*     */ 
/*     */ import charlie.ds.BooleanOption;
/*     */ import charlie.ds.Option;
/*     */ import charlie.ds.OptionChangeAction;
/*     */ 
/*     */ 
/*     */ public class Options
/*     */ {
/*  10 */   public static String version = "Charlie 1.1";
/*  11 */   public static String lastUpdate = "08.04.2008";
/*     */   
/*     */   public static final int CONSOLE = 1;
/*     */   public static final int NO_PRINTING = 0;
/*     */   public static boolean debug = false;
/*     */   public static boolean safeNet = false;
/*     */   public static boolean byteSat = true;
/*     */   public static boolean pinv = true;
/*  19 */   public static Option tinv = (Option)new BooleanOption(true);
/*     */   
/*     */   public static boolean cti = true;
/*     */   
/*     */   public static boolean cpi = true;
/*     */   public static boolean invexport = true;
/*     */   public static boolean dtexport = false;
/*  26 */   public static String dtextension = "_DLS.res";
/*  27 */   public static Option dtp = (Option)new BooleanOption(false);
/*  28 */   public static Option deleteTrivial = (Option)new BooleanOption(false);
/*  29 */   public static Option coverage = (Option)new BooleanOption(true);
/*  30 */   public static Option extended_coverage = (Option)new BooleanOption(false);
/*     */ 
/*     */   
/*  33 */   public static Option proper = (Option)new BooleanOption(false);
/*  34 */   public static Option deadlocks = (Option)new BooleanOption(true) {
/*     */       public void setValue(Object value) {
/*  36 */         super.setValue(value);
/*  37 */         if (((Boolean)value).booleanValue()) {
/*  38 */           Options.dtextension = "_DLS.res";
/*     */         } else {
/*  40 */           Options.dtextension = "_TPS.res";
/*     */         } 
/*     */       }
/*     */     };
/*  44 */   public static int printResults = 0;
/*     */   
/*  46 */   public static String adsFile = "";
/*  47 */   public static String adsConFile = "";
/*  48 */   public static String sdsFile = "";
/*  49 */   public static String invFile = "";
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setADSPaths(String path) {
/*  54 */     adsFile = path;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setSDSPaths(String path) {
/*  59 */     sdsFile = path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setConADSPaths(String path) {
/*  68 */     adsConFile = path;
/*     */   }
/*     */ 
/*     */   
/*  72 */   public static Option ads = (Option)new BooleanOption(false) {
/*     */       public void setValue(Object value) {
/*  74 */         super.setValue(value);
/*  75 */         if (!((Boolean)value).booleanValue()) Options.resetADSPath(); 
/*     */       }
/*     */     };
/*     */   
/*  79 */   public static Option adsCon = (Option)new BooleanOption(false) {
/*     */       public void setValue(Object value) {
/*  81 */         super.setValue(value);
/*  82 */         if (!((Boolean)value).booleanValue()) Options.resetADSConPAth(); 
/*     */       }
/*     */     };
/*  85 */   public static Option sds = (Option)new BooleanOption(false) {
/*     */       public void setValue(Object value) {
/*  87 */         super.setValue(value);
/*  88 */         if (!((Boolean)value).booleanValue()) Options.resetSDSPath();
/*     */       
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetSDSPath() {
/*  99 */     sdsFile = "";
/*     */   }
/*     */   public static void resetADSPath() {
/* 102 */     adsFile = "";
/*     */   }
/*     */   
/*     */   public static void resetADSConPAth() {
/* 106 */     adsConFile = "";
/*     */   }
/*     */   
/*     */   public static void resetPaths() {
/* 110 */     resetADSPath();
/* 111 */     resetSDSPath();
/* 112 */     resetADSConPAth();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void initOptions() {
/* 117 */     sds.addDependency(new OptionChangeAction(ads, new Boolean(true), new Boolean(true)));
/* 118 */     dtp.addDependency(new OptionChangeAction(deadlocks, new Boolean(true), new Boolean(true)));
/* 119 */     proper.addDependency(new OptionChangeAction(dtp, new Boolean(true), new Boolean(false)));
/* 120 */     dtp.addDependency(new OptionChangeAction(proper, new Boolean(true), new Boolean(false)));
/* 121 */     deadlocks.addDependency(new OptionChangeAction(dtp, new Boolean(false), new Boolean(false)));
/* 122 */     ads.addDependency(new OptionChangeAction(sds, new Boolean(false), new Boolean(false)));
/* 123 */     ads.addDependency(new OptionChangeAction(adsCon, new Boolean(false), new Boolean(false)));
/* 124 */     adsCon.addDependency(new OptionChangeAction(ads, new Boolean(true), new Boolean(true)));
/* 125 */     tinv.addDependency(new OptionChangeAction(extended_coverage, new Boolean(false), new Boolean(false)));
/* 126 */     tinv.addDependency(new OptionChangeAction(deleteTrivial, new Boolean(false), new Boolean(false)));
/* 127 */     coverage.addDependency(new OptionChangeAction(deleteTrivial, new Boolean(true), new Boolean(false)));
/*     */     
/* 129 */     deleteTrivial.addDependency(new OptionChangeAction(coverage, new Boolean(true), new Boolean(false)));
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Options.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */