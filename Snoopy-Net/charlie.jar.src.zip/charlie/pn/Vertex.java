/*     */ package charlie.pn;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Vertex
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 9057567016624471458L;
/*     */   protected TraversationData td;
/*  14 */   Edge out = null;
/*  15 */   Edge in = null;
/*     */   
/*  17 */   protected int sccNumber = -1;
/*     */   protected Object label;
/*  19 */   protected byte outDegree = 0;
/*  20 */   protected byte inDegree = 0;
/*     */   
/*     */   public Vertex(Object label) {
/*  23 */     if (label == null) {
/*  24 */       throw new NullPointerException();
/*     */     }
/*  26 */     this.td = new TraversationData();
/*  27 */     this.label = label;
/*     */   }
/*     */ 
/*     */   
/*     */   public Edge out() {
/*  32 */     return this.out;
/*     */   }
/*     */   
/*     */   public Edge in() {
/*  36 */     return this.in;
/*     */   }
/*     */   
/*     */   public int getColorNumber() {
/*  40 */     return sccNumber();
/*     */   }
/*     */   
/*     */   public Vertex getVertex() {
/*  44 */     return this;
/*     */   }
/*     */   
/*     */   public TraversationData getTD() {
/*  48 */     return this.td;
/*     */   }
/*     */   
/*     */   public int addIngoing(Edge inEdge) {
/*  52 */     if (inEdge != null) {
/*  53 */       inEdge.setNext(this.in);
/*  54 */       this.in = inEdge;
/*     */     } 
/*  56 */     this.inDegree = (byte)(this.inDegree + 1);
/*     */     
/*  58 */     return this.inDegree;
/*     */   }
/*     */   
/*     */   public int addOutgoing(Edge outEdge) {
/*  62 */     outEdge.setNext(this.out);
/*  63 */     this.out = outEdge;
/*  64 */     this.outDegree = (byte)(this.outDegree + 1);
/*  65 */     return this.outDegree;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vertex copy() {
/*  70 */     Vertex copy = new Vertex(getLabel());
/*     */     
/*  72 */     return copy;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  77 */     return getLabel().toString();
/*     */   }
/*     */   
/*     */   public void deleteTraversationData() {
/*  81 */     this.td = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getLabel() {
/*  87 */     return this.label;
/*     */   }
/*     */   
/*     */   public int sccNumber() {
/*  91 */     return this.sccNumber;
/*     */   }
/*     */   
/*     */   public void setSccNumber(int scc) {
/*  95 */     this.sccNumber = scc;
/*     */   }
/*     */   
/*     */   public void removePre(Vertex from) {
/*  99 */     Edge prev = this.in;
/* 100 */     while (prev != null) {
/* 101 */       Vertex node = prev.node();
/* 102 */       if (!node.equals(from)) {
/* 103 */         prev = prev.next();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 108 */     if (prev == null) {
/*     */       return;
/*     */     }
/* 111 */     Edge preOut = (prev.node()).out;
/* 112 */     if (preOut != null && preOut.node().equals(this)) {
/* 113 */       (prev.node()).out = preOut.next;
/* 114 */       from.outDegree = (byte)(from.outDegree - 1);
/*     */       
/*     */       return;
/*     */     } 
/* 118 */     while (preOut != null && preOut.next != null) {
/* 119 */       if (preOut.next.node().equals(this)) {
/* 120 */         preOut.next = preOut.next.next;
/*     */         
/* 122 */         from.outDegree = (byte)(from.outDegree - 1);
/*     */         
/*     */         return;
/*     */       } 
/* 126 */       preOut = preOut.next();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removePost(Vertex to) {
/* 131 */     Edge post = this.out;
/* 132 */     while (post != null) {
/*     */       
/* 134 */       Vertex node = post.node();
/* 135 */       if (!node.equals(to)) {
/* 136 */         post = post.next;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 142 */     if (post == null) {
/*     */       return;
/*     */     }
/* 145 */     Edge preIn = (post.node()).in;
/* 146 */     boolean b = true;
/* 147 */     if (to.equals(this)) {
/* 148 */       b = false;
/* 149 */       this.inDegree = (byte)(this.inDegree - 1);
/*     */     } 
/* 151 */     if (b && preIn != null && preIn.node().equals(this)) {
/* 152 */       (post.node()).in = preIn.next;
/* 153 */       to.inDegree = (byte)(to.inDegree - 1);
/* 154 */       b = false;
/*     */     } 
/* 156 */     while (b && preIn != null && preIn.next != null) {
/*     */       
/* 158 */       if (preIn.next.node().equals(this)) {
/* 159 */         preIn.next = preIn.next.next;
/* 160 */         to.inDegree = (byte)(to.inDegree - 1);
/*     */         
/* 162 */         b = false;
/*     */       } 
/* 164 */       preIn = preIn.next();
/*     */     } 
/*     */ 
/*     */     
/* 168 */     post = this.out;
/*     */     
/* 170 */     if (post != null && post.node().equals(to)) {
/* 171 */       this.out = this.out.next;
/* 172 */       this.outDegree = (byte)(this.outDegree - 1);
/*     */       return;
/*     */     } 
/* 175 */     while (post != null && post.next != null) {
/*     */       
/* 177 */       if (post.next.node().equals(to)) {
/* 178 */         post.next = post.next.next;
/* 179 */         this.outDegree = (byte)(this.outDegree - 1);
/*     */         
/*     */         return;
/*     */       } 
/* 183 */       post = post.next();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 190 */     int prime = 31;
/* 191 */     int result = 1;
/* 192 */     result = 31 * result + ((this.label == null) ? 0 : this.label.hashCode());
/*     */     
/* 194 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 199 */     if (this == obj) {
/* 200 */       return true;
/*     */     }
/* 202 */     if (obj == null) {
/* 203 */       return false;
/*     */     }
/* 205 */     if (getClass() != obj.getClass()) {
/* 206 */       return false;
/*     */     }
/* 208 */     Vertex other = (Vertex)obj;
/* 209 */     if (this.label == null) {
/* 210 */       if (other.label != null) {
/* 211 */         return false;
/*     */       }
/* 213 */     } else if (!this.label.equals(other.label)) {
/* 214 */       return false;
/*     */     } 
/* 216 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Vertex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */