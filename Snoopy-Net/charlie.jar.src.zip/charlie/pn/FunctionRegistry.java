/*    */ package charlie.pn;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionRegistry
/*    */ {
/* 10 */   private HashMap<String, Function> map = new HashMap<>();
/*    */ 
/*    */   
/*    */   public void register(String name, Function f) {
/* 14 */     this.map.put(name, f);
/*    */   }
/*    */   
/*    */   public void clear() {
/* 18 */     this.map.clear();
/*    */   }
/*    */   
/*    */   public Function lookUpFunction(String name) throws Exception {
/* 22 */     Function f = this.map.get(name);
/*    */     
/* 24 */     if (f != null) {
/* 25 */       System.out.println(f.toString());
/* 26 */       return f;
/*    */     } 
/* 28 */     throw new Exception("no Function <" + name + "> registered!");
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/FunctionRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */