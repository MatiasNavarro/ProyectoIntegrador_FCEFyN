/*     */ package charlie.pn;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.IProgressListener;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PetriNetReader
/*     */ {
/*  26 */   private static final Log LOG = LogFactory.getLog(PetriNetReader.class);
/*     */ 
/*     */   
/*     */   protected String file;
/*     */ 
/*     */   
/*     */   protected PlaceTransitionNet pn;
/*     */   
/*     */   protected int placeCounter;
/*     */   
/*     */   protected ConstantRegistry constantRegistry;
/*     */   
/*  38 */   protected final List initialMarking = new Vector();
/*     */   
/*  40 */   protected int currentPlaceId = UnsignedByte.min;
/*  41 */   protected short currentTransId = 0;
/*  42 */   protected short currentArcId = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   protected List<IProgressListener<?>> progressListenerList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int countPlaces();
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int countTransitions();
/*     */ 
/*     */   
/*     */   public void init(String filename, ConstantInterface cI) throws Exception {
/*  74 */     startProgress();
/*     */     
/*  76 */     this.pn = initPlaceTransitionNet();
/*     */     
/*  78 */     this.file = filename;
/*  79 */     initReader(cI);
/*     */   }
/*     */   
/*     */   public void init(String filename) throws Exception {
/*  83 */     init(filename, new DefaultConstantInterface());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PlaceTransitionNet initPlaceTransitionNet() {
/*  92 */     return new PlaceTransitionNet();
/*     */   }
/*     */   
/*     */   protected InputStream getInputStream(String _file) throws IOException {
/*  96 */     PushbackInputStream in = new PushbackInputStream(new BufferedInputStream(new FileInputStream(_file)), 2);
/*  97 */     byte[] signature = new byte[2];
/*  98 */     in.read(signature);
/*  99 */     in.unread(signature);
/*     */     
/* 101 */     int magicNumber = signature[0] & 0xFF | signature[1] << 8 & 0xFF00;
/* 102 */     if (magicNumber == 19280) {
/*     */ 
/*     */       
/* 105 */       ZipInputStream zin = new ZipInputStream(in);
/*     */ 
/*     */ 
/*     */       
/* 109 */       if (zin.getNextEntry() != null) {
/* 110 */         return zin;
/*     */       }
/* 112 */     } else if (35615 == magicNumber) {
/* 113 */       return new GZIPInputStream(in);
/*     */     } 
/*     */     
/* 116 */     return in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void readNet() throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlaceTransitionNet getPlaceTransitionNet() {
/* 134 */     return this.pn;
/*     */   }
/*     */   
/*     */   protected void initReader(ConstantInterface cI) throws Exception {
/* 138 */     UnsignedByte.setMin(0);
/*     */     
/* 140 */     this.currentTransId = 0;
/*     */     
/* 142 */     int places = countPlaces();
/* 143 */     if (places > 127) {
/* 144 */       if (places > 255) {
/* 145 */         SortedElementsFactory.idModeByte(false);
/*     */       } else {
/* 147 */         SortedElementsFactory.idModeByte(true);
/* 148 */         UnsignedByte.setMin(-127);
/*     */       } 
/*     */     }
/*     */     
/* 152 */     updateProgress(10);
/*     */     
/* 154 */     int trans = countTransitions();
/* 155 */     this.currentPlaceId = UnsignedByte.min;
/* 156 */     this.placeCounter = 0;
/* 157 */     this.currentTransId = 0;
/* 158 */     this.currentArcId = 0;
/* 159 */     this.initialMarking.clear();
/* 160 */     LookUpTable.init(places, trans);
/* 161 */     this.constantRegistry = new ConstantRegistry(cI);
/*     */     
/* 163 */     this.pn.pf0 = new PlaceSet(places, places);
/* 164 */     this.pn.fp0 = new PlaceSet(places, places);
/* 165 */     this.pn.ft0 = new TransitionSet(trans, trans);
/* 166 */     this.pn.tf0 = new TransitionSet(trans, trans);
/* 167 */     this.pn.transitionsRead = new TransitionSet(trans);
/* 168 */     this.pn.transitionsInhibitor = new TransitionSet(trans);
/* 169 */     this.pn.transitionsReset = new TransitionSet(trans);
/* 170 */     this.pn.notLive = new TransitionSet(trans);
/* 171 */     this.pn.deadTransitions = new TransitionSet(trans, trans);
/* 172 */     SortedElementsFactory.safeMode(true);
/*     */     
/* 174 */     SortedElementsFactory.tMode(true);
/*     */     
/* 176 */     updateProgress(20);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initNet() throws Exception {
/* 181 */     updateProgress(50);
/*     */     
/* 183 */     for (int i = 0; i < this.initialMarking.size(); i += 2) {
/* 184 */       Place p = this.initialMarking.get(i);
/* 185 */       DebugCounter.inc("initNet: Place " + i + " id=" + p.getId() + " name " + p.getName() + "added to m0");
/*     */       
/* 187 */       this.pn.placesM0.addPlace(p.getId(), ((Integer)this.initialMarking.get(i + 1)).intValue());
/*     */     } 
/*     */     
/* 190 */     this.pn.createM0();
/*     */     
/* 192 */     updateProgress(60);
/*     */     
/* 194 */     this.pn.conflicts();
/*     */     
/* 196 */     updateProgress(75);
/*     */     
/* 198 */     for (Iterator<Transition> it = this.pn.getTransitions().iterator(); it.hasNext(); ) {
/* 199 */       Transition t = it.next();
/* 200 */       t.transformSortedPlaces();
/* 201 */       SortedElementsDynamic pp = new SortedElementsDynamic(true);
/* 202 */       int val = 0;
/* 203 */       NodeSet pre = t.preNodes();
/* 204 */       NodeSet post = t.postNodes();
/* 205 */       for (int j = 0; j < this.pn.places(); j++) {
/* 206 */         val = 0;
/* 207 */         if (pre.member(j) && !post.member(j)) {
/* 208 */           val = 1;
/* 209 */         } else if (!pre.member(j) && post.member(j)) {
/* 210 */           val = 2;
/* 211 */         } else if (pre.member(j) && post.member(j)) {
/* 212 */           val = 3;
/*     */         } 
/* 214 */         if (val > 0) {
/* 215 */           pp.addPlace(this.pn.getPlaceByIndex(j).getId(), val);
/*     */         }
/*     */       } 
/* 218 */       t.setPrePost(pp.toArray());
/*     */     } 
/*     */     
/* 221 */     updateProgress(90);
/*     */     
/* 223 */     NodeSet.setNet(this.pn);
/*     */     
/* 225 */     updateProgress(95);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String replaceSpace(String str) {
/* 230 */     StringBuffer stb = new StringBuffer();
/* 231 */     for (int i = 0; i < str.length(); i++) {
/* 232 */       char c = str.charAt(i);
/* 233 */       switch (c) {
/*     */         case '\t':
/*     */         case '\n':
/*     */         case ' ':
/*     */         case ':':
/* 238 */           c = '_';
/*     */           break;
/*     */       } 
/* 241 */       stb.append(c);
/*     */     } 
/*     */     
/* 244 */     return stb.toString();
/*     */   }
/*     */   
/*     */   protected void writePlaceListToFile(String filename) {
/*     */     try {
/* 249 */       BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
/* 250 */       for (int i = 0; i < this.pn.places(); i++) {
/* 251 */         String toWrite = this.pn.getPlaceByIndex(this.pn.places() - i - 1).getName() + "\n";
/* 252 */         bw.write(toWrite);
/*     */       } 
/* 254 */       bw.close();
/* 255 */     } catch (Exception e) {
/* 256 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void updateProgress(int _progress) {
/* 261 */     for (IProgressListener<?> listener : this.progressListenerList) {
/* 262 */       listener.processProgess(_progress);
/*     */     }
/*     */   }
/*     */   
/*     */   private void startProgress() {
/* 267 */     for (IProgressListener<?> listener : this.progressListenerList) {
/* 268 */       listener.processStarted();
/*     */     }
/*     */   }
/*     */   
/*     */   public void loadingFinished() {
/* 273 */     for (IProgressListener<?> listener : this.progressListenerList) {
/* 274 */       listener.processFinished();
/*     */     }
/*     */   }
/*     */   
/*     */   public void addProgressListener(IProgressListener<?> _listener) {
/* 279 */     this.progressListenerList.add(_listener);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/PetriNetReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */