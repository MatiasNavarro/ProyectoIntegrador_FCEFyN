/*    */ package charlie.pn;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TraversationDataTable
/*    */ {
/* 12 */   private HashMap map = new HashMap<>();
/*    */ 
/*    */   
/*    */   public int num(Object key) {
/* 16 */     TraversationData td = (TraversationData)this.map.get(key);
/* 17 */     if (td == null) {
/* 18 */       System.out.println(key + " num:" + -1);
/* 19 */       return -1;
/*    */     } 
/* 21 */     return td.num();
/*    */   }
/*    */   
/*    */   public int low(Object key) {
/* 25 */     TraversationData td = (TraversationData)this.map.get(key);
/* 26 */     if (td == null) {
/* 27 */       System.out.println(key + " low:" + -1);
/* 28 */       return -1;
/*    */     } 
/* 30 */     return td.uplink();
/*    */   }
/*    */ 
/*    */   
/*    */   public void add(Object key, int num) {
/* 35 */     this.map.put(key, new TraversationData(num));
/*    */   }
/*    */   
/*    */   public void setLow(Object key, int low) {
/* 39 */     TraversationData td = (TraversationData)this.map.get(key);
/* 40 */     if (td == null)
/* 41 */       return;  td.setUplink(low);
/*    */   }
/*    */   
/*    */   public void setMinLow(Object key, int n1, int n2) {
/* 45 */     TraversationData td = (TraversationData)this.map.get(key);
/* 46 */     if (td == null) {
/* 47 */       System.out.println(key + " setMin:" + -1);
/*    */       return;
/*    */     } 
/* 50 */     if (n2 < n1)
/* 51 */       td.setUplink(n2); 
/*    */   }
/*    */   
/*    */   public boolean visited(Object key) {
/* 55 */     TraversationData td = (TraversationData)this.map.get(key);
/* 56 */     if (td == null) {
/* 57 */       this.map.put(key, new TraversationData(0));
/* 58 */       td = (TraversationData)this.map.get(key);
/*    */     } 
/*    */     
/* 61 */     return td.visited();
/*    */   }
/*    */   
/*    */   public void setVisited(Object key, boolean v) {
/* 65 */     TraversationData td = (TraversationData)this.map.get(key);
/* 66 */     if (td == null) {
/* 67 */       this.map.put(key, new TraversationData(0));
/* 68 */       td = (TraversationData)this.map.get(key);
/*    */     } 
/* 70 */     td.setVisited(v);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/TraversationDataTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */