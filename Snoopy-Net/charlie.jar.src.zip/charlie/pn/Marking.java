/*     */ package charlie.pn;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import java.util.Collection;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Marking
/*     */   extends State
/*     */ {
/*     */   private static final long serialVersionUID = -8570796506039107540L;
/*     */   public static final int OMEGA = 2147483647;
/*     */   
/*     */   public int getMaxToken() {
/*  57 */     int max = 0;
/*  58 */     for (int i = 0; i < size(); i++) {
/*  59 */       if (max < getToken(i)) {
/*  60 */         max = getToken(i);
/*     */       }
/*     */     } 
/*  63 */     return max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Marking getPlaceMarking() {
/*  70 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Marking getTransitionMarking() {
/*  76 */     DebugCounter.inc("marking.getTransitionMarking called!");
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlaceMarking(Marking placeSet) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTransitionMarking(Marking transitionSet) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Marking translate(Vector<Integer> translationTable) throws SafetyException, ExceedsByteException {
/* 110 */     SortedElementsDynamic sp = new SortedElementsDynamic(true);
/* 111 */     sp.name = " Marking translate";
/* 112 */     for (int i = 0; i < translationTable.size(); i++) {
/* 113 */       int id = UnsignedByte.sign(((Integer)translationTable.get(i)).intValue());
/* 114 */       int token = getTokenById(id);
/* 115 */       if (token > 0) {
/* 116 */         sp.addPlace(UnsignedByte.sign(i), token);
/*     */       }
/*     */     } 
/*     */     
/* 120 */     Marking res = sp.toArray();
/* 121 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSubSet(Marking spa) {
/* 132 */     if (spa == null) {
/* 133 */       return false;
/*     */     }
/* 135 */     if (size() > spa.size()) {
/* 136 */       return false;
/*     */     }
/* 138 */     int index = 0;
/* 139 */     int i = 0;
/* 140 */     Weight current = get(index);
/* 141 */     while (index < size()) {
/*     */       
/* 143 */       int curId = current.getId();
/* 144 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 145 */         i++;
/*     */       }
/* 147 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 148 */         return false;
/*     */       }
/* 150 */       current = get(++index);
/* 151 */       i++;
/*     */     } 
/* 153 */     return true;
/*     */   }
/*     */   
/*     */   public int calculateAutoFiring(Marking spa) {
/* 157 */     if (spa == null) {
/* 158 */       return 0;
/*     */     }
/* 160 */     if (size() > spa.size()) {
/* 161 */       return 0;
/*     */     }
/* 163 */     int index = 0;
/* 164 */     int i = 0;
/* 165 */     int maxfirings = Integer.MAX_VALUE;
/* 166 */     Weight current = get(index);
/* 167 */     while (index < size()) {
/*     */       
/* 169 */       int curId = current.getId();
/* 170 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 171 */         i++;
/*     */       }
/* 173 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 174 */         return 0;
/*     */       }
/* 176 */       if (spa.get(i).getToken() / current.getToken() < maxfirings) {
/* 177 */         maxfirings = spa.get(i).getToken() / current.getToken();
/*     */       }
/* 179 */       current = get(++index);
/* 180 */       i++;
/*     */     } 
/* 182 */     if (maxfirings == Integer.MAX_VALUE) {
/* 183 */       maxfirings = 1;
/*     */     }
/* 185 */     return maxfirings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean marksPlaceSufficient(int id, int vminus) {
/* 196 */     return (getTokenById(id) >= vminus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean allLess(Marking spa) {
/* 206 */     int index = 0;
/* 207 */     int i = 0;
/* 208 */     Weight current = get(index);
/* 209 */     while (index < size()) {
/* 210 */       int curId = current.getId();
/* 211 */       while (i < spa.size() && spa.get(i).getId() < curId) {
/* 212 */         i++;
/*     */       }
/* 214 */       if (i == spa.size()) {
/* 215 */         return true;
/*     */       }
/*     */       
/* 218 */       if (curId == spa.get(i).getId()) {
/* 219 */         if (current.less(spa.get(i)) >= 0) {
/* 220 */           return false;
/*     */         }
/* 222 */         i++;
/*     */       } 
/* 224 */       current = get(++index);
/*     */     } 
/* 226 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<? extends Number> covers(Marking spa) {
/* 296 */     if (spa.size() > size()) {
/* 297 */       return null;
/*     */     }
/*     */     
/* 300 */     Vector<Integer> v = null;
/*     */     
/* 302 */     int index = 0;
/* 303 */     int i = 0;
/* 304 */     while (index < spa.size()) {
/* 305 */       Weight current = spa.get(index);
/* 306 */       int curId = current.getId();
/* 307 */       while (i < size() && get(i).getId() != curId) {
/* 308 */         if (getId(i) > curId) {
/* 309 */           return null;
/*     */         }
/*     */         
/* 312 */         if (v == null) {
/* 313 */           v = new Vector<>();
/*     */         }
/*     */         
/* 316 */         v.add(new Integer(getId(i)));
/* 317 */         i++;
/*     */       } 
/*     */       
/* 320 */       if (i == size() || current.less(get(i)) < 0) {
/* 321 */         return null;
/*     */       }
/*     */       
/* 324 */       if (i < size() && getId(i) == curId && current.getToken() < get(i).getToken()) {
/* 325 */         if (v == null) {
/* 326 */           v = new Vector<>();
/*     */         }
/* 328 */         v.add(new Integer(get(i).getId()));
/*     */       } 
/*     */       
/* 331 */       index++;
/* 332 */       i++;
/*     */     } 
/*     */     
/* 335 */     while (i < size()) {
/* 336 */       if (v == null) {
/* 337 */         v = new Vector<>();
/*     */       }
/*     */       
/* 340 */       v.add(new Integer(getId(i)));
/* 341 */       i++;
/*     */     } 
/*     */     
/* 344 */     return (Collection)v;
/*     */   }
/*     */   
/*     */   public abstract String toString();
/*     */   
/*     */   public abstract int size();
/*     */   
/*     */   public abstract boolean equals(Object paramObject);
/*     */   
/*     */   public abstract Weight get(int paramInt);
/*     */   
/*     */   public abstract Collection<? extends Number> scapeGoats(Marking paramMarking);
/*     */   
/*     */   public abstract int fSG(Marking paramMarking);
/*     */   
/*     */   public abstract int isSubSet2(Marking paramMarking);
/*     */   
/*     */   public abstract boolean retains(Marking paramMarking);
/*     */   
/*     */   public abstract int addPlace(int paramInt1, int paramInt2) throws SafetyException, ExceedsByteException;
/*     */   
/*     */   public abstract Marking toArray() throws SafetyException, ExceedsByteException;
/*     */   
/*     */   public abstract int getId(int paramInt);
/*     */   
/*     */   public abstract int getToken(int paramInt);
/*     */   
/*     */   public abstract int getTokenById(int paramInt);
/*     */   
/*     */   public abstract Marking copy() throws SafetyException, ExceedsByteException;
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Marking.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */