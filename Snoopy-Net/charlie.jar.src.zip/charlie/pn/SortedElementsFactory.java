/*     */ package charlie.pn;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ 
/*     */ public class SortedElementsFactory
/*     */ {
/*     */   public static boolean BYTE = true;
/*     */   public static boolean SAFE = true;
/*     */   public static boolean SAFET = true;
/*     */   private static boolean idModeByte = true;
/*     */   
/*     */   public static void idModeByte(boolean b) {
/*  13 */     DebugCounter.inc("SortedElementsFactory.idModeByte(b = " + b + " )");
/*  14 */     idModeByte = b;
/*     */   }
/*     */   
/*     */   public static boolean idModeByte() {
/*  18 */     return idModeByte;
/*     */   }
/*     */   
/*     */   public Marking getBitSet() {
/*  22 */     return new SortedElementsBitSet(true);
/*     */   }
/*     */   
/*     */   public Marking getByteArray() {
/*  26 */     return new SortedElementsByteArray(LookUpTable.places());
/*     */   }
/*     */   
/*     */   public Marking getWeights() {
/*  30 */     return new SortedWeights(LookUpTable.places());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean byteMode() {
/*  43 */     return BYTE;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean safeMode() {
/*  48 */     return SAFE;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void byteMode(boolean b) {
/*  53 */     BYTE = b;
/*  54 */     if (b && SAFE) safeMode(false); 
/*     */   }
/*     */   
/*     */   public static void weightsMode(boolean b) {
/*  58 */     DebugCounter.inc("SortedElementsFactory.weightsMode(b = " + b + " )");
/*  59 */     BYTE = false;
/*  60 */     SAFE = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void safeMode(boolean b) {
/*  65 */     SAFE = b;
/*  66 */     if (b) { byteMode(false); }
/*  67 */     else { byteMode(true); }
/*     */   
/*     */   }
/*     */   public static boolean tMode() {
/*  71 */     return SAFET;
/*     */   }
/*     */   
/*     */   public static void tMode(boolean b) {
/*  75 */     SAFET = b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Marking getSortedPlaces(int size) {
/*  81 */     if (idModeByte) {
/*     */ 
/*     */       
/*  84 */       if (BYTE)
/*  85 */         return new SortedElementsByteArray(size); 
/*  86 */       if (SAFE) {
/*  87 */         return new SortedElementsBitSet(true);
/*     */       }
/*     */       
/*  90 */       return new SortedWeights(size);
/*     */     } 
/*     */     
/*  93 */     if (SAFE) {
/*  94 */       return new SortedElementsBitSet(true);
/*     */     }
/*  96 */     return new SortedWeights(size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Marking getSortedPlacesForTransition(int size) {
/* 103 */     Marking ret = null;
/* 104 */     if (idModeByte) {
/* 105 */       if (SAFE)
/* 106 */         return new SortedElementsBitSet(false); 
/* 107 */       if (BYTE) {
/* 108 */         return new SortedElementsByteArray(size);
/*     */       }
/*     */       
/* 111 */       return new SortedWeights(size);
/*     */     } 
/*     */     
/* 114 */     if (SAFE) {
/* 115 */       return new SortedElementsBitSet(false);
/*     */     }
/* 117 */     return new SortedWeights(size);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SortedElementsFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */