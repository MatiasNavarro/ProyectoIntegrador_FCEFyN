/*     */ package charlie.pn;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SortedElementsShortArray
/*     */   extends Marking {
/*     */   private short[] places;
/*     */   
/*     */   public void reset() {
/*  11 */     UnsignedByte.init(this.places, size());
/*  12 */     this.size = 0;
/*  13 */     this.hashC = 0;
/*     */   }
/*     */   private int hashC; private short size;
/*     */   public int getTokenById(int id) {
/*  17 */     for (int i = 0; i < size(); i++) {
/*  18 */       if (this.places[i] == id) {
/*  19 */         return 1;
/*     */       }
/*     */     } 
/*  22 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public SortedElementsShortArray copy() throws SafetyException {
/*  27 */     SortedElementsShortArray ret = new SortedElementsShortArray(size());
/*  28 */     for (int i = 0; i < size(); i++) {
/*  29 */       ret.addPlace(getId(i), 1);
/*     */     }
/*  31 */     ret.hashC = this.hashC;
/*  32 */     return ret;
/*     */   }
/*     */   
/*     */   public SortedElementsShortArray(short[] p) {
/*  36 */     this.places = p;
/*  37 */     this.size = (short)p.length;
/*  38 */     for (int i = p.length - 1; i >= 0 && 
/*  39 */       this.places[i] == UnsignedByte.zero; i--) {
/*  40 */       this.size = (short)(this.size - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedElementsShortArray(int p) {
/*  49 */     this.places = new short[p];
/*  50 */     UnsignedByte.init(this.places);
/*  51 */     this.size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  59 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedElementsShortArray toArray() throws SafetyException {
/*  65 */     return copy();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  69 */     StringBuffer res = new StringBuffer();
/*  70 */     for (int i = 0; i < size(); i++) {
/*  71 */       res.append(this.places[i]);
/*  72 */       res.append(" 1");
/*  73 */       if (i < size() - 1) res.append(" "); 
/*     */     } 
/*  75 */     return res.toString();
/*     */   }
/*     */   
/*     */   public Weight get(int index) {
/*  79 */     if (index >= size() || index < 0) {
/*  80 */       return null;
/*     */     }
/*  82 */     Weight ret = LookUpTable.lookUp(this.places[index], 1);
/*  83 */     return ret;
/*     */   }
/*     */   
/*     */   public int getId(int index) {
/*  87 */     return this.places[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getToken(int index) {
/*  92 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setToken(int index, Short t) {
/*  99 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addToken(int index, Short t) {
/* 110 */     return 1;
/*     */   }
/*     */   
/*     */   public short[] getPlaces() {
/* 114 */     return this.places;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 118 */     if (!(obj instanceof SortedElementsShortArray)) return false; 
/* 119 */     SortedElementsShortArray spa = (SortedElementsShortArray)obj;
/* 120 */     if (size() != spa.size()) return false; 
/* 121 */     for (int i = 0; i < size(); i++) {
/* 122 */       if (this.places[i] != spa.places[i]) {
/* 123 */         return false;
/*     */       }
/*     */     } 
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 131 */     int h = this.hashC;
/* 132 */     if (h == 0) {
/* 133 */       for (int i = 0; i < size(); i++) {
/* 134 */         this.hashC = 31 * this.hashC + this.places[i];
/*     */       }
/* 136 */       h = this.hashC;
/*     */     } 
/* 138 */     return h;
/*     */   }
/*     */ 
/*     */   
/*     */   public int addPlace(int id, int token) {
/* 143 */     int i = 0;
/* 144 */     boolean b = true;
/* 145 */     int index = 0;
/*     */ 
/*     */     
/* 148 */     for (i = 0; b && i < this.places.length; i++) {
/* 149 */       if (this.places[i] >= id || this.places[i] == UnsignedByte.zero) {
/*     */ 
/*     */ 
/*     */         
/* 153 */         b = false;
/* 154 */         index = i;
/* 155 */         if (this.places[i] == id) {
/* 156 */           System.out.println("not save"); System.exit(1);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 162 */     for (i = this.places.length - 1; i > index; i--) {
/* 163 */       this.places[i] = this.places[i - 1];
/*     */     }
/* 165 */     this.places[index] = (short)id;
/* 166 */     LookUpTable.addPlace(id, 1);
/* 167 */     this.size = (short)(this.size + 1);
/* 168 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int isSubSet2(Marking sp) {
/* 176 */     if (!(sp instanceof SortedElementsShortArray)) return -1; 
/* 177 */     SortedElementsShortArray spa = (SortedElementsShortArray)sp;
/* 178 */     if (size() > spa.size()) return (short)(UnsignedByte.min - 1); 
/* 179 */     int ret = 0;
/* 180 */     int index = 0;
/* 181 */     int i = 0;
/* 182 */     Weight current = get(index);
/* 183 */     while (index < size()) {
/*     */       
/* 185 */       int curId = current.getId();
/* 186 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 187 */         if (spa.getId(i) > curId) return -1; 
/* 188 */         i++;
/*     */       } 
/* 190 */       if (i == spa.size() || current.less(spa.get(i)) < 0) return -1;
/*     */       
/* 192 */       if (i < spa.size() && current.less(spa.get(i)) == 0) ret++; 
/* 193 */       current = get(++index);
/* 194 */       i++;
/*     */     } 
/* 196 */     return spa.size() - ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection scapeGoats(Marking spa) {
/* 202 */     Collection<Integer> c = new Vector();
/* 203 */     int index = 0;
/* 204 */     int i = 0;
/* 205 */     Weight current = get(index);
/* 206 */     while (index < size()) {
/* 207 */       int curId = current.getId();
/* 208 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 209 */         i++;
/*     */       }
/* 211 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 212 */         c.add(new Integer((short)curId));
/* 213 */         i = 0;
/* 214 */         current = get(++index);
/*     */         
/*     */         continue;
/*     */       } 
/* 218 */       current = get(++index);
/* 219 */       i++;
/*     */     } 
/* 221 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int fSG(Marking spa) {
/* 228 */     int index = 0;
/* 229 */     int i = 0;
/* 230 */     Weight current = get(index);
/* 231 */     while (index < size()) {
/* 232 */       int curId = current.getId();
/* 233 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 234 */         i++;
/*     */       }
/* 236 */       if (i == spa.size() || current.less(spa.get(i)) < 0) return (short)curId; 
/* 237 */       current = get(++index);
/* 238 */       i++;
/*     */     } 
/* 240 */     return (short)(UnsignedByte.min - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retains(Marking s) {
/* 245 */     int index = 0;
/* 246 */     int i = 0;
/* 247 */     Weight current = get(index);
/*     */     
/* 249 */     while (index < size()) {
/* 250 */       Weight current2 = s.get(i);
/*     */       
/* 252 */       int curId = current.getId();
/* 253 */       while (i < s.size() && current2.getId() < curId) {
/* 254 */         current2 = s.get(++i);
/*     */       }
/* 256 */       if (i < s.size() && curId == current2.getId()) return true; 
/* 257 */       current2 = s.get(++i);
/* 258 */       current = get(++index);
/*     */     } 
/* 260 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SortedElementsShortArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */