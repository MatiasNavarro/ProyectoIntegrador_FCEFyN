package charlie.pn;

public interface ReactionTimeTransition {
  State reactionFire(State paramState) throws SafetyException, ExceedsByteException;
  
  boolean reactionCanFire(State paramState);
  
  boolean reactionMustFire(State paramState);
  
  State reactionHandleClocks(State paramState1, State paramState2, PlaceTransitionNet paramPlaceTransitionNet, int paramInt) throws SafetyException, ExceedsByteException;
  
  int getLft(byte paramByte1, byte paramByte2);
  
  int getEft(byte paramByte1, byte paramByte2);
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/ReactionTimeTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */