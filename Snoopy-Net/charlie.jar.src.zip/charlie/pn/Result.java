/*     */ package charlie.pn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Result
/*     */ {
/*     */   public static final int NO_TYPE = -1;
/*     */   public static final int INTEGER = 0;
/*     */   public static final int BOOLEAN = 1;
/*     */   public static final int STRING = 2;
/*     */   private Object val;
/*     */   
/*     */   public Result(Object val) {
/*  16 */     this.val = val;
/*     */   }
/*     */   
/*     */   public String getValue() {
/*  20 */     String res = "null";
/*  21 */     if (this.val instanceof Boolean) {
/*  22 */       if (((Boolean)this.val).booleanValue()) {
/*  23 */         return " Y ";
/*     */       }
/*  25 */       return " N ";
/*     */     } 
/*     */     
/*  28 */     if (this.val instanceof Integer) {
/*  29 */       return this.val.toString();
/*     */     }
/*  31 */     if (this.val instanceof String) {
/*  32 */       return this.val.toString();
/*     */     }
/*  34 */     return res;
/*     */   }
/*     */   
/*     */   public int getType() {
/*  38 */     if (this.val instanceof Boolean) {
/*  39 */       return 1;
/*     */     }
/*  41 */     if (this.val instanceof Integer) {
/*  42 */       return 0;
/*     */     }
/*  44 */     if (this.val instanceof String) {
/*  45 */       return 2;
/*     */     }
/*  47 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result copy() {
/*  56 */     Result returnResult = null;
/*     */     
/*  58 */     switch (getType())
/*     */     
/*     */     { case 0:
/*  61 */         returnResult = new Result(this.val);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  77 */         return returnResult;case 1: returnResult = new Result(this.val); return returnResult;case 2: returnResult = new Result(this.val); return returnResult; }  returnResult = new Result(getValue()); return returnResult;
/*     */   }
/*     */   
/*     */   public boolean equals(Result r) {
/*  81 */     if (getType() == r.getType())
/*     */     {
/*  83 */       if (getValue().equals(r.getValue())) {
/*  84 */         return true;
/*     */       }
/*     */     }
/*  87 */     return false;
/*     */   }
/*     */   
/*     */   public boolean nequals(Result r) {
/*  91 */     return !equals(r);
/*     */   }
/*     */   
/*     */   public boolean gt(Result r) {
/*  95 */     if (getType() == 0) {
/*  96 */       return (((Integer)this.val).intValue() > ((Integer)r.getValueObject()).intValue());
/*     */     }
/*  98 */     return false;
/*     */   }
/*     */   
/*     */   public boolean lt(Result r) {
/* 102 */     if (getType() == 0) {
/* 103 */       return (!gt(r) && !equals(r));
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */   
/*     */   public boolean lteq(Result r) {
/* 109 */     if (getType() == 0) {
/* 110 */       return !gt(r);
/*     */     }
/* 112 */     return false;
/*     */   }
/*     */   
/*     */   public boolean gteq(Result r) {
/* 116 */     if (getType() == 0) {
/* 117 */       return (gt(r) && equals(r));
/*     */     }
/* 119 */     return false;
/*     */   }
/*     */   
/*     */   public Object getValueObject() {
/* 123 */     return this.val;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 127 */     return this.val.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Result.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */