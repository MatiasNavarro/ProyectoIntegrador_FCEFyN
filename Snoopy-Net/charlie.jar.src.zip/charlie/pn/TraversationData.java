/*    */ package charlie.pn;
/*    */ 
/*    */ public class TraversationData {
/*    */   int uplink;
/*    */   int num;
/*    */   byte visited;
/*    */   
/*    */   public TraversationData() {
/*  9 */     this.num = 0;
/* 10 */     this.uplink = 0;
/* 11 */     this.visited = 0;
/*    */   }
/*    */   
/*    */   public TraversationData(int n) {
/* 15 */     this.num = n;
/* 16 */     this.uplink = n;
/* 17 */     this.visited = 0;
/*    */   }
/*    */   
/*    */   public void setNum(int n) {
/* 21 */     this.num = n;
/*    */   }
/*    */   
/*    */   public int num() {
/* 25 */     return this.num;
/*    */   }
/*    */   
/*    */   public void setUplink(int up) {
/* 29 */     this.uplink = up;
/*    */   }
/*    */   
/*    */   public int uplink() {
/* 33 */     return this.uplink;
/*    */   }
/*    */   
/*    */   public boolean visited() {
/* 37 */     return (this.visited == 1);
/*    */   }
/*    */   
/*    */   public void setVisited(boolean v) {
/* 41 */     if (v) {
/* 42 */       this.visited = 1;
/*    */     } else {
/* 44 */       this.visited = 0;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/TraversationData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */