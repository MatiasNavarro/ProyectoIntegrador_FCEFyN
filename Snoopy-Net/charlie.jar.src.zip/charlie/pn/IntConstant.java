/*    */ package charlie.pn;
/*    */ 
/*    */ public class IntConstant
/*    */   extends Constant {
/*    */   public Constant.Type getType() {
/*  6 */     return Constant.Type.INT;
/*    */   }
/*    */   
/*    */   public IntConstant(String name, String value) {
/* 10 */     super(name, value);
/*    */   }
/*    */   
/*    */   public int getValue() throws NumberFormatException {
/*    */     try {
/* 15 */       return Integer.parseInt(this.value);
/* 16 */     } catch (NumberFormatException e) {
/* 17 */       Out.println("Cannot parse the constant value " + toString() + "! Charlie does not support arithmetic expressions!");
/* 18 */       throw e;
/*    */     } 
/*    */   }
/*    */   
/*    */   public String toString() {
/* 23 */     return "IntConstant " + getName() + " : " + this.value;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/IntConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */