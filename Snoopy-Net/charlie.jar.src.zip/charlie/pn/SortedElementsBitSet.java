/*     */ package charlie.pn;
/*     */ 
/*     */ import charlie.ds.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SortedElementsBitSet
/*     */   extends Marking {
/*     */   private BitSet places;
/*     */   private int hashC;
/*  12 */   private static SortedElementsBitSet dummy = new SortedElementsBitSet(true);
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isPlaceMarking = true;
/*     */ 
/*     */   
/*     */   private short size;
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTokenById(int id) {
/*  24 */     if (this.places.member(UnsignedByte.unsign(id)))
/*  25 */       return 1; 
/*  26 */     return 0;
/*     */   }
/*     */   
/*     */   public Marking copy() throws SafetyException, ExceedsByteException {
/*     */     Marking ret;
/*  31 */     if (this.isPlaceMarking) {
/*  32 */       ret = SortedElementsFactory.getSortedPlaces(size());
/*  33 */       ret.name += "SEBitSet.copy() placeMarking->" + this.name;
/*     */     } else {
/*  35 */       ret = SortedElementsFactory.getSortedPlacesForTransition(size());
/*  36 */       ret.name += "SEBitSet.copy() transitionMarking->" + this.name;
/*     */     } 
/*  38 */     for (int i = 0; i < size(); i++) {
/*  39 */       ret.addPlace(getId(i), 1);
/*     */     }
/*  41 */     if (ret instanceof SortedElementsBitSet) {
/*  42 */       ((SortedElementsBitSet)ret).hashC = this.hashC;
/*     */     }
/*     */ 
/*     */     
/*  46 */     return ret;
/*     */   }
/*     */   
/*     */   public SortedElementsBitSet(boolean isPlaceMarking) {
/*  50 */     if (isPlaceMarking) {
/*  51 */       this.places = new BitSet(LookUpTable.places());
/*     */     } else {
/*  53 */       this.places = new BitSet(LookUpTable.transitions());
/*  54 */     }  this.isPlaceMarking = isPlaceMarking;
/*  55 */     this.size = 0;
/*     */   }
/*     */   
/*     */   public SortedElementsBitSet(BitSet p) {
/*  59 */     this.places = p;
/*  60 */     this.size = (short)p.size();
/*     */   }
/*     */   
/*     */   public SortedElementsBitSet(BitSet p, int size) {
/*  64 */     this.places = p;
/*  65 */     this.size = (short)size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  71 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedElementsBitSet toArray() throws SafetyException, ExceedsByteException {
/*  77 */     return (SortedElementsBitSet)copy();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  82 */     StringBuffer res = new StringBuffer();
/*  83 */     for (int i = 0; i < size(); i++) {
/*     */       
/*  85 */       res.append(UnsignedByte.sign(this.places.getElementAt(i)));
/*  86 */       res.append("_1");
/*  87 */       if (i < size() - 1) {
/*  88 */         res.append("_");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  93 */     return res.toString();
/*     */   }
/*     */   
/*     */   public Weight get(int index) {
/*  97 */     if (index >= size() || index < 0) {
/*  98 */       return null;
/*     */     }
/*     */     
/* 101 */     Weight ret = LookUpTable.lookUp(getId(index), 1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     return ret;
/*     */   }
/*     */   
/*     */   public int getId(int index) {
/* 110 */     return UnsignedByte.sign(this.places.getElementAt(index));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getToken(int index) {
/* 115 */     return 1;
/*     */   }
/*     */   
/*     */   public int setToken(int index, byte t) throws SafetyException {
/* 119 */     if (t > 1)
/*     */     {
/*     */ 
/*     */       
/* 123 */       throw new SafetyException();
/*     */     }
/* 125 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int addToken(int index, byte t) throws SafetyException {
/* 130 */     if (t > 1)
/*     */     {
/*     */ 
/*     */       
/* 134 */       throw new SafetyException();
/*     */     }
/* 136 */     return 1;
/*     */   }
/*     */   
/*     */   public byte[] getPlaces() {
/* 140 */     byte[] ret = new byte[this.size];
/* 141 */     for (int i = 0; i < this.size; i++) {
/* 142 */       ret[i] = (byte)this.places.getElementAt(i);
/*     */     }
/* 144 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean isEqual(Marking sp) {
/* 148 */     if (sp.size() != size())
/* 149 */       return false; 
/* 150 */     for (int i = 0; i < this.size; i++) {
/* 151 */       if (!get(i).equals(sp.get(i)))
/* 152 */         return false; 
/*     */     } 
/* 154 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 158 */     if (obj instanceof SortedElementsBitSet) {
/* 159 */       return this.places.equals(((SortedElementsBitSet)obj).places);
/*     */     }
/* 161 */     return isEqual((Marking)obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 166 */     int h = this.hashC;
/* 167 */     if (h == 0) {
/*     */       
/* 169 */       for (Iterator<Integer> it = this.places.iterator(); it.hasNext();) {
/* 170 */         this
/* 171 */           .hashC = 31 * this.hashC + UnsignedByte.sign(((Integer)it.next()).intValue());
/*     */       }
/* 173 */       h = this.hashC;
/*     */     } 
/*     */     
/* 176 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addPlace(int id, int token) throws SafetyException {
/* 183 */     id = UnsignedByte.unsign(id);
/*     */     
/* 185 */     if (token > 1)
/*     */     {
/*     */ 
/*     */       
/* 189 */       throw new SafetyException();
/*     */     }
/* 191 */     if (this.places.member(id))
/*     */     {
/*     */       
/* 194 */       throw new SafetyException();
/*     */     }
/*     */     
/* 197 */     this.places.insert(id);
/* 198 */     LookUpTable.addPlace(UnsignedByte.sign(id), 1);
/* 199 */     this.size = (short)(this.size + 1);
/*     */     
/* 201 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSubSet(Marking sp) {
/* 206 */     if (sp instanceof SortedElementsBitSet)
/* 207 */       return this.places.subSet(((SortedElementsBitSet)sp).places); 
/* 208 */     return super.isSubSet(sp);
/*     */   }
/*     */ 
/*     */   
/*     */   public int isSubSet2(Marking spa) {
/* 213 */     if (spa instanceof SortedElementsByte) {
/*     */       
/* 215 */       SortedElementsBitSet spb = (SortedElementsBitSet)spa;
/* 216 */       dummy.places.clear();
/* 217 */       dummy.places.union(spb.places);
/*     */       
/* 219 */       if (dummy.places.subSet(spb.places)) {
/* 220 */         dummy.places.diff(this.places);
/* 221 */         int j = dummy.places.size();
/*     */         
/* 223 */         return j;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 228 */       return -1;
/*     */     } 
/*     */     
/* 231 */     if (size() > spa.size()) {
/* 232 */       return (byte)(UnsignedByte.min - 1);
/*     */     }
/* 234 */     int ret = 0;
/* 235 */     int index = 0;
/* 236 */     int i = 0;
/*     */     
/* 238 */     Weight current = get(index);
/*     */     
/* 240 */     while (index < size()) {
/*     */       
/* 242 */       int curId = current.getId();
/*     */       
/* 244 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 245 */         if (spa.getId(i) > curId) {
/* 246 */           return -1;
/*     */         }
/*     */         
/* 249 */         i++;
/*     */       } 
/* 251 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 252 */         return -1;
/*     */       }
/*     */       
/* 255 */       if (i < spa.size() && current.less(spa.get(i)) == 0) {
/* 256 */         ret++;
/*     */       }
/*     */       
/* 259 */       current = get(++index);
/* 260 */       i++;
/*     */     } 
/*     */     
/* 263 */     return spa.size() - ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection scapeGoats(Marking spa) {
/* 269 */     Collection<Integer> c = new Vector();
/* 270 */     int index = 0;
/* 271 */     int i = 0;
/* 272 */     Weight current = get(index);
/* 273 */     while (index < size()) {
/* 274 */       int curId = current.getId();
/* 275 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 276 */         i++;
/*     */       }
/* 278 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 279 */         c.add(new Integer((byte)curId));
/* 280 */         i = 0;
/* 281 */         current = get(++index);
/*     */         
/*     */         continue;
/*     */       } 
/* 285 */       current = get(++index);
/* 286 */       i++;
/*     */     } 
/* 288 */     return c;
/*     */   }
/*     */   
/*     */   public int fSG(Marking spa) {
/* 292 */     int index = 0;
/* 293 */     int i = 0;
/* 294 */     Weight current = get(index);
/* 295 */     while (index < size()) {
/* 296 */       int curId = current.getId();
/* 297 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 298 */         i++;
/*     */       }
/* 300 */       if (i == spa.size() || current.less(spa.get(i)) < 0)
/* 301 */         return (byte)curId; 
/* 302 */       current = get(++index);
/* 303 */       i++;
/*     */     } 
/* 305 */     return UnsignedByte.min - 1;
/*     */   }
/*     */   
/*     */   public boolean retains(Marking s) {
/* 309 */     int index = 0;
/* 310 */     int i = 0;
/* 311 */     Weight current = get(index);
/*     */     
/* 313 */     while (index < size()) {
/* 314 */       Weight current2 = s.get(i);
/*     */       
/* 316 */       int curId = current.getId();
/* 317 */       while (i < s.size() && current2.getId() < curId) {
/* 318 */         current2 = s.get(++i);
/*     */       }
/* 320 */       if (i < s.size() && curId == current2.getId())
/* 321 */         return true; 
/* 322 */       current2 = s.get(++i);
/* 323 */       current = get(++index);
/*     */     } 
/* 325 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Marking getNewState(SortedElementsBitSet pre, SortedElementsBitSet post) throws SafetyException {
/* 331 */     if (!pre.places.subSet(this.places))
/* 332 */       return null; 
/* 333 */     SortedElementsBitSet ret = new SortedElementsBitSet(this.isPlaceMarking);
/* 334 */     ret.places.unionAndDiff(this.places, pre.places);
/*     */     
/* 336 */     if (!ret.places.intersection(post.places).isEmpty())
/* 337 */       throw new SafetyException(); 
/* 338 */     ret.places.union(post.places);
/* 339 */     ret.size = (short)ret.places.size();
/* 340 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SortedElementsBitSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */