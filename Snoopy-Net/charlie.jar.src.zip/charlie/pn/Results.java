/*     */ package charlie.pn;
/*     */ 
/*     */ import charlie.pn.rules.Rule;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Results
/*     */ {
/*  25 */   private static final Rule ANALYZER_RULE = new Rule("Analyzer");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int PUR = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int ORD = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int HOM = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int NBM = 3;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int CSV = 4;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SCF = 5;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int FTB = 6;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TFB = 7;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int FPB = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int PFB = 9;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int CON = 10;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SC = 11;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int NC = 12;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int RKTH = 13;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int STP = 14;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int CPI = 15;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int CTI = 16;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int ECTI = 17;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SB = 18;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int B = 19;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int S = 20;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DCF = 21;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DST = 22;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DTr = 23;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int L = 24;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int REV = 25;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SDL = 26;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int RNK = 27;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SCCS = 28;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SECS = 29;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int COLUMNS = 13;
/*     */ 
/*     */ 
/*     */   
/* 157 */   private StringBuffer output = new StringBuffer();
/* 158 */   private int resultCount = 0;
/*     */   
/* 160 */   private final Map<Integer, Result> resultMap = new HashMap<>();
/*     */   
/* 162 */   private static final String[] props = new String[] { "PUR", "ORD", "HOM", "NBM", "CSV", "SCF", "FT0", "TF0", "FP0", "PF0", "CON", "SC ", "NC ", "RKTH", "STP", "CPI", "CTI", "SCTI", "SB", "k-B", "1-B", "DCF", "DSt", "DTr", "LIV", "REV", "SSI", "RNK", "SCCS", "SEQS" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   private static final String[] tooltips = new String[] { "pure", "ordinary", "homogenous", "non blocking multiplicity", "conservative", "structurally conflict free", "every transition has a pre-place", "every transition has a post-place", "every place has a pre-transition", "every place has a post-transition", "connected", "strongly connected", "netclass", "rank theorem", "siphon trap property (also known as: deadlock trap property)", "covered by P-invariants", "covered by T-invariants", "strongly covered by T-invariants", "structurally bounded", "k-bounded", "1- bounded (safe)", "dynamically conflict free", "no dead state(s)", "no dead transition(s)", "live", "reversible", "structural siphon", "rank of the incidence matrix", "structurally conflict cluster sets", "structurally equal cluster sets" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   private static final String[] descriptions = new String[] { "there are no two nodes, connected in both directions", "all arc weights are equal to 1", "all outgoing arcs of a given place have the same multiplicity", "the minimum weight of all incoming arcs of a place is greater or equal to the maximum weight of all outgoing arcs of that place", "all transitions add exactly as many tokens to their postplaces as they subtract from their preplaces", "there are no two transitions sharing a preplace", "every transition has a pre-place", "every transition has a post-place", "every place has a pre-transition", "every place has a post-transition", "for every two nodes a and b there is an undirected path between a and b", "for every two nodes a and b there is a directed path between a and b", "the netclass of the Petri net", "the rank of the incidence matrix is equal to |SCCS| - 1", "every siphon includes an initially marked trap", "there exists a vector x > 0 with x C = 0", "there exists a vector y > 0 with C y = 0", "the net is covered by non-trivial t-invariants", "the number of tokens on each place is bound for every marking", "the number of tokens on each place is bound by k for every reachable marking", "the number of tokens on each place is bound by 1 for every reachable marking", "there exists no reachable marking enabling two conflicting transitions", "there exists no reachable marking so that all transitions are disabled in that marking", "there exists no transition so that it is disabled in \"all\" reachable markings", "all transitions can become enabled from all reachable markings", "the initial marking can be reached from every reachable marking", "SSI", "RNK", "SCCS", "SEQS" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 230 */   public static int RESULTCOUNT = props.length;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 235 */   private static final List<String> keyList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 240 */   private static final List<String> propertyList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 245 */   private static final List<String> tooltipList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 250 */   private static final List<String> descriptionList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 255 */   private static final List<String> visibleList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 260 */     for (int i = 0; i < RESULTCOUNT; i++) {
/* 261 */       keyList.add(props[i]);
/* 262 */       propertyList.add(props[i]);
/* 263 */       tooltipList.add(tooltips[i]);
/* 264 */       descriptionList.add(descriptions[i]);
/*     */ 
/*     */       
/* 267 */       visibleList.add(props[i]);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 272 */     visibleList.remove(props[26]);
/* 273 */     visibleList.remove(props[27]);
/* 274 */     visibleList.remove(props[28]);
/* 275 */     visibleList.remove(props[29]);
/* 276 */     visibleList.remove(props[20]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Results() {
/* 285 */     for (int i = 0; i < RESULTCOUNT; i++) {
/* 286 */       this.resultMap.put(new Integer(i), null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean addFurtherResults(String _key, String _abbr, String _tooltip, String _description, boolean _visible) {
/* 311 */     if (_key == null || _key.trim().equals(""))
/*     */     {
/* 313 */       return false;
/*     */     }
/*     */     
/* 316 */     if (_abbr == null || _abbr.trim().equals(""))
/*     */     {
/* 318 */       return false;
/*     */     }
/* 320 */     if (_tooltip == null) {
/* 321 */       _tooltip = "no tooltip available :(";
/*     */     }
/* 323 */     if (_description == null) {
/* 324 */       _description = _abbr;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 329 */     if (keyList.contains(_key)) {
/* 330 */       return false;
/*     */     }
/*     */     
/* 333 */     keyList.add(_key);
/* 334 */     propertyList.add(_abbr);
/* 335 */     tooltipList.add(_tooltip);
/* 336 */     descriptionList.add(_description);
/*     */     
/* 338 */     if (_visible) {
/* 339 */       visibleList.add(_key);
/*     */     }
/*     */     
/* 342 */     RESULTCOUNT++;
/*     */     
/* 344 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeWith(Results r) {
/* 358 */     if (r == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 364 */     for (int i = 0; i < propertyList.size(); i++) {
/*     */       
/* 366 */       Result tempResult = r.getResult(i);
/*     */       
/* 368 */       if (tempResult != null) {
/* 369 */         Result newResult = tempResult.copy();
/* 370 */         if (newResult != null)
/*     */         {
/* 372 */           this.resultMap.put(Integer.valueOf(i), newResult);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 378 */     this.resultCount = 0;
/* 379 */     for (Result rs : this.resultMap.values()) {
/* 380 */       if (rs != null) {
/* 381 */         this.resultCount++;
/*     */       }
/*     */     } 
/*     */     
/* 385 */     this.output.append("\n" + r.getOutput());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeWithCheckForContradiction(Results _results) throws ResultContradictionException {
/* 402 */     mergeWithCheckForContradiction(_results, ANALYZER_RULE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeWithCheckForContradiction(Results _results, Rule _appliedRule) throws ResultContradictionException {
/* 421 */     if (_results == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 427 */     for (int i = 0; i < propertyList.size(); i++) {
/*     */       
/* 429 */       Result tempResult = _results.getResult(i);
/*     */       
/* 431 */       if (tempResult != null) {
/* 432 */         Result newResult = tempResult.copy();
/* 433 */         if (newResult != null) {
/*     */           
/* 435 */           Result prevResult = this.resultMap.put(Integer.valueOf(i), newResult);
/* 436 */           if (prevResult != null)
/*     */           {
/*     */ 
/*     */             
/* 440 */             if (!prevResult.equals(newResult)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 446 */               if (prevResult.getType() == newResult.getType()) {
/* 447 */                 throw new ResultContradictionException(String.format("The results '%s=%s' and '%s=%s' contradict each other. The rule '%s' will not be applied.", new Object[] { props[i], prevResult
/*     */ 
/*     */ 
/*     */                         
/* 451 */                         .getValue(), props[i], newResult
/*     */                         
/* 453 */                         .getValue(), _appliedRule
/* 454 */                         .getDescription() }));
/*     */               }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 462 */               if (prevResult.getType() != 1)
/*     */               {
/*     */                 
/* 465 */                 if (newResult.getType() == 1) {
/*     */ 
/*     */                   
/* 468 */                   this.resultMap.put(Integer.valueOf(i), prevResult);
/*     */                 } else {
/* 470 */                   throw new ResultContradictionException(String.format("The results '%s=%s' and '%s=%s' contradict each other. The rule '' will not be applied.", new Object[] { props[i], prevResult
/*     */ 
/*     */ 
/*     */                           
/* 474 */                           .getValue(), props[i], newResult
/*     */                           
/* 476 */                           .getValue(), _appliedRule }));
/*     */                 } 
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 487 */     this.resultCount = 0;
/* 488 */     for (Result rs : this.resultMap.values()) {
/* 489 */       if (rs != null) {
/* 490 */         this.resultCount++;
/*     */       }
/*     */     } 
/*     */     
/* 494 */     this.output.append("\n" + _results.getOutput());
/*     */   }
/*     */   
/*     */   public Results copy() {
/* 498 */     Results r = new Results();
/* 499 */     int i = 0;
/* 500 */     for (i = 0; i < RESULTCOUNT; i++) {
/* 501 */       if (getResult(i) != null) {
/* 502 */         r.addResult(i, getResult(i).copy());
/*     */       }
/*     */     } 
/* 505 */     r.appendOutput(getOutput());
/* 506 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result getResult(int index) {
/* 518 */     return this.resultMap.get(Integer.valueOf(index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result getResult(String _key) {
/* 530 */     return getResult(getIndexForKey(_key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addResult(int prop, Result value) {
/* 545 */     this.resultCount++;
/* 546 */     this.resultMap.put(Integer.valueOf(prop), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addResult(String _key, Result _value) {
/* 563 */     if (_key == null) {
/* 564 */       throw new NullPointerException("The property must not be null");
/*     */     }
/*     */     
/* 567 */     int index = keyList.indexOf(_key);
/*     */     
/* 569 */     if (index == -1) {
/* 570 */       throw new IllegalArgumentException(String.format("The property with the key '%s' is unknown.", new Object[] { _key }));
/*     */     }
/*     */     
/* 573 */     this.resultMap.put(Integer.valueOf(index), _value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getIndexForKey(String _key) {
/* 587 */     return keyList.indexOf(_key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getKeyForIndex(int _index) {
/*     */     try {
/* 600 */       return propertyList.get(_index);
/* 601 */     } catch (IndexOutOfBoundsException e) {
/* 602 */       e.printStackTrace();
/*     */       
/* 604 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getVisibleList() {
/* 614 */     return visibleList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getVisibleListSize() {
/* 623 */     return visibleList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isVisible(String _key) {
/* 635 */     return visibleList.contains(_key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringOnlySet() {
/* 646 */     int j = 0;
/* 647 */     ArrayList<Integer> list = new ArrayList<>();
/* 648 */     while (j < propertyList.size()) {
/* 649 */       if (propertyList.get(j) != null && this.resultMap.get(Integer.valueOf(j)) != null) {
/* 650 */         list.add(new Integer(j));
/*     */       }
/* 652 */       j++;
/*     */     } 
/* 654 */     int resultCount = list.size();
/* 655 */     if (resultCount == 0) {
/* 656 */       return "";
/*     */     }
/* 658 */     int rows = resultCount / 13 + 1;
/* 659 */     String[][] valueString = (String[][])null;
/* 660 */     String[][] propString = (String[][])null;
/*     */ 
/*     */     
/* 663 */     if (rows > 0 && resultCount > 0) {
/*     */       
/* 665 */       valueString = new String[rows][13];
/*     */       int i;
/* 667 */       for (i = 0; i < rows; i++) {
/* 668 */         Arrays.fill((Object[])valueString[i], "");
/*     */       }
/* 670 */       propString = new String[rows][13];
/*     */       
/* 672 */       for (i = 0; i < rows; i++) {
/* 673 */         Arrays.fill((Object[])propString[i], "");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 679 */     int currentRow = 0;
/* 680 */     j = 0;
/* 681 */     while (j < resultCount) {
/* 682 */       if (j % 13 == 0 && j > 0) {
/* 683 */         currentRow++;
/*     */       }
/* 685 */       int columnIndex = j - 13 * currentRow;
/* 686 */       propString[currentRow][columnIndex] = propertyList.get(((Integer)list.get(j)).intValue());
/* 687 */       valueString[currentRow][columnIndex] = ((Result)this.resultMap.get(Integer.valueOf(((Integer)list.get(j)).intValue()))).getValue();
/* 688 */       j++;
/*     */     } 
/* 690 */     StringBuffer buf = new StringBuffer();
/* 691 */     currentRow = 0;
/* 692 */     while (currentRow < rows) {
/* 693 */       boolean appended = false; int k;
/* 694 */       for (k = 0; k < 13; k++) {
/* 695 */         if (propString == null) {
/* 696 */           System.out.printf("propString == null, rows %d , j = %d currentRow = %d\n", new Object[] { Integer.valueOf(rows), Integer.valueOf(k), Integer.valueOf(currentRow) });
/*     */         }
/* 698 */         if (propString[currentRow] != null) {
/* 699 */           buf.append(String.format(" %4s ", new Object[] { propString[currentRow][k] }));
/* 700 */           appended = true;
/*     */         } 
/*     */       } 
/* 703 */       if (appended) {
/* 704 */         buf.append("\n");
/*     */       }
/* 706 */       appended = false;
/* 707 */       for (k = 0; k < 13; k++) {
/* 708 */         if (valueString[currentRow] != null) {
/* 709 */           buf.append(String.format(" %4s ", new Object[] { valueString[currentRow][k] }));
/* 710 */           appended = true;
/*     */         } 
/*     */       } 
/*     */       
/* 714 */       if (appended) {
/* 715 */         buf.append("\n");
/*     */       }
/*     */       
/* 718 */       currentRow++;
/*     */     } 
/*     */     
/* 721 */     return buf.toString().trim();
/*     */   }
/*     */   
/*     */   public void appendOutput(String s) {
/* 725 */     if (s != null && s.length() > 0) {
/* 726 */       this.output.append(s);
/*     */ 
/*     */ 
/*     */       
/* 730 */       if (s.charAt(s.length() - 1) != '\n') {
/* 731 */         this.output.append("\n");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getOutput() {
/* 737 */     return this.output.toString();
/*     */   }
/*     */   
/*     */   private static String getResultString(int index) {
/* 741 */     if (index >= 0) {
/* 742 */       return propertyList.get(index);
/*     */     }
/* 744 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getResultString(String _key) {
/* 749 */     return getResultString(getIndexForKey(_key));
/*     */   }
/*     */   
/*     */   private static String getTooltipText(int index) {
/* 753 */     if (index >= 0) {
/* 754 */       return tooltipList.get(index);
/*     */     }
/* 756 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getTooltipText(String _key) {
/* 761 */     return getTooltipText(getIndexForKey(_key));
/*     */   }
/*     */   
/*     */   private static String getDescription(int _index) {
/* 765 */     if (_index >= 0) {
/* 766 */       return descriptionList.get(_index);
/*     */     }
/* 768 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getDescription(String _key) {
/* 773 */     return getDescription(getIndexForKey(_key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getAmountOfResults() {
/* 782 */     return RESULTCOUNT;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 786 */     for (Result r : this.resultMap.values()) {
/* 787 */       if (r != null && r.getValue() != null) {
/* 788 */         return false;
/*     */       }
/*     */     } 
/* 791 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 796 */     StringBuffer buf = new StringBuffer();
/*     */ 
/*     */ 
/*     */     
/* 800 */     for (int i = 0; i <= RESULTCOUNT; i++) {
/* 801 */       if ((i > 0 && i % 13 == 0) || i == RESULTCOUNT) {
/*     */         
/* 803 */         buf.append("\n");
/*     */         
/* 805 */         int start = i - 13;
/* 806 */         if (i == RESULTCOUNT)
/*     */         {
/* 808 */           start = i - i % 13;
/*     */         }
/*     */ 
/*     */         
/* 812 */         for (int j = start; j < i; j++) {
/*     */           String value;
/* 814 */           Result r = this.resultMap.get(Integer.valueOf(j));
/* 815 */           if (r == null) {
/* 816 */             value = " - ";
/*     */           } else {
/* 818 */             value = r.getValue();
/*     */           } 
/* 820 */           buf.append(String.format(" %4s ", new Object[] { value }));
/*     */         } 
/* 822 */         buf.append("\n");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 827 */       if (i != RESULTCOUNT) {
/* 828 */         String key = propertyList.get(i);
/* 829 */         buf.append(String.format(" %4s ", new Object[] { key }));
/*     */       } 
/*     */     } 
/*     */     
/* 833 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 838 */     int prime = 31;
/* 839 */     int result = 1;
/* 840 */     result = 31 * result + this.resultCount;
/* 841 */     result = 31 * result + ((this.resultMap == null) ? 0 : this.resultMap.hashCode());
/* 842 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 847 */     if (this == obj) {
/* 848 */       return true;
/*     */     }
/* 850 */     if (obj == null) {
/* 851 */       return false;
/*     */     }
/* 853 */     if (getClass() != obj.getClass()) {
/* 854 */       return false;
/*     */     }
/* 856 */     Results other = (Results)obj;
/* 857 */     if (this.resultCount != other.resultCount) {
/* 858 */       return false;
/*     */     }
/* 860 */     if (this.resultMap == null) {
/* 861 */       if (other.resultMap != null) {
/* 862 */         return false;
/*     */       }
/* 864 */     } else if (!this.resultMap.equals(other.resultMap)) {
/* 865 */       return false;
/*     */     } 
/* 867 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Results.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */