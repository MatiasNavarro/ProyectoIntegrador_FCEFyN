/*     */ package charlie.pn;
/*     */ 
/*     */ import charlie.ds.BitSet;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileWriter;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransitionSet
/*     */   extends NodeSet
/*     */ {
/*     */   private static final long serialVersionUID = 807746543643129477L;
/*     */   
/*     */   public TransitionSet(int size) {
/*  19 */     super(size);
/*     */   }
/*     */   
/*     */   public TransitionSet(int size, int filledTo) {
/*  23 */     super(size, filledTo);
/*     */   }
/*     */   
/*     */   public TransitionSet(BitSet bs) {
/*  27 */     super(bs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NodeSet getPre() {
/*  33 */     BitSet bs = new BitSet(getNet().places());
/*  34 */     for (int i = 0; i < LookUpTable.transitions(); i++) {
/*  35 */       if (this.nodes.member(i)) {
/*  36 */         bs.union((getNet().getTransition((short)i).preNodes()).nodes);
/*     */       }
/*     */     } 
/*  39 */     return new PlaceSet(bs);
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeSet getEnvironment() {
/*  44 */     BitSet bs = new BitSet(LookUpTable.places());
/*     */     
/*  46 */     for (int i = 0; i < LookUpTable.transitions(); i++) {
/*  47 */       if (this.nodes.member(i)) {
/*  48 */         bs.union((getNet().getTransition((short)i).preNodes()).nodes);
/*  49 */         bs.union((getNet().getTransition((short)i).postNodes()).nodes);
/*     */       } 
/*     */     } 
/*  52 */     return new PlaceSet(bs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NodeSet getPost() {
/*  58 */     BitSet bs = new BitSet(getNet().places());
/*  59 */     for (int i = 0; i < LookUpTable.transitions(); i++) {
/*  60 */       if (this.nodes.member(i)) {
/*  61 */         bs.union((getNet().getTransition((short)i).postNodes()).nodes);
/*     */       }
/*     */     } 
/*  64 */     return new PlaceSet(bs);
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeSet intersection(NodeSet ns) {
/*  69 */     if (!getClass().equals(ns.getClass()))
/*     */     {
/*  71 */       System.exit(1);
/*     */     }
/*  73 */     return new TransitionSet(this.nodes.intersection(ns.nodes));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  78 */     if (isEmpty()) {
/*  79 */       return "\tempty set";
/*     */     }
/*  81 */     StringBuffer sb = new StringBuffer();
/*     */     
/*  83 */     for (Iterator<Integer> it = iterator(); it.hasNext(); ) {
/*  84 */       Transition t = getNet().getTransition((short)((Integer)it.next()).intValue());
/*  85 */       sb.append("\t|");
/*  86 */       sb.append(t.getOrgId());
/*  87 */       sb.append(".");
/*  88 */       sb.append(t.getName());
/*  89 */       sb.append("\t:1");
/*  90 */       if (it.hasNext()) {
/*  91 */         sb.append(",\n");
/*     */       }
/*     */     } 
/*     */     
/*  95 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public TransitionSet copy() {
/* 100 */     return new TransitionSet(this.nodes.copy());
/*     */   }
/*     */   
/*     */   public boolean isEqual(TransitionSet ts) {
/* 104 */     return ts.nodes.equals(this.nodes);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getNameArray() {
/* 109 */     String[] ret = new String[size()];
/* 110 */     int i = 0;
/* 111 */     for (Iterator<Integer> it = iterator(); it.hasNext();) {
/* 112 */       ret[i++] = getNet().getTransition((short)((Integer)it.next()).intValue()).getName();
/*     */     }
/* 114 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getIdArray() {
/* 119 */     String[] ret = new String[size()];
/* 120 */     int i = 0;
/* 121 */     for (Iterator<Integer> it = iterator(); it.hasNext(); ) {
/* 122 */       int id = ((Integer)it.next()).intValue();
/* 123 */       ret[i++] = Integer.toString(id);
/*     */     } 
/* 125 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getOrigIdArray() {
/* 130 */     String[] ret = new String[size()];
/* 131 */     int i = 0;
/* 132 */     for (Iterator<Integer> it = iterator(); it.hasNext(); ) {
/* 133 */       int j = ((Integer)it.next()).intValue();
/*     */       
/* 135 */       int id = getNet().getTransition((short)j).getOrgId();
/* 136 */       ret[i++] = Integer.toString(id);
/*     */     } 
/* 138 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean contains(Transition t) {
/* 142 */     for (Iterator<Integer> it = iterator(); it.hasNext();) {
/* 143 */       if (t.equals(getNet().getTransition((short)((Integer)it.next()).intValue()))) {
/* 144 */         return true;
/*     */       }
/*     */     } 
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public PNNode getNode(int index, boolean ownNodeClass) {
/* 152 */     if (ownNodeClass) {
/* 153 */       return getNet().getTransition((short)index);
/*     */     }
/* 155 */     return getNet().getPlaceByIndex(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void writeToFile(String filename, String title, Vector<TransitionSet> set) {
/* 160 */     if (filename == null || filename.equals("")) {
/*     */       return;
/*     */     }
/*     */     try {
/* 164 */       BufferedWriter out = new BufferedWriter(new FileWriter(filename));
/* 165 */       String str = title + "\n";
/* 166 */       out.write(str, 0, str.length());
/* 167 */       int i = 1;
/*     */       
/* 169 */       Iterator<TransitionSet> it = set.iterator();
/* 170 */       while (it.hasNext()) {
/* 171 */         TransitionSet ns = it.next();
/* 172 */         str = "" + i + ns.toString() + "\n";
/* 173 */         out.write(str, 0, str.length());
/*     */         
/* 175 */         i++;
/*     */       } 
/*     */       
/* 178 */       out.close();
/* 179 */       Out.println("file written: " + filename);
/* 180 */     } catch (Exception ex) {
/* 181 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/TransitionSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */