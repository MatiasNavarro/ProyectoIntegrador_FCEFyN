/*    */ package charlie.pn;
/*    */ 
/*    */ import charlie.util.IProtocol;
/*    */ import charlie.util.StandardOutProtocol;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Out
/*    */ {
/* 17 */   private static final Log LOG = LogFactory.getLog(Out.class);
/*    */   
/* 19 */   private static IProtocol protocol = (IProtocol)new StandardOutProtocol();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static synchronized void setProtocol(IProtocol _protocol) {
/* 27 */     if (LOG.isDebugEnabled()) {
/* 28 */       LOG.debug("new protocol set: " + protocol.toString());
/*    */     }
/* 30 */     protocol = _protocol;
/*    */   }
/*    */   
/*    */   public static synchronized void print(Object _o) {
/* 34 */     if (LOG.isDebugEnabled()) {
/* 35 */       LOG.debug(_o);
/*    */     }
/* 37 */     protocol.print(_o);
/*    */   }
/*    */   
/*    */   public static synchronized void println(Object _o) {
/* 41 */     if (LOG.isDebugEnabled()) {
/* 42 */       LOG.debug(_o);
/*    */     }
/* 44 */     protocol.println(_o);
/*    */   }
/*    */   
/*    */   public static synchronized void errPrint(Object _o) {
/* 48 */     if (LOG.isDebugEnabled()) {
/* 49 */       LOG.debug(_o);
/*    */     }
/* 51 */     protocol.errPrint(_o);
/*    */   }
/*    */   
/*    */   public static synchronized void errPrintln(Object _o) {
/* 55 */     if (LOG.isDebugEnabled()) {
/* 56 */       LOG.debug(_o);
/*    */     }
/* 58 */     protocol.errPrintln(_o);
/*    */   }
/*    */   
/*    */   public static synchronized void println() {
/* 62 */     if (LOG.isDebugEnabled()) {
/* 63 */       LOG.debug("");
/*    */     }
/* 65 */     protocol.println("");
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Out.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */