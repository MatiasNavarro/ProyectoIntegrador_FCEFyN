/*    */ package charlie.pn;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class OrderTransitionForInvariants implements OrderingFunction {
/*  8 */   Vector translationTable = new Vector();
/*    */   
/*    */   PlaceTransitionNet pn;
/* 11 */   HashSet ready = new HashSet();
/*    */   public OrderTransitionForInvariants(PlaceTransitionNet pn) {
/* 13 */     this.pn = pn;
/*    */     
/* 15 */     int start = 0; int i;
/* 16 */     for (i = 0; i < pn.places(); i++) {
/* 17 */       Place pi = pn.getPlaceByIndex(i);
/* 18 */       if (pi.getPostBit().size() == 1 && pi.getPreBit().size() == 1)
/*    */       {
/* 20 */         for (int j = 0; j < pn.places(); j++) {
/* 21 */           Place pj = pn.getPlaceByIndex(j);
/* 22 */           if (pj.getPostBit().size() == 1 && pj.getPreBit().size() == 1) {
/*    */             
/* 24 */             NodeSet pi_post = pi.postNodes().copy();
/* 25 */             NodeSet pi_pre = pi.preNodes().copy();
/* 26 */             pi_post = pi_post.intersection(pj.preNodes());
/* 27 */             pi_pre = pi_pre.intersection(pj.postNodes());
/* 28 */             if (!pi_post.isEmpty() && !pi_pre.isEmpty()) {
/* 29 */               System.out.println(pi + " : " + pj);
/* 30 */               for (Iterator<Integer> iterator1 = pi_post.iterator(); iterator1.hasNext(); ) {
/* 31 */                 Integer index = iterator1.next();
/* 32 */                 System.out.println(pn.getTransition(index.shortValue()));
/* 33 */                 if (!this.ready.contains(index)) {
/* 34 */                   this.ready.add(index);
/* 35 */                   this.translationTable.add(index);
/*    */                 } 
/*    */               } 
/*    */               
/* 39 */               for (Iterator<Integer> it = pi_pre.iterator(); it.hasNext(); ) {
/* 40 */                 Integer index = it.next();
/* 41 */                 System.out.println(pn.getTransition(index.shortValue()));
/* 42 */                 if (!this.ready.contains(index)) {
/* 43 */                   this.ready.add(index);
/* 44 */                   this.translationTable.add(index);
/*    */                 } 
/*    */               } 
/*    */             } 
/*    */           } 
/*    */         } 
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 54 */     System.out.println("v: " + this.translationTable);
/* 55 */     for (i = 0; i < pn.transitions(); i++) {
/* 56 */       Integer index = new Integer(i);
/* 57 */       if (!this.ready.contains(index)) {
/* 58 */         this.translationTable.add(index);
/*    */       }
/*    */     } 
/*    */     
/* 62 */     System.out.println("trans: " + this.translationTable);
/* 63 */     if (this.translationTable.size() != pn.transitions()) {
/* 64 */       System.out.println("error by ordering" + this.translationTable.size() + " : " + pn.transitions());
/* 65 */       System.exit(1);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector getTranslationTable() {
/* 75 */     return this.translationTable;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/OrderTransitionForInvariants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */