/*     */ package charlie.pn;
/*     */ 
/*     */ import charlie.ds.HashStack;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiGraph
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -323407003798705381L;
/*     */   protected Vertex first;
/*  26 */   protected Map<Object, Vertex> vertices = new HashMap<>();
/*     */   
/*  28 */   protected int edges = 0;
/*  29 */   protected int size = 0;
/*     */ 
/*     */   
/*     */   public Vertex getFirst() {
/*  33 */     return this.first;
/*     */   }
/*     */   
/*     */   public Vertex addVertex(Object key, Vertex v) {
/*  37 */     if (this.vertices.isEmpty()) {
/*  38 */       this.first = v;
/*     */     }
/*     */     
/*  41 */     Object o = this.vertices.get(key);
/*  42 */     if (o == null) {
/*  43 */       this.vertices.put(key, v);
/*  44 */       this.size++;
/*  45 */       return null;
/*     */     } 
/*  47 */     return (Vertex)o;
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeVertex(Object key, Vertex v) {
/*  52 */     Edge out = v.out();
/*  53 */     while (out != null) {
/*  54 */       removeEdge(v, out.node());
/*  55 */       out = out.next();
/*     */     } 
/*  57 */     Edge in = v.in();
/*  58 */     while (in != null) {
/*  59 */       removeEdge(in.node(), v);
/*  60 */       in = in.next();
/*     */     } 
/*  62 */     this.vertices.remove(key);
/*  63 */     this.size--;
/*     */   }
/*     */ 
/*     */   
/*     */   public Edge addEdge(Vertex from, Vertex to) {
/*  68 */     int out = 0;
/*  69 */     int in = 0;
/*  70 */     Edge e = new Edge(from, to);
/*  71 */     out = from.addOutgoing(e);
/*  72 */     Edge sE = null;
/*     */     
/*  74 */     sE = new Edge(to, from);
/*  75 */     in = to.addIngoing(sE);
/*     */     
/*  77 */     this.edges++;
/*  78 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Vertex getVertex(Object key) {
/*  84 */     if (this.vertices == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     return this.vertices.get(key);
/*     */   }
/*     */   
/*     */   public void removeEdge(Vertex from, Vertex to) {
/*  91 */     from.removePost(to);
/*  92 */     this.edges--;
/*     */   }
/*     */   
/*     */   public int size() {
/*  96 */     return this.size;
/*     */   }
/*     */   
/*     */   public void replaceVertex(Object key, Vertex q) {
/* 100 */     Vertex v = getVertex(key);
/* 101 */     for (Iterator<Vertex> it = iterator(); it.hasNext(); ) {
/* 102 */       Vertex n = it.next();
/* 103 */       Edge e = n.out();
/* 104 */       while (e != null) {
/* 105 */         if (e.d.equals(v)) {
/* 106 */           e.d = q;
/*     */         }
/* 108 */         e = e.next();
/*     */       } 
/*     */     } 
/* 111 */     q.out = v.out;
/* 112 */     v.out = null;
/* 113 */     this.vertices.put(key, q);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addEdge(Edge e) {
/* 118 */     this.edges++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfEdges() {
/* 127 */     return this.edges;
/*     */   }
/*     */   
/*     */   public Iterator<Vertex> iterator() {
/* 131 */     return this.vertices.values().iterator();
/*     */   }
/*     */   
/*     */   private class StackEntry {
/*     */     Vertex n;
/*     */     Vertex q;
/*     */     Edge e;
/*     */     
/*     */     StackEntry(Vertex n, Edge e, Vertex q) {
/* 140 */       this.n = n;
/* 141 */       this.e = e;
/* 142 */       this.q = q;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean scc() {
/* 147 */     TraversationDataTable tdt = new TraversationDataTable();
/* 148 */     int scc = 0;
/* 149 */     boolean notfinished = true;
/* 150 */     Vertex n = this.first;
/* 151 */     Vertex q = null;
/* 152 */     HashStack states = new HashStack();
/* 153 */     Stack<StackEntry> st = new Stack<>();
/* 154 */     int count = 0;
/* 155 */     Edge e = null;
/*     */     
/*     */     do {
/* 158 */       if (!tdt.visited(n)) {
/* 159 */         n.setSccNumber(0);
/*     */         
/* 161 */         states.push(n);
/* 162 */         count++;
/* 163 */         tdt.add(n, count);
/* 164 */         tdt.setVisited(n, true);
/* 165 */         e = n.out();
/*     */       } 
/* 167 */       if (e != null) {
/* 168 */         q = e.node();
/* 169 */         if (!tdt.visited(q)) {
/* 170 */           st.add(new StackEntry(n, e, q));
/* 171 */           n = q;
/*     */         }
/*     */         else {
/*     */           
/* 175 */           if (states.contains(q)) {
/* 176 */             tdt.setMinLow(n, tdt.low(n), tdt.num(q));
/*     */           }
/*     */           
/* 179 */           e = e.next();
/*     */         } 
/*     */       } else {
/* 182 */         if (tdt.low(n) == tdt.num(n)) {
/* 183 */           scc++;
/* 184 */           Vertex v = (Vertex)states.pop();
/* 185 */           v.sccNumber = scc;
/* 186 */           while (states.size() > 0 && !v.equals(n)) {
/* 187 */             v = (Vertex)states.pop();
/* 188 */             v.sccNumber = scc;
/*     */           } 
/*     */         } 
/* 191 */         if (n.equals(this.first)) {
/* 192 */           notfinished = false;
/*     */         }
/* 194 */         if (!st.isEmpty()) {
/* 195 */           StackEntry top = st.pop();
/* 196 */           n = top.n;
/* 197 */           q = top.q;
/*     */           
/* 199 */           e = top.e.next();
/* 200 */           tdt.setMinLow(n, tdt.low(n), tdt.low(q));
/*     */         } 
/*     */       } 
/* 203 */     } while (notfinished || !st.isEmpty());
/*     */     
/* 205 */     return (scc == 1 && this.size == count);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/DiGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */