/*    */ package charlie.pn;
/*    */ 
/*    */ public class NodeT {
/*    */   NodeT next;
/*    */   NodeT prev;
/*    */   boolean free;
/*    */   Weight place;
/*    */   
/*    */   public NodeT() {
/* 10 */     this.place = null;
/* 11 */     this.next = null;
/* 12 */     this.free = true;
/*    */   }
/*    */   
/*    */   public NodeT(Weight place) {
/* 16 */     this.place = place;
/*    */     
/* 18 */     this.next = null;
/*    */   }
/*    */   
/*    */   public NodeT getNext() {
/* 22 */     return this.next;
/*    */   }
/*    */   
/*    */   public NodeT getPrev() {
/* 26 */     return this.prev;
/*    */   }
/*    */   
/*    */   public Weight getWeight() {
/* 30 */     return this.place;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/NodeT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */