/*     */ package charlie.pn;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ShortSet
/*     */ {
/*     */   private Node first;
/*     */   private short size;
/*     */   
/*     */   private class Node
/*     */   {
/*     */     Node next;
/*     */     short content;
/*     */     
/*     */     Node(short c, Node n) {
/*  16 */       this.content = c;
/*  17 */       this.next = n;
/*     */     }
/*     */     
/*     */     Node copy() {
/*  21 */       return new Node(this.content, this.next);
/*     */     }
/*     */   }
/*     */   
/*     */   public ShortSet() {
/*  26 */     this.first = new Node((short)-1, null);
/*  27 */     this.size = 0;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  31 */     this.size = 0;
/*  32 */     this.first = new Node((short)-1, null);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  36 */     return (this.size == 0);
/*     */   }
/*     */   
/*     */   public int size() {
/*  40 */     return this.size;
/*     */   }
/*     */   
/*     */   public boolean equals(ShortSet fs) {
/*  44 */     if (this.size != fs.size) {
/*  45 */       return false;
/*     */     }
/*  47 */     Node cur1 = this.first;
/*  48 */     Node cur2 = fs.first;
/*  49 */     while (cur1.next != null) {
/*  50 */       if (cur1.next.content != cur2.next.content) {
/*  51 */         return false;
/*     */       }
/*  53 */       cur1 = cur1.next;
/*  54 */       cur2 = cur2.next;
/*     */     } 
/*  56 */     return true;
/*     */   }
/*     */   
/*     */   public Iterator<Short> iterator() {
/*  60 */     return new FSIterator();
/*     */   }
/*     */   
/*     */   public void insert(short i) {
/*  64 */     Node current = this.first;
/*  65 */     while (current.next != null) {
/*  66 */       if (current.next.content < i) {
/*  67 */         current = current.next; continue;
/*  68 */       }  if (current.next.content > i) {
/*     */         break;
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*  74 */     Node n = new Node(i, current.next);
/*  75 */     current.next = n;
/*  76 */     this.size = (short)(this.size + 1);
/*     */   }
/*     */   
/*     */   public short first() {
/*  80 */     if (isEmpty()) {
/*  81 */       return -1;
/*     */     }
/*  83 */     short ret = this.first.next.content;
/*  84 */     this.first.next = this.first.next.next;
/*  85 */     this.size = (short)(this.size - 1);
/*  86 */     return ret;
/*     */   }
/*     */   
/*     */   public void delete(short i) {
/*  90 */     Node current = this.first;
/*  91 */     while (current.next != null) {
/*  92 */       if (current.next.content < i) {
/*  93 */         current = current.next; continue;
/*  94 */       }  if (current.next.content == i) {
/*  95 */         current.next = current.next.next;
/*  96 */         this.size = (short)(this.size - 1);
/*     */         continue;
/*     */       } 
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean member(short i) {
/* 104 */     Node current = this.first;
/* 105 */     while (current.next != null) {
/* 106 */       if (current.next.content < i) {
/* 107 */         current = current.next; continue;
/* 108 */       }  if (current.next.content == i) {
/* 109 */         return true;
/*     */       }
/* 111 */       return false;
/*     */     } 
/*     */     
/* 114 */     return false;
/*     */   }
/*     */   
/*     */   public ShortSet intersection(ShortSet s2) {
/* 118 */     ShortSet intersection = new ShortSet();
/* 119 */     if (isEmpty() || s2.isEmpty()) {
/* 120 */       return intersection;
/*     */     }
/* 122 */     Node cur = intersection.first;
/* 123 */     Node cur1 = this.first;
/* 124 */     Node cur2 = s2.first;
/* 125 */     while (cur1.next != null && cur2.next != null) {
/* 126 */       short c = cur1.next.content;
/* 127 */       while (cur2.next != null) {
/* 128 */         if (cur2.next.content == c) {
/* 129 */           cur.next = new Node(c, cur.next);
/* 130 */           intersection.size = (short)(intersection.size + 1);
/* 131 */           cur = cur.next;
/* 132 */           cur2 = cur2.next;
/* 133 */           cur1 = cur1.next;
/*     */           break;
/*     */         } 
/* 136 */         if (cur2.next.content < c) {
/* 137 */           cur2 = cur2.next; continue;
/*     */         } 
/* 139 */         cur1 = cur1.next;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 144 */     return intersection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void union(ShortSet fs) {
/* 151 */     Node cur = this.first;
/* 152 */     Node cur2 = fs.first;
/* 153 */     label18: while (cur2.next != null) {
/* 154 */       short c = cur2.next.content;
/* 155 */       while (cur.next != null) {
/* 156 */         if (cur.next.content == c) {
/* 157 */           cur2 = cur2.next;
/*     */           continue label18;
/*     */         } 
/* 160 */         if (cur.next.content < c) {
/* 161 */           cur = cur.next; continue;
/*     */         } 
/* 163 */         Node node = new Node(c, cur.next);
/*     */         
/* 165 */         cur.next = node;
/* 166 */         cur2 = cur2.next;
/* 167 */         this.size = (short)(this.size + 1);
/*     */       } 
/*     */ 
/*     */       
/* 171 */       Node n = new Node(c, cur.next);
/* 172 */       cur.next = n;
/* 173 */       cur2 = cur2.next;
/* 174 */       this.size = (short)(this.size + 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean subSet(ShortSet fs) {
/* 181 */     Node cur = this.first;
/* 182 */     Node cur2 = fs.first;
/* 183 */     label19: while (cur.next != null) {
/* 184 */       short c = cur.next.content;
/* 185 */       while (cur2.next != null) {
/* 186 */         if (cur2.next.content == c) {
/* 187 */           cur = cur.next;
/* 188 */           cur2 = cur2.next;
/*     */           
/*     */           continue label19;
/*     */         } 
/* 192 */         if (cur2.next.content < c) {
/* 193 */           cur2 = cur2.next; continue;
/*     */         } 
/* 195 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 199 */       if (cur.next != null) {
/* 200 */         return false;
/*     */       }
/* 202 */       cur = cur.next;
/*     */     } 
/* 204 */     return true;
/*     */   }
/*     */   
/*     */   public void diff(ShortSet fs) {
/* 208 */     Node cur = this.first;
/* 209 */     Node cur2 = fs.first;
/* 210 */     label18: while (cur.next != null) {
/* 211 */       short c = cur.next.content;
/* 212 */       while (cur2.next != null) {
/* 213 */         if (cur2.next.content == c) {
/* 214 */           cur.next = cur.next.next;
/* 215 */           cur2 = cur2.next;
/* 216 */           this.size = (short)(this.size - 1);
/*     */           continue label18;
/*     */         } 
/* 219 */         if (cur2.next.content < c) {
/* 220 */           cur2 = cur2.next; continue;
/*     */         } 
/* 222 */         cur = cur.next;
/*     */       } 
/*     */ 
/*     */       
/* 226 */       cur = cur.next;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 234 */     String ret = "(";
/* 235 */     Node cur = this.first;
/* 236 */     while (cur.next != null) {
/* 237 */       ret = ret + cur.next.content;
/* 238 */       cur = cur.next;
/* 239 */       if (cur.next != null) {
/* 240 */         ret = ret + " , ";
/*     */       }
/*     */     } 
/*     */     
/* 244 */     ret = ret + ") ";
/* 245 */     return ret;
/*     */   }
/*     */   
/*     */   public ShortSet copy() {
/* 249 */     ShortSet ret = new ShortSet();
/* 250 */     Node cur2 = ret.first;
/* 251 */     Node cur = this.first;
/* 252 */     while (cur.next != null) {
/* 253 */       cur2.next = cur.next.copy();
/* 254 */       cur2 = cur2.next;
/* 255 */       cur = cur.next;
/*     */     } 
/* 257 */     ret.size = this.size;
/* 258 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   private class FSIterator
/*     */     implements Iterator<Short>
/*     */   {
/* 265 */     ShortSet.Node current = ShortSet.this.first.next;
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 269 */       return (this.current != null);
/*     */     }
/*     */     
/*     */     public Short next() {
/* 273 */       if (hasNext()) {
/* 274 */         Short ret = new Short(this.current.content);
/* 275 */         this.current = this.current.next;
/* 276 */         return ret;
/*     */       } 
/* 278 */       return null;
/*     */     }
/*     */     
/*     */     public void remove() {}
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/ShortSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */