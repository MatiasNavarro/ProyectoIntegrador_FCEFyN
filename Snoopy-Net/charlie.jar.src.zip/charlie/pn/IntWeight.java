/*    */ package charlie.pn;
/*    */ 
/*    */ public class IntWeight implements Weight {
/*    */   private int token;
/*    */   private int id;
/*    */   
/*    */   public IntWeight(int id, int token) {
/*  8 */     this.id = id;
/*  9 */     this.token = token;
/*    */   }
/*    */   
/*    */   public int getToken() {
/* 13 */     return this.token;
/*    */   }
/*    */   
/*    */   public int addToken(int token) {
/* 17 */     this.token += token;
/* 18 */     return this.token;
/*    */   }
/*    */   
/*    */   public int reduceToken(int token) {
/* 22 */     this.token -= token;
/* 23 */     return this.token;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 27 */     return this.id;
/*    */   }
/*    */   
/*    */   public int less(Weight w) {
/* 31 */     int ret = -1;
/* 32 */     if (this.id == w.getId()) {
/* 33 */       ret = w.getToken() - this.token;
/*    */     }
/* 35 */     return ret;
/*    */   }
/*    */   
/*    */   public boolean isEqual(Weight w) {
/* 39 */     return (this.id == w.getId() && this.token == w.getToken());
/*    */   }
/*    */   
/*    */   public String toString() {
/* 43 */     StringBuffer res = new StringBuffer();
/* 44 */     res.append('('); res.append(this.id); res.append(';'); res.append(this.token);
/* 45 */     res.append(')');
/* 46 */     return res.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/IntWeight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */