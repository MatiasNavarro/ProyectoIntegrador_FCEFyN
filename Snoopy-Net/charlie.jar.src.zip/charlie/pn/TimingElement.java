/*    */ package charlie.pn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimingElement
/*    */ {
/*    */   private int eft;
/*    */   private int lft;
/*    */   private String name;
/*    */   public TimingElement next;
/*    */   
/*    */   public TimingElement(int eft, int lft) {
/* 26 */     this.eft = eft;
/* 27 */     this.lft = lft;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getEft() {
/* 35 */     return this.eft;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setEft(int eft) {
/* 42 */     this.eft = eft;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getLft() {
/* 50 */     return this.lft;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLft(int lft) {
/* 58 */     this.lft = lft;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 66 */     return this.name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setName(String name) {
/* 74 */     this.name = name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void append(TimingElement tElement) {
/* 83 */     TimingElement it = this;
/* 84 */     while (it.next != null)
/*    */     {
/* 86 */       it = it.next;
/*    */     }
/* 88 */     it.next = tElement;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/TimingElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */