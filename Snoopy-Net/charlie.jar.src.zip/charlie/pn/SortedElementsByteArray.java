/*     */ package charlie.pn;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SortedElementsByteArray
/*     */   extends Marking {
/*     */   private byte[] places;
/*     */   private int hashC;
/*     */   private int size;
/*     */   
/*     */   public void reset() {
/*  13 */     UnsignedByte.init(this.places, size());
/*  14 */     this.size = 0;
/*  15 */     this.hashC = 0;
/*     */   }
/*     */   
/*     */   public int getTokenById(int id) {
/*  19 */     for (int i = 0; i < size() * 2; i += 2) {
/*  20 */       if (this.places[i] == (byte)id) {
/*  21 */         return this.places[i + 1];
/*     */       }
/*     */     } 
/*  24 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Marking copy() throws SafetyException, ExceedsByteException {
/*  30 */     Marking ret = SortedElementsFactory.getSortedPlaces(size());
/*  31 */     for (int i = 0; i < size(); i++)
/*  32 */       ret.addPlace(getId(i), getToken(i)); 
/*  33 */     if (ret instanceof SortedElementsByteArray) {
/*  34 */       ((SortedElementsByteArray)ret).hashC = this.hashC;
/*     */     }
/*  36 */     return ret;
/*     */   }
/*     */   
/*     */   public SortedElementsByteArray(byte[] p) {
/*  40 */     this.places = p;
/*  41 */     this.size = p.length / 2;
/*  42 */     for (int i = p.length - 2; i > 1 && 
/*  43 */       this.places[i] == UnsignedByte.min(); i -= 2) this.size--;
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedElementsByteArray(int p) {
/*  52 */     this.places = new byte[p * 2];
/*  53 */     UnsignedByte.init(this.places);
/*  54 */     this.size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  62 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedElementsByteArray toArray() throws SafetyException, ExceedsByteException {
/*  68 */     return (SortedElementsByteArray)copy();
/*     */   }
/*     */   
/*     */   public String toString() {
/*  72 */     StringBuffer res = new StringBuffer();
/*  73 */     for (int i = 0; i < size() * 2; i++) {
/*  74 */       res.append(this.places[i]);
/*  75 */       res.append("_");
/*     */     } 
/*  77 */     return res.toString();
/*     */   }
/*     */   
/*     */   public Weight get(int index) {
/*  81 */     if (index >= size() || index < 0) {
/*  82 */       return null;
/*     */     }
/*  84 */     return LookUpTable.lookUp(this.places[index * 2], this.places[index * 2 + 1]);
/*     */   }
/*     */   
/*     */   public int getId(int index) {
/*  88 */     return this.places[index * 2];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getToken(int index) {
/*  93 */     return this.places[index * 2 + 1];
/*     */   }
/*     */ 
/*     */   
/*     */   public int setToken(int index, int t) {
/*  98 */     this.places[index * 2 + 1] = (byte)t;
/*  99 */     return this.places[index * 2 + 1];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPlaces() {
/* 105 */     return this.places;
/*     */   }
/*     */   
/*     */   public boolean isEqual(Marking sp) {
/* 109 */     if (sp.size() != size()) return false; 
/* 110 */     for (int i = 0; i < this.size; i++) {
/* 111 */       if (!get(i).equals(sp.get(i))) return false; 
/*     */     } 
/* 113 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/* 117 */     if (obj instanceof SortedElementsByteArray) {
/* 118 */       SortedElementsByteArray spa = (SortedElementsByteArray)obj;
/* 119 */       if (size() != spa.size()) return false; 
/* 120 */       for (int i = 0; i < size() * 2; i++) {
/* 121 */         if (this.places[i] != spa.places[i]) {
/* 122 */           return false;
/*     */         }
/*     */       } 
/* 125 */       return true;
/*     */     } 
/* 127 */     return isEqual((Marking)obj);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 131 */     int h = this.hashC;
/* 132 */     if (h == 0) {
/*     */       
/* 134 */       for (int i = 0; i < size() * 2; i++) {
/* 135 */         this.hashC = 31 * this.hashC + this.places[i++];
/*     */       }
/* 137 */       h = this.hashC;
/*     */     } 
/*     */     
/* 140 */     return h;
/*     */   }
/*     */ 
/*     */   
/*     */   public int addToken(int index, int t) throws ExceedsByteException {
/* 145 */     int current = this.places[index * 2 + 1];
/* 146 */     if (current + t >= 127) {
/* 147 */       throw new ExceedsByteException();
/*     */     }
/* 149 */     this.places[index * 2 + 1] = (byte)(this.places[index * 2 + 1] + (byte)t);
/*     */     
/* 151 */     return this.places[index * 2 + 1];
/*     */   }
/*     */   
/*     */   public int addPlace(int id, int token) throws ExceedsByteException {
/* 155 */     if (token >= 127) {
/* 156 */       throw new ExceedsByteException();
/*     */     }
/* 158 */     int i = 0;
/* 159 */     boolean b = true;
/* 160 */     int index = 0;
/*     */ 
/*     */     
/* 163 */     for (i = 0; b && i < this.places.length; i += 2) {
/* 164 */       if (this.places[i] >= id || this.places[i + 1] == 0) {
/*     */ 
/*     */         
/* 167 */         b = false;
/* 168 */         index = i;
/* 169 */         if (this.places[i] == id && id != UnsignedByte.min) {
/* 170 */           addToken(i / 2, token);
/* 171 */           LookUpTable.addPlace(id, this.places[i + 1]);
/* 172 */           return this.places[i + 1];
/*     */         } 
/* 174 */         if (this.places[i] == id && id == UnsignedByte.min && this.places[i + 1] > 0) {
/* 175 */           addToken(i / 2, token);
/* 176 */           LookUpTable.addPlace(id, this.places[i + 1]);
/* 177 */           return this.places[i + 1];
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 182 */     for (i = this.places.length - 1; i > index + 1; i--) {
/* 183 */       this.places[i] = this.places[i - 2];
/*     */     }
/* 185 */     this.places[index] = (byte)id;
/* 186 */     setToken(i / 2, token);
/* 187 */     LookUpTable.addPlace(id, this.places[index + 1]);
/* 188 */     this.size++;
/* 189 */     return token;
/*     */   }
/*     */   
/*     */   public int isSubSet2(Marking spa) {
/* 193 */     if (size() > spa.size()) return UnsignedByte.min - 1; 
/* 194 */     int ret = 0;
/* 195 */     int index = 0;
/* 196 */     int i = 0;
/* 197 */     Weight current = get(index);
/* 198 */     while (index < size()) {
/*     */       
/* 200 */       int curId = current.getId();
/* 201 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 202 */         if (spa.getId(i) > curId) return -1; 
/* 203 */         i++;
/*     */       } 
/* 205 */       if (i == spa.size() || current.less(spa.get(i)) < 0) return -1; 
/* 206 */       if (i < spa.size() && current.less(spa.get(i)) == 0) ret++;
/*     */       
/* 208 */       current = get(++index);
/* 209 */       i++;
/*     */     } 
/*     */     
/* 212 */     return spa.size() - ret;
/*     */   }
/*     */   
/*     */   public Collection<Integer> scapeGoats(Marking spa) {
/* 216 */     Collection<Integer> c = new Vector<>();
/* 217 */     int index = 0;
/* 218 */     int i = 0;
/* 219 */     Weight current = get(index);
/* 220 */     while (index < size()) {
/* 221 */       int curId = current.getId();
/* 222 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 223 */         i++;
/*     */       }
/* 225 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 226 */         c.add(Integer.valueOf(curId));
/* 227 */         i = 0;
/* 228 */         current = get(++index);
/*     */         
/*     */         continue;
/*     */       } 
/* 232 */       current = get(++index);
/* 233 */       i++;
/*     */     } 
/* 235 */     return c;
/*     */   }
/*     */   
/*     */   public int fSG(Marking spa) {
/* 239 */     int index = 0;
/* 240 */     int i = 0;
/* 241 */     Weight current = get(index);
/* 242 */     while (index < size()) {
/* 243 */       int curId = current.getId();
/* 244 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 245 */         i++;
/*     */       }
/* 247 */       if (i == spa.size() || current.less(spa.get(i)) < 0) return curId; 
/* 248 */       current = get(++index);
/* 249 */       i++;
/*     */     } 
/* 251 */     return UnsignedByte.min - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retains(Marking s) {
/* 256 */     int index = 0;
/* 257 */     int i = 0;
/* 258 */     Weight current = get(index);
/*     */     
/* 260 */     while (index < size()) {
/* 261 */       Weight current2 = s.get(i);
/*     */       
/* 263 */       int curId = current.getId();
/* 264 */       while (i < s.size() && current2.getId() < curId) {
/* 265 */         current2 = s.get(++i);
/*     */       }
/* 267 */       if (i < s.size() && curId == current2.getId()) return true; 
/* 268 */       current2 = s.get(++i);
/* 269 */       current = get(++index);
/*     */     } 
/* 271 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SortedElementsByteArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */