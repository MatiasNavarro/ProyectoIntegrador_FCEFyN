/*    */ package charlie.pn;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class OrderTransitionsForSAT implements OrderingFunction {
/*    */   Vector translationTable;
/*    */   PlaceTransitionNet pn;
/*    */   
/*    */   public OrderTransitionsForSAT(PlaceTransitionNet pn) {
/* 11 */     this.pn = pn;
/*    */     
/* 13 */     int start = 0;
/*    */     
/* 15 */     this.translationTable = new Vector(pn.transitions());
/* 16 */     int counter = 0;
/*    */     
/* 18 */     for (Iterator<Transition> it = pn.getTransitions().iterator(); it.hasNext(); ) {
/* 19 */       Transition t = it.next();
/* 20 */       int i = 0;
/* 21 */       while (i < counter && less(t, pn.getTransition(((Integer)this.translationTable.get(i)).shortValue()))) {
/* 22 */         i++;
/*    */       }
/* 24 */       this.translationTable.insertElementAt(new Integer(t.getId()), i);
/* 25 */       counter++;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean less(Transition t1, Transition t2) {
/* 33 */     int b1 = t1.getBot();
/* 34 */     int b2 = t2.getBot();
/* 35 */     if (b1 > b2) return true; 
/* 36 */     if (b2 > b1) return false; 
/* 37 */     int top1 = t1.getTop();
/* 38 */     int top2 = t2.getTop();
/* 39 */     if (top1 > top2) return true; 
/* 40 */     if (top2 > top1) return false; 
/* 41 */     return (t1.getId() < t2.getId());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector getTranslationTable() {
/* 47 */     return this.translationTable;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/OrderTransitionsForSAT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */