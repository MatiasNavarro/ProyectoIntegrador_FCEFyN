/*    */ package charlie.pn;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstantRegistry
/*    */ {
/*    */   private HashMap<String, Constant> map;
/*    */   private ConstantInterface cI;
/*    */   
/*    */   public ConstantRegistry(ConstantInterface cI_p) {
/* 13 */     this.cI = cI_p;
/* 14 */     this.map = new HashMap<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public ConstantRegistry() {
/* 19 */     this.cI = new DefaultConstantInterface();
/* 20 */     this.map = new HashMap<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public void register(String name, Constant c) {
/* 25 */     if (!c.hasValue() && c.getType() == Constant.Type.INT) {
/* 26 */       this.cI.askForValue(c);
/*    */     }
/* 28 */     this.map.put(name, c);
/*    */   }
/*    */   
/*    */   public void clear() {
/* 32 */     this.map.clear();
/*    */   }
/*    */   
/*    */   public double lookUpDoubleConstant(String name) throws Exception {
/* 36 */     Constant c = this.map.get(name);
/* 37 */     if (c != null && c.getType() == Constant.Type.DOUBLE) {
/* 38 */       return ((DoubleConstant)c).getValue().doubleValue();
/*    */     }
/* 40 */     throw new Exception("no DoubleConstant <" + name + "> registered!");
/*    */   }
/*    */ 
/*    */   
/*    */   public int lookUpIntConstant(String name) throws Exception {
/* 45 */     Constant c = this.map.get(name);
/*    */     
/* 47 */     if (c != null && c.getType() == Constant.Type.INT) {
/* 48 */       System.out.println(((IntConstant)c).getValue());
/* 49 */       return ((IntConstant)c).getValue();
/*    */     } 
/* 51 */     throw new Exception("no IntConstant <" + name + "> registered!");
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/ConstantRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */