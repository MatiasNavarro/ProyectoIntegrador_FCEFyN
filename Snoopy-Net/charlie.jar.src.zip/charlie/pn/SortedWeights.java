/*     */ package charlie.pn;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SortedWeights
/*     */   extends Marking
/*     */ {
/*     */   private Weight[] places;
/*     */   private int hashC;
/*     */   private int size;
/*     */   
/*     */   public void reset() {
/*  14 */     for (int i = 0; i < this.size; i++) {
/*  15 */       this.places[i] = null;
/*     */     }
/*  17 */     this.size = 0;
/*  18 */     this.hashC = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTokenById(int id) {
/*  23 */     if (size() == 0) {
/*  24 */       return 0;
/*     */     }
/*  26 */     int lB = 0;
/*  27 */     int uB = size() - 1;
/*  28 */     int mid = 0;
/*  29 */     while (lB != uB) {
/*  30 */       if (id == this.places[lB].getId()) {
/*  31 */         return this.places[lB].getToken();
/*     */       }
/*  33 */       if (id == this.places[uB].getId()) {
/*  34 */         return this.places[uB].getToken();
/*     */       }
/*  36 */       mid = (lB + uB) / 2;
/*  37 */       if (id == this.places[mid].getId()) {
/*  38 */         return this.places[mid].getToken();
/*     */       }
/*  40 */       if (id > this.places[mid].getId()) {
/*  41 */         lB = mid;
/*     */       } else {
/*  43 */         uB = mid;
/*     */       } 
/*  45 */       if (mid == (lB + uB) / 2) {
/*     */         break;
/*     */       }
/*  48 */       mid = (lB + uB) / 2;
/*     */     } 
/*  50 */     if (id == this.places[mid].getId()) {
/*  51 */       return this.places[mid].getToken();
/*     */     }
/*     */     
/*  54 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedWeights copy() throws SafetyException {
/*  61 */     SortedWeights ret = new SortedWeights(size());
/*  62 */     for (int i = 0; i < size(); i++) {
/*  63 */       ret.addPlace(getId(i), getToken(i));
/*     */     }
/*  65 */     ret.hashC = this.hashC;
/*  66 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedWeights(int p) {
/*  74 */     this.places = new Weight[p];
/*  75 */     for (int i = 0; i < p; i++) {
/*  76 */       this.places[i] = null;
/*     */     }
/*  78 */     this.size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  87 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedWeights toArray() throws SafetyException {
/*  93 */     return copy();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  98 */     StringBuffer res = new StringBuffer();
/*  99 */     for (int i = 0; i < size(); i++) {
/* 100 */       res.append(this.places[i]);
/* 101 */       res.append("_");
/*     */     } 
/* 103 */     return res.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Weight get(int index) {
/* 108 */     if (index >= size() || index < 0) {
/* 109 */       return null;
/*     */     }
/* 111 */     return this.places[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getId(int index) {
/* 116 */     return this.places[index].getId();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getToken(int index) {
/* 122 */     return this.places[index].getToken();
/*     */   }
/*     */ 
/*     */   
/*     */   public int setToken(int index, int t) {
/* 127 */     this.places[index] = LookUpTable.addPlace(this.places[index].getId(), t);
/* 128 */     return t;
/*     */   }
/*     */   
/*     */   public int addToken(int index, int t) {
/* 132 */     int current = this.places[index].getToken();
/* 133 */     if (current + t > Integer.MAX_VALUE || current + t <= 0) {
/* 134 */       current = Integer.MAX_VALUE;
/*     */     } else {
/* 136 */       current += t;
/*     */     } 
/*     */     
/* 139 */     this.places[index] = LookUpTable.addPlace(this.places[index].getId(), current);
/* 140 */     return current;
/*     */   }
/*     */   
/*     */   public Weight[] getPlaces() {
/* 144 */     return this.places;
/*     */   }
/*     */   
/*     */   public boolean isEqual(Marking sp) {
/* 148 */     if (sp.size() != size()) {
/* 149 */       return false;
/*     */     }
/* 151 */     for (int i = 0; i < this.size; i++) {
/* 152 */       if (!get(i).equals(sp.get(i))) {
/* 153 */         return false;
/*     */       }
/*     */     } 
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 162 */     if (obj instanceof SortedWeights) {
/* 163 */       SortedWeights spa = (SortedWeights)obj;
/* 164 */       if (size() != spa.size()) {
/* 165 */         return false;
/*     */       }
/* 167 */       for (int i = 0; i < size(); i++) {
/* 168 */         if (this.places[i] != spa.places[i]) {
/* 169 */           return false;
/*     */         }
/*     */       } 
/* 172 */       return true;
/*     */     } 
/* 174 */     return isEqual((Marking)obj);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 180 */     int h = this.hashC;
/* 181 */     if (h == 0) {
/* 182 */       for (int i = 0; i < size(); i++) {
/* 183 */         if (this.places[i] != null) {
/* 184 */           this.hashC = 31 * this.hashC + this.places[i].getId();
/*     */         }
/*     */       } 
/*     */       
/* 188 */       h = this.hashC;
/*     */     } 
/* 190 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addPlace(int id, int token) {
/* 197 */     int i = 0;
/* 198 */     boolean b = true;
/* 199 */     int index = 0;
/*     */ 
/*     */     
/* 202 */     for (i = 0; b && i < this.places.length; i++) {
/* 203 */       if (this.places[i] == null || this.places[i].getId() >= id) {
/*     */ 
/*     */ 
/*     */         
/* 207 */         b = false;
/* 208 */         index = i;
/* 209 */         if (this.places[i] != null && this.places[i].getId() == id) {
/* 210 */           addToken(i, token);
/* 211 */           return this.places[i].getToken();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 216 */     for (i = this.places.length - 1; i > index; i--) {
/* 217 */       this.places[i] = this.places[i - 1];
/*     */     }
/* 219 */     this.places[index] = LookUpTable.addPlace(id, token);
/* 220 */     this.size++;
/* 221 */     return token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int isSubSet2(Marking sp) {
/* 229 */     if (!(sp instanceof SortedWeights)) {
/* 230 */       return -1;
/*     */     }
/* 232 */     SortedWeights spa = (SortedWeights)sp;
/* 233 */     if (size() > spa.size()) {
/* 234 */       return UnsignedByte.min - 1;
/*     */     }
/* 236 */     int ret = 0;
/* 237 */     int index = 0;
/* 238 */     int i = 0;
/* 239 */     Weight current = get(index);
/* 240 */     while (index < size()) {
/*     */       
/* 242 */       int curId = current.getId();
/* 243 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 244 */         if (spa.getId(i) > curId) {
/* 245 */           return -1;
/*     */         }
/* 247 */         i++;
/*     */       } 
/* 249 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 250 */         return -1;
/*     */       }
/* 252 */       if (i < spa.size() && current.less(spa.get(i)) == 0) {
/* 253 */         ret++;
/*     */       }
/*     */       
/* 256 */       current = get(++index);
/* 257 */       i++;
/*     */     } 
/*     */     
/* 260 */     return spa.size() - ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Integer> scapeGoats(Marking spa) {
/* 267 */     Collection<Integer> c = new Vector<>();
/* 268 */     int index = 0;
/* 269 */     int i = 0;
/* 270 */     Weight current = get(index);
/* 271 */     while (index < size()) {
/* 272 */       int curId = current.getId();
/* 273 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 274 */         i++;
/*     */       }
/* 276 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 277 */         c.add(new Integer(curId));
/* 278 */         i = 0;
/* 279 */         current = get(++index);
/*     */         
/*     */         continue;
/*     */       } 
/* 283 */       current = get(++index);
/* 284 */       i++;
/*     */     } 
/* 286 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public int fSG(Marking spa) {
/* 291 */     int index = 0;
/* 292 */     int i = 0;
/* 293 */     Weight current = get(index);
/* 294 */     while (index < size()) {
/* 295 */       int curId = current.getId();
/* 296 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 297 */         i++;
/*     */       }
/* 299 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 300 */         return curId;
/*     */       }
/* 302 */       current = get(++index);
/* 303 */       i++;
/*     */     } 
/* 305 */     return UnsignedByte.min - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean retains(Marking s) {
/* 311 */     int index = 0;
/* 312 */     int i = 0;
/* 313 */     Weight current = get(index);
/*     */     
/* 315 */     while (index < size()) {
/* 316 */       Weight current2 = s.get(i);
/*     */       
/* 318 */       int curId = current.getId();
/* 319 */       while (i < s.size() && current2.getId() < curId) {
/* 320 */         current2 = s.get(++i);
/*     */       }
/* 322 */       if (i < s.size() && curId == current2.getId()) {
/* 323 */         return true;
/*     */       }
/* 325 */       current2 = s.get(++i);
/* 326 */       current = get(++index);
/*     */     } 
/* 328 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SortedWeights.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */