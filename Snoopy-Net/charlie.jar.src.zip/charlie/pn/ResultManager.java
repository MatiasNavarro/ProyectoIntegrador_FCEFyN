/*      */ package charlie.pn;
/*      */ 
/*      */ import GUI.preference.Preference;
/*      */ import GUI.preference.PreferenceFactory;
/*      */ import charlie.pn.rules.ExtendedRule;
/*      */ import charlie.pn.rules.Rule;
/*      */ import charlie.pn.rules.RuleGroup;
/*      */ import charlie.pn.rules.StateMachineRule001;
/*      */ import charlie.pn.rules.StateMachineRule002;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import javax.swing.JOptionPane;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ResultManager
/*      */ {
/*   28 */   private static final Log LOG = LogFactory.getLog(ResultManager.class);
/*      */   
/*   30 */   public static final String DESCRIPTION_SEPARATOR = RuleGroup.SEPARATOR_GROUP.getDescription();
/*      */   
/*      */   public static final String DESCRIPTION_MORE_ELEMENTS = "** ";
/*      */   
/*      */   public static final String DESCRIPTION_NEXT_ELEMENT = "++ ";
/*      */   
/*   36 */   private static final ArrayList<Rule> ruleList = new ArrayList<>();
/*      */   
/*   38 */   private static final ArrayList<RuleGroup> ruleGroupList = new ArrayList<>();
/*      */   
/*   40 */   private static final Set<Rule> appliedRuleSet = new HashSet<>();
/*      */   
/*      */   private static boolean initialized = false;
/*      */   public static boolean gui = true;
/*      */   
/*      */   protected ResultManager() {
/*   46 */     initialize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reset() {
/*   53 */     appliedRuleSet.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void initialize() {
/*   60 */     if (!initialized) {
/*   61 */       createRules();
/*      */       
/*   63 */       addSeparator();
/*      */       
/*   65 */       initialized = true;
/*      */       
/*   67 */       appliedRuleSet.clear();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Results applyRules(Results results, Object object) throws ResultContradictionException {
/*   72 */     if (!initialized) {
/*   73 */       initialize();
/*      */     }
/*      */     
/*   76 */     Results newResults = new Results();
/*   77 */     Results returnResults = new Results();
/*   78 */     newResults.mergeWith(results);
/*   79 */     boolean rulesApplied = false;
/*      */     
/*   81 */     List<Rule> applyableRules = checkApplyableRules(newResults, object);
/*      */     
/*   83 */     if (applyableRules.size() <= 0) {
/*   84 */       return null;
/*      */     }
/*      */     
/*   87 */     while (applyableRules.size() > 0) {
/*   88 */       for (Rule rule : applyableRules) {
/*      */         
/*   90 */         Results tempResults = rule.applyRule(newResults);
/*      */         
/*   92 */         newResults.mergeWithCheckForContradiction(tempResults, rule);
/*   93 */         returnResults.mergeWithCheckForContradiction(tempResults, rule);
/*   94 */         rulesApplied = true;
/*      */       } 
/*   96 */       applyableRules = checkApplyableRules(newResults, object);
/*      */     } 
/*   98 */     if (rulesApplied) {
/*   99 */       LOG.debug(String.format("Rules applied: results = %s", new Object[] { returnResults.toString() }));
/*  100 */       return returnResults;
/*      */     } 
/*  102 */     LOG.debug("No rules can be applied to the current result set.");
/*  103 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Rule> checkApplyableRules(Results results, Object object) {
/*  121 */     int i = 0;
/*  122 */     StringBuilder buf = new StringBuilder();
/*  123 */     buf.append("The following rules can be applied to this result set:\n");
/*  124 */     List<Rule> indices = new ArrayList<>();
/*  125 */     for (Rule r : ruleList) {
/*  126 */       if (appliedRuleSet.contains(r)) {
/*      */         continue;
/*      */       }
/*      */       
/*  130 */       boolean value = false;
/*  131 */       if (r instanceof ExtendedRule) {
/*  132 */         value = ((ExtendedRule)r).checkRule(results, object);
/*      */       } else {
/*  134 */         value = r.checkRule(results);
/*      */       } 
/*  136 */       if (value) {
/*  137 */         i++;
/*  138 */         indices.add(r);
/*  139 */         buf.append(r.getDescription());
/*  140 */         buf.append("\n");
/*      */       } 
/*      */     } 
/*  143 */     if (i > 0) {
/*  144 */       if (gui) {
/*  145 */         int answ = -1;
/*  146 */         if (Boolean.parseBoolean(PreferenceFactory.getPreferenceProperties().getProperty(Preference.APPLY_RULES_PROPERTY.getKey(), Preference.APPLY_RULES_PROPERTY.getDefault()))) {
/*      */           
/*  148 */           answ = 0;
/*      */         } else {
/*  150 */           answ = JOptionPane.showConfirmDialog(null, buf.toString(), "Apply rules ?", 0);
/*      */         } 
/*      */         
/*  153 */         if (answ == 0) {
/*  154 */           LOG.info(String.format("Applying rules: %s", new Object[] { indices.toString().replaceAll("\n", "") }));
/*      */           
/*  156 */           appliedRuleSet.addAll(indices);
/*      */         } else {
/*      */           
/*  159 */           i = 0;
/*  160 */           indices.clear();
/*      */         } 
/*      */       } else {
/*  163 */         LOG.info(String.format("Applying rules: %s", new Object[] { indices.toString().replaceAll("\n", "") }));
/*      */ 
/*      */         
/*  166 */         appliedRuleSet.addAll(indices);
/*      */       } 
/*      */     } else {
/*  169 */       buf = null;
/*      */       
/*  171 */       i = 0;
/*      */     } 
/*  173 */     return indices;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addRule(Rule _rule) {
/*  182 */     ruleList.add(_rule);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  187 */     RuleGroup pluginRuleGroup = new RuleGroup();
/*  188 */     pluginRuleGroup.setDescription(_rule.getDescription());
/*  189 */     pluginRuleGroup.addRule(_rule);
/*      */ 
/*      */     
/*  192 */     ruleGroupList.add(pluginRuleGroup);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addSeparator() {
/*  200 */     ruleGroupList.add(RuleGroup.SEPARATOR_GROUP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void createRules() {
/*  209 */     groupBoundaryNodes();
/*      */ 
/*      */     
/*  212 */     ruleGroupList.add(RuleGroup.SEPARATOR_GROUP);
/*      */ 
/*      */     
/*  215 */     groupLiveAndBound();
/*      */ 
/*      */     
/*  218 */     ruleGroupList.add(RuleGroup.SEPARATOR_GROUP);
/*      */ 
/*      */     
/*  221 */     groupCTIAndCPI();
/*      */ 
/*      */     
/*  224 */     ruleGroupList.add(RuleGroup.SEPARATOR_GROUP);
/*      */ 
/*      */     
/*  227 */     groupMGAndSM();
/*      */ 
/*      */     
/*  230 */     ruleGroupList.add(RuleGroup.SEPARATOR_GROUP);
/*      */ 
/*      */     
/*  233 */     groupSiphonTrapProperty();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  265 */     ruleGroupList.add(RuleGroup.SEPARATOR_GROUP);
/*      */ 
/*      */     
/*  268 */     groupDeadState();
/*      */ 
/*      */     
/*  271 */     ruleGroupList.add(RuleGroup.SEPARATOR_GROUP);
/*      */ 
/*      */     
/*  274 */     groupRankTheorem();
/*      */ 
/*      */     
/*  277 */     ruleGroupList.add(RuleGroup.SEPARATOR_GROUP);
/*      */ 
/*      */     
/*  280 */     groupTrivial();
/*      */ 
/*      */     
/*  283 */     ruleGroupList.add(RuleGroup.SEPARATOR_GROUP);
/*      */ 
/*      */     
/*  286 */     groupUnderTest();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void groupCTIAndCPI() {
/*  293 */     RuleGroup gr = new RuleGroup();
/*  294 */     gr.setDescription("REV => CTI");
/*      */     
/*  296 */     Rule r = new Rule();
/*  297 */     r.setDescription("REV => CTI");
/*  298 */     r.addPreResult(25, 0, true);
/*  299 */     r.addPostResult(16, true);
/*  300 */     ruleList.add(r);
/*  301 */     gr.addRule(r);
/*      */     
/*  303 */     r = new Rule();
/*  304 */     r.setDescription("!CTI => !REV");
/*  305 */     r.addPreResult(16, 0, false);
/*  306 */     r.addPostResult(25, false);
/*  307 */     ruleList.add(r);
/*  308 */     gr.addRule(r);
/*      */     
/*  310 */     ruleGroupList.add(gr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void groupTrivial() {
/*  317 */     RuleGroup gr = new RuleGroup();
/*  318 */     gr.setDescription("trivial rules");
/*  319 */     Rule r = new Rule();
/*  320 */     r.setDescription("SB => k-B");
/*  321 */     r.addPreResult(18, 0, true);
/*  322 */     r.addPostResult(19, true);
/*  323 */     ruleList.add(r);
/*  324 */     gr.addRule(r);
/*      */     
/*  326 */     r = new Rule();
/*  327 */     r.setDescription("!k-B => !SB");
/*  328 */     r.addPreResult(19, 0, false);
/*  329 */     r.addPostResult(18, false);
/*  330 */     ruleList.add(r);
/*  331 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */     
/*  335 */     r = new Rule();
/*  336 */     r.setDescription("SC => CON");
/*  337 */     r.addPreResult(11, 0, true);
/*  338 */     r.addPostResult(10, true);
/*  339 */     ruleList.add(r);
/*  340 */     gr.addRule(r);
/*      */     
/*  342 */     r = new Rule();
/*  343 */     r.setDescription("!CON => !SC");
/*  344 */     r.addPreResult(10, 0, false);
/*  345 */     r.addPostResult(11, false);
/*  346 */     ruleList.add(r);
/*  347 */     gr.addRule(r);
/*      */ 
/*      */     
/*  350 */     r = new Rule();
/*  351 */     r.setDescription("1-B => k-B");
/*  352 */     r.addPreResult(20, 0, true);
/*  353 */     r.addPostResult(19, 1);
/*  354 */     ruleList.add(r);
/*  355 */     gr.addRule(r);
/*      */     
/*  357 */     r = new Rule();
/*  358 */     r.setDescription("!k-B => !1-B");
/*  359 */     r.addPreResult(19, 0, false);
/*  360 */     r.addPostResult(20, false);
/*  361 */     ruleList.add(r);
/*  362 */     gr.addRule(r);
/*      */ 
/*      */     
/*  365 */     r = new Rule();
/*  366 */     r.setDescription("!SB => !CPI");
/*  367 */     r.addPreResult(18, 0, false);
/*  368 */     r.addPostResult(15, false);
/*  369 */     ruleList.add(r);
/*  370 */     gr.addRule(r);
/*      */ 
/*      */     
/*  373 */     r = new Rule();
/*  374 */     r.setDescription("CPI => SB");
/*  375 */     r.addPreResult(15, 0, true);
/*  376 */     r.addPostResult(18, true);
/*  377 */     ruleList.add(r);
/*  378 */     gr.addRule(r);
/*      */ 
/*      */     
/*  381 */     r = new Rule();
/*  382 */     r.setDescription("!CTI => !SCTI");
/*  383 */     r.addPreResult(16, 0, false);
/*  384 */     r.addPostResult(17, false);
/*  385 */     ruleList.add(r);
/*  386 */     gr.addRule(r);
/*      */ 
/*      */     
/*  389 */     r = new Rule();
/*  390 */     r.setDescription("SCF => DCF");
/*  391 */     r.addPreResult(5, 0, true);
/*  392 */     r.addPostResult(21, true);
/*  393 */     ruleList.add(r);
/*  394 */     gr.addRule(r);
/*      */     
/*  396 */     ruleGroupList.add(gr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void groupRankTheorem() {
/*  405 */     RuleGroup gr = new RuleGroup();
/*  406 */     gr.setDescription("rank theorem");
/*  407 */     Rule r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  410 */           Result rankResult = results.getResult(27);
/*  411 */           Result sccsResult = results.getResult(28);
/*      */           
/*  413 */           if (rankResult == null || sccsResult == null)
/*  414 */             return false; 
/*  415 */           if (((Integer)rankResult.getValueObject()).intValue() == ((Integer)sccsResult.getValueObject()).intValue() - 1) {
/*  416 */             return true;
/*      */           }
/*      */           
/*  419 */           return false;
/*      */         }
/*      */       };
/*  422 */     r.setDescription("rank(IM) = |SCCS| - 1 => RKTH");
/*  423 */     r.addPostResult(13, true);
/*  424 */     ruleList.add(r);
/*  425 */     gr.addRule(r);
/*      */     
/*  427 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  430 */           Result rankResult = results.getResult(27);
/*  431 */           Result sccsResult = results.getResult(28);
/*      */           
/*  433 */           if (rankResult == null || sccsResult == null)
/*  434 */             return false; 
/*  435 */           if (((Integer)rankResult.getValueObject()).intValue() != ((Integer)sccsResult.getValueObject()).intValue() - 1) {
/*  436 */             return true;
/*      */           }
/*      */           
/*  439 */           return false;
/*      */         }
/*      */       };
/*  442 */     r.setDescription("rank(IM) != |SCCS| - 1 => !RKTH");
/*  443 */     r.addPostResult(13, false);
/*  444 */     ruleList.add(r);
/*  445 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */     
/*  449 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  452 */           Result rankResult = results.getResult(27);
/*  453 */           Result sccsResult = results.getResult(28);
/*      */           
/*  455 */           if (rankResult == null || sccsResult == null)
/*  456 */             return false; 
/*  457 */           if (((Integer)rankResult.getValueObject()).intValue() == ((Integer)sccsResult.getValueObject()).intValue() - 1) {
/*  458 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  461 */           return false;
/*      */         }
/*      */       };
/*  464 */     r.setDescription("CPI & CTI & rank(IM) = |SCCS| - 1 => LIV");
/*  465 */     r.addPreResult(15, 0, true);
/*  466 */     r.addPreResult(16, 0, true);
/*  467 */     r.addPostResult(24, true);
/*  468 */     ruleList.add(r);
/*  469 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  475 */     r = new Rule();
/*  476 */     r.setDescription("LIV & k-B & CON => SC & CTI");
/*  477 */     r.addPreResult(19, 0, true);
/*  478 */     r.addPreResult(24, 0, true);
/*  479 */     r.addPreResult(10, 0, true);
/*  480 */     r.addPostResult(11, true);
/*  481 */     r.addPostResult(16, true);
/*  482 */     ruleList.add(r);
/*  483 */     gr.addRule(r);
/*      */ 
/*      */     
/*  486 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  489 */           Result rankResult = results.getResult(27);
/*  490 */           Result secsResult = results.getResult(29);
/*      */           
/*  492 */           if (rankResult == null || secsResult == null)
/*  493 */             return false; 
/*  494 */           if (((Integer)rankResult.getValueObject()).intValue() <= ((Integer)secsResult.getValueObject()).intValue() - 1) {
/*  495 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  498 */           return false;
/*      */         }
/*      */       };
/*  501 */     r.setDescription("!k-B & SC & CTI & rank(IM) < |SEQS| => !LIV");
/*  502 */     r.addPreResult(19, 0, false);
/*  503 */     r.addPreResult(11, 0, true);
/*  504 */     r.addPreResult(16, 0, true);
/*  505 */     r.addPostResult(24, false);
/*  506 */     ruleList.add(r);
/*  507 */     gr.addRule(r);
/*      */ 
/*      */     
/*  510 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  513 */           Result rankResult = results.getResult(27);
/*  514 */           Result secsResult = results.getResult(29);
/*      */           
/*  516 */           if (rankResult == null || secsResult == null)
/*  517 */             return false; 
/*  518 */           if (((Integer)rankResult.getValueObject()).intValue() <= ((Integer)secsResult.getValueObject()).intValue() - 1) {
/*  519 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  522 */           return false;
/*      */         }
/*      */       };
/*  525 */     r.setDescription("k-B & CON & !SC & CTI & rank(IM) < |SEQS| => !LIV");
/*  526 */     r.addPreResult(10, 0, true);
/*  527 */     r.addPreResult(19, 0, true);
/*  528 */     r.addPreResult(11, 0, false);
/*  529 */     r.addPreResult(16, 0, true);
/*  530 */     r.addPostResult(24, false);
/*  531 */     ruleList.add(r);
/*  532 */     gr.addRule(r);
/*      */ 
/*      */     
/*  535 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  538 */           Result rankResult = results.getResult(27);
/*  539 */           Result secsResult = results.getResult(29);
/*      */           
/*  541 */           if (rankResult == null || secsResult == null)
/*  542 */             return false; 
/*  543 */           if (((Integer)rankResult.getValueObject()).intValue() <= ((Integer)secsResult.getValueObject()).intValue() - 1) {
/*  544 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  547 */           return false;
/*      */         }
/*      */       };
/*  550 */     r.setDescription("k-B & !SC & CTI & rank(IM) < |SEQS| => !LIV");
/*  551 */     r.addPreResult(19, 0, true);
/*  552 */     r.addPreResult(11, 0, true);
/*  553 */     r.addPreResult(16, 0, false);
/*  554 */     r.addPostResult(24, false);
/*  555 */     ruleList.add(r);
/*  556 */     gr.addRule(r);
/*      */ 
/*      */     
/*  559 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  562 */           Result rankResult = results.getResult(27);
/*  563 */           Result secsResult = results.getResult(29);
/*      */           
/*  565 */           if (rankResult == null || secsResult == null)
/*  566 */             return false; 
/*  567 */           if (((Integer)rankResult.getValueObject()).intValue() >= ((Integer)secsResult.getValueObject()).intValue()) {
/*  568 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  571 */           return false;
/*      */         }
/*      */       };
/*  574 */     r.setDescription("k-B & SC & CTI & rank(IM) >= |SEQS| => !LIV");
/*  575 */     r.addPreResult(19, 0, true);
/*  576 */     r.addPreResult(11, 0, true);
/*  577 */     r.addPreResult(16, 0, true);
/*  578 */     r.addPostResult(24, false);
/*  579 */     ruleList.add(r);
/*  580 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  585 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  588 */           Result rankResult = results.getResult(27);
/*  589 */           Result secsResult = results.getResult(29);
/*      */           
/*  591 */           if (rankResult == null || secsResult == null)
/*  592 */             return false; 
/*  593 */           if (((Integer)rankResult.getValueObject()).intValue() <= ((Integer)secsResult.getValueObject()).intValue() - 1) {
/*  594 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  597 */           return false;
/*      */         }
/*      */       };
/*  600 */     r.setDescription("LIV & CON & !SC & CTI & rank(IM) < |SEQS| => !k-B");
/*  601 */     r.addPreResult(10, 0, true);
/*  602 */     r.addPreResult(24, 0, true);
/*  603 */     r.addPreResult(11, 0, false);
/*  604 */     r.addPreResult(16, 0, true);
/*  605 */     r.addPostResult(19, false);
/*  606 */     ruleList.add(r);
/*  607 */     gr.addRule(r);
/*      */ 
/*      */     
/*  610 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  613 */           Result rankResult = results.getResult(27);
/*  614 */           Result secsResult = results.getResult(29);
/*      */           
/*  616 */           if (rankResult == null || secsResult == null)
/*  617 */             return false; 
/*  618 */           if (((Integer)rankResult.getValueObject()).intValue() <= ((Integer)secsResult.getValueObject()).intValue() - 1) {
/*  619 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  622 */           return false;
/*      */         }
/*      */       };
/*  625 */     r.setDescription("LIV & SC & !CTI & rank(IM) < |SEQS| => !k-B");
/*  626 */     r.addPreResult(24, 0, true);
/*  627 */     r.addPreResult(11, 0, true);
/*  628 */     r.addPreResult(16, 0, false);
/*  629 */     r.addPostResult(19, false);
/*  630 */     ruleList.add(r);
/*  631 */     gr.addRule(r);
/*      */ 
/*      */     
/*  634 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  637 */           Result rankResult = results.getResult(27);
/*  638 */           Result secsResult = results.getResult(29);
/*      */           
/*  640 */           if (rankResult == null || secsResult == null)
/*  641 */             return false; 
/*  642 */           if (((Integer)rankResult.getValueObject()).intValue() <= ((Integer)secsResult.getValueObject()).intValue() - 1) {
/*  643 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  646 */           return false;
/*      */         }
/*      */       };
/*  649 */     r.setDescription("!LIV & SC & CTI & rank(IM) < |SEQS| => !k-B");
/*  650 */     r.addPreResult(24, 0, false);
/*  651 */     r.addPreResult(11, 0, true);
/*  652 */     r.addPreResult(16, 0, true);
/*  653 */     r.addPostResult(19, false);
/*  654 */     ruleList.add(r);
/*  655 */     gr.addRule(r);
/*      */ 
/*      */     
/*  658 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  661 */           Result rankResult = results.getResult(27);
/*  662 */           Result secsResult = results.getResult(29);
/*      */           
/*  664 */           if (rankResult == null || secsResult == null)
/*  665 */             return false; 
/*  666 */           if (((Integer)rankResult.getValueObject()).intValue() >= ((Integer)secsResult.getValueObject()).intValue()) {
/*  667 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  670 */           return false;
/*      */         }
/*      */       };
/*  673 */     r.setDescription("LIV & SC & CTI & rank(IM) >= |SEQS| => !k-B");
/*  674 */     r.addPreResult(24, 0, true);
/*  675 */     r.addPreResult(11, 0, true);
/*  676 */     r.addPreResult(16, 0, true);
/*  677 */     r.addPostResult(19, false);
/*  678 */     ruleList.add(r);
/*  679 */     gr.addRule(r);
/*      */ 
/*      */     
/*  682 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  688 */     gr = new RuleGroup();
/*  689 */     gr.setDescription("|SEQS| = |SCCS| & SC & rank(IM) < |SEQS| => (CPI <=> CTI)");
/*      */ 
/*      */     
/*  692 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  695 */           Result rankResult = results.getResult(27);
/*  696 */           Result sccsResult = results.getResult(28);
/*  697 */           Result secsResult = results.getResult(29);
/*      */           
/*  699 */           if (sccsResult == null || secsResult == null || rankResult == null)
/*  700 */             return false; 
/*  701 */           if (((Integer)sccsResult.getValueObject()).intValue() == ((Integer)secsResult.getValueObject()).intValue() && ((Integer)rankResult
/*  702 */             .getValueObject()).intValue() < ((Integer)secsResult.getValueObject()).intValue()) {
/*  703 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  706 */           return false;
/*      */         }
/*      */       };
/*  709 */     r.setDescription("|SEQS| = |SCCS| & SC & rank(IM) < |SEQS| & CPI => CTI");
/*  710 */     r.addPreResult(11, 0, true);
/*  711 */     r.addPreResult(15, 0, true);
/*  712 */     r.addPostResult(16, true);
/*      */     
/*  714 */     ruleList.add(r);
/*  715 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */     
/*  719 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  722 */           Result rankResult = results.getResult(27);
/*  723 */           Result sccsResult = results.getResult(28);
/*  724 */           Result secsResult = results.getResult(29);
/*      */           
/*  726 */           if (sccsResult == null || secsResult == null || rankResult == null)
/*  727 */             return false; 
/*  728 */           if (((Integer)sccsResult.getValueObject()).intValue() == ((Integer)secsResult.getValueObject()).intValue() && ((Integer)rankResult
/*  729 */             .getValueObject()).intValue() < ((Integer)secsResult.getValueObject()).intValue()) {
/*  730 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  733 */           return false;
/*      */         }
/*      */       };
/*  736 */     r.setDescription("|SEQS| = |SCCS| & SC & rank(IM) < |SEQS| & !CPI => !CTI");
/*  737 */     r.addPreResult(11, 0, true);
/*  738 */     r.addPreResult(15, 0, false);
/*  739 */     r.addPostResult(16, false);
/*  740 */     ruleList.add(r);
/*  741 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */     
/*  745 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  748 */           Result rankResult = results.getResult(27);
/*  749 */           Result sccsResult = results.getResult(28);
/*  750 */           Result secsResult = results.getResult(29);
/*      */           
/*  752 */           if (sccsResult == null || secsResult == null || rankResult == null)
/*  753 */             return false; 
/*  754 */           if (((Integer)sccsResult.getValueObject()).intValue() == ((Integer)secsResult.getValueObject()).intValue() && ((Integer)rankResult
/*  755 */             .getValueObject()).intValue() < ((Integer)secsResult.getValueObject()).intValue()) {
/*  756 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  759 */           return false;
/*      */         }
/*      */       };
/*  762 */     r.setDescription("|SEQS| = |SCCS| & SC & rank(IM) < |SEQS| & CTI => CPI");
/*  763 */     r.addPreResult(11, 0, true);
/*  764 */     r.addPreResult(16, 0, true);
/*  765 */     r.addPostResult(15, true);
/*      */     
/*  767 */     ruleList.add(r);
/*  768 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */     
/*  772 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  775 */           Result rankResult = results.getResult(27);
/*  776 */           Result sccsResult = results.getResult(28);
/*  777 */           Result secsResult = results.getResult(29);
/*      */           
/*  779 */           if (sccsResult == null || secsResult == null || rankResult == null)
/*  780 */             return false; 
/*  781 */           if (((Integer)sccsResult.getValueObject()).intValue() == ((Integer)secsResult.getValueObject()).intValue() && ((Integer)rankResult
/*  782 */             .getValueObject()).intValue() < ((Integer)secsResult.getValueObject()).intValue()) {
/*  783 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  786 */           return false;
/*      */         }
/*      */       };
/*  789 */     r.setDescription("|SEQS| = |SCCS| & SC & rank(IM) < |SEQS| & !CTI => !CPI");
/*  790 */     r.addPreResult(11, 0, true);
/*  791 */     r.addPreResult(16, 0, false);
/*  792 */     r.addPostResult(15, false);
/*      */     
/*  794 */     ruleList.add(r);
/*  795 */     gr.addRule(r);
/*      */     
/*  797 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  803 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  806 */           Result rankResult = results.getResult(27);
/*  807 */           Result sccsResult = results.getResult(28);
/*  808 */           Result secsResult = results.getResult(29);
/*      */           
/*  810 */           if (sccsResult == null || secsResult == null || rankResult == null)
/*  811 */             return false; 
/*  812 */           if (((Integer)sccsResult.getValueObject()).intValue() == ((Integer)secsResult.getValueObject()).intValue()) {
/*  813 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  816 */           return false;
/*      */         }
/*      */       };
/*  819 */     r.setDescription("|SEQS| = |SCCS| & LIV & k-B => SB");
/*  820 */     r.addPreResult(24, 0, true);
/*  821 */     r.addPreResult(19, 0, true);
/*  822 */     r.addPostResult(18, true);
/*      */     
/*  824 */     ruleList.add(r);
/*  825 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */     
/*  829 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  832 */           Result rankResult = results.getResult(27);
/*  833 */           Result sccsResult = results.getResult(28);
/*  834 */           Result secsResult = results.getResult(29);
/*      */           
/*  836 */           if (sccsResult == null || secsResult == null || rankResult == null)
/*  837 */             return false; 
/*  838 */           if (((Integer)sccsResult.getValueObject()).intValue() == ((Integer)secsResult.getValueObject()).intValue()) {
/*  839 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  842 */           return false;
/*      */         }
/*      */       };
/*  845 */     r.setDescription("|SEQS| = |SCCS| & LIV & !k-B => !SB");
/*  846 */     r.addPreResult(24, 0, true);
/*  847 */     r.addPreResult(19, 0, false);
/*  848 */     r.addPostResult(18, false);
/*      */     
/*  850 */     ruleList.add(r);
/*  851 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */     
/*  855 */     r = new Rule()
/*      */       {
/*      */         public boolean checkPreConditions(Results results) {
/*  858 */           Result rankResult = results.getResult(27);
/*  859 */           Result sccsResult = results.getResult(28);
/*  860 */           Result secsResult = results.getResult(29);
/*      */           
/*  862 */           if (sccsResult == null || secsResult == null || rankResult == null)
/*  863 */             return false; 
/*  864 */           if (((Integer)sccsResult.getValueObject()).intValue() == ((Integer)secsResult.getValueObject()).intValue()) {
/*  865 */             return super.checkPreConditions(results);
/*      */           }
/*      */           
/*  868 */           return false;
/*      */         }
/*      */       };
/*  871 */     r.setDescription("|SEQS| = |SCCS| & LIV & !SB => !k-B");
/*  872 */     r.addPreResult(24, 0, true);
/*  873 */     r.addPreResult(18, 0, false);
/*  874 */     r.addPostResult(19, false);
/*      */     
/*  876 */     ruleList.add(r);
/*  877 */     gr.addRule(r);
/*      */     
/*  879 */     ruleGroupList.add(gr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void groupDeadState() {
/*  887 */     RuleGroup gr = new RuleGroup();
/*  888 */     gr.setDescription("LIV => ! DSt & ! DTr");
/*      */ 
/*      */     
/*  891 */     Rule r = new Rule();
/*  892 */     r.addPreResult(24, 0, true);
/*  893 */     r.addPostResult(22, 0);
/*  894 */     r.addPostResult(23, true);
/*  895 */     r.setDescription("LIV => ! DSt & ! DTr");
/*  896 */     ruleList.add(r);
/*  897 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  902 */     r = new Rule();
/*  903 */     r.addPreResult(22, 1, 0);
/*  904 */     r.addPostResult(24, false);
/*  905 */     r.setDescription("DSt => !LIV");
/*  906 */     ruleList.add(r);
/*  907 */     gr.addRule(r);
/*      */     
/*  909 */     ruleGroupList.add(gr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void groupSiphonTrapProperty() {
/*  918 */     RuleGroup gr = new RuleGroup();
/*  919 */     gr.setDescription("no siphons => LIV");
/*      */ 
/*      */     
/*  922 */     Rule r = new Rule();
/*  923 */     r.addPreResult(26, 0, false);
/*  924 */     r.addPostResult(24, true);
/*  925 */     r.setDescription("no siphons => LIV");
/*  926 */     ruleList.add(r);
/*  927 */     gr.addRule(r);
/*      */     
/*  929 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  935 */     gr = new RuleGroup();
/*  936 */     gr.setDescription("Siphon Trap Property (for ES, EFC, FC, SM and MG)");
/*      */ 
/*      */ 
/*      */     
/*  940 */     ExtendedRule er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/*  943 */           addPreResult(14, 0, true);
/*  944 */           addPreResult(2, 0, true);
/*  945 */           addPreResult(3, 0, true);
/*  946 */           addPostResult(22, 0);
/*  947 */           setDescription("STP & HOM & NBM => !DSt");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/*  952 */           if (object instanceof PlaceTransitionNet) {
/*  953 */             PlaceTransitionNet pn = (PlaceTransitionNet)object;
/*  954 */             return (pn.determineNetClass() > 4);
/*      */           } 
/*  956 */           return false;
/*      */         }
/*      */       };
/*      */     
/*  960 */     ruleList.add(er);
/*  961 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/*  965 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/*  968 */           addPreResult(14, 0, true);
/*  969 */           addPreResult(2, 0, true);
/*  970 */           addPreResult(3, 0, true);
/*  971 */           addPostResult(22, 0);
/*  972 */           setDescription("STP & HOM & NMB & !ES => !Dst");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/*  977 */           if (!(object instanceof PlaceTransitionNet)) {
/*  978 */             return false;
/*      */           }
/*  980 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/*  981 */           return (pn.determineNetClass() == 5);
/*      */         }
/*      */       };
/*      */     
/*  985 */     ruleList.add(er);
/*  986 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/*  990 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/*  993 */           addPreResult(14, 0, true);
/*  994 */           addPreResult(2, 0, true);
/*  995 */           addPreResult(3, 0, true);
/*  996 */           addPostResult(24, true);
/*  997 */           setDescription("STP & HOM & NMB & ES => LIV");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1002 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1003 */             return false;
/*      */           }
/* 1005 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1006 */           return (pn.determineNetClass() == 4);
/*      */         }
/*      */       };
/*      */     
/* 1010 */     ruleList.add(er);
/* 1011 */     gr.addRule((Rule)er);
/*      */ 
/*      */     
/* 1014 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1017 */           addPreResult(14, 0, true);
/* 1018 */           addPreResult(2, 0, true);
/* 1019 */           addPreResult(3, 0, true);
/* 1020 */           addPostResult(24, true);
/* 1021 */           setDescription("STP & HOM & NMB & EFC => LIV");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1026 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1027 */             return false;
/*      */           }
/* 1029 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1030 */           return (pn.determineNetClass() == 3);
/*      */         }
/*      */       };
/*      */     
/* 1034 */     ruleList.add(er);
/* 1035 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1039 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1042 */           addPreResult(14, 0, true);
/* 1043 */           addPreResult(2, 0, true);
/* 1044 */           addPreResult(3, 0, true);
/* 1045 */           addPostResult(24, true);
/* 1046 */           setDescription("STP & HOM & NMB & FC => LIV");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1051 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1052 */             return false;
/*      */           }
/* 1054 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1055 */           return (pn.determineNetClass() == 2);
/*      */         }
/*      */       };
/*      */     
/* 1059 */     ruleList.add(er);
/* 1060 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1064 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1067 */           addPreResult(14, 0, true);
/* 1068 */           addPreResult(2, 0, true);
/* 1069 */           addPreResult(3, 0, true);
/* 1070 */           addPostResult(24, true);
/* 1071 */           setDescription("STP & HOM & NMB & SM => LIV");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1076 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1077 */             return false;
/*      */           }
/* 1079 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1080 */           return (pn.determineNetClass() == 0);
/*      */         }
/*      */       };
/*      */     
/* 1084 */     ruleList.add(er);
/* 1085 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1089 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1092 */           addPreResult(14, 0, true);
/* 1093 */           addPreResult(2, 0, true);
/* 1094 */           addPreResult(3, 0, true);
/* 1095 */           addPostResult(24, true);
/* 1096 */           setDescription("STP & HOM & NMB & MG => LIV");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1101 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1102 */             return false;
/*      */           }
/* 1104 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1105 */           return (pn.determineNetClass() == 1);
/*      */         }
/*      */       };
/*      */     
/* 1109 */     ruleList.add(er);
/* 1110 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1114 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1117 */           addPreResult(14, 0, false);
/* 1118 */           addPreResult(2, 0, true);
/* 1119 */           addPreResult(3, 0, true);
/* 1120 */           addPostResult(24, false);
/* 1121 */           setDescription("!STP & HOM & NMB & EFC => !LIV");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1126 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1127 */             return false;
/*      */           }
/* 1129 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1130 */           return (pn.determineNetClass() == 3);
/*      */         }
/*      */       };
/*      */     
/* 1134 */     ruleList.add(er);
/* 1135 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1139 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1142 */           addPreResult(14, 0, false);
/* 1143 */           addPreResult(2, 0, true);
/* 1144 */           addPreResult(3, 0, true);
/* 1145 */           addPostResult(24, false);
/* 1146 */           setDescription("!STP & HOM & NMB & FC => !LIV");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1151 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1152 */             return false;
/*      */           }
/* 1154 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1155 */           return (pn.determineNetClass() == 2);
/*      */         }
/*      */       };
/*      */     
/* 1159 */     ruleList.add(er);
/* 1160 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1164 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1167 */           addPreResult(14, 0, false);
/* 1168 */           addPreResult(2, 0, true);
/* 1169 */           addPreResult(3, 0, true);
/* 1170 */           addPostResult(24, false);
/* 1171 */           setDescription("!STP & HOM & NMB & SM => !LIV");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1176 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1177 */             return false;
/*      */           }
/* 1179 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1180 */           return (pn.determineNetClass() == 0);
/*      */         }
/*      */       };
/*      */     
/* 1184 */     ruleList.add(er);
/* 1185 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1189 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1192 */           addPreResult(14, 0, false);
/* 1193 */           addPreResult(2, 0, true);
/* 1194 */           addPreResult(3, 0, true);
/* 1195 */           addPostResult(24, false);
/* 1196 */           setDescription("!STP & HOM & NMB & MG => !LIV");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1201 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1202 */             return false;
/*      */           }
/* 1204 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1205 */           return (pn.determineNetClass() == 1);
/*      */         }
/*      */       };
/*      */     
/* 1209 */     ruleList.add(er);
/* 1210 */     gr.addRule((Rule)er);
/*      */     
/* 1212 */     ruleGroupList.add(gr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void groupMGAndSM() {
/* 1220 */     RuleGroup gr = new RuleGroup();
/* 1221 */     gr.setDescription("MG => DCF");
/*      */ 
/*      */ 
/*      */     
/* 1225 */     ExtendedRule er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1228 */           addPostResult(21, true);
/* 1229 */           setDescription("MG => DCF");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1234 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1235 */             return false;
/*      */           }
/* 1237 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1238 */           return pn.isMG();
/*      */         }
/*      */       };
/* 1241 */     ruleList.add(er);
/* 1242 */     gr.addRule((Rule)er);
/*      */     
/* 1244 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1249 */     gr = new RuleGroup();
/* 1250 */     gr.setDescription("MG & ORD & SC => k-B");
/*      */ 
/*      */ 
/*      */     
/* 1254 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1257 */           addPreResult(1, 0, true);
/* 1258 */           addPreResult(11, 0, true);
/* 1259 */           addPostResult(19, true);
/* 1260 */           setDescription("MG & ORD & SC => k-B");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1265 */           if (object instanceof PlaceTransitionNet) {
/* 1266 */             PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1267 */             return pn.isMG();
/*      */           } 
/* 1269 */           return false;
/*      */         }
/*      */       };
/*      */     
/* 1273 */     ruleList.add(er);
/* 1274 */     gr.addRule((Rule)er);
/*      */     
/* 1276 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1281 */     gr = new RuleGroup();
/* 1282 */     gr.setDescription("SM & ORD => SB & k-B & CSV");
/*      */ 
/*      */     
/* 1285 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1288 */           addPreResult(1, 0, true);
/* 1289 */           addPostResult(18, true);
/* 1290 */           addPostResult(19, true);
/* 1291 */           addPostResult(4, true);
/* 1292 */           setDescription("SM & ORD => [SB & k-B & CSV]");
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1297 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1298 */             return false;
/*      */           }
/* 1300 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/* 1301 */           return pn.isSM();
/*      */         }
/*      */       };
/* 1304 */     ruleList.add(er);
/* 1305 */     gr.addRule((Rule)er);
/*      */     
/* 1307 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1335 */     gr = new RuleGroup();
/* 1336 */     gr.setDescription("SM & ORD : => [SC & token => LIV & k-B & REV]");
/*      */ 
/*      */     
/* 1339 */     StateMachineRule001 stateMachineRule001 = new StateMachineRule001();
/* 1340 */     ruleList.add(stateMachineRule001);
/* 1341 */     gr.addRule((Rule)stateMachineRule001);
/*      */ 
/*      */     
/* 1344 */     StateMachineRule002 stateMachineRule002 = new StateMachineRule002();
/* 1345 */     ruleList.add(stateMachineRule002);
/* 1346 */     gr.addRule((Rule)stateMachineRule002);
/*      */     
/* 1348 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1355 */     gr = new RuleGroup();
/* 1356 */     gr.setDescription("SM & CSV & CON => rank = |P| - 1");
/*      */ 
/*      */     
/* 1359 */     ExtendedRule extendedRule1 = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1362 */           setDescription("SM & CSV & CON => rank = |P| - 1");
/*      */           
/* 1364 */           addPreResult(4, 0, true);
/* 1365 */           addPreResult(10, 0, true);
/* 1366 */           addPostResult(27, 1);
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1371 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1372 */             return false;
/*      */           }
/* 1374 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/*      */           
/* 1376 */           addPostResult(27, pn.places() - 1);
/*      */           
/* 1378 */           return pn.isSM();
/*      */         }
/*      */       };
/* 1381 */     extendedRule1.setDescription("SM & CSV & CON => rank = |P| - 1");
/*      */     
/* 1383 */     ruleList.add(extendedRule1);
/*      */     
/* 1385 */     gr.addRule((Rule)extendedRule1);
/* 1386 */     ruleGroupList.add(gr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void groupLiveAndBound() {
/* 1394 */     RuleGroup gr = new RuleGroup();
/* 1395 */     gr.setDescription("LIV & k-B & CON => SC");
/*      */ 
/*      */     
/* 1398 */     Rule r = new Rule();
/* 1399 */     r.addPreResult(10, 0, true);
/* 1400 */     r.addPreResult(24, 0, true);
/* 1401 */     r.addPreResult(19, 0, true);
/* 1402 */     r.addPostResult(11, true);
/* 1403 */     r.setDescription("LIV & k-B & CON => SC");
/* 1404 */     ruleList.add(r);
/* 1405 */     gr.addRule(r);
/*      */     
/* 1407 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1412 */     gr = new RuleGroup();
/* 1413 */     gr.setDescription("LIV & k-B => CTI");
/*      */     
/* 1415 */     r = new Rule();
/* 1416 */     r.addPreResult(16, 0, false);
/* 1417 */     r.addPreResult(19, 0, true);
/* 1418 */     r.addPostResult(24, false);
/* 1419 */     r.setDescription("!CTI & k-B => !LIV");
/* 1420 */     ruleList.add(r);
/* 1421 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */     
/* 1425 */     r = new Rule();
/* 1426 */     r.addPreResult(24, 0, true);
/* 1427 */     r.addPreResult(19, 0, true);
/* 1428 */     r.addPostResult(16, true);
/* 1429 */     r.setDescription("LIV & k-B => CTI");
/* 1430 */     ruleList.add(r);
/*      */     
/* 1432 */     gr.addRule(r);
/* 1433 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1438 */     gr = new RuleGroup();
/* 1439 */     gr.setDescription("CSV | CPI => k-B & SB");
/*      */     
/* 1441 */     r = new Rule();
/* 1442 */     r.addPreResult(4, 0, true);
/* 1443 */     r.addPostResult(19, true);
/* 1444 */     r.setDescription("CSV => k-B");
/* 1445 */     ruleList.add(r);
/* 1446 */     gr.addRule(r);
/*      */ 
/*      */     
/* 1449 */     r = new Rule();
/* 1450 */     r.addPreResult(4, 0, true);
/* 1451 */     r.addPostResult(18, true);
/* 1452 */     r.setDescription("CSV => SB");
/* 1453 */     ruleList.add(r);
/* 1454 */     gr.addRule(r);
/*      */ 
/*      */     
/* 1457 */     r = new Rule();
/* 1458 */     r.addPreResult(15, 0, true);
/* 1459 */     r.addPostResult(19, true);
/* 1460 */     r.setDescription("CPI => k-B");
/* 1461 */     ruleList.add(r);
/* 1462 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */     
/* 1466 */     ruleGroupList.add(gr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void groupBoundaryNodes() {
/* 1474 */     RuleGroup gr = new RuleGroup();
/* 1475 */     gr.setDescription("!FT0 => !k-B & !1-B & !SB");
/*      */ 
/*      */     
/* 1478 */     Rule r = new Rule();
/* 1479 */     r.addPreResult(6, 0, false);
/* 1480 */     r.addPostResult(19, false);
/* 1481 */     r.addPostResult(18, false);
/* 1482 */     r.addPostResult(20, false);
/* 1483 */     r.setDescription("!FT0 => !k-B & !SB & !1-B");
/* 1484 */     ruleList.add(r);
/* 1485 */     gr.addRule(r);
/*      */     
/* 1487 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1492 */     gr = new RuleGroup();
/* 1493 */     gr.setDescription("!TF0 => !LIV | !k-B");
/*      */     
/* 1495 */     r = new Rule();
/* 1496 */     r.setDescription("!TF0 & LIV => !k-B");
/* 1497 */     r.addPreResult(7, 0, false);
/* 1498 */     r.addPreResult(24, 0, true);
/* 1499 */     r.addPostResult(19, false);
/* 1500 */     gr.addRule(r);
/*      */ 
/*      */     
/* 1503 */     r = new Rule();
/* 1504 */     r.setDescription("!TF0 & k-B => !LIV");
/* 1505 */     r.addPreResult(7, 0, false);
/* 1506 */     r.addPreResult(19, 0, true);
/* 1507 */     r.addPostResult(24, false);
/* 1508 */     gr.addRule(r);
/*      */     
/* 1510 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1516 */     gr = new RuleGroup();
/* 1517 */     gr.setDescription("!FP0 => !LIV");
/*      */     
/* 1519 */     r = new Rule();
/* 1520 */     r.addPreResult(8, 0, false);
/* 1521 */     r.addPostResult(24, false);
/*      */     
/* 1523 */     gr.addRule(r);
/*      */     
/* 1525 */     ruleGroupList.add(gr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1530 */     gr = new RuleGroup();
/* 1531 */     gr.setDescription("CON & !PF0 & LIV => !k-B");
/*      */ 
/*      */     
/* 1534 */     r = new Rule();
/*      */     
/* 1536 */     r.setDescription("!PF0 & LIV => !k-B");
/* 1537 */     r.addPreResult(9, 0, false);
/*      */     
/* 1539 */     r.addPreResult(24, 0, true);
/* 1540 */     r.addPostResult(19, false);
/* 1541 */     ruleList.add(r);
/*      */     
/* 1543 */     gr.addRule(r);
/* 1544 */     ruleGroupList.add(gr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void groupUnderTest() {
/* 1554 */     RuleGroup gr = new RuleGroup();
/* 1555 */     gr.setDescription("under test");
/*      */ 
/*      */ 
/*      */     
/* 1559 */     Rule r = new Rule();
/* 1560 */     r.setDescription("CSV => CPI");
/* 1561 */     r.addPreResult(4, 0, true);
/* 1562 */     r.addPostResult(15, true);
/* 1563 */     ruleList.add(r);
/* 1564 */     gr.addRule(r);
/*      */ 
/*      */ 
/*      */     
/* 1568 */     ExtendedRule er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1571 */           setDescription("SM & CSV => CPI");
/*      */           
/* 1573 */           addPreResult(4, 0, true);
/* 1574 */           addPostResult(15, true);
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1579 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1580 */             return false;
/*      */           }
/* 1582 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/*      */           
/* 1584 */           return pn.isSM();
/*      */         }
/*      */       };
/* 1587 */     er.setDescription("SM & CSV => CPI");
/* 1588 */     ruleList.add(er);
/* 1589 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1593 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1596 */           setDescription("SM & CSV & SC => CTI");
/*      */           
/* 1598 */           addPreResult(4, 0, true);
/* 1599 */           addPreResult(11, 0, true);
/* 1600 */           addPostResult(16, true);
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1605 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1606 */             return false;
/*      */           }
/* 1608 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/*      */           
/* 1610 */           return pn.isSM();
/*      */         }
/*      */       };
/* 1613 */     er.setDescription("SM & CSV & SC => CTI");
/* 1614 */     ruleList.add(er);
/* 1615 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1619 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1622 */           setDescription("SM & CON & CPI => rank(IM) = |P| - 1");
/*      */           
/* 1624 */           addPreResult(10, 0, true);
/* 1625 */           addPreResult(15, 0, true);
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1630 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1631 */             return false;
/*      */           }
/* 1633 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/*      */           
/* 1635 */           addPostResult(27, pn.places() - 1);
/*      */           
/* 1637 */           return pn.isSM();
/*      */         }
/*      */       };
/* 1640 */     er.setDescription("SM & CON & CPI => rank(IM) = |P| - 1");
/* 1641 */     ruleList.add(er);
/* 1642 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1646 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1649 */           setDescription("MG & ORD => CTI");
/*      */           
/* 1651 */           addPreResult(1, 0, true);
/* 1652 */           addPostResult(16, true);
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1657 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1658 */             return false;
/*      */           }
/* 1660 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/*      */           
/* 1662 */           return pn.isMG();
/*      */         }
/*      */       };
/* 1665 */     er.setDescription("MG & ORD => CTI");
/* 1666 */     ruleList.add(er);
/* 1667 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1671 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1674 */           setDescription("MG & ORD & SC => CPI");
/*      */           
/* 1676 */           addPreResult(1, 0, true);
/* 1677 */           addPreResult(11, 0, true);
/* 1678 */           addPostResult(15, true);
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1683 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1684 */             return false;
/*      */           }
/* 1686 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/*      */           
/* 1688 */           return pn.isMG();
/*      */         }
/*      */       };
/* 1691 */     er.setDescription("MG & ORD & SC => CPI");
/* 1692 */     ruleList.add(er);
/* 1693 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */     
/* 1697 */     er = new ExtendedRule()
/*      */       {
/*      */         public void initialize() {
/* 1700 */           setDescription("MG & CON & CTI => rank(IM) = |T| - 1");
/*      */           
/* 1702 */           addPreResult(10, 0, true);
/* 1703 */           addPreResult(15, 0, true);
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean checkSpecialProperties(Object object) {
/* 1708 */           if (!(object instanceof PlaceTransitionNet)) {
/* 1709 */             return false;
/*      */           }
/* 1711 */           PlaceTransitionNet pn = (PlaceTransitionNet)object;
/*      */           
/* 1713 */           addPostResult(27, pn.transitions() - 1);
/*      */           
/* 1715 */           return pn.isMG();
/*      */         }
/*      */       };
/* 1718 */     er.setDescription("MG & CON & CTI => rank(IM) = |T| - 1");
/* 1719 */     ruleList.add(er);
/* 1720 */     gr.addRule((Rule)er);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1725 */     ruleGroupList.add(gr);
/*      */   }
/*      */ 
/*      */   
/*      */   public static String[] getRuleDescriptions() {
/* 1730 */     return getRuleDescriptions(-1);
/*      */   }
/*      */   
/*      */   public static String[] getRuleDescriptions(int moreInfo) {
/* 1734 */     List<String> s = new ArrayList<>();
/* 1735 */     int count = 0;
/* 1736 */     for (RuleGroup r : ruleGroupList) {
/* 1737 */       if (r.size() > 1) {
/* 1738 */         s.add("** " + r.getDescription());
/* 1739 */         if (count == moreInfo) {
/* 1740 */           for (Rule rule : r.getRuleList()) {
/* 1741 */             s.add("++ " + rule.getDescription());
/*      */           }
/*      */         }
/* 1744 */         count++; continue;
/*      */       } 
/* 1746 */       s.add(r.getDescription());
/*      */     } 
/*      */ 
/*      */     
/* 1750 */     return s.<String>toArray(new String[0]);
/*      */   }
/*      */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/ResultManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */