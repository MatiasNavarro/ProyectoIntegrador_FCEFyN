/*     */ package charlie.pn;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.ds.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Transition
/*     */   extends PNNode
/*     */ {
/*     */   private static final long serialVersionUID = 941621062848246086L;
/*  23 */   static byte firstCall = 0;
/*     */   
/*     */   protected short id;
/*     */   
/*     */   protected short orgId;
/*     */   
/*     */   protected Marking pre;
/*     */   protected Marking post;
/*     */   protected Marking prePost;
/*     */   protected NodeList nl;
/*     */   public Vector<Integer> szk;
/*  34 */   protected Set<Transition> conflicts = new HashSet<>();
/*     */   
/*     */   public static PlaceTransitionNet pn;
/*     */   
/*  38 */   protected TransitionSet conflictSet = null;
/*     */   
/*  40 */   int multiplicity = 1;
/*     */ 
/*     */ 
/*     */   
/*  44 */   private Vector<Transition> orderedConflicts = new Vector<>();
/*     */   
/*  46 */   public String function = "";
/*     */   
/*     */   public Transition(String identifier, String name, short id) {
/*  49 */     super(name, identifier);
/*  50 */     this.id = id;
/*  51 */     this.orgId = id;
/*     */     
/*  53 */     this.szk = new Vector<>();
/*  54 */     this.pre = new SortedElementsDynamic(true);
/*  55 */     this.pre.name += " Transition " + id + " pre Places";
/*  56 */     this.post = new SortedElementsDynamic(true);
/*  57 */     this.post.name += " Transition " + id + " post places";
/*     */   }
/*     */   
/*     */   public Transition(String name, short id) {
/*  61 */     super(name);
/*  62 */     this.id = id;
/*  63 */     this.orgId = id;
/*     */     
/*  65 */     this.szk = new Vector<>();
/*  66 */     this.pre = new SortedElementsDynamic(true);
/*  67 */     this.pre.name += " Transition " + id + " pre Places";
/*  68 */     this.post = new SortedElementsDynamic(true);
/*  69 */     this.post.name += " Transition " + id + " post places";
/*     */   }
/*     */   
/*     */   public int getTop() {
/*  73 */     int ret = Integer.MIN_VALUE;
/*  74 */     for (int i = 0; i < this.prePost.size(); i++) {
/*  75 */       if (this.prePost.getToken(i) != 3) {
/*  76 */         return this.prePost.getId(i);
/*     */       }
/*     */     } 
/*  79 */     return ret;
/*     */   }
/*     */   
/*     */   public int getBot() {
/*  83 */     int ret = Integer.MIN_VALUE;
/*  84 */     for (int i = this.prePost.size() - 1; i >= 0; i--) {
/*  85 */       if (this.prePost.getToken(i) != 3) {
/*  86 */         return this.prePost.getId(i);
/*     */       }
/*     */     } 
/*  89 */     return ret;
/*     */   }
/*     */   
/*     */   public int firstInOrder() {
/*  93 */     int id = Integer.MAX_VALUE;
/*     */     
/*  95 */     NodeSet neighboors = postNodes().getPre();
/*  96 */     if (!neighboors.isEmpty()) {
/*  97 */       int nid = ((Integer)neighboors.iterator().next()).intValue();
/*  98 */       if (nid < id) {
/*  99 */         id = nid;
/*     */       }
/*     */     } 
/* 102 */     neighboors = postNodes().getPost();
/* 103 */     if (!neighboors.isEmpty()) {
/* 104 */       int nid = ((Integer)neighboors.iterator().next()).intValue();
/* 105 */       if (nid < id) {
/* 106 */         id = nid;
/*     */       }
/*     */     } 
/* 109 */     neighboors = preNodes().getPost();
/* 110 */     if (!neighboors.isEmpty()) {
/* 111 */       int nid = ((Integer)neighboors.iterator().next()).intValue();
/* 112 */       if (nid < id) {
/* 113 */         id = nid;
/*     */       }
/*     */     } 
/* 116 */     neighboors = preNodes().getPre();
/* 117 */     if (!neighboors.isEmpty()) {
/* 118 */       int nid = ((Integer)neighboors.iterator().next()).intValue();
/* 119 */       if (nid < id) {
/* 120 */         id = nid;
/*     */       }
/*     */     } 
/* 123 */     if (id == Integer.MAX_VALUE) {
/* 124 */       id = getId();
/*     */     }
/* 126 */     return id;
/*     */   }
/*     */   
/*     */   public void setPrePost(Marking pp) {
/* 130 */     this.prePost = pp;
/* 131 */     this.prePost.name += " marking prepost";
/*     */   }
/*     */   
/*     */   public Marking getPrePost() {
/* 135 */     return this.prePost;
/*     */   }
/*     */   
/*     */   public short getId() {
/* 139 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(short id) {
/* 143 */     this.id = id;
/*     */   }
/*     */   
/*     */   public short getOrgId() {
/* 147 */     return this.orgId;
/*     */   }
/*     */   
/*     */   public void setOrgId(short id) {
/* 151 */     this.orgId = id;
/*     */   }
/*     */   
/*     */   public void addPrePlace(int placeId, int weight) throws Exception {
/* 155 */     this.pre.addPlace(placeId, weight);
/*     */   }
/*     */   
/*     */   public void addPostPlace(int placeId, int weight) throws Exception {
/* 159 */     this.post.addPlace(placeId, weight);
/*     */   }
/*     */ 
/*     */   
/*     */   public void updatePrePost(Vector<Integer> translationTable) {
/*     */     try {
/* 165 */       this.pre = this.pre.translate(translationTable);
/* 166 */       this.post = this.post.translate(translationTable);
/* 167 */       this.prePost = this.prePost.translate(translationTable);
/* 168 */     } catch (Exception e) {
/* 169 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addConflict(Transition t) {
/* 174 */     this.conflicts.add(t);
/* 175 */     int i = 0;
/* 176 */     while (i < this.orderedConflicts.size() && t
/* 177 */       .getId() > ((Transition)this.orderedConflicts.get(i)).getId()) {
/* 178 */       i++;
/*     */     }
/* 180 */     this.orderedConflicts.add(i, t);
/*     */   }
/*     */   
/*     */   public void orderConflicts() {
/* 184 */     this.orderedConflicts.clear();
/* 185 */     for (Transition o : this.conflicts) {
/* 186 */       int i = 0;
/* 187 */       Transition t = o;
/* 188 */       while (i < this.orderedConflicts.size() && t.getId() > ((Transition)this.orderedConflicts.get(i)).getId()) {
/* 189 */         i++;
/*     */       }
/* 191 */       this.orderedConflicts.add(i, t);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Collection<Transition> getConflicts() {
/* 196 */     return this.conflicts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TransitionSet getConflictSet(int numberOfTransitions) {
/* 207 */     this.conflictSet = new TransitionSet(numberOfTransitions);
/*     */     
/* 209 */     Iterator<Transition> conflicts_it = this.conflicts.iterator();
/* 210 */     while (conflicts_it.hasNext()) {
/* 211 */       Transition t2 = conflicts_it.next();
/* 212 */       this.conflictSet.insert(t2.getId());
/*     */     } 
/*     */     
/* 215 */     return this.conflictSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector<Transition> getOrderedConflicts() {
/* 224 */     return this.orderedConflicts;
/*     */   }
/*     */   
/*     */   public void transformSortedPlaces() throws SafetyException, ExceedsByteException {
/* 228 */     this.post = this.post.toArray();
/* 229 */     this.pre = this.pre.toArray();
/*     */   }
/*     */   
/*     */   public void printConflicts() {
/* 233 */     for (Iterator<Transition> it = this.conflicts.iterator(); it.hasNext();) {
/* 234 */       Out.println(((Transition)it.next()).toString());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean canFire(State m) {
/* 239 */     return this.pre.isSubSet(m.getPlaceMarking());
/*     */   }
/*     */   
/*     */   public Collection<? extends Number> getScapeGoats(Marking m) {
/* 243 */     return this.pre.scapeGoats(m);
/*     */   }
/*     */   
/*     */   public int getFirstScapeGoat(Marking m) {
/* 247 */     return this.pre.fSG(m);
/*     */   }
/*     */   
/*     */   public Marking getPre() {
/* 251 */     return this.pre;
/*     */   }
/*     */   
/*     */   public Marking getPost() {
/* 255 */     return this.post;
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeSet preNodes() {
/* 260 */     BitSet bs = new BitSet(LookUpTable.places());
/* 261 */     for (int i = 0; i < this.pre.size(); i++) {
/* 262 */       bs.insert(UnsignedByte.unsign(this.pre.getId(i)));
/*     */     }
/* 264 */     return new PlaceSet(bs);
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeSet postNodes() {
/* 269 */     BitSet bs = new BitSet(LookUpTable.places());
/* 270 */     for (int i = 0; i < this.post.size(); i++) {
/* 271 */       bs.insert(UnsignedByte.unsign(this.post.getId(i)));
/*     */     }
/* 273 */     return new PlaceSet(bs);
/*     */   }
/*     */   
/*     */   public boolean firesInScc(int sccNumber) {
/* 277 */     return this.szk.contains(new Integer(sccNumber));
/*     */   }
/*     */   
/*     */   public boolean addSZK(int s) {
/* 281 */     if (this.szk.contains(Integer.valueOf(s))) {
/* 282 */       return false;
/*     */     }
/* 284 */     this.szk.add(Integer.valueOf(s));
/* 285 */     return true;
/*     */   }
/*     */   
/*     */   public Vector<Integer> szk() {
/* 289 */     return this.szk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public State fire(State state) throws SafetyException, ExceedsByteException {
/* 305 */     this.multiplicity = 1;
/* 306 */     return fire(state, true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public State simfire(State state) throws SafetyException, ExceedsByteException {
/* 311 */     this.multiplicity = this.pre.calculateAutoFiring(state.getPlaceMarking());
/*     */ 
/*     */     
/* 314 */     return fire(state, true, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public State actualfire(State state) throws SafetyException, ExceedsByteException {
/* 319 */     return fire(state, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public State fire(State state, boolean considerPrePlaces, boolean considerPostPlaces) throws SafetyException, ExceedsByteException {
/*     */     State newState;
/* 346 */     Marking tempPost = null;
/* 347 */     Marking tempPre = null;
/* 348 */     boolean safeMode = SortedElementsFactory.safeMode();
/* 349 */     boolean byteMode = SortedElementsFactory.byteMode();
/*     */     
/* 351 */     if (firstCall > 0) {
/* 352 */       SortedElementsFactory.safeMode(true);
/* 353 */       if (!(state instanceof SortedElementsBitSet)) {
/* 354 */         SortedElementsFactory.safeMode(false);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 359 */     if (!considerPrePlaces) {
/*     */       try {
/* 361 */         tempPre = this.pre.copy();
/* 362 */       } catch (SafetyException e) {
/*     */         
/* 364 */         SortedElementsFactory.safeMode(false);
/* 365 */         tempPre = this.pre.copy();
/* 366 */         SortedElementsFactory.safeMode(true);
/* 367 */       } catch (ExceedsByteException e) {
/*     */         
/* 369 */         SortedElementsFactory.byteMode(false);
/* 370 */         tempPre = this.pre.copy();
/* 371 */         SortedElementsFactory.byteMode(true);
/*     */       } 
/* 373 */       this.pre = SortedElementsFactory.getSortedPlaces(0);
/* 374 */       this.pre.name = " transition.fire pre places ";
/*     */     } 
/* 376 */     if (!considerPostPlaces) {
/*     */       try {
/* 378 */         tempPost = this.post.copy();
/* 379 */       } catch (SafetyException e) {
/*     */         
/* 381 */         SortedElementsFactory.safeMode(false);
/* 382 */         tempPost = this.post.copy();
/* 383 */         SortedElementsFactory.safeMode(true);
/* 384 */       } catch (ExceedsByteException e) {
/*     */         
/* 386 */         SortedElementsFactory.byteMode(false);
/* 387 */         tempPost = this.post.copy();
/* 388 */         SortedElementsFactory.byteMode(true);
/*     */       } 
/* 390 */       this.post = SortedElementsFactory.getSortedPlaces(0);
/* 391 */       this.post.name = " transition.fire post places ";
/*     */     } 
/*     */     
/* 394 */     SortedElementsFactory.safeMode(safeMode);
/* 395 */     SortedElementsFactory.byteMode(byteMode);
/*     */     
/* 397 */     firstCall = (byte)(firstCall + 1);
/* 398 */     if (firstCall > 0) {
/* 399 */       SortedElementsFactory.safeMode(true);
/* 400 */       if (!(state instanceof SortedElementsBitSet)) {
/* 401 */         SortedElementsFactory.safeMode(false);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 406 */     SortedElementsFactory.byteMode(byteMode);
/*     */     
/*     */     try {
/* 409 */       if (state != null && SortedElementsFactory.safeMode() && state instanceof SortedElementsBitSet && this.pre instanceof SortedElementsBitSet && this.post instanceof SortedElementsBitSet) {
/*     */ 
/*     */ 
/*     */         
/* 413 */         State state1 = ((SortedElementsBitSet)state).getNewState((SortedElementsBitSet)this.pre, (SortedElementsBitSet)this.post);
/* 414 */         if (tempPost != null) {
/* 415 */           this.post = tempPost;
/*     */         }
/* 417 */         if (tempPre != null) {
/* 418 */           this.pre = tempPre;
/*     */         }
/* 420 */         if (state1 == null) {
/* 421 */           DebugCounter.inc("Transition fire :368 returns null  as new State !");
/*     */         }
/* 423 */         return state1;
/*     */       } 
/*     */       
/* 426 */       if (state == null) {
/* 427 */         DebugCounter.inc("Transition.fire(State,b,b):375 state==null -> null");
/* 428 */         return null;
/*     */       } 
/* 430 */       int p = 0;
/* 431 */       p = this.pre.isSubSet2(state.getPlaceMarking());
/*     */       
/* 433 */       if (p < 0) {
/*     */         
/* 435 */         DebugCounter.inc("Transition.fire(State,b,b):382 pre.isSubSet2(state.getPlaceMarking() -> null");
/* 436 */         return null;
/*     */       } 
/* 438 */       newState = SortedElementsFactory.getSortedPlaces(p + this.post.size());
/* 439 */       newState.name += "transitions.fire newState";
/* 440 */       int i = 0;
/* 441 */       int ipre = 0;
/* 442 */       int ipost = 0;
/* 443 */       Weight currentPre = this.pre.get(ipre);
/* 444 */       Weight currentPost = this.post.get(ipost);
/*     */       
/* 446 */       while (ipre < this.pre.size()) {
/* 447 */         int curId = currentPre.getId();
/*     */ 
/*     */         
/* 450 */         while (i < state.getPlaceMarking().size() && state
/* 451 */           .getPlaceMarking().get(i).getId() != curId) {
/* 452 */           Weight place = state.getPlaceMarking().get(i);
/* 453 */           newState.addPlace(place.getId(), place.getToken());
/*     */ 
/*     */           
/* 456 */           while (ipost < this.post.size() && currentPost.getId() < curId) {
/* 457 */             newState.addPlace(currentPost.getId(), this.multiplicity * currentPost
/* 458 */                 .getToken());
/* 459 */             currentPost = this.post.get(++ipost);
/*     */           } 
/* 461 */           i++;
/*     */         } 
/* 463 */         if (i == state.getPlaceMarking().size() || currentPre
/* 464 */           .less(state.getPlaceMarking().get(i)) < 0) {
/* 465 */           return null;
/*     */         }
/*     */ 
/*     */         
/* 469 */         if (state.getPlaceMarking().get(i).getToken() == Integer.MAX_VALUE) {
/* 470 */           newState.addPlace(curId, 2147483647);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 475 */           int token = state.getPlaceMarking().get(i).getToken() - this.multiplicity * currentPre.getToken();
/* 476 */           if (token > 0) {
/* 477 */             newState.addPlace(curId, token);
/*     */           }
/*     */         } 
/* 480 */         currentPre = this.pre.get(++ipre);
/* 481 */         i++;
/*     */       } 
/*     */       
/* 484 */       while (i < state.getPlaceMarking().size()) {
/* 485 */         Weight place = state.getPlaceMarking().get(i);
/* 486 */         newState.addPlace(place.getId(), place.getToken());
/*     */         
/* 488 */         while (ipost < this.post.size() && currentPost
/* 489 */           .getId() < place.getId()) {
/* 490 */           newState.addPlace(currentPost.getId(), this.multiplicity * currentPost
/* 491 */               .getToken());
/* 492 */           currentPost = this.post.get(++ipost);
/*     */         } 
/* 494 */         i++;
/*     */       } 
/*     */       
/* 497 */       while (ipost < this.post.size()) {
/* 498 */         newState.addPlace(currentPost.getId(), this.multiplicity * currentPost
/* 499 */             .getToken());
/* 500 */         currentPost = this.post.get(++ipost);
/*     */       } 
/* 502 */     } catch (SafetyException e) {
/*     */ 
/*     */       
/* 505 */       SortedElementsFactory.safeMode(false);
/* 506 */       newState = fire(state, considerPrePlaces, considerPostPlaces);
/* 507 */       SortedElementsFactory.safeMode(true);
/* 508 */     } catch (ExceedsByteException e) {
/*     */ 
/*     */       
/* 511 */       SortedElementsFactory.byteMode(false);
/* 512 */       newState = fire(state, considerPrePlaces, considerPostPlaces);
/* 513 */       SortedElementsFactory.byteMode(true);
/*     */     } 
/* 515 */     firstCall = 0;
/* 516 */     if (tempPost != null) {
/* 517 */       this.post = tempPost;
/*     */     }
/* 519 */     if (tempPre != null) {
/* 520 */       this.pre = tempPre;
/*     */     }
/* 522 */     if (newState == null)
/*     */     {
/* 524 */       DebugCounter.inc("Transition fire returns null  as new State !");
/*     */     }
/* 526 */     return newState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public State consume(State state) throws SafetyException, ExceedsByteException {
/* 533 */     State retState = fire(state, true, false);
/* 534 */     return retState;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 539 */     return "transition: " + getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 544 */     int prime = 31;
/* 545 */     int result = super.hashCode();
/* 546 */     result = 31 * result + this.id;
/* 547 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 552 */     if (this == obj) {
/* 553 */       return true;
/*     */     }
/* 555 */     if (!super.equals(obj)) {
/* 556 */       return false;
/*     */     }
/* 558 */     if (getClass() != obj.getClass()) {
/* 559 */       return false;
/*     */     }
/* 561 */     Transition other = (Transition)obj;
/* 562 */     if (this.id != other.id) {
/* 563 */       return false;
/*     */     }
/* 565 */     return true;
/*     */   }
/*     */   
/*     */   public String toExtendedString() {
/* 569 */     StringBuffer sb = new StringBuffer();
/* 570 */     sb.append("\t|");
/* 571 */     sb.append(getOrgId());
/* 572 */     sb.append(".");
/* 573 */     sb.append(getName());
/* 574 */     sb.append("\t:1");
/* 575 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Transition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */