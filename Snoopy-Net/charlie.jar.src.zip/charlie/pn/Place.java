/*     */ package charlie.pn;
/*     */ 
/*     */ import charlie.ds.BitSet;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Place
/*     */   extends PNNode
/*     */ {
/*     */   private static final long serialVersionUID = 443278462984678914L;
/*  14 */   private int boundedness = Integer.MAX_VALUE;
/*     */   
/*     */   private BitSet preBit;
/*     */   
/*     */   private BitSet postBit;
/*  19 */   private int Vminus = 0;
/*  20 */   private int Vplus = 0;
/*  21 */   private int VminusNBM = 0;
/*     */   
/*     */   private int token;
/*     */   private int id;
/*     */   private int orgId;
/*     */   private int capacity;
/*     */   
/*     */   public Place(String identifier, String name, int token, int id, int orgId, int capacity) {
/*  29 */     super(name, identifier);
/*  30 */     this.token = token;
/*  31 */     this.id = id;
/*  32 */     this.orgId = orgId;
/*     */ 
/*     */     
/*  35 */     this.capacity = capacity;
/*  36 */     this.preBit = new BitSet(LookUpTable.transitions());
/*  37 */     this.postBit = new BitSet(LookUpTable.transitions());
/*     */   }
/*     */   
/*     */   public int getToken() {
/*  41 */     return this.token;
/*     */   }
/*     */   
/*     */   public int getBoundedness() {
/*  45 */     return this.boundedness;
/*     */   }
/*     */   
/*     */   public void setBoundedness(int b) {
/*  49 */     this.boundedness = b;
/*     */   }
/*     */   
/*     */   public int getId() {
/*  53 */     return this.id;
/*     */   }
/*     */   
/*     */   public int getOrgId() {
/*  57 */     return this.orgId;
/*     */   }
/*     */   
/*     */   public void setId(int id) {
/*  61 */     this.id = id;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updatePrePost(Vector<Integer> translationTable) {
/*  66 */     this.preBit = this.preBit.translate(translationTable);
/*  67 */     this.postBit = this.postBit.translate(translationTable);
/*     */   }
/*     */   
/*     */   public BitSet getPreBit() {
/*  71 */     return this.preBit;
/*     */   }
/*     */   
/*     */   public BitSet getPostBit() {
/*  75 */     return this.postBit;
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeSet preNodes() {
/*  80 */     return new TransitionSet(this.preBit);
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeSet postNodes() {
/*  85 */     return new TransitionSet(this.postBit);
/*     */   }
/*     */   
/*     */   public String toExtendedString() {
/*  89 */     StringBuffer sb = new StringBuffer();
/*     */     
/*  91 */     sb.append("\t|");
/*  92 */     sb.append(getOrgId());
/*  93 */     sb.append(".");
/*  94 */     sb.append(getName());
/*  95 */     sb.append("\t:1");
/*     */     
/*  97 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void addPre(Transition t) {
/* 101 */     this.preBit.insert(t.getId());
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPost(Transition t) {
/* 106 */     this.postBit.insert(t.getId());
/*     */   }
/*     */   
/*     */   public void addPre(Transition t, int weight) {
/* 110 */     if (this.Vplus == 0 || weight < this.Vplus) {
/* 111 */       this.Vplus = weight;
/*     */     }
/* 113 */     this.preBit.insert(t.getId());
/*     */   }
/*     */   
/*     */   public void addPost(Transition t, int weight) {
/* 117 */     if (this.VminusNBM == 0 || weight > this.VminusNBM) {
/* 118 */       this.VminusNBM = weight;
/*     */     }
/* 120 */     if (this.Vminus == 0 || weight < this.Vminus) {
/* 121 */       this.Vminus = weight;
/*     */     }
/* 123 */     this.postBit.insert(t.getId());
/*     */   }
/*     */   
/*     */   public boolean hasNBM() {
/* 127 */     return (this.Vplus >= this.VminusNBM);
/*     */   }
/*     */   
/*     */   public int vminus() {
/* 131 */     return this.Vminus;
/*     */   }
/*     */   
/*     */   public int vplus() {
/* 135 */     return this.Vplus;
/*     */   }
/*     */   
/*     */   public int vminusNBM() {
/* 139 */     return this.VminusNBM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setToken(int token) {
/* 147 */     this.token = token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCapacity() {
/* 154 */     return this.capacity;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 159 */     String res = String.format("place: %s, id: %s, orgId: %s", new Object[] { getName(), Integer.valueOf(getId()), Integer.valueOf(getOrgId()) });
/*     */     
/* 161 */     return res;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Place.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */