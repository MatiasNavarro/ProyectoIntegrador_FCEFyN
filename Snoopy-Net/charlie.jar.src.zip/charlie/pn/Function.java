/*    */ package charlie.pn;
/*    */ 
/*    */ import charlie.util.arithmetic.AbstractExpr;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ public class Function
/*    */ {
/*    */   protected AbstractExpr body;
/*    */   protected String name;
/*    */   protected ArrayList<String> param;
/*    */   
/*    */   public Function(String name_p, AbstractExpr body_p) {
/* 14 */     this.body = body_p;
/* 15 */     this.name = name_p;
/*    */   }
/*    */   
/*    */   public Function(String name_p, AbstractExpr body_p, ArrayList<String> param_p) {
/* 19 */     this.body = body_p;
/* 20 */     this.name = name_p;
/* 21 */     this.param = param_p;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 25 */     return this.name;
/*    */   }
/*    */   
/*    */   public AbstractExpr getBody() {
/* 29 */     return this.body;
/*    */   }
/*    */   
/*    */   public ArrayList<String> getParam() {
/* 33 */     return this.param;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 37 */     StringBuilder sb = new StringBuilder();
/* 38 */     sb.append(this.name);
/* 39 */     sb.append('(');
/* 40 */     boolean first = true;
/*    */     
/* 42 */     for (String p : this.param) {
/*    */       
/* 44 */       if (!first) {
/* 45 */         sb.append(',');
/*    */       }
/* 47 */       sb.append(p);
/* 48 */       first = false;
/*    */     } 
/* 50 */     sb.append(")=");
/* 51 */     sb.append(this.body);
/* 52 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Function.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */