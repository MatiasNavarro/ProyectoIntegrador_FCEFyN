/*    */ package charlie.pn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceedsByteException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 10 */   private static int instances = 0;
/*    */   
/*    */   public ExceedsByteException() {
/* 13 */     instances++;
/*    */   }
/*    */   
/*    */   public static void reset() {
/* 17 */     instances = 0;
/*    */   }
/*    */   
/*    */   public static int instances() {
/* 21 */     return instances;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/ExceedsByteException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */