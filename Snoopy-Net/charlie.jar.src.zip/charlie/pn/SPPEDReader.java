/*     */ package charlie.pn;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPPEDReader
/*     */   extends PetriNetReader
/*     */ {
/*  15 */   static int nc = -1;
/*  16 */   static int PLACE = 0;
/*  17 */   static int TRANSITION = 1;
/*  18 */   static int IGNORE = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean evalVersion() {
/*  26 */     String version = "";
/*     */     try {
/*  28 */       version = System.getProperty("java.version");
/*  29 */       System.out.println(version);
/*  30 */       if (version.startsWith("1.6")) {
/*  31 */         return true;
/*     */       }
/*  33 */     } catch (Exception exc) {
/*  34 */       exc.printStackTrace();
/*  35 */       return false;
/*     */     } 
/*  37 */     return true;
/*     */   }
/*     */   
/*     */   public SPPEDReader() {
/*  41 */     if (evalVersion()) {
/*  42 */       PetriNetReaderFactory.registerReader(".spped", this);
/*  43 */       PetriNetReaderFactory.registerReader(".spept", this);
/*  44 */       PetriNetReaderFactory.registerReader(".spstochpn", this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void eval(String val) {
/*  51 */     if (val.equals("Place")) {
/*  52 */       nc = PLACE;
/*  53 */     } else if (val.equals("Transition")) {
/*  54 */       nc = TRANSITION;
/*  55 */     } else if (val.equals("Edge")) {
/*  56 */       nc = PlaceTransitionNet.EDGE;
/*  57 */     } else if (val.equals("Read Edge")) {
/*  58 */       nc = PlaceTransitionNet.READ_EDGE;
/*  59 */     } else if (val.equals("Inhibitor Edge")) {
/*  60 */       nc = PlaceTransitionNet.INHIBITOR_EDGE;
/*  61 */     } else if (val.equals("Equal Edge")) {
/*  62 */       nc = PlaceTransitionNet.EQUAL_EDGE;
/*  63 */     } else if (val.equals("Reset Edge")) {
/*  64 */       nc = PlaceTransitionNet.RESET_EDGE;
/*     */     } else {
/*  66 */       nc = IGNORE;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public SPPEDReader(String filename, PlaceTransitionNet pn, ConstantInterface cI) throws Exception {
/*  72 */     this.file = filename;
/*     */     
/*  74 */     this.pn = pn;
/*  75 */     if (pn.getName().endsWith(".spped")) {
/*  76 */       pn.setName(pn.getName().substring(0, pn.getName().length() - 6));
/*  77 */     } else if (pn.getName().endsWith(".spept")) {
/*  78 */       pn.setName(pn.getName().substring(0, pn.getName().length() - 6));
/*     */     } 
/*  80 */     this.pn.TIMED_NET_TYPE = 4;
/*  81 */     this.pn.setTimedNet(false);
/*  82 */     initReader(cI);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int countPlaces() {
/*  99 */     UnsignedByte.setMin(0);
/* 100 */     int places = countNodesOfType("Place");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     return places;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int countTransitions() {
/* 114 */     return countNodesOfType("Transition");
/*     */   }
/*     */ 
/*     */   
/*     */   public void readNet() throws Exception {
/* 119 */     read();
/* 120 */     this.pn.TIMED_NET_TYPE = 4;
/* 121 */     this.pn.setTimedNet(false);
/* 122 */     initNet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int countNodesOfType(String type) {
/* 128 */     int counter = 0;
/*     */     try {
/* 130 */       InputStream in = getInputStream(this.file);
/* 131 */       XMLInputFactory factory = XMLInputFactory.newInstance();
/* 132 */       XMLStreamReader parser = factory.createXMLStreamReader(in);
/*     */       
/* 134 */       StringBuilder spacer = new StringBuilder();
/* 135 */       while (parser.hasNext()) {
/*     */         String ln;
/* 137 */         int i, event = parser.next();
/*     */         
/* 139 */         switch (event) {
/*     */           case 7:
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 8:
/* 146 */             parser.close();
/*     */             break;
/*     */           
/*     */           case 13:
/*     */             break;
/*     */           case 1:
/* 152 */             spacer.append("  ");
/*     */ 
/*     */             
/* 155 */             ln = parser.getLocalName();
/* 156 */             if (ln.equals("node")) {
/* 157 */               if ((nc == PLACE && type.equals("Place")) || (nc == TRANSITION && type
/* 158 */                 .equals("Transition"))) {
/* 159 */                 counter++;
/*     */               }
/*     */               break;
/*     */             } 
/* 163 */             for (i = 0; i < parser.getAttributeCount(); i++) {
/* 164 */               parser.getAttributeLocalName(i);
/* 165 */               String av = parser.getAttributeValue(i);
/* 166 */               if (ln.equals("nodeclass")) {
/* 167 */                 eval(av);
/*     */               }
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 178 */     } catch (Exception e) {
/* 179 */       e.printStackTrace();
/*     */     } 
/* 181 */     return counter;
/*     */   }
/*     */   
/*     */   public void read() {
/*     */     try {
/* 186 */       this.placeCounter = 0;
/*     */       
/* 188 */       InputStream in = getInputStream(this.file);
/* 189 */       XMLInputFactory factory = XMLInputFactory.newInstance();
/* 190 */       XMLStreamReader parser = factory.createXMLStreamReader(in);
/*     */       
/* 192 */       StringBuilder spacer = new StringBuilder();
/* 193 */       while (parser.hasNext()) {
/*     */         String ln;
/* 195 */         int i, event = parser.next();
/*     */         
/* 197 */         switch (event) {
/*     */           case 7:
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 8:
/* 204 */             parser.close();
/*     */             break;
/*     */           case 13:
/*     */             break;
/*     */           case 1:
/* 209 */             spacer.append("  ");
/* 210 */             ln = parser.getLocalName();
/* 211 */             if (ln.equals("node") || ln.equals("edge")) {
/* 212 */               readNode(parser);
/*     */               break;
/*     */             } 
/* 215 */             for (i = 0; i < parser.getAttributeCount(); i++) {
/* 216 */               parser.getAttributeLocalName(i);
/* 217 */               String av = parser.getAttributeValue(i);
/* 218 */               if (ln.equals("nodeclass") || ln.equals("edgeclass")) {
/* 219 */                 eval(av);
/*     */               }
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 232 */     } catch (Exception e) {
/* 233 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void readNode(XMLStreamReader parser) {
/* 240 */     String id = "";
/* 241 */     int net = -1;
/* 242 */     String source = "";
/* 243 */     String target = "";
/* 244 */     for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 245 */       String lv = parser.getAttributeLocalName(i);
/* 246 */       String av = parser.getAttributeValue(i);
/* 247 */       if (lv.equals("net")) {
/* 248 */         net = Integer.parseInt(av);
/* 249 */       } else if (lv.equals("id")) {
/* 250 */         id = av;
/* 251 */       } else if (lv.equals("source")) {
/* 252 */         source = av;
/* 253 */       } else if (lv.equals("target")) {
/* 254 */         target = av;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 259 */     if (nc == PLACE) {
/* 260 */       PNNode n = readPlace(parser, id);
/*     */       
/* 262 */       Place p = (Place)n;
/*     */       
/* 264 */       this.pn.allNodes().put(id, n);
/* 265 */       this.pn.identifier().put(n, id);
/* 266 */       this.pn.addPlace((Place)n);
/* 267 */       if (p.getToken() > 0) {
/*     */ 
/*     */         
/* 270 */         this.initialMarking.add(p);
/* 271 */         this.initialMarking.add(new Integer(p.getToken()));
/*     */       } 
/*     */       
/* 274 */       this.pn.structure.addVertex(n.getName(), n);
/* 275 */     } else if (nc == TRANSITION) {
/* 276 */       PNNode n = readTransition(parser, id);
/* 277 */       this.pn.allNodes().put(id, n);
/* 278 */       this.pn.identifier().put(n, id);
/* 279 */       this.pn.addTransition((Transition)n);
/* 280 */       this.pn.structure.addVertex(n.getName(), n);
/* 281 */     } else if (nc == PlaceTransitionNet.EDGE) {
/* 282 */       readEdge(parser, source, target, PlaceTransitionNet.EDGE);
/* 283 */     } else if (nc == PlaceTransitionNet.INHIBITOR_EDGE) {
/* 284 */       readEdge(parser, source, target, PlaceTransitionNet.INHIBITOR_EDGE);
/* 285 */     } else if (nc == PlaceTransitionNet.READ_EDGE) {
/* 286 */       readEdge(parser, source, target, PlaceTransitionNet.READ_EDGE);
/* 287 */     } else if (nc == PlaceTransitionNet.EQUAL_EDGE) {
/* 288 */       readEdge(parser, source, target, PlaceTransitionNet.EQUAL_EDGE);
/* 289 */     } else if (nc == PlaceTransitionNet.RESET_EDGE) {
/* 290 */       readEdge(parser, source, target, PlaceTransitionNet.RESET_EDGE);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Place readPlace(XMLStreamReader parser, String identifier) {
/*     */     try {
/* 297 */       String name = "";
/* 298 */       String init = "";
/* 299 */       String id = "";
/* 300 */       while (parser.hasNext()) {
/* 301 */         String ln; int event = parser.next();
/*     */         
/* 303 */         switch (event) {
/*     */           case 2:
/* 305 */             if (parser.getLocalName().equals("node")) {
/* 306 */               if (name.equals("")) {
/* 307 */                 name = "P_" + id;
/*     */               }
/* 309 */               Place ret = new Place(identifier, name, Byte.parseByte(init), this.currentPlaceId++, this.placeCounter++, 0);
/*     */               
/* 311 */               return ret;
/*     */             } 
/*     */           
/*     */           case 1:
/* 315 */             ln = parser.getLocalName();
/* 316 */             if (ln.equals("attribute")) {
/* 317 */               for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 318 */                 parser.getAttributeLocalName(i);
/* 319 */                 String av = parser.getAttributeValue(i);
/* 320 */                 if (av.equals("Name")) {
/* 321 */                   name = replaceSpace(readAttribute(parser)); break;
/*     */                 } 
/* 323 */                 if (av.equals("ID")) {
/* 324 */                   id = readAttribute(parser); break;
/*     */                 } 
/* 326 */                 if (av.equals("Marking")) {
/* 327 */                   init = readAttribute(parser);
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 335 */     } catch (Exception e) {
/* 336 */       e.printStackTrace();
/*     */     } 
/* 338 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Transition readTransition(XMLStreamReader parser, String identifier) {
/*     */     try {
/* 344 */       String name = "";
/* 345 */       String id = "";
/* 346 */       while (parser.hasNext()) {
/* 347 */         String ln; int event = parser.next();
/*     */         
/* 349 */         switch (event) {
/*     */           case 2:
/* 351 */             if (parser.getLocalName().equals("node")) {
/* 352 */               if (name.equals("")) {
/* 353 */                 name = "T_" + id;
/*     */               }
/* 355 */               this.currentTransId = (short)(this.currentTransId + 1); Transition ret = new Transition(identifier, name, this.currentTransId);
/* 356 */               return ret;
/*     */             } 
/*     */           
/*     */           case 1:
/* 360 */             ln = parser.getLocalName();
/* 361 */             if (ln.equals("attribute")) {
/* 362 */               for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 363 */                 parser.getAttributeLocalName(i);
/* 364 */                 String av = parser.getAttributeValue(i);
/* 365 */                 if (av.equals("Name")) {
/* 366 */                   name = replaceSpace(readAttribute(parser)); break;
/*     */                 } 
/* 368 */                 if (av.equals("ID")) {
/* 369 */                   id = readAttribute(parser);
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 377 */     } catch (Exception e) {
/* 378 */       e.printStackTrace();
/*     */     } 
/* 380 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readEdge(XMLStreamReader parser, String source, String target, int type) {
/*     */     try {
/* 386 */       String weight = "";
/* 387 */       while (parser.hasNext()) {
/* 388 */         String ln; int event = parser.next();
/*     */         
/* 390 */         switch (event) {
/*     */           case 2:
/* 392 */             if (parser.getLocalName().equals("edge")) {
/* 393 */               if (type == PlaceTransitionNet.RESET_EDGE) {
/* 394 */                 evalEdge(this.pn.lookUp(source), this.pn.lookUp(target), (byte)1, type);
/*     */               } else {
/* 396 */                 evalEdge(this.pn.lookUp(source), this.pn.lookUp(target), Byte.parseByte(weight), type);
/*     */               } 
/*     */               return;
/*     */             } 
/*     */           
/*     */           case 1:
/* 402 */             ln = parser.getLocalName();
/* 403 */             if (ln.equals("attribute")) {
/* 404 */               for (int i = 0; i < parser.getAttributeCount(); i++) {
/* 405 */                 parser.getAttributeLocalName(i);
/* 406 */                 String av = parser.getAttributeValue(i);
/* 407 */                 if (av.equals("Multiplicity")) {
/* 408 */                   weight = readAttribute(parser);
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 416 */     } catch (Exception e) {
/* 417 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String readAttribute(XMLStreamReader parser) {
/* 423 */     String ret = "";
/*     */     try {
/* 425 */       while (parser.hasNext()) {
/* 426 */         int event = parser.next();
/* 427 */         switch (event) {
/*     */           case 2:
/* 429 */             if (parser.getLocalName().equals("attribute")) {
/* 430 */               return ret;
/*     */             }
/*     */           
/*     */           case 4:
/* 434 */             if (!parser.isWhiteSpace()) {
/* 435 */               ret = parser.getText();
/*     */             }
/*     */         } 
/*     */       
/*     */       } 
/* 440 */     } catch (Exception e) {
/* 441 */       e.printStackTrace();
/*     */     } 
/* 443 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   private void evalEdge(PNNode from, PNNode to, byte weight, int type) {
/* 448 */     this.pn.addEdge(from, to, weight, type);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SPPEDReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */