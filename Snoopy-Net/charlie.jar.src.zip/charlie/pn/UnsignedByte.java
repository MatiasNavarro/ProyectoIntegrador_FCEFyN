/*    */ package charlie.pn;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsignedByte
/*    */ {
/*  7 */   public static int min = -1;
/*  8 */   public static byte zero = -2;
/*    */   
/*    */   public static int unsign(int b) {
/* 11 */     return b - min;
/*    */   }
/*    */   
/*    */   public static int sign(int b) {
/* 15 */     return b + min;
/*    */   }
/*    */   
/*    */   public static byte min() {
/* 19 */     return (byte)min;
/*    */   }
/*    */   
/*    */   public static byte zero() {
/* 23 */     return zero;
/*    */   }
/*    */   
/*    */   public static void setMin(int m) {
/* 27 */     min = m;
/* 28 */     zero = (byte)(min - 1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void init(byte[] a) {
/* 34 */     if (SortedElementsFactory.safeMode()) {
/* 35 */       for (int j = 0; j < a.length; j++) {
/* 36 */         a[j] = zero();
/*    */       }
/*    */       
/*    */       return;
/*    */     } 
/* 41 */     for (int i = 0; i < a.length; i++) {
/* 42 */       if (i % 2 == 0) {
/* 43 */         a[i] = min();
/*    */       } else {
/* 45 */         a[i] = 0;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void init(byte[] a, int size) {
/* 52 */     for (int i = 0; i < size * 2; i++) {
/* 53 */       if (i % 2 == 0) {
/* 54 */         a[i] = min();
/*    */       } else {
/* 56 */         a[i] = 0;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void init(short[] a) {
/* 63 */     if (SortedElementsFactory.safeMode()) {
/* 64 */       for (int j = 0; j < a.length; j++) {
/* 65 */         a[j] = (short)min();
/*    */       }
/*    */       return;
/*    */     } 
/* 69 */     for (int i = 0; i < a.length; i++) {
/* 70 */       if (i % 2 == 0) {
/* 71 */         a[i] = (short)min();
/*    */       } else {
/* 73 */         a[i] = 0;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void init(short[] a, int size) {
/* 80 */     for (int i = 0; i < size * 2; i++) {
/* 81 */       if (i % 2 == 0) {
/* 82 */         a[i] = (short)min();
/*    */       } else {
/* 84 */         a[i] = 0;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/UnsignedByte.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */