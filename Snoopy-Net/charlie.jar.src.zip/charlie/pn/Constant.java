/*    */ package charlie.pn;public abstract class Constant {
/*    */   protected String value;
/*    */   protected String name;
/*    */   
/*    */   enum Type {
/*  6 */     INT, DOUBLE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Constant(String name_p, String value_p) {
/* 13 */     this.value = value_p;
/* 14 */     this.name = name_p;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 22 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setValue(String value_p) {
/* 26 */     this.value = value_p;
/*    */   }
/*    */   
/*    */   public boolean hasValue() {
/* 30 */     return (this.value != null);
/*    */   }
/*    */   
/*    */   public abstract Type getType();
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Constant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */