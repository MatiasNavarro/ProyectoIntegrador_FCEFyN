/*    */ package charlie.pn;
/*    */ 
/*    */ import charlie.ds.BitSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class OrderTransitionsForBDD
/*    */   implements OrderingFunction {
/*    */   Vector translationTable;
/*    */   PlaceTransitionNet pn;
/*    */   
/*    */   public OrderTransitionsForBDD(PlaceTransitionNet pn) {
/* 13 */     this.pn = pn;
/*    */     
/* 15 */     int start = 0;
/*    */     
/* 17 */     Vector<Integer> v = pn.dfsLin(false, 0);
/* 18 */     System.out.println("v: " + v);
/* 19 */     this.translationTable = new Vector(pn.transitions());
/* 20 */     BitSet consumed = new BitSet(pn.transitions());
/* 21 */     Marking m = pn.getM0Places();
/* 22 */     PlaceSet preConditions = new PlaceSet(pn.places());
/* 23 */     for (int i = 0; i < m.size(); i++) {
/* 24 */       preConditions.insert(UnsignedByte.sign(m.getId(i)));
/*    */     }
/* 26 */     while (consumed.size() < pn.transitions()) {
/* 27 */       for (Iterator<Transition> it = pn.getTransitions().iterator(); it.hasNext(); ) {
/* 28 */         Transition t = it.next();
/* 29 */         if (!consumed.member(t.getId()) && t.preNodes().subSet(preConditions)) {
/* 30 */           this.translationTable.add(new Integer(t.getId()));
/* 31 */           preConditions.union(t.postNodes());
/* 32 */           consumed.insert(t.getId());
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Vector getTranslationTable() {
/* 45 */     return this.translationTable;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/OrderTransitionsForBDD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */