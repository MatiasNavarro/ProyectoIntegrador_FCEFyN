/*    */ package charlie.pn;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PNNode
/*    */   extends Vertex
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 7811456922587632343L;
/*    */   private String identifier;
/*    */   private String name;
/*    */   
/*    */   public PNNode(String name) {
/* 18 */     super(name);
/* 19 */     this.name = name;
/*    */   }
/*    */   
/*    */   public PNNode(String name, String identifier) {
/* 23 */     super(identifier);
/* 24 */     this.name = name;
/* 25 */     this.identifier = identifier;
/*    */   }
/*    */   
/*    */   public abstract void updatePrePost(Vector<Integer> paramVector);
/*    */   
/*    */   public String getName() {
/* 31 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getIdentifier() {
/* 36 */     return this.identifier;
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract NodeSet preNodes();
/*    */   
/*    */   public abstract NodeSet postNodes();
/*    */   
/*    */   public String toString() {
/* 45 */     String res = "name: " + getName();
/* 46 */     return res;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 51 */     int prime = 31;
/* 52 */     int result = super.hashCode();
/* 53 */     result = 31 * result + ((this.identifier == null) ? 0 : this.identifier.hashCode());
/* 54 */     result = 31 * result + ((this.name == null) ? 0 : this.name.hashCode());
/* 55 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 60 */     if (this == obj) {
/* 61 */       return true;
/*    */     }
/* 63 */     if (!super.equals(obj)) {
/* 64 */       return false;
/*    */     }
/* 66 */     if (getClass() != obj.getClass()) {
/* 67 */       return false;
/*    */     }
/* 69 */     PNNode other = (PNNode)obj;
/* 70 */     if (this.identifier == null) {
/* 71 */       if (other.identifier != null) {
/* 72 */         return false;
/*    */       }
/* 74 */     } else if (!this.identifier.equals(other.identifier)) {
/* 75 */       return false;
/*    */     } 
/* 77 */     if (this.name == null) {
/* 78 */       if (other.name != null) {
/* 79 */         return false;
/*    */       }
/* 81 */     } else if (!this.name.equals(other.name)) {
/* 82 */       return false;
/*    */     } 
/* 84 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/PNNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */