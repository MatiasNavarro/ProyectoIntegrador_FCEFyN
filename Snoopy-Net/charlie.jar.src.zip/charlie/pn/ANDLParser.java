/*      */ package charlie.pn;
/*      */ 
/*      */ import charlie.util.arithmetic.AbsExpr;
/*      */ import charlie.util.arithmetic.AbstractExpr;
/*      */ import charlie.util.arithmetic.AddExpr;
/*      */ import charlie.util.arithmetic.ArgumentExpr;
/*      */ import charlie.util.arithmetic.DivExpr;
/*      */ import charlie.util.arithmetic.Literal;
/*      */ import charlie.util.arithmetic.MaxExpr;
/*      */ import charlie.util.arithmetic.MinExpr;
/*      */ import charlie.util.arithmetic.MulExpr;
/*      */ import charlie.util.arithmetic.NonTerminalExpr;
/*      */ import charlie.util.arithmetic.SubExpr;
/*      */ import charlie.util.arithmetic.TerminalExpr;
/*      */ import charlie.util.arithmetic.UMinusExpr;
/*      */ import charlie.util.arithmetic.UserDefExpr;
/*      */ import charlie.util.arithmetic.Variable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Vector;
/*      */ import org.antlr.runtime.BitSet;
/*      */ import org.antlr.runtime.IntStream;
/*      */ import org.antlr.runtime.MismatchedSetException;
/*      */ import org.antlr.runtime.NoViableAltException;
/*      */ import org.antlr.runtime.Parser;
/*      */ import org.antlr.runtime.ParserRuleReturnScope;
/*      */ import org.antlr.runtime.RecognitionException;
/*      */ import org.antlr.runtime.RecognizerSharedState;
/*      */ import org.antlr.runtime.Token;
/*      */ import org.antlr.runtime.TokenStream;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class ANDLParser
/*      */   extends Parser
/*      */ {
/*   40 */   public static final String[] tokenNames = new String[] { "<invalid>", "<EOR>", "<DOWN>", "<UP>", "COMMENT", "DIGIT", "EXPONENT", "FLOAT1", "FLOAT2", "FLOAT3", "IDENT", "INT", "LETTER", "LINE_COMMENT", "SPECIALCHAR", "WS", "'&'", "'('", "')'", "'*'", "'+'", "','", "'-'", "'/'", "':'", "';'", "'<'", "'='", "'>='", "'LevelInterpretation'", "'MassAction'", "'MichaelisMenten'", "'['", "']'", "'abs'", "'constants'", "'continuous'", "'cpn'", "'deterministic'", "'discrete'", "'double'", "'fix'", "'functions'", "'gspn'", "'hpn'", "'immediate'", "'int'", "'max'", "'min'", "'observers'", "'place'", "'places'", "'pn'", "'rev'", "'scheduled'", "'spn'", "'stochastic'", "'tpn'", "'transition'", "'transitions'", "'valuesets'", "'xpn'", "'xspn'", "'{'", "'}'" };
/*      */   
/*      */   public static final int EOF = -1;
/*      */   
/*      */   public static final int T__16 = 16;
/*      */   
/*      */   public static final int T__17 = 17;
/*      */   
/*      */   public static final int T__18 = 18;
/*      */   
/*      */   public static final int T__19 = 19;
/*      */   
/*      */   public static final int T__20 = 20;
/*      */   public static final int T__21 = 21;
/*      */   public static final int T__22 = 22;
/*      */   public static final int T__23 = 23;
/*      */   public static final int T__24 = 24;
/*      */   public static final int T__25 = 25;
/*      */   public static final int T__26 = 26;
/*      */   public static final int T__27 = 27;
/*      */   public static final int T__28 = 28;
/*      */   public static final int T__29 = 29;
/*      */   public static final int T__30 = 30;
/*      */   public static final int T__31 = 31;
/*      */   public static final int T__32 = 32;
/*      */   public static final int T__33 = 33;
/*      */   public static final int T__34 = 34;
/*      */   public static final int T__35 = 35;
/*      */   public static final int T__36 = 36;
/*      */   public static final int T__37 = 37;
/*      */   public static final int T__38 = 38;
/*      */   public static final int T__39 = 39;
/*      */   public static final int T__40 = 40;
/*      */   public static final int T__41 = 41;
/*      */   public static final int T__42 = 42;
/*      */   public static final int T__43 = 43;
/*      */   public static final int T__44 = 44;
/*      */   public static final int T__45 = 45;
/*      */   public static final int T__46 = 46;
/*      */   public static final int T__47 = 47;
/*      */   public static final int T__48 = 48;
/*      */   public static final int T__49 = 49;
/*      */   public static final int T__50 = 50;
/*      */   public static final int T__51 = 51;
/*      */   public static final int T__52 = 52;
/*      */   public static final int T__53 = 53;
/*      */   public static final int T__54 = 54;
/*      */   public static final int T__55 = 55;
/*      */   public static final int T__56 = 56;
/*      */   public static final int T__57 = 57;
/*      */   public static final int T__58 = 58;
/*      */   public static final int T__59 = 59;
/*      */   public static final int T__60 = 60;
/*      */   public static final int T__61 = 61;
/*      */   public static final int T__62 = 62;
/*      */   public static final int T__63 = 63;
/*      */   public static final int T__64 = 64;
/*      */   public static final int COMMENT = 4;
/*      */   public static final int DIGIT = 5;
/*      */   public static final int EXPONENT = 6;
/*      */   public static final int FLOAT1 = 7;
/*      */   public static final int FLOAT2 = 8;
/*      */   public static final int FLOAT3 = 9;
/*      */   public static final int IDENT = 10;
/*      */   public static final int INT = 11;
/*      */   public static final int LETTER = 12;
/*      */   public static final int LINE_COMMENT = 13;
/*      */   public static final int SPECIALCHAR = 14;
/*      */   public static final int WS = 15;
/*      */   private Mode mode;
/*      */   public int nrPlaces;
/*      */   public int nrTransitions;
/*      */   public int currentPlaceId;
/*      */   public int placeCounter;
/*      */   public short currentTransId;
/*      */   
/*      */   public Parser[] getDelegates() {
/*  117 */     return new Parser[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ANDLParser(TokenStream input) {
/*  124 */     this(input, new RecognizerSharedState());
/*      */   }
/*      */   public String[] getTokenNames() { return tokenNames; } public String getGrammarFileName() { return "ANDL.g"; } public enum Mode {
/*  127 */     COUNT, PARSE; } public void setMode(Mode m) { this.mode = m; this.nrPlaces = 0; this.nrTransitions = 0; this.currentPlaceId = 0; this.currentTransId = 0; this.placeCounter = 0; } public void reportError(RecognitionException e) { throw new IllegalArgumentException(e); } public void setConstantRegistry(ConstantRegistry registry) { this.constants = registry; } public ANDLParser(TokenStream input, RecognizerSharedState state) { super(input, state);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  181 */     this.functions = new FunctionRegistry();
/*  182 */     this.argument = new ArgumentExpr();
/*      */     
/*  184 */     this.initialMarking = new Vector();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  213 */     this.requires = new HashMap<>();
/*  214 */     this.increases = new HashMap<>();
/*  215 */     this.decreases = new HashMap<>();
/*  216 */     this.bounds = new HashMap<>();
/*  217 */     this.assigns = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  231 */     this.cp = new Element();
/*      */     
/*  233 */     this.pn = null; }
/*      */   public void setNet(PlaceTransitionNet pn) { this.pn = pn;
/*      */     this.requires.clear();
/*      */     this.increases.clear();
/*      */     this.decreases.clear();
/*      */     this.bounds.clear();
/*      */     this.assigns.clear(); } private static final Log LOG = LogFactory.getLog(ANDLParser.class); ConstantRegistry constants; FunctionRegistry functions; ArgumentExpr argument; public final void start() throws RecognitionException {
/*  240 */     Token IDENT1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  246 */       pushFollow(FOLLOW_net_type_in_start36);
/*  247 */       net_type();
/*  248 */       this.state._fsp--;
/*      */       
/*  250 */       match((IntStream)this.input, 32, FOLLOW_32_in_start38);
/*  251 */       IDENT1 = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_start40);
/*  252 */       match((IntStream)this.input, 33, FOLLOW_33_in_start42);
/*  253 */       Out.println("loading " + ((IDENT1 != null) ? IDENT1.getText() : null));
/*  254 */       match((IntStream)this.input, 63, FOLLOW_63_in_start46);
/*  255 */       pushFollow(FOLLOW_net_in_start48);
/*  256 */       net();
/*  257 */       this.state._fsp--;
/*      */       
/*  259 */       match((IntStream)this.input, 64, FOLLOW_64_in_start50);
/*      */ 
/*      */     
/*      */     }
/*  263 */     catch (RecognitionException re) {
/*  264 */       reportError(re);
/*  265 */       recover((IntStream)this.input, re);
/*      */     } finally {} } public List initialMarking; private HashMap<String, List<Tupel>> requires; private HashMap<String, List<Tupel>> increases; private HashMap<String, List<Tupel>> decreases; private HashMap<String, List<Tupel>> bounds; private HashMap<String, List<Tupel>> assigns; Element cp; PlaceTransitionNet pn; private enum Type {
/*      */     DOUBLE, INT; } class Element {
/*      */     ANDLParser.Type type; double value; int ivalue; boolean hasValue; String identifier; AbstractExpr node; } class Tupel {
/*      */     public String identifier; public int value; public double dvalue; public Tupel(String id, int val) { this.identifier = id; this.value = val; }
/*      */     public Tupel(String id, double val) { this.identifier = id;
/*      */       this.dvalue = val; } }
/*      */   public void addTupel(HashMap<String, List<Tupel>> map, String key, Tupel t) { if (this.mode == Mode.PARSE) {
/*      */       if (map.get(key) == null)
/*      */         map.put(key, new LinkedList<>()); 
/*      */       List<Tupel> l = map.get(key);
/*      */       l.add(t);
/*      */     }  }
/*      */   public final void net_type() throws RecognitionException { try {
/*      */       NoViableAltException nvae;
/*  280 */       int alt1 = 8;
/*  281 */       switch (this.input.LA(1)) {
/*      */         
/*      */         case 52:
/*  284 */           alt1 = 1;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 61:
/*  289 */           alt1 = 2;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 55:
/*  294 */           alt1 = 3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 43:
/*  299 */           alt1 = 4;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 62:
/*  304 */           alt1 = 5;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 37:
/*  309 */           alt1 = 6;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 44:
/*  314 */           alt1 = 7;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 57:
/*  319 */           alt1 = 8;
/*      */           break;
/*      */         
/*      */         default:
/*  323 */           nvae = new NoViableAltException("", 1, 0, (IntStream)this.input);
/*      */           
/*  325 */           throw nvae;
/*      */       } 
/*  327 */       switch (alt1) {
/*      */ 
/*      */         
/*      */         case 1:
/*  331 */           match((IntStream)this.input, 52, FOLLOW_52_in_net_type63);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/*  338 */           match((IntStream)this.input, 61, FOLLOW_61_in_net_type71);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 3:
/*  345 */           match((IntStream)this.input, 55, FOLLOW_55_in_net_type79);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/*  352 */           match((IntStream)this.input, 43, FOLLOW_43_in_net_type87);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 5:
/*  359 */           match((IntStream)this.input, 62, FOLLOW_62_in_net_type95);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 6:
/*  366 */           match((IntStream)this.input, 37, FOLLOW_37_in_net_type102);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 7:
/*  373 */           match((IntStream)this.input, 44, FOLLOW_44_in_net_type110);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 8:
/*  380 */           match((IntStream)this.input, 57, FOLLOW_57_in_net_type118);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  387 */     } catch (RecognitionException re) {
/*  388 */       reportError(re);
/*  389 */       recover((IntStream)this.input, re);
/*      */     } finally {} }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void net() throws RecognitionException {
/*      */     try {
/*  407 */       int alt2 = 2;
/*  408 */       int LA2_0 = this.input.LA(1);
/*  409 */       if (LA2_0 == 42) {
/*  410 */         alt2 = 1;
/*      */       }
/*  412 */       switch (alt2) {
/*      */ 
/*      */         
/*      */         case 1:
/*  416 */           pushFollow(FOLLOW_functions_in_net134);
/*  417 */           functions();
/*  418 */           this.state._fsp--;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  426 */       int alt3 = 2;
/*  427 */       int LA3_0 = this.input.LA(1);
/*  428 */       if (LA3_0 == 35) {
/*  429 */         alt3 = 1;
/*      */       }
/*  431 */       switch (alt3) {
/*      */ 
/*      */         
/*      */         case 1:
/*  435 */           pushFollow(FOLLOW_constants_in_net139);
/*  436 */           constants();
/*  437 */           this.state._fsp--;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  444 */       pushFollow(FOLLOW_places_in_net143);
/*  445 */       places();
/*  446 */       this.state._fsp--;
/*      */ 
/*      */       
/*  449 */       int alt4 = 2;
/*  450 */       int LA4_0 = this.input.LA(1);
/*  451 */       if (LA4_0 == 49) {
/*  452 */         alt4 = 1;
/*      */       }
/*  454 */       switch (alt4) {
/*      */ 
/*      */         
/*      */         case 1:
/*  458 */           pushFollow(FOLLOW_observers_in_net146);
/*  459 */           observers();
/*  460 */           this.state._fsp--;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  467 */       pushFollow(FOLLOW_transitions_in_net150);
/*  468 */       transitions();
/*  469 */       this.state._fsp--;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  475 */     catch (RecognitionException re) {
/*  476 */       reportError(re);
/*  477 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void functions() throws RecognitionException {
/*      */     try {
/*  494 */       match((IntStream)this.input, 42, FOLLOW_42_in_functions163);
/*  495 */       match((IntStream)this.input, 24, FOLLOW_24_in_functions165);
/*      */ 
/*      */       
/*      */       while (true) {
/*  499 */         int alt5 = 2;
/*  500 */         int LA5_0 = this.input.LA(1);
/*  501 */         if (LA5_0 == 10) {
/*  502 */           alt5 = 1;
/*      */         }
/*      */         
/*  505 */         switch (alt5) {
/*      */ 
/*      */           
/*      */           case 1:
/*  509 */             pushFollow(FOLLOW_function_def_in_functions168);
/*  510 */             function_def();
/*  511 */             this.state._fsp--;
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  524 */     } catch (RecognitionException re) {
/*  525 */       reportError(re);
/*  526 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void function_def() throws RecognitionException {
/*  539 */     ParserRuleReturnScope function_name2 = null;
/*  540 */     AbstractExpr arithmetic_function3 = null;
/*  541 */     ArrayList<String> function_param4 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  547 */       pushFollow(FOLLOW_function_name_in_function_def182);
/*  548 */       function_name2 = function_name();
/*  549 */       this.state._fsp--;
/*      */       
/*  551 */       match((IntStream)this.input, 17, FOLLOW_17_in_function_def184);
/*      */       
/*  553 */       int alt6 = 2;
/*  554 */       int LA6_0 = this.input.LA(1);
/*  555 */       if (LA6_0 == 10) {
/*  556 */         alt6 = 1;
/*      */       }
/*  558 */       switch (alt6) {
/*      */ 
/*      */         
/*      */         case 1:
/*  562 */           pushFollow(FOLLOW_function_param_in_function_def186);
/*  563 */           function_param4 = function_param();
/*  564 */           this.state._fsp--;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  571 */       match((IntStream)this.input, 18, FOLLOW_18_in_function_def189);
/*  572 */       match((IntStream)this.input, 27, FOLLOW_27_in_function_def191);
/*  573 */       pushFollow(FOLLOW_arithmetic_function_in_function_def193);
/*  574 */       arithmetic_function3 = arithmetic_function();
/*  575 */       this.state._fsp--;
/*      */       
/*  577 */       match((IntStream)this.input, 25, FOLLOW_25_in_function_def195);
/*      */       
/*  579 */       if (this.mode == Mode.PARSE) {
/*  580 */         Function f = new Function((function_name2 != null) ? this.input.toString(function_name2.start, function_name2.stop) : null, arithmetic_function3, function_param4);
/*  581 */         this.functions.register((function_name2 != null) ? this.input.toString(function_name2.start, function_name2.stop) : null, f);
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  587 */     catch (RecognitionException re) {
/*  588 */       reportError(re);
/*  589 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class function_name_return
/*      */     extends ParserRuleReturnScope {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final function_name_return function_name() throws RecognitionException {
/*  605 */     function_name_return retval = new function_name_return();
/*  606 */     retval.start = this.input.LT(1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  612 */       match((IntStream)this.input, 10, FOLLOW_IDENT_in_function_name209);
/*      */ 
/*      */       
/*  615 */       retval.stop = this.input.LT(-1);
/*      */     
/*      */     }
/*  618 */     catch (RecognitionException re) {
/*  619 */       reportError(re);
/*  620 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */     
/*  625 */     return retval;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ArrayList<String> function_param() throws RecognitionException {
/*  634 */     ArrayList<String> params = null;
/*      */ 
/*      */     
/*  637 */     Token pa = null;
/*  638 */     Token po = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  644 */       pa = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_function_param226);
/*  645 */       params = new ArrayList<>(); params.add((pa != null) ? pa.getText() : null);
/*      */ 
/*      */       
/*      */       while (true) {
/*  649 */         int alt7 = 2;
/*  650 */         int LA7_0 = this.input.LA(1);
/*  651 */         if (LA7_0 == 21) {
/*  652 */           alt7 = 1;
/*      */         }
/*      */         
/*  655 */         switch (alt7) {
/*      */ 
/*      */           
/*      */           case 1:
/*  659 */             match((IntStream)this.input, 21, FOLLOW_21_in_function_param235);
/*  660 */             po = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_function_param239);
/*  661 */             params.add((po != null) ? po.getText() : null);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  673 */     } catch (RecognitionException re) {
/*  674 */       reportError(re);
/*  675 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */     
/*  680 */     return params;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void constants() throws RecognitionException {
/*      */     try {
/*  693 */       match((IntStream)this.input, 35, FOLLOW_35_in_constants256);
/*  694 */       match((IntStream)this.input, 24, FOLLOW_24_in_constants258);
/*      */       
/*  696 */       int alt8 = 2;
/*  697 */       int LA8_0 = this.input.LA(1);
/*  698 */       if (LA8_0 == 60) {
/*  699 */         alt8 = 1;
/*      */       }
/*  701 */       switch (alt8) {
/*      */ 
/*      */         
/*      */         case 1:
/*  705 */           pushFollow(FOLLOW_valuesets_in_constants261);
/*  706 */           valuesets();
/*  707 */           this.state._fsp--;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/*  717 */         int alt9 = 2;
/*  718 */         int LA9_0 = this.input.LA(1);
/*  719 */         if (LA9_0 == 10 || LA9_0 == 40 || LA9_0 == 46) {
/*  720 */           alt9 = 1;
/*      */         }
/*      */         
/*  723 */         switch (alt9) {
/*      */ 
/*      */           
/*      */           case 1:
/*  727 */             pushFollow(FOLLOW_constant_def_in_constants266);
/*  728 */             constant_def();
/*  729 */             this.state._fsp--;
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  742 */     } catch (RecognitionException re) {
/*  743 */       reportError(re);
/*  744 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void group() throws RecognitionException {
/*      */     try {
/*  761 */       pushFollow(FOLLOW_name_in_group280);
/*  762 */       name();
/*  763 */       this.state._fsp--;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  768 */     catch (RecognitionException re) {
/*  769 */       reportError(re);
/*  770 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void valuesets() throws RecognitionException {
/*      */     try {
/*  787 */       match((IntStream)this.input, 60, FOLLOW_60_in_valuesets294);
/*  788 */       match((IntStream)this.input, 32, FOLLOW_32_in_valuesets296);
/*  789 */       pushFollow(FOLLOW_name_in_valuesets298);
/*  790 */       name();
/*  791 */       this.state._fsp--;
/*      */ 
/*      */ 
/*      */       
/*      */       while (true) {
/*  796 */         int alt10 = 2;
/*  797 */         int LA10_0 = this.input.LA(1);
/*  798 */         if (LA10_0 == 24) {
/*  799 */           alt10 = 1;
/*      */         }
/*      */         
/*  802 */         switch (alt10) {
/*      */ 
/*      */           
/*      */           case 1:
/*  806 */             match((IntStream)this.input, 24, FOLLOW_24_in_valuesets301);
/*  807 */             pushFollow(FOLLOW_name_in_valuesets303);
/*  808 */             name();
/*  809 */             this.state._fsp--;
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*  819 */       match((IntStream)this.input, 33, FOLLOW_33_in_valuesets307);
/*      */ 
/*      */     
/*      */     }
/*  823 */     catch (RecognitionException re) {
/*  824 */       reportError(re);
/*  825 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void constant_def() throws RecognitionException {
/*      */     try {
/*      */       int LA15_1;
/*      */       NoViableAltException nvae;
/*  840 */       int alt11, alt13, nvaeMark, LA11_0, LA13_0, alt12, alt14, LA12_0, LA14_0, alt15 = 2;
/*  841 */       switch (this.input.LA(1)) {
/*      */         
/*      */         case 10:
/*  844 */           LA15_1 = this.input.LA(2);
/*  845 */           if (LA15_1 == 24) {
/*  846 */             int LA15_4 = this.input.LA(3);
/*  847 */             if (LA15_4 == 46) {
/*  848 */               alt15 = 1; break;
/*      */             } 
/*  850 */             if (LA15_4 == 40) {
/*  851 */               alt15 = 2;
/*      */               
/*      */               break;
/*      */             } 
/*  855 */             int i = this.input.mark();
/*      */             try {
/*  857 */               for (int nvaeConsume = 0; nvaeConsume < 2; nvaeConsume++) {
/*  858 */                 this.input.consume();
/*      */               }
/*  860 */               NoViableAltException noViableAltException = new NoViableAltException("", 15, 4, (IntStream)this.input);
/*      */               
/*  862 */               throw noViableAltException;
/*      */             } finally {
/*  864 */               this.input.rewind(i);
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  871 */           nvaeMark = this.input.mark();
/*      */           try {
/*  873 */             this.input.consume();
/*  874 */             NoViableAltException noViableAltException = new NoViableAltException("", 15, 1, (IntStream)this.input);
/*      */             
/*  876 */             throw noViableAltException;
/*      */           } finally {
/*  878 */             this.input.rewind(nvaeMark);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 46:
/*  886 */           alt15 = 1;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 40:
/*  891 */           alt15 = 2;
/*      */           break;
/*      */         
/*      */         default:
/*  895 */           nvae = new NoViableAltException("", 15, 0, (IntStream)this.input);
/*      */           
/*  897 */           throw nvae;
/*      */       } 
/*  899 */       switch (alt15) {
/*      */ 
/*      */ 
/*      */         
/*      */         case 1:
/*  904 */           alt11 = 2;
/*  905 */           LA11_0 = this.input.LA(1);
/*  906 */           if (LA11_0 == 10) {
/*  907 */             alt11 = 1;
/*      */           }
/*  909 */           switch (alt11) {
/*      */ 
/*      */             
/*      */             case 1:
/*  913 */               pushFollow(FOLLOW_group_in_constant_def320);
/*  914 */               group();
/*  915 */               this.state._fsp--;
/*      */               
/*  917 */               match((IntStream)this.input, 24, FOLLOW_24_in_constant_def322);
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  923 */           match((IntStream)this.input, 46, FOLLOW_46_in_constant_def326);
/*  924 */           pushFollow(FOLLOW_name_in_constant_def328);
/*  925 */           name();
/*  926 */           this.state._fsp--;
/*      */ 
/*      */           
/*  929 */           alt12 = 2;
/*  930 */           LA12_0 = this.input.LA(1);
/*  931 */           if (LA12_0 == 27) {
/*  932 */             alt12 = 1;
/*      */           }
/*  934 */           switch (alt12) {
/*      */ 
/*      */             
/*      */             case 1:
/*  938 */               match((IntStream)this.input, 27, FOLLOW_27_in_constant_def331);
/*  939 */               pushFollow(FOLLOW_int_const_init_in_constant_def333);
/*  940 */               int_const_init();
/*  941 */               this.state._fsp--;
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  948 */           match((IntStream)this.input, 25, FOLLOW_25_in_constant_def337);
/*      */ 
/*      */           
/*  951 */           if (this.mode == Mode.PARSE) {
/*  952 */             Constant c = new IntConstant(this.cp.identifier, null);
/*      */             
/*  954 */             if (this.cp.hasValue) {
/*  955 */               c = new IntConstant(this.cp.identifier, "" + this.cp.ivalue);
/*  956 */               this.argument.put(this.cp.identifier, Integer.valueOf(this.cp.ivalue));
/*      */             } 
/*  958 */             Out.println("const int " + this.cp.identifier + " = " + this.cp.ivalue);
/*  959 */             this.constants.register(this.cp.identifier, c);
/*      */           } 
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/*  968 */           alt13 = 2;
/*  969 */           LA13_0 = this.input.LA(1);
/*  970 */           if (LA13_0 == 10) {
/*  971 */             alt13 = 1;
/*      */           }
/*  973 */           switch (alt13) {
/*      */ 
/*      */             
/*      */             case 1:
/*  977 */               pushFollow(FOLLOW_group_in_constant_def347);
/*  978 */               group();
/*  979 */               this.state._fsp--;
/*      */               
/*  981 */               match((IntStream)this.input, 24, FOLLOW_24_in_constant_def349);
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  987 */           match((IntStream)this.input, 40, FOLLOW_40_in_constant_def353);
/*  988 */           pushFollow(FOLLOW_name_in_constant_def355);
/*  989 */           name();
/*  990 */           this.state._fsp--;
/*      */ 
/*      */           
/*  993 */           alt14 = 2;
/*  994 */           LA14_0 = this.input.LA(1);
/*  995 */           if (LA14_0 == 27) {
/*  996 */             alt14 = 1;
/*      */           }
/*  998 */           switch (alt14) {
/*      */ 
/*      */             
/*      */             case 1:
/* 1002 */               match((IntStream)this.input, 27, FOLLOW_27_in_constant_def358);
/* 1003 */               pushFollow(FOLLOW_double_const_init_in_constant_def360);
/* 1004 */               double_const_init();
/* 1005 */               this.state._fsp--;
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1012 */           match((IntStream)this.input, 25, FOLLOW_25_in_constant_def364);
/*      */ 
/*      */           
/* 1015 */           if (this.mode == Mode.PARSE) {
/* 1016 */             Constant c = new DoubleConstant(this.cp.identifier, null);
/*      */             
/* 1018 */             if (this.cp.hasValue) {
/* 1019 */               c = new DoubleConstant(this.cp.identifier, "" + this.cp.value);
/* 1020 */               this.argument.put(this.cp.identifier, Double.valueOf(this.cp.value));
/*      */             } 
/* 1022 */             Out.println("const double " + this.cp.identifier + " = " + this.cp.value);
/* 1023 */             this.constants.register(this.cp.identifier, c);
/*      */           } 
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1031 */     } catch (RecognitionException re) {
/* 1032 */       reportError(re);
/* 1033 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void int_const_init() throws RecognitionException {
/* 1046 */     int v = 0;
/*      */ 
/*      */     
/*      */     try {
/* 1050 */       int alt18 = 2;
/* 1051 */       int LA18_0 = this.input.LA(1);
/* 1052 */       if ((LA18_0 >= 7 && LA18_0 <= 11) || LA18_0 == 17 || LA18_0 == 22 || LA18_0 == 34 || (LA18_0 >= 47 && LA18_0 <= 48)) {
/* 1053 */         alt18 = 1;
/*      */       }
/* 1055 */       else if (LA18_0 == 32) {
/* 1056 */         alt18 = 2;
/*      */       }
/*      */       else {
/*      */         
/* 1060 */         NoViableAltException nvae = new NoViableAltException("", 18, 0, (IntStream)this.input);
/*      */         
/* 1062 */         throw nvae;
/*      */       } 
/*      */       
/* 1065 */       switch (alt18) {
/*      */ 
/*      */         
/*      */         case 1:
/* 1069 */           pushFollow(FOLLOW_integer_in_int_const_init381);
/* 1070 */           v = integer();
/* 1071 */           this.state._fsp--;
/*      */ 
/*      */           
/* 1074 */           this.cp.hasValue = true;
/* 1075 */           this.cp.ivalue = v;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 1082 */           match((IntStream)this.input, 32, FOLLOW_32_in_int_const_init389);
/* 1083 */           pushFollow(FOLLOW_integer_in_int_const_init393);
/* 1084 */           v = integer();
/* 1085 */           this.state._fsp--;
/*      */ 
/*      */           
/* 1088 */           this.cp.hasValue = true;
/* 1089 */           this.cp.ivalue = v;
/*      */ 
/*      */ 
/*      */           
/*      */           while (true) {
/* 1094 */             int alt16, LA16_0, alt17 = 2;
/* 1095 */             int LA17_0 = this.input.LA(1);
/* 1096 */             if (LA17_0 == 24) {
/* 1097 */               alt17 = 1;
/*      */             }
/*      */             
/* 1100 */             switch (alt17) {
/*      */ 
/*      */               
/*      */               case 1:
/* 1104 */                 match((IntStream)this.input, 24, FOLLOW_24_in_int_const_init398);
/*      */                 
/* 1106 */                 alt16 = 2;
/* 1107 */                 LA16_0 = this.input.LA(1);
/* 1108 */                 if ((LA16_0 >= 7 && LA16_0 <= 11) || LA16_0 == 17 || LA16_0 == 22 || LA16_0 == 34 || (LA16_0 >= 47 && LA16_0 <= 48)) {
/* 1109 */                   alt16 = 1;
/*      */                 }
/* 1111 */                 switch (alt16) {
/*      */ 
/*      */                   
/*      */                   case 1:
/* 1115 */                     pushFollow(FOLLOW_integer_in_int_const_init400);
/* 1116 */                     integer();
/* 1117 */                     this.state._fsp--;
/*      */                     continue;
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/* 1132 */           match((IntStream)this.input, 33, FOLLOW_33_in_int_const_init405);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 1138 */     } catch (RecognitionException re) {
/* 1139 */       reportError(re);
/* 1140 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void double_const_init() throws RecognitionException {
/* 1153 */     double v = 0.0D;
/*      */ 
/*      */     
/*      */     try {
/* 1157 */       int alt21 = 2;
/* 1158 */       int LA21_0 = this.input.LA(1);
/* 1159 */       if ((LA21_0 >= 7 && LA21_0 <= 11) || LA21_0 == 17 || LA21_0 == 22 || LA21_0 == 34 || (LA21_0 >= 47 && LA21_0 <= 48)) {
/* 1160 */         alt21 = 1;
/*      */       }
/* 1162 */       else if (LA21_0 == 32) {
/* 1163 */         alt21 = 2;
/*      */       }
/*      */       else {
/*      */         
/* 1167 */         NoViableAltException nvae = new NoViableAltException("", 21, 0, (IntStream)this.input);
/*      */         
/* 1169 */         throw nvae;
/*      */       } 
/*      */       
/* 1172 */       switch (alt21) {
/*      */ 
/*      */         
/*      */         case 1:
/* 1176 */           pushFollow(FOLLOW_real_in_double_const_init420);
/* 1177 */           v = real();
/* 1178 */           this.state._fsp--;
/*      */ 
/*      */           
/* 1181 */           this.cp.hasValue = true;
/* 1182 */           this.cp.value = v;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 1189 */           match((IntStream)this.input, 32, FOLLOW_32_in_double_const_init428);
/* 1190 */           pushFollow(FOLLOW_real_in_double_const_init432);
/* 1191 */           v = real();
/* 1192 */           this.state._fsp--;
/*      */ 
/*      */           
/* 1195 */           this.cp.hasValue = true;
/* 1196 */           this.cp.value = v;
/*      */ 
/*      */ 
/*      */           
/*      */           while (true) {
/* 1201 */             int alt19, LA19_0, alt20 = 2;
/* 1202 */             int LA20_0 = this.input.LA(1);
/* 1203 */             if (LA20_0 == 24) {
/* 1204 */               alt20 = 1;
/*      */             }
/*      */             
/* 1207 */             switch (alt20) {
/*      */ 
/*      */               
/*      */               case 1:
/* 1211 */                 match((IntStream)this.input, 24, FOLLOW_24_in_double_const_init437);
/*      */                 
/* 1213 */                 alt19 = 2;
/* 1214 */                 LA19_0 = this.input.LA(1);
/* 1215 */                 if ((LA19_0 >= 7 && LA19_0 <= 11) || LA19_0 == 17 || LA19_0 == 22 || LA19_0 == 34 || (LA19_0 >= 47 && LA19_0 <= 48)) {
/* 1216 */                   alt19 = 1;
/*      */                 }
/* 1218 */                 switch (alt19) {
/*      */ 
/*      */                   
/*      */                   case 1:
/* 1222 */                     pushFollow(FOLLOW_real_in_double_const_init439);
/* 1223 */                     real();
/* 1224 */                     this.state._fsp--;
/*      */                     continue;
/*      */                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/* 1239 */           match((IntStream)this.input, 33, FOLLOW_33_in_double_const_init444);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 1245 */     } catch (RecognitionException re) {
/* 1246 */       reportError(re);
/* 1247 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void places() throws RecognitionException {
/*      */     try {
/* 1264 */       match((IntStream)this.input, 51, FOLLOW_51_in_places456);
/* 1265 */       match((IntStream)this.input, 24, FOLLOW_24_in_places458);
/*      */ 
/*      */       
/*      */       while (true) {
/* 1269 */         int alt22 = 2;
/* 1270 */         int LA22_0 = this.input.LA(1);
/* 1271 */         if (LA22_0 == 10 || LA22_0 == 36 || LA22_0 == 39) {
/* 1272 */           alt22 = 1;
/*      */         }
/*      */         
/* 1275 */         switch (alt22) {
/*      */ 
/*      */           
/*      */           case 1:
/* 1279 */             pushFollow(FOLLOW_typed_places_in_places460);
/* 1280 */             typed_places();
/* 1281 */             this.state._fsp--;
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 1294 */     } catch (RecognitionException re) {
/* 1295 */       reportError(re);
/* 1296 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void typed_places() throws RecognitionException {
/*      */     try {
/*      */       while (true) {
/* 1316 */         int alt23 = 2;
/* 1317 */         int LA23_0 = this.input.LA(1);
/* 1318 */         if (LA23_0 == 36 || LA23_0 == 39) {
/* 1319 */           alt23 = 1;
/*      */         }
/*      */         
/* 1322 */         switch (alt23) {
/*      */ 
/*      */           
/*      */           case 1:
/* 1326 */             pushFollow(FOLLOW_place_type_in_typed_places472);
/* 1327 */             place_type();
/* 1328 */             this.state._fsp--;
/*      */             
/* 1330 */             match((IntStream)this.input, 24, FOLLOW_24_in_typed_places474);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 1339 */       pushFollow(FOLLOW_place_def_in_typed_places478);
/* 1340 */       place_def();
/* 1341 */       this.state._fsp--;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1346 */     catch (RecognitionException re) {
/* 1347 */       reportError(re);
/* 1348 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void place_type() throws RecognitionException {
/*      */     try {
/* 1365 */       if (this.input.LA(1) == 36 || this.input.LA(1) == 39) {
/* 1366 */         this.input.consume();
/* 1367 */         this.state.errorRecovery = false;
/*      */       } else {
/*      */         
/* 1370 */         MismatchedSetException mse = new MismatchedSetException(null, (IntStream)this.input);
/* 1371 */         throw mse;
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1376 */     catch (RecognitionException re) {
/* 1377 */       reportError(re);
/* 1378 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void place_def() throws RecognitionException {
/* 1391 */     int integer5 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1397 */       pushFollow(FOLLOW_place_name_in_place_def508);
/* 1398 */       place_name();
/* 1399 */       this.state._fsp--;
/*      */ 
/*      */       
/* 1402 */       int alt24 = 2;
/* 1403 */       int LA24_0 = this.input.LA(1);
/* 1404 */       if (LA24_0 == 63) {
/* 1405 */         alt24 = 1;
/*      */       }
/* 1407 */       switch (alt24) {
/*      */ 
/*      */         
/*      */         case 1:
/* 1411 */           match((IntStream)this.input, 63, FOLLOW_63_in_place_def511);
/* 1412 */           match((IntStream)this.input, 41, FOLLOW_41_in_place_def513);
/* 1413 */           match((IntStream)this.input, 64, FOLLOW_64_in_place_def515);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1419 */       match((IntStream)this.input, 27, FOLLOW_27_in_place_def519);
/* 1420 */       pushFollow(FOLLOW_integer_in_place_def521);
/* 1421 */       integer5 = integer();
/* 1422 */       this.state._fsp--;
/*      */       
/* 1424 */       match((IntStream)this.input, 25, FOLLOW_25_in_place_def523);
/*      */       
/* 1426 */       if (this.mode == Mode.PARSE) {
/* 1427 */         int token = integer5;
/* 1428 */         Place ret = new Place(this.cp.identifier, this.cp.identifier, token, this.currentPlaceId++, this.placeCounter++, 0);
/* 1429 */         this.pn.allNodes().put(this.cp.identifier, ret);
/* 1430 */         this.pn.identifier().put(ret, this.cp.identifier);
/* 1431 */         this.pn.addPlace(ret);
/* 1432 */         if (token > 0) {
/* 1433 */           this.initialMarking.add(ret);
/* 1434 */           this.initialMarking.add(new Integer(token));
/*      */         } 
/* 1436 */         Out.println("place " + this.cp.identifier + " = " + token);
/*      */       } else {
/* 1438 */         this.nrPlaces++;
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1444 */     catch (RecognitionException re) {
/* 1445 */       reportError(re);
/* 1446 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void place_name() throws RecognitionException {
/*      */     try {
/* 1463 */       pushFollow(FOLLOW_name_in_place_name539);
/* 1464 */       name();
/* 1465 */       this.state._fsp--;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1470 */     catch (RecognitionException re) {
/* 1471 */       reportError(re);
/* 1472 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void observers() throws RecognitionException {
/*      */     try {
/* 1489 */       match((IntStream)this.input, 49, FOLLOW_49_in_observers552);
/* 1490 */       match((IntStream)this.input, 24, FOLLOW_24_in_observers554);
/*      */ 
/*      */       
/*      */       while (true) {
/* 1494 */         int alt25 = 2;
/* 1495 */         int LA25_0 = this.input.LA(1);
/* 1496 */         if (LA25_0 == 10 || LA25_0 == 50 || LA25_0 == 58) {
/* 1497 */           alt25 = 1;
/*      */         }
/*      */         
/* 1500 */         switch (alt25) {
/*      */ 
/*      */           
/*      */           case 1:
/* 1504 */             pushFollow(FOLLOW_observer_in_observers556);
/* 1505 */             observer();
/* 1506 */             this.state._fsp--;
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 1519 */     } catch (Exception e) {
/*      */       
/* 1521 */       throw new RecognitionException();
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void observer() throws RecognitionException {
/*      */     try {
/*      */       while (true) {
/* 1543 */         int alt26 = 2;
/* 1544 */         int LA26_0 = this.input.LA(1);
/* 1545 */         if (LA26_0 == 50 || LA26_0 == 58) {
/* 1546 */           alt26 = 1;
/*      */         }
/*      */         
/* 1549 */         switch (alt26) {
/*      */ 
/*      */           
/*      */           case 1:
/* 1553 */             pushFollow(FOLLOW_observer_type_in_observer573);
/* 1554 */             observer_type();
/* 1555 */             this.state._fsp--;
/*      */             
/* 1557 */             match((IntStream)this.input, 24, FOLLOW_24_in_observer575);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 1566 */       match((IntStream)this.input, 10, FOLLOW_IDENT_in_observer579);
/* 1567 */       match((IntStream)this.input, 27, FOLLOW_27_in_observer581);
/* 1568 */       pushFollow(FOLLOW_arithmetic_function_in_observer583);
/* 1569 */       arithmetic_function();
/* 1570 */       this.state._fsp--;
/*      */       
/* 1572 */       match((IntStream)this.input, 25, FOLLOW_25_in_observer585);
/*      */ 
/*      */     
/*      */     }
/* 1576 */     catch (RecognitionException re) {
/* 1577 */       reportError(re);
/* 1578 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void observer_type() throws RecognitionException {
/*      */     try {
/* 1595 */       if (this.input.LA(1) == 50 || this.input.LA(1) == 58) {
/* 1596 */         this.input.consume();
/* 1597 */         this.state.errorRecovery = false;
/*      */       } else {
/*      */         
/* 1600 */         MismatchedSetException mse = new MismatchedSetException(null, (IntStream)this.input);
/* 1601 */         throw mse;
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1606 */     catch (RecognitionException re) {
/* 1607 */       reportError(re);
/* 1608 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void transitions() throws RecognitionException {
/*      */     try {
/* 1625 */       match((IntStream)this.input, 59, FOLLOW_59_in_transitions611);
/* 1626 */       match((IntStream)this.input, 24, FOLLOW_24_in_transitions613);
/*      */ 
/*      */       
/*      */       while (true) {
/* 1630 */         int alt27 = 2;
/* 1631 */         int LA27_0 = this.input.LA(1);
/* 1632 */         if (LA27_0 == 10 || LA27_0 == 36 || LA27_0 == 38 || LA27_0 == 45 || LA27_0 == 54 || LA27_0 == 56) {
/* 1633 */           alt27 = 1;
/*      */         }
/*      */         
/* 1636 */         switch (alt27) {
/*      */ 
/*      */           
/*      */           case 1:
/* 1640 */             pushFollow(FOLLOW_typed_trans_in_transitions615);
/* 1641 */             typed_trans();
/* 1642 */             this.state._fsp--;
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 1655 */     } catch (Exception e) {
/*      */       
/* 1657 */       throw new RecognitionException();
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void typed_trans() throws RecognitionException {
/*      */     try {
/*      */       while (true) {
/* 1679 */         int alt28 = 2;
/* 1680 */         int LA28_0 = this.input.LA(1);
/* 1681 */         if (LA28_0 == 36 || LA28_0 == 38 || LA28_0 == 45 || LA28_0 == 54 || LA28_0 == 56) {
/* 1682 */           alt28 = 1;
/*      */         }
/*      */         
/* 1685 */         switch (alt28) {
/*      */ 
/*      */           
/*      */           case 1:
/* 1689 */             pushFollow(FOLLOW_trans_type_in_typed_trans632);
/* 1690 */             trans_type();
/* 1691 */             this.state._fsp--;
/*      */             
/* 1693 */             match((IntStream)this.input, 24, FOLLOW_24_in_typed_trans634);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 1702 */       pushFollow(FOLLOW_trans_def_in_typed_trans638);
/* 1703 */       trans_def();
/* 1704 */       this.state._fsp--;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1709 */     catch (RecognitionException re) {
/* 1710 */       reportError(re);
/* 1711 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void trans_type() throws RecognitionException {
/*      */     try {
/* 1728 */       if (this.input.LA(1) == 36 || this.input.LA(1) == 38 || this.input.LA(1) == 45 || this.input.LA(1) == 54 || this.input.LA(1) == 56) {
/* 1729 */         this.input.consume();
/* 1730 */         this.state.errorRecovery = false;
/*      */       } else {
/*      */         
/* 1733 */         MismatchedSetException mse = new MismatchedSetException(null, (IntStream)this.input);
/* 1734 */         throw mse;
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1739 */     catch (RecognitionException re) {
/* 1740 */       reportError(re);
/* 1741 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void trans_def() throws RecognitionException {
/*      */     try {
/* 1758 */       pushFollow(FOLLOW_trans_name_in_trans_def681);
/* 1759 */       trans_name();
/* 1760 */       this.state._fsp--;
/*      */ 
/*      */       
/* 1763 */       int alt29 = 2;
/* 1764 */       int LA29_0 = this.input.LA(1);
/* 1765 */       if (LA29_0 == 63) {
/* 1766 */         alt29 = 1;
/*      */       }
/* 1768 */       switch (alt29) {
/*      */ 
/*      */         
/*      */         case 1:
/* 1772 */           match((IntStream)this.input, 63, FOLLOW_63_in_trans_def684);
/* 1773 */           match((IntStream)this.input, 53, FOLLOW_53_in_trans_def686);
/* 1774 */           match((IntStream)this.input, 64, FOLLOW_64_in_trans_def688);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1780 */       match((IntStream)this.input, 24, FOLLOW_24_in_trans_def692);
/*      */       
/* 1782 */       int alt31 = 2;
/* 1783 */       int LA31_0 = this.input.LA(1);
/* 1784 */       if (LA31_0 == 32) {
/* 1785 */         alt31 = 1;
/*      */       }
/* 1787 */       switch (alt31) {
/*      */ 
/*      */         
/*      */         case 1:
/* 1791 */           pushFollow(FOLLOW_condition_expr_in_trans_def695);
/* 1792 */           condition_expr();
/* 1793 */           this.state._fsp--;
/*      */ 
/*      */ 
/*      */           
/*      */           while (true) {
/* 1798 */             int alt30 = 2;
/* 1799 */             int LA30_0 = this.input.LA(1);
/* 1800 */             if (LA30_0 == 16) {
/* 1801 */               alt30 = 1;
/*      */             }
/*      */             
/* 1804 */             switch (alt30) {
/*      */ 
/*      */               
/*      */               case 1:
/* 1808 */                 match((IntStream)this.input, 16, FOLLOW_16_in_trans_def698);
/* 1809 */                 pushFollow(FOLLOW_condition_expr_in_trans_def700);
/* 1810 */                 condition_expr();
/* 1811 */                 this.state._fsp--;
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1826 */       match((IntStream)this.input, 24, FOLLOW_24_in_trans_def706);
/*      */       
/* 1828 */       int alt33 = 2;
/* 1829 */       int LA33_0 = this.input.LA(1);
/* 1830 */       if (LA33_0 == 32) {
/* 1831 */         alt33 = 1;
/*      */       }
/* 1833 */       switch (alt33) {
/*      */ 
/*      */         
/*      */         case 1:
/* 1837 */           pushFollow(FOLLOW_update_expr_in_trans_def711);
/* 1838 */           update_expr();
/* 1839 */           this.state._fsp--;
/*      */ 
/*      */ 
/*      */           
/*      */           while (true) {
/* 1844 */             int alt32 = 2;
/* 1845 */             int LA32_0 = this.input.LA(1);
/* 1846 */             if (LA32_0 == 16) {
/* 1847 */               alt32 = 1;
/*      */             }
/*      */             
/* 1850 */             switch (alt32) {
/*      */ 
/*      */               
/*      */               case 1:
/* 1854 */                 match((IntStream)this.input, 16, FOLLOW_16_in_trans_def714);
/* 1855 */                 pushFollow(FOLLOW_update_expr_in_trans_def717);
/* 1856 */                 update_expr();
/* 1857 */                 this.state._fsp--;
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1873 */       int alt34 = 2;
/* 1874 */       int LA34_0 = this.input.LA(1);
/* 1875 */       if (LA34_0 == 25) {
/* 1876 */         alt34 = 1;
/*      */       }
/* 1878 */       else if (LA34_0 == 24) {
/* 1879 */         alt34 = 2;
/*      */       }
/*      */       else {
/*      */         
/* 1883 */         NoViableAltException nvae = new NoViableAltException("", 34, 0, (IntStream)this.input);
/*      */         
/* 1885 */         throw nvae;
/*      */       } 
/*      */       
/* 1888 */       switch (alt34) {
/*      */ 
/*      */         
/*      */         case 1:
/* 1892 */           match((IntStream)this.input, 25, FOLLOW_25_in_trans_def726);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 1898 */           pushFollow(FOLLOW_trans_function_in_trans_def730);
/* 1899 */           trans_function();
/* 1900 */           this.state._fsp--;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1908 */       if (this.mode == Mode.PARSE) {
/* 1909 */         String transname = this.cp.identifier;
/*      */         
/* 1911 */         this.currentTransId = (short)(this.currentTransId + 1); PNNode transition = new Transition(transname, transname, this.currentTransId);
/*      */         
/* 1913 */         this.pn.allNodes().put(this.cp.identifier, transition);
/* 1914 */         this.pn.identifier().put(transition, this.cp.identifier);
/* 1915 */         this.pn.addTransition((Transition)transition);
/*      */ 
/*      */         
/* 1918 */         List<Tupel> l = this.increases.get(transname);
/* 1919 */         if (l != null) {
/* 1920 */           for (Iterator<Tupel> it = l.iterator(); it.hasNext(); ) {
/* 1921 */             Tupel t = it.next();
/* 1922 */             int weight = t.value;
/* 1923 */             PNNode place = this.pn.lookUp(t.identifier);
/* 1924 */             this.pn.addEdge(transition, place, weight, PlaceTransitionNet.EDGE);
/*      */           } 
/*      */         }
/*      */         
/* 1928 */         l = this.decreases.get(transname);
/* 1929 */         if (l != null) {
/* 1930 */           for (Iterator<Tupel> it = l.iterator(); it.hasNext(); ) {
/* 1931 */             Tupel t = it.next();
/* 1932 */             PNNode place = this.pn.lookUp(t.identifier);
/* 1933 */             int weight = t.value;
/* 1934 */             this.pn.addEdge(place, transition, weight, PlaceTransitionNet.EDGE);
/*      */           } 
/*      */         }
/*      */         
/* 1938 */         l = this.bounds.get(transname);
/* 1939 */         if (l != null) {
/* 1940 */           for (Iterator<Tupel> it = l.iterator(); it.hasNext(); ) {
/* 1941 */             Tupel t = it.next();
/* 1942 */             PNNode place = this.pn.lookUp(t.identifier);
/* 1943 */             int weight = t.value;
/* 1944 */             this.pn.addEdge(place, transition, weight, PlaceTransitionNet.INHIBITOR_EDGE);
/* 1945 */             transition = this.pn.lookUp(transname);
/*      */           } 
/*      */         }
/* 1948 */         l = this.requires.get(transname);
/* 1949 */         if (l != null) {
/* 1950 */           for (Iterator<Tupel> it = l.iterator(); it.hasNext(); ) {
/* 1951 */             Tupel t = it.next();
/* 1952 */             PNNode place = this.pn.lookUp(t.identifier);
/* 1953 */             int weight = t.value;
/* 1954 */             this.pn.addEdge(place, transition, weight, PlaceTransitionNet.READ_EDGE);
/* 1955 */             transition = this.pn.lookUp(transname);
/*      */           } 
/*      */         }
/* 1958 */         l = this.assigns.get(transname);
/*      */         
/* 1960 */         if (l != null) {
/* 1961 */           for (Iterator<Tupel> it = l.iterator(); it.hasNext(); ) {
/* 1962 */             Tupel t = it.next();
/* 1963 */             PNNode place = this.pn.lookUp(t.identifier);
/* 1964 */             int weight = t.value;
/* 1965 */             this.pn.addEdge(place, transition, weight, PlaceTransitionNet.RESET_EDGE);
/* 1966 */             transition = this.pn.lookUp(transname);
/* 1967 */             this.pn.addEdge(transition, place, weight, PlaceTransitionNet.EDGE);
/*      */           } 
/*      */         }
/*      */       } else {
/* 1971 */         this.nrTransitions++;
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1978 */     catch (RecognitionException re) {
/* 1979 */       reportError(re);
/* 1980 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void trans_name() throws RecognitionException {
/*      */     try {
/* 1997 */       pushFollow(FOLLOW_name_in_trans_name746);
/* 1998 */       name();
/* 1999 */       this.state._fsp--;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2004 */     catch (RecognitionException re) {
/* 2005 */       reportError(re);
/* 2006 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void name() throws RecognitionException {
/* 2019 */     Token IDENT6 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2025 */       IDENT6 = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_name757);
/*      */       
/* 2027 */       this.cp.identifier = (IDENT6 != null) ? IDENT6.getText() : null;
/* 2028 */       this.cp.hasValue = false;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2033 */     catch (RecognitionException re) {
/* 2034 */       reportError(re);
/* 2035 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void condition_expr() throws RecognitionException {
/* 2048 */     Token IDENT7 = null;
/* 2049 */     Token IDENT9 = null;
/* 2050 */     Token IDENT11 = null;
/* 2051 */     int integer8 = 0;
/* 2052 */     int integer10 = 0;
/* 2053 */     int integer12 = 0;
/*      */ 
/*      */     
/*      */     try {
/* 2057 */       int alt35 = 4;
/* 2058 */       int LA35_0 = this.input.LA(1);
/* 2059 */       if (LA35_0 == 32) {
/* 2060 */         int LA35_1 = this.input.LA(2);
/* 2061 */         if (LA35_1 == 10) {
/* 2062 */           int nvaeMark; switch (this.input.LA(3)) {
/*      */             
/*      */             case 26:
/* 2065 */               alt35 = 1;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 28:
/* 2070 */               alt35 = 2;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 27:
/* 2075 */               alt35 = 3;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 33:
/* 2080 */               alt35 = 4;
/*      */               break;
/*      */             
/*      */             default:
/* 2084 */               nvaeMark = this.input.mark();
/*      */               try {
/* 2086 */                 for (int nvaeConsume = 0; nvaeConsume < 2; nvaeConsume++) {
/* 2087 */                   this.input.consume();
/*      */                 }
/* 2089 */                 NoViableAltException nvae = new NoViableAltException("", 35, 2, (IntStream)this.input);
/*      */                 
/* 2091 */                 throw nvae;
/*      */               } finally {
/* 2093 */                 this.input.rewind(nvaeMark);
/*      */               } 
/*      */           } 
/*      */ 
/*      */         
/*      */         } else {
/* 2099 */           int nvaeMark = this.input.mark();
/*      */           try {
/* 2101 */             this.input.consume();
/* 2102 */             NoViableAltException nvae = new NoViableAltException("", 35, 1, (IntStream)this.input);
/*      */             
/* 2104 */             throw nvae;
/*      */           } finally {
/* 2106 */             this.input.rewind(nvaeMark);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 2113 */         NoViableAltException nvae = new NoViableAltException("", 35, 0, (IntStream)this.input);
/*      */         
/* 2115 */         throw nvae;
/*      */       } 
/*      */       
/* 2118 */       switch (alt35) {
/*      */ 
/*      */         
/*      */         case 1:
/* 2122 */           match((IntStream)this.input, 32, FOLLOW_32_in_condition_expr772);
/* 2123 */           IDENT7 = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_condition_expr775);
/* 2124 */           match((IntStream)this.input, 26, FOLLOW_26_in_condition_expr778);
/* 2125 */           pushFollow(FOLLOW_integer_in_condition_expr780);
/* 2126 */           integer8 = integer();
/* 2127 */           this.state._fsp--;
/*      */           
/* 2129 */           match((IntStream)this.input, 33, FOLLOW_33_in_condition_expr782);
/*      */           
/* 2131 */           addTupel(this.bounds, this.cp.identifier, new Tupel((IDENT7 != null) ? IDENT7.getText() : null, (new Integer(integer8)).intValue()));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 2138 */           match((IntStream)this.input, 32, FOLLOW_32_in_condition_expr792);
/* 2139 */           IDENT9 = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_condition_expr795);
/* 2140 */           match((IntStream)this.input, 28, FOLLOW_28_in_condition_expr798);
/* 2141 */           pushFollow(FOLLOW_integer_in_condition_expr800);
/* 2142 */           integer10 = integer();
/* 2143 */           this.state._fsp--;
/*      */           
/* 2145 */           match((IntStream)this.input, 33, FOLLOW_33_in_condition_expr802);
/*      */           
/* 2147 */           addTupel(this.requires, this.cp.identifier, new Tupel((IDENT9 != null) ? IDENT9.getText() : null, (new Integer(integer10)).intValue()));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 3:
/* 2154 */           match((IntStream)this.input, 32, FOLLOW_32_in_condition_expr811);
/* 2155 */           IDENT11 = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_condition_expr814);
/* 2156 */           match((IntStream)this.input, 27, FOLLOW_27_in_condition_expr816);
/* 2157 */           pushFollow(FOLLOW_integer_in_condition_expr818);
/* 2158 */           integer12 = integer();
/* 2159 */           this.state._fsp--;
/*      */           
/* 2161 */           match((IntStream)this.input, 33, FOLLOW_33_in_condition_expr820);
/*      */           
/* 2163 */           addTupel(this.requires, this.cp.identifier, new Tupel((IDENT11 != null) ? IDENT11.getText() : null, (new Integer(integer12)).intValue()));
/* 2164 */           addTupel(this.bounds, this.cp.identifier, new Tupel((IDENT11 != null) ? IDENT11.getText() : null, (new Integer(integer12 + 1)).intValue()));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/* 2171 */           match((IntStream)this.input, 32, FOLLOW_32_in_condition_expr828);
/* 2172 */           match((IntStream)this.input, 10, FOLLOW_IDENT_in_condition_expr831);
/* 2173 */           match((IntStream)this.input, 33, FOLLOW_33_in_condition_expr833);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2180 */     } catch (RecognitionException re) {
/* 2181 */       reportError(re);
/* 2182 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void update_expr() throws RecognitionException {
/* 2195 */     Token IDENT13 = null;
/* 2196 */     Token IDENT15 = null;
/* 2197 */     Token IDENT17 = null;
/* 2198 */     int integer14 = 0;
/* 2199 */     int integer16 = 0;
/* 2200 */     int integer18 = 0;
/*      */ 
/*      */     
/*      */     try {
/* 2204 */       int alt36 = 3;
/* 2205 */       int LA36_0 = this.input.LA(1);
/* 2206 */       if (LA36_0 == 32) {
/* 2207 */         int LA36_1 = this.input.LA(2);
/* 2208 */         if (LA36_1 == 10) {
/* 2209 */           int nvaeMark; switch (this.input.LA(3)) {
/*      */             
/*      */             case 20:
/* 2212 */               alt36 = 1;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 22:
/* 2217 */               alt36 = 2;
/*      */               break;
/*      */ 
/*      */             
/*      */             case 27:
/* 2222 */               alt36 = 3;
/*      */               break;
/*      */             
/*      */             default:
/* 2226 */               nvaeMark = this.input.mark();
/*      */               try {
/* 2228 */                 for (int nvaeConsume = 0; nvaeConsume < 2; nvaeConsume++) {
/* 2229 */                   this.input.consume();
/*      */                 }
/* 2231 */                 NoViableAltException nvae = new NoViableAltException("", 36, 2, (IntStream)this.input);
/*      */                 
/* 2233 */                 throw nvae;
/*      */               } finally {
/* 2235 */                 this.input.rewind(nvaeMark);
/*      */               } 
/*      */           } 
/*      */ 
/*      */         
/*      */         } else {
/* 2241 */           int nvaeMark = this.input.mark();
/*      */           try {
/* 2243 */             this.input.consume();
/* 2244 */             NoViableAltException nvae = new NoViableAltException("", 36, 1, (IntStream)this.input);
/*      */             
/* 2246 */             throw nvae;
/*      */           } finally {
/* 2248 */             this.input.rewind(nvaeMark);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 2255 */         NoViableAltException nvae = new NoViableAltException("", 36, 0, (IntStream)this.input);
/*      */         
/* 2257 */         throw nvae;
/*      */       } 
/*      */       
/* 2260 */       switch (alt36) {
/*      */ 
/*      */         
/*      */         case 1:
/* 2264 */           match((IntStream)this.input, 32, FOLLOW_32_in_update_expr850);
/* 2265 */           IDENT13 = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_update_expr852);
/* 2266 */           match((IntStream)this.input, 20, FOLLOW_20_in_update_expr854);
/* 2267 */           pushFollow(FOLLOW_integer_in_update_expr856);
/* 2268 */           integer14 = integer();
/* 2269 */           this.state._fsp--;
/*      */           
/* 2271 */           match((IntStream)this.input, 33, FOLLOW_33_in_update_expr858);
/*      */           
/* 2273 */           addTupel(this.increases, this.cp.identifier, new Tupel((IDENT13 != null) ? IDENT13.getText() : null, (new Integer(integer14)).intValue()));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 2280 */           match((IntStream)this.input, 32, FOLLOW_32_in_update_expr867);
/* 2281 */           IDENT15 = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_update_expr869);
/* 2282 */           match((IntStream)this.input, 22, FOLLOW_22_in_update_expr871);
/* 2283 */           pushFollow(FOLLOW_integer_in_update_expr873);
/* 2284 */           integer16 = integer();
/* 2285 */           this.state._fsp--;
/*      */           
/* 2287 */           match((IntStream)this.input, 33, FOLLOW_33_in_update_expr875);
/*      */           
/* 2289 */           addTupel(this.decreases, this.cp.identifier, new Tupel((IDENT15 != null) ? IDENT15.getText() : null, (new Integer(integer16)).intValue()));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 3:
/* 2296 */           match((IntStream)this.input, 32, FOLLOW_32_in_update_expr884);
/* 2297 */           IDENT17 = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_update_expr886);
/* 2298 */           match((IntStream)this.input, 27, FOLLOW_27_in_update_expr888);
/* 2299 */           pushFollow(FOLLOW_integer_in_update_expr890);
/* 2300 */           integer18 = integer();
/* 2301 */           this.state._fsp--;
/*      */           
/* 2303 */           match((IntStream)this.input, 33, FOLLOW_33_in_update_expr892);
/*      */           
/* 2305 */           addTupel(this.assigns, this.cp.identifier, new Tupel((IDENT17 != null) ? IDENT17.getText() : null, (new Integer(integer18)).intValue()));
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2312 */     } catch (RecognitionException re) {
/* 2313 */       reportError(re);
/* 2314 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void trans_function() throws RecognitionException {
/*      */     try {
/* 2331 */       match((IntStream)this.input, 24, FOLLOW_24_in_trans_function907);
/*      */ 
/*      */       
/*      */       while (true) {
/* 2335 */         int alt37 = 2;
/* 2336 */         int LA37_0 = this.input.LA(1);
/* 2337 */         if (LA37_0 == 25) {
/* 2338 */           alt37 = 2;
/*      */         }
/* 2340 */         else if ((LA37_0 >= 4 && LA37_0 <= 24) || (LA37_0 >= 26 && LA37_0 <= 64)) {
/* 2341 */           alt37 = 1;
/*      */         } 
/*      */         
/* 2344 */         switch (alt37) {
/*      */ 
/*      */           
/*      */           case 1:
/* 2348 */             matchAny((IntStream)this.input);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2357 */       match((IntStream)this.input, 25, FOLLOW_25_in_trans_function914);
/*      */ 
/*      */     
/*      */     }
/* 2361 */     catch (RecognitionException re) {
/* 2362 */       reportError(re);
/* 2363 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void pattern() throws RecognitionException {
/*      */     try {
/*      */       NoViableAltException nvae;
/* 2378 */       int alt38 = 3;
/* 2379 */       switch (this.input.LA(1)) {
/*      */         
/*      */         case 30:
/* 2382 */           alt38 = 1;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 29:
/* 2387 */           alt38 = 2;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 31:
/* 2392 */           alt38 = 3;
/*      */           break;
/*      */         
/*      */         default:
/* 2396 */           nvae = new NoViableAltException("", 38, 0, (IntStream)this.input);
/*      */           
/* 2398 */           throw nvae;
/*      */       } 
/* 2400 */       switch (alt38) {
/*      */ 
/*      */         
/*      */         case 1:
/* 2404 */           match((IntStream)this.input, 30, FOLLOW_30_in_pattern924);
/* 2405 */           match((IntStream)this.input, 17, FOLLOW_17_in_pattern926);
/* 2406 */           pushFollow(FOLLOW_arithmetic_function_in_pattern928);
/* 2407 */           arithmetic_function();
/* 2408 */           this.state._fsp--;
/*      */           
/* 2410 */           match((IntStream)this.input, 18, FOLLOW_18_in_pattern930);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 2416 */           match((IntStream)this.input, 29, FOLLOW_29_in_pattern935);
/* 2417 */           match((IntStream)this.input, 17, FOLLOW_17_in_pattern937);
/* 2418 */           pushFollow(FOLLOW_arithmetic_function_in_pattern939);
/* 2419 */           arithmetic_function();
/* 2420 */           this.state._fsp--;
/*      */           
/* 2422 */           match((IntStream)this.input, 21, FOLLOW_21_in_pattern941);
/* 2423 */           pushFollow(FOLLOW_arithmetic_function_in_pattern943);
/* 2424 */           arithmetic_function();
/* 2425 */           this.state._fsp--;
/*      */           
/* 2427 */           match((IntStream)this.input, 18, FOLLOW_18_in_pattern945);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 3:
/* 2433 */           match((IntStream)this.input, 31, FOLLOW_31_in_pattern950);
/* 2434 */           match((IntStream)this.input, 17, FOLLOW_17_in_pattern952);
/* 2435 */           pushFollow(FOLLOW_arithmetic_function_in_pattern954);
/* 2436 */           arithmetic_function();
/* 2437 */           this.state._fsp--;
/*      */           
/* 2439 */           match((IntStream)this.input, 21, FOLLOW_21_in_pattern956);
/* 2440 */           pushFollow(FOLLOW_arithmetic_function_in_pattern958);
/* 2441 */           arithmetic_function();
/* 2442 */           this.state._fsp--;
/*      */           
/* 2444 */           match((IntStream)this.input, 18, FOLLOW_18_in_pattern960);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/* 2450 */     } catch (RecognitionException re) {
/* 2451 */       reportError(re);
/* 2452 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int integer() throws RecognitionException {
/* 2465 */     int value = 0;
/*      */ 
/*      */     
/* 2468 */     AbstractExpr arithmetic_function19 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2474 */       pushFollow(FOLLOW_arithmetic_function_in_integer975);
/* 2475 */       arithmetic_function19 = arithmetic_function();
/* 2476 */       this.state._fsp--;
/*      */ 
/*      */       
/* 2479 */       if (this.mode == Mode.PARSE) {
/*      */         try {
/* 2481 */           Number result = arithmetic_function19.eval(this.argument);
/* 2482 */           value = (int)Math.ceil(result.doubleValue());
/* 2483 */         } catch (Exception e) {
/* 2484 */           Out.println(e.getMessage());
/* 2485 */           throw new RecognitionException();
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */     }
/* 2492 */     catch (RecognitionException re) {
/* 2493 */       reportError(re);
/* 2494 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */     
/* 2499 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final double real() throws RecognitionException {
/* 2508 */     double value = 0.0D;
/*      */ 
/*      */     
/* 2511 */     AbstractExpr arithmetic_function20 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2517 */       pushFollow(FOLLOW_arithmetic_function_in_real994);
/* 2518 */       arithmetic_function20 = arithmetic_function();
/* 2519 */       this.state._fsp--;
/*      */ 
/*      */       
/* 2522 */       if (this.mode == Mode.PARSE) {
/*      */         try {
/* 2524 */           Number result = arithmetic_function20.eval(this.argument);
/* 2525 */           value = result.doubleValue();
/* 2526 */         } catch (Exception e) {
/* 2527 */           Out.println(e.getMessage());
/* 2528 */           throw new RecognitionException();
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */     }
/* 2535 */     catch (Exception e) {
/*      */       
/* 2537 */       throw new RecognitionException();
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2544 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AbstractExpr arithmetic_function() throws RecognitionException {
/*      */     SubExpr subExpr;
/* 2553 */     AbstractExpr node = null;
/*      */ 
/*      */     
/* 2556 */     AbstractExpr e = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2562 */       pushFollow(FOLLOW_term_in_arithmetic_function1018);
/* 2563 */       e = term();
/* 2564 */       this.state._fsp--;
/*      */       
/* 2566 */       node = e; while (true) {
/*      */         AddExpr addExpr1;
/*      */         AbstractExpr tmp;
/*      */         AddExpr addExpr2;
/* 2570 */         int alt39 = 3;
/* 2571 */         int LA39_0 = this.input.LA(1);
/* 2572 */         if (LA39_0 == 20) {
/* 2573 */           alt39 = 1;
/*      */         }
/* 2575 */         else if (LA39_0 == 22) {
/* 2576 */           alt39 = 2;
/*      */         } 
/*      */         
/* 2579 */         switch (alt39) {
/*      */ 
/*      */           
/*      */           case 1:
/* 2583 */             match((IntStream)this.input, 20, FOLLOW_20_in_arithmetic_function1026);
/* 2584 */             pushFollow(FOLLOW_term_in_arithmetic_function1030);
/* 2585 */             e = term();
/* 2586 */             this.state._fsp--;
/*      */ 
/*      */             
/* 2589 */             tmp = node;
/* 2590 */             addExpr1 = new AddExpr(tmp, e);
/*      */             continue;
/*      */ 
/*      */ 
/*      */           
/*      */           case 2:
/* 2596 */             match((IntStream)this.input, 22, FOLLOW_22_in_arithmetic_function1037);
/* 2597 */             pushFollow(FOLLOW_term_in_arithmetic_function1041);
/* 2598 */             e = term();
/* 2599 */             this.state._fsp--;
/*      */ 
/*      */             
/* 2602 */             addExpr2 = addExpr1;
/* 2603 */             subExpr = new SubExpr((AbstractExpr)addExpr2, e);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2615 */     } catch (Exception ee) {
/*      */ 
/*      */ 
/*      */       
/* 2619 */       throw new RecognitionException();
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2626 */     return (AbstractExpr)subExpr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AbstractExpr term() throws RecognitionException {
/*      */     DivExpr divExpr;
/* 2635 */     AbstractExpr node = null;
/*      */ 
/*      */     
/* 2638 */     AbstractExpr e = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2644 */       pushFollow(FOLLOW_factor_in_term1069);
/* 2645 */       e = factor();
/* 2646 */       this.state._fsp--;
/*      */       
/* 2648 */       node = e; while (true) {
/*      */         MulExpr mulExpr1;
/*      */         AbstractExpr tmp;
/*      */         MulExpr mulExpr2;
/* 2652 */         int alt40 = 3;
/* 2653 */         int LA40_0 = this.input.LA(1);
/* 2654 */         if (LA40_0 == 19) {
/* 2655 */           alt40 = 1;
/*      */         }
/* 2657 */         else if (LA40_0 == 23) {
/* 2658 */           alt40 = 2;
/*      */         } 
/*      */         
/* 2661 */         switch (alt40) {
/*      */ 
/*      */           
/*      */           case 1:
/* 2665 */             match((IntStream)this.input, 19, FOLLOW_19_in_term1077);
/* 2666 */             pushFollow(FOLLOW_factor_in_term1081);
/* 2667 */             e = factor();
/* 2668 */             this.state._fsp--;
/*      */ 
/*      */             
/* 2671 */             tmp = node;
/* 2672 */             mulExpr1 = new MulExpr(tmp, e);
/*      */             continue;
/*      */ 
/*      */ 
/*      */           
/*      */           case 2:
/* 2678 */             match((IntStream)this.input, 23, FOLLOW_23_in_term1088);
/* 2679 */             pushFollow(FOLLOW_factor_in_term1092);
/* 2680 */             e = factor();
/* 2681 */             this.state._fsp--;
/*      */ 
/*      */             
/* 2684 */             mulExpr2 = mulExpr1;
/* 2685 */             divExpr = new DivExpr((AbstractExpr)mulExpr2, e);
/*      */             continue;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/* 2697 */     } catch (Exception ee) {
/*      */ 
/*      */ 
/*      */       
/* 2701 */       throw new RecognitionException();
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2708 */     return (AbstractExpr)divExpr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AbstractExpr factor() throws RecognitionException {
/*      */     TerminalExpr terminalExpr1;
/* 2717 */     AbstractExpr node = null;
/*      */ 
/*      */     
/* 2720 */     AbstractExpr e = null;
/* 2721 */     AbstractExpr arithmetic_function21 = null;
/* 2722 */     NonTerminalExpr func_122 = null;
/* 2723 */     NonTerminalExpr func_223 = null;
/* 2724 */     NonTerminalExpr user_defined24 = null;
/* 2725 */     TerminalExpr atomic25 = null; try {
/*      */       UMinusExpr uMinusExpr; NonTerminalExpr nonTerminalExpr;
/*      */       int LA41_5;
/*      */       NoViableAltException nvae;
/* 2729 */       int nvaeMark, alt41 = 6;
/* 2730 */       switch (this.input.LA(1)) {
/*      */         
/*      */         case 17:
/* 2733 */           alt41 = 1;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 22:
/* 2738 */           alt41 = 2;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 34:
/* 2743 */           alt41 = 3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 47:
/*      */         case 48:
/* 2749 */           alt41 = 4;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 10:
/* 2754 */           LA41_5 = this.input.LA(2);
/* 2755 */           if (LA41_5 == 17) {
/* 2756 */             alt41 = 5; break;
/*      */           } 
/* 2758 */           if ((LA41_5 >= 18 && LA41_5 <= 25) || LA41_5 == 33) {
/* 2759 */             alt41 = 6;
/*      */             
/*      */             break;
/*      */           } 
/* 2763 */           nvaeMark = this.input.mark();
/*      */           try {
/* 2765 */             this.input.consume();
/* 2766 */             NoViableAltException noViableAltException = new NoViableAltException("", 41, 5, (IntStream)this.input);
/*      */             
/* 2768 */             throw noViableAltException;
/*      */           } finally {
/* 2770 */             this.input.rewind(nvaeMark);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*      */         case 9:
/*      */         case 11:
/* 2781 */           alt41 = 6;
/*      */           break;
/*      */         
/*      */         default:
/* 2785 */           nvae = new NoViableAltException("", 41, 0, (IntStream)this.input);
/*      */           
/* 2787 */           throw nvae;
/*      */       } 
/* 2789 */       switch (alt41) {
/*      */ 
/*      */         
/*      */         case 1:
/* 2793 */           match((IntStream)this.input, 17, FOLLOW_17_in_factor1116);
/* 2794 */           pushFollow(FOLLOW_arithmetic_function_in_factor1118);
/* 2795 */           arithmetic_function21 = arithmetic_function();
/* 2796 */           this.state._fsp--;
/*      */           
/* 2798 */           match((IntStream)this.input, 18, FOLLOW_18_in_factor1120);
/*      */           
/* 2800 */           node = arithmetic_function21;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 2807 */           match((IntStream)this.input, 22, FOLLOW_22_in_factor1129);
/* 2808 */           pushFollow(FOLLOW_factor_in_factor1133);
/* 2809 */           e = factor();
/* 2810 */           this.state._fsp--;
/*      */ 
/*      */           
/* 2813 */           uMinusExpr = new UMinusExpr(e);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 3:
/* 2820 */           pushFollow(FOLLOW_func_1_in_factor1141);
/* 2821 */           func_122 = func_1();
/* 2822 */           this.state._fsp--;
/*      */ 
/*      */           
/* 2825 */           nonTerminalExpr = func_122;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/* 2832 */           pushFollow(FOLLOW_func_2_in_factor1150);
/* 2833 */           func_223 = func_2();
/* 2834 */           this.state._fsp--;
/*      */ 
/*      */           
/* 2837 */           nonTerminalExpr = func_223;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 5:
/* 2844 */           pushFollow(FOLLOW_user_defined_in_factor1159);
/* 2845 */           user_defined24 = user_defined();
/* 2846 */           this.state._fsp--;
/*      */ 
/*      */           
/* 2849 */           nonTerminalExpr = user_defined24;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 6:
/* 2856 */           pushFollow(FOLLOW_atomic_in_factor1168);
/* 2857 */           atomic25 = atomic();
/* 2858 */           this.state._fsp--;
/*      */ 
/*      */           
/* 2861 */           terminalExpr1 = atomic25;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2868 */     } catch (Exception ee) {
/*      */ 
/*      */ 
/*      */       
/* 2872 */       throw new RecognitionException();
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2879 */     return (AbstractExpr)terminalExpr1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final NonTerminalExpr func_1() throws RecognitionException {
/*      */     AbsExpr absExpr;
/* 2888 */     NonTerminalExpr node = null;
/*      */ 
/*      */     
/* 2891 */     AbstractExpr e = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2897 */       match((IntStream)this.input, 34, FOLLOW_34_in_func_11190);
/* 2898 */       match((IntStream)this.input, 17, FOLLOW_17_in_func_11192);
/* 2899 */       pushFollow(FOLLOW_arithmetic_function_in_func_11196);
/* 2900 */       e = arithmetic_function();
/* 2901 */       this.state._fsp--;
/*      */       
/* 2903 */       match((IntStream)this.input, 18, FOLLOW_18_in_func_11198);
/*      */       
/* 2905 */       absExpr = new AbsExpr(e);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2910 */     catch (RecognitionException re) {
/* 2911 */       reportError(re);
/* 2912 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */     
/* 2917 */     return (NonTerminalExpr)absExpr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final NonTerminalExpr func_2() throws RecognitionException {
/*      */     MaxExpr maxExpr;
/* 2926 */     NonTerminalExpr node = null;
/*      */ 
/*      */     
/* 2929 */     AbstractExpr e1 = null;
/* 2930 */     AbstractExpr e2 = null;
/*      */     
/*      */     try {
/*      */       MinExpr minExpr;
/* 2934 */       int alt42 = 2;
/* 2935 */       int LA42_0 = this.input.LA(1);
/* 2936 */       if (LA42_0 == 48) {
/* 2937 */         alt42 = 1;
/*      */       }
/* 2939 */       else if (LA42_0 == 47) {
/* 2940 */         alt42 = 2;
/*      */       }
/*      */       else {
/*      */         
/* 2944 */         NoViableAltException nvae = new NoViableAltException("", 42, 0, (IntStream)this.input);
/*      */         
/* 2946 */         throw nvae;
/*      */       } 
/*      */       
/* 2949 */       switch (alt42) {
/*      */ 
/*      */         
/*      */         case 1:
/* 2953 */           match((IntStream)this.input, 48, FOLLOW_48_in_func_21216);
/* 2954 */           match((IntStream)this.input, 17, FOLLOW_17_in_func_21218);
/* 2955 */           pushFollow(FOLLOW_arithmetic_function_in_func_21222);
/* 2956 */           e1 = arithmetic_function();
/* 2957 */           this.state._fsp--;
/*      */           
/* 2959 */           match((IntStream)this.input, 21, FOLLOW_21_in_func_21224);
/* 2960 */           pushFollow(FOLLOW_arithmetic_function_in_func_21228);
/* 2961 */           e2 = arithmetic_function();
/* 2962 */           this.state._fsp--;
/*      */           
/* 2964 */           match((IntStream)this.input, 18, FOLLOW_18_in_func_21230);
/*      */           
/* 2966 */           minExpr = new MinExpr(e1, e2);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 2973 */           match((IntStream)this.input, 47, FOLLOW_47_in_func_21238);
/* 2974 */           match((IntStream)this.input, 17, FOLLOW_17_in_func_21240);
/* 2975 */           pushFollow(FOLLOW_arithmetic_function_in_func_21244);
/* 2976 */           e1 = arithmetic_function();
/* 2977 */           this.state._fsp--;
/*      */           
/* 2979 */           match((IntStream)this.input, 21, FOLLOW_21_in_func_21246);
/* 2980 */           pushFollow(FOLLOW_arithmetic_function_in_func_21250);
/* 2981 */           e2 = arithmetic_function();
/* 2982 */           this.state._fsp--;
/*      */           
/* 2984 */           match((IntStream)this.input, 18, FOLLOW_18_in_func_21252);
/*      */           
/* 2986 */           maxExpr = new MaxExpr(e1, e2);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2993 */     } catch (RecognitionException re) {
/* 2994 */       reportError(re);
/* 2995 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */     
/* 3000 */     return (NonTerminalExpr)maxExpr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final NonTerminalExpr user_defined() throws RecognitionException {
/*      */     UserDefExpr userDefExpr;
/* 3009 */     NonTerminalExpr node = null;
/*      */ 
/*      */     
/* 3012 */     Token IDENT26 = null;
/* 3013 */     AbstractExpr a1 = null;
/* 3014 */     AbstractExpr a2 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3020 */       IDENT26 = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_user_defined1269);
/* 3021 */       match((IntStream)this.input, 17, FOLLOW_17_in_user_defined1271);
/* 3022 */       ArrayList<AbstractExpr> params = new ArrayList<>();
/*      */       
/* 3024 */       int alt44 = 2;
/* 3025 */       int LA44_0 = this.input.LA(1);
/* 3026 */       if ((LA44_0 >= 7 && LA44_0 <= 11) || LA44_0 == 17 || LA44_0 == 22 || LA44_0 == 34 || (LA44_0 >= 47 && LA44_0 <= 48)) {
/* 3027 */         alt44 = 1;
/*      */       }
/* 3029 */       switch (alt44) {
/*      */ 
/*      */         
/*      */         case 1:
/* 3033 */           pushFollow(FOLLOW_arithmetic_function_in_user_defined1282);
/* 3034 */           a1 = arithmetic_function();
/* 3035 */           this.state._fsp--;
/*      */           
/* 3037 */           params.add(a1);
/*      */ 
/*      */           
/*      */           while (true) {
/* 3041 */             int alt43 = 2;
/* 3042 */             int LA43_0 = this.input.LA(1);
/* 3043 */             if (LA43_0 == 21) {
/* 3044 */               alt43 = 1;
/*      */             }
/*      */             
/* 3047 */             switch (alt43) {
/*      */ 
/*      */               
/*      */               case 1:
/* 3051 */                 match((IntStream)this.input, 21, FOLLOW_21_in_user_defined1293);
/* 3052 */                 pushFollow(FOLLOW_arithmetic_function_in_user_defined1298);
/* 3053 */                 a2 = arithmetic_function();
/* 3054 */                 this.state._fsp--;
/*      */                 
/* 3056 */                 params.add(a2);
/*      */                 continue;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3070 */       match((IntStream)this.input, 18, FOLLOW_18_in_user_defined1311);
/*      */       
/* 3072 */       String name = (IDENT26 != null) ? IDENT26.getText() : null;
/*      */       
/*      */       try {
/* 3075 */         Function f = this.functions.lookUpFunction(name);
/* 3076 */         if (f.getParam().size() == params.size()) {
/* 3077 */           userDefExpr = new UserDefExpr(name, f.getBody(), f.getParam(), params);
/*      */         } else {
/* 3079 */           throw new RecognitionException();
/*      */         } 
/* 3081 */       } catch (Exception e) {
/*      */         
/* 3083 */         throw new RecognitionException();
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 3089 */     catch (RecognitionException re) {
/* 3090 */       reportError(re);
/* 3091 */       recover((IntStream)this.input, re);
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */     
/* 3096 */     return (NonTerminalExpr)userDefExpr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final TerminalExpr atomic() throws RecognitionException {
/*      */     Variable variable;
/* 3105 */     TerminalExpr node = null;
/*      */ 
/*      */     
/* 3108 */     Token FLOAT127 = null;
/* 3109 */     Token FLOAT228 = null;
/* 3110 */     Token FLOAT329 = null;
/* 3111 */     Token INT30 = null;
/* 3112 */     Token IDENT31 = null;
/*      */     try {
/*      */       Literal literal;
/*      */       NoViableAltException nvae;
/* 3116 */       int alt45 = 5;
/* 3117 */       switch (this.input.LA(1)) {
/*      */         
/*      */         case 7:
/* 3120 */           alt45 = 1;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/* 3125 */           alt45 = 2;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/* 3130 */           alt45 = 3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 11:
/* 3135 */           alt45 = 4;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 10:
/* 3140 */           alt45 = 5;
/*      */           break;
/*      */         
/*      */         default:
/* 3144 */           nvae = new NoViableAltException("", 45, 0, (IntStream)this.input);
/*      */           
/* 3146 */           throw nvae;
/*      */       } 
/* 3148 */       switch (alt45) {
/*      */ 
/*      */         
/*      */         case 1:
/* 3152 */           FLOAT127 = (Token)match((IntStream)this.input, 7, FOLLOW_FLOAT1_in_atomic1329);
/*      */           
/* 3154 */           literal = new Literal(Double.valueOf((FLOAT127 != null) ? FLOAT127.getText() : null));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/* 3161 */           FLOAT228 = (Token)match((IntStream)this.input, 8, FOLLOW_FLOAT2_in_atomic1338);
/*      */           
/* 3163 */           literal = new Literal(Double.valueOf((FLOAT228 != null) ? FLOAT228.getText() : null));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 3:
/* 3170 */           FLOAT329 = (Token)match((IntStream)this.input, 9, FOLLOW_FLOAT3_in_atomic1347);
/*      */           
/* 3172 */           literal = new Literal(Double.valueOf((FLOAT329 != null) ? FLOAT329.getText() : null));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/* 3179 */           INT30 = (Token)match((IntStream)this.input, 11, FOLLOW_INT_in_atomic1356);
/*      */           
/* 3181 */           literal = new Literal(Integer.valueOf((INT30 != null) ? INT30.getText() : null));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 5:
/* 3188 */           IDENT31 = (Token)match((IntStream)this.input, 10, FOLLOW_IDENT_in_atomic1365);
/*      */           
/* 3190 */           variable = new Variable((IDENT31 != null) ? IDENT31.getText() : null);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3197 */     } catch (Exception ee) {
/*      */ 
/*      */       
/* 3200 */       throw new RecognitionException();
/*      */     } finally {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3207 */     return (TerminalExpr)variable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3215 */   public static final BitSet FOLLOW_net_type_in_start36 = new BitSet(new long[] { 4294967296L });
/* 3216 */   public static final BitSet FOLLOW_32_in_start38 = new BitSet(new long[] { 1024L });
/* 3217 */   public static final BitSet FOLLOW_IDENT_in_start40 = new BitSet(new long[] { 8589934592L });
/* 3218 */   public static final BitSet FOLLOW_33_in_start42 = new BitSet(new long[] { Long.MIN_VALUE });
/* 3219 */   public static final BitSet FOLLOW_63_in_start46 = new BitSet(new long[] { 2256232219934720L });
/* 3220 */   public static final BitSet FOLLOW_net_in_start48 = new BitSet(new long[] { 0L, 1L });
/* 3221 */   public static final BitSet FOLLOW_64_in_start50 = new BitSet(new long[] { 2L });
/* 3222 */   public static final BitSet FOLLOW_52_in_net_type63 = new BitSet(new long[] { 2L });
/* 3223 */   public static final BitSet FOLLOW_61_in_net_type71 = new BitSet(new long[] { 2L });
/* 3224 */   public static final BitSet FOLLOW_55_in_net_type79 = new BitSet(new long[] { 2L });
/* 3225 */   public static final BitSet FOLLOW_43_in_net_type87 = new BitSet(new long[] { 2L });
/* 3226 */   public static final BitSet FOLLOW_62_in_net_type95 = new BitSet(new long[] { 2L });
/* 3227 */   public static final BitSet FOLLOW_37_in_net_type102 = new BitSet(new long[] { 2L });
/* 3228 */   public static final BitSet FOLLOW_44_in_net_type110 = new BitSet(new long[] { 2L });
/* 3229 */   public static final BitSet FOLLOW_57_in_net_type118 = new BitSet(new long[] { 2L });
/* 3230 */   public static final BitSet FOLLOW_functions_in_net134 = new BitSet(new long[] { 2251834173423616L });
/* 3231 */   public static final BitSet FOLLOW_constants_in_net139 = new BitSet(new long[] { 2251799813685248L });
/* 3232 */   public static final BitSet FOLLOW_places_in_net143 = new BitSet(new long[] { 577023702256844800L });
/* 3233 */   public static final BitSet FOLLOW_observers_in_net146 = new BitSet(new long[] { 576460752303423488L });
/* 3234 */   public static final BitSet FOLLOW_transitions_in_net150 = new BitSet(new long[] { 2L });
/* 3235 */   public static final BitSet FOLLOW_42_in_functions163 = new BitSet(new long[] { 16777216L });
/* 3236 */   public static final BitSet FOLLOW_24_in_functions165 = new BitSet(new long[] { 1026L });
/* 3237 */   public static final BitSet FOLLOW_function_def_in_functions168 = new BitSet(new long[] { 1026L });
/* 3238 */   public static final BitSet FOLLOW_function_name_in_function_def182 = new BitSet(new long[] { 131072L });
/* 3239 */   public static final BitSet FOLLOW_17_in_function_def184 = new BitSet(new long[] { 263168L });
/* 3240 */   public static final BitSet FOLLOW_function_param_in_function_def186 = new BitSet(new long[] { 262144L });
/* 3241 */   public static final BitSet FOLLOW_18_in_function_def189 = new BitSet(new long[] { 134217728L });
/* 3242 */   public static final BitSet FOLLOW_27_in_function_def191 = new BitSet(new long[] { 422229649264512L });
/* 3243 */   public static final BitSet FOLLOW_arithmetic_function_in_function_def193 = new BitSet(new long[] { 33554432L });
/* 3244 */   public static final BitSet FOLLOW_25_in_function_def195 = new BitSet(new long[] { 2L });
/* 3245 */   public static final BitSet FOLLOW_IDENT_in_function_name209 = new BitSet(new long[] { 2L });
/* 3246 */   public static final BitSet FOLLOW_IDENT_in_function_param226 = new BitSet(new long[] { 2097154L });
/* 3247 */   public static final BitSet FOLLOW_21_in_function_param235 = new BitSet(new long[] { 1024L });
/* 3248 */   public static final BitSet FOLLOW_IDENT_in_function_param239 = new BitSet(new long[] { 2097154L });
/* 3249 */   public static final BitSet FOLLOW_35_in_constants256 = new BitSet(new long[] { 16777216L });
/* 3250 */   public static final BitSet FOLLOW_24_in_constants258 = new BitSet(new long[] { 1152992972862653442L });
/* 3251 */   public static final BitSet FOLLOW_valuesets_in_constants261 = new BitSet(new long[] { 71468255806466L });
/* 3252 */   public static final BitSet FOLLOW_constant_def_in_constants266 = new BitSet(new long[] { 71468255806466L });
/* 3253 */   public static final BitSet FOLLOW_name_in_group280 = new BitSet(new long[] { 2L });
/* 3254 */   public static final BitSet FOLLOW_60_in_valuesets294 = new BitSet(new long[] { 4294967296L });
/* 3255 */   public static final BitSet FOLLOW_32_in_valuesets296 = new BitSet(new long[] { 1024L });
/* 3256 */   public static final BitSet FOLLOW_name_in_valuesets298 = new BitSet(new long[] { 8606711808L });
/* 3257 */   public static final BitSet FOLLOW_24_in_valuesets301 = new BitSet(new long[] { 1024L });
/* 3258 */   public static final BitSet FOLLOW_name_in_valuesets303 = new BitSet(new long[] { 8606711808L });
/* 3259 */   public static final BitSet FOLLOW_33_in_valuesets307 = new BitSet(new long[] { 2L });
/* 3260 */   public static final BitSet FOLLOW_group_in_constant_def320 = new BitSet(new long[] { 16777216L });
/* 3261 */   public static final BitSet FOLLOW_24_in_constant_def322 = new BitSet(new long[] { 70368744177664L });
/* 3262 */   public static final BitSet FOLLOW_46_in_constant_def326 = new BitSet(new long[] { 1024L });
/* 3263 */   public static final BitSet FOLLOW_name_in_constant_def328 = new BitSet(new long[] { 167772160L });
/* 3264 */   public static final BitSet FOLLOW_27_in_constant_def331 = new BitSet(new long[] { 422233944231808L });
/* 3265 */   public static final BitSet FOLLOW_int_const_init_in_constant_def333 = new BitSet(new long[] { 33554432L });
/* 3266 */   public static final BitSet FOLLOW_25_in_constant_def337 = new BitSet(new long[] { 2L });
/* 3267 */   public static final BitSet FOLLOW_group_in_constant_def347 = new BitSet(new long[] { 16777216L });
/* 3268 */   public static final BitSet FOLLOW_24_in_constant_def349 = new BitSet(new long[] { 1099511627776L });
/* 3269 */   public static final BitSet FOLLOW_40_in_constant_def353 = new BitSet(new long[] { 1024L });
/* 3270 */   public static final BitSet FOLLOW_name_in_constant_def355 = new BitSet(new long[] { 167772160L });
/* 3271 */   public static final BitSet FOLLOW_27_in_constant_def358 = new BitSet(new long[] { 422233944231808L });
/* 3272 */   public static final BitSet FOLLOW_double_const_init_in_constant_def360 = new BitSet(new long[] { 33554432L });
/* 3273 */   public static final BitSet FOLLOW_25_in_constant_def364 = new BitSet(new long[] { 2L });
/* 3274 */   public static final BitSet FOLLOW_integer_in_int_const_init381 = new BitSet(new long[] { 2L });
/* 3275 */   public static final BitSet FOLLOW_32_in_int_const_init389 = new BitSet(new long[] { 422229649264512L });
/* 3276 */   public static final BitSet FOLLOW_integer_in_int_const_init393 = new BitSet(new long[] { 8606711808L });
/* 3277 */   public static final BitSet FOLLOW_24_in_int_const_init398 = new BitSet(new long[] { 422238255976320L });
/* 3278 */   public static final BitSet FOLLOW_integer_in_int_const_init400 = new BitSet(new long[] { 8606711808L });
/* 3279 */   public static final BitSet FOLLOW_33_in_int_const_init405 = new BitSet(new long[] { 2L });
/* 3280 */   public static final BitSet FOLLOW_real_in_double_const_init420 = new BitSet(new long[] { 2L });
/* 3281 */   public static final BitSet FOLLOW_32_in_double_const_init428 = new BitSet(new long[] { 422229649264512L });
/* 3282 */   public static final BitSet FOLLOW_real_in_double_const_init432 = new BitSet(new long[] { 8606711808L });
/* 3283 */   public static final BitSet FOLLOW_24_in_double_const_init437 = new BitSet(new long[] { 422238255976320L });
/* 3284 */   public static final BitSet FOLLOW_real_in_double_const_init439 = new BitSet(new long[] { 8606711808L });
/* 3285 */   public static final BitSet FOLLOW_33_in_double_const_init444 = new BitSet(new long[] { 2L });
/* 3286 */   public static final BitSet FOLLOW_51_in_places456 = new BitSet(new long[] { 16777216L });
/* 3287 */   public static final BitSet FOLLOW_24_in_places458 = new BitSet(new long[] { 618475291650L });
/* 3288 */   public static final BitSet FOLLOW_typed_places_in_places460 = new BitSet(new long[] { 618475291650L });
/* 3289 */   public static final BitSet FOLLOW_place_type_in_typed_places472 = new BitSet(new long[] { 16777216L });
/* 3290 */   public static final BitSet FOLLOW_24_in_typed_places474 = new BitSet(new long[] { 618475291648L });
/* 3291 */   public static final BitSet FOLLOW_place_def_in_typed_places478 = new BitSet(new long[] { 2L });
/* 3292 */   public static final BitSet FOLLOW_place_name_in_place_def508 = new BitSet(new long[] { -9223372036720558080L });
/* 3293 */   public static final BitSet FOLLOW_63_in_place_def511 = new BitSet(new long[] { 2199023255552L });
/* 3294 */   public static final BitSet FOLLOW_41_in_place_def513 = new BitSet(new long[] { 0L, 1L });
/* 3295 */   public static final BitSet FOLLOW_64_in_place_def515 = new BitSet(new long[] { 134217728L });
/* 3296 */   public static final BitSet FOLLOW_27_in_place_def519 = new BitSet(new long[] { 422229649264512L });
/* 3297 */   public static final BitSet FOLLOW_integer_in_place_def521 = new BitSet(new long[] { 33554432L });
/* 3298 */   public static final BitSet FOLLOW_25_in_place_def523 = new BitSet(new long[] { 2L });
/* 3299 */   public static final BitSet FOLLOW_name_in_place_name539 = new BitSet(new long[] { 2L });
/* 3300 */   public static final BitSet FOLLOW_49_in_observers552 = new BitSet(new long[] { 16777216L });
/* 3301 */   public static final BitSet FOLLOW_24_in_observers554 = new BitSet(new long[] { 289356276058555394L });
/* 3302 */   public static final BitSet FOLLOW_observer_in_observers556 = new BitSet(new long[] { 289356276058555394L });
/* 3303 */   public static final BitSet FOLLOW_observer_type_in_observer573 = new BitSet(new long[] { 16777216L });
/* 3304 */   public static final BitSet FOLLOW_24_in_observer575 = new BitSet(new long[] { 289356276058555392L });
/* 3305 */   public static final BitSet FOLLOW_IDENT_in_observer579 = new BitSet(new long[] { 134217728L });
/* 3306 */   public static final BitSet FOLLOW_27_in_observer581 = new BitSet(new long[] { 422229649264512L });
/* 3307 */   public static final BitSet FOLLOW_arithmetic_function_in_observer583 = new BitSet(new long[] { 33554432L });
/* 3308 */   public static final BitSet FOLLOW_25_in_observer585 = new BitSet(new long[] { 2L });
/* 3309 */   public static final BitSet FOLLOW_59_in_transitions611 = new BitSet(new long[] { 16777216L });
/* 3310 */   public static final BitSet FOLLOW_24_in_transitions613 = new BitSet(new long[] { 90107520516883458L });
/* 3311 */   public static final BitSet FOLLOW_typed_trans_in_transitions615 = new BitSet(new long[] { 90107520516883458L });
/* 3312 */   public static final BitSet FOLLOW_trans_type_in_typed_trans632 = new BitSet(new long[] { 16777216L });
/* 3313 */   public static final BitSet FOLLOW_24_in_typed_trans634 = new BitSet(new long[] { 90107520516883456L });
/* 3314 */   public static final BitSet FOLLOW_trans_def_in_typed_trans638 = new BitSet(new long[] { 2L });
/* 3315 */   public static final BitSet FOLLOW_trans_name_in_trans_def681 = new BitSet(new long[] { -9223372036837998592L });
/* 3316 */   public static final BitSet FOLLOW_63_in_trans_def684 = new BitSet(new long[] { 9007199254740992L });
/* 3317 */   public static final BitSet FOLLOW_53_in_trans_def686 = new BitSet(new long[] { 0L, 1L });
/* 3318 */   public static final BitSet FOLLOW_64_in_trans_def688 = new BitSet(new long[] { 16777216L });
/* 3319 */   public static final BitSet FOLLOW_24_in_trans_def692 = new BitSet(new long[] { 4311744512L });
/* 3320 */   public static final BitSet FOLLOW_condition_expr_in_trans_def695 = new BitSet(new long[] { 16842752L });
/* 3321 */   public static final BitSet FOLLOW_16_in_trans_def698 = new BitSet(new long[] { 4294967296L });
/* 3322 */   public static final BitSet FOLLOW_condition_expr_in_trans_def700 = new BitSet(new long[] { 16842752L });
/* 3323 */   public static final BitSet FOLLOW_24_in_trans_def706 = new BitSet(new long[] { 4345298944L });
/* 3324 */   public static final BitSet FOLLOW_update_expr_in_trans_def711 = new BitSet(new long[] { 50397184L });
/* 3325 */   public static final BitSet FOLLOW_16_in_trans_def714 = new BitSet(new long[] { 4294967296L });
/* 3326 */   public static final BitSet FOLLOW_update_expr_in_trans_def717 = new BitSet(new long[] { 50397184L });
/* 3327 */   public static final BitSet FOLLOW_25_in_trans_def726 = new BitSet(new long[] { 2L });
/* 3328 */   public static final BitSet FOLLOW_trans_function_in_trans_def730 = new BitSet(new long[] { 2L });
/* 3329 */   public static final BitSet FOLLOW_name_in_trans_name746 = new BitSet(new long[] { 2L });
/* 3330 */   public static final BitSet FOLLOW_IDENT_in_name757 = new BitSet(new long[] { 2L });
/* 3331 */   public static final BitSet FOLLOW_32_in_condition_expr772 = new BitSet(new long[] { 1024L });
/* 3332 */   public static final BitSet FOLLOW_IDENT_in_condition_expr775 = new BitSet(new long[] { 67108864L });
/* 3333 */   public static final BitSet FOLLOW_26_in_condition_expr778 = new BitSet(new long[] { 422229649264512L });
/* 3334 */   public static final BitSet FOLLOW_integer_in_condition_expr780 = new BitSet(new long[] { 8589934592L });
/* 3335 */   public static final BitSet FOLLOW_33_in_condition_expr782 = new BitSet(new long[] { 2L });
/* 3336 */   public static final BitSet FOLLOW_32_in_condition_expr792 = new BitSet(new long[] { 1024L });
/* 3337 */   public static final BitSet FOLLOW_IDENT_in_condition_expr795 = new BitSet(new long[] { 268435456L });
/* 3338 */   public static final BitSet FOLLOW_28_in_condition_expr798 = new BitSet(new long[] { 422229649264512L });
/* 3339 */   public static final BitSet FOLLOW_integer_in_condition_expr800 = new BitSet(new long[] { 8589934592L });
/* 3340 */   public static final BitSet FOLLOW_33_in_condition_expr802 = new BitSet(new long[] { 2L });
/* 3341 */   public static final BitSet FOLLOW_32_in_condition_expr811 = new BitSet(new long[] { 1024L });
/* 3342 */   public static final BitSet FOLLOW_IDENT_in_condition_expr814 = new BitSet(new long[] { 134217728L });
/* 3343 */   public static final BitSet FOLLOW_27_in_condition_expr816 = new BitSet(new long[] { 422229649264512L });
/* 3344 */   public static final BitSet FOLLOW_integer_in_condition_expr818 = new BitSet(new long[] { 8589934592L });
/* 3345 */   public static final BitSet FOLLOW_33_in_condition_expr820 = new BitSet(new long[] { 2L });
/* 3346 */   public static final BitSet FOLLOW_32_in_condition_expr828 = new BitSet(new long[] { 1024L });
/* 3347 */   public static final BitSet FOLLOW_IDENT_in_condition_expr831 = new BitSet(new long[] { 8589934592L });
/* 3348 */   public static final BitSet FOLLOW_33_in_condition_expr833 = new BitSet(new long[] { 2L });
/* 3349 */   public static final BitSet FOLLOW_32_in_update_expr850 = new BitSet(new long[] { 1024L });
/* 3350 */   public static final BitSet FOLLOW_IDENT_in_update_expr852 = new BitSet(new long[] { 1048576L });
/* 3351 */   public static final BitSet FOLLOW_20_in_update_expr854 = new BitSet(new long[] { 422229649264512L });
/* 3352 */   public static final BitSet FOLLOW_integer_in_update_expr856 = new BitSet(new long[] { 8589934592L });
/* 3353 */   public static final BitSet FOLLOW_33_in_update_expr858 = new BitSet(new long[] { 2L });
/* 3354 */   public static final BitSet FOLLOW_32_in_update_expr867 = new BitSet(new long[] { 1024L });
/* 3355 */   public static final BitSet FOLLOW_IDENT_in_update_expr869 = new BitSet(new long[] { 4194304L });
/* 3356 */   public static final BitSet FOLLOW_22_in_update_expr871 = new BitSet(new long[] { 422229649264512L });
/* 3357 */   public static final BitSet FOLLOW_integer_in_update_expr873 = new BitSet(new long[] { 8589934592L });
/* 3358 */   public static final BitSet FOLLOW_33_in_update_expr875 = new BitSet(new long[] { 2L });
/* 3359 */   public static final BitSet FOLLOW_32_in_update_expr884 = new BitSet(new long[] { 1024L });
/* 3360 */   public static final BitSet FOLLOW_IDENT_in_update_expr886 = new BitSet(new long[] { 134217728L });
/* 3361 */   public static final BitSet FOLLOW_27_in_update_expr888 = new BitSet(new long[] { 422229649264512L });
/* 3362 */   public static final BitSet FOLLOW_integer_in_update_expr890 = new BitSet(new long[] { 8589934592L });
/* 3363 */   public static final BitSet FOLLOW_33_in_update_expr892 = new BitSet(new long[] { 2L });
/* 3364 */   public static final BitSet FOLLOW_24_in_trans_function907 = new BitSet(new long[] { -16L, 1L });
/* 3365 */   public static final BitSet FOLLOW_25_in_trans_function914 = new BitSet(new long[] { 2L });
/* 3366 */   public static final BitSet FOLLOW_30_in_pattern924 = new BitSet(new long[] { 131072L });
/* 3367 */   public static final BitSet FOLLOW_17_in_pattern926 = new BitSet(new long[] { 422229649264512L });
/* 3368 */   public static final BitSet FOLLOW_arithmetic_function_in_pattern928 = new BitSet(new long[] { 262144L });
/* 3369 */   public static final BitSet FOLLOW_18_in_pattern930 = new BitSet(new long[] { 2L });
/* 3370 */   public static final BitSet FOLLOW_29_in_pattern935 = new BitSet(new long[] { 131072L });
/* 3371 */   public static final BitSet FOLLOW_17_in_pattern937 = new BitSet(new long[] { 422229649264512L });
/* 3372 */   public static final BitSet FOLLOW_arithmetic_function_in_pattern939 = new BitSet(new long[] { 2097152L });
/* 3373 */   public static final BitSet FOLLOW_21_in_pattern941 = new BitSet(new long[] { 422229649264512L });
/* 3374 */   public static final BitSet FOLLOW_arithmetic_function_in_pattern943 = new BitSet(new long[] { 262144L });
/* 3375 */   public static final BitSet FOLLOW_18_in_pattern945 = new BitSet(new long[] { 2L });
/* 3376 */   public static final BitSet FOLLOW_31_in_pattern950 = new BitSet(new long[] { 131072L });
/* 3377 */   public static final BitSet FOLLOW_17_in_pattern952 = new BitSet(new long[] { 422229649264512L });
/* 3378 */   public static final BitSet FOLLOW_arithmetic_function_in_pattern954 = new BitSet(new long[] { 2097152L });
/* 3379 */   public static final BitSet FOLLOW_21_in_pattern956 = new BitSet(new long[] { 422229649264512L });
/* 3380 */   public static final BitSet FOLLOW_arithmetic_function_in_pattern958 = new BitSet(new long[] { 262144L });
/* 3381 */   public static final BitSet FOLLOW_18_in_pattern960 = new BitSet(new long[] { 2L });
/* 3382 */   public static final BitSet FOLLOW_arithmetic_function_in_integer975 = new BitSet(new long[] { 2L });
/* 3383 */   public static final BitSet FOLLOW_arithmetic_function_in_real994 = new BitSet(new long[] { 2L });
/* 3384 */   public static final BitSet FOLLOW_term_in_arithmetic_function1018 = new BitSet(new long[] { 5242882L });
/* 3385 */   public static final BitSet FOLLOW_20_in_arithmetic_function1026 = new BitSet(new long[] { 422229649264512L });
/* 3386 */   public static final BitSet FOLLOW_term_in_arithmetic_function1030 = new BitSet(new long[] { 5242882L });
/* 3387 */   public static final BitSet FOLLOW_22_in_arithmetic_function1037 = new BitSet(new long[] { 422229649264512L });
/* 3388 */   public static final BitSet FOLLOW_term_in_arithmetic_function1041 = new BitSet(new long[] { 5242882L });
/* 3389 */   public static final BitSet FOLLOW_factor_in_term1069 = new BitSet(new long[] { 8912898L });
/* 3390 */   public static final BitSet FOLLOW_19_in_term1077 = new BitSet(new long[] { 422229649264512L });
/* 3391 */   public static final BitSet FOLLOW_factor_in_term1081 = new BitSet(new long[] { 8912898L });
/* 3392 */   public static final BitSet FOLLOW_23_in_term1088 = new BitSet(new long[] { 422229649264512L });
/* 3393 */   public static final BitSet FOLLOW_factor_in_term1092 = new BitSet(new long[] { 8912898L });
/* 3394 */   public static final BitSet FOLLOW_17_in_factor1116 = new BitSet(new long[] { 422229649264512L });
/* 3395 */   public static final BitSet FOLLOW_arithmetic_function_in_factor1118 = new BitSet(new long[] { 262144L });
/* 3396 */   public static final BitSet FOLLOW_18_in_factor1120 = new BitSet(new long[] { 2L });
/* 3397 */   public static final BitSet FOLLOW_22_in_factor1129 = new BitSet(new long[] { 422229649264512L });
/* 3398 */   public static final BitSet FOLLOW_factor_in_factor1133 = new BitSet(new long[] { 2L });
/* 3399 */   public static final BitSet FOLLOW_func_1_in_factor1141 = new BitSet(new long[] { 2L });
/* 3400 */   public static final BitSet FOLLOW_func_2_in_factor1150 = new BitSet(new long[] { 2L });
/* 3401 */   public static final BitSet FOLLOW_user_defined_in_factor1159 = new BitSet(new long[] { 2L });
/* 3402 */   public static final BitSet FOLLOW_atomic_in_factor1168 = new BitSet(new long[] { 2L });
/* 3403 */   public static final BitSet FOLLOW_34_in_func_11190 = new BitSet(new long[] { 131072L });
/* 3404 */   public static final BitSet FOLLOW_17_in_func_11192 = new BitSet(new long[] { 422229649264512L });
/* 3405 */   public static final BitSet FOLLOW_arithmetic_function_in_func_11196 = new BitSet(new long[] { 262144L });
/* 3406 */   public static final BitSet FOLLOW_18_in_func_11198 = new BitSet(new long[] { 2L });
/* 3407 */   public static final BitSet FOLLOW_48_in_func_21216 = new BitSet(new long[] { 131072L });
/* 3408 */   public static final BitSet FOLLOW_17_in_func_21218 = new BitSet(new long[] { 422229649264512L });
/* 3409 */   public static final BitSet FOLLOW_arithmetic_function_in_func_21222 = new BitSet(new long[] { 2097152L });
/* 3410 */   public static final BitSet FOLLOW_21_in_func_21224 = new BitSet(new long[] { 422229649264512L });
/* 3411 */   public static final BitSet FOLLOW_arithmetic_function_in_func_21228 = new BitSet(new long[] { 262144L });
/* 3412 */   public static final BitSet FOLLOW_18_in_func_21230 = new BitSet(new long[] { 2L });
/* 3413 */   public static final BitSet FOLLOW_47_in_func_21238 = new BitSet(new long[] { 131072L });
/* 3414 */   public static final BitSet FOLLOW_17_in_func_21240 = new BitSet(new long[] { 422229649264512L });
/* 3415 */   public static final BitSet FOLLOW_arithmetic_function_in_func_21244 = new BitSet(new long[] { 2097152L });
/* 3416 */   public static final BitSet FOLLOW_21_in_func_21246 = new BitSet(new long[] { 422229649264512L });
/* 3417 */   public static final BitSet FOLLOW_arithmetic_function_in_func_21250 = new BitSet(new long[] { 262144L });
/* 3418 */   public static final BitSet FOLLOW_18_in_func_21252 = new BitSet(new long[] { 2L });
/* 3419 */   public static final BitSet FOLLOW_IDENT_in_user_defined1269 = new BitSet(new long[] { 131072L });
/* 3420 */   public static final BitSet FOLLOW_17_in_user_defined1271 = new BitSet(new long[] { 422229649526656L });
/* 3421 */   public static final BitSet FOLLOW_arithmetic_function_in_user_defined1282 = new BitSet(new long[] { 2359296L });
/* 3422 */   public static final BitSet FOLLOW_21_in_user_defined1293 = new BitSet(new long[] { 422229649264512L });
/* 3423 */   public static final BitSet FOLLOW_arithmetic_function_in_user_defined1298 = new BitSet(new long[] { 2359296L });
/* 3424 */   public static final BitSet FOLLOW_18_in_user_defined1311 = new BitSet(new long[] { 2L });
/* 3425 */   public static final BitSet FOLLOW_FLOAT1_in_atomic1329 = new BitSet(new long[] { 2L });
/* 3426 */   public static final BitSet FOLLOW_FLOAT2_in_atomic1338 = new BitSet(new long[] { 2L });
/* 3427 */   public static final BitSet FOLLOW_FLOAT3_in_atomic1347 = new BitSet(new long[] { 2L });
/* 3428 */   public static final BitSet FOLLOW_INT_in_atomic1356 = new BitSet(new long[] { 2L });
/* 3429 */   public static final BitSet FOLLOW_IDENT_in_atomic1365 = new BitSet(new long[] { 2L });
/*      */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/ANDLParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */