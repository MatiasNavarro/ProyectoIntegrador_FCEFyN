/*    */ package charlie.pn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnknownArcException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -2111902588852032087L;
/*    */   String info;
/*    */   
/*    */   public UnknownArcException(String str) {
/* 13 */     this.info = str;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 18 */     return this.info;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/UnknownArcException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */