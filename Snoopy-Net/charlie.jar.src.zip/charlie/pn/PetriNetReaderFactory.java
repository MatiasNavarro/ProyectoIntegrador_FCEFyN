/*     */ package charlie.pn;
/*     */ 
/*     */ import GUI.util.StringHashMap;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PetriNetReaderFactory
/*     */ {
/*  22 */   private static StringHashMap<PetriNetReader> registeredReader = new StringHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initReaders() {
/*  28 */     new ApnnReader();
/*  29 */     new ANDLReader();
/*  30 */     new SnoopyModuleNetReader();
/*  31 */     new SnoopyPTNetReader(true);
/*  32 */     new SPTPTReader();
/*  33 */     new InaReader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void registerReader(String extension, PetriNetReader pnr) {
/*  50 */     if (extension == null || pnr == null) {
/*  51 */       throw new NullPointerException(String.format("Neither the extension (%s) nor the reader (%s) must be null.", new Object[] { extension, pnr }));
/*     */     }
/*     */     
/*  54 */     registeredReader.put(extension, pnr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getExtensions() {
/*  63 */     String[] ret = new String[registeredReader.size() + 1];
/*  64 */     StringBuffer all = new StringBuffer();
/*  65 */     int i = 0;
/*  66 */     for (Iterator<String> it = registeredReader.keySet().iterator(); it.hasNext(); ) {
/*  67 */       String str = it.next();
/*  68 */       ret[i++] = str;
/*  69 */       all.append(str);
/*  70 */       if (it.hasNext()) {
/*  71 */         all.append(";");
/*     */       }
/*     */     } 
/*  74 */     ret[i] = all.toString();
/*  75 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PetriNetReader getReader(String extension) throws UnsupportedFormatException {
/*  88 */     PetriNetReader pnr = (PetriNetReader)registeredReader.get(extension);
/*  89 */     if (pnr == null) {
/*  90 */       throw new UnsupportedFormatException(extension + " is no registered Petri net format");
/*     */     }
/*  92 */     return pnr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PetriNetReader getReader(File file) throws UnsupportedFormatException, FileNotFoundException {
/* 106 */     if (file == null) {
/* 107 */       return null;
/*     */     }
/* 109 */     if (!file.exists()) {
/* 110 */       throw new FileNotFoundException(String.format("The file %s cannot be found.", new Object[] { file.getAbsolutePath() }));
/*     */     }
/*     */     
/* 113 */     String fileName = file.getName();
/* 114 */     String extension = fileName.substring(fileName.lastIndexOf("."));
/* 115 */     return getReader(extension);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String printInfo() {
/* 124 */     StringBuilder sb = new StringBuilder();
/* 125 */     sb.append("PetriNetReaderFactory:\n");
/* 126 */     Set<String> keys = registeredReader.keySet();
/* 127 */     for (String s : keys) {
/* 128 */       sb.append("registered extension: " + s + " \n");
/* 129 */       PetriNetReader pnr = (PetriNetReader)registeredReader.get(s);
/* 130 */       sb.append("registered reader: " + pnr.getClass().getName() + " \n");
/*     */     } 
/* 132 */     System.out.println(sb.toString());
/*     */     
/* 134 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/PetriNetReaderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */