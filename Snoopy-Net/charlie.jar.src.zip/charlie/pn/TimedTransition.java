/*     */ package charlie.pn;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimedTransition
/*     */   extends Transition
/*     */   implements DurationTimeTransition, ReactionTimeTransition
/*     */ {
/*     */   public static final byte RESET_ALL_CLOCKS = 1;
/*     */   public static final byte RESET_CLOCKS_INA_LIKE = 2;
/*     */   public static final byte RESET_ONLY_FIRING_CLOCK = 3;
/*     */   public static final byte COUNT_UP = 4;
/*     */   public static final byte COUNT_DOWN = 5;
/*     */   TimingElement intervallTimeElement;
/*     */   TimingElement constantTimeElement;
/*     */   
/*     */   public TimedTransition(String name, short id, TimingElement intervallTimeElement, TimingElement constantTimeElement) {
/*  42 */     super(name, id);
/*  43 */     this.intervallTimeElement = intervallTimeElement;
/*  44 */     this.constantTimeElement = constantTimeElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimedTransition(String identifier, String name, short id, TimingElement intervallTimeElement, TimingElement constantTimeElement) {
/*  56 */     super(identifier, name, id);
/*  57 */     this.intervallTimeElement = intervallTimeElement;
/*  58 */     this.constantTimeElement = constantTimeElement;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean durationCanFire(State m) {
/*  63 */     if (m.timedNetType == 4) {
/*  64 */       return super.canFire(m);
/*     */     }
/*  66 */     if (m.clockHandling == 4) {
/*  67 */       return (this.pre.isSubSet(m.getPlaceMarking()) && m.getTransitionMarking().getTokenById(this.id) - 1 == 0);
/*     */     }
/*  69 */     this.pre.isSubSet(m.getPlaceMarking());
/*  70 */     boolean t = (m.getTransitionMarking().getTokenById(this.id) == 0);
/*  71 */     return (this.pre.isSubSet(m.getPlaceMarking()) && m.getTransitionMarking().getTokenById(this.id) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canFire(State m) {
/*  78 */     if (m.timedNetType == 3) {
/*  79 */       return durationCanFire(m);
/*     */     }
/*  81 */     return reactionCanFire(m);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public State durationFire(State state) throws SafetyException, ExceedsByteException {
/*  87 */     if (state.timedNetType == 4) {
/*  88 */       return fire(state, true, true);
/*     */     }
/*  90 */     return consume(state);
/*     */   }
/*     */   
/*     */   public State reactionFire(State state) throws SafetyException, ExceedsByteException {
/*  94 */     if (state.timedNetType == 4) {
/*  95 */       return fire(state, true, true);
/*     */     }
/*  97 */     State retState = new TimedState(state.clockHandling, state.timedNetType, state.timeDesignation);
/*  98 */     retState = fire(state, true, true);
/*  99 */     return retState;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean reactionCanFire(State m) {
/* 104 */     byte nT = m.timedNetType;
/* 105 */     byte tD = m.timeDesignation;
/*     */     
/* 107 */     if (nT == 4) {
/* 108 */       return super.canFire(m);
/*     */     }
/* 110 */     return (this.pre.isSubSet(m.getPlaceMarking()) && m.getTransitionMarking().getTokenById(this.id) - 1 >= getEft(nT, tD) && (m
/* 111 */       .getTransitionMarking().getTokenById(this.id) - 1 <= getLft(nT, tD) || getLft(nT, tD) == -1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean reactionMustFire(State m) {
/* 121 */     if (m.getTransitionMarking() == null) {
/* 122 */       DebugCounter.inc("TimedTransition.reactionMustFire: m.getTransitionMarking() == null");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     return (getLft(m.timedNetType, m.timeDesignation) == m.getTransitionMarking().getTokenById(this.id) - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public State consume(State state) throws SafetyException, ExceedsByteException {
/* 135 */     if (state.timedNetType == 4) {
/* 136 */       return super.consume(state);
/*     */     }
/*     */     
/* 139 */     State newState = new TimedState(state.clockHandling, state.timedNetType, state.timeDesignation);
/*     */     
/* 141 */     State next = fire(state, true, false);
/* 142 */     if (next == null) {
/* 143 */       DebugCounter.inc("TimedTransition.consume(State):  super.consume(state) == null!\n state=" + state);
/*     */     }
/* 145 */     newState.setPlaceMarking(next.getPlaceMarking());
/* 146 */     newState.setTransitionMarking(state.getTransitionMarking());
/* 147 */     return newState;
/*     */   }
/*     */ 
/*     */   
/*     */   public State produce(State state) throws SafetyException, ExceedsByteException {
/* 152 */     State newState = new TimedState(state.clockHandling, state.timedNetType, state.timeDesignation);
/* 153 */     newState.setTransitionMarking(state.getTransitionMarking());
/* 154 */     newState.setPlaceMarking(fire(state, false, true).getPlaceMarking());
/* 155 */     return newState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEft(byte netType, byte timeDesignation) {
/* 165 */     if (netType == 3) {
/*     */       
/* 167 */       if (timeDesignation == 0) {
/*     */         
/* 169 */         if (this.intervallTimeElement.getEft() == -1) {
/* 170 */           return 0;
/*     */         }
/* 172 */         return this.intervallTimeElement.getEft();
/*     */       } 
/*     */ 
/*     */       
/* 176 */       if (this.constantTimeElement.getEft() == -1) {
/* 177 */         return 0;
/*     */       }
/* 179 */       return this.constantTimeElement.getEft();
/*     */     } 
/*     */ 
/*     */     
/* 183 */     if (timeDesignation == 0) {
/* 184 */       return this.intervallTimeElement.getEft();
/*     */     }
/* 186 */     return this.constantTimeElement.getEft();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLft(byte netType, byte timeDesignation) {
/* 197 */     if (netType == 3) {
/*     */       
/* 199 */       if (timeDesignation == 0) {
/* 200 */         if (this.intervallTimeElement.getLft() == -1) {
/* 201 */           if (this.intervallTimeElement.getEft() > -1) {
/* 202 */             return this.intervallTimeElement.getEft();
/*     */           }
/* 204 */           return 0;
/*     */         } 
/*     */         
/* 207 */         return this.intervallTimeElement.getLft();
/*     */       } 
/*     */ 
/*     */       
/* 211 */       if (this.constantTimeElement.getEft() == -1) {
/* 212 */         return 0;
/*     */       }
/* 214 */       return this.constantTimeElement.getEft();
/*     */     } 
/*     */ 
/*     */     
/* 218 */     if (timeDesignation == 0) {
/* 219 */       return this.intervallTimeElement.getLft();
/*     */     }
/* 221 */     return this.constantTimeElement.getEft();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public State reactionHandleClocks(State oldState, State newState, PlaceTransitionNet net, int clockHandling) throws SafetyException, ExceedsByteException {
/* 230 */     if (newState == null) {
/* 231 */       return null;
/*     */     }
/* 233 */     State tco = oldState;
/* 234 */     if (tco.clockHandling == 1) {
/* 235 */       System.out.printf("\n\treactionHandleClocks oldstate clockhandling: Reset all\n", new Object[0]);
/* 236 */     } else if (tco.clockHandling == 2) {
/* 237 */       System.out.printf("\n\treactionHandleClocks oldstate clockhandling: Reset ina like\n", new Object[0]);
/* 238 */     } else if (tco.clockHandling == 3) {
/* 239 */       System.out.printf("\n\treactionHandleClocks oldstate clockhandling: Reset ina like\n", new Object[0]);
/*     */     } else {
/* 241 */       System.out.printf("\n\treactionHandleClocks oldstate WRONG clockhandling !!!\n", new Object[0]);
/*     */     } 
/*     */     
/* 244 */     State retState = new TimedState(oldState.clockHandling, oldState.timedNetType, oldState.timeDesignation);
/* 245 */     retState.setPlaceMarking(newState.getPlaceMarking());
/* 246 */     SortedElementsDynamic transitionsM0 = new SortedElementsDynamic(false);
/* 247 */     transitionsM0.name = " TimedTransition reactHandlClk trans.M0";
/* 248 */     Iterator<Transition> it = getOrderedConflicts().iterator();
/* 249 */     int counter = 0;
/* 250 */     int id = oldState.getTransitionMarking().getId(counter);
/* 251 */     while (it.hasNext() && counter < oldState.getTransitionMarking().size()) {
/*     */       
/* 253 */       id = oldState.getTransitionMarking().getId(counter);
/* 254 */       Transition t = it.next();
/* 255 */       int curID = t.getId();
/* 256 */       while (counter < oldState.getTransitionMarking().size() && (id = oldState.getTransitionMarking().getId(counter)) < curID) {
/*     */         
/* 258 */         if (id == getId()) {
/*     */           
/* 260 */           if (this.pre.isSubSet(newState.getPlaceMarking()))
/*     */           {
/* 262 */             transitionsM0.addPlace(id, 1);
/*     */           }
/*     */         } else {
/*     */           
/* 266 */           transitionsM0.addPlace(id, oldState.getTransitionMarking().getTokenById(id));
/*     */         } 
/* 268 */         counter++;
/*     */       } 
/* 270 */       if (id == curID) {
/*     */         
/* 272 */         if (t.getPre().isSubSet(newState.getPlaceMarking()))
/*     */         {
/* 274 */           if (clockHandling == 3) {
/* 275 */             transitionsM0.addPlace(id, oldState.getTransitionMarking().getTokenById(id));
/*     */           } else {
/* 277 */             transitionsM0.addPlace(curID, 1);
/*     */           } 
/*     */         }
/* 280 */         counter++;
/*     */       } 
/*     */     } 
/* 283 */     while (counter < oldState.getTransitionMarking().size()) {
/*     */       
/* 285 */       id = oldState.getTransitionMarking().getId(counter);
/*     */       
/* 287 */       if (id == getId()) {
/*     */         
/* 289 */         if (this.pre.isSubSet(newState.getPlaceMarking()))
/*     */         {
/* 291 */           transitionsM0.addPlace(id, 1);
/*     */         }
/*     */       } else {
/*     */         
/* 295 */         transitionsM0.addPlace(id, oldState.getTransitionMarking().getTokenById(id));
/*     */       } 
/* 297 */       counter++;
/*     */     } 
/* 299 */     SortedElementsDynamic transitionsM0AllClocks = new SortedElementsDynamic(false);
/* 300 */     transitionsM0AllClocks.name = " TimedTransition.transitionsM0AllClocks";
/* 301 */     Marking trSet = transitionsM0.toArray();
/* 302 */     Vector<Integer> transitionsAfter = new Vector();
/* 303 */     for (int i = 0; i < this.post.size(); i++) {
/*     */       
/* 305 */       TransitionSet postTransitions = (TransitionSet)net.getPlaceByIndex(this.post.getId(i)).postNodes();
/* 306 */       for (Iterator<Integer> itTransitions = postTransitions.iterator(); itTransitions.hasNext(); ) {
/*     */         
/* 308 */         int tNumber = ((Integer)itTransitions.next()).intValue();
/*     */         
/* 310 */         Transition t = net.getTransition((short)tNumber);
/* 311 */         if (!transitionsAfter.contains(Integer.valueOf(tNumber))) {
/*     */           
/* 313 */           transitionsAfter.add(Integer.valueOf(tNumber));
/* 314 */           if (clockHandling == 1) {
/* 315 */             if (t.getPre().isSubSet(newState.getPlaceMarking())) {
/* 316 */               transitionsM0AllClocks.addPlace(t.getId(), 1);
/*     */             }
/*     */             continue;
/*     */           } 
/* 320 */           if (trSet.getTokenById(t.getId()) == 0)
/*     */           {
/* 322 */             if (t.getPre().isSubSet(newState.getPlaceMarking())) {
/* 323 */               transitionsM0.addPlace(t.getId(), 1);
/*     */             }
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 330 */     if (clockHandling == 1) {
/* 331 */       Marking trSet1 = transitionsM0AllClocks.toArray();
/* 332 */       for (int j = 0; j < trSet.size(); j++) {
/*     */         
/* 334 */         int idIn = trSet.getId(j);
/* 335 */         if (trSet1.getTokenById(idIn) == 0) {
/* 336 */           transitionsM0AllClocks.addPlace(idIn, trSet.getTokenById(idIn));
/*     */         }
/*     */       } 
/* 339 */       transitionsM0 = transitionsM0AllClocks;
/*     */     } 
/*     */     
/* 342 */     retState.setTransitionMarking(transitionsM0.toArray());
/* 343 */     return retState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimingElement getIntervallTimeElement() {
/* 351 */     return this.intervallTimeElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimingElement getConstantTimeElement() {
/* 359 */     return this.constantTimeElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimingElements(String nameConstant, String nameInterval) {
/* 369 */     if (nameConstant != null)
/*     */     {
/* 371 */       while (this.constantTimeElement != null) {
/*     */         
/* 373 */         if (this.constantTimeElement.getName().equals(nameConstant)) {
/*     */           
/* 375 */           this.constantTimeElement.next = null;
/*     */           break;
/*     */         } 
/* 378 */         this.constantTimeElement = this.constantTimeElement.next;
/*     */       } 
/*     */     }
/* 381 */     if (nameInterval != null)
/*     */     {
/* 383 */       while (this.intervallTimeElement != null) {
/*     */         
/* 385 */         if (this.intervallTimeElement.getName().equals(nameInterval)) {
/*     */           
/* 387 */           this.intervallTimeElement.next = null;
/*     */           break;
/*     */         } 
/* 390 */         this.intervallTimeElement = this.intervallTimeElement.next;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 399 */     return "Name: " + getName() + ", ID: " + this.id;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/TimedTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */