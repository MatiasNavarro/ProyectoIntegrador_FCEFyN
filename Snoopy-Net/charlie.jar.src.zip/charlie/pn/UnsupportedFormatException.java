/*    */ package charlie.pn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedFormatException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 7095829295049054976L;
/*    */   
/*    */   public UnsupportedFormatException() {}
/*    */   
/*    */   public UnsupportedFormatException(String _message) {
/* 15 */     super(_message);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/UnsupportedFormatException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */