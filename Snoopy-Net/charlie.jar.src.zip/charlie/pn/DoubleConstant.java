/*    */ package charlie.pn;
/*    */ 
/*    */ public class DoubleConstant
/*    */   extends Constant
/*    */ {
/*    */   public Constant.Type getType() {
/*  7 */     return Constant.Type.DOUBLE;
/*    */   }
/*    */   
/*    */   public DoubleConstant(String name, String value) {
/* 11 */     super(name, value);
/*    */   }
/*    */   
/*    */   public Double getValue() throws NumberFormatException {
/* 15 */     return Double.valueOf(Double.parseDouble(this.value));
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/DoubleConstant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */