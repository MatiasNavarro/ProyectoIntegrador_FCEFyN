/*    */ package charlie.pn;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Edge
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6837352079725526876L;
/*    */   protected Vertex d;
/*    */   protected Edge next;
/*    */   
/*    */   public Edge(Vertex s, Vertex d) {
/* 16 */     this.next = null;
/* 17 */     this.d = d;
/*    */   }
/*    */ 
/*    */   
/*    */   public Edge next() {
/* 22 */     return this.next;
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 26 */     return (this.next != null);
/*    */   }
/*    */   
/*    */   public void setNext(Edge next) {
/* 30 */     this.next = next;
/*    */   }
/*    */   
/*    */   public Vertex node() {
/* 34 */     return this.d;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 39 */     int prime = 31;
/* 40 */     int result = 1;
/* 41 */     result = 31 * result + ((this.d == null) ? 0 : this.d.hashCode());
/* 42 */     result = 31 * result + ((this.next == null) ? 0 : this.next.hashCode());
/* 43 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 48 */     if (this == obj) {
/* 49 */       return true;
/*    */     }
/* 51 */     if (obj == null) {
/* 52 */       return false;
/*    */     }
/* 54 */     if (getClass() != obj.getClass()) {
/* 55 */       return false;
/*    */     }
/* 57 */     Edge other = (Edge)obj;
/* 58 */     if (this.d == null) {
/* 59 */       if (other.d != null) {
/* 60 */         return false;
/*    */       }
/* 62 */     } else if (!this.d.equals(other.d)) {
/* 63 */       return false;
/*    */     } 
/* 65 */     if (this.next == null) {
/* 66 */       if (other.next != null) {
/* 67 */         return false;
/*    */       }
/* 69 */     } else if (!this.next.equals(other.next)) {
/* 70 */       return false;
/*    */     } 
/* 72 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/Edge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */