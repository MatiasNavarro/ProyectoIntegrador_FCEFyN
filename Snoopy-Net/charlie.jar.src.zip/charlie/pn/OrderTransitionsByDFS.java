/*    */ package charlie.pn;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class OrderTransitionsByDFS implements OrderingFunction {
/*    */   Vector translationTable;
/*    */   
/*    */   public OrderTransitionsByDFS(PlaceTransitionNet pn) {
/* 10 */     this.pn = pn;
/*    */     
/* 12 */     int start = 0;
/*    */     
/* 14 */     Vector<Integer> v = pn.dfsLin(false, 0);
/* 15 */     System.out.println("v: " + v);
/* 16 */     this.translationTable = new Vector(pn.transitions());
/*    */     
/* 18 */     for (Iterator<Integer> it = v.iterator(); it.hasNext(); ) {
/* 19 */       Integer i = it.next();
/*    */ 
/*    */       
/* 22 */       this.translationTable.add(i);
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 28 */     System.out.println("trans: " + this.translationTable);
/* 29 */     if (this.translationTable.size() != pn.transitions()) {
/* 30 */       System.out.println("error by ordering");
/* 31 */       System.exit(1);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   PlaceTransitionNet pn;
/*    */ 
/*    */   
/*    */   public Vector getTranslationTable() {
/* 41 */     return this.translationTable;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/OrderTransitionsByDFS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */