/*    */ package charlie.pn;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class State
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 7002240702476688823L;
/* 24 */   public byte clockHandling = -1;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   public byte timedNetType = 4;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public byte timeDesignation = -1;
/*    */   
/* 36 */   public String name = "";
/*    */   
/*    */   public abstract Marking getPlaceMarking();
/*    */   
/*    */   public abstract Marking getTransitionMarking();
/*    */   
/*    */   public abstract void setTransitionMarking(Marking paramMarking);
/*    */   
/*    */   public abstract void setPlaceMarking(Marking paramMarking);
/*    */   
/*    */   public abstract int addPlace(int paramInt1, int paramInt2) throws SafetyException, ExceedsByteException;
/*    */   
/*    */   public abstract State copy() throws SafetyException, ExceedsByteException;
/*    */   
/*    */   public abstract String toString();
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/State.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */