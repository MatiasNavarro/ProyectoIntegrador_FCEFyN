/*     */ package charlie.pn;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.HashSet;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ 
/*     */ public class SnoopyModuleNetReader
/*     */   extends SnoopyPTNetReader
/*     */ {
/*  12 */   HashSet toIgnore = new HashSet();
/*     */   
/*     */   public SnoopyModuleNetReader() {
/*  15 */     super(false);
/*  16 */     if (evalVersion()) {
/*  17 */       PetriNetReaderFactory.registerReader(".spmnet", this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected int countPlaces() {
/*  23 */     this.toIgnore.clear();
/*  24 */     determineRemainingPlaces();
/*     */     
/*  26 */     return this.toIgnore.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void determineRemainingPlaces() {
/*     */     try {
/*  34 */       this.placeCounter = 0;
/*     */       
/*  36 */       InputStream in = getInputStream(this.file);
/*  37 */       XMLInputFactory factory = XMLInputFactory.newInstance();
/*  38 */       XMLStreamReader parser = factory.createXMLStreamReader(in);
/*     */       
/*  40 */       StringBuilder spacer = new StringBuilder();
/*  41 */       while (parser.hasNext()) {
/*     */         String ln;
/*  43 */         int i, event = parser.next();
/*     */         
/*  45 */         switch (event) {
/*     */           case 7:
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 8:
/*  52 */             parser.close();
/*     */             break;
/*     */           case 13:
/*     */             break;
/*     */           case 1:
/*  57 */             spacer.append("  ");
/*  58 */             ln = parser.getLocalName();
/*  59 */             if (ln.equals("node") || ln.equals("edge")) {
/*  60 */               checkForPlaces(parser);
/*     */               break;
/*     */             } 
/*  63 */             for (i = 0; i < parser.getAttributeCount(); i++) {
/*  64 */               parser.getAttributeLocalName(i);
/*  65 */               String av = parser.getAttributeValue(i);
/*  66 */               if (ln.equals("nodeclass") || ln.equals("edgeclass")) {
/*  67 */                 eval(av);
/*     */               }
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/*  80 */     } catch (Exception e) {
/*  81 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkForPlaces(XMLStreamReader parser) {
/*  88 */     String id = "";
/*  89 */     int net = -1;
/*  90 */     String source = "";
/*  91 */     String target = "";
/*  92 */     for (int i = 0; i < parser.getAttributeCount(); i++) {
/*  93 */       String lv = parser.getAttributeLocalName(i);
/*  94 */       String av = parser.getAttributeValue(i);
/*  95 */       if (lv.equals("net")) {
/*  96 */         net = Integer.parseInt(av);
/*  97 */       } else if (lv.equals("id")) {
/*  98 */         id = av;
/*  99 */       } else if (lv.equals("source")) {
/* 100 */         source = av;
/* 101 */       } else if (lv.equals("target")) {
/* 102 */         target = av;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 107 */     if (nc == PLACE) {
/* 108 */       this.toIgnore.add(id);
/*     */     }
/* 110 */     else if (nc == PlaceTransitionNet.UNDIRECTED_EDGE) {
/* 111 */       if (this.toIgnore.contains(source))
/*     */       {
/* 113 */         this.toIgnore.remove(source);
/*     */       }
/* 115 */       if (this.toIgnore.contains(target))
/*     */       {
/* 117 */         this.toIgnore.remove(target);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean ignoreNode(String id) {
/* 125 */     boolean b = !this.toIgnore.contains(id);
/*     */     
/* 127 */     return b;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SnoopyModuleNetReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */