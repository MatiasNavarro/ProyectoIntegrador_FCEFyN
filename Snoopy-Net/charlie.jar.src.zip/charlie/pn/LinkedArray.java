package charlie.pn;

public interface LinkedArray {
  int get(int paramInt);
  
  void set(int paramInt1, int paramInt2);
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/LinkedArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */