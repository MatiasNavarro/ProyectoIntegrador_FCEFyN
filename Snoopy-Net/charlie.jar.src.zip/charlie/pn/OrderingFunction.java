package charlie.pn;

import java.util.Vector;

public interface OrderingFunction {
  Vector<Integer> getTranslationTable();
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/OrderingFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */