/*     */ package charlie.pn;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InaReader
/*     */   extends PetriNetReader
/*     */ {
/*  23 */   private static final Log LOG = LogFactory.getLog(InaReader.class);
/*     */   
/*     */   public InaReader() {
/*  26 */     PetriNetReaderFactory.registerReader(".pnt", this);
/*  27 */     PetriNetReaderFactory.registerReader(".cnt", this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int countPlaces() {
/*  32 */     int count = 0;
/*  33 */     BufferedReader reader = null;
/*     */     try {
/*  35 */       InputStream fileInput = getInputStream(this.file);
/*  36 */       reader = new BufferedReader(new InputStreamReader(fileInput));
/*     */       
/*  38 */       String line = null;
/*  39 */       while ((line = reader.readLine()) != null && !line.trim().equals("@"));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  44 */       reader.readLine();
/*     */ 
/*     */ 
/*     */       
/*  48 */       while ((line = reader.readLine()) != null && !line.trim().equals("@")) {
/*     */         
/*  50 */         if (!line.trim().equals("")) {
/*  51 */           count++;
/*     */         }
/*     */       } 
/*  54 */     } catch (FileNotFoundException e) {
/*  55 */       LOG.error(e.getMessage(), e);
/*  56 */     } catch (IOException e) {
/*  57 */       LOG.error(e.getMessage(), e);
/*     */     } finally {
/*     */       try {
/*  60 */         reader.close();
/*  61 */       } catch (IOException e) {
/*  62 */         LOG.error(e.getMessage(), e);
/*     */       } 
/*     */     } 
/*     */     
/*  66 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int countTransitions() {
/*  71 */     int count = 0;
/*  72 */     BufferedReader reader = null;
/*     */     try {
/*  74 */       InputStream fileInput = getInputStream(this.file);
/*  75 */       reader = new BufferedReader(new InputStreamReader(fileInput));
/*     */       
/*  77 */       String line = null;
/*  78 */       while ((line = reader.readLine()) != null && !line.trim().equals("@"));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  83 */       while ((line = reader.readLine()) != null && !line.trim().equals("@"));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  88 */       reader.readLine();
/*     */ 
/*     */ 
/*     */       
/*  92 */       while ((line = reader.readLine()) != null && !line.trim().equals("@")) {
/*     */         
/*  94 */         if (!line.trim().equals("")) {
/*  95 */           count++;
/*     */         }
/*     */       } 
/*  98 */     } catch (FileNotFoundException e) {
/*  99 */       LOG.error(e.getMessage(), e);
/* 100 */     } catch (IOException e) {
/* 101 */       LOG.error(e.getMessage(), e);
/*     */     } finally {
/*     */       try {
/* 104 */         reader.close();
/* 105 */       } catch (IOException e) {
/* 106 */         LOG.error(e.getMessage(), e);
/*     */       } 
/*     */     } 
/*     */     
/* 110 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readNet() throws Exception {
/* 115 */     read();
/* 116 */     this.pn.TIMED_NET_TYPE = 4;
/* 117 */     this.pn.setTimedNet(false);
/* 118 */     initNet();
/*     */   }
/*     */   
/*     */   private void read() throws Exception {
/* 122 */     BufferedReader reader = null;
/*     */     try {
/* 124 */       InputStream fileInput = getInputStream(this.file);
/* 125 */       reader = new BufferedReader(new InputStreamReader(fileInput));
/*     */ 
/*     */       
/* 128 */       String line = reader.readLine();
/* 129 */       line.substring(line.trim().lastIndexOf(' '));
/*     */       
/* 131 */       this.pn.setName(line);
/*     */ 
/*     */ 
/*     */       
/* 135 */       Map<Short, Short> transitionIdIndexMap = new HashMap<>();
/*     */ 
/*     */       
/* 138 */       short currentPlaceId = 0;
/* 139 */       short currentTransitionId = 0;
/*     */ 
/*     */ 
/*     */       
/* 143 */       StringBuffer buffer = new StringBuffer();
/* 144 */       while ((line = reader.readLine()) != null && !line.trim().equals("@")) {
/* 145 */         if (!line.trim().equals("")) {
/* 146 */           buffer.append(line.trim());
/* 147 */           buffer.append('\n');
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 153 */       reader.readLine();
/*     */ 
/*     */       
/* 156 */       while ((line = reader.readLine()) != null && !line.trim().equals("@")) {
/* 157 */         if (!line.trim().equals("")) {
/* 158 */           String[] data = line.trim().split("\\s+");
/*     */           
/* 160 */           String identifier = data[0].substring(0, data[0].length() - 1);
/* 161 */           int id = currentPlaceId = (short)(currentPlaceId + 1);
/* 162 */           int orgId = Integer.parseInt(identifier);
/*     */           
/* 164 */           int capacity = 0;
/*     */           
/* 166 */           String name = data[1];
/*     */ 
/*     */           
/* 169 */           int token = 0;
/*     */           
/* 171 */           Place place = new Place(identifier, name, token, id, orgId, capacity);
/* 172 */           this.pn.addPlace(place);
/* 173 */           this.pn.allNodes().put(identifier, place);
/* 174 */           this.pn.identifier().put(place, identifier);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 180 */       reader.readLine();
/*     */ 
/*     */       
/* 183 */       while ((line = reader.readLine()) != null && !line.trim().equals("@")) {
/* 184 */         if (!line.trim().equals("")) {
/* 185 */           String[] data = line.trim().split("\\s+");
/*     */           
/* 187 */           String identifier = data[0].substring(0, data[0].length() - 1);
/* 188 */           short id = Short.parseShort(identifier);
/*     */ 
/*     */           
/* 191 */           String name = data[1];
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 196 */           transitionIdIndexMap.put(Short.valueOf(id), Short.valueOf(currentTransitionId));
/*     */           
/* 198 */           Transition transition = new Transition(identifier, name, currentTransitionId);
/* 199 */           this.pn.addTransition(transition);
/* 200 */           this.pn.allNodes().put(identifier, transition);
/* 201 */           this.pn.identifier().put(transition, identifier);
/*     */           
/* 203 */           currentTransitionId = (short)(currentTransitionId + 1);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 209 */       BufferedReader edgeReader = new BufferedReader(new StringReader(buffer.toString()));
/* 210 */       while ((line = edgeReader.readLine()) != null) {
/*     */         
/* 212 */         String[] data = line.trim().split("\\s+", 3);
/*     */ 
/*     */         
/* 215 */         int id = Integer.parseInt(data[0]);
/* 216 */         int token = Integer.parseInt(data[1]);
/*     */ 
/*     */         
/* 219 */         Place place = this.pn.getPlaceByOrigId(id);
/* 220 */         place.setToken(token);
/*     */         
/* 222 */         this.initialMarking.add(place);
/* 223 */         this.initialMarking.add(Integer.valueOf(token));
/*     */ 
/*     */ 
/*     */         
/* 227 */         String[] prePost = data[2].split(",");
/*     */         
/* 229 */         String[] pre = prePost[0].split("(?<=\\d+(\\s*:\\s+\\d+)?\\s+)");
/* 230 */         String[] post = prePost[1].split("(?<=\\d+(\\s*:\\s+\\d+)?\\s+)");
/*     */         
/* 232 */         for (String e : pre) {
/* 233 */           int weight = 1;
/* 234 */           short transId = -1;
/*     */           
/* 236 */           if (e.contains(":")) {
/*     */             
/* 238 */             String[] idAndWeight = e.split(":");
/* 239 */             transId = Short.parseShort(idAndWeight[0].trim());
/* 240 */             weight = Integer.parseInt(idAndWeight[1].trim());
/*     */           }
/*     */           else {
/*     */             
/* 244 */             transId = Short.parseShort(e.trim());
/*     */           } 
/*     */ 
/*     */           
/* 248 */           Transition from = this.pn.getTransition(((Short)transitionIdIndexMap.get(Short.valueOf(transId))).shortValue());
/*     */ 
/*     */           
/* 251 */           this.pn.addEdge(from, place, weight, PlaceTransitionNet.EDGE);
/*     */         } 
/*     */         
/* 254 */         for (String e : post) {
/* 255 */           int weight = 1;
/* 256 */           short transId = -1;
/*     */           
/* 258 */           if (e.contains(":")) {
/*     */             
/* 260 */             String[] idAndWeight = e.split(":");
/* 261 */             transId = Short.parseShort(idAndWeight[0].trim());
/* 262 */             weight = Integer.parseInt(idAndWeight[1].trim());
/*     */           }
/*     */           else {
/*     */             
/* 266 */             transId = Short.parseShort(e.trim());
/*     */           } 
/*     */ 
/*     */           
/* 270 */           Transition to = this.pn.getTransition(((Short)transitionIdIndexMap.get(Short.valueOf(transId))).shortValue());
/*     */ 
/*     */           
/* 273 */           this.pn.addEdge(place, to, weight, PlaceTransitionNet.EDGE);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 280 */       edgeReader.close();
/*     */     } finally {
/*     */       try {
/* 283 */         reader.close();
/* 284 */       } catch (IOException e) {
/* 285 */         LOG.error(e.getMessage(), e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/InaReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */