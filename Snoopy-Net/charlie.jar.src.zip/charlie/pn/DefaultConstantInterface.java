/*   */ package charlie.pn;
/*   */ 
/*   */ public class DefaultConstantInterface
/*   */   implements ConstantInterface {
/*   */   public void askForValue(Constant c) {
/* 6 */     throw new RuntimeException("missing value for constant " + c.getName());
/*   */   }
/*   */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/DefaultConstantInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */