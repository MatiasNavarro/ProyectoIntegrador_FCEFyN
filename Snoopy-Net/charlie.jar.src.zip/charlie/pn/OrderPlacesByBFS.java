/*    */ package charlie.pn;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class OrderPlacesByBFS implements OrderingFunction {
/*    */   Vector translationTable;
/*    */   
/*    */   public OrderPlacesByBFS(PlaceTransitionNet pn) {
/* 10 */     this.pn = pn;
/*    */     
/* 12 */     Vector<Integer> v = pn.bfsLin(true);
/*    */     
/* 14 */     System.out.println(v);
/* 15 */     this.translationTable = new Vector(pn.places());
/* 16 */     int mod = 1;
/* 17 */     for (Iterator<Integer> it = v.iterator(); it.hasNext(); ) {
/* 18 */       Integer i = it.next();
/*    */       
/* 20 */       if (mod == 0) {
/* 21 */         this.translationTable.add(0, i); continue;
/*    */       } 
/* 23 */       this.translationTable.add(i);
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 29 */     System.out.println("places: " + this.translationTable);
/* 30 */     if (this.translationTable.size() != pn.places()) {
/* 31 */       System.out.println("error by ordering");
/* 32 */       System.exit(1);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   PlaceTransitionNet pn;
/*    */ 
/*    */   
/*    */   public Vector getTranslationTable() {
/* 42 */     return this.translationTable;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/OrderPlacesByBFS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */