/*     */ package charlie.pn;
/*     */ 
/*     */ import charlie.ds.BitSet;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileWriter;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NodeSet
/*     */   implements Iterable<Integer>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -447043389026635550L;
/*     */   private static PlaceTransitionNet pn;
/*     */   protected BitSet nodes;
/*     */   
/*     */   public NodeSet(int length) {
/*  27 */     this.nodes = new BitSet(length);
/*     */   }
/*     */   
/*     */   public BitSet nodes() {
/*  31 */     return this.nodes;
/*     */   }
/*     */   
/*     */   public NodeSet(int length, int filledTo) {
/*  35 */     this.nodes = new BitSet(length, filledTo);
/*     */   }
/*     */   
/*     */   public void clear() {
/*  39 */     this.nodes.clear();
/*     */   }
/*     */   
/*     */   public NodeSet(BitSet bs) {
/*  43 */     this.nodes = bs;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setNet(PlaceTransitionNet net) {
/*  48 */     pn = net;
/*     */   }
/*     */ 
/*     */   
/*     */   public static PlaceTransitionNet getNet() {
/*  53 */     return pn;
/*     */   }
/*     */   
/*     */   public int size() {
/*  57 */     return this.nodes.size();
/*     */   }
/*     */   
/*     */   public void insert(int nodeId) {
/*  61 */     this.nodes.insert(nodeId);
/*     */   }
/*     */   
/*     */   public void delete(int nodeId) {
/*  65 */     this.nodes.delete(nodeId);
/*     */   }
/*     */   
/*     */   public Iterator<Integer> iterator() {
/*  69 */     return this.nodes.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(NodeSet _ns) {
/*  81 */     return this.nodes.contains(_ns.nodes);
/*     */   }
/*     */   
/*     */   public boolean member(int nodeId) {
/*  85 */     return this.nodes.member(nodeId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract NodeSet getPre();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract NodeSet getEnvironment();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract NodeSet getPost();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String[] getNameArray();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String[] getIdArray();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String[] getOrigIdArray();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract NodeSet copy();
/*     */ 
/*     */   
/*     */   public void union(NodeSet ns) {
/* 118 */     if (getClass() != ns.getClass()) {
/* 119 */       throw new IllegalArgumentException("The given class must be " + NodeSet.class.getName());
/*     */     }
/* 121 */     this.nodes.union(ns.nodes);
/*     */   }
/*     */   
/*     */   public abstract NodeSet intersection(NodeSet paramNodeSet);
/*     */   
/*     */   public void diff(NodeSet ns) {
/* 127 */     if (getClass() != ns.getClass()) {
/* 128 */       throw new IllegalArgumentException("The given class must be " + NodeSet.class.getName());
/*     */     }
/* 130 */     this.nodes.diff(ns.nodes);
/*     */   }
/*     */   public boolean subSet(NodeSet ns) {
/* 133 */     if (getClass() != ns.getClass()) {
/* 134 */       throw new IllegalArgumentException("The given class must be " + NodeSet.class.getName());
/*     */     }
/* 136 */     return this.nodes.subSet(ns.nodes);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 140 */     return this.nodes.isEmpty();
/*     */   }
/*     */   
/*     */   public int first() {
/* 144 */     return this.nodes.first();
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeSet getEmptySet() {
/* 149 */     NodeSet n = copy();
/* 150 */     n.clear();
/* 151 */     return n;
/*     */   }
/*     */   
/*     */   public abstract PNNode getNode(int paramInt, boolean paramBoolean);
/*     */   
/*     */   public Set<NodeSet> decompose() {
/* 157 */     return decompose(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<NodeSet> decompose(NodeSet ignore) {
/* 162 */     Set<NodeSet> res = new HashSet<>();
/* 163 */     NodeSet unprocessedNodes = copy();
/* 164 */     NodeSet processedNodes = getEmptySet();
/* 165 */     NodeSet reachableUnprocessedNodes = getEmptySet();
/*     */     
/* 167 */     NodeSet reachableNodes = getEmptySet();
/*     */     
/* 169 */     while (!unprocessedNodes.isEmpty()) {
/* 170 */       int n = unprocessedNodes.first();
/* 171 */       unprocessedNodes.delete(n);
/* 172 */       processedNodes.insert(n);
/* 173 */       reachableUnprocessedNodes.insert(n);
/* 174 */       reachableNodes = getEmptySet();
/* 175 */       reachableNodes.insert(n);
/*     */       
/* 177 */       while (!reachableUnprocessedNodes.isEmpty()) {
/* 178 */         n = reachableUnprocessedNodes.first();
/* 179 */         reachableUnprocessedNodes.delete(n);
/* 180 */         PNNode pnn1 = getNode(n, true);
/*     */         
/* 182 */         for (Iterator<Integer> iterator = pnn1.postNodes().iterator(); iterator.hasNext(); ) {
/* 183 */           int m = ((Integer)iterator.next()).intValue();
/* 184 */           if (ignore != null && ignore.member(m)) {
/*     */             continue;
/*     */           }
/* 187 */           PNNode pnn2 = getNode(m, false);
/* 188 */           NodeSet intsec = pnn2.postNodes().intersection(this);
/* 189 */           reachableNodes.union(intsec);
/* 190 */           intsec.diff(processedNodes);
/* 191 */           reachableUnprocessedNodes.union(intsec);
/* 192 */           processedNodes.union(intsec);
/*     */         } 
/*     */       } 
/* 195 */       for (Iterator<NodeSet> it = res.iterator(); it.hasNext(); ) {
/* 196 */         NodeSet cur = it.next();
/* 197 */         NodeSet intsec = cur.intersection(reachableNodes);
/* 198 */         if (!intsec.isEmpty()) {
/* 199 */           cur.union(reachableNodes);
/* 200 */           unprocessedNodes.diff(reachableNodes);
/*     */         } 
/*     */       } 
/*     */       
/* 204 */       res.add(reachableNodes);
/* 205 */       unprocessedNodes.diff(reachableNodes);
/*     */     } 
/* 207 */     return res;
/*     */   }
/*     */   
/*     */   public static void writeToFile(String filename, String title, Collection<NodeSet> nodesets) {
/* 211 */     if (filename == null || filename.equals("")) {
/*     */       return;
/*     */     }
/*     */     try {
/* 215 */       BufferedWriter out = new BufferedWriter(new FileWriter(filename));
/* 216 */       String str = title + "\n";
/* 217 */       out.write(str, 0, str.length());
/* 218 */       int i = 1;
/* 219 */       for (Iterator<NodeSet> it = nodesets.iterator(); it.hasNext(); ) {
/* 220 */         NodeSet ns = it.next();
/* 221 */         str = "" + i + ns.toString() + "\n";
/* 222 */         out.write(str, 0, str.length());
/* 223 */         i++;
/*     */       } 
/* 225 */       out.close();
/* 226 */       Out.println("file written: " + filename);
/* 227 */     } catch (Exception ex) {
/* 228 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String writeToString(String title, Collection<NodeSet> nodesets) {
/*     */     try {
/* 236 */       StringBuilder out = new StringBuilder();
/* 237 */       out.append(title + "\n");
/* 238 */       int i = 1;
/* 239 */       for (NodeSet ns : nodesets) {
/* 240 */         out.append("" + i + ns.toString() + "\n");
/* 241 */         i++;
/*     */       } 
/*     */       
/* 244 */       return out.toString();
/* 245 */     } catch (Exception ex) {
/* 246 */       ex.printStackTrace();
/*     */       
/* 248 */       return "";
/*     */     } 
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 253 */     int prime = 31;
/* 254 */     int result = 1;
/* 255 */     result = 31 * result + ((this.nodes == null) ? 0 : this.nodes.hashCode());
/* 256 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 261 */     if (this == obj) {
/* 262 */       return true;
/*     */     }
/* 264 */     if (obj == null) {
/* 265 */       return false;
/*     */     }
/* 267 */     if (getClass() != obj.getClass()) {
/* 268 */       return false;
/*     */     }
/*     */     
/* 271 */     NodeSet other = (NodeSet)obj;
/* 272 */     if (this.nodes == null) {
/* 273 */       if (other.nodes != null) {
/* 274 */         return false;
/*     */       }
/* 276 */     } else if (!this.nodes.equals(other.nodes)) {
/* 277 */       return false;
/*     */     } 
/*     */     
/* 280 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/NodeSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */