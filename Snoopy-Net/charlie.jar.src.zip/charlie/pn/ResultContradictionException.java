/*    */ package charlie.pn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultContradictionException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1207630177507585511L;
/*    */   
/*    */   public ResultContradictionException() {}
/*    */   
/*    */   public ResultContradictionException(String _message) {
/* 15 */     super(_message);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/ResultContradictionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */