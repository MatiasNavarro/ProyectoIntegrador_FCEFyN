/*    */ package charlie.pn;
/*    */ 
/*    */ 
/*    */ public class NodeList
/*    */ {
/*    */   private NodeT[] nodes;
/*    */   private int current;
/*    */   int size;
/*  9 */   int counter = 0;
/* 10 */   int gtcounter = 0;
/* 11 */   int fcounter = 0;
/*    */ 
/*    */   
/*    */   public NodeList(int size) {
/* 15 */     this.size = size;
/* 16 */     this.nodes = new NodeT[size];
/* 17 */     for (int i = 0; i < size; i++) {
/* 18 */       this.nodes[i] = new NodeT();
/*    */     }
/* 20 */     this.current = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NodeT getNext() {
/* 34 */     this.gtcounter++;
/* 35 */     if (this.size == 0) {
/*    */       
/* 37 */       this.counter++;
/* 38 */       return new NodeT();
/* 39 */     }  if (this.current == this.nodes.length) {
/* 40 */       this.current = 0;
/*    */     }
/* 42 */     while (!(this.nodes[this.current]).free) {
/* 43 */       this.current++;
/*    */     }
/* 45 */     NodeT res = this.nodes[this.current];
/* 46 */     res.free = false;
/* 47 */     res.next = null;
/* 48 */     res.place = null;
/* 49 */     res.prev = null;
/* 50 */     this.current++;
/* 51 */     this.size--;
/* 52 */     return res;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void free(NodeT n) {
/* 58 */     this.fcounter++;
/* 59 */     if (n.prev != null) {
/* 60 */       n.prev.next = null;
/*    */     }
/* 62 */     n.prev = null;
/* 63 */     n.free = true;
/* 64 */     this.size++;
/*    */   }
/*    */   
/*    */   public void freeAll(NodeT n) {
/* 68 */     while (n != null) {
/* 69 */       if (n.prev != null) {
/* 70 */         n.prev.next = null;
/*    */       }
/*    */       
/* 73 */       this.fcounter++;
/* 74 */       n.prev = null;
/* 75 */       n.free = true;
/* 76 */       this.size++;
/* 77 */       n = n.next;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/NodeList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */