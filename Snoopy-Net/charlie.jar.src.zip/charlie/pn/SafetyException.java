package charlie.pn;

public class SafetyException extends Exception {
  private static final long serialVersionUID = -1052559632374668197L;
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SafetyException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */