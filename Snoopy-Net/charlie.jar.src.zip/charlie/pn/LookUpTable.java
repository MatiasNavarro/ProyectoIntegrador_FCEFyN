/*    */ package charlie.pn;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LookUpTable
/*    */ {
/*    */   private static final int MAX = 128;
/*    */   private static int places;
/*    */   private static int transitions;
/*    */   private static Map<Integer, Map<Integer, Weight>> map;
/*    */   
/*    */   public static void init(int p, int t) {
/* 17 */     places = p;
/* 18 */     transitions = t;
/* 19 */     map = new HashMap<>(p);
/*    */   }
/*    */   
/*    */   public static Weight lookUp(int id, int token) {
/* 23 */     Integer key = new Integer(token);
/* 24 */     if (!map.containsKey(key)) {
/* 25 */       map.put(key, new HashMap<>());
/*    */     }
/* 27 */     Map<Integer, Weight> hm = map.get(key);
/* 28 */     Integer val = new Integer(id);
/* 29 */     if (hm.containsKey(val)) {
/* 30 */       return hm.get(val);
/*    */     }
/* 32 */     Weight w = new IntWeight(id, token);
/* 33 */     hm.put(val, w);
/* 34 */     return w;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int places() {
/* 39 */     return places;
/*    */   }
/*    */   
/*    */   public static int transitions() {
/* 43 */     return transitions;
/*    */   }
/*    */   
/*    */   public static Weight addPlace(int id, int token) {
/* 47 */     return lookUp(id, token);
/*    */   }
/*    */   
/*    */   public static int[] boundednessOfPlaces() {
/* 51 */     int[] res = new int[places];
/* 52 */     for (int i = 0; i < places; i++) {
/* 53 */       res[i] = -1;
/*    */     }
/* 55 */     for (Iterator<Integer> it = map.keySet().iterator(); it.hasNext(); ) {
/* 56 */       Integer key = it.next();
/* 57 */       int token = key.intValue();
/* 58 */       Map<Integer, Weight> map2 = map.get(key);
/* 59 */       for (Iterator<Integer> it2 = map2.keySet().iterator(); it2.hasNext(); ) {
/* 60 */         int id = ((Integer)it2.next()).intValue();
/* 61 */         if (res[UnsignedByte.sign(id)] < token) {
/* 62 */           res[UnsignedByte.sign(id)] = token;
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 67 */     return res;
/*    */   }
/*    */ 
/*    */   
/*    */   public static int mostToken() {
/* 72 */     int max = 0;
/* 73 */     for (Iterator<Integer> it = map.keySet().iterator(); it.hasNext(); ) {
/* 74 */       int key = ((Integer)it.next()).intValue();
/* 75 */       if (key > max) {
/* 76 */         max = key;
/*    */       }
/*    */     } 
/*    */     
/* 80 */     return max;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/LookUpTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */