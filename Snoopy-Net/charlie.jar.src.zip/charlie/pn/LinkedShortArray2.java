/*    */ package charlie.pn;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class LinkedShortArray2 implements LinkedArray {
/*    */   Vector arrays;
/*    */   int arraySize;
/*  8 */   int size = 0;
/*  9 */   int resized = 0;
/* 10 */   final int INCREASE = 10;
/*    */   
/*    */   public LinkedShortArray2(int arraySize, int size) {
/* 13 */     this.arrays = new Vector(size);
/* 14 */     this.arraySize = arraySize;
/* 15 */     this.arrays.add(new short[arraySize]);
/* 16 */     this.size++;
/*    */   }
/*    */   
/*    */   public void set(int index, int value) {
/*    */     try {
/* 21 */       if (value > 32767 || value < -32768) {
/* 22 */         System.out.println(value + " to large for short");
/* 23 */         System.exit(1);
/*    */       } 
/* 25 */       int vectorIndex = index / this.arraySize;
/* 26 */       ((short[])this.arrays.get(vectorIndex))[index % this.arraySize] = (short)value;
/* 27 */     } catch (Exception e) {
/*    */ 
/*    */       
/* 30 */       increasing();
/* 31 */       set(index, value);
/*    */     } 
/*    */   }
/*    */   
/*    */   public int get(int index) {
/*    */     try {
/* 37 */       int vectorIndex = index / this.arraySize;
/* 38 */       return ((short[])this.arrays.get(vectorIndex))[index % this.arraySize];
/* 39 */     } catch (Exception e) {
/*    */ 
/*    */       
/* 42 */       increasing();
/* 43 */       return get(index);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void doubling() {
/* 48 */     for (int i = 0; i < this.size; i++) {
/* 49 */       this.arrays.add(new short[this.arraySize]);
/*    */     }
/* 51 */     this.size *= 2;
/*    */     
/* 53 */     this.resized++;
/* 54 */     if (this.resized % 1000 == 0) System.out.println("size: " + this.size); 
/*    */   }
/*    */   
/*    */   private void increasing() {
/* 58 */     for (int i = 0; i < 10; i++) {
/* 59 */       this.arrays.add(new short[this.arraySize]);
/*    */     }
/* 61 */     this.size += 10;
/* 62 */     this.resized++;
/* 63 */     if (this.resized % 1000 == 0)
/* 64 */       System.out.println("size ShortArray: " + this.size); 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/LinkedShortArray2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */