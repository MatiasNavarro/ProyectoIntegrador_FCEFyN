/*     */ package charlie.pn;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SortedElementsByte
/*     */   extends Marking
/*     */ {
/*  11 */   private static final Log LOG = LogFactory.getLog(SortedElementsByte.class);
/*     */   private byte[] places;
/*     */   private int hashC;
/*     */   private short size;
/*     */   
/*     */   public void reset() {
/*  17 */     UnsignedByte.init(this.places, size());
/*  18 */     this.size = 0;
/*  19 */     this.hashC = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTokenById(int id) {
/*  24 */     int lB = 0;
/*  25 */     int uB = size() - 1;
/*     */     
/*  27 */     int mid = 0;
/*     */     
/*  29 */     while (lB != uB) {
/*  30 */       if (id == this.places[lB] || id == this.places[uB]) {
/*  31 */         return 1;
/*     */       }
/*     */       
/*  34 */       mid = (lB + uB) / 2;
/*  35 */       if (id == this.places[mid]) {
/*  36 */         return 1;
/*     */       }
/*     */       
/*  39 */       if (id > this.places[mid]) {
/*  40 */         lB = mid;
/*     */       } else {
/*  42 */         uB = mid;
/*     */       } 
/*     */       
/*  45 */       if (mid == (lB + uB) / 2) {
/*     */         break;
/*     */       }
/*     */       
/*  49 */       mid = (lB + uB) / 2;
/*     */     } 
/*  51 */     if (id == this.places[mid]) {
/*  52 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*  56 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Marking copy() throws SafetyException, ExceedsByteException {
/*  61 */     Marking ret = SortedElementsFactory.getSortedPlaces(size());
/*  62 */     ret.name = "SEByte.copy() " + this.name;
/*     */     
/*  64 */     for (int i = 0; i < size(); i++) {
/*  65 */       ret.addPlace(getId(i), 1);
/*     */     }
/*  67 */     ((SortedElementsByte)ret).hashC = this.hashC;
/*     */     
/*  69 */     return ret;
/*     */   }
/*     */   
/*     */   public SortedElementsByte(byte[] p) {
/*  73 */     this.places = p;
/*  74 */     this.size = (short)p.length;
/*     */     
/*  76 */     for (int i = p.length - 1; i >= 0 && 
/*  77 */       this.places[i] == UnsignedByte.zero; i--) {
/*  78 */       this.size = (short)(this.size - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedElementsByte(int p) {
/*  88 */     this.places = new byte[p];
/*  89 */     UnsignedByte.init(this.places);
/*  90 */     this.size = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  95 */     return this.size;
/*     */   }
/*     */ 
/*     */   
/*     */   public SortedElementsByte toArray() throws SafetyException, ExceedsByteException {
/* 100 */     return (SortedElementsByte)copy();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 105 */     StringBuffer res = new StringBuffer();
/* 106 */     for (int i = 0; i < size(); i++) {
/* 107 */       res.append(this.places[i]);
/* 108 */       res.append(" 1");
/* 109 */       if (i < size() - 1) {
/* 110 */         res.append(" ");
/*     */       }
/*     */     } 
/*     */     
/* 114 */     return res.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Weight get(int index) {
/* 119 */     if (index >= size() || index < 0) {
/* 120 */       return null;
/*     */     }
/*     */     
/* 123 */     Weight ret = LookUpTable.lookUp(this.places[index], 1);
/*     */     
/* 125 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getId(int index) {
/* 130 */     return this.places[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getToken(int index) {
/* 135 */     return 1;
/*     */   }
/*     */   
/*     */   public int setToken(int index, byte t) throws SafetyException {
/* 139 */     if (t > 1) {
/* 140 */       LOG.error("setToken: net is not save -> token: " + t + "! exit");
/* 141 */       throw new SafetyException();
/*     */     } 
/* 143 */     return 1;
/*     */   }
/*     */   
/*     */   public int addToken(int index, byte t) throws SafetyException {
/* 147 */     if (t > 1) {
/* 148 */       LOG.error("setToken: net is not save -> token: " + t + "! exit");
/* 149 */       throw new SafetyException();
/*     */     } 
/* 151 */     return 1;
/*     */   }
/*     */   
/*     */   public byte[] getPlaces() {
/* 155 */     return this.places;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 160 */     if (!(obj instanceof SortedElementsByte)) {
/* 161 */       return false;
/*     */     }
/* 163 */     SortedElementsByte spa = (SortedElementsByte)obj;
/* 164 */     if (size() != spa.size()) {
/* 165 */       return false;
/*     */     }
/* 167 */     for (int i = 0; i < size(); i++) {
/* 168 */       if (this.places[i] != spa.places[i]) {
/* 169 */         return false;
/*     */       }
/*     */     } 
/* 172 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 177 */     int h = this.hashC;
/* 178 */     if (h == 0) {
/* 179 */       for (int i = 0; i < size(); i++) {
/* 180 */         this.hashC = 31 * this.hashC + this.places[i];
/*     */       }
/* 182 */       h = this.hashC;
/*     */     } 
/* 184 */     return h;
/*     */   }
/*     */ 
/*     */   
/*     */   public int addPlace(int id, int token) throws SafetyException {
/* 189 */     int i = 0;
/* 190 */     boolean b = true;
/* 191 */     int index = 0;
/*     */     
/* 193 */     for (i = 0; b && i < this.places.length; i++) {
/* 194 */       if (this.places[i] >= id || this.places[i] == UnsignedByte.zero) {
/*     */ 
/*     */         
/* 197 */         b = false;
/* 198 */         index = i;
/* 199 */         if (this.places[i] == id) {
/* 200 */           LOG.error("addPlace 2 not save at place: " + id);
/* 201 */           throw new SafetyException();
/*     */         } 
/*     */       } 
/*     */     } 
/* 205 */     for (i = this.places.length - 1; i > index; i--) {
/* 206 */       this.places[i] = this.places[i - 1];
/*     */     }
/* 208 */     this.places[index] = (byte)id;
/*     */     
/* 210 */     LookUpTable.addPlace(id, 1);
/* 211 */     this.size = (short)(this.size + 1);
/*     */     
/* 213 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSubSet(Marking sp) {
/* 218 */     if (!(sp instanceof SortedElementsByte)) {
/* 219 */       return false;
/*     */     }
/*     */     
/* 222 */     SortedElementsByte spa = (SortedElementsByte)sp;
/* 223 */     if (size() > spa.size()) {
/* 224 */       return false;
/*     */     }
/*     */     
/* 227 */     int index = 0;
/* 228 */     int i = 0;
/* 229 */     Weight current = get(index);
/* 230 */     while (index < size()) {
/*     */       
/* 232 */       int curId = current.getId();
/* 233 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 234 */         i++;
/*     */       }
/* 236 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 237 */         return false;
/*     */       }
/* 239 */       current = get(++index);
/* 240 */       i++;
/*     */     } 
/* 242 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int isSubSet2(Marking spa) {
/* 247 */     if (size() > spa.size()) {
/* 248 */       return (byte)(UnsignedByte.min - 1);
/*     */     }
/*     */     
/* 251 */     int ret = 0;
/* 252 */     int index = 0;
/* 253 */     int i = 0;
/* 254 */     Weight current = get(index);
/* 255 */     while (index < size()) {
/*     */       
/* 257 */       int curId = current.getId();
/* 258 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 259 */         if (spa.getId(i) > curId) {
/* 260 */           return -1;
/*     */         }
/* 262 */         i++;
/*     */       } 
/*     */       
/* 265 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 266 */         return -1;
/*     */       }
/*     */       
/* 269 */       if (i < spa.size() && current.less(spa.get(i)) == 0) {
/* 270 */         ret++;
/*     */       }
/*     */       
/* 273 */       current = get(++index);
/* 274 */       i++;
/*     */     } 
/*     */     
/* 277 */     return spa.size() - ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Integer> scapeGoats(Marking spa) {
/* 282 */     Collection<Integer> c = new Vector<>();
/* 283 */     int index = 0;
/* 284 */     int i = 0;
/* 285 */     Weight current = get(index);
/* 286 */     while (index < size()) {
/* 287 */       int curId = current.getId();
/* 288 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 289 */         i++;
/*     */       }
/* 291 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 292 */         c.add(new Integer((byte)curId));
/* 293 */         i = 0;
/* 294 */         current = get(++index);
/*     */         
/*     */         continue;
/*     */       } 
/* 298 */       current = get(++index);
/* 299 */       i++;
/*     */     } 
/* 301 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public int fSG(Marking spa) {
/* 306 */     int index = 0;
/* 307 */     int i = 0;
/* 308 */     Weight current = get(index);
/* 309 */     while (index < size()) {
/* 310 */       int curId = current.getId();
/* 311 */       while (i < spa.size() && spa.get(i).getId() != curId) {
/* 312 */         i++;
/*     */       }
/* 314 */       if (i == spa.size() || current.less(spa.get(i)) < 0) {
/* 315 */         return (byte)curId;
/*     */       }
/* 317 */       current = get(++index);
/* 318 */       i++;
/*     */     } 
/* 320 */     return (byte)(UnsignedByte.min - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retains(Marking s) {
/* 325 */     int index = 0;
/* 326 */     int i = 0;
/* 327 */     Weight current = get(index);
/*     */     
/* 329 */     while (index < size()) {
/* 330 */       Weight current2 = s.get(i);
/*     */       
/* 332 */       int curId = current.getId();
/* 333 */       while (i < s.size() && current2.getId() < curId) {
/* 334 */         current2 = s.get(++i);
/*     */       }
/* 336 */       if (i < s.size() && curId == current2.getId()) {
/* 337 */         return true;
/*     */       }
/* 339 */       current2 = s.get(++i);
/* 340 */       current = get(++index);
/*     */     } 
/* 342 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<? extends Number> covers(Marking sp) {
/* 347 */     if (sp.size() > size()) {
/* 348 */       return null;
/*     */     }
/*     */     
/* 351 */     Collection<Byte> v = null;
/* 352 */     SortedElementsByte spa = (SortedElementsByte)sp;
/* 353 */     int index = 0;
/* 354 */     int i = 0;
/*     */     
/* 356 */     while (index < spa.size()) {
/* 357 */       Weight current = spa.get(index);
/* 358 */       int curId = current.getId();
/* 359 */       while (i < size() && get(i).getId() != curId) {
/* 360 */         if (getId(i) > curId) {
/* 361 */           return null;
/*     */         }
/* 363 */         if (v == null) {
/* 364 */           v = new Vector<>();
/*     */         }
/* 366 */         v.add(Byte.valueOf((byte)getId(i)));
/* 367 */         i++;
/*     */       } 
/* 369 */       if (i == size() || current.less(get(i)) < 0) {
/* 370 */         return null;
/*     */       }
/* 372 */       if (i < size() && getId(i) == curId && current
/* 373 */         .getToken() < get(i).getToken()) {
/* 374 */         if (v == null) {
/* 375 */           v = new Vector<>();
/*     */         }
/* 377 */         v.add(Byte.valueOf((byte)get(i).getId()));
/*     */       } 
/*     */       
/* 380 */       index++;
/* 381 */       i++;
/*     */     } 
/*     */     
/* 384 */     while (i < size()) {
/* 385 */       if (v == null) {
/* 386 */         v = new Vector<>();
/*     */       }
/*     */       
/* 389 */       v.add(Byte.valueOf((byte)getId(i)));
/* 390 */       i++;
/*     */     } 
/*     */     
/* 393 */     return (Collection)v;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/SortedElementsByte.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */