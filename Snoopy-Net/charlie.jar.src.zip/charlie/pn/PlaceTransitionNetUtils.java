/*     */ package charlie.pn;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlaceTransitionNetUtils
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6471147473556339818L;
/*     */   private PlaceTransitionNet pn;
/*     */   private int[][] incidenceMatrix;
/*  34 */   private NetClass netclass = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlaceTransitionNetUtils(PlaceTransitionNet _pn) {
/*  42 */     this.pn = _pn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PlaceTransitionNet getPN() {
/*  51 */     return this.pn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(Transition _t) {
/*  63 */     PlaceSet prePlaces = (PlaceSet)_t.preNodes();
/*     */     
/*  65 */     for (Integer i : prePlaces) {
/*  66 */       Place p = this.pn.getPlaceByIndex(i.intValue());
/*     */       
/*  68 */       if (this.pn.takesTokenFrom(p, _t) > p.getToken())
/*     */       {
/*  70 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  75 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] getIncidenceMatrix() {
/*  93 */     if (this.incidenceMatrix == null) {
/*  94 */       this.incidenceMatrix = copyIncidenceMatrix();
/*     */     }
/*     */     
/*  97 */     return this.incidenceMatrix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetIncidenceMatrix() {
/* 109 */     this.incidenceMatrix = (int[][])null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[][] copyIncidenceMatrix() {
/* 125 */     int[][] incMatrix = new int[this.pn.places()][this.pn.transitions()];
/*     */     
/* 127 */     for (int i = 0; i < this.pn.places(); i++) {
/* 128 */       for (int j = 0; j < this.pn.transitions(); j++) {
/* 129 */         incMatrix[i][j] = this.pn.changesTokenOn(this.pn.getPlaceByIndex(i), this.pn
/* 130 */             .getTransition((short)j));
/*     */       }
/*     */     } 
/*     */     
/* 134 */     return incMatrix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStateMachine() {
/* 143 */     if (this.netclass != null) {
/* 144 */       return (this.netclass == NetClass.SM_AND_MG || this.netclass == NetClass.SM);
/*     */     }
/*     */     
/* 147 */     for (Transition t : this.pn.getTransitions()) {
/* 148 */       if (t.postNodes().size() != 1 || t.preNodes().size() != 1) {
/* 149 */         return false;
/*     */       }
/*     */     } 
/* 152 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMarkingGraph() {
/* 161 */     if (this.netclass != null) {
/* 162 */       return (this.netclass == NetClass.SM_AND_MG || this.netclass == NetClass.MG);
/*     */     }
/*     */     
/* 165 */     for (Place p : this.pn.getPlaces()) {
/* 166 */       if (p.postNodes().size() != 1 || p.preNodes().size() != 1) {
/* 167 */         return false;
/*     */       }
/*     */     } 
/* 170 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NetClass getNetClass() {
/* 179 */     if (this.netclass != null) {
/* 180 */       return this.netclass;
/*     */     }
/*     */     
/* 183 */     boolean sm = false;
/* 184 */     boolean mg = false;
/*     */     
/* 186 */     if (isStateMachine()) {
/* 187 */       sm = true;
/*     */     }
/* 189 */     if (isMarkingGraph()) {
/* 190 */       mg = true;
/*     */     }
/*     */     
/* 193 */     if (sm && mg)
/* 194 */       return NetClass.SM_AND_MG; 
/* 195 */     if (sm)
/* 196 */       return NetClass.SM; 
/* 197 */     if (mg) {
/* 198 */       return NetClass.MG;
/*     */     }
/*     */     
/* 201 */     boolean fc = true;
/* 202 */     boolean efc = true;
/* 203 */     boolean es = true; Iterator<Place> it;
/* 204 */     label56: for (it = this.pn.getPlaces().iterator(); it.hasNext(); ) {
/* 205 */       Place p = it.next();
/* 206 */       NodeSet pf = p.postNodes();
/* 207 */       Place p2 = null;
/* 208 */       for (Iterator<Integer> it2 = pf.iterator(); it2.hasNext(); ) {
/* 209 */         Transition t = this.pn.getTransition((short)((Integer)it2.next()).intValue());
/*     */         
/* 211 */         for (Iterator<Integer> it3 = pf.iterator(); it3.hasNext(); ) {
/* 212 */           Transition t2 = this.pn.getTransition((short)((Integer)it3.next()).intValue());
/* 213 */           if (t.getId() == t2.getId()) {
/*     */             continue;
/*     */           }
/* 216 */           if (fc && t.getPre().size() == 1 && t2.getPre().size() == 1) {
/*     */             continue;
/*     */           }
/* 219 */           fc = false;
/*     */           
/* 221 */           if (efc && t.preNodes().equals(t2.preNodes())) {
/*     */             continue;
/*     */           }
/* 224 */           efc = false;
/*     */           
/* 226 */           if (es) {
/* 227 */             for (Iterator<Integer> it4 = t2.preNodes().iterator(); it4.hasNext(); ) {
/* 228 */               p2 = this.pn.getPlaceByIndex(((Integer)it4.next()).intValue());
/* 229 */               if (p2.postNodes().subSet(p.postNodes()) || p
/* 230 */                 .postNodes().subSet(p2.postNodes()))
/*     */                 continue; 
/* 232 */               es = false;
/*     */               
/*     */               break label56;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 241 */     if (fc) {
/* 242 */       return NetClass.FC;
/*     */     }
/* 244 */     if (efc) {
/* 245 */       return NetClass.EFC;
/*     */     }
/* 247 */     if (es) {
/* 248 */       return NetClass.ES;
/*     */     }
/* 250 */     return NetClass.NES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetNetClass() {
/* 257 */     this.netclass = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum NetClass
/*     */   {
/* 269 */     SM_AND_MG,
/*     */ 
/*     */ 
/*     */     
/* 273 */     SM,
/*     */ 
/*     */ 
/*     */     
/* 277 */     MG,
/*     */ 
/*     */ 
/*     */     
/* 281 */     FC,
/*     */ 
/*     */ 
/*     */     
/* 285 */     EFC,
/*     */ 
/*     */ 
/*     */     
/* 289 */     ES,
/*     */ 
/*     */ 
/*     */     
/* 293 */     NES;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/pn/PlaceTransitionNetUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */