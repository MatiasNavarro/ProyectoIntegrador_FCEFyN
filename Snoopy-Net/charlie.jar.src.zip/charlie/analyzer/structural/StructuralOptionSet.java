/*    */ package charlie.analyzer.structural;
/*    */ 
/*    */ import charlie.analyzer.OptionSet;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StructuralOptionSet
/*    */   extends OptionSet
/*    */ {
/*    */   public String toString() {
/* 12 */     return "charlie.analyzer.structural.StructuralOptionSet";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Properties getAsProperties() {
/* 21 */     return new Properties();
/*    */   }
/*    */   
/*    */   public boolean initByProperties(Properties props) {
/* 25 */     return true;
/*    */   }
/*    */   public String getHtmlInfo() {
/* 28 */     StringBuffer buf = new StringBuffer();
/* 29 */     buf.append("<html><table border=\"1px\">");
/* 30 */     buf.append("<tr><td width=\"200px\">");
/* 31 */     buf.append("Structural options");
/* 32 */     buf.append("</td><td width=\"200px\"></td></tr>");
/* 33 */     buf.append("<tr><td>    </td><td>");
/* 34 */     buf.append("  ");
/* 35 */     buf.append("</td></tr><tr><td>     </td><td>");
/* 36 */     buf.append("   ");
/* 37 */     buf.append("</td></tr></table></html>");
/* 38 */     return buf.toString();
/*    */   }
/*    */   public boolean initializeByString(String parameters) {
/* 41 */     return true;
/*    */   }
/*    */   
/*    */   public static String getHelpString() {
/* 45 */     StringBuilder buf = new StringBuilder();
/* 46 */     buf.append("\nStructural properties analysis options\n");
/* 47 */     buf.append("--------------------------------------\n");
/* 48 */     buf.append("Invoke analysis by typing --analyze=PROPS or --analyze=props \n\n");
/* 49 */     buf.append("There are no further options for this analysis, all structural properties\n of the net are determined\n");
/* 50 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/structural/StructuralOptionSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */