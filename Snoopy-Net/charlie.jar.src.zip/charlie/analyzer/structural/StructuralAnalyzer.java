/*     */ package charlie.analyzer.structural;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.pn.PNNode;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Result;
/*     */ import charlie.pn.Transition;
/*     */ import charlie.pn.TransitionSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StructuralAnalyzer
/*     */   extends Analyzer
/*     */ {
/*     */   private static final long serialVersionUID = 7778408214848053472L;
/*  33 */   private static final Log LOG = LogFactory.getLog(StructuralAnalyzer.class);
/*     */   
/*  35 */   private PlaceTransitionNet pn = null;
/*  36 */   private Vector<TransitionSet> sccs = null;
/*  37 */   private Vector<TransitionSet> secs = null;
/*     */ 
/*     */   
/*     */   public StructuralAnalyzer() {
/*  41 */     this.immediateExecution = true;
/*  42 */     setUpdateInterval(1L);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  47 */     return "Structural Analyzer";
/*     */   }
/*     */ 
/*     */   
/*     */   public Analyzer getNewInstance(OptionSet options) {
/*  52 */     StructuralAnalyzer a = new StructuralAnalyzer();
/*  53 */     a.setup(options);
/*  54 */     return a;
/*     */   }
/*     */   
/*     */   public static boolean register() {
/*  58 */     PlaceTransitionNet pn = new PlaceTransitionNet();
/*  59 */     StructuralAnalyzer sa = new StructuralAnalyzer();
/*  60 */     boolean value = AnalyzerManagerFactory.getAnalyzerManager().register(sa, pn, pn);
/*     */     
/*  62 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeInfoStrings() {
/*  70 */     int count = 8;
/*  71 */     this.infoStrings = new String[count];
/*  72 */     this.infoStrings[0] = "Time:";
/*  73 */     this.infoStrings[1] = "";
/*  74 */     this.infoStrings[2] = "rows";
/*  75 */     this.infoStrings[3] = "";
/*  76 */     this.infoStrings[4] = "Columns";
/*  77 */     this.infoStrings[5] = "";
/*  78 */     this.infoStrings[6] = "Nets:";
/*  79 */     this.infoStrings[7] = "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluate() {
/*  90 */     this.pn = (PlaceTransitionNet)this.options.getObjectToAnalyze();
/*  91 */     if (this.pn == null) {
/*  92 */       DebugCounter.inc("NO place transition net on Structural analyzer");
/*     */       
/*     */       return;
/*     */     } 
/*  96 */     addOutput(String.format("\nnumber of places: %d", new Object[] { Integer.valueOf(this.pn.places()) }));
/*  97 */     addOutput(String.format("number of transitions: %d", new Object[] { Integer.valueOf(this.pn.transitions()) }));
/*  98 */     addOutput(String.format("number of arcs: %d", new Object[] { Integer.valueOf(this.pn.edges()) }));
/*  99 */     addOutput("\n");
/*     */     
/* 101 */     if (!this.pn.getFP0().isEmpty()) {
/* 102 */       addOutput("input places:\n" + this.pn.getFP0());
/*     */     } else {
/* 104 */       addOutput("input places:\nno input places");
/*     */     } 
/* 106 */     if (!this.pn.getPF0().isEmpty()) {
/* 107 */       addOutput("output places:\n" + this.pn.getPF0());
/*     */     } else {
/* 109 */       addOutput("output places:\nno output places");
/*     */     } 
/*     */     
/* 112 */     if (!this.pn.getFT0().isEmpty()) {
/* 113 */       DebugCounter.inc("pn.getFT0().isEmpty() == false => " + this.pn.getFT0());
/* 114 */       addResult(19, new Result(Boolean.valueOf(false)));
/* 115 */       addOutput("input transitions:\n" + this.pn.getFT0());
/* 116 */       addResult(18, new Result(Boolean.valueOf(false)));
/* 117 */       addResult(20, new Result(Boolean.valueOf(false)));
/*     */     } else {
/*     */       
/* 120 */       DebugCounter.inc("pn.getFT0().isEmpty() == true => no input transitions");
/* 121 */       addOutput("input transitions:\nno input transitions");
/*     */     } 
/* 123 */     if (!this.pn.getTF0().isEmpty()) {
/* 124 */       addOutput("output transitions:\n" + this.pn.getTF0());
/*     */     } else {
/* 126 */       addOutput("output transitions:\nno output transitions");
/*     */     } 
/*     */     
/* 129 */     if (this.pn.isExtendedPN()) {
/* 130 */       addOutput("the net contains non-standard arcs");
/* 131 */       if (!this.pn.getTransitionsRead().isEmpty()) {
/* 132 */         addOutput("the following transitions are incident to read arcs:");
/* 133 */         addOutput(this.pn.getTransitionsRead().toString());
/*     */       } 
/* 135 */       if (!this.pn.getTransitionsInhibitor().isEmpty()) {
/* 136 */         addOutput("the following transitions are incident to inhibitor arcs:");
/* 137 */         addOutput(this.pn.getTransitionsInhibitor().toString());
/*     */       } 
/* 139 */       if (!this.pn.getTransitionsReset().isEmpty()) {
/* 140 */         addOutput("the following transitions are incident to reset arcs:");
/* 141 */         addOutput(this.pn.getTransitionsReset().toString());
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 147 */     addResult(4, new Result(this.pn.isConservative()));
/* 148 */     addResult(3, new Result(Boolean.valueOf(this.pn.hasNBM())));
/* 149 */     addResult(1, new Result(this.pn.isOrdinary()));
/*     */     
/* 151 */     addResult(10, new Result(isConnected()));
/* 152 */     addResult(11, new Result(Boolean.valueOf(this.pn.isStronglyConnected())));
/* 153 */     addResult(2, new Result(new Boolean(this.pn.homogenous)));
/* 154 */     addResult(0, new Result(this.pn.isPure()));
/* 155 */     addResult(5, new Result(Boolean.valueOf(this.pn.isSCF())));
/*     */ 
/*     */     
/* 158 */     addResult(6, new Result(Boolean.valueOf(this.pn.getFT0().isEmpty())));
/* 159 */     addResult(7, new Result(Boolean.valueOf(this.pn.getTF0().isEmpty())));
/*     */ 
/*     */     
/* 162 */     addResult(9, new Result(Boolean.valueOf(this.pn.getPF0().isEmpty())));
/* 163 */     addResult(8, new Result(Boolean.valueOf(this.pn.getFP0().isEmpty())));
/*     */     
/* 165 */     if (this.pn.getM0().getMaxToken() > 1) {
/* 166 */       addResult(20, new Result(Boolean.valueOf(false)));
/*     */     }
/*     */     
/* 169 */     determineNetClass();
/* 170 */     determineSCS();
/*     */     
/* 172 */     addResult(29, Integer.valueOf(this.secs.size()));
/* 173 */     addResult(28, Integer.valueOf(this.sccs.size()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze() {
/* 184 */     this.pn = (PlaceTransitionNet)this.options.getObjectToAnalyze();
/*     */   }
/*     */   
/*     */   public Boolean isConnected() {
/* 188 */     HashSet<Set<PNNode>> components = this.pn.isConnected();
/*     */     
/* 190 */     boolean connected = (components.size() == 1);
/* 191 */     if (!connected) {
/* 192 */       addOutput("the net is not connected,\nthere are " + components
/* 193 */           .size() + " components:\n");
/* 194 */       int i = 1;
/* 195 */       for (Iterator<Set<PNNode>> it = components.iterator(); it.hasNext(); ) {
/* 196 */         Set<PNNode> component = it.next();
/* 197 */         addOutput("C" + i + ":");
/* 198 */         i++;
/*     */         
/* 200 */         for (Iterator<PNNode> it2 = component.iterator(); it2.hasNext(); ) {
/* 201 */           PNNode p = it2.next();
/*     */           
/* 203 */           addOutput(p.toString());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 208 */     addOutput("\n");
/* 209 */     return new Boolean(connected);
/*     */   }
/*     */   
/*     */   public void determineNetClass() {
/* 213 */     if (this.pn.isSM() && this.pn.isMG()) {
/* 214 */       addResult(12, new Result("SM & SG"));
/* 215 */     } else if (this.pn.isSM()) {
/* 216 */       addResult(12, new Result("SM"));
/* 217 */     } else if (this.pn.isMG()) {
/* 218 */       addResult(12, new Result("SG"));
/*     */     } else {
/* 220 */       int nc = this.pn.determineNetClass();
/* 221 */       switch (nc) {
/*     */         case 5:
/* 223 */           addResult(12, new Result("nES"));
/*     */           break;
/*     */         case 2:
/* 226 */           addResult(12, new Result("FC"));
/*     */           break;
/*     */         case 3:
/* 229 */           addResult(12, new Result("EFC"));
/*     */           break;
/*     */         case 4:
/* 232 */           addResult(12, new Result("ES"));
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void determineSCS() {
/* 247 */     Vector<Transition> trans = new Vector<>(this.pn.getTransitions());
/*     */     
/* 249 */     if (this.sccs == null) {
/* 250 */       this.sccs = new Vector<>();
/*     */     } else {
/* 252 */       this.sccs.clear();
/*     */     } 
/*     */     
/* 255 */     if (this.secs == null) {
/* 256 */       this.secs = new Vector<>();
/*     */     } else {
/* 258 */       this.secs.clear();
/*     */     } 
/*     */ 
/*     */     
/* 262 */     Iterator<Transition> trans_it = trans.iterator();
/* 263 */     while (trans_it.hasNext()) {
/* 264 */       Transition t = trans_it.next();
/*     */ 
/*     */       
/* 267 */       TransitionSet scc = this.pn.getEmptyTransitionSet();
/*     */ 
/*     */       
/* 270 */       scc.insert(t.getId());
/*     */ 
/*     */       
/* 273 */       determineSCC(t, scc);
/*     */ 
/*     */       
/* 276 */       this.sccs.add(scc);
/*     */ 
/*     */       
/* 279 */       Vector<TransitionSet> temp_secs = new Vector<>();
/* 280 */       determineSEC(scc, temp_secs);
/*     */ 
/*     */       
/* 283 */       Iterator<TransitionSet> temp_secs_it = temp_secs.iterator();
/* 284 */       while (temp_secs_it.hasNext()) {
/* 285 */         this.secs.add(temp_secs_it.next());
/*     */       }
/*     */ 
/*     */       
/* 289 */       Iterator<Integer> cluster_it = scc.iterator();
/* 290 */       while (cluster_it.hasNext()) {
/* 291 */         short id = ((Integer)cluster_it.next()).shortValue();
/* 292 */         trans.remove(this.pn.getTransition(id));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 297 */       trans_it = trans.iterator();
/*     */     } 
/*     */     
/* 300 */     outputSCS(this.sccs, "Structural coupled conflict sets: \n");
/* 301 */     outputSCS(this.secs, "Structural equal conflict sets: \n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void determineSCC(Transition t, TransitionSet cluster) {
/* 309 */     TransitionSet conflicts = t.getConflictSet(this.pn.transitions());
/*     */ 
/*     */     
/* 312 */     if (conflicts.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 319 */     Iterator<Integer> conflicts_it = conflicts.iterator();
/* 320 */     while (conflicts_it.hasNext()) {
/* 321 */       short trans_id = ((Integer)conflicts_it.next()).shortValue();
/* 322 */       Transition trans = this.pn.getTransition(trans_id);
/*     */ 
/*     */ 
/*     */       
/* 326 */       if (cluster.contains(trans)) {
/*     */         continue;
/*     */       }
/* 329 */       cluster.insert(trans_id);
/* 330 */       determineSCC(trans, cluster);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void determineSEC(TransitionSet scc, Vector<TransitionSet> secs) {
/* 340 */     TransitionSet conflicts = scc.copy();
/*     */     
/* 342 */     Iterator<Integer> conflicts_it = conflicts.iterator();
/* 343 */     while (conflicts_it.hasNext()) {
/* 344 */       short trans_id = ((Integer)conflicts_it.next()).shortValue();
/* 345 */       Transition trans = this.pn.getTransition(trans_id);
/*     */       
/* 347 */       TransitionSet sec = this.pn.getEmptyTransitionSet();
/* 348 */       sec.insert(trans_id);
/* 349 */       conflicts.delete(trans_id);
/*     */ 
/*     */       
/* 352 */       conflicts_it = conflicts.iterator();
/* 353 */       while (conflicts_it.hasNext()) {
/* 354 */         short trans_id2 = ((Integer)conflicts_it.next()).shortValue();
/* 355 */         Transition trans2 = this.pn.getTransition(trans_id2);
/*     */ 
/*     */         
/* 358 */         if (trans.preNodes().equals(trans2.preNodes())) {
/* 359 */           sec.insert(trans_id2);
/* 360 */           conflicts.delete(trans_id2);
/* 361 */           conflicts_it = conflicts.iterator();
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 367 */       secs.add(sec);
/* 368 */       conflicts_it = conflicts.iterator();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void outputSCS(Vector<TransitionSet> set, String description) {
/* 382 */     StringBuffer buf = new StringBuffer();
/* 383 */     buf.append(description).append("\n");
/*     */     
/* 385 */     int count = 1;
/* 386 */     if (set == null) {
/* 387 */       buf.append("No conflict set\n");
/*     */     } else {
/* 389 */       Iterator<TransitionSet> set_it = set.iterator();
/* 390 */       while (set_it.hasNext()) {
/* 391 */         TransitionSet cluster = set_it.next();
/*     */         
/* 393 */         buf.append(count++).append(cluster.toString()).append('\n');
/*     */       } 
/*     */     } 
/* 396 */     buf.append(" ");
/*     */     
/* 398 */     String output = buf.toString();
/* 399 */     addOutput(output);
/* 400 */     LOG.debug(output);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeScsToFile(Vector<TransitionSet> set, String filename, String title) {
/* 414 */     TransitionSet.writeToFile(filename, title, set);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/structural/StructuralAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */