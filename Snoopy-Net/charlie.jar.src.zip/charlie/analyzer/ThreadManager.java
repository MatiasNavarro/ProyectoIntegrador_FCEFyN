/*     */ package charlie.analyzer;
/*     */ 
/*     */ import GUI.threadmanager.ThreadManagerFrame;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ class ThreadManager
/*     */ {
/*  14 */   private static Log LOG = LogFactory.getLog(ThreadManager.class);
/*     */   
/*  16 */   private transient Object lock = new Object();
/*  17 */   private transient AnalyzerList threadList = new AnalyzerList();
/*  18 */   private transient ThreadPoolExecutor executor = null;
/*     */   private transient boolean initialized = false;
/*  20 */   private transient ThreadManagerFrame frame = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private transient boolean gui = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createGui() {
/*  30 */     LOG.debug("threadmanager create gui...");
/*  31 */     if (!this.gui) {
/*  32 */       synchronized (this.lock) {
/*  33 */         if (!this.initialized) {
/*  34 */           initialize();
/*     */         }
/*  36 */         this.gui = true;
/*     */         
/*  38 */         this.frame = new ThreadManagerFrame(this.threadList);
/*  39 */         this.frame.setVisible(true);
/*     */       } 
/*  41 */     } else if (this.gui && !this.frame.isVisible()) {
/*  42 */       this.frame.setVisible(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {
/*  48 */     ArrayBlockingQueue<Runnable> queue = new ArrayBlockingQueue<>(10, true);
/*  49 */     Runtime r = Runtime.getRuntime();
/*     */     
/*  51 */     this.executor = new ThreadPoolExecutor(r.availableProcessors(), r.availableProcessors(), 10L, TimeUnit.SECONDS, queue);
/*  52 */     this.initialized = true;
/*     */   }
/*     */   
/*     */   public void add(Analyzer analyzer) {
/*  56 */     if (!this.initialized) {
/*  57 */       initialize();
/*     */     }
/*     */     
/*  60 */     synchronized (this.lock) {
/*  61 */       if (this.gui && analyzer.executeImmediately()) {
/*  62 */         addImmediate(analyzer);
/*     */         
/*     */         return;
/*     */       } 
/*  66 */       this.threadList.add(analyzer);
/*     */       
/*  68 */       if (this.gui && this.frame != null) {
/*  69 */         this.frame.updateView();
/*     */       }
/*     */       
/*  72 */       this.executor.execute(analyzer);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addImmediate(Analyzer analyzer) {
/*  77 */     if (!this.initialized) {
/*  78 */       initialize();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  83 */     Thread t = new Thread(analyzer);
/*  84 */     t.start();
/*     */   }
/*     */   
/*     */   public void setFinished(Analyzer analyzer) {
/*  88 */     synchronized (this.lock) {
/*  89 */       this.threadList.update();
/*  90 */       if (this.frame != null) {
/*  91 */         this.frame.updateView();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void update() {
/*  97 */     this.threadList.update();
/*     */   }
/*     */   
/*     */   public void reset() {
/* 101 */     this.threadList.clear();
/*     */     
/* 103 */     if (this.executor != null) {
/* 104 */       this.executor.shutdownNow();
/*     */     }
/* 106 */     initialize();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/ThreadManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */