/*    */ package charlie.analyzer.algorithm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NeverStopStatusController
/*    */   implements AlgorithmStatusController
/*    */ {
/*    */   public boolean continueWork() {
/* 18 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/algorithm/NeverStopStatusController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */