/*     */ package charlie.analyzer.algorithm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GaussAlgorithm
/*     */ {
/*     */   private final double[][] matrix;
/*  24 */   private int rank = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  29 */   private AlgorithmStatusController statusController = new NeverStopStatusController();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussAlgorithm(double[][] _matrix) {
/*  39 */     this.matrix = new double[_matrix.length][(_matrix[0]).length];
/*     */     
/*  41 */     for (int i = 0; i < _matrix.length; i++) {
/*  42 */       for (int j = 0; j < (_matrix[0]).length; j++) {
/*  43 */         this.matrix[i][j] = _matrix[i][j];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GaussAlgorithm(int[][] _matrix) {
/*  56 */     this.matrix = new double[_matrix.length][(_matrix[0]).length];
/*     */     
/*  58 */     for (int i = 0; i < _matrix.length; i++) {
/*  59 */       for (int j = 0; j < (_matrix[0]).length; j++) {
/*  60 */         this.matrix[i][j] = _matrix[i][j];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlgorithmStatusController(AlgorithmStatusController _controller) {
/*  72 */     this.statusController = _controller;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void solve() {
/*  80 */     int n = this.matrix.length;
/*  81 */     int m = (this.matrix[0]).length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     int i = 0;
/*  88 */     int j = 0;
/*     */     
/*  90 */     while (i < n && j < m) {
/*     */       
/*  92 */       if (!this.statusController.continueWork()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 100 */       int maxi = i;
/*     */       
/* 102 */       for (int k = i + 1; k < n; k++) {
/*     */         
/* 104 */         if (Math.abs(this.matrix[k][j]) > Math.abs(this.matrix[maxi][j]))
/*     */         {
/* 106 */           maxi = k;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 112 */       if (this.matrix[maxi][j] != 0.0D) {
/*     */         
/* 114 */         swapRows(this.matrix, i, maxi);
/*     */ 
/*     */ 
/*     */         
/* 118 */         double mult = this.matrix[i][j];
/* 119 */         for (int r = j; r < m; r++) {
/* 120 */           this.matrix[i][r] = this.matrix[i][r] / mult;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 125 */         for (int u = i + 1; u < n; u++) {
/*     */           
/* 127 */           mult = this.matrix[u][j];
/* 128 */           for (int s = j; s < m; s++) {
/* 129 */             double sub = mult * this.matrix[i][s];
/* 130 */             this.matrix[u][s] = this.matrix[u][s] - sub;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 136 */         i++;
/*     */       } 
/*     */ 
/*     */       
/* 140 */       j++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void swapRows(double[][] _matrix, int _row1, int _row2) {
/* 153 */     double[] tmp = _matrix[_row1];
/* 154 */     _matrix[_row1] = _matrix[_row2];
/* 155 */     _matrix[_row2] = tmp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRank() {
/* 173 */     if (this.rank != -1) {
/* 174 */       return this.rank;
/*     */     }
/*     */     
/* 177 */     for (int i = this.matrix.length - 1; i >= 0; i--) {
/* 178 */       for (int j = 0; j < (this.matrix[0]).length; j++) {
/* 179 */         if (this.matrix[i][j] != 0.0D) {
/*     */           
/* 181 */           this.rank = i + 1;
/* 182 */           return this.rank;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 187 */     this.rank = 0;
/* 188 */     return this.rank;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/algorithm/GaussAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */