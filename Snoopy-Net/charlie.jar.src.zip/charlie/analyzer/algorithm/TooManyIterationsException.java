/*    */ package charlie.analyzer.algorithm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TooManyIterationsException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public TooManyIterationsException(String _message) {
/* 22 */     super(_message);
/*    */   }
/*    */   
/*    */   public TooManyIterationsException() {}
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/algorithm/TooManyIterationsException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */