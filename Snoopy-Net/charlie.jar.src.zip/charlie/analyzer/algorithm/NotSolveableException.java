/*    */ package charlie.analyzer.algorithm;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotSolveableException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 946098343033116854L;
/*    */   
/*    */   public NotSolveableException() {}
/*    */   
/*    */   public NotSolveableException(String message) {
/* 19 */     super(message);
/*    */   }
/*    */   
/*    */   public NotSolveableException(Throwable cause) {
/* 23 */     super(cause);
/*    */   }
/*    */   
/*    */   public NotSolveableException(String message, Throwable cause) {
/* 27 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/algorithm/NotSolveableException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */