package charlie.analyzer.algorithm;

public interface AlgorithmStatusController {
  boolean continueWork();
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/algorithm/AlgorithmStatusController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */