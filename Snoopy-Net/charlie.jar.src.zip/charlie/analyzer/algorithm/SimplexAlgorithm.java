/*     */ package charlie.analyzer.algorithm;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimplexAlgorithm
/*     */ {
/*  34 */   private static final Log LOG = LogFactory.getLog(SimplexAlgorithm.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int solutionNum;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int solutionLine;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final double[][] tableau;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private double pivotElement = -1.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private int pivotColumn = 0;
/*     */ 
/*     */ 
/*     */   
/*  63 */   private int pivotRow = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private AlgorithmStatusController statusController = new NeverStopStatusController();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SimplexAlgorithm(int _columns, int _rows, int _solutionNum, int _solutionLine) {
/*  81 */     this(new double[_columns][_rows], _solutionNum, _solutionLine);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SimplexAlgorithm(double[][] _tableau, int _solutionNum, int _solutionLine) {
/*  98 */     this.tableau = _tableau;
/*  99 */     this.solutionNum = _solutionNum;
/* 100 */     this.solutionLine = _solutionLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimplexAlgorithm(double[][] _a, double[] _b, double[] _f) {
/* 118 */     this(_a, _b, _f, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimplexAlgorithm(double[][] _a, double[] _b, double[] _f, boolean _minimize) {
/* 151 */     this.solutionNum = (_a[0]).length;
/*     */     
/* 153 */     this.solutionLine = _a.length;
/*     */ 
/*     */     
/* 156 */     if (_minimize) {
/* 157 */       this.tableau = new double[_a.length + 1 + 1][_a.length + (_a[0]).length + 1];
/*     */       int m;
/* 159 */       for (m = 0; m < _a.length; m++) {
/* 160 */         for (int n = 0; n < (_a[0]).length; n++) {
/* 161 */           this.tableau[m][n] = _a[m][n];
/*     */         }
/*     */       } 
/*     */       
/* 165 */       for (m = 0; m < _b.length; m++) {
/* 166 */         this.tableau[m][(this.tableau[0]).length - 1] = _b[m];
/*     */       }
/*     */       
/* 169 */       for (int k = 0; k < _f.length; k++) {
/* 170 */         this.tableau[this.tableau.length - 2][k] = -_f[k];
/*     */       }
/*     */       
/* 173 */       for (int i = 0; i < _a.length; i++) {
/* 174 */         this.tableau[i][_a.length + i - 1] = -1.0D;
/*     */       }
/*     */       
/* 177 */       for (int j = 0; j < (this.tableau[0]).length; j++) {
/* 178 */         double value = 0.0D;
/* 179 */         for (int n = 0; n < this.tableau.length - 2; n++) {
/* 180 */           value += this.tableau[n][j];
/*     */         }
/* 182 */         this.tableau[this.tableau.length - 1][j] = -value;
/*     */       } 
/*     */     } else {
/*     */       
/* 186 */       this.tableau = new double[_a.length + 1][_a.length + (_a[0]).length + 1];
/* 187 */       for (int k = 0; k < _a.length; k++) {
/* 188 */         for (int m = 0; m < (_a[0]).length; m++) {
/* 189 */           this.tableau[k][m] = _a[k][m];
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 194 */       for (int d = 0; d < _a.length; d++) {
/* 195 */         this.tableau[d][(_a[0]).length + d] = 1.0D;
/*     */       }
/*     */       
/* 198 */       for (int i = 0; i < _b.length; i++) {
/* 199 */         this.tableau[i][(this.tableau[0]).length - 1] = _b[i];
/*     */       }
/*     */       
/* 202 */       for (int j = 0; j < _f.length; j++) {
/* 203 */         this.tableau[this.tableau.length - 1][j] = -_f[j];
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlgorithmStatusController(AlgorithmStatusController _controller) {
/* 215 */     this.statusController = _controller;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void solve() throws NotSolveableException {
/* 225 */     boolean negativ = true;
/*     */ 
/*     */     
/* 228 */     while (negativ) {
/*     */       
/* 230 */       if (!this.statusController.continueWork()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 237 */       findPivotElement();
/*     */       
/* 239 */       calculateElements();
/*     */ 
/*     */       
/* 242 */       negativ = false;
/*     */       
/* 244 */       for (int j = 0; j < (this.tableau[0]).length - 1; j++) {
/*     */         
/* 246 */         if (this.tableau[this.tableau.length - 1][j] < 0.0D) {
/*     */           
/* 248 */           negativ = true;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void calculateElements() {
/* 257 */     for (int k = 0; k < this.tableau.length; k++) {
/*     */       
/* 259 */       for (int m = 0; m < (this.tableau[0]).length; m++) {
/*     */         
/* 261 */         if (k != this.pivotRow && m != this.pivotColumn)
/*     */         {
/* 263 */           this.tableau[k][m] = this.tableau[k][m] - this.tableau[k][this.pivotColumn] * this.tableau[this.pivotRow][m] / this.pivotElement;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 269 */     for (int j = 0; j < (this.tableau[0]).length; j++)
/*     */     {
/* 271 */       this.tableau[this.pivotRow][j] = this.tableau[this.pivotRow][j] / this.pivotElement;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 276 */     this.tableau[this.pivotRow][this.pivotColumn] = 1.0D;
/*     */ 
/*     */     
/* 279 */     for (int i = 0; i < this.tableau.length; i++) {
/*     */       
/* 281 */       if (i != this.pivotRow)
/*     */       {
/* 283 */         this.tableau[i][this.pivotColumn] = 0.0D;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void findPivotElement() throws NotSolveableException {
/* 295 */     double maxWert = 0.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 300 */     int n = this.tableau.length - 1;
/* 301 */     int m = (this.tableau[0]).length - 1;
/*     */ 
/*     */     
/* 304 */     for (int j = 0; j < m; j++) {
/*     */       
/* 306 */       if (this.tableau[n][j] < maxWert) {
/*     */         
/* 308 */         maxWert = this.tableau[n][j];
/*     */         
/* 310 */         this.pivotColumn = j;
/*     */       } 
/*     */     } 
/*     */     
/* 314 */     double min = Double.MAX_VALUE;
/*     */ 
/*     */     
/* 317 */     for (int i = 0; i < n; i++) {
/*     */ 
/*     */       
/* 320 */       if (this.tableau[i][this.pivotColumn] > 0.0D) {
/* 321 */         double possiblePivot = this.tableau[i][m] / this.tableau[i][this.pivotColumn];
/* 322 */         if (possiblePivot < min) {
/* 323 */           min = possiblePivot;
/* 324 */           this.pivotRow = i;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 330 */     this.pivotElement = this.tableau[this.pivotRow][this.pivotColumn];
/*     */     
/* 332 */     if (LOG.isDebugEnabled()) {
/* 333 */       LOG.debug(String.format("pivotElement: %f, pivotRow: %d, pivotColumn: %d", new Object[] { Double.valueOf(this.pivotElement), Integer.valueOf(this.pivotRow), Integer.valueOf(this.pivotColumn) }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] getSolution() {
/* 351 */     double[] solution = new double[this.solutionNum + 1];
/*     */     
/* 353 */     solution[this.solutionNum] = this.tableau[this.solutionLine][(this.tableau[0]).length - 1];
/*     */ 
/*     */ 
/*     */     
/* 357 */     for (int i = 0; i < this.tableau.length - 1; i++) {
/* 358 */       for (int j = 0; j < this.solutionNum; j++) {
/* 359 */         if (this.tableau[i][j] == 1.0D) {
/*     */           
/* 361 */           solution[j] = this.tableau[i][(this.tableau[0]).length - 1];
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 369 */     return solution;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getObjectiveFunctionSolution() {
/* 380 */     return this.tableau[this.tableau.length - 1][(this.tableau[0]).length - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printTableau() {
/* 388 */     System.out.println(toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 393 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 395 */     for (int i = 0; i < this.tableau.length; i++) {
/* 396 */       for (int j = 0; j < (this.tableau[0]).length; j++) {
/* 397 */         buf.append(this.tableau[i][j]).append(" ");
/*     */       }
/* 399 */       buf.append("\n");
/*     */     } 
/*     */     
/* 402 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/algorithm/SimplexAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */