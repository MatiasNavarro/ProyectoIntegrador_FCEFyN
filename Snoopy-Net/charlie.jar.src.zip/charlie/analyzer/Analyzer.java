/*     */ package charlie.analyzer;
/*     */ 
/*     */ import GUI.analyzer.ThreadPanel;
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.ElapsedTime;
/*     */ import GUI.util.StackTracePrinter;
/*     */ import charlie.pn.Result;
/*     */ import charlie.pn.Results;
/*     */ import java.io.File;
/*     */ import java.io.Serializable;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Analyzer
/*     */   implements Runnable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  45 */   private static final Log LOG = LogFactory.getLog(Analyzer.class);
/*     */   
/*     */   public static final int CREATED = -3;
/*     */   
/*     */   public static final int REGISTERED = -2;
/*     */   
/*     */   public static final int SETUP = -1;
/*     */   
/*     */   public static final int WAITING = 0;
/*     */   
/*     */   public static final int PAUSED = 1;
/*     */   
/*     */   public static final int ACTIVE = 2;
/*     */   
/*     */   public static final int FINISHED = 3;
/*     */   public static final int CANCELLED = 4;
/*  61 */   private long count = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private long updateInterval = 250L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private transient ThreadPanel panel = null;
/*     */   
/*  83 */   private ElapsedTime elTime = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private transient Object lock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   protected OptionSet options = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] infoStrings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private long endTime = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private long startTime = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean immediateExecution = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   protected Initiator initiator = null;
/*     */   
/* 138 */   protected int status = -3;
/*     */   
/*     */   public void setup(OptionSet options) {
/* 141 */     setup(options.getObjectToAnalyze(), options, options.getResultObject());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setup(Object objectToAnalyze, OptionSet options, Object resultObject) {
/* 149 */     if (resultObject == null) {
/* 150 */       LOG.warn("Analyzer.setup() was called with a null reference for resultObject!");
/*     */       return;
/*     */     } 
/* 153 */     if (objectToAnalyze == null) {
/* 154 */       LOG.warn("Analyzer.setup() was called with a null reference for objectToAnalyze!");
/*     */       return;
/*     */     } 
/* 157 */     if (options == null) {
/* 158 */       LOG.warn("Analyzer.setup() was called with a null reference for options!");
/*     */       return;
/*     */     } 
/* 161 */     if (options.getResultObject() == null) {
/* 162 */       options.setResultObject(resultObject);
/*     */     }
/* 164 */     if (options.getObjectToAnalyze() == null) {
/* 165 */       options.setObjectToAnalyze(objectToAnalyze);
/*     */     }
/* 167 */     if (LOG.isDebugEnabled()) {
/* 168 */       LOG.debug("Analyzer.setup():  Analyzer for object: " + resultObject.getClass().getName() + ".");
/*     */     }
/* 170 */     this.options = options;
/* 171 */     initializeInfoStrings();
/* 172 */     this.endTime = 0L;
/* 173 */     this.startTime = 0L;
/* 174 */     this.status = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 181 */     this.options = null;
/* 182 */     this.startTime = System.currentTimeMillis();
/* 183 */     this.endTime = this.startTime;
/* 184 */     this.initiator = null;
/* 185 */     this.status = -3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getResultObject() {
/* 192 */     return this.options.getResultObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObjectToAnalyze() {
/* 202 */     return this.options.getObjectToAnalyze();
/*     */   }
/*     */   
/*     */   public void setUpdateInterval(long interval) {
/* 206 */     if (interval > 0L) {
/* 207 */       this.updateInterval = interval;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void evaluate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Results getResults() {
/* 225 */     if (this.options != null) {
/* 226 */       return this.options.getResults();
/*     */     }
/* 228 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStatus() {
/* 233 */     return this.status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setStatus(int state) {
/* 245 */     switch (state) {
/*     */       
/*     */       case 2:
/* 248 */         if (this.panel != null) {
/* 249 */           this.panel.setStatusRunning();
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 257 */         if (this.panel != null) {
/* 258 */           this.panel.setStatusFinished();
/*     */         }
/*     */         break;
/*     */       
/*     */       case 0:
/* 263 */         DebugCounter.inc("Analyzer.setStatus(int = WAITING) called ! Should not be set directly!");
/*     */         break;
/*     */       
/*     */       case 4:
/* 267 */         if (this.panel != null) {
/* 268 */           this.panel.setStatusCancelled();
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 275 */     this.status = state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean executeImmediately() {
/* 296 */     return this.immediateExecution;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHtmlInfoString() {
/* 305 */     initializeInfoStrings();
/* 306 */     StringBuffer buf = new StringBuffer();
/* 307 */     buf.append("<html><table>");
/* 308 */     for (String s : this.infoStrings) {
/* 309 */       buf.append("<tr><td>" + s + "</td></tr>");
/*     */     }
/* 311 */     buf.append("</table></html>");
/* 312 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private long setStartTime() {
/* 318 */     this.startTime = System.currentTimeMillis();
/* 319 */     this.endTime = this.startTime;
/* 320 */     if (this.panel != null) {
/*     */       
/* 322 */       this.panel.setTimeText("");
/* 323 */       this.elTime = ElapsedTime.getElapsedTimer(this.panel.getTimeLabel(), 125, true);
/* 324 */       this.elTime.start();
/*     */     } 
/*     */     
/* 327 */     return this.startTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long setEndTime() {
/* 335 */     long returnTime = 0L;
/* 336 */     switch (this.status) {
/*     */       
/*     */       case 0:
/* 339 */         returnTime = 0L;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 2:
/* 344 */         returnTime = 0L;
/*     */         break;
/*     */       case 3:
/* 347 */         if (this.endTime - this.startTime < 0L) {
/* 348 */           this.endTime = System.currentTimeMillis();
/* 349 */           if (this.elTime != null)
/* 350 */             this.elTime.stop(); 
/*     */           break;
/*     */         } 
/* 353 */         returnTime = this.endTime;
/*     */         break;
/*     */       
/*     */       case 4:
/* 357 */         if (this.endTime - this.startTime < 0L) {
/* 358 */           this.endTime = System.currentTimeMillis();
/*     */         } else {
/*     */           
/* 361 */           returnTime = this.endTime;
/*     */         } 
/* 363 */         if (this.elTime != null) {
/* 364 */           this.elTime.stop();
/*     */         }
/*     */         break;
/*     */       default:
/* 368 */         DebugCounter.inc("Analyzer.setEndTime() called on analyzer in undefined state...!");
/* 369 */         returnTime = 0L;
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 374 */     if (this.elTime != null) {
/* 375 */       this.elTime.stop();
/*     */     }
/*     */     
/* 378 */     return returnTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getDuration() {
/* 383 */     if (this.status == 3 || this.status == 4) {
/* 384 */       if (this.endTime - this.startTime < 0L) {
/* 385 */         setEndTime();
/*     */       }
/* 387 */       return this.endTime - this.startTime;
/* 388 */     }  if (this.status == 2) {
/* 389 */       return getCurrentDuration();
/*     */     }
/*     */ 
/*     */     
/* 393 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getCurrentDuration() {
/* 403 */     if (this.status == 2) {
/* 404 */       return System.currentTimeMillis() - this.startTime;
/*     */     }
/* 406 */     if (this.status == 3 || this.status == 4) {
/* 407 */       if (this.endTime - this.startTime < 0L) {
/* 408 */         setEndTime();
/*     */       }
/* 410 */       return this.endTime - this.startTime;
/*     */     } 
/*     */     
/* 413 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormatedDuration() {
/* 420 */     if (this.elTime != null) {
/* 421 */       return this.elTime.getElapsedTime();
/*     */     }
/* 423 */     long currDuration = 0L;
/* 424 */     if (this.status == 2) {
/* 425 */       currDuration = getCurrentDuration();
/*     */     }
/* 427 */     if (this.status == 3 || this.status == 4) {
/* 428 */       currDuration = getDuration();
/*     */     }
/*     */     
/* 431 */     if (currDuration > 0L) {
/* 432 */       String ret = "" + (currDuration / 60000L);
/* 433 */       ret = ret + " m ";
/* 434 */       ret = ret + ((currDuration % 60000L) / 1000.0D);
/* 435 */       ret = ret + " s ";
/*     */ 
/*     */ 
/*     */       
/* 439 */       return ret;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 444 */     return " 0 m 0 s";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getInfoStrings() {
/* 454 */     initializeInfoStrings();
/* 455 */     return this.infoStrings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void analyze();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 474 */     if (this.status != -1) {
/* 475 */       DebugCounter.inc("Analyzer" + getName() + ".run(), setup(...) was not called before !");
/* 476 */       setStatus(4);
/*     */       return;
/*     */     } 
/* 479 */     setStatus(2);
/* 480 */     setStartTime();
/* 481 */     if (this.panel != null)
/*     */     {
/* 483 */       addOutput("Analyzer: " + getName() + "\nstart time: " + (new SimpleDateFormat()).format(new Date()) + "\n");
/*     */     }
/*     */     
/*     */     try {
/* 487 */       addOutput("starts analysis with following options:\n" + this.options.toString());
/* 488 */     } catch (Throwable e) {
/* 489 */       DebugCounter.inc("Analyzer" + getName() + ".run(), error because of ...options.toString() !");
/*     */     } 
/*     */     
/*     */     try {
/* 493 */       analyze();
/* 494 */       evaluate();
/* 495 */     } catch (Throwable e) {
/* 496 */       LOG.error(e.getMessage(), e);
/*     */       
/* 498 */       addOutput("Analysis could not be finished due to an error:\nException message: " + e.getMessage() + "\n");
/* 499 */       DebugCounter.inc("Analysis could not be finished due to an error:\nException message: " + e
/* 500 */           .getMessage() + "\n");
/* 501 */       DebugCounter.inc("StackTrace:\n" + StackTracePrinter.getStackTrace(e));
/* 502 */       DebugCounter.writeLog(new File("charlieError.log"));
/* 503 */       cancel();
/*     */     } 
/* 505 */     if (getStatus() != 4) {
/*     */ 
/*     */       
/* 508 */       DebugCounter.inc("time:  " + getFormatedDuration());
/* 509 */       setStatus(3);
/*     */     }
/* 511 */     else if (this.elTime != null) {
/* 512 */       this.elTime.stop();
/*     */     } 
/*     */     
/* 515 */     setEndTime();
/* 516 */     addOutput("time: " + getFormatedDuration());
/* 517 */     if (this.elTime != null) {
/* 518 */       DebugCounter.inc("stop ElapsedTime! Timer is running=" + this.elTime.isRunning());
/* 519 */       this.elTime.stop();
/*     */     } 
/*     */     
/* 522 */     AnalyzerManagerFactory.getAnalyzerManager().analyzerHasFinished(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 530 */     synchronized (this.lock) {
/* 531 */       if (this.status != 3) {
/*     */         
/* 533 */         if (this.status != 4) {
/* 534 */           addOutput("\n***************************\n The analysis was cancelled !\n*************************\n");
/*     */         }
/* 536 */         this.status = 4;
/* 537 */         setEndTime();
/*     */       } 
/*     */       try {
/* 540 */         this.lock.notify();
/* 541 */       } catch (Throwable lockException) {
/* 542 */         DebugCounter.inc("Analyzer: " + getName() + " lock Exception on cancel() !");
/*     */         
/* 544 */         LOG.error(lockException.getMessage(), lockException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void cleanup();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void initializeInfoStrings();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkStatus() {
/* 595 */     synchronized (this.lock) {
/* 596 */       this.count++;
/* 597 */       if (this.count % this.updateInterval == 0L) {
/* 598 */         this.count = 0L;
/*     */       }
/* 600 */       if (this.status == 1) {
/*     */         try {
/* 602 */           this.lock.wait();
/* 603 */         } catch (Throwable e) {
/* 604 */           LOG.error(e.getMessage(), e);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 610 */     if (this.status == 4) {
/* 611 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 615 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pause() {
/* 623 */     synchronized (this.lock) {
/* 624 */       if (this.status == 2) {
/* 625 */         setStatus(1);
/* 626 */         if (this.elTime != null) {
/* 627 */           this.elTime.pause();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Analyzer getNewInstance(OptionSet paramOptionSet);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resume() {
/* 654 */     synchronized (this.lock) {
/*     */       
/* 656 */       if (this.status == 1) {
/*     */         try {
/* 658 */           if (this.elTime != null) {
/* 659 */             this.elTime.resume();
/*     */           }
/* 661 */           setStatus(2);
/* 662 */           this.lock.notify();
/* 663 */         } catch (Throwable lockException) {
/* 664 */           LOG.error(lockException.getMessage(), lockException);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean register() {
/* 678 */     System.out.printf("An analyzer Class has not yet implemented static method register()!\n", new Object[0]);
/* 679 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OptionSet getOptionSet() {
/* 689 */     return this.options;
/*     */   }
/*     */   
/*     */   public Initiator getInitiator() {
/* 693 */     if (this.options != null) {
/* 694 */       return this.options.initiator;
/*     */     }
/* 696 */     return this.initiator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInitiator(Initiator initiator) {
/* 701 */     if (this.options != null) {
/* 702 */       this.options.initiator = initiator;
/*     */     } else {
/* 704 */       this.initiator = initiator;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOutput() {
/* 714 */     return this.options.getResults().getOutput();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected void setOutput(String _s) {
/* 727 */     addOutput(_s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addOutput(String _s) {
/* 737 */     this.options.appendOutput(_s);
/*     */   }
/*     */   
/*     */   public void setPanel(ThreadPanel p) {
/* 741 */     this.panel = p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Result getResult(int index) {
/* 755 */     if (this.options != null) {
/* 756 */       Results r = getResults();
/* 757 */       if (r != null) {
/* 758 */         return r.getResult(index);
/*     */       }
/*     */     } 
/* 761 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addResult(String _key, Object _result) {
/* 776 */     addResult(_key, new Result(_result));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addResult(String _key, Result _result) {
/* 791 */     int index = Results.getIndexForKey(_key);
/* 792 */     addResult(index, _result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addResult(int index, Result result) {
/* 810 */     if (this.options != null) {
/* 811 */       Results r = this.options.getResults();
/* 812 */       if (r != null) {
/* 813 */         r.addResult(index, result);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addResult(int _index, Object _result) {
/* 839 */     addResult(_index, new Result(_result));
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/Analyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */