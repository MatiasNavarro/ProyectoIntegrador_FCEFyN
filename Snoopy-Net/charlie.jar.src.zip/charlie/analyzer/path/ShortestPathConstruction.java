/*     */ package charlie.analyzer.path;
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.filter.BinFilter;
/*     */ import charlie.filter.Filter;
/*     */ import charlie.filter.WrongFilterException;
/*     */ import charlie.pn.ExceedsByteException;
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.SafetyException;
/*     */ import charlie.pn.State;
/*     */ import charlie.pn.Transition;
/*     */ import charlie.pn.TraversationDataTable;
/*     */ import charlie.rg.NoReduction;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGEdge;
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Stack;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class ShortestPathConstruction extends PathConstruction {
/*     */   private double progress;
/*  25 */   int count = 1; public HashSet edgeTree;
/*  26 */   Path p = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  34 */     return "shortest path construction";
/*     */   }
/*     */ 
/*     */   
/*     */   public void analyze() {
/*  39 */     System.out.println("starting");
/*  40 */     this.po = (PathComputationOptions)this.options;
/*  41 */     if (this.po.rGraph == null && this.po.getObjectToAnalyze() == null) {
/*  42 */       cleanup(); return;
/*     */     } 
/*  44 */     if (this.po.rGraph == null && this.po.getObjectToAnalyze() != null && 
/*  45 */       this.po.getObjectToAnalyze() instanceof RGraph) {
/*  46 */       this.po.rGraph = (RGraph)this.po.getObjectToAnalyze();
/*     */     }
/*     */     
/*  49 */     this.rg = this.po.rGraph;
/*  50 */     this.pn = this.po.rGraph.getNet();
/*  51 */     this.maximumStates = this.po.maximalConsideredStates;
/*  52 */     if (this.maximumStates == -1L || this.maximumStates == 0L) {
/*  53 */       this.maximumStates = 2147483647L;
/*     */     }
/*  55 */     this.maximumLength = this.po.maxPathLength;
/*  56 */     if (this.maximumLength == -1L || this.maximumLength == 0L) {
/*  57 */       this.maximumLength = 2147483647L;
/*     */     }
/*  59 */     this.edgeTree = new HashSet();
/*  60 */     DebugCounter.inc("ShortestPathConstruction: maximumStates=" + this.maximumStates + " maximumLength " + this.maximumLength);
/*     */     
/*  62 */     if (this.po.targetFilterFile != null)
/*     */       try {
/*  64 */         this.po.targetFilter = (Filter)new BinFilter(this.po.targetFilterFile.getAbsolutePath(), this.rg.getNet());
/*  65 */       } catch (Exception e) {
/*  66 */         DebugCounter.inc("Could not create filter from filter file, make shure the file contains a valid filter!");
/*  67 */         cleanup(); cancel();
/*     */         return;
/*     */       }  
/*  70 */     if (this.po.targetFilter != null && this.po.targetState == null) {
/*  71 */       this.target = this.po.targetFilter;
/*  72 */       if (this.po.markingType == 1) {
/*  73 */         this.equal = true;
/*     */         try {
/*  75 */           this.target = this.po.targetFilter.createMarking();
/*  76 */         } catch (WrongFilterException e) {
/*     */           
/*  78 */           setOutput("provided target filter could not be created!");
/*  79 */           System.out.println("provided target filter could not be created!");
/*  80 */           DebugCounter.inc("Output\n" + getOutput());
/*  81 */           cancel();
/*     */           return;
/*     */         } 
/*  84 */       } else if (this.po.markingType == 0) {
/*  85 */         this.equal = false;
/*     */       } else {
/*  87 */         setOutput("Markingtype set to unknown value :" + this.po.markingType);
/*  88 */         DebugCounter.inc("Output\n" + getOutput());
/*  89 */         cancel();
/*     */         return;
/*     */       } 
/*  92 */     } else if (this.po.targetFilter == null && this.po.targetState != null) {
/*  93 */       this.target = this.po.targetState;
/*     */       
/*  95 */       this.equal = true;
/*     */     } else {
/*     */       
/*  98 */       if (this.po.targetFilter == null && this.po.targetState == null && this.po.targetFilterFile != null) {
/*  99 */         setOutput("target Filter and target state are not initialized!");
/*     */       }
/* 101 */       if (this.po.targetFilter == null && this.po.targetState == null && this.po.targetFilterFile != null)
/*     */       {
/* 103 */         setOutput("target Filter and target state are not initialized!");
/*     */       }
/* 105 */       if (this.po.targetFilter != null && this.po.targetState != null) {
/* 106 */         setOutput("target Filter and target state are both initialized don't know which to choose!");
/*     */       }
/* 108 */       DebugCounter.inc("Output\n" + getOutput());
/* 109 */       cancel();
/*     */       
/*     */       return;
/*     */     } 
/* 113 */     if (this.po.startState != null && this.po.startFilter == null) {
/* 114 */       this.start = this.po.startState;
/* 115 */     } else if (this.po.startState == null && this.po.startFilter != null) {
/* 116 */       this.start = this.po.startFilter;
/*     */     } else {
/* 118 */       if (this.po.startState == null && this.po.startFilter == null && !this.po.useM0) {
/* 119 */         setOutput("start Filter and start state are not initialized !");
/*     */       }
/* 121 */       if (this.po.startState != null && this.po.startFilter != null && !this.po.useM0) {
/* 122 */         setOutput("start Filter and start state are both initialized don't know which to choose!");
/*     */       }
/* 124 */       cancel();
/* 125 */       DebugCounter.inc("No Start stateOutput\n" + getOutput());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (this.start == null || this.target == null) {
/* 158 */       cancel();
/*     */       return;
/*     */     } 
/*     */     try {
/* 162 */       this.p = compute();
/* 163 */       this.po.setResultObject(this.p);
/* 164 */       this.p.setName(this.target.toString());
/* 165 */       this.po.pathRGraph = this.rg;
/* 166 */       DebugCounter.inc("computed path: " + this.p);
/* 167 */     } catch (Exception e) {
/* 168 */       cancel();
/* 169 */       DebugCounter.inc("ShortestPathConstruction compute() threw exception\n" + e.getClass().getName() + "\n" + e.getMessage() + "\n  Output\n" + getOutput());
/* 170 */       e.printStackTrace();
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Path compute() throws Exception {
/* 176 */     DebugCounter.inc("ShortestPathConstruction.compute()");
/*     */     
/*     */     try {
/* 179 */       boolean found = false;
/*     */       
/* 181 */       DebugCounter.inc("spanningGraphConstruction()");
/* 182 */       found = spanningGraphConstruction();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 187 */       DebugCounter.inc("value of found " + found);
/* 188 */       DebugCounter.inc("value of checkStatus " + checkStatus());
/* 189 */       if (found && checkStatus()) {
/* 190 */         this.p = computePath();
/* 191 */         if (this.start instanceof State) {
/* 192 */           setOutput("\nshortest Path from " + this.pn.toLabel((State)this.start));
/*     */         }
/* 194 */         if (this.equal) {
/* 195 */           setOutput("to " + this.pn.toLabel((State)this.target));
/*     */         } else {
/* 197 */           setOutput("to a marking which satisfies " + this.target);
/*     */         } 
/* 199 */         int i = 0;
/* 200 */         setOutput("computed path: " + this.p.getString());
/* 201 */         setOutput("\n" + this.p.toParikhVector(this.pn));
/*     */       } else {
/* 203 */         DebugCounter.inc("value of found " + found);
/* 204 */         setOutput("marking not reached");
/* 205 */         this.p = new Path();
/*     */       }
/*     */     
/* 208 */     } catch (Exception e) {
/* 209 */       throw e;
/*     */     } 
/* 211 */     this.progress = 100.0D;
/* 212 */     if (!checkStatus()) { cleanup(); return null; }
/* 213 */      return this.p;
/*     */   }
/*     */   public RGraph getGraph() {
/* 216 */     return this.rg;
/*     */   }
/*     */   
/*     */   private boolean check(Marking m, Object target) {
/* 220 */     if (target == null) {
/* 221 */       JOptionPane.showMessageDialog(null, "ShortestPathConstruction.check(Marking m, Object target) target == null!");
/*     */     }
/* 223 */     if (this.equal)
/*     */     {
/* 225 */       return m.equals(target);
/*     */     }
/* 227 */     return ((Filter)target).filter(m);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean spanningGraphConstruction() throws SafetyException, ExceedsByteException {
/* 232 */     NoReduction noReduction = new NoReduction(this.pn);
/* 233 */     HashSet visited = new HashSet();
/* 234 */     Vector<Marking> queue = new Vector();
/* 235 */     Marking m = ((State)this.start).getPlaceMarking();
/* 236 */     int layer = 1;
/* 237 */     int statesInNextLayer = 0;
/* 238 */     int statesInCurrentLayer = 1;
/* 239 */     this.rg = new RGraph(this.pn);
/* 240 */     this.rg.addNode(new RGNode(this.pn, (State)m));
/* 241 */     queue.add(m);
/*     */ 
/*     */     
/* 244 */     this.progress = 0.0D;
/* 245 */     if (!checkStatus()) { cleanup(); return false; }
/*     */     
/* 247 */     float prog = 0.0F;
/* 248 */     while (!queue.isEmpty() && checkStatus()) {
/*     */       
/* 250 */       m = queue.get(0); queue.remove(0);
/* 251 */       RGNode n = this.rg.getNode(m);
/* 252 */       State m1 = null;
/*     */       
/* 254 */       Collection c = noReduction.getTransitions((State)m.getPlaceMarking());
/* 255 */       for (Iterator<Transition> it = c.iterator(); it.hasNext(); ) {
/*     */         
/* 257 */         Transition t = it.next();
/* 258 */         m1 = t.fire((State)m, true, true);
/*     */         
/* 260 */         if (m1 != null) {
/* 261 */           RGNode q = this.rg.getNode(m1);
/* 262 */           if (check(m1.getPlaceMarking(), this.target)) {
/* 263 */             if (q == null) {
/* 264 */               q = new RGNode(this.pn, m1);
/*     */             }
/* 266 */             this.edgeTree.add(this.rg.addEdge(n, q, t.getId()));
/* 267 */             if (!checkStatus()) { cleanup(); return false; }
/* 268 */              return true;
/*     */           } 
/* 270 */           if (q == null) {
/* 271 */             if (check(m1.getPlaceMarking(), this.target)) {
/* 272 */               DebugCounter.inc("found a state ");
/* 273 */               q = new RGNode(this.pn, m1);
/* 274 */               this.edgeTree.add(this.rg.addEdge(n, q, t.getId()));
/*     */               
/* 276 */               if (!checkStatus()) { cleanup(); return false; }
/* 277 */                return true;
/*     */             } 
/* 279 */             if (this.count > this.maximumStates) {
/* 280 */               return false;
/*     */             }
/* 282 */             q = new RGNode(this.pn, m1);
/* 283 */             this.rg.addNode(q);
/* 284 */             this.edgeTree.add(this.rg.addEdge(n, q, t.getId()));
/* 285 */             queue.add(m1);
/* 286 */             statesInNextLayer++;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 292 */       if (this.count % 500 == 0) {
/*     */         
/* 294 */         this.progress++;
/* 295 */         if (!checkStatus()) { cleanup(); return false; }
/*     */       
/* 297 */       }  this.count++;
/* 298 */       statesInCurrentLayer--;
/* 299 */       if (statesInCurrentLayer == 0) {
/* 300 */         layer++;
/* 301 */         if (layer > this.maximumLength) {
/* 302 */           if (!checkStatus()) { cleanup(); return false; }
/*     */           
/* 304 */           return false;
/*     */         } 
/* 306 */         statesInCurrentLayer = statesInNextLayer;
/* 307 */         statesInNextLayer = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 311 */     if (!checkStatus()) { cleanup(); return false; }
/* 312 */      return false;
/*     */   }
/*     */   
/*     */   public boolean spanningSubGraphConstruction() throws SafetyException, WrongFilterException {
/* 316 */     NoReduction noReduction = new NoReduction(this.pn);
/* 317 */     int layer = 1;
/* 318 */     int statesInNextLayer = 0;
/* 319 */     int statesInCurrentLayer = 1;
/*     */     
/* 321 */     HashSet visited = new HashSet();
/* 322 */     Vector<RGNode> queue = new Vector<>();
/* 323 */     Marking m = ((State)this.start).getPlaceMarking();
/* 324 */     DebugCounter.inc("start.getPlaceMarking() = " + m);
/* 325 */     RGNode n = this.rg.getNode(m);
/* 326 */     if (n == null) {
/* 327 */       return false;
/*     */     }
/* 329 */     DebugCounter.inc("starting with rgnode: " + n);
/*     */     
/* 331 */     queue.add(n);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     while (!queue.isEmpty() && checkStatus()) {
/* 340 */       n = queue.get(0);
/* 341 */       queue.remove(0);
/* 342 */       RGEdge edge = n.out();
/* 343 */       while (edge != null) {
/* 344 */         RGNode q = edge.node(n);
/*     */         
/* 346 */         if (check(q.getLabel(), this.target)) {
/* 347 */           this.edgeTree.add(edge);
/*     */           
/* 349 */           return true;
/*     */         } 
/* 351 */         System.out.printf("q: %s maxStates: %d count : %d queue.size() %d\n", new Object[] { q, Long.valueOf(this.maximumStates), Integer.valueOf(this.count), Integer.valueOf(queue.size()) });
/* 352 */         if (this.count > this.maximumStates) {
/* 353 */           return false;
/*     */         }
/* 355 */         this.edgeTree.add(edge);
/* 356 */         queue.add(q);
/* 357 */         statesInNextLayer++;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 365 */       this.count++;
/* 366 */       statesInCurrentLayer--;
/* 367 */       if (statesInCurrentLayer == 0) {
/* 368 */         layer++;
/* 369 */         if (layer > this.maximumLength)
/*     */         {
/* 371 */           return false;
/*     */         }
/* 373 */         statesInCurrentLayer = statesInNextLayer;
/* 374 */         statesInNextLayer = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 378 */     if (!checkStatus()) { cleanup(); return false; }
/* 379 */      return false;
/*     */   }
/*     */   
/*     */   private Path computePath() {
/* 383 */     DebugCounter.inc("ComputePath start");
/* 384 */     TraversationDataTable tdt = new TraversationDataTable();
/* 385 */     int scc = 0;
/* 386 */     boolean notfinished = true;
/* 387 */     RGNode n = this.rg.getNode(this.start);
/* 388 */     Path p = new Path(n, this.rg);
/* 389 */     RGNode q = null;
/* 390 */     Vector<Short> transitionIds = new Vector();
/* 391 */     Stack<StackEntry> st = new Stack();
/* 392 */     Collection c = null;
/* 393 */     Iterator it = null;
/* 394 */     int count = 0;
/* 395 */     float oneProg = 20.0F / this.rg.getNumberOfNodes();
/* 396 */     float prog = 80.0F;
/*     */     
/* 398 */     RGEdge edge = null;
/*     */     
/*     */     do {
/* 401 */       prog += oneProg;
/* 402 */       if ((int)prog >= (int)this.progress + 1) {
/*     */         
/* 404 */         this.progress = (int)prog;
/* 405 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/*     */       } 
/* 408 */       if (!tdt.visited(n)) {
/* 409 */         tdt.setVisited(n, true);
/* 410 */         edge = n.out();
/* 411 */         while (edge != null && !this.edgeTree.contains(edge)) {
/* 412 */           edge = n.out();
/*     */         }
/*     */       } 
/* 415 */       if (edge != null)
/* 416 */       { q = edge.node(n);
/*     */         
/* 418 */         if (check(q.getLabel(), this.target)) {
/*     */           
/* 420 */           p.checkAndAddNode(q);
/*     */           
/* 422 */           transitionIds.add(new Short(edge.getId()));
/*     */           
/*     */           break;
/*     */         } 
/* 426 */         if (!tdt.visited(q)) {
/* 427 */           p.checkAndAddNode(q);
/* 428 */           transitionIds.add(new Short(edge.getId()));
/* 429 */           if (check(q.getLabel(), this.target)) {
/* 430 */             return p;
/*     */           }
/* 432 */           st.add(new StackEntry(n, edge, q));
/*     */           
/* 434 */           n = q;
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 439 */           edge = edge.next();
/*     */         }  }
/* 441 */       else { if (n.equals(this.start)) {
/* 442 */           notfinished = false;
/*     */         }
/* 444 */         if (!st.isEmpty()) {
/* 445 */           StackEntry top = st.pop();
/*     */           
/* 447 */           p.deleteLast();
/* 448 */           n = top.n;
/* 449 */           q = top.q;
/* 450 */           edge = top.e.next();
/*     */         }
/*     */          }
/*     */     
/* 454 */     } while (notfinished || !st.isEmpty());
/* 455 */     DebugCounter.inc("ComputePath finish");
/* 456 */     DebugCounter.inc("path " + p.length());
/* 457 */     return p;
/*     */   }
/*     */   
/*     */   public boolean isShortestPathSearch() {
/* 461 */     return true;
/*     */   }
/*     */   
/*     */   private class StackEntry {
/*     */     RGNode n;
/*     */     RGNode q;
/*     */     RGEdge e;
/*     */     
/*     */     public StackEntry(RGNode n, RGEdge e, RGNode q) {
/* 470 */       this.n = n;
/* 471 */       this.e = e;
/* 472 */       this.q = q;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/path/ShortestPathConstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */