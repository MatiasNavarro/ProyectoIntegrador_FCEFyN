/*     */ package charlie.analyzer.path;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.TextFile;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGraph;
/*     */ 
/*     */ public class PathConstruction
/*     */   extends Analyzer {
/*  14 */   public static int INFINITY = Integer.MAX_VALUE;
/*     */ 
/*     */   
/*  17 */   protected Path foundPath = null;
/*     */   
/*  19 */   protected PathComputationOptions po = null;
/*     */ 
/*     */   
/*     */   protected boolean equal = false;
/*     */   
/*  24 */   protected Object start = null;
/*     */   
/*  26 */   protected Object target = null;
/*     */ 
/*     */   
/*  29 */   protected RGraph rg = null;
/*     */   
/*  31 */   protected PlaceTransitionNet pn = null;
/*     */   
/*  33 */   long maximumStates = 10000000L;
/*     */   
/*  35 */   long maximumLength = 10000000L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  43 */     return "Path construction";
/*     */   }
/*     */ 
/*     */   
/*     */   public void evaluate() {
/*  48 */     Path path = (Path)this.po.getResultObject();
/*  49 */     if (path == null);
/*     */ 
/*     */     
/*  52 */     if (this.po.exportFileMarkingSequence != null) {
/*  53 */       TextFile.writeToFile(this.po.exportFileMarkingSequence, path.toMarkingSequence(this.pn), true);
/*     */     }
/*  55 */     if (this.po.exportFileTransitionSequence != null) {
/*  56 */       TextFile.writeToFile(this.po.exportFileTransitionSequence, path.toTransitionSequence(this.pn), true);
/*     */     }
/*  58 */     if (this.po.exportFileParikhVector != null) {
/*  59 */       TextFile.writeToFile(this.po.exportFileParikhVector, path.toParikhVector(this.pn), true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean register() {
/*  75 */     PathConstruction pc = new PathConstruction();
/*  76 */     boolean value = AnalyzerManagerFactory.getAnalyzerManager().register(pc, new RGraph(), new Path());
/*  77 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Analyzer getNewInstance(OptionSet options) {
/*  82 */     PathComputationOptions po = (PathComputationOptions)options;
/*  83 */     PathConstruction spc = null;
/*  84 */     if (po.rGraph == null && 
/*  85 */       po.getObjectToAnalyze() != null && po.getObjectToAnalyze() instanceof RGraph) {
/*  86 */       po.rGraph = (RGraph)po.getObjectToAnalyze();
/*     */     }
/*     */     
/*  89 */     if (po.computationType == 0) {
/*  90 */       if (po.rGraph.isTimedGraph()) {
/*  91 */         spc = new TimedShortestPathConstruction();
/*     */       } else {
/*  93 */         spc = new ShortestPathConstruction();
/*     */       } 
/*  95 */     } else if (po.computationType == 1) {
/*  96 */       spc = new TimedLongestPathConstruction();
/*     */     } 
/*  98 */     spc.setup(options);
/*  99 */     DebugCounter.inc("PathConstruction Returning : " + spc.getClass().getName());
/* 100 */     return spc;
/*     */   }
/*     */   
/*     */   public void cleanUp() {}
/*     */   
/*     */   public void initializeInfoStrings() {}
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/path/PathConstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */