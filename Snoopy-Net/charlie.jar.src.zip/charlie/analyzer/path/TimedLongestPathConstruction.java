/*     */ package charlie.analyzer.path;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.StackTracePrinter;
/*     */ import charlie.filter.Filter;
/*     */ import charlie.filter.WrongFilterException;
/*     */ import charlie.pn.State;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGEdge;
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import charlie.rg.SCC;
/*     */ import charlie.rg.TimedEdge;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Stack;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimedLongestPathConstruction
/*     */   extends PathConstruction
/*     */ {
/*     */   private double progress;
/*     */   boolean equal;
/*     */   private RGNode[] nodeIndices;
/*  29 */   private Path p = null;
/*     */   
/*     */   Vector<RGEdge>[] sccEdges;
/*  32 */   RGraph pathRGraph = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   int count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  44 */     return "Timed Longest Path Construction";
/*     */   }
/*     */ 
/*     */   
/*     */   public void analyze() {
/*  49 */     this.po = (PathComputationOptions)this.options;
/*  50 */     if (this.po.rGraph == null) { setOutput("no rgraph provided in options"); cancel(); return; }
/*  51 */      this.rg = this.po.rGraph;
/*  52 */     this.pn = this.po.rGraph.getNet();
/*  53 */     this.maximumStates = this.po.maximalConsideredStates;
/*  54 */     if (this.maximumStates == -1L || this.maximumStates == 0L) {
/*  55 */       this.maximumStates = 2147483647L;
/*     */     }
/*  57 */     this.maximumLength = this.po.maxPathLength;
/*  58 */     if (this.maximumLength == -1L || this.maximumLength == 0L);
/*     */     
/*  60 */     this.maximumLength = 2147483647L;
/*  61 */     setOutput("longest path construction");
/*  62 */     DebugCounter.inc("LongestPathConstruction started");
/*     */     
/*  64 */     if (this.po.targetFilter != null && this.po.targetState == null) {
/*  65 */       this.target = this.po.targetFilter;
/*  66 */       if (this.po.markingType == 1) {
/*  67 */         this.equal = true;
/*     */         try {
/*  69 */           this.target = this.po.targetFilter.createMarking();
/*  70 */         } catch (WrongFilterException e) {
/*     */           
/*  72 */           setOutput("provided target filter could not be created!");
/*  73 */           cancel();
/*     */           return;
/*     */         } 
/*  76 */       } else if (this.po.markingType == 0) {
/*  77 */         this.equal = false;
/*     */       } else {
/*  79 */         setOutput("Markingtype set to unknown value :" + this.po.markingType);
/*  80 */         cancel();
/*     */         return;
/*     */       } 
/*  83 */     } else if (this.po.targetFilter == null && this.po.targetState != null) {
/*  84 */       this.target = this.po.targetState;
/*     */       
/*  86 */       this.equal = true;
/*     */     } else {
/*     */       
/*  89 */       if (this.po.targetFilter == null && this.po.targetState == null) {
/*  90 */         setOutput("target Filter and target state are not initialized!");
/*  91 */         DebugCounter.inc("target Filter and target state are not initialized!");
/*  92 */       }  if (this.po.targetFilter != null && this.po.targetState != null) {
/*  93 */         setOutput("target Filter and target state are both initialized don't know which to choose!");
/*  94 */         DebugCounter.inc("target Filter and target state are both initialized don't know which to choose!");
/*     */       } 
/*  96 */       cancel();
/*     */       return;
/*     */     } 
/*  99 */     DebugCounter.inc("LongestPathConstruction: target filter initialized");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     if (this.po.startState != null && this.po.startFilter == null) {
/* 129 */       this.start = this.po.startState;
/* 130 */     } else if (this.po.startState == null && this.po.startFilter != null) {
/* 131 */       this.start = this.po.startFilter;
/*     */     } else {
/* 133 */       if (this.po.startState == null && this.po.startFilter == null) {
/* 134 */         setOutput("start Filter and start state are not initialized !");
/*     */       }
/* 136 */       if (this.po.startState != null && this.po.startFilter != null) {
/* 137 */         setOutput("start Filter and start state are both initialized don't know which to choose!");
/*     */       }
/* 139 */       cancel();
/*     */       return;
/*     */     } 
/* 142 */     this.nodeIndices = new RGNode[this.rg.verticesSize()];
/* 143 */     DebugCounter.inc("start filter initialized");
/* 144 */     setOutput("start:\n" + this.start);
/* 145 */     setOutput("target:\n" + this.target);
/*     */     try {
/* 147 */       this.p = compute();
/* 148 */       if (this.p == null) {
/* 149 */         DebugCounter.inc("LongestPathConstruction.compute did not return a path");
/*     */       } else {
/* 151 */         DebugCounter.inc("longest path length:" + this.p.length());
/* 152 */         setOutput("path length:" + this.p.length());
/* 153 */         switch (this.p.getInfinityState()) { case 0:
/* 154 */             setOutput("Path is finite"); break;
/* 155 */           case 1: setOutput("Path has an infinite cycle"); break;
/* 156 */           case 2: setOutput("path has an inifinite time edge"); break; }
/*     */       
/*     */       } 
/* 159 */       this.po.setResultObject(this.p);
/* 160 */       this.p.setName(this.target.toString());
/* 161 */       this.po.pathRGraph = this.pathRGraph;
/* 162 */     } catch (Exception e) {
/* 163 */       DebugCounter.inc("LongestPathConstruction caught exception\n" + e.getClass().getName() + "\n" + StackTracePrinter.getStackTrace(e));
/* 164 */       cancel();
/* 165 */       cleanup();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path compute() throws Exception {
/* 183 */     DebugCounter.inc("LongestPathConstruction.compute()");
/* 184 */     this.sccEdges = (Vector<RGEdge>[])new Vector[this.rg.verticesSize()];
/* 185 */     for (int i = 0; i < this.sccEdges.length; i++) {
/*     */       
/* 187 */       this.sccEdges[i] = null;
/* 188 */       if (!checkStatus()) { cleanup(); return null; }
/*     */     
/* 190 */     }  Collection<RGNode> startNodes = new Vector();
/* 191 */     this.progress = 0.0D;
/* 192 */     if (!checkStatus()) { cleanup(); return null; }
/*     */     
/* 194 */     if (this.start instanceof State) {
/*     */       
/* 196 */       if (this.rg.getNode(this.start) == null) {
/*     */         
/* 198 */         startNodes = this.rg.getSatisfyingStates((State)this.start);
/* 199 */         if (startNodes.isEmpty()) {
/* 200 */           return new Path();
/*     */         }
/*     */       } else {
/* 203 */         startNodes.add(this.rg.getNode(this.start));
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 208 */       startNodes = this.rg.getSatisfyingStates((Filter)this.start);
/* 209 */       if (startNodes.isEmpty()) {
/* 210 */         return new Path();
/*     */       }
/*     */     } 
/*     */     
/* 214 */     Collection<RGNode> targetNodes = new Vector();
/* 215 */     if (this.target instanceof State) {
/*     */       
/* 217 */       if (this.rg.getNode(this.target) == null) {
/*     */         
/* 219 */         targetNodes = this.rg.getSatisfyingStates((State)this.target);
/* 220 */         if (targetNodes.isEmpty()) {
/* 221 */           return new Path();
/*     */         }
/*     */       } else {
/* 224 */         targetNodes.add(this.rg.getNode(this.target));
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 229 */       targetNodes = this.rg.getSatisfyingStates((Filter)this.target);
/* 230 */       if (targetNodes.isEmpty()) {
/* 231 */         return new Path();
/*     */       }
/*     */     } 
/* 234 */     Iterator<RGNode> it = startNodes.iterator();
/* 235 */     RGNode startNode = null;
/* 236 */     RGNode endNode = null;
/* 237 */     Path p = new Path();
/* 238 */     Vector<Stack<StackEntry>> ways = new Vector<>();
/* 239 */     if (startNodes.size() == 1) {
/*     */       
/* 241 */       Vector<Integer> nodesNotReachable = findNotReachableNodes(targetNodes, startNode);
/* 242 */       Vector<Integer> sccNotReachable = findNotReachableSCCs(nodesNotReachable);
/* 243 */       if (!checkStatus()) { cleanup(); return null; }
/*     */       
/* 245 */       startNode = it.next();
/* 246 */       ways = popova(startNode, targetNodes, startNodes.size(), sccNotReachable);
/* 247 */       if (!checkStatus()) { cleanup(); return null; }
/*     */     
/*     */     } else {
/* 250 */       Vector<Integer> nodesNotReachable = findNotReachableNodes(targetNodes, startNode);
/* 251 */       Vector<Integer> sccNotReachable = findNotReachableSCCs(nodesNotReachable);
/* 252 */       if (!checkStatus()) { cleanup(); return null; }
/*     */       
/* 254 */       while (it.hasNext()) {
/*     */         
/* 256 */         Vector<Stack<StackEntry>> way = popova(it.next(), targetNodes, startNodes.size(), sccNotReachable);
/* 257 */         if (way != null) {
/* 258 */           ways.addAll(way);
/*     */         } else {
/*     */           
/* 261 */           ways = null;
/*     */           break;
/*     */         } 
/* 264 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/*     */       } 
/* 267 */     }  if (ways == null) {
/* 268 */       setOutput("\nNo longest path because there are cycles on a path to the node and so the path is infinite.");
/* 269 */       p.setInfinityState(1);
/* 270 */       return p;
/*     */     } 
/* 272 */     if (!ways.isEmpty()) {
/* 273 */       p = getAbsoluteLongestPath(ways);
/* 274 */       if (p == null) {
/*     */         
/* 276 */         p = new Path();
/* 277 */         p.setInfinityState(2);
/* 278 */         setOutput("\nNo longest path because there are infinite time transitions on a path to the node and so the path is infinite.");
/* 279 */         return p;
/*     */       } 
/* 281 */       this.pathRGraph = computeRG(p);
/*     */     } 
/*     */ 
/*     */     
/* 285 */     startNode = p.first();
/* 286 */     endNode = p.last();
/* 287 */     if (p.first() != null && startNode != null && endNode != null) {
/* 288 */       setOutput("\nlongest Path from " + this.pn.toLabel(startNode.getMarking()));
/* 289 */       setOutput("to " + this.pn.toLabel(endNode.getMarking()));
/* 290 */       int distance = p.getWayLength();
/* 291 */       if (distance > 0) {
/* 292 */         setOutput("distance of the computed path: " + distance);
/*     */       }
/* 294 */       setOutput("sequence length of the computed path: " + p.length());
/* 295 */       setOutput("computed path: " + p.getString());
/* 296 */       setOutput("\n" + p.toParikhVector(this.pn));
/*     */     } else {
/* 298 */       setOutput("marking not reached");
/*     */     } 
/* 300 */     this.progress = 100.0D;
/* 301 */     if (!checkStatus()) { cleanup(); return null; }
/* 302 */      return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RGEdge getMaximalEdge(RGNode out, RGNode in) {
/* 320 */     RGEdge edge = null;
/* 321 */     if (out != null && in != null) {
/*     */       
/* 323 */       RGEdge outEdge = out.out();
/* 324 */       while (outEdge != null) {
/*     */         
/* 326 */         if (outEdge.getDestinationNode() == in) {
/*     */           
/* 328 */           if (outEdge instanceof TimedEdge && (
/* 329 */             (TimedEdge)outEdge).isInfinite()) {
/* 330 */             return outEdge;
/*     */           }
/*     */           
/* 333 */           if (edge == null || edge.getDistance() < outEdge.getDistance()) {
/* 334 */             edge = outEdge;
/*     */           }
/*     */         } 
/* 337 */         outEdge = outEdge.next();
/*     */       } 
/*     */     } 
/* 340 */     return edge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RGraph getGraph() {
/* 347 */     return this.rg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector<RGEdge> getAllEdges(RGNode node) {
/* 356 */     boolean[] nodeNumberField = new boolean[this.rg.getNumberOfNodes()];
/* 357 */     for (int i = 0; i < nodeNumberField.length; i++) {
/* 358 */       nodeNumberField[i] = false;
/*     */     }
/* 360 */     Vector<RGEdge> allEdges = new Vector<>();
/* 361 */     RGEdge inEdge = node.out();
/* 362 */     while (inEdge != null) {
/*     */       
/* 364 */       RGNode tempNode = inEdge.getDestinationNode();
/* 365 */       if (tempNode.sccNumber() != node.sccNumber() && !nodeNumberField[tempNode.getStateNumber() - 1]) {
/*     */         
/* 367 */         RGEdge e = getMaximalEdge(node, tempNode);
/* 368 */         allEdges.add(e);
/* 369 */         nodeNumberField[tempNode.getStateNumber() - 1] = true;
/*     */       } 
/* 371 */       inEdge = inEdge.next();
/*     */     } 
/* 373 */     return allEdges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector<Stack<StackEntry>> popova(RGNode startNode, Collection endNodes, int numberOfStartNodes, Vector<Integer> sccNotReachable) {
/* 384 */     Stack<StackEntry> sccStack = new Stack<>();
/* 385 */     Stack<StackEntry> longestStack = new Stack<>();
/* 386 */     Vector<Stack<StackEntry>> wayStacks = new Vector<>();
/* 387 */     SCC startSCC = (SCC)this.rg.getScc().get(Integer.valueOf(startNode.sccNumber()));
/* 388 */     if (startSCC.size() > 1) {
/* 389 */       return null;
/*     */     }
/* 391 */     int strictlyCCOnTheWay = 0;
/* 392 */     double N = this.rg.getScc().size() - sccNotReachable.size();
/* 393 */     double V = this.rg.getNumberOfEdges();
/* 394 */     double oneProg = 70.0D / N * N * N * numberOfStartNodes;
/* 395 */     double prog = this.progress;
/* 396 */     int currentWayLength = 0;
/* 397 */     int biggestWayLength = 0;
/* 398 */     int biggestSequenceLength = 0;
/* 399 */     sccStack.push(new StackEntry(startSCC, getAllOutEdges(startSCC), null));
/* 400 */     double i = 0.0D;
/* 401 */     while (!sccStack.isEmpty() && checkStatus()) {
/*     */       
/* 403 */       Vector<RGEdge> currentTransitionEdges = ((StackEntry)sccStack.peek()).remainingEdges;
/* 404 */       if (!currentTransitionEdges.isEmpty() && sccStack.size() <= this.maximumLength) {
/*     */         
/* 406 */         RGEdge edge = currentTransitionEdges.firstElement();
/* 407 */         currentTransitionEdges.remove(edge);
/* 408 */         SCC newSCC = (SCC)this.rg.getScc().get(Integer.valueOf(edge.getDestinationNode().sccNumber()));
/* 409 */         if (!sccNotReachable.contains(Integer.valueOf(newSCC.number()))) {
/*     */           
/* 411 */           boolean foundOnStack = false;
/* 412 */           i++;
/* 413 */           currentWayLength += edge.getDistance();
/* 414 */           if (newSCC.size() > 1 || edge.getDestinationNode().hasCycleEdge())
/*     */           {
/* 416 */             strictlyCCOnTheWay++;
/*     */           }
/* 418 */           StackEntry newEntry = new StackEntry(newSCC, getAllOutEdges(newSCC), edge);
/* 419 */           if (longestStack.contains(newEntry) && !((StackEntry)longestStack.lastElement()).equals(newEntry)) {
/*     */             
/* 421 */             foundOnStack = true;
/* 422 */             if (strictlyCCOnTheWay == 0)
/* 423 */             { Stack<StackEntry> newStack = new Stack<>();
/* 424 */               for (Iterator<StackEntry> itStack = sccStack.iterator(); itStack.hasNext();) {
/* 425 */                 newStack.push(itStack.next());
/*     */               }
/* 427 */               newStack.push(newEntry);
/* 428 */               Iterator<StackEntry> longestStackIt = longestStack.iterator();
/* 429 */               while (!((StackEntry)longestStackIt.next()).equals(newEntry));
/*     */ 
/*     */               
/* 432 */               int lastLength = 0;
/* 433 */               StackEntry entryBefore = newEntry;
/* 434 */               while (longestStackIt.hasNext()) {
/*     */                 
/* 436 */                 StackEntry se = longestStackIt.next();
/* 437 */                 newStack.push(se);
/* 438 */                 RGEdge tempEdge = getEdgeBetween2Entries(entryBefore, se);
/* 439 */                 if (tempEdge != null) {
/* 440 */                   lastLength += tempEdge.getDistance();
/*     */                 }
/*     */               } 
/* 443 */               if (currentWayLength + lastLength > biggestWayLength)
/*     */               {
/* 445 */                 longestStack = newStack;
/* 446 */                 biggestWayLength = currentWayLength + lastLength;
/* 447 */                 biggestSequenceLength = newStack.size();
/*     */               
/*     */               }
/* 450 */               else if (currentWayLength + lastLength == biggestWayLength && biggestSequenceLength < newStack.size())
/*     */               {
/* 452 */                 longestStack = newStack;
/* 453 */                 biggestSequenceLength = newStack.size();
/*     */               
/*     */               }
/*     */                }
/*     */             
/* 458 */             else if (!checkStatus()) { cleanup(); return null; }
/*     */ 
/*     */           
/*     */           } else {
/*     */             
/* 463 */             for (Iterator<RGNode> it = endNodes.iterator(); it.hasNext(); ) {
/*     */               
/* 465 */               RGNode n = it.next();
/* 466 */               if (newSCC.contains(n)) {
/*     */                 
/* 468 */                 if (strictlyCCOnTheWay == 0) {
/*     */                   
/* 470 */                   if (biggestWayLength < currentWayLength) {
/*     */                     
/* 472 */                     longestStack.clear();
/* 473 */                     for (Iterator<StackEntry> itStack = sccStack.iterator(); itStack.hasNext();) {
/* 474 */                       longestStack.push(itStack.next());
/*     */                     }
/* 476 */                     longestStack.push(newEntry);
/* 477 */                     biggestWayLength = currentWayLength;
/* 478 */                     biggestSequenceLength = longestStack.size();
/*     */                     continue;
/*     */                   } 
/* 481 */                   if (biggestWayLength == currentWayLength && biggestSequenceLength < sccStack.size()) {
/*     */                     
/* 483 */                     longestStack.clear();
/* 484 */                     for (Iterator<StackEntry> itStack = sccStack.iterator(); itStack.hasNext();) {
/* 485 */                       longestStack.push(itStack.next());
/*     */                     }
/* 487 */                     longestStack.push(newEntry);
/* 488 */                     biggestSequenceLength = longestStack.size();
/*     */                   } 
/*     */ 
/*     */ 
/*     */                   
/*     */                   continue;
/*     */                 } 
/*     */ 
/*     */ 
/*     */                 
/* 498 */                 if (!checkStatus()) { cleanup(); return null; }
/*     */               
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 505 */           prog += oneProg;
/* 506 */           if (((int)prog > (int)this.progress + 1 && (int)prog < 80) || this.count % 500 == 0) {
/*     */             
/* 508 */             this.progress = (int)prog;
/* 509 */             if (!checkStatus()) { cleanup(); return null; }
/*     */           
/* 511 */           }  if (!foundOnStack) {
/*     */             
/* 513 */             sccStack.push(new StackEntry(newSCC, getAllOutEdges(newSCC), edge));
/* 514 */             this.count++; continue;
/*     */           } 
/* 516 */           currentWayLength -= edge.getDistance();
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 521 */       StackEntry e = sccStack.pop();
/* 522 */       if (e.scc.size() > 1) {
/*     */         
/* 524 */         strictlyCCOnTheWay--;
/*     */       }
/* 526 */       else if (e.scc.getRoot().hasCycleEdge()) {
/* 527 */         strictlyCCOnTheWay--;
/*     */       } 
/* 529 */       if (e.incomingEdge != null)
/*     */       {
/* 531 */         currentWayLength -= e.incomingEdge.getDistance();
/*     */       }
/*     */     } 
/*     */     
/* 535 */     if (!checkStatus()) { cleanup(); return null; }
/* 536 */      this.progress = prog;
/* 537 */     if (!longestStack.isEmpty()) {
/* 538 */       wayStacks.add(longestStack);
/*     */     }
/* 540 */     return wayStacks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector<RGEdge> getAllOutEdges(SCC scc) {
/* 549 */     if (this.sccEdges[scc.number()] != null) {
/* 550 */       return this.sccEdges[scc.number()];
/*     */     }
/* 552 */     Vector<RGEdge> edges = new Vector<>();
/* 553 */     for (Iterator<RGNode> it = scc.iterator(); it.hasNext();)
/*     */     {
/* 555 */       edges.addAll(getAllEdges(it.next()));
/*     */     }
/* 557 */     this.sccEdges[scc.number()] = edges;
/* 558 */     return edges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RGEdge getEdgeBetween2Entries(StackEntry beginEntry, StackEntry endEntry) {
/* 568 */     if (beginEntry == null || endEntry == null) {
/* 569 */       return null;
/*     */     }
/* 571 */     RGEdge outEdge = null;
/* 572 */     for (RGEdge e : beginEntry.allEdges) {
/*     */       
/* 574 */       if (e.getDestinationNode().sccNumber() == endEntry.scc.number())
/*     */       {
/* 576 */         if (outEdge == null || outEdge.getDistance() < e.getDistance()) {
/* 577 */           outEdge = e;
/*     */         }
/*     */       }
/*     */     } 
/* 581 */     return outEdge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Path getAbsoluteLongestPath(Vector<Stack<StackEntry>> wayStacks) {
/* 591 */     Path path = new Path();
/* 592 */     Vector<Path> shortestPaths = new Vector<>();
/* 593 */     int currentLength = -1;
/* 594 */     double oneProg = 10.0D / wayStacks.size();
/* 595 */     this.progress = 80.0D;
/* 596 */     double prog = this.progress;
/*     */     
/* 598 */     for (Stack<StackEntry> stack : wayStacks) {
/*     */       
/* 600 */       prog += oneProg;
/* 601 */       if ((int)prog >= (int)this.progress + 1) {
/*     */         
/* 603 */         this.progress = (int)prog;
/* 604 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/* 606 */       }  Iterator<StackEntry> stackIt = stack.iterator();
/* 607 */       StackEntry entryBefore = stackIt.next();
/* 608 */       Path newPath = new Path(entryBefore.scc.getRoot(), this.rg);
/* 609 */       while (stackIt.hasNext()) {
/*     */         
/* 611 */         StackEntry se = stackIt.next();
/* 612 */         RGEdge tempEdge = getEdgeBetween2Entries(entryBefore, se);
/* 613 */         if (tempEdge instanceof TimedEdge && (
/* 614 */           (TimedEdge)tempEdge).isInfinite()) {
/* 615 */           return null;
/*     */         }
/*     */         
/* 618 */         newPath.checkAndAddNode(se.scc.getRoot(), tempEdge);
/* 619 */         entryBefore = se;
/*     */       } 
/* 621 */       int newPathLength = newPath.getWayLength();
/* 622 */       if (newPathLength > currentLength) {
/*     */         
/* 624 */         shortestPaths.clear();
/* 625 */         shortestPaths.add(newPath);
/* 626 */         currentLength = newPathLength; continue;
/*     */       } 
/* 628 */       if (newPathLength == currentLength) {
/* 629 */         shortestPaths.add(newPath);
/*     */       }
/*     */     } 
/* 632 */     currentLength = -1;
/* 633 */     oneProg = 5.0D / shortestPaths.size();
/* 634 */     this.progress = 90.0D;
/* 635 */     prog = this.progress;
/*     */     
/* 637 */     for (Path p : shortestPaths) {
/*     */       
/* 639 */       prog += oneProg;
/* 640 */       if ((int)prog >= (int)this.progress + 1) {
/*     */         
/* 642 */         this.progress = (int)prog;
/* 643 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/* 645 */       }  if (p.length() > currentLength) {
/*     */         
/* 647 */         currentLength = p.length();
/* 648 */         path = p;
/*     */       } 
/*     */     } 
/*     */     
/* 652 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RGraph computeRG(Path p) {
/* 661 */     RGraph newRG = new RGraph(this.pn);
/* 662 */     Iterator<RGNode> nodeIt = p.NodeIterator();
/* 663 */     Vector<RGNode> nodeQueue = new Vector<>();
/* 664 */     while (nodeIt.hasNext()) {
/* 665 */       nodeQueue.add(0, nodeIt.next());
/*     */     }
/*     */     
/* 668 */     newRG.addNode(new RGNode(this.pn, ((RGNode)nodeQueue.firstElement()).getMarking()));
/* 669 */     RGNode nodeBefore = newRG.getNode(((RGNode)nodeQueue.firstElement()).getMarking());
/* 670 */     nodeBefore.setStateNumber(((RGNode)nodeQueue.firstElement()).getStateNumber());
/* 671 */     nodeQueue.remove(0);
/* 672 */     Iterator edgeIt = p.iteratorEdgeIds();
/* 673 */     Vector edgeQueue = new Vector();
/* 674 */     while (edgeIt.hasNext()) {
/* 675 */       edgeQueue.add(0, edgeIt.next());
/*     */     }
/*     */     
/* 678 */     double oneProg = 5.0D / nodeQueue.size();
/* 679 */     double prog = 95.0D;
/* 680 */     this.progress = 95.0D;
/* 681 */     if (!checkStatus()) { cleanup(); return null; }
/*     */ 
/*     */     
/* 684 */     int i = 0;
/* 685 */     for (RGNode n : nodeQueue) {
/*     */       
/* 687 */       prog += oneProg;
/* 688 */       if ((int)prog >= (int)this.progress + 1) {
/*     */         
/* 690 */         this.progress = (int)prog;
/* 691 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/* 693 */       }  newRG.addNode(new RGNode(this.pn, n.getMarking()));
/* 694 */       RGNode currentNode = newRG.getNode(n.getMarking());
/* 695 */       currentNode.setStateNumber(n.getStateNumber());
/* 696 */       Object e = edgeQueue.get(i++);
/* 697 */       if (e instanceof TimedEdge) {
/* 698 */         newRG.addEdge(nodeBefore, currentNode, (short)-2, ((TimedEdge)e).getTimeTransition(), ((TimedEdge)e).getTransitions());
/*     */       } else {
/* 700 */         newRG.addEdge(nodeBefore, currentNode, ((RGEdge)e).getId());
/*     */       } 
/* 702 */       nodeBefore = currentNode;
/*     */     } 
/* 704 */     return newRG;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void printWays(Vector<Stack<StackEntry>> wayStacks) {
/* 712 */     StringBuffer stb = new StringBuffer();
/* 713 */     stb.append("Ways:\n");
/* 714 */     if (wayStacks == null) {
/* 715 */       stb.append("infinite Ways!");
/*     */     } else {
/* 717 */       for (Stack<StackEntry> stack : wayStacks) {
/*     */         
/* 719 */         stb.append("new Way:\n");
/* 720 */         stb.append("{\n");
/* 721 */         StackEntry entryBefore = null;
/* 722 */         for (Iterator<StackEntry> it = stack.iterator(); it.hasNext(); ) {
/*     */           
/* 724 */           StackEntry se = it.next();
/* 725 */           RGEdge edge = getEdgeBetween2Entries(entryBefore, se);
/* 726 */           if (edge != null) {
/* 727 */             stb.append("EdgeWeight: " + edge.getDistance() + "\n");
/*     */           }
/* 729 */           for (Iterator<RGNode> sccIterator = se.scc.iterator(); sccIterator.hasNext();)
/*     */           {
/* 731 */             stb.append(this.pn.toLabel(((RGNode)sccIterator.next()).getMarking()) + " ");
/*     */           }
/* 733 */           stb.append("\n");
/* 734 */           entryBefore = se;
/*     */         } 
/* 736 */         stb.append("}\n");
/*     */       } 
/*     */     } 
/* 739 */     System.out.println(stb.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector<Integer> findNotReachableSCCs(Vector<Integer> notReachableNodes) {
/* 749 */     Vector<Integer> sccs = new Vector<>();
/* 750 */     for (Iterator<SCC> it = this.rg.getScc().values().iterator(); it.hasNext(); ) {
/*     */       
/* 752 */       SCC newSCC = it.next();
/* 753 */       boolean found = true;
/* 754 */       for (Iterator<RGNode> it1 = newSCC.iterator(); it1.hasNext(); ) {
/*     */         
/* 756 */         RGNode n = it1.next();
/* 757 */         if (!notReachableNodes.contains(Integer.valueOf(n.getStateNumber()))) {
/*     */           
/* 759 */           found = false;
/*     */           break;
/*     */         } 
/*     */       } 
/* 763 */       if (found) {
/* 764 */         sccs.add(Integer.valueOf(newSCC.number()));
/*     */       }
/*     */     } 
/* 767 */     return sccs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector<Integer> findNotReachableNodes(Collection endNodes, RGNode startNode) {
/* 779 */     for (Iterator<RGNode> it = this.rg.verticesIterator(); it.hasNext(); ) {
/* 780 */       RGNode n = it.next();
/* 781 */       if (n.getStateNumber() - 1 >= this.nodeIndices.length) {
/* 782 */         DebugCounter.inc("TimedLongestPathConstruction.findNotReachableNodes (n.getStateNumber()-1)> nodeIndices.length\n" + (n.getStateNumber() - 1) + " > " + this.nodeIndices.length); continue;
/* 783 */       }  if (n.getStateNumber() - 1 == -1) {
/* 784 */         DebugCounter.inc("TimedLongestPathConstruction.findNotReachableNodes (n.getStateNumber()-1)== -1"); continue;
/*     */       } 
/* 786 */       this.nodeIndices[n.getStateNumber() - 1] = n;
/*     */     } 
/*     */     
/* 789 */     Vector<Integer> nodesNotReachable = new Vector<>();
/* 790 */     for (Iterator<RGNode> iterator1 = endNodes.iterator(); iterator1.hasNext(); ) {
/*     */       
/* 792 */       Vector<Integer> nodes = dijkstra(iterator1.next(), endNodes.size());
/* 793 */       if (nodesNotReachable.isEmpty()) {
/* 794 */         nodesNotReachable.addAll(nodes);
/*     */         continue;
/*     */       } 
/* 797 */       Vector<Integer> nodesToDelete = new Vector<>();
/* 798 */       for (Integer n : nodesNotReachable) {
/*     */         
/* 800 */         if (!nodes.contains(n)) {
/* 801 */           nodesToDelete.add(n);
/*     */         }
/*     */       } 
/* 804 */       nodesNotReachable.removeAll(nodesToDelete);
/*     */     } 
/*     */     
/* 807 */     this.progress = 10.0D;
/* 808 */     if (!checkStatus()) { cleanup(); return null; }
/* 809 */      return nodesNotReachable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector<Integer> dijkstra(RGNode startNode, int numberOfStartNodes) {
/* 818 */     HashMap<Integer, Integer> wayLengths = new HashMap<>();
/*     */     
/* 820 */     Vector<Integer> nodesNotInRG = new Vector<>();
/* 821 */     for (Iterator<RGNode> it = this.rg.verticesIterator(); it.hasNext(); ) {
/* 822 */       RGNode n = it.next();
/* 823 */       wayLengths.put(Integer.valueOf(n.getStateNumber()), Integer.valueOf(INFINITY));
/* 824 */       nodesNotInRG.add(new Integer(n.getStateNumber()));
/*     */     } 
/* 826 */     int numberOfNodes = nodesNotInRG.size();
/* 827 */     double oneProg = 10.0D / numberOfStartNodes * numberOfNodes;
/* 828 */     double prog = this.progress;
/*     */     
/* 830 */     nodesNotInRG.remove(new Integer(startNode.getStateNumber()));
/* 831 */     wayLengths.put(Integer.valueOf(startNode.getStateNumber()), Integer.valueOf(0));
/* 832 */     RGNode currentState = startNode;
/* 833 */     int i = 0;
/* 834 */     while (!nodesNotInRG.isEmpty() && currentState != null && checkStatus()) {
/*     */       
/* 836 */       for (Integer m : nodesNotInRG) {
/*     */         
/* 838 */         RGEdge edge = getMinimalEdge(currentState, getNodeByNumber(m.intValue()));
/* 839 */         if (edge != null)
/*     */         {
/* 841 */           if (((Integer)wayLengths.get(Integer.valueOf(currentState.getStateNumber()))).intValue() < INFINITY && edge.getDistance() < INFINITY && ((Integer)wayLengths.get(m)).intValue() > ((Integer)wayLengths.get(Integer.valueOf(currentState.getStateNumber()))).intValue() + edge.getDistance())
/*     */           {
/* 843 */             wayLengths.put(Integer.valueOf(getNodeByNumber(m.intValue()).getStateNumber()), Integer.valueOf(((Integer)wayLengths.get(Integer.valueOf(currentState.getStateNumber()))).intValue() + edge.getDistance()));
/*     */           }
/*     */         }
/*     */       } 
/* 847 */       currentState = searchMinimal(wayLengths, nodesNotInRG);
/*     */       
/* 849 */       nodesNotInRG.remove(new Integer(currentState.getStateNumber()));
/*     */       
/* 851 */       prog += oneProg;
/* 852 */       if ((int)prog >= (int)this.progress + 1) {
/*     */         
/* 854 */         this.progress = (int)prog;
/* 855 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/*     */       } 
/* 858 */     }  Vector<Integer> nodesNotReachable = new Vector<>();
/* 859 */     for (Integer n : wayLengths.keySet()) {
/*     */       
/* 861 */       if (((Integer)wayLengths.get(n)).intValue() == INFINITY) {
/* 862 */         nodesNotReachable.add(n);
/*     */       }
/*     */     } 
/* 865 */     this.progress = prog;
/* 866 */     return nodesNotReachable;
/*     */   }
/*     */ 
/*     */   
/*     */   private RGNode getNodeByNumber(int nodeNumber) {
/* 871 */     return this.nodeIndices[nodeNumber - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RGEdge getMinimalEdge(RGNode out, RGNode in) {
/* 883 */     RGEdge edge = null;
/* 884 */     if (out != null && in != null) {
/*     */       
/* 886 */       RGEdge inEdge = out.inEdge();
/* 887 */       while (inEdge != null) {
/*     */         
/* 889 */         if (inEdge.getSourceNode().getStateNumber() == in.getStateNumber())
/*     */         {
/* 891 */           if (edge == null || edge.getDistance() > inEdge.getDistance()) {
/* 892 */             edge = inEdge;
/*     */           }
/*     */         }
/* 895 */         inEdge = inEdge.next();
/*     */       } 
/*     */     } 
/*     */     
/* 899 */     return edge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RGNode searchMinimal(HashMap<Integer, Integer> wayLengths, Vector<Integer> nodesNotInRG) {
/* 908 */     RGNode currentState = null;
/* 909 */     Integer currentWeight = Integer.valueOf(INFINITY);
/* 910 */     for (Integer key : nodesNotInRG) {
/*     */       
/* 912 */       if (currentState == null || currentWeight.intValue() >= ((Integer)wayLengths.get(key)).intValue()) {
/*     */         
/* 914 */         currentState = getNodeByNumber(key.intValue());
/* 915 */         currentWeight = wayLengths.get(key);
/*     */       } 
/*     */     } 
/* 918 */     return currentState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isShortestPathSearch() {
/* 925 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class StackEntry
/*     */   {
/*     */     SCC scc;
/*     */ 
/*     */     
/*     */     Vector<RGEdge> remainingEdges;
/*     */ 
/*     */     
/*     */     Vector<RGEdge> allEdges;
/*     */ 
/*     */     
/*     */     RGEdge incomingEdge;
/*     */ 
/*     */     
/*     */     public StackEntry() {}
/*     */ 
/*     */     
/*     */     public StackEntry(SCC scc, Vector<RGEdge> remainingEdges, RGEdge incomingEdge) {
/* 948 */       this.scc = scc;
/* 949 */       this.allEdges = remainingEdges;
/* 950 */       this.remainingEdges = new Vector<>();
/* 951 */       this.incomingEdge = incomingEdge;
/* 952 */       for (RGEdge e : this.allEdges) {
/* 953 */         this.remainingEdges.add(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 959 */       if (!(o instanceof StackEntry)) {
/* 960 */         return false;
/*     */       }
/* 962 */       if (((StackEntry)o).scc.number() == this.scc.number()) {
/* 963 */         return true;
/*     */       }
/* 965 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/path/TimedLongestPathConstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */