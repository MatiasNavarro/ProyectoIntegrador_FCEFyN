/*     */ package charlie.analyzer.path;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.filter.Filter;
/*     */ import charlie.filter.WrongFilterException;
/*     */ import charlie.pn.State;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGEdge;
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimedShortestPathConstruction
/*     */   extends PathConstruction
/*     */ {
/*     */   double progress;
/*     */   boolean noEndNode = true;
/*     */   RGNode[] nodeIndices;
/*  25 */   Path p = null;
/*  26 */   RGNode startNode = null;
/*  27 */   RGNode endNode = null;
/*  28 */   RGraph pathRGraph = null;
/*  29 */   private int countStates = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  36 */     return "Timed Shortes Path Construction";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze() {
/*  42 */     this.po = (PathComputationOptions)this.options;
/*  43 */     if (this.po.rGraph == null) { cancel(); return; }
/*  44 */      this.rg = this.po.rGraph;
/*  45 */     this.pn = this.po.rGraph.getNet();
/*  46 */     this.maximumStates = this.po.maximalConsideredStates;
/*  47 */     if (this.maximumStates == -1L || this.maximumStates == 0L) {
/*  48 */       this.maximumStates = 2147483647L;
/*     */     }
/*  50 */     this.maximumLength = this.po.maxPathLength;
/*  51 */     if (this.maximumLength == -1L || this.maximumLength == 0L) {
/*  52 */       this.maximumLength = 2147483647L;
/*     */     }
/*     */ 
/*     */     
/*  56 */     if (this.po.targetFilter != null && this.po.targetState == null) {
/*  57 */       this.target = this.po.targetFilter;
/*  58 */       if (this.po.markingType == 1) {
/*  59 */         this.equal = true;
/*     */         try {
/*  61 */           this.target = this.po.targetFilter.createMarking();
/*  62 */         } catch (WrongFilterException e) {
/*     */           
/*  64 */           setOutput("provided target filter could not be created!");
/*  65 */           cancel();
/*     */           return;
/*     */         } 
/*  68 */       } else if (this.po.markingType == 0) {
/*  69 */         this.equal = false;
/*     */       } else {
/*  71 */         setOutput("Markingtype set to unknown value :" + this.po.markingType);
/*  72 */         cancel();
/*     */         return;
/*     */       } 
/*  75 */     } else if (this.po.targetFilter == null && this.po.targetState != null) {
/*  76 */       this.target = this.po.targetState;
/*     */       
/*  78 */       this.equal = true;
/*     */     } else {
/*     */       
/*  81 */       if (this.po.targetFilter == null && this.po.targetState == null) {
/*  82 */         setOutput("target Filter and target state are not initialized!");
/*     */       }
/*  84 */       if (this.po.targetFilter != null && this.po.targetState != null) {
/*  85 */         setOutput("target Filter and target state are both initialized don't know which to choose!");
/*     */       }
/*  87 */       cancel();
/*     */       
/*     */       return;
/*     */     } 
/*  91 */     if (this.po.startState != null && this.po.startFilter == null) {
/*  92 */       this.start = this.po.startState;
/*  93 */     } else if (this.po.startState == null && this.po.startFilter != null) {
/*  94 */       this.start = this.po.startFilter;
/*     */     } else {
/*  96 */       if (this.po.startState == null && this.po.startFilter == null && !this.po.useM0) {
/*  97 */         setOutput("start Filter and start state are not initialized !");
/*     */       }
/*  99 */       if (this.po.startState != null && this.po.startFilter != null && !this.po.useM0) {
/* 100 */         setOutput("start Filter and start state are both initialized don't know which to choose!");
/*     */       }
/* 102 */       cancel();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     this.nodeIndices = new RGNode[this.rg.verticesSize()];
/* 117 */     for (Iterator<RGNode> it = this.rg.verticesIterator(); it.hasNext(); ) {
/* 118 */       RGNode n = it.next();
/* 119 */       this.nodeIndices[n.getStateNumber() - 1] = n;
/*     */     } 
/* 121 */     DebugCounter.inc("TimedShortestPathConstruction: Length of NodeIndices:" + this.nodeIndices.length);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 127 */       this.p = compute();
/* 128 */       this.po.setResultObject(this.p);
/* 129 */       this.p.setName(this.target.toString());
/* 130 */       this.po.pathRGraph = getGraph();
/*     */       
/* 132 */       if (this.p == null || this.p.first() == null) {
/* 133 */         System.out.printf("TimedShortestPathConstruction output:\n" + getOutput() + "\n", new Object[0]);
/*     */       }
/* 135 */     } catch (Exception e) {
/* 136 */       cancel();
/* 137 */       cleanup();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path compute() throws Exception {
/* 154 */     Collection<RGNode> startNodes = new Vector();
/*     */     
/* 156 */     this.progress = 0.0D;
/* 157 */     if (!checkStatus()) { cleanup(); return null; }
/*     */     
/* 159 */     System.out.printf("TimedShortestPath ....compute() start.class = " + this.start.getClass().getName() + "\n", new Object[0]);
/* 160 */     if (this.start instanceof State) {
/* 161 */       if (this.rg.getNode(this.start) == null) {
/* 162 */         startNodes = this.rg.getSatisfyingStates((State)this.start);
/* 163 */         if (startNodes.isEmpty()) {
/* 164 */           setOutput("startNodes are empty, no satisfying states");
/* 165 */           return new Path();
/*     */         } 
/*     */       } else {
/* 168 */         startNodes.add(this.rg.getNode(this.start));
/*     */       } 
/* 170 */     } else if (this.start instanceof Filter) {
/* 171 */       startNodes = this.rg.getSatisfyingStates((Filter)this.start);
/* 172 */       if (startNodes.isEmpty()) {
/* 173 */         setOutput("startNodes are empty, no satisfying states");
/* 174 */         return new Path();
/*     */       } 
/*     */     } 
/*     */     
/* 178 */     System.out.printf("TimedShortestPath ....compute() target.class = " + this.target.getClass().getName() + "\n", new Object[0]);
/* 179 */     Collection<RGNode> targetNodes = new Vector();
/* 180 */     if (this.target instanceof State) {
/* 181 */       if (this.rg.getNode(this.target) == null) {
/* 182 */         targetNodes = this.rg.getSatisfyingStates((State)this.target);
/* 183 */         if (targetNodes.isEmpty()) {
/* 184 */           return new Path();
/*     */         }
/*     */       } else {
/* 187 */         targetNodes.add(this.rg.getNode(this.target));
/*     */       } 
/* 189 */     } else if (this.target instanceof Filter) {
/* 190 */       targetNodes = this.rg.getSatisfyingStates((Filter)this.target);
/* 191 */       if (targetNodes.isEmpty()) {
/* 192 */         setOutput("targetNodes are empty, no satisfying states");
/* 193 */         return new Path();
/*     */       } 
/*     */     } 
/* 196 */     System.out.printf("Collection startNodes = " + startNodes + "\n", new Object[0]);
/* 197 */     System.out.printf("Collection targetNodes = " + targetNodes + "\n", new Object[0]);
/* 198 */     Iterator<RGNode> it = startNodes.iterator();
/*     */     
/* 200 */     this.p = new Path();
/* 201 */     this.progress = 0.0D;
/* 202 */     if (!checkStatus()) { cleanup(); return null; }
/*     */     
/* 204 */     HashMap<Integer, Predecessor> predecessors = new HashMap<>();
/* 205 */     this.noEndNode = true;
/* 206 */     while (it.hasNext()) {
/*     */ 
/*     */       
/* 209 */       if (targetNodes.contains(it.next())) {
/* 210 */         this.noEndNode = false;
/*     */       }
/*     */     } 
/*     */     
/* 214 */     System.out.printf("noEndNodes= " + this.noEndNode + "\n", new Object[0]);
/* 215 */     if (this.noEndNode) {
/* 216 */       MinimalWay w = extendedDijkstra(startNodes, targetNodes, predecessors);
/* 217 */       if (w != null) {
/*     */         
/* 219 */         this.startNode = w.startNode;
/* 220 */         this.endNode = w.endNode;
/*     */       } 
/* 222 */       System.out.printf("minimal way " + w + "\n", new Object[0]);
/*     */     } else {
/*     */       
/* 225 */       MinimalWay w = new MinimalWay();
/* 226 */       RGraph tempRG = floydWarshall(startNodes, targetNodes, predecessors, w);
/* 227 */       if (tempRG == null) {
/* 228 */         return new Path();
/*     */       }
/* 230 */       this.rg = tempRG;
/*     */ 
/*     */       
/* 233 */       this.startNode = w.startNode;
/* 234 */       this.endNode = w.endNode;
/*     */     } 
/* 236 */     System.out.printf("startNode = " + this.startNode + " endNOde " + this.endNode + " \n", new Object[0]);
/* 237 */     if (!checkStatus()) { cleanup(); return null; }
/* 238 */      DebugCounter.inc("timedshortestPathConstruction\ncompute Path with : start" + this.startNode + " endnode " + this.endNode + "\n predecessors " + predecessors);
/* 239 */     this.p = computePath(this.startNode, this.endNode, predecessors);
/* 240 */     if (this.p == null) {
/* 241 */       System.out.printf("no path computed\n", new Object[0]);
/* 242 */     } else if (this.p.first() == null) {
/* 243 */       System.out.printf("empty path \n", new Object[0]);
/*     */     } 
/*     */     
/* 246 */     if (!checkStatus()) { cleanup(); return null; }
/* 247 */      this.progress = 100.0D;
/* 248 */     return this.p;
/*     */   }
/*     */ 
/*     */   
/*     */   public void evaluate() {
/* 253 */     if (this.p == null) {
/* 254 */       System.out.printf("no path to evaluate\n" + getOutput(), new Object[0]);
/*     */       return;
/*     */     } 
/* 257 */     if (this.p.first() != null && this.startNode != null && this.endNode != null) {
/*     */       
/* 259 */       setOutput("\nshortest Path from " + this.pn.toLabel(this.startNode.getMarking()));
/* 260 */       setOutput("to " + this.pn.toLabel(this.endNode.getMarking()));
/* 261 */       if (this.noEndNode) {
/* 262 */         setOutput("computed by Dijkstra");
/*     */       } else {
/* 264 */         setOutput("computed by Floyd-Warshall");
/*     */       } 
/* 266 */       setOutput("distance of the computed path: " + this.p.getWayLength());
/* 267 */       setOutput("sequence length of the computed path: " + this.p.length());
/* 268 */       setOutput("computed path: " + this.p.getString());
/* 269 */       setOutput(this.p.toParikhVector(this.pn));
/*     */     } else {
/* 271 */       setOutput("marking not reached");
/*     */     } 
/* 273 */     super.evaluate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RGraph floydWarshall(Collection startNodes, Collection targetNodes, HashMap<Integer, Predecessor> predecessors, MinimalWay w) {
/* 282 */     int numberOfNodes = this.nodeIndices.length;
/* 283 */     int nodeChange = (int)(1.0D / Math.cbrt(numberOfNodes) * 500.0D);
/* 284 */     double oneProg = 5.0D / numberOfNodes;
/* 285 */     double prog = this.progress;
/* 286 */     int[][] weightMatrix = new int[this.nodeIndices.length][this.nodeIndices.length];
/* 287 */     for (int i = 0; i < weightMatrix.length; i++) {
/*     */       
/* 289 */       prog += oneProg;
/* 290 */       if ((int)prog >= (int)this.progress + 1) {
/*     */         
/* 292 */         this.progress = (int)prog;
/* 293 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/* 295 */       }  for (int m = 0; m < weightMatrix.length; m++) {
/*     */         
/* 297 */         RGEdge e = getMinimalEdge(this.nodeIndices[i], this.nodeIndices[m]);
/* 298 */         if (e != null) {
/* 299 */           weightMatrix[i][m] = e.getDistance();
/*     */         } else {
/* 301 */           weightMatrix[i][m] = INFINITY;
/*     */         } 
/* 303 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/*     */       } 
/* 306 */     }  int[][] wayMatrix = new int[this.nodeIndices.length][this.nodeIndices.length];
/* 307 */     oneProg = 5.0D / numberOfNodes;
/* 308 */     this.progress = 5.0D;
/* 309 */     prog = this.progress;
/* 310 */     this.progress = 5.0D;
/* 311 */     if (!checkStatus()) { cleanup(); return null; }
/*     */     
/* 313 */     for (int j = 0; j < wayMatrix.length; j++) {
/*     */       
/* 315 */       prog += oneProg;
/* 316 */       if ((int)prog >= (int)this.progress + 1)
/*     */       {
/* 318 */         this.progress = (int)prog;
/*     */       }
/*     */       
/* 321 */       for (int m = 0; m < wayMatrix.length; m++) {
/*     */         
/* 323 */         if (weightMatrix[j][m] == INFINITY) {
/* 324 */           wayMatrix[j][m] = -1;
/*     */         } else {
/* 326 */           wayMatrix[j][m] = j;
/*     */         } 
/* 328 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/*     */       } 
/* 331 */     }  oneProg = 50.0D / numberOfNodes;
/* 332 */     this.progress = 10.0D;
/* 333 */     prog = this.progress;
/* 334 */     if (!checkStatus()) { cleanup(); return null; }
/*     */ 
/*     */     
/* 337 */     for (int k = 0; k < this.nodeIndices.length; k++) {
/*     */       
/* 339 */       prog += oneProg;
/* 340 */       this.countStates++;
/* 341 */       if ((int)prog >= (int)this.progress + 1 || this.countStates % nodeChange == 0) {
/*     */         
/* 343 */         this.progress = (int)prog;
/* 344 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/* 346 */       }  for (int m = 0; m < this.nodeIndices.length; m++) {
/* 347 */         for (int n = 0; n < this.nodeIndices.length; n++) {
/*     */           
/* 349 */           if (weightMatrix[m][k] < INFINITY && weightMatrix[k][n] < INFINITY && weightMatrix[m][n] > weightMatrix[m][k] + weightMatrix[k][n]) {
/*     */             
/* 351 */             weightMatrix[m][n] = weightMatrix[m][k] + weightMatrix[k][n];
/* 352 */             wayMatrix[m][n] = wayMatrix[k][n];
/*     */           } 
/* 354 */           if (!checkStatus()) { cleanup(); return null; }
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/* 359 */     this.progress = 60.0D;
/* 360 */     if (!checkStatus()) { cleanup(); return null; }
/*     */     
/* 362 */     MinimalWay minWay = searchMinimal(startNodes, targetNodes, weightMatrix, wayMatrix, this.nodeIndices);
/* 363 */     if (minWay == null) {
/* 364 */       return null;
/*     */     }
/* 366 */     RGNode start = minWay.startNode;
/* 367 */     RGNode end = minWay.endNode;
/* 368 */     w.startNode = minWay.startNode;
/* 369 */     w.endNode = minWay.endNode;
/* 370 */     w.length = minWay.length;
/* 371 */     HashMap<Integer, Predecessor> pred = getPredecessors(start, end, wayMatrix, this.nodeIndices);
/* 372 */     if (pred != null)
/*     */     {
/* 374 */       for (Integer s : pred.keySet())
/*     */       {
/* 376 */         predecessors.put(s, pred.get(s));
/*     */       }
/*     */     }
/* 379 */     return computeRG(w.startNode, wayMatrix, this.nodeIndices);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RGraph dijkstra(RGNode startNode, HashMap<Integer, Predecessor> predecessors, HashMap<Integer, Integer> wayLengths, int numberOfStartNodes) {
/* 388 */     RGraph newRG = new RGraph(this.pn);
/*     */     
/* 390 */     Vector<Integer> nodesNotInRG = new Vector<>();
/* 391 */     for (Iterator<RGNode> it = this.rg.verticesIterator(); it.hasNext(); ) {
/* 392 */       RGNode n = it.next();
/* 393 */       wayLengths.put(Integer.valueOf(n.getStateNumber()), Integer.valueOf(INFINITY));
/* 394 */       nodesNotInRG.add(new Integer(n.getStateNumber()));
/*     */     } 
/* 396 */     int numberOfNodes = nodesNotInRG.size();
/* 397 */     double oneProg = 60.0D / numberOfStartNodes * numberOfNodes;
/* 398 */     double prog = this.progress;
/* 399 */     newRG.addNode(new RGNode(this.pn, startNode.getMarking()));
/* 400 */     newRG.getNode(startNode.getMarking()).setStateNumber(startNode.getStateNumber());
/* 401 */     nodesNotInRG.remove(new Integer(startNode.getStateNumber()));
/* 402 */     wayLengths.put(Integer.valueOf(startNode.getStateNumber()), Integer.valueOf(0));
/* 403 */     RGNode currentState = startNode;
/* 404 */     int i = 0;
/* 405 */     while (newRG.getNumberOfNodes() <= this.rg.getNumberOfNodes() && !nodesNotInRG.isEmpty() && currentState != null && checkStatus()) {
/*     */       
/* 407 */       for (Integer m : nodesNotInRG) {
/*     */         
/* 409 */         RGEdge edge = getMinimalEdge(currentState, getNodeByNumber(m.intValue()));
/* 410 */         if (edge != null)
/*     */         {
/* 412 */           if (((Integer)wayLengths.get(Integer.valueOf(currentState.getStateNumber()))).intValue() < INFINITY && edge.getDistance() < INFINITY && ((Integer)wayLengths.get(m)).intValue() > ((Integer)wayLengths.get(Integer.valueOf(currentState.getStateNumber()))).intValue() + edge.getDistance()) {
/*     */             
/* 414 */             wayLengths.put(Integer.valueOf(getNodeByNumber(m.intValue()).getStateNumber()), Integer.valueOf(((Integer)wayLengths.get(Integer.valueOf(currentState.getStateNumber()))).intValue() + edge.getDistance()));
/* 415 */             predecessors.put(m, new Predecessor(currentState, edge));
/*     */           } 
/*     */         }
/*     */       } 
/* 419 */       currentState = searchMinimal(wayLengths, nodesNotInRG);
/*     */ 
/*     */       
/* 422 */       newRG.addNode(new RGNode(this.pn, currentState.getMarking()));
/* 423 */       newRG.getNode(currentState.getMarking()).setStateNumber(currentState.getStateNumber());
/* 424 */       nodesNotInRG.remove(new Integer(currentState.getStateNumber()));
/* 425 */       this.countStates++;
/* 426 */       prog += oneProg;
/* 427 */       if ((int)prog >= (int)this.progress + 1 || this.countStates % 500 == 0) {
/*     */         
/* 429 */         this.progress = (int)prog;
/* 430 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/*     */       } 
/* 433 */     }  oneProg = 30.0D / numberOfStartNodes * numberOfNodes;
/* 434 */     Set<Integer> keys = predecessors.keySet();
/* 435 */     for (Integer key : keys) {
/*     */       
/* 437 */       if (!checkStatus()) { cleanup(); return null; }
/* 438 */        Predecessor tempPre = predecessors.get(key);
/* 439 */       RGNode from = newRG.getNode(tempPre.state.getMarking());
/* 440 */       RGNode to = newRG.getNode(getNodeByNumber(key.intValue()).getMarking());
/* 441 */       if (from != null && to != null)
/*     */       {
/* 443 */         newRG.addEdgeUniversal(from, to, tempPre.edge.copy());
/*     */       }
/* 445 */       prog += oneProg;
/* 446 */       if ((int)prog >= (int)this.progress + 1) {
/*     */         
/* 448 */         this.progress = (int)prog;
/* 449 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/*     */       } 
/* 452 */     }  this.progress = prog;
/* 453 */     return newRG;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MinimalWay extendedDijkstra(Collection startNodes, Collection targetNodes, HashMap<Integer, Predecessor> predecessors) {
/* 463 */     int numberOfStartNodes = startNodes.size();
/* 464 */     MinimalWay currentMinimalWay = null;
/* 465 */     RGraph currentRG = null;
/* 466 */     for (Iterator<RGNode> it = startNodes.iterator(); it.hasNext(); ) {
/*     */       
/* 468 */       HashMap<Integer, Predecessor> preds = new HashMap<>();
/* 469 */       HashMap<Integer, Integer> wayLengths = new HashMap<>();
/* 470 */       RGNode startNode = it.next();
/* 471 */       RGraph tempRG = dijkstra(startNode, preds, wayLengths, numberOfStartNodes);
/* 472 */       if (!checkStatus()) { cleanup(); return null; }
/* 473 */        Vector<Integer> tempTargetVector = new Vector<>();
/* 474 */       Iterator<RGNode> it1 = targetNodes.iterator();
/* 475 */       while (it1.hasNext()) {
/* 476 */         tempTargetVector.add(new Integer(((RGNode)it1.next()).getStateNumber()));
/*     */       }
/* 478 */       MinimalWay w = searchMinimalReachable(startNode, wayLengths, tempTargetVector, preds);
/* 479 */       if (w != null && (currentMinimalWay == null || w.length < currentMinimalWay.length || (w.length == currentMinimalWay.length && w.sequenceLength < currentMinimalWay.sequenceLength))) {
/*     */         
/* 481 */         currentMinimalWay = w;
/* 482 */         currentRG = tempRG;
/* 483 */         predecessors.clear();
/* 484 */         for (Integer key : preds.keySet()) {
/* 485 */           predecessors.put(key, preds.get(key));
/*     */         }
/*     */       } 
/*     */     } 
/* 489 */     if (currentRG != null) {
/* 490 */       this.rg = currentRG;
/*     */     }
/*     */     
/* 493 */     return currentMinimalWay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<Integer, Predecessor> getPredecessors(RGNode startNode, RGNode endNode, int[][] wayMatrix, RGNode[] nodeIndices) {
/* 503 */     HashMap<Integer, Predecessor> predecessors = new HashMap<>();
/* 504 */     int start = getIndexByNode(startNode);
/* 505 */     int i = getIndexByNode(endNode);
/* 506 */     boolean endFound = false;
/* 507 */     while (!endFound) {
/*     */       
/* 509 */       RGEdge e = null;
/* 510 */       if (wayMatrix[start][i] >= 0) {
/*     */         
/* 512 */         e = getMinimalEdge(nodeIndices[wayMatrix[start][i]], nodeIndices[i]);
/* 513 */         if (e != null) {
/* 514 */           predecessors.put(Integer.valueOf(nodeIndices[i].getStateNumber()), new Predecessor(this.rg.getNode(nodeIndices[wayMatrix[start][i]].getMarking()), e));
/*     */         }
/* 516 */         i = wayMatrix[start][i];
/*     */       }
/*     */       else {
/*     */         
/* 520 */         predecessors = null;
/*     */         break;
/*     */       } 
/* 523 */       endFound = (nodeIndices[i].getStateNumber() == startNode.getStateNumber());
/*     */     } 
/* 525 */     return predecessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Path computePath(RGNode startNode, RGNode endNode, HashMap<Integer, Predecessor> predecessors) {
/* 534 */     if (startNode == null || endNode == null || predecessors.isEmpty()) {
/* 535 */       return new Path();
/*     */     }
/* 537 */     Path p = new Path(startNode, this.rg);
/* 538 */     Vector<Predecessor> preVector = new Vector<>();
/*     */     
/* 540 */     RGNode currentState = endNode;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 545 */     if (!checkStatus()) { cleanup(); return null; }
/*     */     
/*     */     while (true) {
/* 548 */       preVector.add(0, predecessors.get(Integer.valueOf(currentState.getStateNumber())));
/* 549 */       currentState = ((Predecessor)predecessors.get(Integer.valueOf(currentState.getStateNumber()))).state;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 555 */       if (currentState.getStateNumber() == startNode.getStateNumber()) {
/* 556 */         this.progress = 95.0D;
/* 557 */         if (!checkStatus()) { cleanup(); return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 562 */         for (Predecessor pre : preVector) {
/*     */           
/* 564 */           RGNode tempNode = pre.state;
/* 565 */           if (tempNode == null)
/*     */           {
/* 567 */             return new Path();
/*     */           }
/* 569 */           p.checkAndAddNode(tempNode, pre.edge);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 577 */         p.checkAndAddNode(endNode, null);
/* 578 */         return p;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RGraph computeRG(RGNode startNode, int[][] wayMatrix, RGNode[] nodeIndices) {
/* 587 */     RGraph newRG = new RGraph(this.pn);
/* 588 */     Vector<Integer> nodesInRG = new Vector<>();
/* 589 */     for (Iterator<RGNode> it = this.rg.verticesIterator(); it.hasNext(); ) {
/* 590 */       RGNode n = it.next();
/* 591 */       nodesInRG.add(new Integer(n.getStateNumber()));
/*     */     } 
/* 593 */     int numberOfNodes = nodesInRG.size();
/* 594 */     int i = 0;
/* 595 */     double oneProg = 30.0D / numberOfNodes;
/*     */     
/* 597 */     this.progress = 60.0D;
/* 598 */     double prog = this.progress;
/* 599 */     if (!checkStatus()) { cleanup(); return null; }
/*     */     
/* 601 */     for (Integer node : nodesInRG) {
/*     */       
/* 603 */       if (!checkStatus()) { cleanup(); return null; }
/* 604 */        prog += oneProg;
/* 605 */       if ((int)prog >= (int)this.progress + 1) {
/*     */         
/* 607 */         this.progress = (int)prog;
/* 608 */         if (!checkStatus()) { cleanup(); return null; }
/*     */       
/* 610 */       }  HashMap<Integer, Predecessor> predecessors = getPredecessors(startNode, getNodeByNumber(node.intValue()), wayMatrix, nodeIndices);
/* 611 */       if (predecessors != null && !predecessors.isEmpty()) {
/*     */         RGNode nodeBefore; RGEdge edgeToAdd; Iterator<Predecessor> iterator;
/* 613 */         Vector<Predecessor> preVector = new Vector<>();
/* 614 */         RGNode currentState = getNodeByNumber(node.intValue());
/*     */         while (true)
/* 616 */         { preVector.add(0, predecessors.get(Integer.valueOf(currentState.getStateNumber())));
/* 617 */           currentState = ((Predecessor)predecessors.get(Integer.valueOf(currentState.getStateNumber()))).state;
/* 618 */           if (currentState.getStateNumber() == startNode.getStateNumber())
/* 619 */           { preVector.add(new Predecessor(getNodeByNumber(node.intValue()), null));
/* 620 */             nodeBefore = null;
/* 621 */             edgeToAdd = null;
/* 622 */             iterator = preVector.iterator(); break; }  }  while (iterator.hasNext()) { Predecessor pre = iterator.next();
/*     */           
/* 624 */           RGNode newNode = newRG.getNode(pre.state.getMarking());
/* 625 */           if (newNode == null) {
/*     */             
/* 627 */             newNode = new RGNode(this.pn, pre.state.getMarking());
/* 628 */             newRG.addNode(newNode);
/* 629 */             newNode.setStateNumber(pre.state.getStateNumber());
/*     */           } 
/* 631 */           if (nodeBefore != null && edgeToAdd != null && !newRG.edgeExists(nodeBefore, newNode, edgeToAdd))
/*     */           {
/* 633 */             newRG.addEdgeUniversal(nodeBefore, newNode, edgeToAdd.copy());
/*     */           }
/* 635 */           edgeToAdd = pre.edge;
/* 636 */           nodeBefore = newNode; }
/*     */       
/*     */       } 
/*     */     } 
/* 640 */     this.progress = 90.0D;
/* 641 */     if (!checkStatus()) { cleanup(); return null; }
/* 642 */      return newRG;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MinimalWay searchMinimal(Collection startNodes, Collection targetNodes, int[][] weightMatrix, int[][] wayMatrix, RGNode[] nodeIndices) {
/* 652 */     Vector<MinimalWay> wayWeights = new Vector<>();
/* 653 */     MinimalWay shortestWay = null;
/* 654 */     for (int i = 0; i < weightMatrix.length; i++) {
/* 655 */       for (int j = 0; j < weightMatrix.length; j++) {
/*     */         
/* 657 */         if (startNodes.contains(nodeIndices[i]) && targetNodes.contains(nodeIndices[j]))
/*     */         {
/* 659 */           if (weightMatrix[i][j] < INFINITY) {
/*     */             
/* 661 */             MinimalWay newWay = new MinimalWay(nodeIndices[i], nodeIndices[j], weightMatrix[i][j]);
/* 662 */             int count = 0;
/* 663 */             while (count < wayWeights.size() && ((MinimalWay)wayWeights.get(count)).length < newWay.length) {
/* 664 */               count++;
/*     */             }
/* 666 */             if (count == wayWeights.size()) {
/* 667 */               wayWeights.add(newWay);
/*     */             } else {
/* 669 */               wayWeights.add(count, newWay);
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 675 */     if (wayWeights.size() > 0) {
/*     */       
/* 677 */       int smallestWayWeight = ((MinimalWay)wayWeights.firstElement()).length;
/* 678 */       int count = 0;
/* 679 */       while (count < wayWeights.size() && ((MinimalWay)wayWeights.get(count)).length == smallestWayWeight) {
/* 680 */         count++;
/*     */       }
/* 682 */       for (int s = count + 1; s < wayWeights.size(); s++) {
/* 683 */         wayWeights.remove(s);
/*     */       }
/* 685 */       shortestWay = searchForMinimalSequence(wayWeights, wayMatrix, nodeIndices);
/*     */     } 
/* 687 */     return shortestWay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getIndexByNode(RGNode node) {
/* 698 */     if (this.nodeIndices[node.getStateNumber() - 1] == node) {
/* 699 */       return node.getStateNumber() - 1;
/*     */     }
/* 701 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private RGNode getNodeByNumber(int nodeNumber) {
/* 707 */     return this.nodeIndices[nodeNumber - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RGNode searchMinimal(HashMap<Integer, Integer> wayLengths, Vector<Integer> nodesNotInRG) {
/* 716 */     RGNode currentState = null;
/* 717 */     Integer currentWeight = Integer.valueOf(INFINITY);
/* 718 */     for (Integer key : nodesNotInRG) {
/*     */       
/* 720 */       if (currentState == null || currentWeight.intValue() >= ((Integer)wayLengths.get(key)).intValue()) {
/*     */         
/* 722 */         currentState = getNodeByNumber(key.intValue());
/* 723 */         currentWeight = wayLengths.get(key);
/*     */       } 
/*     */     } 
/* 726 */     return currentState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MinimalWay searchMinimalReachable(RGNode startNode, HashMap<Integer, Integer> wayLengths, Vector<Integer> targetNodes, HashMap<Integer, Predecessor> predecessors) {
/* 736 */     MinimalWay currentWay = null;
/* 737 */     Vector<MinimalWay> wayWeights = new Vector<>();
/* 738 */     for (Integer key : targetNodes) {
/*     */       
/* 740 */       if (((Integer)wayLengths.get(key)).intValue() < INFINITY) {
/*     */         
/* 742 */         MinimalWay newWay = new MinimalWay(startNode, getNodeByNumber(key.intValue()), ((Integer)wayLengths.get(key)).intValue());
/* 743 */         int count = 0;
/* 744 */         while (count < wayWeights.size() && ((MinimalWay)wayWeights.get(count)).length < newWay.length) {
/* 745 */           count++;
/*     */         }
/* 747 */         if (count == wayWeights.size()) {
/* 748 */           wayWeights.add(newWay); continue;
/*     */         } 
/* 750 */         wayWeights.add(count, newWay);
/*     */       } 
/*     */     } 
/*     */     
/* 754 */     while (wayWeights.size() > 0 && currentWay == null) {
/*     */       
/* 756 */       Vector<MinimalWay> smallestWayWeights = new Vector<>();
/* 757 */       int smallestWayWeight = ((MinimalWay)wayWeights.firstElement()).length;
/* 758 */       int count = 0;
/* 759 */       while (count < wayWeights.size() && ((MinimalWay)wayWeights.get(count)).length == smallestWayWeight) {
/* 760 */         count++;
/*     */       }
/* 762 */       for (int s = 0; s < count; s++)
/*     */       {
/* 764 */         smallestWayWeights.add(wayWeights.get(s));
/*     */       }
/* 766 */       wayWeights.removeAll(smallestWayWeights);
/* 767 */       currentWay = searchForMinimalSequence(smallestWayWeights, predecessors);
/*     */     } 
/* 769 */     return currentWay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MinimalWay searchForMinimalSequence(Vector<MinimalWay> ways, int[][] wayMatrix, RGNode[] nodeIndices) {
/* 778 */     int currentSize = INFINITY;
/* 779 */     MinimalWay smallestWay = null;
/* 780 */     for (MinimalWay w : ways) {
/*     */       
/* 782 */       int size = getPredecessors(w.startNode, w.endNode, wayMatrix, nodeIndices).size() - 1;
/* 783 */       if (size < currentSize && size < this.maximumLength) {
/*     */         
/* 785 */         smallestWay = w;
/* 786 */         currentSize = size;
/*     */       } 
/*     */     } 
/* 789 */     return smallestWay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MinimalWay searchForMinimalSequence(Vector<MinimalWay> ways, HashMap<Integer, Predecessor> predecessors) {
/* 798 */     int currentSize = INFINITY;
/* 799 */     MinimalWay smallestWay = null;
/* 800 */     for (MinimalWay w : ways) {
/*     */       
/* 802 */       w.sequenceLength = getSequenceLength(w, predecessors);
/* 803 */       if (w.sequenceLength >= 0 && w.sequenceLength < currentSize && w.sequenceLength <= this.maximumLength) {
/*     */         
/* 805 */         currentSize = w.sequenceLength;
/* 806 */         smallestWay = w;
/*     */       } 
/*     */     } 
/* 809 */     return smallestWay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getSequenceLength(MinimalWay way, HashMap<Integer, Predecessor> predecessors) {
/* 817 */     int size = 0;
/*     */ 
/*     */     
/* 820 */     RGNode currentState = way.endNode;
/*     */     while (true) {
/* 822 */       size++;
/* 823 */       currentState = ((Predecessor)predecessors.get(Integer.valueOf(currentState.getStateNumber()))).state;
/* 824 */       if (currentState.getStateNumber() == way.startNode.getStateNumber()) {
/* 825 */         return size;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RGEdge getMinimalEdge(RGNode out, RGNode in) {
/* 837 */     RGEdge edge = null;
/* 838 */     if (out != null && in != null) {
/*     */       
/* 840 */       RGEdge outEdge = out.out();
/* 841 */       while (outEdge != null) {
/*     */         
/* 843 */         if (outEdge.getDestinationNode().getStateNumber() == in.getStateNumber())
/*     */         {
/* 845 */           if (edge == null || edge.getDistance() > outEdge.getDistance()) {
/* 846 */             edge = outEdge;
/*     */           }
/*     */         }
/* 849 */         outEdge = outEdge.next();
/*     */       } 
/*     */     } 
/*     */     
/* 853 */     return edge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RGraph getGraph() {
/* 860 */     return this.rg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void printMatrix(int[][] matrix, String name) {
/* 867 */     System.out.println("Matrix " + name + ": ");
/* 868 */     for (int i = 0; i < matrix.length; i++) {
/*     */       
/* 870 */       for (int j = 0; j < matrix.length; j++) {
/*     */         
/* 872 */         if (matrix[i][j] == INFINITY) {
/* 873 */           System.out.print("oo ");
/*     */         } else {
/* 875 */           System.out.print(matrix[i][j] + " ");
/*     */         } 
/*     */       } 
/* 878 */       System.out.println();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isShortestPathSearch() {
/* 883 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private class MinimalWay
/*     */   {
/*     */     RGNode startNode;
/*     */     
/*     */     RGNode endNode;
/*     */     
/*     */     int length;
/*     */     
/*     */     int sequenceLength;
/*     */ 
/*     */     
/*     */     public MinimalWay() {}
/*     */ 
/*     */     
/*     */     public MinimalWay(RGNode startNode, RGNode endNode, int length) {
/* 902 */       this.startNode = startNode;
/* 903 */       this.endNode = endNode;
/* 904 */       this.length = length;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class Predecessor
/*     */   {
/*     */     RGNode state;
/*     */     
/*     */     RGEdge edge;
/*     */     
/*     */     public Predecessor(RGNode state, RGEdge edge) {
/* 916 */       this.edge = edge;
/* 917 */       this.state = state;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/path/TimedShortestPathConstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */