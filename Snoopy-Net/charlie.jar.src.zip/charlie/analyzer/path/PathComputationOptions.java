/*     */ package charlie.analyzer.path;
/*     */ 
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.analyzer.rg.ConstructionOptions;
/*     */ import charlie.filter.Filter;
/*     */ import charlie.pn.State;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGraph;
/*     */ import java.io.File;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathComputationOptions
/*     */   extends OptionSet
/*     */ {
/*     */   public static final byte SHORTEST_PATH = 0;
/*     */   public static final byte LONGEST_PATH = 1;
/*     */   public static final byte SUBMARKING = 0;
/*     */   public static final byte FULLMARKING = 1;
/*  21 */   public RGraph rGraph = null;
/*  22 */   public RGraph pathRGraph = null;
/*  23 */   public File sourceFilterFile = null;
/*  24 */   public File targetFilterFile = null;
/*  25 */   public Filter startFilter = null;
/*  26 */   public Filter targetFilter = null;
/*  27 */   public State startState = null;
/*  28 */   public State targetState = null;
/*     */   public boolean useM0 = true;
/*     */   public boolean considerRG = false;
/*  31 */   public byte computationType = 0;
/*  32 */   public byte markingType = 0;
/*  33 */   public int maxPathLength = -1;
/*  34 */   public int maximalConsideredStates = -1;
/*  35 */   public File exportFileMarkingSequence = null;
/*  36 */   public File exportFileTransitionSequence = null;
/*  37 */   public File exportFileParikhVector = null;
/*     */ 
/*     */ 
/*     */   
/*     */   public PathComputationOptions() {
/*  42 */     OptionSet[] t = { (OptionSet)new ConstructionOptions() };
/*  43 */     this.beforeSet = t;
/*  44 */     this.objectToAnalyze = new RGraph();
/*  45 */     this.resultObject = new Path();
/*     */   }
/*     */   
/*     */   public Properties getAsProperties() {
/*  49 */     return new Properties();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initByProperties(Properties props) {
/*  54 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHtmlInfo() {
/*  59 */     StringBuilder sb = new StringBuilder();
/*  60 */     sb.append("<html><p>path computation options</p><table>");
/*  61 */     sb.append("<tr><th>option name</th><th>value</th><tr>");
/*  62 */     sb.append("<tr><td width=\"150px\">");
/*  63 */     sb.append("computation type:");
/*  64 */     sb.append("</td><td width = \"60px\">");
/*  65 */     if (this.computationType == 0) {
/*  66 */       sb.append("shortest path");
/*  67 */     } else if (this.computationType == 1) {
/*  68 */       sb.append("longest path");
/*     */     } else {
/*  70 */       sb.append("unkown construction type ERROR");
/*  71 */     }  sb.append("</td></tr>");
/*     */     
/*  73 */     sb.append("<tr><td>");
/*  74 */     sb.append("maximal path length");
/*  75 */     sb.append("</td><td>");
/*  76 */     sb.append(Integer.toString(this.maxPathLength));
/*  77 */     sb.append("</td></tr>");
/*     */     
/*  79 */     sb.append("<tr><td>");
/*  80 */     sb.append("maximal number of considered states");
/*  81 */     sb.append("</td><td>");
/*  82 */     sb.append(Integer.toString(this.maximalConsideredStates));
/*  83 */     sb.append("</td></tr>");
/*     */ 
/*     */     
/*  86 */     sb.append("<tr><td>");
/*  87 */     sb.append("source filter");
/*  88 */     sb.append("</td><td>");
/*  89 */     if (this.useM0) {
/*  90 */       sb.append("using m0 as initial marking");
/*  91 */     } else if (this.sourceFilterFile != null) {
/*  92 */       sb.append("file: " + this.sourceFilterFile.getName());
/*     */     } else {
/*  94 */       sb.append("no source file specified");
/*  95 */     }  sb.append("</td></tr>");
/*  96 */     if (this.targetState != null) {
/*  97 */       sb.append("<tr><td>");
/*  98 */       sb.append("start state: ");
/*  99 */       sb.append("</td><td>");
/* 100 */       sb.append(this.startState.toString());
/* 101 */       sb.append("</td></tr>");
/*     */     } 
/* 103 */     sb.append("<tr><td>");
/* 104 */     sb.append("consider rg");
/*     */     
/* 106 */     sb.append("</td><td>");
/* 107 */     if (this.considerRG) {
/* 108 */       sb.append("yes");
/*     */     } else {
/* 110 */       sb.append("no");
/* 111 */     }  sb.append("</td></tr>");
/*     */ 
/*     */     
/* 114 */     sb.append("<tr><td>");
/* 115 */     sb.append("target filter:");
/* 116 */     sb.append("</td><td>");
/* 117 */     if (this.targetFilterFile != null) {
/* 118 */       sb.append("file: " + this.targetFilterFile.getName());
/*     */     } else {
/* 120 */       sb.append("file: not specified");
/* 121 */     }  sb.append("</td></tr>");
/* 122 */     if (this.targetState != null) {
/* 123 */       sb.append("<tr><td>");
/* 124 */       sb.append("target state: ");
/* 125 */       sb.append("</td><td>");
/* 126 */       sb.append(this.targetState.toString());
/* 127 */       sb.append("</td></tr>");
/*     */     } 
/* 129 */     sb.append("<tr><td>");
/* 130 */     sb.append("target filter is");
/* 131 */     sb.append("</td><td>");
/* 132 */     if (this.markingType == 0) {
/* 133 */       sb.append("sub marking");
/* 134 */     } else if (this.markingType == 1) {
/* 135 */       sb.append("full marking");
/*     */     } else {
/* 137 */       sb.append("unknown marking type ERROR");
/* 138 */     }  sb.append("</td></tr>");
/*     */     
/* 140 */     if (this.exportFileMarkingSequence != null) {
/* 141 */       sb.append("<tr><td>");
/* 142 */       sb.append("export path to file:");
/* 143 */       sb.append("</td><td>");
/* 144 */       sb.append("file: " + this.exportFileMarkingSequence.getName());
/* 145 */       sb.append("</td></tr>");
/*     */     } 
/*     */     
/* 148 */     sb.append("</table></html>");
/* 149 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 153 */     StringBuilder sb = new StringBuilder();
/* 154 */     sb.append("path computation options:\n");
/* 155 */     sb.append("computation type:\t");
/* 156 */     if (this.computationType == 0) {
/* 157 */       sb.append("shortest path\n");
/* 158 */     } else if (this.computationType == 1) {
/* 159 */       sb.append("longest path\n");
/*     */     } else {
/* 161 */       sb.append("unkown construction type ERROR\n");
/* 162 */     }  sb.append("maximal path length:\t");
/* 163 */     sb.append(Integer.toString(this.maxPathLength) + "\n");
/* 164 */     sb.append("maximal number of considered states:\t");
/* 165 */     sb.append(Integer.toString(this.maximalConsideredStates) + "\n");
/* 166 */     sb.append("source filter:\t");
/* 167 */     if (this.useM0) {
/* 168 */       sb.append("using m0 as initial marking\n");
/* 169 */     } else if (this.sourceFilterFile != null) {
/* 170 */       sb.append("file: " + this.sourceFilterFile.getName() + "\n");
/* 171 */     } else if (this.startState != null) {
/* 172 */       sb.append("state: " + this.startState.toString() + "\n");
/*     */     } else {
/* 174 */       sb.append("no source file/state-id specified\n");
/* 175 */     }  sb.append("consider rg:\t");
/*     */     
/* 177 */     if (this.considerRG) {
/* 178 */       sb.append("yes\n");
/*     */     } else {
/* 180 */       sb.append("no\n");
/* 181 */     }  sb.append("target filter:\t");
/* 182 */     if (this.targetFilterFile != null) {
/* 183 */       sb.append("file: " + this.targetFilterFile.getName() + "\n");
/* 184 */     } else if (this.targetState != null) {
/* 185 */       sb.append("state: " + this.targetState.toString() + "\n");
/*     */     } else {
/* 187 */       sb.append("file/state-id: not specified\n");
/* 188 */     }  sb.append("target filter is:\t");
/*     */     
/* 190 */     if (this.markingType == 0) {
/* 191 */       sb.append("sub marking\n");
/* 192 */     } else if (this.markingType == 1) {
/* 193 */       sb.append("full marking\n");
/*     */     } else {
/* 195 */       sb.append("unknown marking type ERROR\n");
/*     */     } 
/* 197 */     if (this.exportFileMarkingSequence != null) {
/* 198 */       sb.append("export path to file:\t");
/* 199 */       sb.append("file: " + this.exportFileMarkingSequence.getName() + "\n");
/*     */     } 
/* 201 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public boolean initializeByString(String parameters) {
/* 205 */     String tempString = "";
/* 206 */     this.sourceFilterFile = getValue(parameters, "source", this.sourceFilterFile);
/* 207 */     if (this.sourceFilterFile == null) {
/* 208 */       this.useM0 = true;
/*     */     } else {
/* 210 */       this.useM0 = false;
/* 211 */     }  this.considerRG = getValue(parameters, "considerRG", this.considerRG);
/* 212 */     this.targetFilterFile = getValue(parameters, "target", this.targetFilterFile);
/* 213 */     if (this.targetFilterFile == null) {
/* 214 */       System.out.println("PathComputationOptions, could not initialize option target! This option must be provided!\nPlease specifiy a file that contains a targetfilter or check provided path!");
/* 215 */       System.out.println(getHelpString());
/* 216 */       return false;
/*     */     } 
/*     */     
/* 219 */     tempString = getValue(parameters, "compute", tempString);
/* 220 */     if (tempString.equals("shortest")) {
/* 221 */       this.computationType = 0;
/* 222 */     } else if (tempString.equals("longest")) {
/* 223 */       this.computationType = 1;
/*     */     } else {
/* 225 */       System.out.println("PathComputationOptions, could not initialize option compute! The compute option must be set!\n Allowed values are: shortest, longest\nprovided value :" + tempString);
/* 226 */       System.out.println(getHelpString());
/* 227 */       return false;
/*     */     } 
/* 229 */     tempString = "";
/* 230 */     tempString = getValue(parameters, "targetMarkingType", tempString);
/* 231 */     if (tempString.equals("sub")) {
/* 232 */       this.markingType = 0;
/* 233 */     } else if (tempString.equals("full")) {
/* 234 */       this.markingType = 1;
/* 235 */     } else if (tempString.equals("")) {
/* 236 */       System.out.println("PathComputationOptions, option targetMarkingType was not specified using standard value (target marking is sub marking)");
/*     */     } else {
/* 238 */       System.out.println("PathComputationOptions, option targetMarkingType was not correctly\nAllowed values are: sub, full\n\nprovided value : " + tempString);
/* 239 */       System.out.println(getHelpString());
/* 240 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 244 */     this.maxPathLength = getValue(parameters, "maxPathLength", this.maxPathLength);
/* 245 */     this.maximalConsideredStates = getValue(parameters, "maxConsidered", this.maximalConsideredStates);
/* 246 */     this.exportFileMarkingSequence = getValue(parameters, "export", this.exportFileMarkingSequence);
/* 247 */     return true;
/*     */   }
/*     */   
/*     */   public static String getHelpString() {
/* 251 */     StringBuilder sb = new StringBuilder();
/* 252 */     sb.append("\nPath computation options\n");
/* 253 */     sb.append("-------------------------\n");
/* 254 */     sb.append("use --analyze=Path or --analyze=path to invoke Path analysis\n");
/* 255 */     String formatString = "%30s | %-30s\n";
/* 256 */     sb.append(String.format(formatString, new Object[] { "option-name", "allowed values" }));
/* 257 */     sb.append(String.format(formatString, new Object[] { "--source", "source file path" }));
/* 258 */     sb.append(String.format(formatString, new Object[] { "", "The file must contain a filter" }));
/* 259 */     sb.append(String.format(formatString, new Object[] { "", "m0 is used if not specified" }));
/* 260 */     sb.append(String.format(formatString, new Object[] { "--considerRG", "0 / 1 " }));
/* 261 */     sb.append(String.format(formatString, new Object[] { "", "if the first satisfying state of" }));
/* 262 */     sb.append(String.format(formatString, new Object[] { "", "the rg, should be used" }));
/* 263 */     sb.append(String.format(formatString, new Object[] { "--target", "target file path" }));
/* 264 */     sb.append(String.format(formatString, new Object[] { "", "The file must contain a filter" }));
/* 265 */     sb.append(String.format(formatString, new Object[] { "--compute", "shortest / longest" }));
/* 266 */     sb.append(String.format(formatString, new Object[] { "", "which path to compute" }));
/* 267 */     sb.append(String.format(formatString, new Object[] { "--targetMarkingType", "sub / full" }));
/* 268 */     sb.append(String.format(formatString, new Object[] { "", "if target filter is a set (sub)" }));
/* 269 */     sb.append(String.format(formatString, new Object[] { "", "of single (full) state" }));
/* 270 */     sb.append(String.format(formatString, new Object[] { "--maxPathLength", " integer value >0" }));
/* 271 */     sb.append(String.format(formatString, new Object[] { "", "defines maximal length of path" }));
/* 272 */     sb.append(String.format(formatString, new Object[] { "--maxConsidered", " integer value >0" }));
/* 273 */     sb.append(String.format(formatString, new Object[] { "", "defines max number of considered" }));
/* 274 */     sb.append(String.format(formatString, new Object[] { "", "states" }));
/* 275 */     sb.append(String.format(formatString, new Object[] { "--export", "export file path" }));
/* 276 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/path/PathComputationOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */