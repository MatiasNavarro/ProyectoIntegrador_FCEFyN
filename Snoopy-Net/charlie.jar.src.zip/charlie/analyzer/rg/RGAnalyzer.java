/*     */ package charlie.analyzer.rg;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.ds.Stack;
/*     */ import charlie.pn.LookUpTable;
/*     */ import charlie.pn.Options;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Result;
/*     */ import charlie.pn.State;
/*     */ import charlie.pn.Transition;
/*     */ import charlie.pn.TraversationDataTable;
/*     */ import charlie.rg.RGEdge;
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import charlie.rg.SCC;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RGAnalyzer
/*     */   extends Analyzer
/*     */ {
/*  31 */   private static final Log LOG = LogFactory.getLog(RGAnalyzer.class);
/*     */ 
/*     */   
/*     */   public ConstructionOptions co;
/*     */   
/*  36 */   protected RGraph rg = null;
/*  37 */   protected PlaceTransitionNet pn = null;
/*     */   
/*     */   public RGAnalyzer() {
/*  40 */     setUpdateInterval(1000L);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  45 */     return "RG Analyzer";
/*     */   }
/*     */   
/*     */   public static boolean register() {
/*  49 */     RGAnalyzer ra = new RGAnalyzer();
/*  50 */     boolean value = AnalyzerManagerFactory.getAnalyzerManager().register(ra, new PlaceTransitionNet(), new RGraph());
/*     */     
/*  52 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Analyzer getNewInstance(OptionSet options) {
/*  57 */     if (options instanceof ConstructionOptions) {
/*  58 */       ConstructionOptions o = (ConstructionOptions)options;
/*  59 */       if (o.rule == 1)
/*  60 */         return new MaximumConstruction(); 
/*  61 */       if (o.rule == 0) {
/*  62 */         return new SimpleConstruction();
/*     */       }
/*  64 */       return null;
/*     */     } 
/*     */     
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeInfoStrings() {
/*  72 */     int count = 6;
/*  73 */     this.infoStrings = new String[count];
/*  74 */     Arrays.fill((Object[])this.infoStrings, "");
/*  75 */     this.infoStrings[0] = "edges:";
/*  76 */     if (this.rg != null) {
/*  77 */       this.infoStrings[1] = Integer.toString(this.rg.getNumberOfEdges());
/*     */     }
/*  79 */     this.infoStrings[2] = "states";
/*  80 */     if (this.rg != null) {
/*  81 */       this.infoStrings[3] = Integer.toString(this.rg.getNumberOfNodes());
/*     */     }
/*  83 */     this.infoStrings[4] = "scc:";
/*  84 */     if (this.rg != null) {
/*  85 */       this.infoStrings[5] = Integer.toString(this.rg.getNumberOfScc());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluate() {
/*  96 */     if (this.rg != null) {
/*  97 */       evalRG();
/*     */       
/*  99 */       if (LOG.isDebugEnabled()) {
/* 100 */         LOG.debug("RGAnalyzer: options.getResultObject()" + this.options.getResultObject().toString() + "\n");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze() {
/* 112 */     DebugCounter.inc("RGAnalyzer.analyze() should not be called directly !");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 121 */     super.reset();
/* 122 */     this.rg = null;
/* 123 */     this.co = null;
/* 124 */     this.pn = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLive(boolean b) {
/* 132 */     boolean deadTransitions = this.pn.getDeadTransitions().isEmpty();
/* 133 */     addResult(23, new Result(Boolean.valueOf(deadTransitions)));
/* 134 */     if (!b) {
/* 135 */       addOutput("transition not live:");
/* 136 */       addOutput(this.pn.getNotLiveTransitions().toString());
/*     */     } 
/*     */     
/* 139 */     if (deadTransitions) {
/* 140 */       addOutput("transition dead at m0:");
/* 141 */       addOutput(this.pn.getDeadTransitions().toString());
/*     */     } 
/*     */     
/* 144 */     addResult(24, new Result(Boolean.valueOf(b)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void evalRG() {
/* 153 */     this.rg.determineTerminalSCCs();
/*     */     
/* 155 */     if (this.rg.complete && this.pn.isBounded()) {
/* 156 */       isLive();
/*     */       
/* 158 */       addResult(25, new Result(rev()));
/* 159 */       addResult(21, new Result(isPersistent()));
/* 160 */       addResult(20, new Result(isS()));
/* 161 */       addResult(22, new Result(dst()));
/*     */     } 
/*     */ 
/*     */     
/* 165 */     String graph = "reachability graph";
/* 166 */     if (!this.pn.isBounded()) {
/* 167 */       graph = "coverability graph";
/* 168 */       addResult(20, new Result(new Boolean(false)));
/* 169 */       addResult(19, new Result(new Boolean(false)));
/*     */     } else {
/* 171 */       addResult(19, Integer.valueOf(this.rg.getMaxTokenCount()));
/*     */     } 
/*     */     
/* 174 */     addOutput("-- " + graph + " constructed in " + getFormatedDuration() + "--");
/* 175 */     this.rg.setConstructionTime(getFormatedDuration());
/* 176 */     addOutput(this.options.toString());
/* 177 */     if (!this.rg.complete) {
/* 178 */       addOutput(graph + " is not complete");
/*     */     }
/*     */     
/* 181 */     addOutput("states: " + this.rg.size());
/*     */     
/* 183 */     addOutput("bound: " + this.rg.getMaxTokenCount());
/*     */     
/* 185 */     addOutput("edges: " + this.rg.edges());
/*     */     
/* 187 */     addOutput("#scc: " + this.rg.getNumberOfScc());
/* 188 */     addOutput("#terminal scc: " + this.rg.getNumbersOfFinalScc().size());
/*     */   }
/*     */   
/*     */   public Boolean isLive() {
/* 192 */     boolean ret = true;
/* 193 */     if (this.rg == null) {
/* 194 */       return null;
/*     */     }
/*     */     
/* 197 */     Collection<Integer> finalScc = this.rg.getNumbersOfFinalScc();
/* 198 */     for (Iterator<Transition> it = this.pn.getTransitions().iterator(); it.hasNext(); ) {
/* 199 */       Transition t = it.next();
/* 200 */       for (Iterator<Integer> it2 = finalScc.iterator(); it2.hasNext(); ) {
/* 201 */         int s = ((Integer)it2.next()).intValue();
/* 202 */         if (!t.firesInScc(s)) {
/* 203 */           this.pn.getNotLiveTransitions().insert(t.getId());
/* 204 */           ret = false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 209 */     setLive(ret);
/* 210 */     if (ret) {
/* 211 */       addOutput("the net is live");
/*     */     } else {
/* 213 */       addOutput("the net is not live");
/*     */     } 
/* 215 */     return new Boolean(ret);
/*     */   }
/*     */   
/*     */   public Result isB() {
/* 219 */     return getResult(19);
/*     */   }
/*     */   
/*     */   public Result isL() {
/* 223 */     return getResult(24);
/*     */   }
/*     */   
/*     */   public Result isSafe() {
/* 227 */     return getResult(20);
/*     */   }
/*     */   
/*     */   public Boolean isS() {
/* 231 */     if (Options.printResults == 1) {
/* 232 */       System.out.println("RGA: return isS\n");
/*     */     }
/*     */     
/* 235 */     if (this.rg == null) {
/* 236 */       return null;
/*     */     }
/*     */     
/* 239 */     boolean v = this.rg.safe();
/* 240 */     if (v) {
/* 241 */       addOutput("the net is safe");
/*     */     } else {
/* 243 */       addOutput("the net is not safe");
/*     */     } 
/* 245 */     return Boolean.valueOf(v);
/*     */   }
/*     */   
/*     */   public Integer mostToken() {
/* 249 */     if (this.rg == null) {
/* 250 */       return null;
/*     */     }
/*     */     
/* 253 */     return new Integer(LookUpTable.mostToken());
/*     */   }
/*     */   
/*     */   public Result isReversible() {
/* 257 */     return getResult(25);
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean rev() {
/* 262 */     Boolean b = new Boolean((this.rg.getScc().size() == 1 && (this.rg.size() != 1 || this.rg.edges() > 0)));
/* 263 */     DebugCounter.inc("RGAnalyzer.rev(): " + b.toString() + " getScc().size()==1 :" + this.rg.getScc().size() + " rg.size()!=1 :" + this.rg.size() + " rg.edges()>0 :" + this.rg.edges());
/*     */     
/* 265 */     return b;
/*     */   }
/*     */   
/*     */   public Integer dst() {
/* 269 */     if (this.rg == null) {
/* 270 */       return null;
/*     */     }
/*     */     
/* 273 */     Integer i = new Integer(this.rg.getDeadStates().size());
/* 274 */     addOutput("number of dead states: " + i.toString());
/* 275 */     addOutput("filter for dead states: ");
/* 276 */     int j = 0;
/* 277 */     for (Iterator<RGNode> it = this.rg.getDeadStates().iterator(); it.hasNext(); ) {
/* 278 */       j++;
/* 279 */       addOutput("dead state " + j + ": " + this.pn.toFilter(((RGNode)it.next()).getMarking().getPlaceMarking()));
/*     */     } 
/* 281 */     return i;
/*     */   }
/*     */   
/*     */   public Result hasDeadStates() {
/* 285 */     if (Options.printResults == 1) {
/* 286 */       System.out.println("RGA: return  hasDeadStates\n");
/*     */     }
/* 288 */     return getResult(22);
/*     */   }
/*     */   
/*     */   public Result isDCF() {
/* 292 */     return getResult(21);
/*     */   }
/*     */   
/*     */   public Boolean isPersistent() {
/* 296 */     if (this.rg == null) {
/* 297 */       return null;
/*     */     }
/* 299 */     Boolean b = new Boolean(this.rg.isDCFree());
/* 300 */     if (b.booleanValue()) {
/* 301 */       addOutput("is persistent");
/*     */     } else {
/* 303 */       addOutput("is not persistent");
/*     */     } 
/*     */     
/* 306 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {}
/*     */ 
/*     */   
/*     */   public void computeTimedProperties() {
/* 315 */     RGNode[] nodeField = new RGNode[this.rg.verticesSize()];
/* 316 */     if (this.rg.first.getStateNumber() > 0) {
/* 317 */       while (this.rg.getNumberOfScc() > 0) {
/* 318 */         this.rg.decScc();
/*     */       }
/*     */       
/* 321 */       for (Iterator<RGNode> it = this.rg.iterator(); it.hasNext(); ) {
/* 322 */         RGNode node = it.next();
/* 323 */         node.sccNumber = -1;
/* 324 */         node.setStateNumber(0);
/*     */       } 
/*     */     } 
/*     */     
/* 328 */     int fieldPointer = 0;
/* 329 */     this.rg.getScc().clear();
/* 330 */     Stack<RGEdge> transitions = new Stack();
/* 331 */     TraversationDataTable tdt = new TraversationDataTable();
/*     */     
/* 333 */     boolean notfinished = true;
/* 334 */     RGNode n = this.rg.getFirst();
/* 335 */     nodeField[fieldPointer++] = n;
/*     */     
/* 337 */     Stack<StackEntry> st = new Stack();
/* 338 */     int count = 0;
/*     */ 
/*     */     
/*     */     do {
/* 342 */       if (n.sccNumber() < 0) {
/* 343 */         n.setSccNumber(0);
/* 344 */         if (!checkStatus()) {
/* 345 */           cleanup();
/*     */           return;
/*     */         } 
/* 348 */         count++;
/* 349 */         n.setStateNumber(count);
/* 350 */         tdt.add(Integer.valueOf(n.getStateNumber()), count);
/* 351 */         n.transitions = 0;
/* 352 */         Vector<RGEdge> tEdges = n.getAllOutEdges();
/* 353 */         if (tEdges.size() == 0) {
/* 354 */           this.rg.addDeadState(n);
/*     */         }
/* 356 */         for (RGEdge te : tEdges) {
/* 357 */           transitions.push(te);
/* 358 */           n.transitions++;
/*     */         } 
/*     */       } 
/* 361 */       if (n.transitions > 0) {
/* 362 */         State m1 = null;
/* 363 */         RGEdge edge = (RGEdge)transitions.pop();
/* 364 */         n.transitions--;
/* 365 */         m1 = edge.getDestinationNode().getMarking();
/* 366 */         Transition[] transitionField = edge.getTransitions();
/*     */         
/* 368 */         if (transitionField != null) {
/* 369 */           for (int i = 0; i < transitionField.length; i++) {
/* 370 */             this.pn.removeDeadTransition(transitionField[i].getId());
/*     */           }
/*     */         }
/* 373 */         if (this.rg.isDCFree() && transitionField != null) {
/* 374 */           for (int i = 0; i < transitionField.length; i++) {
/* 375 */             Transition t = transitionField[i];
/* 376 */             if (this.rg.isDCFree() && !t.getConflicts().isEmpty()) {
/* 377 */               for (Iterator<Transition> con_it = t.getConflicts().iterator(); con_it.hasNext(); ) {
/* 378 */                 Transition con_t = con_it.next();
/* 379 */                 if (con_t.canFire(n.getMarking()) && 
/* 380 */                   !con_t.canFire(m1)) {
/* 381 */                   this.rg.setDCFree(false);
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           } 
/*     */         }
/*     */         
/* 390 */         RGNode q = this.rg.getNode(m1);
/* 391 */         if (q != null && q.getStateNumber() == 0) {
/* 392 */           st.push(new StackEntry(n, q));
/* 393 */           n = q;
/* 394 */           nodeField[fieldPointer++] = q;
/*     */         } else {
/* 396 */           if (q == null) {
/* 397 */             DebugCounter.inc("RGAnalyzer.computeTimedProperties(), rg.getNode(m1) == null\nm1 = " + m1 + " \n rg.getNode(m1)=" + this.rg.getNode(m1));
/*     */             break;
/*     */           } 
/* 400 */           if (!tdt.visited(Integer.valueOf(q.getStateNumber())))
/*     */           {
/*     */ 
/*     */             
/* 404 */             tdt.setMinLow(Integer.valueOf(n.getStateNumber()), tdt.low(Integer.valueOf(n.getStateNumber())), tdt.num(Integer.valueOf(q.getStateNumber()))); } 
/*     */         } 
/*     */       } else {
/* 407 */         if (tdt.low(Integer.valueOf(n.getStateNumber())) == tdt.num(Integer.valueOf(n.getStateNumber()))) {
/* 408 */           int sccNumber = this.rg.getScc().size();
/* 409 */           SCC scc = new SCC(sccNumber, n);
/* 410 */           for (int i = 0; i < fieldPointer; i++) {
/* 411 */             RGNode rn = nodeField[i];
/* 412 */             if (!checkStatus()) {
/* 413 */               cleanup();
/*     */               return;
/*     */             } 
/* 416 */             if (!tdt.visited(Integer.valueOf(rn.getStateNumber())) && tdt.num(Integer.valueOf(rn.getStateNumber())) >= tdt.num(Integer.valueOf(n.getStateNumber()))) {
/* 417 */               rn.setSccNumber(sccNumber);
/* 418 */               tdt.setVisited(Integer.valueOf(rn.getStateNumber()), true);
/* 419 */               scc.add(rn);
/*     */             } 
/*     */           } 
/* 422 */           this.rg.addScc(scc);
/* 423 */           this.rg.incScc();
/*     */         } 
/* 425 */         if (n == this.rg.getFirst()) {
/* 426 */           notfinished = false;
/*     */         }
/* 428 */         if (!st.isEmpty()) {
/* 429 */           StackEntry top = (StackEntry)st.pop();
/* 430 */           n = top.n;
/* 431 */           RGNode q = top.q;
/* 432 */           tdt.setMinLow(Integer.valueOf(n.getStateNumber()), tdt.low(Integer.valueOf(n.getStateNumber())), tdt.low(Integer.valueOf(q.getStateNumber())));
/*     */         } 
/*     */       } 
/* 435 */     } while (notfinished || !st.isEmpty());
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/rg/RGAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */