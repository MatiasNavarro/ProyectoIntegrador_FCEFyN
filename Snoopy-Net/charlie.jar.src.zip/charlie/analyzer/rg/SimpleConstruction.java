/*     */ package charlie.analyzer.rg;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.ds.Stack;
/*     */ import charlie.pn.ExceedsByteException;
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.SafetyException;
/*     */ import charlie.pn.SortedElementsFactory;
/*     */ import charlie.pn.State;
/*     */ import charlie.pn.Transition;
/*     */ import charlie.pn.TraversationDataTable;
/*     */ import charlie.rg.NoReduction;
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import charlie.rg.Reduction;
/*     */ import charlie.rg.SCC;
/*     */ import charlie.rg.StubbornReduction;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class SimpleConstruction extends RGAnalyzer {
/*     */   private long searchTime;
/*     */   
/*     */   public SimpleConstruction() {
/*  28 */     setUpdateInterval(100L);
/*     */   }
/*     */   long currentMillis;
/*     */   
/*     */   public String getName() {
/*  33 */     return "RGraph Simple Construction";
/*     */   }
/*     */ 
/*     */   
/*     */   public void analyze() {
/*  38 */     this.pn = (PlaceTransitionNet)this.options.getObjectToAnalyze();
/*  39 */     this.co = (ConstructionOptions)this.options;
/*  40 */     this.rg = new RGraph(this.pn);
/*  41 */     this.rg.setBackEdgeOption(this.co.backEdges);
/*     */     
/*  43 */     setOutput("reachability graph analyzer:\n");
/*  44 */     setOutput("computing rechability graph using simple  firing rule");
/*     */     try {
/*  46 */       this.rg = construct();
/*  47 */       this.options.setResultObject(this.rg);
/*  48 */     } catch (Exception e) {
/*  49 */       setOutput("simple construction failed due to safety exception.");
/*  50 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private RGraph construct() throws SafetyException {
/*     */     NoReduction noReduction;
/*  57 */     DebugCounter.inc("SimpleConstruction.construct() started!");
/*     */     
/*  59 */     if (this.co.stubborn) {
/*  60 */       StubbornReduction stubbornReduction = new StubbornReduction(this.pn);
/*     */     } else {
/*  62 */       noReduction = new NoReduction(this.pn);
/*     */     } 
/*  64 */     if (this.co.stateSpace) {
/*  65 */       return bfs(this.pn, (Reduction)noReduction);
/*     */     }
/*  67 */     RGraph ret = constructSimple(this.pn, (Reduction)noReduction);
/*  68 */     System.gc();
/*  69 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private RGraph bfs(PlaceTransitionNet pn, Reduction reduction) throws SafetyException {
/*     */     try {
/*  76 */       setOutput("bfs");
/*  77 */       HashSet<State> visited = new HashSet<>();
/*     */       
/*  79 */       Stack<State> newStates = new Stack();
/*  80 */       Marking marking = this.co.m0;
/*     */       
/*  82 */       RGraph rg = new RGraph(pn);
/*  83 */       newStates.push(marking);
/*  84 */       visited.add(marking);
/*  85 */       int count = 1;
/*  86 */       while (!newStates.isEmpty()) {
/*  87 */         System.out.print("\r" + count++);
/*  88 */         State state1 = (State)newStates.pop();
/*  89 */         State m1 = null;
/*  90 */         Collection<Transition> c = reduction.getTransitions(state1);
/*  91 */         for (Iterator<Transition> it = c.iterator(); it.hasNext(); ) {
/*  92 */           Transition t = it.next();
/*  93 */           if (!checkStatus()) {
/*  94 */             cleanup();
/*     */             
/*  96 */             return null;
/*     */           } 
/*     */           
/*  99 */           m1 = t.fire(state1);
/* 100 */           if (m1 != null && !visited.contains(m1)) {
/* 101 */             visited.add(m1);
/* 102 */             newStates.push(m1);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 107 */       return rg;
/* 108 */     } catch (ExceedsByteException be) {
/* 109 */       be.printStackTrace();
/*     */       
/* 111 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public RGraph constructSimple(PlaceTransitionNet pn, Reduction reduction) throws SafetyException {
/*     */     try {
/* 117 */       Stack<Transition> transitions = new Stack();
/* 118 */       this.searchTime = 0L;
/* 119 */       boolean aborted = false;
/* 120 */       TraversationDataTable tdt = new TraversationDataTable();
/* 121 */       Collection<Transition> conflicts = new HashSet<>();
/* 122 */       RGraph rgraph = new RGraph(pn);
/*     */ 
/*     */       
/* 125 */       boolean notfinished = true;
/* 126 */       HashSet<State> unBounded = new HashSet<>();
/* 127 */       RGNode n = new RGNode(pn, (State)this.co.m0);
/* 128 */       DebugCounter.inc("SimpleConstruction starting with m0 = " + this.co.m0 + " class = " + this.co.m0.getClass().getName());
/* 129 */       rgraph.addNode(n);
/* 130 */       RGNode first = n;
/*     */       
/* 132 */       short id = 0;
/* 133 */       Stack<StackEntry> st = new Stack();
/*     */       
/* 135 */       int count = 0;
/*     */       
/*     */       do {
/* 138 */         if (!checkStatus()) {
/* 139 */           cleanup();
/* 140 */           return null;
/*     */         } 
/* 142 */         if (n.sccNumber() < 0) {
/* 143 */           n.setSccNumber(0);
/* 144 */           count++;
/* 145 */           tdt.add(n, count);
/*     */           
/* 147 */           if (this.co.maxDepth != 0 && this.co.maxDepth == st.size()) {
/* 148 */             aborted = true;
/*     */           } else {
/* 150 */             n.transitions = reduction.getTransitions((State)n.getLabel(), transitions);
/*     */           } 
/*     */         } 
/*     */         
/* 154 */         if (n.transitions > 0) {
/* 155 */           State m1 = null;
/* 156 */           Marking marking = n.getLabel();
/*     */           
/* 158 */           Transition t = (Transition)transitions.pop();
/* 159 */           n.transitions--;
/* 160 */           id = t.getId();
/* 161 */           if (rgraph.isDCFree() && !t.getConflicts().isEmpty()) {
/* 162 */             conflicts.clear();
/* 163 */             for (Iterator<Transition> con_it = t.getConflicts().iterator(); con_it.hasNext(); ) {
/* 164 */               Transition con_t = con_it.next();
/* 165 */               if (con_t.canFire((State)marking)) {
/* 166 */                 conflicts.add(con_t);
/*     */               }
/*     */             } 
/*     */           } 
/* 170 */           m1 = t.fire((State)marking);
/* 171 */           while (m1 == null && n.transitions > 0) {
/* 172 */             n.transitions--;
/* 173 */             t = (Transition)transitions.pop();
/* 174 */             id = t.getId();
/* 175 */             m1 = t.fire((State)marking);
/*     */           } 
/*     */           
/* 178 */           if (m1 == null && n.transitions == 0) {
/*     */             continue;
/*     */           }
/*     */           
/* 182 */           pn.removeDeadTransition(id);
/* 183 */           if (!conflicts.isEmpty()) {
/* 184 */             for (Iterator<Transition> con_it = conflicts.iterator(); con_it.hasNext(); ) {
/* 185 */               Transition con_t = con_it.next();
/* 186 */               if (!con_t.canFire(m1)) {
/* 187 */                 rgraph.setDCFree(false);
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           }
/* 192 */           this.currentMillis = System.currentTimeMillis();
/* 193 */           RGNode q = rgraph.getNode(m1);
/* 194 */           this.searchTime += System.currentTimeMillis() - this.currentMillis;
/* 195 */           if (q == null) {
/* 196 */             if (this.co.boundedness) {
/* 197 */               Collection<? extends Number> c1 = null;
/* 198 */               c1 = m1.getPlaceMarking().covers(marking.getPlaceMarking());
/*     */               
/* 200 */               if (c1 == null) {
/* 201 */                 Iterator<StackEntry> stackIt = st.iterator();
/* 202 */                 while (stackIt.hasNext()) {
/* 203 */                   StackEntry ste = stackIt.next();
/*     */                   
/* 205 */                   c1 = m1.getPlaceMarking().covers(ste.n.getLabel().getPlaceMarking());
/*     */                   
/* 207 */                   if (c1 != null) {
/*     */                     break;
/*     */                   }
/*     */                 } 
/*     */               } 
/* 212 */               if (c1 != null) {
/*     */                 
/* 214 */                 pn.setUnbounded();
/* 215 */                 for (Iterator<? extends Number> itc = c1.iterator(); itc.hasNext(); ) {
/* 216 */                   int id2 = ((Number)itc.next()).shortValue();
/*     */                   try {
/* 218 */                     m1.addPlace(id2, 2147483647);
/* 219 */                     System.out.println(m1 + "-1-" + pn.toLabel(m1));
/* 220 */                   } catch (Exception e) {
/* 221 */                     SortedElementsFactory.safeMode(false);
/* 222 */                     SortedElementsFactory.byteMode(false);
/* 223 */                     m1 = m1.copy();
/* 224 */                     System.out.println(m1 + "-0-" + pn.toLabel(m1));
/* 225 */                     m1.addPlace(id2, 2147483647);
/* 226 */                     System.out.println(m1.getClass());
/* 227 */                     System.out.println(m1 + "-2-" + pn.toLabel(m1));
/*     */                   } 
/*     */                 } 
/* 230 */                 if (!unBounded.contains(m1)) {
/* 231 */                   unBounded.add(m1);
/*     */                 }
/* 233 */                 this.currentMillis = System.currentTimeMillis();
/* 234 */                 q = rgraph.getNode(m1);
/* 235 */                 this.searchTime += System.currentTimeMillis() - this.currentMillis;
/*     */               } 
/*     */             } 
/*     */             
/* 239 */             if (q == null) {
/* 240 */               q = new RGNode(pn, m1);
/* 241 */               rgraph.addNode(q);
/* 242 */               rgraph.addEdge(n, q, id, unBounded.contains(q.getLabel()));
/* 243 */               st.push(new StackEntry(n, q));
/* 244 */               n = q;
/*     */               continue;
/*     */             } 
/*     */           } 
/* 248 */           rgraph.addEdge(n, q, id, unBounded.contains(q.getLabel()));
/* 249 */           if (!tdt.visited(q))
/* 250 */             tdt.setMinLow(n, tdt.low(n), tdt.num(q)); 
/*     */           continue;
/*     */         } 
/* 253 */         if (n.outDegree == 0) {
/* 254 */           rgraph.addDeadState(n);
/*     */         }
/* 256 */         if (tdt.low(n) == tdt.num(n)) {
/* 257 */           int sccNumber = rgraph.getScc().size();
/* 258 */           SCC scc = new SCC(sccNumber, n);
/* 259 */           for (Iterator<RGNode> it_set = rgraph.iterator(); it_set.hasNext(); ) {
/* 260 */             RGNode rn = it_set.next();
/* 261 */             if (!tdt.visited(rn) && tdt
/* 262 */               .num(rn) >= tdt.num(n)) {
/* 263 */               rn.setSccNumber(sccNumber);
/* 264 */               tdt.setVisited(rn, true);
/* 265 */               scc.add(rn);
/*     */             } 
/*     */           } 
/* 268 */           rgraph.addScc(scc);
/* 269 */           rgraph.incScc();
/*     */         } 
/* 271 */         if (n.equals(first)) {
/* 272 */           notfinished = false;
/*     */         }
/* 274 */         if (!st.isEmpty()) {
/* 275 */           StackEntry top = (StackEntry)st.pop();
/* 276 */           n = top.n;
/* 277 */           RGNode q = top.q;
/* 278 */           tdt.setMinLow(n, tdt.low(n), tdt.low(q));
/*     */         }
/*     */       
/*     */       }
/* 282 */       while (notfinished || !st.isEmpty());
/*     */       
/* 284 */       if (!aborted && reduction instanceof NoReduction) {
/* 285 */         rgraph.complete = true;
/*     */       }
/* 287 */       return rgraph;
/* 288 */     } catch (ExceedsByteException be) {
/* 289 */       be.printStackTrace();
/*     */       
/* 291 */       return null;
/*     */     } 
/*     */   }
/*     */   public Analyzer getNewInstance() {
/* 295 */     return new SimpleConstruction();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/rg/SimpleConstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */