/*     */ package charlie.analyzer.rg;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.SafetyException;
/*     */ import charlie.rg.NoReduction;
/*     */ import charlie.rg.RGraph;
/*     */ import charlie.rg.Reduction;
/*     */ import charlie.rg.StubbornReduction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MaximumConstruction
/*     */   extends RGAnalyzer
/*     */ {
/*     */   public void analyze() {
/*  31 */     this.pn = (PlaceTransitionNet)this.options.getObjectToAnalyze();
/*  32 */     this.co = (ConstructionOptions)this.options;
/*     */     
/*  34 */     this.rg = new RGraph(this.pn);
/*  35 */     this.rg.setBackEdgeOption(this.co.backEdges);
/*     */     try {
/*  37 */       this.rg = construct();
/*  38 */       this.options.setResultObject(this.rg);
/*  39 */     } catch (Exception e) {
/*  40 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public MaximumConstruction() {
/*  45 */     setUpdateInterval(100L);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  50 */     return "RGraph Maximum Construction";
/*     */   }
/*     */   public RGraph construct() throws SafetyException {
/*     */     NoReduction noReduction;
/*  54 */     DebugCounter.inc("MaximumConstruction.construct() started!");
/*  55 */     setOutput("reachability graph analyzer:\n");
/*  56 */     setOutput("computing rechability graph using maximum firing rule");
/*     */     
/*  58 */     if (this.co.stubborn) {
/*  59 */       StubbornReduction stubbornReduction = new StubbornReduction(this.pn);
/*     */     } else {
/*  61 */       noReduction = new NoReduction(this.pn);
/*     */     } 
/*  63 */     this.rg = constructMax(this.pn, (Reduction)noReduction);
/*  64 */     return this.rg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RGraph constructMax(PlaceTransitionNet pn, Reduction reduction) throws SafetyException {
/*     */     // Byte code:
/*     */     //   0: new charlie/pn/TraversationDataTable
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_3
/*     */     //   8: new java/util/HashSet
/*     */     //   11: dup
/*     */     //   12: invokespecial <init> : ()V
/*     */     //   15: astore #4
/*     */     //   17: new java/util/HashSet
/*     */     //   20: dup
/*     */     //   21: invokespecial <init> : ()V
/*     */     //   24: astore #5
/*     */     //   26: iconst_0
/*     */     //   27: istore #6
/*     */     //   29: iconst_1
/*     */     //   30: istore #7
/*     */     //   32: iconst_0
/*     */     //   33: istore #8
/*     */     //   35: iconst_1
/*     */     //   36: istore #9
/*     */     //   38: new java/util/HashSet
/*     */     //   41: dup
/*     */     //   42: invokespecial <init> : ()V
/*     */     //   45: astore #10
/*     */     //   47: new charlie/rg/RGNode
/*     */     //   50: dup
/*     */     //   51: aload_1
/*     */     //   52: aload_0
/*     */     //   53: getfield co : Lcharlie/analyzer/rg/ConstructionOptions;
/*     */     //   56: getfield m0 : Lcharlie/pn/Marking;
/*     */     //   59: invokespecial <init> : (Lcharlie/pn/PlaceTransitionNet;Lcharlie/pn/State;)V
/*     */     //   62: astore #11
/*     */     //   64: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*     */     //   67: new java/lang/StringBuilder
/*     */     //   70: dup
/*     */     //   71: invokespecial <init> : ()V
/*     */     //   74: ldc '\\n'
/*     */     //   76: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   79: aload_0
/*     */     //   80: getfield co : Lcharlie/analyzer/rg/ConstructionOptions;
/*     */     //   83: getfield m0 : Lcharlie/pn/Marking;
/*     */     //   86: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   89: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   92: ldc ' '
/*     */     //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   97: aload_0
/*     */     //   98: getfield co : Lcharlie/analyzer/rg/ConstructionOptions;
/*     */     //   101: getfield m0 : Lcharlie/pn/Marking;
/*     */     //   104: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   107: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   110: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   113: aload_0
/*     */     //   114: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   117: aload #11
/*     */     //   119: invokevirtual addNode : (Lcharlie/rg/RGNode;)Lcharlie/rg/RGNode;
/*     */     //   122: pop
/*     */     //   123: aload #11
/*     */     //   125: astore #12
/*     */     //   127: invokestatic currentTimeMillis : ()J
/*     */     //   130: lstore #13
/*     */     //   132: iconst_0
/*     */     //   133: istore #15
/*     */     //   135: iconst_0
/*     */     //   136: anewarray java/lang/Short
/*     */     //   139: astore #16
/*     */     //   141: new java/util/Stack
/*     */     //   144: dup
/*     */     //   145: invokespecial <init> : ()V
/*     */     //   148: astore #17
/*     */     //   150: aconst_null
/*     */     //   151: astore #18
/*     */     //   153: aconst_null
/*     */     //   154: astore #19
/*     */     //   156: iconst_0
/*     */     //   157: istore #20
/*     */     //   159: aload #11
/*     */     //   161: invokevirtual sccNumber : ()I
/*     */     //   164: ifge -> 280
/*     */     //   167: aload #11
/*     */     //   169: iconst_0
/*     */     //   170: invokevirtual setSccNumber : (I)V
/*     */     //   173: aload_0
/*     */     //   174: invokevirtual checkStatus : ()Z
/*     */     //   177: ifne -> 186
/*     */     //   180: iconst_1
/*     */     //   181: istore #8
/*     */     //   183: goto -> 856
/*     */     //   186: iinc #6, 1
/*     */     //   189: aload_3
/*     */     //   190: aload #11
/*     */     //   192: iload #6
/*     */     //   194: invokevirtual add : (Ljava/lang/Object;I)V
/*     */     //   197: new java/util/HashSet
/*     */     //   200: dup
/*     */     //   201: invokespecial <init> : ()V
/*     */     //   204: astore #21
/*     */     //   206: aload_1
/*     */     //   207: aload #21
/*     */     //   209: aload #11
/*     */     //   211: invokevirtual getMarking : ()Lcharlie/pn/State;
/*     */     //   214: aload_2
/*     */     //   215: aload #11
/*     */     //   217: invokevirtual getLabel : ()Lcharlie/pn/Marking;
/*     */     //   220: invokeinterface getTransitions : (Lcharlie/pn/State;)Ljava/util/Collection;
/*     */     //   225: iconst_0
/*     */     //   226: invokestatic getIndependentSets : (Lcharlie/pn/PlaceTransitionNet;Ljava/util/Set;Lcharlie/pn/State;Ljava/util/Collection;I)V
/*     */     //   229: goto -> 239
/*     */     //   232: astore #22
/*     */     //   234: aload #22
/*     */     //   236: invokevirtual printStackTrace : ()V
/*     */     //   239: aload_0
/*     */     //   240: getfield co : Lcharlie/analyzer/rg/ConstructionOptions;
/*     */     //   243: getfield maxDepth : I
/*     */     //   246: ifeq -> 271
/*     */     //   249: aload_0
/*     */     //   250: getfield co : Lcharlie/analyzer/rg/ConstructionOptions;
/*     */     //   253: getfield maxDepth : I
/*     */     //   256: aload #17
/*     */     //   258: invokevirtual size : ()I
/*     */     //   261: if_icmpne -> 271
/*     */     //   264: aload #21
/*     */     //   266: invokeinterface clear : ()V
/*     */     //   271: aload #21
/*     */     //   273: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   278: astore #19
/*     */     //   280: aload #19
/*     */     //   282: invokeinterface hasNext : ()Z
/*     */     //   287: ifeq -> 632
/*     */     //   290: aconst_null
/*     */     //   291: astore #21
/*     */     //   293: aload #11
/*     */     //   295: invokevirtual getLabel : ()Lcharlie/pn/Marking;
/*     */     //   298: astore #22
/*     */     //   300: aload_0
/*     */     //   301: getfield co : Lcharlie/analyzer/rg/ConstructionOptions;
/*     */     //   304: getfield rule : I
/*     */     //   307: iconst_1
/*     */     //   308: if_icmpne -> 485
/*     */     //   311: aload #11
/*     */     //   313: invokevirtual getLabel : ()Lcharlie/pn/Marking;
/*     */     //   316: astore #21
/*     */     //   318: aload #19
/*     */     //   320: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   325: checkcast charlie/pn/TransitionSet
/*     */     //   328: astore #23
/*     */     //   330: aload #23
/*     */     //   332: invokevirtual size : ()I
/*     */     //   335: anewarray java/lang/Short
/*     */     //   338: astore #16
/*     */     //   340: iconst_0
/*     */     //   341: istore #24
/*     */     //   343: aload #23
/*     */     //   345: invokevirtual iterator : ()Ljava/util/Iterator;
/*     */     //   348: astore #25
/*     */     //   350: aload #25
/*     */     //   352: invokeinterface hasNext : ()Z
/*     */     //   357: ifeq -> 485
/*     */     //   360: aload #16
/*     */     //   362: iload #24
/*     */     //   364: new java/lang/Short
/*     */     //   367: dup
/*     */     //   368: aload #25
/*     */     //   370: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   375: checkcast java/lang/Integer
/*     */     //   378: invokevirtual shortValue : ()S
/*     */     //   381: invokespecial <init> : (S)V
/*     */     //   384: aastore
/*     */     //   385: iinc #24, 1
/*     */     //   388: aload_1
/*     */     //   389: invokevirtual getTransitions : ()Ljava/util/List;
/*     */     //   392: aload #16
/*     */     //   394: iload #24
/*     */     //   396: iconst_1
/*     */     //   397: isub
/*     */     //   398: aaload
/*     */     //   399: invokevirtual shortValue : ()S
/*     */     //   402: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   407: checkcast charlie/pn/Transition
/*     */     //   410: astore #26
/*     */     //   412: aload #26
/*     */     //   414: aload #21
/*     */     //   416: invokevirtual canFire : (Lcharlie/pn/State;)Z
/*     */     //   419: ifne -> 463
/*     */     //   422: getstatic java/lang/System.out : Ljava/io/PrintStream;
/*     */     //   425: new java/lang/StringBuilder
/*     */     //   428: dup
/*     */     //   429: invokespecial <init> : ()V
/*     */     //   432: aload #26
/*     */     //   434: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   437: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   440: ldc ' is disabled by '
/*     */     //   442: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   445: aload_0
/*     */     //   446: getfield pn : Lcharlie/pn/PlaceTransitionNet;
/*     */     //   449: aload #21
/*     */     //   451: invokevirtual toLabel : (Lcharlie/pn/State;)Ljava/lang/String;
/*     */     //   454: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   457: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   460: invokevirtual println : (Ljava/lang/String;)V
/*     */     //   463: aload #26
/*     */     //   465: aload #21
/*     */     //   467: invokevirtual fire : (Lcharlie/pn/State;)Lcharlie/pn/State;
/*     */     //   470: astore #21
/*     */     //   472: goto -> 482
/*     */     //   475: astore #27
/*     */     //   477: aload #27
/*     */     //   479: invokevirtual printStackTrace : ()V
/*     */     //   482: goto -> 350
/*     */     //   485: aload_0
/*     */     //   486: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   489: aload #21
/*     */     //   491: invokevirtual getNode : (Ljava/lang/Object;)Lcharlie/rg/RGNode;
/*     */     //   494: astore #23
/*     */     //   496: aload #23
/*     */     //   498: ifnonnull -> 588
/*     */     //   501: new charlie/rg/RGNode
/*     */     //   504: dup
/*     */     //   505: aload_1
/*     */     //   506: aload #21
/*     */     //   508: invokespecial <init> : (Lcharlie/pn/PlaceTransitionNet;Lcharlie/pn/State;)V
/*     */     //   511: astore #23
/*     */     //   513: aload_0
/*     */     //   514: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   517: aload #23
/*     */     //   519: invokevirtual addNode : (Lcharlie/rg/RGNode;)Lcharlie/rg/RGNode;
/*     */     //   522: pop
/*     */     //   523: aload_0
/*     */     //   524: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   527: aload #11
/*     */     //   529: aload #23
/*     */     //   531: aload #16
/*     */     //   533: invokevirtual addEdge : (Lcharlie/rg/RGNode;Lcharlie/rg/RGNode;[Ljava/lang/Short;)Lcharlie/rg/RGEdge;
/*     */     //   536: pop
/*     */     //   537: aload_0
/*     */     //   538: getfield co : Lcharlie/analyzer/rg/ConstructionOptions;
/*     */     //   541: getfield maxDepth : I
/*     */     //   544: ifeq -> 562
/*     */     //   547: aload_0
/*     */     //   548: getfield co : Lcharlie/analyzer/rg/ConstructionOptions;
/*     */     //   551: getfield maxDepth : I
/*     */     //   554: aload #17
/*     */     //   556: invokevirtual size : ()I
/*     */     //   559: if_icmple -> 856
/*     */     //   562: aload #17
/*     */     //   564: new charlie/analyzer/rg/StackEntry
/*     */     //   567: dup
/*     */     //   568: aload #11
/*     */     //   570: aload #19
/*     */     //   572: aload #23
/*     */     //   574: invokespecial <init> : (Lcharlie/rg/RGNode;Ljava/util/Iterator;Lcharlie/rg/RGNode;)V
/*     */     //   577: invokevirtual add : (Ljava/lang/Object;)Z
/*     */     //   580: pop
/*     */     //   581: aload #23
/*     */     //   583: astore #11
/*     */     //   585: goto -> 856
/*     */     //   588: aload_0
/*     */     //   589: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   592: aload #11
/*     */     //   594: aload #23
/*     */     //   596: aload #16
/*     */     //   598: invokevirtual addEdge : (Lcharlie/rg/RGNode;Lcharlie/rg/RGNode;[Ljava/lang/Short;)Lcharlie/rg/RGEdge;
/*     */     //   601: pop
/*     */     //   602: aload_3
/*     */     //   603: aload #23
/*     */     //   605: invokevirtual visited : (Ljava/lang/Object;)Z
/*     */     //   608: ifne -> 629
/*     */     //   611: aload_3
/*     */     //   612: aload #11
/*     */     //   614: aload_3
/*     */     //   615: aload #11
/*     */     //   617: invokevirtual low : (Ljava/lang/Object;)I
/*     */     //   620: aload_3
/*     */     //   621: aload #23
/*     */     //   623: invokevirtual num : (Ljava/lang/Object;)I
/*     */     //   626: invokevirtual setMinLow : (Ljava/lang/Object;II)V
/*     */     //   629: goto -> 856
/*     */     //   632: aload #11
/*     */     //   634: getfield outDegree : B
/*     */     //   637: ifne -> 649
/*     */     //   640: aload_0
/*     */     //   641: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   644: aload #11
/*     */     //   646: invokevirtual addDeadState : (Lcharlie/rg/RGNode;)V
/*     */     //   649: aload_3
/*     */     //   650: aload #11
/*     */     //   652: invokevirtual low : (Ljava/lang/Object;)I
/*     */     //   655: aload_3
/*     */     //   656: aload #11
/*     */     //   658: invokevirtual num : (Ljava/lang/Object;)I
/*     */     //   661: if_icmpne -> 786
/*     */     //   664: aload_0
/*     */     //   665: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   668: invokevirtual getScc : ()Ljava/util/Map;
/*     */     //   671: invokeinterface size : ()I
/*     */     //   676: istore #21
/*     */     //   678: new charlie/rg/SCC
/*     */     //   681: dup
/*     */     //   682: iload #21
/*     */     //   684: aload #11
/*     */     //   686: invokespecial <init> : (ILcharlie/rg/RGNode;)V
/*     */     //   689: astore #22
/*     */     //   691: aload_0
/*     */     //   692: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   695: invokevirtual iterator : ()Ljava/util/Iterator;
/*     */     //   698: astore #23
/*     */     //   700: aload #23
/*     */     //   702: invokeinterface hasNext : ()Z
/*     */     //   707: ifeq -> 770
/*     */     //   710: aload #23
/*     */     //   712: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   717: checkcast charlie/rg/RGNode
/*     */     //   720: astore #24
/*     */     //   722: aload_3
/*     */     //   723: aload #24
/*     */     //   725: invokevirtual visited : (Ljava/lang/Object;)Z
/*     */     //   728: ifne -> 767
/*     */     //   731: aload_3
/*     */     //   732: aload #24
/*     */     //   734: invokevirtual num : (Ljava/lang/Object;)I
/*     */     //   737: aload_3
/*     */     //   738: aload #11
/*     */     //   740: invokevirtual num : (Ljava/lang/Object;)I
/*     */     //   743: if_icmplt -> 767
/*     */     //   746: aload #24
/*     */     //   748: iload #21
/*     */     //   750: invokevirtual setSccNumber : (I)V
/*     */     //   753: aload_3
/*     */     //   754: aload #24
/*     */     //   756: iconst_1
/*     */     //   757: invokevirtual setVisited : (Ljava/lang/Object;Z)V
/*     */     //   760: aload #22
/*     */     //   762: aload #24
/*     */     //   764: invokevirtual add : (Lcharlie/rg/RGNode;)V
/*     */     //   767: goto -> 700
/*     */     //   770: aload_0
/*     */     //   771: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   774: aload #22
/*     */     //   776: invokevirtual addScc : (Lcharlie/rg/SCC;)V
/*     */     //   779: aload_0
/*     */     //   780: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   783: invokevirtual incScc : ()V
/*     */     //   786: aload #11
/*     */     //   788: aload #12
/*     */     //   790: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   793: ifeq -> 799
/*     */     //   796: iconst_0
/*     */     //   797: istore #7
/*     */     //   799: aload #17
/*     */     //   801: invokevirtual isEmpty : ()Z
/*     */     //   804: ifne -> 856
/*     */     //   807: aload #17
/*     */     //   809: invokevirtual pop : ()Ljava/lang/Object;
/*     */     //   812: checkcast charlie/analyzer/rg/StackEntry
/*     */     //   815: astore #21
/*     */     //   817: aload #21
/*     */     //   819: getfield n : Lcharlie/rg/RGNode;
/*     */     //   822: astore #11
/*     */     //   824: aload #21
/*     */     //   826: getfield q : Lcharlie/rg/RGNode;
/*     */     //   829: astore #22
/*     */     //   831: aload #21
/*     */     //   833: getfield it : Ljava/util/Iterator;
/*     */     //   836: astore #19
/*     */     //   838: aload_3
/*     */     //   839: aload #11
/*     */     //   841: aload_3
/*     */     //   842: aload #11
/*     */     //   844: invokevirtual low : (Ljava/lang/Object;)I
/*     */     //   847: aload_3
/*     */     //   848: aload #22
/*     */     //   850: invokevirtual low : (Ljava/lang/Object;)I
/*     */     //   853: invokevirtual setMinLow : (Ljava/lang/Object;II)V
/*     */     //   856: iload #8
/*     */     //   858: ifne -> 874
/*     */     //   861: iload #7
/*     */     //   863: ifne -> 159
/*     */     //   866: aload #17
/*     */     //   868: invokevirtual isEmpty : ()Z
/*     */     //   871: ifeq -> 159
/*     */     //   874: invokestatic gc : ()V
/*     */     //   877: aload_0
/*     */     //   878: getfield rg : Lcharlie/rg/RGraph;
/*     */     //   881: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #68	-> 0
/*     */     //   #70	-> 8
/*     */     //   #71	-> 17
/*     */     //   #72	-> 26
/*     */     //   #73	-> 29
/*     */     //   #74	-> 32
/*     */     //   #75	-> 35
/*     */     //   #76	-> 38
/*     */     //   #79	-> 47
/*     */     //   #80	-> 64
/*     */     //   #81	-> 113
/*     */     //   #82	-> 123
/*     */     //   #84	-> 127
/*     */     //   #85	-> 132
/*     */     //   #86	-> 135
/*     */     //   #87	-> 141
/*     */     //   #88	-> 150
/*     */     //   #89	-> 153
/*     */     //   #92	-> 156
/*     */     //   #97	-> 159
/*     */     //   #98	-> 167
/*     */     //   #105	-> 173
/*     */     //   #106	-> 180
/*     */     //   #107	-> 183
/*     */     //   #109	-> 186
/*     */     //   #110	-> 189
/*     */     //   #112	-> 197
/*     */     //   #114	-> 206
/*     */     //   #117	-> 229
/*     */     //   #115	-> 232
/*     */     //   #116	-> 234
/*     */     //   #120	-> 239
/*     */     //   #122	-> 264
/*     */     //   #124	-> 271
/*     */     //   #126	-> 280
/*     */     //   #127	-> 290
/*     */     //   #128	-> 293
/*     */     //   #130	-> 300
/*     */     //   #131	-> 311
/*     */     //   #133	-> 318
/*     */     //   #135	-> 330
/*     */     //   #136	-> 340
/*     */     //   #140	-> 343
/*     */     //   #141	-> 360
/*     */     //   #142	-> 385
/*     */     //   #143	-> 388
/*     */     //   #144	-> 412
/*     */     //   #145	-> 422
/*     */     //   #149	-> 463
/*     */     //   #152	-> 472
/*     */     //   #150	-> 475
/*     */     //   #151	-> 477
/*     */     //   #153	-> 482
/*     */     //   #185	-> 485
/*     */     //   #186	-> 496
/*     */     //   #188	-> 501
/*     */     //   #189	-> 513
/*     */     //   #190	-> 523
/*     */     //   #191	-> 537
/*     */     //   #193	-> 562
/*     */     //   #194	-> 581
/*     */     //   #199	-> 588
/*     */     //   #201	-> 602
/*     */     //   #202	-> 611
/*     */     //   #204	-> 629
/*     */     //   #205	-> 632
/*     */     //   #206	-> 640
/*     */     //   #208	-> 649
/*     */     //   #210	-> 664
/*     */     //   #211	-> 678
/*     */     //   #212	-> 691
/*     */     //   #213	-> 710
/*     */     //   #214	-> 722
/*     */     //   #215	-> 746
/*     */     //   #216	-> 753
/*     */     //   #217	-> 760
/*     */     //   #219	-> 767
/*     */     //   #220	-> 770
/*     */     //   #221	-> 779
/*     */     //   #224	-> 786
/*     */     //   #225	-> 796
/*     */     //   #227	-> 799
/*     */     //   #228	-> 807
/*     */     //   #229	-> 817
/*     */     //   #230	-> 824
/*     */     //   #231	-> 831
/*     */     //   #232	-> 838
/*     */     //   #235	-> 856
/*     */     //   #238	-> 874
/*     */     //   #239	-> 877
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   234	5	22	e	Ljava/lang/Exception;
/*     */     //   206	74	21	transitions	Ljava/util/Set;
/*     */     //   477	5	27	be	Lcharlie/pn/ExceedsByteException;
/*     */     //   412	70	26	t	Lcharlie/pn/Transition;
/*     */     //   350	135	25	itcur	Ljava/util/Iterator;
/*     */     //   330	155	23	cur	Lcharlie/pn/TransitionSet;
/*     */     //   343	142	24	i	I
/*     */     //   293	336	21	m1	Lcharlie/pn/State;
/*     */     //   300	329	22	m	Lcharlie/pn/Marking;
/*     */     //   496	133	23	q	Lcharlie/rg/RGNode;
/*     */     //   722	45	24	rn	Lcharlie/rg/RGNode;
/*     */     //   700	70	23	it_set	Ljava/util/Iterator;
/*     */     //   678	108	21	sccNumber	I
/*     */     //   691	95	22	scc	Lcharlie/rg/SCC;
/*     */     //   817	39	21	top	Lcharlie/analyzer/rg/StackEntry;
/*     */     //   831	25	22	q	Lcharlie/rg/RGNode;
/*     */     //   0	882	0	this	Lcharlie/analyzer/rg/MaximumConstruction;
/*     */     //   0	882	1	pn	Lcharlie/pn/PlaceTransitionNet;
/*     */     //   0	882	2	reduction	Lcharlie/rg/Reduction;
/*     */     //   8	874	3	tdt	Lcharlie/pn/TraversationDataTable;
/*     */     //   17	865	4	conflicts	Ljava/util/Collection;
/*     */     //   26	856	5	del	Ljava/util/Set;
/*     */     //   29	853	6	count	I
/*     */     //   32	850	7	notfinished	Z
/*     */     //   35	847	8	aborted	Z
/*     */     //   38	844	9	rgsize	I
/*     */     //   47	835	10	unBounded	Ljava/util/HashSet;
/*     */     //   64	818	11	n	Lcharlie/rg/RGNode;
/*     */     //   127	755	12	first	Lcharlie/rg/RGNode;
/*     */     //   132	750	13	currentTime	J
/*     */     //   135	747	15	id	S
/*     */     //   141	741	16	ids	[Ljava/lang/Short;
/*     */     //   150	732	17	st	Ljava/util/Stack;
/*     */     //   153	729	18	c	Ljava/util/Collection;
/*     */     //   156	726	19	it	Ljava/util/Iterator;
/*     */     //   159	723	20	unbound	Z
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   206	229	232	java/lang/Exception
/*     */     //   463	472	475	charlie/pn/ExceedsByteException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Analyzer getNewInstance() {
/* 243 */     return new MaximumConstruction();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/rg/MaximumConstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */