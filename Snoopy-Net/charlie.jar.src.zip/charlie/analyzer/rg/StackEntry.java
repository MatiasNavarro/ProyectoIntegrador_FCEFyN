/*    */ package charlie.analyzer.rg;
/*    */ 
/*    */ import charlie.rg.RGNode;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ class StackEntry
/*    */ {
/*    */   public RGNode n;
/*    */   Iterator it;
/*    */   public RGNode q;
/*    */   
/*    */   StackEntry(RGNode n, RGNode q) {
/* 13 */     this.n = n;
/* 14 */     this.q = q;
/*    */   }
/*    */   
/*    */   StackEntry(RGNode n, Iterator iterator, RGNode q) {
/* 18 */     this.n = n;
/* 19 */     this.it = iterator;
/* 20 */     this.q = q;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/rg/StackEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */