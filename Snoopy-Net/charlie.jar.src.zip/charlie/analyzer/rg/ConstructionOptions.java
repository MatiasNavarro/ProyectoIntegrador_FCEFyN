/*     */ package charlie.analyzer.rg;
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.StackTracePrinter;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.PetriNetReader;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.State;
/*     */ import java.io.File;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class ConstructionOptions extends OptionSet {
/*     */   public static final int SIMPLE = 0;
/*  15 */   public int rule = 0; public static final int MAXIMUM = 1;
/*     */   public boolean boundedness = true;
/*     */   public boolean stateSpace = false;
/*  18 */   public int maxDepth = 0;
/*     */   public boolean completed = true;
/*     */   public boolean stubborn = false;
/*     */   public boolean backEdges = true;
/*  22 */   public Marking m0 = null;
/*  23 */   public PlaceTransitionNet pn = null;
/*     */ 
/*     */   
/*     */   public String toString() {
/*  27 */     StringBuilder stb = new StringBuilder();
/*  28 */     stb.append("used construction options:\n");
/*  29 */     if (this.rule == 1) {
/*  30 */       stb.append("firing rule: maximum\n");
/*     */     } else {
/*  32 */       stb.append("firing rule: single\n");
/*     */     } 
/*  34 */     if (this.boundedness) {
/*  35 */       stb.append("boundedness check: yes\n");
/*     */     } else {
/*  37 */       stb.append("boundedness check: no\n");
/*     */     } 
/*  39 */     if (this.maxDepth != 0) {
/*  40 */       stb.append("maximal construction depth: " + this.maxDepth + "\n");
/*     */     } else {
/*  42 */       stb.append("maximal construction depth: none\n");
/*     */     } 
/*  44 */     if (this.stubborn) {
/*  45 */       stb.append("reduction: partial order (stubborn)\n");
/*     */     } else {
/*  47 */       stb.append("reduction: none\n");
/*     */     } 
/*  49 */     if (this.m0 != null) {
/*  50 */       stb.append("initial marking:" + this.pn.toLabel((State)this.m0) + "\n");
/*     */     }
/*     */     
/*  53 */     return stb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getAsProperties() {
/*  62 */     return new Properties();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initByProperties(Properties props) {
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHtmlInfo() {
/*  72 */     StringBuilder buf = new StringBuilder();
/*  73 */     buf.append("<html><table border=\"1px\">");
/*  74 */     buf.append("<tr><td width=\"200px\">");
/*  75 */     buf.append("RG construction options");
/*  76 */     buf.append("</td><td width=\"200px\"></td></tr>");
/*  77 */     buf.append("<tr><td>firing rule</td><td>");
/*  78 */     if (this.rule == 1) {
/*  79 */       buf.append("maximum");
/*     */     } else {
/*  81 */       buf.append("simple");
/*     */     } 
/*  83 */     buf.append("</td></tr><tr><td>boundedness</td><td>");
/*  84 */     buf.append(Boolean.toString(this.boundedness));
/*  85 */     buf.append("</td></tr><tr><td>maxDepth</td><td>");
/*  86 */     if (this.maxDepth != 0) {
/*  87 */       buf.append(Integer.toString(this.maxDepth));
/*     */     } else {
/*  89 */       buf.append("none");
/*     */     } 
/*  91 */     buf.append("</td></tr><tr><td>reduction</td><td>");
/*  92 */     if (this.stubborn) {
/*  93 */       buf.append("partial order (stubborn)");
/*     */     } else {
/*  95 */       buf.append("none");
/*     */     } 
/*  97 */     buf.append("</td></tr><tr><td>back edges</td><td>");
/*  98 */     buf.append(Boolean.toString(this.backEdges));
/*  99 */     buf.append("</td></tr><tr><td>initial marking</td><td>");
/* 100 */     buf.append(this.m0.toString());
/* 101 */     buf.append("</td></tr><tr><td>initial place marking</td><td>");
/* 102 */     buf.append(this.m0.getPlaceMarking().toString());
/*     */     
/* 104 */     buf.append("</td></tr></table></html>");
/* 105 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initializeByString(String parameters) {
/* 110 */     System.out.printf("ConstructionOptions.initializeByString()\n", new Object[0]);
/*     */     try {
/* 112 */       if (this.pn == null) {
/* 113 */         File file = null;
/* 114 */         file = getValue(parameters, "netfile", file);
/* 115 */         if (file != null) {
/*     */           try {
/* 117 */             PetriNetReader pnr = PetriNetReaderFactory.getReader(file);
/* 118 */             pnr.init(file.getAbsolutePath());
/* 119 */             pnr.readNet();
/* 120 */             this.pn = pnr.getPlaceTransitionNet();
/* 121 */           } catch (Exception e) {
/* 122 */             DebugCounter.inc("ConstructionOptions could not intialize netfile file:" + file.getName());
/* 123 */             System.out.printf(getHelpString(), new Object[0]);
/* 124 */             return false;
/*     */           } 
/*     */         } else {
/*     */           
/* 128 */           System.out.printf("Construction options could not initialize --netfile=...;", new Object[0]);
/* 129 */           return false;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 134 */       if (this.pn == null) {
/* 135 */         throw new Exception("no initialized net found!");
/*     */       }
/* 137 */       String r = "SIMPLE";
/* 138 */       r = getValue(parameters, "rule", r);
/* 139 */       if (r.equals("MAXIMUM")) {
/* 140 */         this.rule = 1;
/*     */       } else {
/* 142 */         this.rule = 0;
/*     */       } 
/* 144 */       this.boundedness = getValue(parameters, "boundedness", this.boundedness);
/* 145 */       this.maxDepth = getValue(parameters, "maxDepth", this.maxDepth);
/* 146 */       this.stubborn = getValue(parameters, "stubborn", this.stubborn);
/* 147 */       this.backEdges = getValue(parameters, "backEdges", this.backEdges);
/* 148 */       String m0String = getValue(parameters, "m0", "");
/* 149 */       System.out.printf("ConstructionOptions:initializeByString reconized m0String:\n" + m0String, new Object[0]);
/* 150 */       if (m0String != null && !m0String.equals("")) {
/* 151 */         StringTokenizer st = new StringTokenizer(m0String, ",");
/* 152 */         this.m0 = (Marking)new SortedElementsDynamic(true);
/* 153 */         String placeName = null;
/* 154 */         int id = -1;
/* 155 */         int token = -1;
/* 156 */         boolean a = false;
/* 157 */         if (st.countTokens() / 2 == 0) {
/* 158 */           throw new Exception("check list of ids and token values for m0!");
/*     */         }
/* 160 */         while (st.hasMoreTokens()) {
/* 161 */           if (!a) {
/*     */             
/* 163 */             placeName = st.nextToken();
/* 164 */             if (placeName != null && !placeName.equals("")) {
/* 165 */               id = this.pn.lookUpPlaceIDbyName(placeName);
/* 166 */               a = true;
/*     */             } else {
/* 168 */               throw new Exception("could not identify place with name: " + placeName);
/*     */             } 
/*     */           } else {
/* 171 */             token = Integer.parseInt(st.nextToken());
/* 172 */             a = false;
/*     */           } 
/* 174 */           if (id != -1 && token != -1) {
/* 175 */             if (this.pn.getPlaceByIndex(id) != null) {
/* 176 */               this.m0.addPlace(id, token);
/* 177 */               id = -1;
/* 178 */               token = -1;
/* 179 */               placeName = null; continue;
/*     */             } 
/* 181 */             throw new Exception("place with name=" + id + " does not exist in place transition net!");
/*     */           } 
/*     */         } 
/*     */         
/* 185 */         System.out.printf("initial marking set to m0=" + this.m0 + "\n", new Object[0]);
/*     */       }
/* 187 */       else if (this.pn != null) {
/* 188 */         this.m0 = this.pn.getNonTimedM0State();
/*     */       }
/*     */     
/*     */     }
/* 192 */     catch (Exception e) {
/* 193 */       DebugCounter.inc(StackTracePrinter.getStackTrace(e));
/* 194 */       System.out.printf("error message: " + e.getMessage() + "\n" + getHelpString(), new Object[0]);
/* 195 */       return false;
/*     */     } 
/* 197 */     return true;
/*     */   }
/*     */   
/*     */   public static String getHelpString() {
/* 201 */     StringBuilder buf = new StringBuilder();
/* 202 */     buf.append("\nReachability graph construction options\n");
/* 203 */     buf.append("---------------------------------------\n");
/* 204 */     buf.append("Invoke analysis by typing --analyze=rg or --analyze=rgraph \n\n");
/* 205 */     String fS = "%30s | %-30s\n";
/* 206 */     buf.append(String.format(fS, new Object[] { "option name", "option values" }));
/* 207 */     buf.append(String.format(fS, new Object[] { "--rule", "SIMPLE for simple firing rule" }));
/* 208 */     buf.append(String.format(fS, new Object[] { "", "MAXIMUM for maximum firing rule" }));
/* 209 */     buf.append(String.format(fS, new Object[] { "--boundedness", "0 = no / 1 = yes" }));
/* 210 */     buf.append(String.format(fS, new Object[] { "", "check the boundedness of the net" }));
/* 211 */     buf.append(String.format(fS, new Object[] { "--maxDepth", "integer value" }));
/* 212 */     buf.append(String.format(fS, new Object[] { "", "limit the maximal depth of the graph" }));
/* 213 */     buf.append(String.format(fS, new Object[] { "--stubborn", "0 = no / 1 = yes" }));
/* 214 */     buf.append(String.format(fS, new Object[] { "", "use stubborn reduction" }));
/* 215 */     buf.append(String.format(fS, new Object[] { "--backEdges", "0 = no / 1 = yes" }));
/* 216 */     buf.append(String.format(fS, new Object[] { "", "create back edges" }));
/* 217 */     buf.append(String.format(fS, new Object[] { "--m0", "provide a alternating list of place names" }));
/*     */     
/* 219 */     buf.append(String.format(fS, new Object[] { "", "and token values to initialize the initial " }));
/* 220 */     buf.append(String.format(fS, new Object[] { "", "place marking" }));
/* 221 */     buf.append(String.format(fS, new Object[] { "", "eg. m0=car,12,phone,1;" }));
/* 222 */     buf.append(String.format(fS, new Object[] { "", "=> place w. place car has 12 token" }));
/* 223 */     buf.append(String.format(fS, new Object[] { "", "place phone has 1 token" }));
/* 224 */     buf.append(String.format(fS, new Object[] { "", "the net is checked for correct place names " }));
/* 225 */     buf.append(String.format(fS, new Object[] { "", "use only commata as separator!" }));
/* 226 */     buf.append("\n");
/* 227 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/rg/ConstructionOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */