/*     */ package charlie.analyzer.rg;
/*     */ 
/*     */ import charlie.pn.ExceedsByteException;
/*     */ import charlie.pn.LookUpTable;
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.NodeSet;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.SafetyException;
/*     */ import charlie.pn.SortedElementsFactory;
/*     */ import charlie.pn.State;
/*     */ import charlie.pn.Transition;
/*     */ import charlie.pn.TransitionSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MaxFireRule
/*     */ {
/*     */   public static Collection maxFire(Collection<Transition> transitions, Marking m, Collection independentTransitions) throws SafetyException, ExceedsByteException {
/*  25 */     Collection<State> states = new Vector();
/*     */     
/*  27 */     Set ready = new HashSet();
/*  28 */     Set conflicts = new HashSet();
/*  29 */     Set c1 = new HashSet();
/*     */     
/*  31 */     if (!transitions.isEmpty()) {
/*  32 */       Transition t = transitions.iterator().next();
/*  33 */       states.add(fireFor((short)-1, (State)m, transitions, states, independentTransitions, new Vector()));
/*     */     } 
/*  35 */     return states;
/*     */   }
/*     */   
/*     */   private static State fireFor(short id, State m1, Collection transitions, Collection<State> states, Collection<Collection<Short>> independent, Collection<Short> cur) throws SafetyException, ExceedsByteException {
/*  39 */     State m3 = m1;
/*  40 */     State m2 = m1;
/*  41 */     for (Iterator<Transition> it = transitions.iterator(); it.hasNext(); ) {
/*  42 */       Transition t2 = it.next();
/*  43 */       if (t2.getId() > id && 
/*  44 */         t2.canFire(m1)) {
/*  45 */         cur.add(new Short(t2.getId()));
/*  46 */         m2 = t2.fire(m1, true, true);
/*     */         
/*  48 */         for (Iterator<Transition> it2 = t2.getConflicts().iterator(); it2.hasNext(); ) {
/*  49 */           Transition t3 = it2.next();
/*  50 */           if (transitions.contains(t3) && t3.getId() > t2.getId() && !t3.canFire(m2)) {
/*     */             
/*  52 */             Collection<Short> curNext = new Vector();
/*  53 */             for (int i = 0; i < cur.size() - 1; i++) {
/*  54 */               curNext.add(new Short(((Short)((Vector<Short>)cur).get(i)).shortValue()));
/*     */             }
/*  56 */             curNext.add(Short.valueOf(t3.getId()));
/*  57 */             states.add(fireFor(t2.getId(), t3.fire(m1, true, true), transitions, states, independent, curNext));
/*     */           } 
/*     */         } 
/*  60 */         m1 = m2;
/*     */       } 
/*     */     } 
/*     */     
/*  64 */     states.add(m1);
/*  65 */     independent.add(cur);
/*  66 */     return m1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getIndependentSets(PlaceTransitionNet pn, Set<TransitionSet> independent, State m, Collection transitions, int numberOfTransitions) throws SafetyException, ExceedsByteException {
/* 133 */     Vector<TransitionSet> tempIndependent = new Vector<>();
/* 134 */     Vector<Transition> firingTransitions = new Vector<>();
/* 135 */     for (Object o : transitions) {
/*     */       
/* 137 */       Transition t = (Transition)o;
/* 138 */       if (t.canFire(m)) {
/*     */         
/* 140 */         TransitionSet tempTrSet = new TransitionSet(LookUpTable.transitions());
/* 141 */         tempTrSet.insert(t.getId());
/* 142 */         tempIndependent.add(tempTrSet);
/* 143 */         firingTransitions.add(t);
/*     */       } 
/*     */     } 
/* 146 */     boolean changed = true;
/* 147 */     while (changed == true) {
/*     */       
/* 149 */       changed = false;
/* 150 */       Vector<TransitionSet> removedSets = new Vector<>();
/* 151 */       Vector<TransitionSet> addedSets = new Vector<>();
/* 152 */       for (TransitionSet transitionSet : tempIndependent) {
/*     */         State m1;
/*     */         
/*     */         try {
/* 156 */           m1 = m.copy();
/* 157 */         } catch (SafetyException e) {
/*     */           
/* 159 */           SortedElementsFactory.safeMode(false);
/* 160 */           m1 = m.copy();
/* 161 */           SortedElementsFactory.safeMode(true);
/* 162 */         } catch (ExceedsByteException e) {
/*     */           
/* 164 */           SortedElementsFactory.byteMode(false);
/* 165 */           m1 = m.copy();
/* 166 */           SortedElementsFactory.byteMode(true);
/*     */         }  Iterator<Integer> iterator;
/* 168 */         for (iterator = transitionSet.iterator(); iterator.hasNext(); ) {
/*     */           
/* 170 */           int id = ((Integer)iterator.next()).intValue();
/* 171 */           Transition t = pn.getTransition((short)id);
/* 172 */           m1 = t.consume(m1);
/*     */         } 
/* 174 */         for (iterator = (Iterator)firingTransitions.iterator(); iterator.hasNext(); ) { Transition currentTransition = (Transition)iterator.next();
/* 175 */           if (currentTransition.canFire(m1) && !transitionSet.contains(currentTransition)) {
/*     */             
/* 177 */             TransitionSet newTrSet = new TransitionSet(transitionSet.nodes().copy());
/* 178 */             newTrSet.insert(currentTransition.getId());
/* 179 */             if (!containsTransitionSet(tempIndependent, newTrSet) && !containsTransitionSet(addedSets, newTrSet)) {
/*     */               
/* 181 */               addedSets.add(newTrSet);
/* 182 */               changed = true;
/*     */             } 
/* 184 */             if (!containsTransitionSet(removedSets, transitionSet)) {
/* 185 */               removedSets.add(transitionSet);
/*     */             }
/*     */           }  }
/*     */       
/*     */       } 
/* 190 */       tempIndependent.addAll(addedSets);
/* 191 */       tempIndependent.removeAll(removedSets);
/*     */     } 
/* 193 */     for (TransitionSet v : tempIndependent)
/*     */     {
/* 195 */       independent.add(v);
/*     */     }
/*     */     
/* 198 */     HashSet<TransitionSet> prune = new HashSet();
/* 199 */     for (Iterator<TransitionSet> it = independent.iterator(); it.hasNext(); ) {
/* 200 */       TransitionSet current = it.next();
/* 201 */       for (Iterator<TransitionSet> itinner = independent.iterator(); itinner.hasNext(); ) {
/* 202 */         TransitionSet temp = itinner.next();
/* 203 */         if (temp != current && 
/* 204 */           current.subSet((NodeSet)temp)) {
/* 205 */           prune.add(current);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 210 */     System.out.println("Before pruning:\n" + independent);
/* 211 */     independent.removeAll(prune);
/* 212 */     System.out.println("After pruning:\n" + independent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean containsTransitionSet(Vector<TransitionSet> vector, TransitionSet trSet) {
/* 233 */     boolean found = false;
/* 234 */     int count = 0;
/* 235 */     for (Iterator<TransitionSet> it = vector.iterator(); it.hasNext(); ) {
/* 236 */       TransitionSet ts2 = it.next();
/* 237 */       if (ts2.isEqual(trSet)) {
/* 238 */         found = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 242 */     return found;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/rg/MaxFireRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */