/*     */ package charlie.analyzer;
/*     */ 
/*     */ import charlie.pn.Results;
/*     */ import java.io.File;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OptionSet
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  21 */   public OptionSet[] beforeSet = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  29 */   protected Object resultObject = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   protected Object objectToAnalyze = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   public Initiator initiator = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public OptionSet nextStage = null;
/*     */   
/*  52 */   private Results results = new Results();
/*     */   
/*  54 */   private ArrayList<OptionSet> setList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean logOutput = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Properties getAsProperties();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean initByProperties(Properties paramProperties);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getHtmlInfo();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String toString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean initializeByString(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPreviousResults(OptionSet options) {
/*  99 */     for (OptionSet set : options.getPreviousOptionSets()) {
/* 100 */       this.setList.add(set);
/*     */     }
/* 102 */     this.setList.add(options);
/*     */   }
/*     */   
/*     */   public ArrayList<OptionSet> getPreviousOptionSets() {
/* 106 */     return this.setList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int numberOfResults() {
/* 113 */     return this.setList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Results getStageResult(int index) {
/* 121 */     if (index < this.setList.size() && index >= 0) {
/* 122 */       return ((OptionSet)this.setList.get(index)).getResults();
/*     */     }
/* 124 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Results getResults() {
/* 129 */     return this.results;
/*     */   }
/*     */   
/*     */   public void setResults(Results results) {
/* 133 */     if (this.results != null) {
/* 134 */       this.results.mergeWith(results);
/*     */     } else {
/* 136 */       this.results = results;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLogOutput() {
/* 147 */     return this.logOutput;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogOutput(boolean _log) {
/* 158 */     this.logOutput = _log;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendOutput(String s) {
/* 170 */     if (this.logOutput)
/*     */     {
/* 172 */       this.results.appendOutput(s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getStageResultObject(int index) {
/* 181 */     if (index < this.setList.size() && index >= 0) {
/* 182 */       return ((OptionSet)this.setList.get(index)).getResultObject();
/*     */     }
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAllOutput() {
/* 191 */     StringBuffer buf = new StringBuffer();
/* 192 */     for (OptionSet set : this.setList)
/*     */     {
/* 194 */       buf.append(set.getResults().getOutput() + "\n");
/*     */     }
/* 196 */     buf.append(this.results.getOutput() + "\n");
/* 197 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public Object getResultObject() {
/* 201 */     return this.resultObject;
/*     */   }
/*     */   
/*     */   public void setResultObject(Object object) {
/* 205 */     this.resultObject = object;
/*     */   }
/*     */   
/*     */   public Object getObjectToAnalyze() {
/* 209 */     return this.objectToAnalyze;
/*     */   }
/*     */   
/*     */   public void setObjectToAnalyze(Object object) {
/* 213 */     this.objectToAnalyze = object;
/*     */   }
/*     */   
/*     */   public Initiator getInitiator() {
/* 217 */     return this.initiator;
/*     */   }
/*     */   
/*     */   public void setInitiator(Initiator _initiator) {
/* 221 */     this.initiator = _initiator;
/*     */   }
/*     */   
/*     */   public static boolean getValue(String parameterlist, String search, boolean b) {
/* 225 */     boolean oldValue = b;
/*     */ 
/*     */     
/* 228 */     String value = getSearchedString(parameterlist, search);
/* 229 */     if (value == null || value.length() == 0) {
/* 230 */       return oldValue;
/*     */     }
/* 232 */     if (value.equals("1"))
/* 233 */       return true; 
/* 234 */     if (value.equals("0")) {
/* 235 */       return false;
/*     */     }
/* 237 */     return oldValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getValue(String parameterlist, String search, int b) {
/* 242 */     int oldValue = b;
/*     */ 
/*     */     
/* 245 */     String value = getSearchedString(parameterlist, search);
/* 246 */     if (value == null || value.length() == 0) {
/* 247 */       return oldValue;
/*     */     }
/*     */     try {
/* 250 */       b = Integer.parseInt(value);
/* 251 */       return b;
/* 252 */     } catch (NumberFormatException e) {
/* 253 */       return oldValue;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte getValue(String parameterlist, String search, byte b) {
/* 258 */     byte oldValue = b;
/*     */ 
/*     */     
/* 261 */     String value = getSearchedString(parameterlist, search);
/* 262 */     if (value == null || value.length() == 0) {
/* 263 */       return oldValue;
/*     */     }
/*     */     try {
/* 266 */       b = Byte.parseByte(value);
/* 267 */       return b;
/* 268 */     } catch (NumberFormatException e) {
/*     */       
/* 270 */       return oldValue;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getValue(String parameterlist, String search, String b) {
/* 275 */     String oldValue = b;
/*     */ 
/*     */     
/* 278 */     String value = getSearchedString(parameterlist, search);
/* 279 */     if (value == null || value.length() == 0)
/*     */     {
/* 281 */       return oldValue;
/*     */     }
/* 283 */     b = value;
/* 284 */     return b;
/*     */   }
/*     */   
/*     */   public static File getValue(String parameterlist, String search, File b) {
/* 288 */     File oldValue = b;
/*     */ 
/*     */ 
/*     */     
/* 292 */     String value = getSearchedString(parameterlist, search);
/* 293 */     if (value == null || value.length() == 0) {
/* 294 */       return oldValue;
/*     */     }
/* 296 */     b = new File(value);
/*     */     
/* 298 */     if (b == null || !b.exists()) {
/* 299 */       return oldValue;
/*     */     }
/* 301 */     return b;
/*     */   }
/*     */   
/*     */   private static String getSearchedString(String parameterlist, String search) {
/* 305 */     int searchpos = parameterlist.indexOf("--" + search + "=", 0);
/* 306 */     if (searchpos < 0) {
/* 307 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 311 */     int semipos = parameterlist.indexOf("--", searchpos + 2);
/*     */     
/* 313 */     if (semipos < 0)
/*     */     {
/*     */ 
/*     */       
/* 317 */       semipos = parameterlist.length();
/*     */     }
/* 319 */     int l = ("--" + search + "=").length();
/*     */     
/* 321 */     String value = parameterlist.substring(searchpos + l, semipos);
/* 322 */     if (value != null) {
/* 323 */       value = value.trim();
/* 324 */       return value;
/*     */     } 
/* 326 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getHelpString() {
/* 331 */     return "Optionset.getHelpString should not be called directly.\nA inheriting class did not override getHelpString()";
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/OptionSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */