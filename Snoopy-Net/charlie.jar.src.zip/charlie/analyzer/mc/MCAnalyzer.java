/*    */ package charlie.analyzer.mc;
/*    */ 
/*    */ import GUI.debug.DebugCounter;
/*    */ import charlie.analyzer.Analyzer;
/*    */ import charlie.analyzer.AnalyzerManagerFactory;
/*    */ import charlie.analyzer.OptionSet;
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.rg.RGraph;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileReader;
/*    */ 
/*    */ public class MCAnalyzer
/*    */   extends Analyzer {
/* 15 */   protected RGraph rg = null;
/* 16 */   protected PlaceTransitionNet pn = null;
/* 17 */   protected String formula = null;
/*    */   protected boolean formulaResult = false;
/* 19 */   protected MCOptions mco = null;
/*    */   
/*    */   public MCAnalyzer() {
/* 22 */     setUpdateInterval(100L);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 27 */     return "MCAnalyzer";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void analyze() {
/* 33 */     DebugCounter.inc("charlie.mc.MCAnalyzer.analyze() called , should not be called directly!\n Awaited LTLMCAnalyzer.analyze() or CTLMCAnalyzer.analyze() ?");
/*    */   }
/*    */ 
/*    */   
/*    */   public void evaluate() {
/* 38 */     DebugCounter.inc("MCAnalyzer.evaluate()");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void cleanup() {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean register() {
/* 50 */     boolean b = AnalyzerManagerFactory.getAnalyzerManager().register(new MCAnalyzer(), new RGraph(), new Formula());
/* 51 */     if (!b) {
/* 52 */       DebugCounter.inc("MCAnalyzer.register() failed there is already an analyzer registerd for MCOptions!");
/*    */     }
/* 54 */     return b;
/*    */   }
/*    */ 
/*    */   
/*    */   public void initializeInfoStrings() {
/* 59 */     this.infoStrings = new String[1];
/* 60 */     this.infoStrings[0] = getFormatedDuration();
/*    */   }
/*    */ 
/*    */   
/*    */   public Analyzer getNewInstance(OptionSet options) {
/* 65 */     if (!(options instanceof MCOptions)) {
/* 66 */       return null;
/*    */     }
/* 68 */     MCOptions mco = (MCOptions)options;
/* 69 */     Analyzer newAnalyzer = null;
/* 70 */     if (mco.mode == 1) {
/* 71 */       newAnalyzer = new LTLMCAnalyzer();
/* 72 */     } else if (mco.mode == 0) {
/* 73 */       newAnalyzer = new CTLMCAnalyzer();
/*    */     } 
/* 75 */     newAnalyzer.setup(mco);
/* 76 */     return newAnalyzer;
/*    */   }
/*    */   
/*    */   public String readFormulaFile(String fileName) {
/* 80 */     StringBuffer buf = new StringBuffer();
/* 81 */     File file = new File(fileName);
/* 82 */     if (file != null && file.exists()) {
/*    */       try {
/* 84 */         BufferedReader br = new BufferedReader(new FileReader(file));
/*    */         
/* 86 */         String s = br.readLine();
/* 87 */         while (s != null) {
/* 88 */           buf.append(s);
/* 89 */           buf.append("\n");
/* 90 */           s = br.readLine();
/*    */         } 
/* 92 */         br.close();
/* 93 */         return buf.toString();
/* 94 */       } catch (Exception ex) {
/* 95 */         System.out.printf("could not read file : %s \n", new Object[] { file.getName() });
/* 96 */         return null;
/*    */       } 
/*    */     }
/* 99 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/mc/MCAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */