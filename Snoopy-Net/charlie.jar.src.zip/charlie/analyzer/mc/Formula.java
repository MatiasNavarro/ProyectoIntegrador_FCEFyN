/*    */ package charlie.analyzer.mc;
/*    */ 
/*    */ public class Formula
/*    */ {
/*  5 */   private String formula = null;
/*  6 */   private byte mode = 0;
/*    */   
/*    */   private boolean valid;
/*    */ 
/*    */   
/*    */   public Formula() {}
/*    */   
/*    */   public Formula(String formula, byte mode) {
/* 14 */     this.formula = formula;
/* 15 */     this.mode = mode;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setFormula(String f) {
/* 20 */     this.formula = f;
/*    */   }
/*    */   
/*    */   public void setMode(byte m) {
/* 24 */     this.mode = m;
/*    */   }
/*    */   
/*    */   public String getFormula() {
/* 28 */     return this.formula;
/*    */   }
/*    */   
/*    */   public byte getMode() {
/* 32 */     return this.mode;
/*    */   }
/*    */   
/*    */   public void setResult(boolean b) {
/* 36 */     this.valid = b;
/*    */   }
/*    */   
/*    */   public boolean isTrue() {
/* 40 */     return this.valid;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 44 */     if (this.mode == 0) return "Ctl-formula: " + this.formula + " is " + this.valid; 
/* 45 */     if (this.mode == 1) return "Ltl-formula: " + this.formula + " is " + this.valid; 
/* 46 */     return this.formula + " is " + this.valid;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/mc/Formula.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */