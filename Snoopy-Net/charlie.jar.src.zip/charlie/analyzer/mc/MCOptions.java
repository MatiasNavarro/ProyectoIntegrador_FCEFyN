/*     */ package charlie.analyzer.mc;
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.analyzer.rg.ConstructionOptions;
/*     */ import charlie.pn.PetriNetReader;
/*     */ import charlie.pn.PetriNetReaderFactory;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.rg.RGraph;
/*     */ import java.io.File;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class MCOptions extends OptionSet {
/*     */   public static final byte CTL = 0;
/*  14 */   public RGraph rg = null; public static final byte LTL = 1;
/*  15 */   public PlaceTransitionNet pn = null;
/*  16 */   public String formula = null;
/*     */   public boolean formulaResult = false;
/*  18 */   public String formulaFile = null;
/*  19 */   public byte mode = 0;
/*  20 */   public Path path = null;
/*     */   
/*     */   public MCOptions() {
/*  23 */     OptionSet[] t = { (OptionSet)new ConstructionOptions() };
/*  24 */     this.beforeSet = t;
/*  25 */     setObjectToAnalyze(new RGraph());
/*  26 */     setResultObject(new Formula());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean initializeByString(String parameters) {
/*  33 */     if (this.pn == null) {
/*  34 */       File file = null;
/*  35 */       file = getValue(parameters, "netfile", file);
/*  36 */       if (file != null) {
/*     */         try {
/*  38 */           PetriNetReader pnr = PetriNetReaderFactory.getReader(file);
/*  39 */           pnr.init(file.getAbsolutePath());
/*  40 */           pnr.readNet();
/*  41 */           this.pn = pnr.getPlaceTransitionNet();
/*  42 */         } catch (Exception e) {
/*  43 */           DebugCounter.inc("MCOptions could not intialize netfile file:" + file.getName());
/*  44 */           System.out.printf(getHelpString(), new Object[0]);
/*  45 */           return false;
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/*  50 */         System.out.printf("Modelchecking options could not initialize --netfile=...;", new Object[0]);
/*  51 */         return false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  56 */     String modeString = "";
/*  57 */     modeString = getValue(parameters, "mode", modeString);
/*  58 */     if (modeString.equals("CTL") || modeString.equals("ctl")) {
/*  59 */       this.mode = 0;
/*  60 */     } else if (modeString.equals("LTL") || modeString.equals("ltl")) {
/*  61 */       this.mode = 1;
/*     */     } else {
/*  63 */       System.out.printf(getHelpString(), new Object[0]);
/*  64 */       return false;
/*     */     } 
/*     */     
/*  67 */     this.formulaFile = getValue(parameters, "formulaFile", this.formulaFile);
/*  68 */     if (this.pn != null && (this.formula != null || this.formulaFile != null)) {
/*  69 */       return true;
/*     */     }
/*  71 */     System.out.printf("Modelchecking options : provide a formula or a formula file!\n" + getHelpString(), new Object[0]);
/*  72 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getAsProperties() {
/*  79 */     return new Properties();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean initByProperties(Properties props) {
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHtmlInfo() {
/*  90 */     StringBuffer buf = new StringBuffer();
/*  91 */     buf.append("<html><table>");
/*  92 */     if (this.mode == 0) {
/*  93 */       buf.append("<tr><td>mode</td><td>CTL</td></tr>");
/*     */     }
/*  95 */     if (this.mode == 1) {
/*  96 */       buf.append("<tr><td>mode</td><td>LTL</td></tr>");
/*     */     }
/*  98 */     if (this.formulaFile != null) {
/*  99 */       buf.append("<tr><td>formula file</td><td>" + this.formulaFile + "</td></tr>");
/*     */     }
/* 101 */     buf.append("</table></html>");
/* 102 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 106 */     StringBuilder buf = new StringBuilder();
/* 107 */     if (this.mode == 0) {
/* 108 */       buf.append("mode : CTL");
/*     */     }
/* 110 */     if (this.mode == 1) {
/* 111 */       buf.append("mode : LTL");
/*     */     }
/* 113 */     buf.append("\n");
/* 114 */     if (this.formulaFile != null) {
/* 115 */       buf.append("formula file : " + this.formulaFile);
/*     */     }
/* 117 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getHelpString() {
/* 123 */     StringBuilder buf = new StringBuilder();
/* 124 */     buf.append("\nModel checking options\n");
/* 125 */     buf.append("----------------------\n");
/* 126 */     buf.append("model checking needs a computed reachability graph.\nSo put the options behind a reachability graph option set \n");
/* 127 */     buf.append("invoke analysis by typing --analyze=mc or --analyze=formula\n");
/* 128 */     String fS = "%30s | %-30s\n";
/* 129 */     buf.append(String.format(fS, new Object[] { "Option name", "option values" }));
/* 130 */     buf.append(String.format(fS, new Object[] { "--mode", "use CTL or LTL" }));
/* 131 */     buf.append(String.format(fS, new Object[] { "--formulaFile", "provide a path to a file" }));
/* 132 */     buf.append(String.format(fS, new Object[] { "", "which contains a valid formula " }));
/* 133 */     buf.append("\n");
/* 134 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/mc/MCOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */