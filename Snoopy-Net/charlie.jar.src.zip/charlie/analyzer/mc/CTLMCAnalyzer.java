/*    */ package charlie.analyzer.mc;
/*    */ import GUI.util.TextFile;
/*    */ import charlie.ctl.Main;
/*    */ import charlie.ctl.NoPlaceException;
/*    */ import charlie.rg.RGraph;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.StringReader;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class CTLMCAnalyzer extends MCAnalyzer {
/*    */   public CTLMCAnalyzer() {
/* 13 */     setUpdateInterval(100L);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 17 */     return "CTL-MC-Analyzer";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void analyze() {
/* 24 */     this.mco = (MCOptions)this.options;
/* 25 */     if (this.mco.rg == null && this.mco.getObjectToAnalyze() != null && this.mco.getObjectToAnalyze() instanceof RGraph)
/* 26 */       this.mco.rg = (RGraph)this.mco.getObjectToAnalyze(); 
/* 27 */     if (this.mco.rg != null && this.mco.pn == null)
/* 28 */       this.mco.pn = this.mco.rg.getNet(); 
/* 29 */     if (this.mco.formula != null) {
/* 30 */       this.formula = this.mco.formula;
/* 31 */     } else if (this.mco.formulaFile != null) {
/* 32 */       System.out.printf("Try reading formula file" + this.mco.formulaFile + "\n", new Object[0]);
/* 33 */       String fm = TextFile.readTextFile(new File(this.mco.formulaFile));
/* 34 */       System.out.printf("formula file contained following formula:\n" + fm + "\n", new Object[0]);
/* 35 */       this.mco.formula = fm;
/* 36 */       this.formula = this.mco.formula;
/*    */     } 
/* 38 */     if (this.mco.formula == null) {
/* 39 */       System.out.printf("Cannot analyze CTL formula mco.formula == null\n", new Object[0]);
/* 40 */       setStatus(4);
/*    */       return;
/*    */     } 
/* 43 */     System.out.printf("Analyzing following CTL formula" + this.mco.formula + "\n", new Object[0]);
/*    */     try {
/* 45 */       if (this.mco.rg != null && this.mco.pn != null && this.mco.mode == 0) {
/*    */         
/* 47 */         Main.resultText = new StringBuffer();
/* 48 */         Vector v = new Vector();
/* 49 */         Main.checkFormulae(this.mco.pn, this.mco.rg, new StringReader(this.formula), v);
/* 50 */         System.out.printf("CTL Output\n" + Main.resultText.toString(), new Object[0]);
/* 51 */         setOutput("CTL model checker output:\n" + Main.resultText.toString());
/*    */       } else {
/* 53 */         System.out.printf("Analyzing following CTL formula" + this.mco.formula + "\n", new Object[0]);
/*    */       } 
/* 55 */     } catch (NoPlaceException npe) {
/* 56 */       setOutput(npe.getMessage());
/* 57 */       setStatus(4);
/*    */       
/*    */       return;
/* 60 */     } catch (IOException ioe) {
/* 61 */       setStatus(4);
/*    */       return;
/* 63 */     } catch (Exception exc) {
/* 64 */       exc.printStackTrace();
/* 65 */       setStatus(4);
/*    */       return;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/mc/CTLMCAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */