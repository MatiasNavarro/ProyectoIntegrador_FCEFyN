/*    */ package charlie.analyzer.mc;
/*    */ 
/*    */ import charlie.ctl.NoPlaceException;
/*    */ import charlie.ltl.LTL_Main;
/*    */ import charlie.rg.RGraph;
/*    */ import java.io.IOException;
/*    */ import java.io.StringReader;
/*    */ 
/*    */ public class LTLMCAnalyzer
/*    */   extends MCAnalyzer
/*    */ {
/*    */   public LTLMCAnalyzer() {
/* 13 */     setUpdateInterval(100L);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 17 */     return "LTL-MC-Analyzer";
/*    */   }
/*    */   
/*    */   public void analyze() {
/* 21 */     MCOptions mco = (MCOptions)this.options;
/*    */     
/* 23 */     if (mco.rg == null && mco.getObjectToAnalyze() != null && mco.getObjectToAnalyze() instanceof RGraph)
/* 24 */       mco.rg = (RGraph)mco.getObjectToAnalyze(); 
/* 25 */     if (mco.rg != null && mco.pn == null)
/* 26 */       mco.pn = mco.rg.getNet(); 
/* 27 */     if (mco.formula != null) {
/* 28 */       this.formula = mco.formula;
/* 29 */     } else if (mco.formulaFile != null) {
/* 30 */       this.formula = readFormulaFile(mco.formulaFile);
/* 31 */       mco.formula = this.formula;
/*    */     } 
/* 33 */     if (mco.formula == null) {
/* 34 */       setStatus(4);
/*    */       
/*    */       return;
/*    */     } 
/*    */     try {
/* 39 */       if (mco.rg != null && mco.pn != null && mco.mode == 1) {
/*    */         
/* 41 */         mco.path = LTL_Main.checkFormulae(mco.pn, mco.rg, new StringReader(this.formula));
/* 42 */         this.formula = LTL_Main.currentFormula;
/* 43 */         mco.formulaResult = LTL_Main.currentResult;
/*    */         
/* 45 */         if (mco.path != null) {
/* 46 */           mco.path.setName(LTL_Main.currentFormula);
/*    */         } else {
/* 48 */           System.out.printf("could not set pathname on computed path!", new Object[0]);
/*    */         } 
/* 50 */         setOutput(LTL_Main.out.toString());
/*    */       } 
/* 52 */     } catch (NoPlaceException npe) {
/* 53 */       setOutput(npe.getMessage());
/* 54 */       setStatus(4);
/*    */       
/*    */       return;
/* 57 */     } catch (IOException ioe) {
/* 58 */       setStatus(4);
/*    */       return;
/* 60 */     } catch (Exception exc) {
/* 61 */       exc.printStackTrace();
/* 62 */       setStatus(4);
/*    */       return;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/mc/LTLMCAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */