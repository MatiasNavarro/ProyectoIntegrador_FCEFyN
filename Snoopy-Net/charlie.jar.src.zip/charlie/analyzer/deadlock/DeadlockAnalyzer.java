/*     */ package charlie.analyzer.deadlock;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.TextFile;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.pn.NodeSet;
/*     */ import charlie.pn.PlaceSet;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Result;
/*     */ import java.io.File;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ public class DeadlockAnalyzer
/*     */   extends Analyzer
/*     */ {
/*  23 */   private static final Log LOG = LogFactory.getLog(DeadlockAnalyzer.class);
/*     */   
/*     */   private PlaceTransitionNet pn;
/*     */   private DeadlockSet ddl2;
/*     */   private HashSet<PlaceSet> old2;
/*  28 */   private String info = "";
/*     */   private HashSet<PlaceSet> notMarked;
/*  30 */   private DeadlockOptions dOptions = null;
/*     */   
/*     */   private boolean breakComputation = false;
/*     */ 
/*     */   
/*     */   public DeadlockAnalyzer() {
/*  36 */     setUpdateInterval(10000L);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  41 */     return "Siphon Analyzer";
/*     */   }
/*     */   
/*     */   public static boolean register() {
/*  45 */     DeadlockAnalyzer da = new DeadlockAnalyzer();
/*  46 */     boolean value = AnalyzerManagerFactory.getAnalyzerManager().register(da, new PlaceTransitionNet(), new DeadlockSet());
/*  47 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeInfoStrings() {
/*  56 */     int count = 4;
/*  57 */     this.infoStrings = new String[count];
/*  58 */     if (this.dOptions == null && this.options != null && this.options instanceof DeadlockOptions)
/*     */     {
/*  60 */       this.dOptions = (DeadlockOptions)this.options;
/*     */     }
/*  62 */     if (this.dOptions.properSets) {
/*  63 */       if (this.dOptions.breakDtpComputation) {
/*     */         
/*  65 */         this.infoStrings[0] = "proper siphons";
/*     */       } else {
/*  67 */         this.infoStrings[0] = "minimal proper siphons";
/*     */       }
/*     */     
/*  70 */     } else if (this.dOptions.breakDtpComputation) {
/*     */       
/*  72 */       this.infoStrings[0] = "siphons";
/*     */     } else {
/*  74 */       this.infoStrings[0] = "minimal siphons";
/*     */     } 
/*     */     
/*  77 */     if (this.ddl2 != null) {
/*  78 */       this.infoStrings[1] = Integer.toString(this.ddl2.size());
/*     */     } else {
/*  80 */       this.infoStrings[1] = "0";
/*     */     } 
/*  82 */     this.infoStrings[2] = "time";
/*  83 */     this.infoStrings[3] = getFormatedDuration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluate() {
/*  94 */     if (this.dOptions.exportFile != null) {
/*  95 */       DebugCounter.inc("Export Siphons to:" + this.dOptions.exportFile);
/*     */       
/*  97 */       writeToFile(this.dOptions.exportFile.getAbsolutePath());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze() {
/* 108 */     this.ddl2 = new DeadlockSet();
/* 109 */     this.old2 = new HashSet<>();
/* 110 */     this.notMarked = new HashSet<>();
/* 111 */     this.ddl2.notMarked = this.notMarked;
/* 112 */     this.pn = (PlaceTransitionNet)this.options.getObjectToAnalyze();
/* 113 */     addOutput("Siphon Analyzer:\n computing siphons\n");
/* 114 */     deadlocks((NodeSet)new PlaceSet(this.pn.places()), (NodeSet)new PlaceSet(this.pn.places(), this.pn.places()));
/* 115 */     if (!checkStatus()) {
/* 116 */       addOutput("Siphon Analyzer:\n computing aborted\n");
/* 117 */       cleanup();
/*     */       
/*     */       return;
/*     */     } 
/* 121 */     this.dOptions = (DeadlockOptions)this.options;
/* 122 */     this.info = new String();
/*     */     
/* 124 */     if (this.dOptions.computeDtp) {
/* 125 */       hasDTP();
/* 126 */       this.ddl2.dtp = true;
/*     */       
/* 128 */       if (this.dOptions.breakDtpComputation) {
/*     */         
/* 130 */         this.info += this.ddl2.size() + " siphons computed " + getFormatedDuration();
/*     */       } else {
/*     */         
/* 133 */         this.info += this.ddl2.size() + " minimal siphons computed " + getFormatedDuration();
/*     */       } 
/*     */     } else {
/* 136 */       DeadlockSet properSets = new DeadlockSet();
/* 137 */       DeadlockSet badSiphonSets = new DeadlockSet();
/* 138 */       DeadlockSet cleanSoundSiphonSets = new DeadlockSet();
/* 139 */       DeadlockSet markedSoundSiphonSets = new DeadlockSet();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 144 */       Iterator<PlaceSet> iter = this.ddl2.iterator();
/* 145 */       while (iter.hasNext()) {
/* 146 */         PlaceSet currentSiphon = iter.next();
/* 147 */         PlaceSet maxtrap = currentSiphon.maxTrap();
/*     */         
/* 149 */         boolean added = false;
/* 150 */         if (this.dOptions.properSets && this.dOptions.invSupports != null && !this.dOptions.invSupports.contains(currentSiphon.nodes())) {
/* 151 */           properSets.add(currentSiphon);
/* 152 */           added = true;
/*     */         } 
/* 154 */         if (this.dOptions.computeBadSiphons && !currentSiphon.subSet((NodeSet)maxtrap)) {
/* 155 */           badSiphonSets.add(currentSiphon);
/* 156 */           added = true;
/*     */         } 
/* 158 */         if (this.dOptions.computeSoundSiphons && currentSiphon.subSet((NodeSet)maxtrap)) {
/* 159 */           if (!maxtrap.marksPlaceSetSufficient(this.pn.getM0())) {
/* 160 */             cleanSoundSiphonSets.add(currentSiphon);
/*     */           } else {
/* 162 */             markedSoundSiphonSets.add(currentSiphon);
/*     */           } 
/* 164 */           added = true;
/*     */         } 
/*     */         
/* 167 */         if (!added)
/*     */         {
/*     */ 
/*     */           
/* 171 */           if (this.dOptions.properSets || this.dOptions.computeBadSiphons || this.dOptions.computeSoundSiphons) {
/* 172 */             if (LOG.isDebugEnabled()) {
/* 173 */               LOG.debug("removing " + currentSiphon.toString());
/*     */             }
/* 175 */             iter.remove();
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 180 */       String timeNeeded = getFormatedDuration();
/* 181 */       if (this.dOptions.properSets) {
/* 182 */         this.info += properSets.size() + " minimal proper siphons computed in " + timeNeeded + "\n";
/* 183 */         this.info += properSets.toString() + "\n";
/*     */       } 
/* 185 */       if (this.dOptions.computeBadSiphons) {
/* 186 */         this.info += badSiphonSets.size() + " minimal bad siphons computed in " + timeNeeded + "\n";
/* 187 */         this.info += badSiphonSets.toString() + "\n";
/*     */       } 
/* 189 */       if (this.dOptions.computeSoundSiphons) {
/* 190 */         this.info += (cleanSoundSiphonSets.size() + markedSoundSiphonSets.size()) + " minimal sound siphons computed in " + timeNeeded + "\n";
/* 191 */         this.info += cleanSoundSiphonSets.size() + " clean sound siphons\n";
/* 192 */         this.info += cleanSoundSiphonSets.toString() + "\n";
/* 193 */         this.info += markedSoundSiphonSets.size() + " marked sound siphons\n";
/* 194 */         this.info += markedSoundSiphonSets.toString() + "\n";
/*     */       } 
/* 196 */       if (!this.dOptions.properSets && !this.dOptions.computeBadSiphons && !this.dOptions.computeSoundSiphons) {
/*     */ 
/*     */         
/* 199 */         this.info += this.ddl2.size() + " minimal siphons computed in " + timeNeeded + "\n";
/* 200 */         this.info += this.ddl2.toString() + "\n";
/*     */       } 
/*     */     } 
/*     */     
/* 204 */     this.options.setResultObject(this.ddl2);
/*     */     
/* 206 */     addOutput(this.info);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<PlaceSet> deadlocks(NodeSet q, NodeSet r) {
/* 213 */     while (!r.isEmpty()) {
/* 214 */       if (!checkStatus()) {
/* 215 */         cleanup();
/* 216 */         return null;
/*     */       } 
/* 218 */       NodeSet d = q.copy();
/* 219 */       d.insert(r.first());
/* 220 */       boolean existD = false;
/* 221 */       for (Iterator<PlaceSet> it = this.ddl2.iterator(); it.hasNext(); ) {
/* 222 */         NodeSet ss = (NodeSet)it.next();
/* 223 */         if (ss.subSet(d)) {
/* 224 */           existD = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 228 */       if (!existD) {
/* 229 */         NodeSet df = d.getPost();
/* 230 */         NodeSet fd = d.getPre();
/* 231 */         if (fd.subSet(df)) {
/* 232 */           add(this.ddl2, d);
/* 233 */           if (this.dOptions.breakDtpComputation) {
/* 234 */             PlaceSet maxtrap = ((PlaceSet)d).maxTrap();
/* 235 */             if (!maxtrap.marksPlaceSetSufficient(this.pn.getM0())) {
/* 236 */               this.info += "\nSTP is not valid\n";
/*     */               
/* 238 */               this.info += "siphon:\n" + d + "\n";
/* 239 */               this.info += "\tmaximal trap:\n" + maxtrap.toString();
/* 240 */               this.info += "\n\tis not sufficiently marked\n";
/* 241 */               this.breakComputation = true;
/* 242 */               LOG.debug(this.info);
/* 243 */               return this.ddl2;
/*     */             } 
/*     */           } 
/*     */           continue;
/*     */         } 
/* 248 */         boolean existS = false;
/* 249 */         for (Iterator<PlaceSet> iterator = this.old2.iterator(); iterator.hasNext(); ) {
/* 250 */           NodeSet ss = (NodeSet)iterator.next();
/* 251 */           if (ss.subSet(d)) {
/* 252 */             existS = true;
/*     */             break;
/*     */           } 
/*     */         } 
/* 256 */         if (!existS) {
/*     */ 
/*     */ 
/*     */           
/* 260 */           fd = d.getPre();
/* 261 */           fd.diff(d.getPost());
/*     */ 
/*     */           
/* 264 */           NodeSet prePlaces = fd.getPre();
/*     */           
/* 266 */           prePlaces.diff(d);
/*     */           
/* 268 */           deadlocks(d, prePlaces);
/* 269 */           if (this.breakComputation) {
/* 270 */             return this.ddl2;
/*     */           }
/* 272 */           add(this.old2, d);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 277 */     return this.ddl2;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkDTP() {
/* 282 */     if (this.ddl2 == null) {
/* 283 */       return false;
/*     */     }
/*     */     
/* 286 */     StringBuffer counterBuffer = new StringBuffer();
/* 287 */     StringBuffer infoBuffer = new StringBuffer();
/*     */     
/* 289 */     boolean stp = true;
/* 290 */     for (Iterator<PlaceSet> it = this.ddl2.iterator(); it.hasNext(); ) {
/* 291 */       PlaceSet ns = it.next();
/*     */       
/* 293 */       PlaceSet maxtrap = ns.maxTrap();
/*     */       
/* 295 */       if (!maxtrap.marksPlaceSetSufficient(this.pn.getM0())) {
/* 296 */         if (this.dOptions.breakDtpComputation) {
/*     */           
/* 298 */           counterBuffer.append("    siphon:\n").append(ns.toString()).append("\n");
/*     */           
/* 300 */           if (maxtrap.isEmpty()) {
/* 301 */             counterBuffer.append("\tis a bad siphon\n");
/*     */           } else {
/* 303 */             counterBuffer.append("\tmaximal trap:\n").append(maxtrap.toString());
/* 304 */             counterBuffer.append("\n\tis not sufficiently marked\n");
/*     */           } 
/* 306 */           stp = false;
/*     */           break;
/*     */         } 
/* 309 */         counterBuffer.append("    minimal siphon:\n").append(ns.toString()).append("\n");
/*     */ 
/*     */         
/* 312 */         counterBuffer.append("\tmaximal trap:\n").append(maxtrap.toString()).append("\n");
/* 313 */         counterBuffer.append("\tis not sufficiently marked\n");
/* 314 */         stp = false; continue;
/*     */       } 
/* 316 */       if (this.dOptions.breakDtpComputation) {
/*     */         
/* 318 */         infoBuffer.append("    siphon:\n").append(ns.toString()).append("\n");
/*     */       } else {
/* 320 */         infoBuffer.append("    minimal siphon:\n").append(ns.toString()).append("\n");
/*     */       } 
/* 322 */       infoBuffer.append("\tmaximal trap:\n").append(maxtrap.toString()).append("\n");
/* 323 */       infoBuffer.append("\tis sufficiently marked\n");
/*     */     } 
/*     */ 
/*     */     
/* 327 */     if (stp) {
/* 328 */       this.info += "\nSTP is valid\n";
/* 329 */       this.info += infoBuffer.toString();
/*     */     } else {
/* 331 */       this.info += "\nSTP is not valid\n";
/* 332 */       this.info += " counter examples:\n";
/* 333 */       this.info += counterBuffer.toString();
/*     */ 
/*     */       
/* 336 */       if (!this.dOptions.breakDtpComputation) {
/* 337 */         this.info += " siphons with sufficiently marked traps:\n";
/* 338 */         this.info += infoBuffer.toString();
/*     */       } 
/*     */     } 
/*     */     
/* 342 */     return stp;
/*     */   }
/*     */   
/*     */   public boolean hasDTP() {
/* 346 */     boolean ret = checkDTP();
/*     */     
/* 348 */     addResult(14, new Result(Boolean.valueOf(ret)));
/* 349 */     addResult(26, new Result(Boolean.valueOf((this.ddl2.size() > 0))));
/* 350 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   private void add(HashSet<NodeSet> hs, NodeSet d) {
/* 355 */     HashSet<NodeSet> del = new HashSet();
/* 356 */     for (Iterator<NodeSet> iterator1 = hs.iterator(); iterator1.hasNext(); ) {
/* 357 */       NodeSet ss = iterator1.next();
/* 358 */       if (d.subSet(ss)) {
/* 359 */         del.add(ss); continue;
/* 360 */       }  if (ss.subSet(d)) {
/*     */         return;
/*     */       }
/*     */     } 
/* 364 */     for (Iterator<NodeSet> it = del.iterator(); it.hasNext();) {
/* 365 */       hs.remove(it.next());
/*     */     }
/*     */     
/* 368 */     LOG.debug("Adding " + d.toString());
/*     */     
/* 370 */     hs.add(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public Analyzer getNewInstance(OptionSet options) {
/* 375 */     DeadlockAnalyzer a = new DeadlockAnalyzer();
/* 376 */     a.setup(options);
/* 377 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {}
/*     */ 
/*     */   
/*     */   public void writeToFile(String filename) {
/* 386 */     if (filename == null || filename.equals("")) {
/*     */       return;
/*     */     }
/* 389 */     StringBuffer buf = new StringBuffer();
/* 390 */     StringBuffer comment = new StringBuffer();
/* 391 */     if (this.dOptions.properSets) {
/* 392 */       if (this.dOptions.breakDtpComputation) {
/*     */         
/* 394 */         buf.append(" proper siphon ( place )= ");
/*     */       } else {
/* 396 */         buf.append(" minimal proper siphon ( place )= ");
/*     */       }
/*     */     
/* 399 */     } else if (this.dOptions.breakDtpComputation) {
/*     */       
/* 401 */       buf.append(" siphon ( place ) = ");
/*     */     } else {
/* 403 */       buf.append(" minimal siphon ( place ) = ");
/*     */     } 
/*     */     
/* 406 */     buf.append("\n");
/* 407 */     int i = 1;
/* 408 */     int dl_count = 1;
/*     */     
/* 410 */     for (Iterator<PlaceSet> it = this.ddl2.iterator(); it.hasNext(); ) {
/* 411 */       buf.append("\n" + i);
/*     */       
/* 413 */       PlaceSet ps = it.next();
/* 414 */       buf.append(ps.toString());
/* 415 */       comment.append("\n" + i + "| siphon_" + dl_count + "| minimal siphon_" + dl_count);
/* 416 */       if (this.dOptions.computeDtp) {
/* 417 */         PlaceSet maxTrap = ps.maxTrap();
/* 418 */         boolean marksSufficient = !maxTrap.marksPlaceSetSufficient(this.pn.getM0());
/* 419 */         if (maxTrap.isEmpty()) {
/* 420 */           comment.append(" with empty maximal trap ");
/*     */         } else {
/* 422 */           comment.append(" |");
/* 423 */           i++;
/* 424 */           buf.append("\n" + i);
/* 425 */           buf.append(maxTrap.toString());
/* 426 */           comment.append("\n" + i + "| trap_" + dl_count + "|maximal trap of siphon_" + dl_count);
/*     */         } 
/* 428 */         if (marksSufficient) {
/* 429 */           comment.append(" not sufficiently marked | ");
/*     */         } else {
/* 431 */           comment.append(" sufficiently marked |");
/*     */         } 
/*     */       } 
/*     */       
/* 435 */       i++;
/* 436 */       dl_count++;
/*     */     } 
/* 438 */     buf.append("\n@\n");
/* 439 */     buf.append(comment.toString());
/* 440 */     TextFile.writeToFile(new File(filename), buf, true);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/deadlock/DeadlockAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */