/*     */ package charlie.analyzer.deadlock;
/*     */ 
/*     */ import GUI.preference.FilterFactory;
/*     */ import GUI.preference.SiphonTrapFilterPreference;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.pn.PlaceSet;
/*     */ import java.io.File;
/*     */ import java.util.HashSet;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeadlockOptions
/*     */   extends OptionSet
/*     */ {
/*     */   private static final String OPTIONS_COMPUTE = "DeadlockOptions_compute";
/*     */   private static final String OPTIONS_EXPORT = "DeadlockOptions_export";
/*     */   private static final String OPTIONS_COMPUTE_STP = "DeadlockOptions_computeDtp";
/*     */   private static final String OPTIONS_COMPUTE_BAD_SIPHONS = "DeadlockOptions_computeBadSiphons";
/*     */   private static final String OPTIONS_COMPUTE_SOUND_SIPHONS = "DeadlockOptions_computeSoundSiphons";
/*     */   private static final String OPTIONS_BREAK_STP_COMPUTATION = "DeadlockOptions_breakDtpComputation";
/*     */   private static final String OPTIONS_EXPORT_FILE = "DeadlockOptions_exportFile";
/*     */   private static final String OPTIONS_PROPER_SETS = "DeadlockOptions_properSets";
/*     */   public boolean compute = false;
/*     */   public boolean export = false;
/*     */   public boolean properSets = false;
/*     */   public boolean computeDtp = false;
/*     */   public boolean computeBadSiphons = false;
/*     */   public boolean computeSoundSiphons = false;
/*     */   public boolean breakDtpComputation = false;
/*  48 */   public File exportFile = null;
/*     */   public HashSet<PlaceSet> invSupports;
/*     */   
/*     */   public DeadlockOptions() {
/*  52 */     setLogOutput(!FilterFactory.getFilterProperties().isFiltered(SiphonTrapFilterPreference.FILTER_SIPHON_TRAP_SIPHON.getKey()));
/*  53 */     setLogOutput(!FilterFactory.getFilterProperties().isFiltered(SiphonTrapFilterPreference.FILTER_SIPHON_TRAP_STP.getKey()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties getAsProperties() {
/*  58 */     Properties p = new Properties();
/*  59 */     if (this.compute) {
/*  60 */       p.setProperty("DeadlockOptions_compute", Boolean.toString(true));
/*     */     } else {
/*  62 */       p.setProperty("DeadlockOptions_compute", Boolean.toString(false));
/*     */     } 
/*     */     
/*  65 */     if (this.computeBadSiphons) {
/*  66 */       p.setProperty("DeadlockOptions_computeBadSiphons", Boolean.toString(true));
/*     */     } else {
/*  68 */       p.setProperty("DeadlockOptions_computeBadSiphons", Boolean.toString(false));
/*     */     } 
/*  70 */     if (this.computeSoundSiphons) {
/*  71 */       p.setProperty("DeadlockOptions_computeSoundSiphons", Boolean.toString(true));
/*     */     } else {
/*  73 */       p.setProperty("DeadlockOptions_computeSoundSiphons", Boolean.toString(false));
/*     */     } 
/*     */     
/*  76 */     if (this.export) {
/*  77 */       p.setProperty("DeadlockOptions_export", Boolean.toString(true));
/*     */     } else {
/*  79 */       p.setProperty("DeadlockOptions_export", Boolean.toString(false));
/*     */     } 
/*     */     
/*  82 */     if (this.properSets) {
/*  83 */       p.setProperty("DeadlockOptions_properSets", Boolean.toString(true));
/*     */     } else {
/*  85 */       p.setProperty("DeadlockOptions_properSets", Boolean.toString(false));
/*     */     } 
/*     */     
/*  88 */     if (this.computeDtp) {
/*  89 */       p.setProperty("DeadlockOptions_computeDtp", Boolean.toString(true));
/*     */     } else {
/*  91 */       p.setProperty("DeadlockOptions_computeDtp", Boolean.toString(false));
/*     */     } 
/*  93 */     if (this.breakDtpComputation) {
/*  94 */       p.setProperty("DeadlockOptions_breakDtpComputation", Boolean.toString(true));
/*     */     } else {
/*  96 */       p.setProperty("DeadlockOptions_breakDtpComputation", Boolean.toString(false));
/*     */     } 
/*     */     
/*  99 */     if (this.exportFile != null) {
/* 100 */       p.setProperty("DeadlockOptions_exportFile", this.exportFile.getAbsolutePath());
/*     */     }
/* 102 */     return p;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initByProperties(Properties p) {
/* 107 */     String s = p.getProperty("DeadlockOptions_compute");
/* 108 */     if (s != null) {
/* 109 */       if (s.equals("true")) {
/* 110 */         this.compute = true;
/* 111 */       } else if (s.equals("false")) {
/* 112 */         this.compute = false;
/*     */       } 
/*     */     }
/* 115 */     s = null;
/* 116 */     s = p.getProperty("DeadlockOptions_export");
/* 117 */     if (s != null) {
/* 118 */       if (s.equals("true")) {
/* 119 */         this.export = true;
/* 120 */       } else if (s.equals("false")) {
/* 121 */         this.export = false;
/*     */       } 
/*     */     }
/*     */     
/* 125 */     s = null;
/* 126 */     s = p.getProperty("DeadlockOptions_computeBadSiphons");
/* 127 */     if (s != null) {
/* 128 */       if (s.equals("true")) {
/* 129 */         this.computeBadSiphons = true;
/* 130 */       } else if (s.equals("false")) {
/* 131 */         this.computeBadSiphons = false;
/*     */       } 
/*     */     }
/*     */     
/* 135 */     s = null;
/* 136 */     s = p.getProperty("DeadlockOptions_computeSoundSiphons");
/* 137 */     if (s != null) {
/* 138 */       if (s.equals("true")) {
/* 139 */         this.computeSoundSiphons = true;
/* 140 */       } else if (s.equals("false")) {
/* 141 */         this.computeSoundSiphons = false;
/*     */       } 
/*     */     }
/*     */     
/* 145 */     s = null;
/* 146 */     s = p.getProperty("DeadlockOptions_properSets");
/* 147 */     if (s != null) {
/* 148 */       if (s.equals("true")) {
/* 149 */         this.properSets = true;
/* 150 */       } else if (s.equals("false")) {
/* 151 */         this.properSets = false;
/*     */       } 
/*     */     }
/* 154 */     s = null;
/* 155 */     s = p.getProperty("DeadlockOptions_computeDtp");
/* 156 */     if (s != null) {
/* 157 */       if (s.equals("true")) {
/* 158 */         this.computeDtp = true;
/* 159 */       } else if (s.equals("false")) {
/* 160 */         this.computeDtp = false;
/*     */       } 
/*     */     }
/* 163 */     s = p.getProperty("DeadlockOptions_breakDtpComputation");
/* 164 */     if (s != null) {
/* 165 */       if (s.equals("true")) {
/* 166 */         this.breakDtpComputation = true;
/* 167 */       } else if (s.equals("false")) {
/* 168 */         this.breakDtpComputation = false;
/*     */       } 
/*     */     }
/* 171 */     s = null;
/* 172 */     s = p.getProperty("DeadlockOptions_exportFile");
/* 173 */     if (s != null && 
/* 174 */       !s.equals("")) {
/* 175 */       this.exportFile = new File(s);
/*     */     }
/*     */     
/* 178 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHtmlInfo() {
/* 183 */     StringBuffer buf = new StringBuffer();
/* 184 */     buf.append("<html><table>");
/* 185 */     buf.append("<tr><td width=\"200px\">");
/* 186 */     buf.append("siphon options");
/* 187 */     buf.append("</td><td width=\"200px\"></td></tr>");
/* 188 */     buf.append("<tr><td>");
/* 189 */     buf.append("exportFile");
/* 190 */     buf.append("</td><td>");
/* 191 */     if (this.exportFile != null) {
/* 192 */       buf.append(this.exportFile.getName());
/*     */     } else {
/* 194 */       buf.append("not set!");
/*     */     } 
/* 196 */     buf.append("</td></tr>");
/*     */     
/* 198 */     buf.append("<tr><td>");
/* 199 */     buf.append("properSets");
/* 200 */     buf.append("</td><td>");
/* 201 */     buf.append(Boolean.toString(this.properSets));
/* 202 */     buf.append("</td></tr>");
/* 203 */     buf.append("<tr><td>");
/* 204 */     buf.append("compute siphon trap property");
/* 205 */     buf.append("</td><td>");
/* 206 */     buf.append(Boolean.toString(this.computeDtp));
/* 207 */     buf.append("</td></tr>");
/* 208 */     buf.append("<tr><td>");
/* 209 */     buf.append("compute bad siphons only");
/* 210 */     buf.append("</td><td>");
/* 211 */     buf.append(Boolean.toString(this.computeBadSiphons));
/* 212 */     buf.append("</td></tr>");
/* 213 */     buf.append("<tr><td>");
/* 214 */     buf.append("compute sound siphons only");
/* 215 */     buf.append("</td><td>");
/* 216 */     buf.append(Boolean.toString(this.computeSoundSiphons));
/* 217 */     buf.append("</td></tr>");
/* 218 */     buf.append("<tr><td>");
/* 219 */     buf.append("export");
/* 220 */     buf.append("</td><td>");
/* 221 */     buf.append(Boolean.toString(this.export));
/* 222 */     buf.append("</td></tr>");
/* 223 */     buf.append("<tr><td>");
/* 224 */     buf.append("compute siphons");
/* 225 */     buf.append("</td><td>");
/* 226 */     buf.append(Boolean.toString(this.compute));
/* 227 */     buf.append("</td></tr>");
/* 228 */     buf.append("</table></html>");
/* 229 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initializeByString(String parameters) {
/*     */     try {
/* 235 */       this.compute = true;
/* 236 */       this.properSets = getValue(parameters, "properSets", this.properSets);
/* 237 */       this.computeDtp = getValue(parameters, "computeDtp", this.computeDtp);
/* 238 */       this.exportFile = getValue(parameters, "exportFile", this.exportFile);
/* 239 */       this.computeBadSiphons = getValue(parameters, "computeBadSiphons", this.computeBadSiphons);
/* 240 */       this.computeSoundSiphons = getValue(parameters, "computeSoundSiphons", this.computeSoundSiphons);
/* 241 */       if (this.exportFile != null && this.exportFile.exists()) {
/* 242 */         this.export = true;
/*     */       }
/* 244 */     } catch (Exception e) {
/* 245 */       e.printStackTrace();
/* 246 */       System.out.printf(getHelpString(), new Object[0]);
/* 247 */       return false;
/*     */     } 
/* 249 */     return true;
/*     */   }
/*     */   
/*     */   public static String getHelpString() {
/* 253 */     StringBuilder buf = new StringBuilder();
/* 254 */     buf.append("\nDeadlock computation options\n");
/* 255 */     buf.append("----------------------------\n");
/* 256 */     buf.append("Invoke analysis by typing --analyze=siphon\n\n");
/* 257 */     String fS = "%30s | %-30s\n";
/* 258 */     buf.append(String.format(fS, new Object[] { "option name", "option values" }));
/* 259 */     buf.append(String.format(fS, new Object[] { "--properSets", "0 = no / 1 = yes" }));
/* 260 */     buf.append(String.format(fS, new Object[] { "", "compute the proper sets" }));
/* 261 */     buf.append(String.format(fS, new Object[] { "--computeDtp", "0 = no / 1 = yes" }));
/* 262 */     buf.append(String.format(fS, new Object[] { "", "compute the siphon trap property" }));
/* 263 */     buf.append(String.format(fS, new Object[] { "--breakDtpComputation", "0 = no / 1 = yes" }));
/* 264 */     buf.append(String.format(fS, new Object[] { "", "break the computation when finding a bad siphon" }));
/* 265 */     buf.append(String.format(fS, new Object[] { "--computeBadSiphons", "0 = no / 1 = yes" }));
/* 266 */     buf.append(String.format(fS, new Object[] { "", "compute bad siphons only" }));
/* 267 */     buf.append(String.format(fS, new Object[] { "--computeSoundSiphons", "0 = no / 1 = yes" }));
/* 268 */     buf.append(String.format(fS, new Object[] { "", "compute sound siphons only" }));
/* 269 */     buf.append(String.format(fS, new Object[] { "--exportFile", "path to a file, if the file exists" }));
/* 270 */     buf.append(String.format(fS, new Object[] { "", "it will be overwritten!" }));
/* 271 */     buf.append("\n");
/* 272 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 277 */     return "siphon options";
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/deadlock/DeadlockOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */