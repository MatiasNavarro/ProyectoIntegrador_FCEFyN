/*    */ package charlie.analyzer.deadlock;
/*    */ 
/*    */ import GUI.util.TextFile;
/*    */ import charlie.pn.PlaceSet;
/*    */ import java.io.File;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeadlockSet
/*    */   extends HashSet<PlaceSet>
/*    */ {
/*    */   private static final long serialVersionUID = 5926400675722788333L;
/*    */   public boolean proper = false;
/*    */   public boolean dtp = false;
/* 18 */   public HashSet<PlaceSet> notMarked = new HashSet<>();
/*    */   
/*    */   public void writeToFile(String filename) {
/* 21 */     if (filename == null || filename.equals("")) {
/*    */       return;
/*    */     }
/*    */     
/* 25 */     TextFile.writeToFile(new File(filename), toString(), true);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 30 */     StringBuffer buf = new StringBuffer();
/* 31 */     if (this.proper) {
/* 32 */       buf.append(" minimal proper siphons ( place ) = ");
/*    */     } else {
/* 34 */       buf.append(" minimal siphons ( place ) = ");
/*    */     } 
/* 36 */     buf.append("\n");
/* 37 */     int i = 1;
/* 38 */     for (Iterator<PlaceSet> it = iterator(); it.hasNext(); ) {
/* 39 */       buf.append("\n" + i);
/* 40 */       PlaceSet ps = it.next();
/* 41 */       buf.append(ps.toString());
/* 42 */       if (this.dtp) {
/* 43 */         buf.append("\n\tmaximal trap (place): \n");
/* 44 */         buf.append(ps.maxTrap());
/* 45 */         if (this.notMarked.contains(ps)) {
/* 46 */           buf.append("\n\tnot sufficiently marked");
/*    */         } else {
/* 48 */           buf.append("\n\tsufficiently marked");
/*    */         } 
/*    */       } 
/* 51 */       i++;
/*    */     } 
/* 53 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/deadlock/DeadlockSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */