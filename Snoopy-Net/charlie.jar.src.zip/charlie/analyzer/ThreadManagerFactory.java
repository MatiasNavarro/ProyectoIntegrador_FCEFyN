/*   */ package charlie.analyzer;
/*   */ 
/*   */ public class ThreadManagerFactory
/*   */ {
/* 5 */   private static ThreadManager threadManager = new ThreadManager();
/*   */   
/*   */   public static ThreadManager getThreadManager() {
/* 8 */     return threadManager;
/*   */   }
/*   */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/ThreadManagerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */