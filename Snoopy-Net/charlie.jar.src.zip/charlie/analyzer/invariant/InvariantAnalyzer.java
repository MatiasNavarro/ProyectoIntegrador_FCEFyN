/*     */ package charlie.analyzer.invariant;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.ds.BitSet;
/*     */ import charlie.ds.Stack;
/*     */ import charlie.ds.sm.ExtendedIncMatrix;
/*     */ import charlie.ds.sm.SparseMatrix;
/*     */ import charlie.ds.sm.SupportCheck;
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.NodeSet;
/*     */ import charlie.pn.Out;
/*     */ import charlie.pn.PlaceSet;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Result;
/*     */ import charlie.pn.TransitionSet;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ public class InvariantAnalyzer
/*     */   extends Analyzer
/*     */ {
/*  29 */   private static final Log LOG = LogFactory.getLog(InvariantAnalyzer.class);
/*     */ 
/*     */ 
/*     */   
/*  33 */   private String invTitle = "minimal semipositive";
/*  34 */   protected SparseMatrix simpleIncMatrix = null;
/*     */   
/*  36 */   protected PlaceTransitionNet pn = null;
/*  37 */   protected PInvariantSet pInvariants = null;
/*  38 */   protected TInvariantSet tInvariants = null;
/*  39 */   protected InvOptions io = null;
/*  40 */   protected BitSet bitSet = null;
/*  41 */   protected SupportCheck sc = new SupportCheck();
/*     */   
/*     */   public InvariantAnalyzer() {
/*  44 */     setUpdateInterval(250L);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  49 */     return "InvariantAnalyzer";
/*     */   }
/*     */   
/*     */   public static boolean register() {
/*  53 */     InvariantAnalyzer ia = new InvariantAnalyzer();
/*  54 */     PlaceTransitionNet pn = new PlaceTransitionNet();
/*  55 */     boolean b1 = AnalyzerManagerFactory.getAnalyzerManager().register(ia, pn, new PInvariantSet());
/*  56 */     boolean b2 = AnalyzerManagerFactory.getAnalyzerManager().register(ia, pn, new TInvariantSet());
/*  57 */     if (b1 && b2) {
/*  58 */       return true;
/*     */     }
/*  60 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Analyzer getNewInstance(OptionSet options) {
/*  66 */     InvariantAnalyzer a = new InvariantAnalyzer();
/*  67 */     a.setup(options);
/*     */     
/*  69 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeInfoStrings() {
/*  78 */     int count = 4;
/*  79 */     this.infoStrings = new String[count];
/*  80 */     Arrays.fill((Object[])this.infoStrings, "");
/*  81 */     if (this.io != null && this.options != null && this.options instanceof InvOptions) {
/*  82 */       this.io = (InvOptions)this.options;
/*     */     }
/*  84 */     if (this.io != null) {
/*  85 */       if (this.io.isComputeTInvariants()) {
/*  86 */         this.infoStrings[0] = "t-invariants:";
/*     */       } else {
/*  88 */         this.infoStrings[0] = "p-invariants:";
/*     */       } 
/*  90 */       if (this.tInvariants != null) {
/*  91 */         this.infoStrings[1] = Integer.toString(this.tInvariants.rows());
/*  92 */       } else if (this.pInvariants != null) {
/*  93 */         this.infoStrings[1] = Integer.toString(this.pInvariants.rows());
/*     */       } else {
/*  95 */         this.infoStrings[1] = "0";
/*     */       } 
/*  97 */       this.infoStrings[2] = "time:";
/*  98 */       this.infoStrings[3] = getFormatedDuration();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluate() {
/* 108 */     this.io = (InvOptions)this.options;
/* 109 */     if (this.io.isComputeTInvariants()) {
/* 110 */       evaluateTInvariants();
/* 111 */       if (this.io.exportFile != null) {
/* 112 */         this.tInvariants.writeToFile(this.io.exportFile, this.invTitle + " transition invariants=");
/*     */       }
/*     */     } else {
/* 115 */       evaluatePInvariants();
/* 116 */       if (this.io.exportFile != null) {
/* 117 */         this.pInvariants.writeToFile(this.io.exportFile, this.invTitle + " place invariants=");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readOptions() {
/* 128 */     this.pn = (PlaceTransitionNet)this.options.getObjectToAnalyze();
/* 129 */     this.io = (InvOptions)this.options;
/*     */   }
/*     */ 
/*     */   
/*     */   public void analyze() {
/* 134 */     this.pn = (PlaceTransitionNet)this.options.getObjectToAnalyze();
/* 135 */     this.io = (InvOptions)this.options;
/*     */ 
/*     */     
/* 138 */     this.simpleIncMatrix = null;
/* 139 */     this.bitSet = null;
/* 140 */     this.sc = new SupportCheck();
/*     */     
/* 142 */     if (this.options.getResultObject() instanceof PInvariantSet) {
/* 143 */       PInvariantSet tP = (PInvariantSet)this.options.getResultObject();
/* 144 */       if (tP.rows() > 0) {
/* 145 */         addOutput("Invariant Analyzer: evaluating loaded P-Invariants\n");
/* 146 */         this.pInvariants = tP;
/* 147 */         this.pInvariants.pn = this.pn;
/*     */         
/*     */         return;
/*     */       } 
/* 151 */       addOutput("Invariant Analyzer: computing P-Invariants\n");
/* 152 */       this.pInvariants = null;
/* 153 */       calculatePInvariants();
/* 154 */       this.pInvariants.pn = this.pn;
/* 155 */     } else if (this.options.getResultObject() instanceof TInvariantSet) {
/* 156 */       TInvariantSet tT = (TInvariantSet)this.options.getResultObject();
/* 157 */       if (tT.rows() > 0) {
/* 158 */         addOutput("Invariant Analyzer: evaluating loaded T-Invariants\n");
/* 159 */         this.tInvariants = tT;
/* 160 */         this.tInvariants.pn = this.pn;
/*     */         return;
/*     */       } 
/* 163 */       addOutput("Invariant Analyzer: computing T-Invariants\n");
/* 164 */       this.tInvariants = null;
/* 165 */       calculateTInvariants();
/* 166 */       this.tInvariants.pn = this.pn;
/*     */     } else {
/* 168 */       DebugCounter.inc("InvariantAnalyzer no ResultObject specified!\n");
/*     */     } 
/* 170 */     DebugCounter.inc("InvariantAnalyzer required Time:" + getFormatedDuration());
/*     */   }
/*     */   
/*     */   private void calculatePInvariants() {
/* 174 */     this.simpleIncMatrix = new SparseMatrix(getSimpleIncP());
/* 175 */     ExtendedIncMatrix sm = new ExtendedIncMatrix(getIncP(), this.pn.places());
/* 176 */     this.pInvariants = new PInvariantSet(this.pn.places());
/*     */     try {
/* 178 */       solve(sm);
/* 179 */       for (int i = 0; i < sm.rows(); i++) {
/* 180 */         this.pInvariants.addRow(sm.getInvariant(i));
/*     */       }
/* 182 */       this.pInvariants.applyGcdDeviding();
/* 183 */       computeBoundedness();
/* 184 */       deleteTrivial(this.pInvariants);
/* 185 */       this.options.setResultObject(this.pInvariants);
/* 186 */     } catch (Exception e) {
/* 187 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected int[][] getIncP() {
/* 192 */     int[][] incMatrix = new int[this.pn.places()][this.pn.transitions() + this.pn.places()];
/*     */     
/* 194 */     for (int i = 0; i < this.pn.places(); i++) {
/* 195 */       for (int j = 0; j < this.pn.transitions(); j++) {
/*     */         try {
/* 197 */           incMatrix[i][j] = this.pn.changesTokenOn(this.pn.getPlaceByIndex(i), this.pn.getTransition((short)j));
/* 198 */         } catch (Exception e) {
/* 199 */           LOG.error(e.getMessage(), e);
/*     */         } 
/*     */       } 
/* 202 */       incMatrix[i][i + this.pn.transitions()] = 1;
/*     */     } 
/*     */     
/* 205 */     return incMatrix;
/*     */   }
/*     */   
/*     */   protected int[][] getSimpleIncP() {
/* 209 */     Out.println(this.pn);
/* 210 */     int[][] incMatrix = new int[this.pn.places()][this.pn.transitions()];
/* 211 */     for (int i = 0; i < this.pn.places(); i++) {
/* 212 */       for (int j = 0; j < this.pn.transitions(); j++) {
/*     */         try {
/* 214 */           incMatrix[i][j] = this.pn.changesTokenOn(this.pn.getPlaceByIndex(i), this.pn
/* 215 */               .getTransition((short)j));
/* 216 */         } catch (Exception e) {
/* 217 */           LOG.error(e.getMessage(), e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     return incMatrix;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[][] getIncT() {
/* 227 */     int[][] incMatrix = new int[this.pn.transitions()][this.pn.transitions() + this.pn.places()];
/*     */     
/* 229 */     for (int i = 0; i < this.pn.transitions(); i++) {
/* 230 */       for (int j = 0; j < this.pn.places(); j++) {
/*     */         try {
/* 232 */           incMatrix[i][j] = this.pn.changesTokenOn(this.pn.getPlaceByIndex(j), this.pn
/* 233 */               .getTransition((short)i));
/* 234 */         } catch (Exception e) {
/* 235 */           LOG.error(e.getMessage(), e);
/*     */         } 
/*     */       } 
/* 238 */       incMatrix[i][i + this.pn.places()] = 1;
/*     */     } 
/* 240 */     return incMatrix;
/*     */   }
/*     */   
/*     */   public int[][] getSimpleIncT() {
/* 244 */     int[][] incMatrix = new int[this.pn.transitions()][this.pn.places()];
/*     */     
/* 246 */     for (int i = 0; i < this.pn.transitions(); i++) {
/* 247 */       for (int j = 0; j < this.pn.places(); j++) {
/*     */         try {
/* 249 */           incMatrix[i][j] = this.pn.changesTokenOn(this.pn.getPlaceByIndex(j), this.pn
/* 250 */               .getTransition((short)i));
/* 251 */         } catch (Exception e) {
/* 252 */           LOG.error(e.getMessage(), e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 258 */     return incMatrix;
/*     */   }
/*     */   
/*     */   public void deleteTrivial(SparseMatrix sm) {
/*     */     try {
/* 263 */       Stack<Integer> st = new Stack();
/*     */       
/* 265 */       if (this.io.deleteTrivial) {
/* 266 */         for (int i = 0; i < sm.rows(); i++) {
/* 267 */           BitSet bs = sm.getSupport(i);
/* 268 */           if (bs.size() == 2) {
/* 269 */             st.push(new Integer(i));
/*     */           }
/*     */         } 
/* 272 */         while (!st.isEmpty()) {
/* 273 */           sm.deleteRow(((Integer)st.pop()).intValue());
/*     */         }
/*     */       } 
/* 276 */     } catch (Exception e) {
/* 277 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void calculateTInvariants() {
/* 284 */     this.simpleIncMatrix = new SparseMatrix(getSimpleIncT());
/* 285 */     ExtendedIncMatrix sm = new ExtendedIncMatrix(getIncT(), this.pn.transitions());
/* 286 */     this.tInvariants = new TInvariantSet(this.pn.transitions());
/*     */     
/*     */     try {
/* 289 */       solve(sm);
/* 290 */       for (int i = 0; i < sm.rows(); i++) {
/* 291 */         this.tInvariants.addRow(sm.getInvariant(i));
/*     */       }
/* 293 */       this.tInvariants.applyGcdDeviding();
/* 294 */       deleteTrivial(this.tInvariants);
/* 295 */       this.options.setResultObject(this.tInvariants);
/* 296 */     } catch (Exception e) {
/* 297 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void solve(ExtendedIncMatrix sm) {
/*     */     try {
/* 303 */       if (this.io.isComputeTInvariants()) {
/* 304 */         DebugCounter.inc("InvariantAnalyzer.solve(): solving T Invariant");
/*     */       } else {
/* 306 */         DebugCounter.inc("InvariantAnalyzer.solve(): solving P Invariant");
/*     */       } 
/* 308 */       this.bitSet = new BitSet(this.simpleIncMatrix.rowLength);
/*     */       
/* 310 */       long inv = 0L;
/*     */ 
/*     */       
/* 313 */       BitSet union = new BitSet(sm.identity);
/* 314 */       BitSet h1 = new BitSet(sm.identity);
/*     */ 
/*     */       
/* 317 */       for (int i = 0; i < sm.rows(); i++) {
/* 318 */         sm.actualizeTablesAdd(i);
/*     */       }
/* 320 */       sm.max();
/*     */       
/* 322 */       int count = 0;
/* 323 */       while (sm.max() > 0 && this.status != 4) {
/* 324 */         int currentRows = sm.lastRow;
/* 325 */         count += sm.getZero().size();
/* 326 */         int col = sm.minCol();
/*     */         
/* 328 */         if (col < 0) {
/*     */           break;
/*     */         }
/* 331 */         count++;
/*     */         
/* 333 */         currentRows = sm.lastRow;
/* 334 */         for (int k = 0; k < currentRows && this.status != 4; k++) {
/* 335 */           int col1 = sm.containsColumnIndex(k, col);
/* 336 */           if (col1 >= 0) {
/* 337 */             sm.getSupport(k, h1);
/* 338 */             if (!this.sc.checkMin(h1)) {
/* 339 */               for (int m = k + 1; m < currentRows && this.status != 4; m++) {
/* 340 */                 int col2 = sm.containsColumnIndex(m, col);
/* 341 */                 if (col2 >= 0) {
/* 342 */                   long test = (sm.getValue(col1) * sm.getValue(col2));
/* 343 */                   if (test < 0L) {
/* 344 */                     sm.getSupport(k, union);
/* 345 */                     sm.getSupport(m, h1);
/* 346 */                     union.union(h1);
/* 347 */                     if (!this.sc.checkMin(union)) {
/* 348 */                       if (sm.getValue(col1) == -1 * sm.getValue(col2)) {
/* 349 */                         sm.addSumOfRows(k, m);
/*     */                       } else {
/* 351 */                         int factor2 = Math.abs(sm.getValue(col2));
/* 352 */                         int factor1 = Math.abs(sm.getValue(col1));
/* 353 */                         sm.addSumOfRows(k, factor1, m, factor2);
/* 354 */                         sm.applyGcdDevidingOnRow(sm.lastRow - 1);
/*     */                       } 
/* 356 */                       h1 = sm.getSupport(sm.lastRow - 1);
/*     */                       
/* 358 */                       if (h1.size() > upperBound(h1) + 1) {
/* 359 */                         sm.actualizeTablesDelete(sm.lastRow - 1);
/* 360 */                         sm.deleteLastRow();
/* 361 */                       } else if (sm.getFirstColumnIndex(sm.lastRow - 1) >= sm.rowLength - sm.identity && sm
/* 362 */                         .homogenousRow(sm.lastRow - 1)) {
/* 363 */                         this.sc.add2(sm.getSupport(sm.lastRow - 1));
/* 364 */                         sm.applyGcdDevidingOnRow(sm.lastRow - 1);
/*     */                       } else {
/* 366 */                         sm.actualizeTablesAdd(sm.lastRow - 1);
/*     */                       } 
/* 368 */                       sm.applyGcdDevidingOnRow(sm.lastRow - 1);
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 377 */                 if (!checkStatus()) {
/* 378 */                   cleanup();
/*     */                   
/*     */                   return;
/*     */                 } 
/*     */               } 
/*     */             }
/* 384 */             sm.insert(k);
/*     */           } 
/*     */           
/* 387 */           if (inv != this.sc.bddSize()) {
/* 388 */             inv = this.sc.sizeOfMin();
/* 389 */             for (int m = 0; m < sm.rows(); m++) {
/* 390 */               sm.getSupport(m, h1);
/*     */               
/* 392 */               if (this.sc.checkMin2(h1)) {
/* 393 */                 sm.insert(m);
/*     */               }
/*     */               
/* 396 */               if (!checkStatus()) {
/* 397 */                 cleanup();
/*     */                 
/*     */                 return;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 404 */         sm.deleteMarkedRows2();
/*     */       } 
/*     */       
/* 407 */       if (this.status == 4) {
/* 408 */         LOG.info("canceled");
/*     */         
/*     */         return;
/*     */       } 
/* 412 */       HashSet<BitSet> del = new HashSet<>();
/* 413 */       SupportCheck sc = new SupportCheck();
/* 414 */       for (int j = 0; j < sm.rows(); j++) {
/* 415 */         sc.checkRemaining(sm.getSupport(j), del, sm.getSupport(j));
/* 416 */         if (!checkStatus()) {
/* 417 */           cleanup();
/*     */           return;
/*     */         } 
/*     */       } 
/* 421 */       for (Iterator<BitSet> it = del.iterator(); it.hasNext(); ) {
/* 422 */         int index = sm.getRowIndex(it.next());
/* 423 */         if (index >= 0) {
/* 424 */           sm.insert(index);
/*     */         }
/* 426 */         if (!checkStatus()) {
/* 427 */           cleanup();
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 432 */       sm.deleteMarkedRows2();
/* 433 */     } catch (Exception e) {
/* 434 */       LOG.error(e.getMessage(), e);
/* 435 */     } catch (Error e) {
/* 436 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCoveredByPInvariants() {
/* 446 */     if (this.pInvariants != null) {
/* 447 */       return checkCoverage(this.pInvariants, this.pn.places());
/*     */     }
/* 449 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCoveredByTInvariants() {
/* 458 */     if (this.tInvariants != null) {
/* 459 */       return checkCoverage(this.tInvariants, this.pn.transitions());
/*     */     }
/* 461 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkCoverage(SparseMatrix sm, int size) {
/* 473 */     BitSet supportUnion = new BitSet(size);
/* 474 */     for (int i = 0; i < sm.rows(); i++) {
/*     */       try {
/* 476 */         supportUnion.union(sm.getSupport(i));
/* 477 */       } catch (Exception e) {
/* 478 */         LOG.error(e.getMessage(), e);
/*     */       } 
/*     */     } 
/* 481 */     DebugCounter.inc("InvariantAnalyzer.checkCoverage(): supportUnion.size=" + 
/* 482 */         String.valueOf(supportUnion.size()) + " size = " + 
/* 483 */         String.valueOf(size));
/* 484 */     return (supportUnion.size() == size);
/*     */   }
/*     */   
/*     */   private void evaluatePInvariants() {
/* 488 */     if (this.pInvariants == null) {
/* 489 */       LOG.warn("InvariantAnalyzer.evaluatePInvariants: P Invariants not yet computed ");
/*     */       return;
/*     */     } 
/* 492 */     if (this.pn == null) {
/* 493 */       LOG.warn("InvariantAnalyzer.evaluatePInvariants: no PN set on InvariantAnalyzer ");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 499 */       if (this.io.coverage) {
/* 500 */         if (isCoveredByPInvariants()) {
/* 501 */           addResult(15, new Result(new Boolean(true)));
/*     */         } else {
/* 503 */           addOutput("check coverage:\nnet is NOT covered by P-Invariants (CPI) because of:\n" + 
/* 504 */               preventCoverage(this.pInvariants));
/* 505 */           addResult(15, new Result(new Boolean(false)));
/*     */         } 
/*     */       }
/* 508 */       if (this.pInvariants != null) {
/* 509 */         addOutput(this.invTitle + " place invariants: \n" + this.pInvariants.rows());
/*     */       }
/* 511 */     } catch (Exception e) {
/* 512 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void evaluateTInvariants() {
/* 517 */     if (this.tInvariants == null) {
/* 518 */       DebugCounter.inc("InvariantAnalyzer.evaluateTInvariants: T Invariants not yet computed ");
/*     */       return;
/*     */     } 
/* 521 */     if (this.pn == null) {
/* 522 */       DebugCounter.inc("InvariantAnalyzer.evaluateTInvariants: no PN set on InvariantAnalyzer ");
/*     */       return;
/*     */     } 
/*     */     try {
/* 526 */       if (this.io.coverage) {
/* 527 */         if (isCoveredByTInvariants()) {
/* 528 */           addOutput("check coverage:\nnet is covered by T-Invariants");
/* 529 */           addResult(16, new Result(new Boolean(true)));
/*     */         } else {
/*     */           
/* 532 */           addOutput("check coverage:\nnet is NOT covered by T-Invariants" + 
/* 533 */               preventCoverage(this.tInvariants));
/* 534 */           addResult(16, new Result(new Boolean(false)));
/*     */         } 
/*     */       }
/*     */       
/* 538 */       if (this.io.extendedCoverage) {
/* 539 */         if (supportStrongCoverage(this.tInvariants).size() == this.pn.transitions()) {
/* 540 */           DebugCounter.inc("net does is support strong Coverage by T Invariants");
/* 541 */           addOutput("net does is support strong Coverage by T Invariants");
/* 542 */           addResult(17, new Result(new Boolean(true)));
/*     */         } else {
/* 544 */           DebugCounter.inc("net does is not support strong Coverage by T Invariants");
/* 545 */           addOutput("net does is not support strong Coverage by T Invariants");
/* 546 */           addResult(17, new Result(new Boolean(false)));
/* 547 */           addOutput("not SCTI because of:" + preventStrongCoverage(this.tInvariants).toString());
/*     */         } 
/*     */       }
/* 550 */       if (this.tInvariants != null) {
/* 551 */         addOutput(this.invTitle + " transition invariants:\n" + this.tInvariants.rows());
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 556 */     catch (Exception e) {
/* 557 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public BitSet supportCoverage(SparseMatrix sm) {
/* 562 */     BitSet supportUnion = new BitSet(determineSize());
/* 563 */     for (int i = 0; i < sm.rows(); i++) {
/*     */       try {
/* 565 */         BitSet bs = sm.getSupport(i);
/* 566 */         supportUnion.union(bs);
/* 567 */       } catch (Exception e) {
/* 568 */         LOG.error(e.getMessage(), e);
/*     */       } 
/*     */     } 
/*     */     
/* 572 */     return supportUnion;
/*     */   }
/*     */   
/*     */   public BitSet supportStrongCoverage(SparseMatrix sm) {
/* 576 */     BitSet supportUnion = new BitSet(determineSize());
/* 577 */     for (int i = 0; i < sm.rows(); i++) {
/*     */       try {
/* 579 */         BitSet bs = sm.getSupport(i);
/* 580 */         if (bs.size() != 2) {
/* 581 */           supportUnion.union(bs);
/*     */         }
/* 583 */       } catch (Exception e) {
/* 584 */         LOG.error(e.getMessage(), e);
/*     */       } 
/*     */     } 
/*     */     
/* 588 */     return supportUnion;
/*     */   }
/*     */   
/*     */   private int determineSize() {
/* 592 */     if (this.io.isComputeTInvariants()) {
/* 593 */       return this.pn.transitions();
/*     */     }
/* 595 */     return this.pn.places();
/*     */   }
/*     */   
/*     */   private BitSet preventsSC(SparseMatrix sm) {
/* 599 */     BitSet all = new BitSet(determineSize(), determineSize());
/* 600 */     BitSet supp = supportStrongCoverage(sm);
/* 601 */     all.diff(supp);
/*     */     
/* 603 */     return all;
/*     */   }
/*     */   
/*     */   private BitSet preventsC(SparseMatrix sm) {
/* 607 */     BitSet all = new BitSet(determineSize(), determineSize());
/* 608 */     BitSet supp = supportCoverage(sm);
/* 609 */     all.diff(supp);
/*     */     
/* 611 */     return all;
/*     */   }
/*     */   
/*     */   private NodeSet preventStrongCoverage(SparseMatrix sm) {
/* 615 */     if (this.io.isComputeTInvariants()) {
/* 616 */       return (NodeSet)new TransitionSet(preventsSC(sm));
/*     */     }
/* 618 */     return (NodeSet)new PlaceSet(preventsSC(sm));
/*     */   }
/*     */ 
/*     */   
/*     */   private NodeSet preventCoverage(SparseMatrix sm) {
/* 623 */     if (this.io.isComputeTInvariants()) {
/* 624 */       return (NodeSet)new TransitionSet(preventsC(sm));
/*     */     }
/* 626 */     return (NodeSet)new PlaceSet(preventsC(sm));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int upperBound(BitSet bs) {
/*     */     try {
/* 633 */       this.bitSet.clear();
/* 634 */       for (Iterator<Integer> it = bs.iterator(); it.hasNext(); ) {
/* 635 */         int rowIndex = ((Integer)it.next()).intValue();
/*     */         
/* 637 */         BitSet h = this.simpleIncMatrix.getSupport(rowIndex);
/*     */         
/* 639 */         this.bitSet.union(h);
/*     */       } 
/*     */       
/* 642 */       return this.bitSet.size();
/* 643 */     } catch (Exception e) {
/* 644 */       LOG.error(e.getMessage(), e);
/*     */ 
/*     */       
/* 647 */       return -1;
/*     */     } 
/*     */   }
/*     */   private SparseMatrix computeBoundedness() {
/* 651 */     SparseMatrix res = null;
/*     */     try {
/* 653 */       if (this.pInvariants == null) {
/* 654 */         return null;
/*     */       }
/*     */       
/* 657 */       int[] bt = new int[this.pn.places()];
/* 658 */       int[] btmin = new int[this.pn.places()];
/* 659 */       for (int i = 0; i < btmin.length; i++) {
/* 660 */         btmin[i] = Integer.MAX_VALUE;
/*     */       }
/* 662 */       Marking m0 = this.pn.getM0();
/* 663 */       int weight = 0;
/*     */       
/* 665 */       for (int row = 0; row < this.pInvariants.rows(); row++) {
/* 666 */         for (int m = 0; m < bt.length; m++) {
/* 667 */           bt[m] = 0;
/*     */         }
/* 669 */         weight = 0;
/* 670 */         bt = this.pInvariants.getRow(row);
/*     */         
/* 672 */         int k = 0;
/*     */         int n;
/* 674 */         for (n = 0; n < m0.size(); n++) {
/* 675 */           int pId = m0.getId(n);
/* 676 */           while (this.pn.getPlaceByIndex(k).getId() != pId && k < this.pn
/* 677 */             .places()) {
/* 678 */             k++;
/*     */           }
/* 680 */           if (k < this.pn.places() && this.pn.getPlaceByIndex(k).getId() == pId) {
/* 681 */             int token = m0.getToken(n);
/* 682 */             weight += token * bt[k];
/*     */           } 
/*     */         } 
/*     */         
/* 686 */         for (n = 0; n < bt.length; n++) {
/* 687 */           if (bt[n] != 0) {
/* 688 */             bt[n] = weight / bt[n];
/*     */             
/* 690 */             if (bt[n] == 0) {
/* 691 */               bt[n] = weight;
/*     */             }
/* 693 */             if (bt[n] < btmin[n]) {
/* 694 */               btmin[n] = bt[n];
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 699 */       for (int j = 0; j < btmin.length; j++) {
/* 700 */         this.pn.getPlaceByIndex(j).setBoundedness(btmin[j]);
/*     */       }
/* 702 */       res = new SparseMatrix(btmin.length);
/*     */       
/* 704 */       res.addRow(btmin);
/*     */       
/* 706 */       this.pn.boundednessChecked = true;
/* 707 */     } catch (Exception e) {
/* 708 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 711 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {}
/*     */ 
/*     */   
/*     */   public String getIncMatrixMatlab() {
/*     */     int[][] matrix;
/* 721 */     if (this.options.getResultObject() instanceof PInvariantSet) {
/* 722 */       matrix = getSimpleIncP();
/*     */     } else {
/* 724 */       matrix = getSimpleIncT();
/*     */     } 
/* 726 */     return incMatrixToMatlab(matrix);
/*     */   }
/*     */   
/*     */   public String incMatrixToMatlab(int[][] matrix) {
/* 730 */     StringBuffer sb = new StringBuffer();
/* 731 */     sb.append("C=[\n");
/* 732 */     for (int i = 0; i < matrix.length; i++) {
/* 733 */       for (int j = 0; j < (matrix[i]).length; j++) {
/* 734 */         sb.append(matrix[i][j]);
/* 735 */         if (j < (matrix[i]).length - 1) {
/* 736 */           sb.append(" ");
/*     */         } else {
/* 738 */           sb.append(";\n");
/*     */         } 
/*     */       } 
/*     */     } 
/* 742 */     sb.append("]");
/* 743 */     String res = sb.toString();
/* 744 */     return res;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/InvariantAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */