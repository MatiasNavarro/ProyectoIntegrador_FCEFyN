/*    */ package charlie.analyzer.invariant;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PInvariantSet
/*    */   extends InvariantSet
/*    */ {
/*    */   public PInvariantSet() {
/*  9 */     this.type = 0;
/*    */   }
/*    */   
/*    */   public PInvariantSet(int rowlength) {
/* 13 */     super(rowlength);
/* 14 */     this.type = 0;
/*    */   }
/*    */   
/*    */   public PInvariantSet(int[][] matrix) {
/* 18 */     super(matrix);
/* 19 */     this.type = 0;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/PInvariantSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */