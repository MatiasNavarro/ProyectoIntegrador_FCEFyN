/*    */ package charlie.analyzer.invariant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RankResultSet
/*    */ {
/*  8 */   private double[][] incidenceMatrix = (double[][])null;
/*    */   
/* 10 */   private int rank = -1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setIncidenceMatrix(double[][] _matrix) {
/* 20 */     if (_matrix == null) {
/* 21 */       throw new IllegalArgumentException("The matrix must not be null.");
/*    */     }
/* 23 */     this.incidenceMatrix = _matrix;
/* 24 */     this.rank = -1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double[][] getIncidenceMatrx() {
/* 33 */     return this.incidenceMatrix;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getRank() {
/* 42 */     if (this.rank != -1) {
/* 43 */       return this.rank;
/*    */     }
/*    */     
/* 46 */     for (int i = this.incidenceMatrix.length - 1; i >= 0; i--) {
/* 47 */       for (int j = 0; j < (this.incidenceMatrix[0]).length; j++) {
/* 48 */         if (this.incidenceMatrix[i][j] != 0.0D) {
/*    */           
/* 50 */           this.rank = i + 1;
/* 51 */           return this.rank;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 56 */     this.rank = 0;
/* 57 */     return this.rank;
/*    */   }
/*    */   
/*    */   public static String printMatrix(double[][] _matrix) {
/* 61 */     StringBuffer buffer = new StringBuffer();
/*    */     
/* 63 */     for (int i = 0; i < _matrix.length; i++) {
/* 64 */       for (int j = 0; j < (_matrix[0]).length; j++) {
/* 65 */         buffer.append(_matrix[i][j]);
/* 66 */         buffer.append(" ");
/*    */       } 
/* 68 */       buffer.append("\n");
/*    */     } 
/*    */     
/* 71 */     return buffer.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return printMatrix(this.incidenceMatrix);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/RankResultSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */