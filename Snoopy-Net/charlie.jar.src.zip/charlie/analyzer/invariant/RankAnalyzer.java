/*     */ package charlie.analyzer.invariant;
/*     */ 
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Result;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RankAnalyzer
/*     */   extends Analyzer
/*     */ {
/*  20 */   private static final Log LOG = LogFactory.getLog(RankAnalyzer.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  27 */     return "Rank of Matrix Analyzer";
/*     */   }
/*     */   
/*     */   public static boolean register() {
/*  31 */     RankAnalyzer crnta = new RankAnalyzer();
/*  32 */     return AnalyzerManagerFactory.getAnalyzerManager().register(crnta, new PlaceTransitionNet(), new RankResultSet());
/*     */   }
/*     */   
/*     */   public boolean registerAnalyzer() {
/*  36 */     return register();
/*     */   }
/*     */ 
/*     */   
/*     */   public void analyze() {
/*  41 */     PlaceTransitionNet pn = (PlaceTransitionNet)getOptionSet().getObjectToAnalyze();
/*  42 */     double[][] matrix = getIncidenceMatrix(pn);
/*     */     
/*  44 */     if (LOG.isDebugEnabled()) {
/*  45 */       StringBuffer buf = new StringBuffer("\n");
/*  46 */       for (int k = 0; k < matrix.length; k++) {
/*  47 */         for (int i1 = 0; i1 < (matrix[0]).length; i1++) {
/*  48 */           buf.append(matrix[k][i1]).append(" ");
/*     */         }
/*  50 */         buf.append("\n");
/*     */       } 
/*  52 */       LOG.debug(buf.toString());
/*     */     } 
/*     */ 
/*     */     
/*  56 */     int n = matrix.length;
/*  57 */     int m = (matrix[0]).length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     int i = 0;
/*  64 */     int j = 0;
/*     */     
/*  66 */     while (i < n && j < m) {
/*     */ 
/*     */       
/*  69 */       int maxi = i;
/*     */       
/*  71 */       for (int k = i + 1; k < n; k++) {
/*     */         
/*  73 */         if (Math.abs(matrix[k][j]) > Math.abs(matrix[maxi][j]))
/*     */         {
/*  75 */           maxi = k;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  81 */       if (matrix[maxi][j] != 0.0D) {
/*     */         
/*  83 */         swapRows(matrix, i, maxi);
/*     */ 
/*     */ 
/*     */         
/*  87 */         double mult = matrix[i][j];
/*  88 */         for (int r = j; r < m; r++) {
/*  89 */           matrix[i][r] = matrix[i][r] / mult;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  94 */         for (int u = i + 1; u < n; u++) {
/*     */           
/*  96 */           mult = matrix[u][j];
/*  97 */           for (int s = j; s < m; s++) {
/*  98 */             double sub = mult * matrix[i][s];
/*  99 */             matrix[u][s] = matrix[u][s] - sub;
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 105 */         i++;
/*     */       } 
/*     */ 
/*     */       
/* 109 */       j++;
/*     */     } 
/*     */ 
/*     */     
/* 113 */     RankResultSet resultSet = (RankResultSet)this.options.getResultObject();
/* 114 */     resultSet.setIncidenceMatrix(matrix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void swapRows(double[][] _matrix, int _row1, int _row2) {
/* 125 */     double[] tmp = _matrix[_row1];
/* 126 */     _matrix[_row1] = _matrix[_row2];
/* 127 */     _matrix[_row2] = tmp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double[][] getIncidenceMatrix(PlaceTransitionNet _pn) {
/* 138 */     double[][] incMatrix = new double[_pn.places()][_pn.transitions()];
/*     */     
/* 140 */     for (int i = 0; i < _pn.places(); i++) {
/* 141 */       for (int j = 0; j < _pn.transitions(); j++) {
/* 142 */         incMatrix[i][j] = _pn.changesTokenOn(_pn.getPlaceByIndex(i), _pn
/* 143 */             .getTransition((short)j));
/*     */       }
/*     */     } 
/*     */     
/* 147 */     return incMatrix;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {}
/*     */ 
/*     */   
/*     */   protected void evaluate() {
/* 156 */     RankIncidenceMatrixOptionSet optionSet = (RankIncidenceMatrixOptionSet)getOptionSet();
/* 157 */     RankResultSet result = (RankResultSet)optionSet.getResultObject();
/*     */     
/* 159 */     addOutput(String.format("Rank of the incidence matrix: %d", new Object[] { Integer.valueOf(result.getRank()) }));
/*     */     
/* 161 */     addResult(27, new Result(Integer.valueOf(result.getRank())));
/*     */   }
/*     */ 
/*     */   
/*     */   public Analyzer getNewInstance(OptionSet _options) {
/* 166 */     return new RankAnalyzer();
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeInfoStrings() {
/* 171 */     this.infoStrings = new String[4];
/*     */     
/* 173 */     this.infoStrings[0] = "rank of incidence matrix";
/* 174 */     this.infoStrings[1] = "0";
/* 175 */     this.infoStrings[2] = "time";
/* 176 */     this.infoStrings[3] = getFormatedDuration();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/RankAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */