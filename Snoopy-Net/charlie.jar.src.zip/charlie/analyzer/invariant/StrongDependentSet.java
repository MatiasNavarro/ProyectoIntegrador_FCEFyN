/*    */ package charlie.analyzer.invariant;
/*    */ 
/*    */ public class StrongDependentSet
/*    */   extends DependentSet
/*    */ {
/*    */   public StrongDependentSet() {
/*  7 */     this.type = DependentSet.STRONG_DEPENDENT_SET;
/*    */   }
/*    */   public StrongDependentSet(int rowlength) {
/* 10 */     super(rowlength);
/* 11 */     this.type = DependentSet.STRONG_DEPENDENT_SET;
/*    */   }
/*    */   
/*    */   public StrongDependentSet(int[][] matrix) {
/* 15 */     super(matrix);
/* 16 */     this.type = DependentSet.STRONG_DEPENDENT_SET;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/StrongDependentSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */