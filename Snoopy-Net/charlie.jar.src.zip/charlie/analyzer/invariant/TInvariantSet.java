/*    */ package charlie.analyzer.invariant;
/*    */ 
/*    */ public class TInvariantSet
/*    */   extends InvariantSet {
/*    */   public TInvariantSet() {
/*  6 */     this.type = 1;
/*    */   }
/*    */   
/*    */   public TInvariantSet(int rowlength) {
/* 10 */     super(rowlength);
/* 11 */     this.type = 1;
/*    */   }
/*    */   
/*    */   public TInvariantSet(int[][] matrix) {
/* 15 */     super(matrix);
/* 16 */     this.type = 1;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/TInvariantSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */