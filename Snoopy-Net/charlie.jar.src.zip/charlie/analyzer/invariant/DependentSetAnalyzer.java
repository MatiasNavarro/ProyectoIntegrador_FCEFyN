/*     */ package charlie.analyzer.invariant;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.ds.BitSet;
/*     */ import charlie.ds.sm.SparseMatrix;
/*     */ import charlie.pn.NodeSet;
/*     */ import charlie.pn.Out;
/*     */ import charlie.pn.PlaceSet;
/*     */ import charlie.pn.TransitionSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DependentSetAnalyzer
/*     */   extends Analyzer {
/*  23 */   private static final Log LOG = LogFactory.getLog(DependentSetAnalyzer.class);
/*     */   
/*     */   public boolean transitions;
/*     */   
/*     */   DependentSetOptions mo;
/*     */   
/*     */   private InvariantSet invariants;
/*     */   private SparseMatrix abstractDependentSets;
/*     */   private SparseMatrix strongDependentSets;
/*     */   private Collection<NodeSet> decomposedDTS;
/*  33 */   private String adsTitle = "abstract dependent";
/*  34 */   private String adsConTitle = "connected abstract dependent";
/*  35 */   private String sdsTitle = "strong dependent";
/*  36 */   private String adsTitleShort = "abstract dependent";
/*  37 */   private String sdsTitleShort = "strong dependent";
/*     */   
/*     */   public DependentSetAnalyzer() {
/*  40 */     this.infoStrings = new String[1];
/*  41 */     this.infoStrings[0] = "no information available";
/*  42 */     setUpdateInterval(250L);
/*  43 */     initializeInfoStrings();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  48 */     return "Dependend Set Analyzer";
/*     */   }
/*     */   
/*     */   public static boolean register() {
/*  52 */     DependentSetAnalyzer dsa = new DependentSetAnalyzer();
/*  53 */     PInvariantSet pInv = new PInvariantSet();
/*     */     
/*  55 */     AnalyzerManagerFactory.getAnalyzerManager().register(dsa, pInv, new DependentSet());
/*     */     
/*  57 */     TInvariantSet tInv = new TInvariantSet();
/*     */     
/*  59 */     AnalyzerManagerFactory.getAnalyzerManager().register(dsa, tInv, new DependentSet());
/*     */     
/*  61 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Analyzer getNewInstance(OptionSet options) {
/*  66 */     DependentSetAnalyzer a = new DependentSetAnalyzer();
/*  67 */     a.setup(options);
/*  68 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeInfoStrings() {
/*  73 */     if (this.options == null || this.options.getResultObject() == null) {
/*     */       return;
/*     */     }
/*     */     
/*  77 */     if (((DependentSetOptions)this.options).transitions) {
/*  78 */       this.adsTitle += " transition sets =\n";
/*  79 */       this.sdsTitle += " transition sets =\n";
/*  80 */       this.adsConTitle += " transition sets =\n";
/*  81 */       this.adsTitleShort = "ADT-sets";
/*  82 */       this.sdsTitleShort = "SDT-sets";
/*     */     } else {
/*     */       
/*  85 */       this.adsTitle += " place sets =\n";
/*  86 */       this.sdsTitle += " place sets =\n";
/*  87 */       this.adsConTitle += " place sets =\n";
/*  88 */       this.adsTitleShort = "ADP-sets";
/*  89 */       this.sdsTitleShort = "SDP-sets";
/*     */     } 
/*  91 */     this.infoStrings[0] = getFormatedDuration();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze() {
/*  97 */     DebugCounter.inc("DependentSetAnalyzer.run(): computing " + this.options.getResultObject().getClass().getName());
/*  98 */     if (!(this.options.getObjectToAnalyze() instanceof InvariantSet)) {
/*  99 */       addOutput("DependendSetAnalyzer wrong object provided for analysis expected Invariant got " + this.options.getObjectToAnalyze().getClass().getName());
/*     */       return;
/*     */     } 
/* 102 */     this.invariants = (InvariantSet)this.options.getObjectToAnalyze();
/* 103 */     if (this.invariants instanceof PInvariantSet) {
/* 104 */       this.transitions = false;
/* 105 */     } else if (this.invariants instanceof TInvariantSet) {
/* 106 */       this.transitions = true;
/*     */     } else {
/* 108 */       DebugCounter.inc("DependentSetAnalyzer analyze() Wrong class for invariants : " + this.invariants.getClass().getName());
/*     */     } 
/* 110 */     this.mo = (DependentSetOptions)this.options;
/*     */     
/* 112 */     if (this.mo.getResultObject() instanceof DependentSet) {
/* 113 */       if (this.mo.ads && !this.mo.sds) {
/*     */         
/* 115 */         this.abstractDependentSets = computeSupportDTS();
/*     */         
/* 117 */         if (this.mo.decompose) {
/* 118 */           this.decomposedDTS = decomposeDts();
/* 119 */           addOutput("there are " + this.decomposedDTS.size() + " connected ADSs");
/* 120 */           addOutput(NodeSet.writeToString(this.adsConTitle, this.decomposedDTS));
/*     */         } 
/* 122 */         if (this.mo.adsFile != null) {
/* 123 */           addOutput("abstract depenent sets file written: " + this.mo.adsFile);
/* 124 */           this.invariants.writeToFile(this.mo.adsFile, this.adsTitle, this.abstractDependentSets);
/*     */         } 
/* 126 */       } else if (this.mo.ads && this.mo.sds) {
/* 127 */         this.strongDependentSets = computeStrongDTS();
/*     */         
/* 129 */         if (this.mo.decompose) {
/* 130 */           this.decomposedDTS = decomposeDts();
/* 131 */           addOutput("there are " + this.decomposedDTS.size() + " connected ADSs");
/* 132 */           addOutput(NodeSet.writeToString(this.adsConTitle, this.decomposedDTS));
/*     */         } 
/* 134 */         if (this.mo.sdsFile != null) {
/* 135 */           addOutput("strong depenent sets file written: " + this.mo.sdsFile);
/* 136 */           this.invariants.writeToFile(this.mo.sdsFile, this.sdsTitle, this.strongDependentSets);
/*     */         } 
/* 138 */         if (this.mo.adsFile != null) {
/* 139 */           addOutput("abstract depenent sets file written: " + this.mo.adsFile);
/* 140 */           this.invariants.writeToFile(this.mo.adsFile, this.adsTitle, this.abstractDependentSets);
/*     */         } 
/*     */       } 
/*     */       
/* 144 */       if (this.mo.decompose == true && this.decomposedDTS != null && this.mo.adsConFile != null && !this.mo.adsConFile.equals("")) {
/* 145 */         writeConnectedDtsToFile(this.mo.adsConFile);
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 155 */       DebugCounter.inc("DependentSetAnalyzer.run(): Wrong class type for resultObject, check codeline that contains setup! Provided ClassName " + this.options.getResultObject().getClass().getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SparseMatrix computeSupportDTS() {
/*     */     try {
/* 163 */       addOutput("computing AbstractDependendSets");
/*     */       
/* 165 */       Out.println(this.invariants);
/*     */       
/* 167 */       SparseMatrix res = new SparseMatrix(this.invariants.rowLength);
/*     */       
/* 169 */       HashSet<BitSet> supports = new HashSet<>();
/* 170 */       for (int r = 0; r < this.invariants.rows(); r++) {
/* 171 */         supports.add(this.invariants.getSupport(r));
/*     */       }
/* 173 */       int size = !this.mo.transitions ? this.invariants.pn.places() : this.invariants.pn.transitions();
/* 174 */       BitSet ready = new BitSet(size);
/*     */       
/* 176 */       for (int i = 0; i < size && ready.size() < size; i++) {
/* 177 */         if (!ready.member(i)) {
/*     */ 
/*     */           
/* 180 */           ready.insert(i);
/*     */ 
/*     */           
/* 183 */           int[] dts = new int[size];
/* 184 */           dts[i] = 1;
/*     */ 
/*     */           
/* 187 */           for (int j = i + 1; j < size; j++) {
/*     */             
/* 189 */             Iterator<BitSet> iterator = supports.iterator(); while (true) { if (iterator.hasNext()) { BitSet supp = iterator.next();
/* 190 */                 if (!checkStatus()) { cleanup(); return null; }
/* 191 */                  if (supp.member(i) ? 
/* 192 */                   supp.member(j) : 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 198 */                   !supp.member(j)) {
/*     */                   continue;
/*     */                 }
/*     */ 
/*     */                 
/*     */                 break; }
/*     */ 
/*     */               
/* 206 */               dts[j] = 1;
/*     */ 
/*     */               
/* 209 */               ready.insert(j); break; }
/*     */           
/* 211 */           }  res.addRow(dts);
/* 212 */           int m = res.rows() - 1;
/* 213 */           for (int k = 0; k < res.rows() - 1; k++) {
/* 214 */             if (res.equalRows(k, m)) {
/* 215 */               res.deleteLastRow(); break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 220 */       this.abstractDependentSets = res;
/* 221 */       addOutput(this.abstractDependentSets.rows() + " " + this.adsTitleShort + "set computed.\n");
/*     */       
/* 223 */       return res;
/* 224 */     } catch (Exception e) {
/* 225 */       LOG.error(e.getMessage(), e);
/*     */       
/* 227 */       return null;
/*     */     } 
/*     */   }
/*     */   public SparseMatrix computeStrongDTS() {
/*     */     try {
/* 232 */       if (this.abstractDependentSets == null) {
/* 233 */         computeSupportDTS();
/*     */       }
/* 235 */       addOutput("computing Strong Dependend Sets");
/* 236 */       SparseMatrix res = new SparseMatrix(this.abstractDependentSets.rowLength);
/*     */       
/* 238 */       int size = !this.mo.transitions ? this.invariants.pn.places() : this.invariants.pn.transitions();
/* 239 */       for (int row = 0; row < this.abstractDependentSets.rows(); row++) {
/* 240 */         BitSet d = this.abstractDependentSets.getSupport(row);
/* 241 */         for (int i = 0; i < this.abstractDependentSets.elementsInRow(row); i++) {
/* 242 */           int index1 = this.abstractDependentSets.getIthColumnIndexInRow(row, i);
/*     */           
/* 244 */           int[] stDts = new int[size];
/* 245 */           stDts[index1] = 1;
/* 246 */           d.delete(index1);
/*     */           
/* 248 */           for (int j = 0; j < this.abstractDependentSets.elementsInRow(row); j++) {
/* 249 */             int index2 = this.abstractDependentSets.getIthColumnIndexInRow(row, j);
/* 250 */             if (index1 != index2) {
/*     */ 
/*     */               
/* 253 */               float ratio = 0.0F;
/*     */               
/* 255 */               int inv = 0; while (true) { if (inv < this.invariants.rows()) {
/* 256 */                   if (!checkStatus()) { cleanup(); return null; }
/* 257 */                    int inv_index1 = this.invariants.containsColumnIndex(inv, index1);
/* 258 */                   if (inv_index1 < 0) {
/*     */                     continue;
/*     */                   }
/* 261 */                   int inv_index2 = this.invariants.containsColumnIndex(inv, index2);
/* 262 */                   int val1 = this.invariants.getValue(inv_index1);
/* 263 */                   int val2 = this.invariants.getValue(inv_index2);
/*     */                   
/* 265 */                   if (ratio == 0.0F) {
/* 266 */                     ratio = (val1 / val2); continue;
/*     */                   } 
/* 268 */                   if (ratio == (val1 / val2)) {
/*     */                     continue;
/*     */                   }
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */                 
/* 275 */                 stDts[index2] = 1;
/* 276 */                 d.delete(index2); break; inv++; }
/*     */             
/*     */             } 
/* 279 */           }  res.addRow(stDts);
/* 280 */           int r = res.rows() - 1;
/* 281 */           for (int k = 0; k < res.rows() - 1; k++) {
/* 282 */             if (res.equalRows(k, r)) {
/* 283 */               Out.println("del");
/* 284 */               res.deleteLastRow();
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 291 */       this.strongDependentSets = res;
/* 292 */       addOutput(this.strongDependentSets.rows() + " " + this.sdsTitleShort + " computed\n");
/*     */       
/* 294 */       return res;
/* 295 */     } catch (Exception e) {
/* 296 */       LOG.error(e.getMessage(), e);
/*     */       
/* 298 */       return null;
/*     */     } 
/*     */   }
/*     */   public String getInfoString() {
/* 302 */     StringBuffer stb = new StringBuffer();
/* 303 */     stb.append("<html>");
/* 304 */     if (this.abstractDependentSets != null) {
/* 305 */       stb.append("<br>");
/* 306 */       stb.append(this.abstractDependentSets.rows() + " " + this.adsTitleShort + " computed in " + getFormatedDuration());
/*     */     } 
/* 308 */     if (this.strongDependentSets != null) {
/* 309 */       stb.append("<br>");
/* 310 */       stb.append(this.strongDependentSets.rows() + " " + this.sdsTitleShort + " computed in " + getFormatedDuration());
/*     */     } 
/* 312 */     stb.append("</html>");
/* 313 */     return stb.toString();
/*     */   }
/*     */   
/*     */   public Collection<NodeSet> decomposeDts() {
/* 317 */     Collection<NodeSet> ret = null;
/*     */     try {
/* 319 */       if (this.abstractDependentSets == null) {
/* 320 */         return null;
/*     */       }
/* 322 */       addOutput("starting decomposition of ADSs considering connectivity:");
/* 323 */       if (this.mo.ignore != null && !this.mo.ignore.isEmpty()) {
/* 324 */         addOutput("ignoring the following nodes: ");
/* 325 */         addOutput(this.mo.ignore.toString());
/* 326 */         addOutput("===============");
/*     */       } 
/* 328 */       ret = new Vector<>();
/*     */       
/* 330 */       boolean decomposed = false;
/* 331 */       int count = 1;
/* 332 */       int countAll = 0;
/* 333 */       for (int i = 0; i < this.abstractDependentSets.rows(); i++) {
/* 334 */         PlaceSet placeSet; if (this.transitions) {
/* 335 */           TransitionSet transitionSet = new TransitionSet(this.abstractDependentSets.getSupport(i));
/*     */         } else {
/* 337 */           placeSet = new PlaceSet(this.abstractDependentSets.getSupport(i));
/*     */         } 
/* 339 */         Set<NodeSet> mcsSet = placeSet.decompose(this.mo.ignore);
/* 340 */         if (mcsSet.size() > 1) {
/* 341 */           decomposed = true;
/* 342 */           countAll++;
/* 343 */           addOutput(placeSet.toString());
/* 344 */           addOutput("has been decomposed into the following connected ADSs:");
/*     */         } 
/* 346 */         for (NodeSet mcs : mcsSet) {
/* 347 */           if (decomposed) {
/* 348 */             addOutput("" + count++ + mcs);
/*     */           }
/* 350 */           ret.add(mcs);
/*     */         } 
/* 352 */         if (decomposed) {
/* 353 */           addOutput("===============================");
/*     */         }
/* 355 */         decomposed = false;
/* 356 */         count = 1;
/*     */       } 
/* 358 */       addOutput("number of decomposed ADSs: " + countAll);
/* 359 */     } catch (Exception e) {
/* 360 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 362 */     return ret;
/*     */   }
/*     */   
/*     */   public Collection<NodeSet> computeInterfaceNodes(Collection<NodeSet> ads) {
/* 366 */     if (ads == null) {
/* 367 */       return null;
/*     */     }
/*     */     
/* 370 */     Collection<NodeSet> ret = new Vector<>();
/*     */     try {
/* 372 */       for (NodeSet ns : ads) {
/*     */         
/* 374 */         NodeSet prepost = ns.getEnvironment();
/*     */         
/* 376 */         NodeSet pp_prepost = prepost.getEnvironment();
/* 377 */         pp_prepost.diff(ns);
/* 378 */         NodeSet bounds = pp_prepost.getEnvironment().intersection(prepost);
/* 379 */         ret.add(bounds);
/*     */       } 
/* 381 */     } catch (Exception e) {
/* 382 */       LOG.error(e.getMessage(), e);
/*     */     } 
/* 384 */     return ret;
/*     */   }
/*     */   public void writeConnectedDtsToFile(String filename) {
/*     */     String title;
/* 388 */     if (this.abstractDependentSets == null || filename == null || filename.equals("")) {
/*     */       return;
/*     */     }
/*     */     
/* 392 */     Collection<NodeSet> decomposedDts = decomposeDts();
/* 393 */     Collection<NodeSet> bounds = computeInterfaceNodes(decomposedDts);
/* 394 */     addOutput("there are " + decomposedDts.size() + " connected ADSs");
/* 395 */     NodeSet.writeToFile(filename, this.adsConTitle, decomposedDts);
/*     */ 
/*     */     
/* 398 */     if (this.transitions) {
/* 399 */       title = "interface place sets=\n";
/*     */     } else {
/* 401 */       title = "interface transition sets =\n";
/*     */     } 
/*     */     
/* 404 */     NodeSet.writeToFile(filename + ".ifn", title, bounds);
/*     */   }
/*     */   
/*     */   public void writeStrongDtsToFile(String filename) {
/* 408 */     if (this.strongDependentSets == null || filename == null || filename.equals("")) {
/*     */       return;
/*     */     }
/* 411 */     addOutput("file written: " + filename);
/* 412 */     this.invariants.writeToFile(filename, this.sdsTitle, this.strongDependentSets);
/*     */   }
/*     */   
/*     */   public void evaluate() {}
/*     */   
/*     */   public void cleanup() {}
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/DependentSetAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */