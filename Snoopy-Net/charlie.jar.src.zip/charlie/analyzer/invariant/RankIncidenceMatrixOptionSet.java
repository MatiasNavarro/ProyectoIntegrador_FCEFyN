/*    */ package charlie.analyzer.invariant;
/*    */ 
/*    */ import GUI.preference.FilterFactory;
/*    */ import GUI.preference.IncidenceMatrixBasedFilterPreference;
/*    */ import charlie.analyzer.OptionSet;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RankIncidenceMatrixOptionSet
/*    */   extends OptionSet
/*    */ {
/*    */   private static final long serialVersionUID = -8681555243442614533L;
/* 19 */   private static final Log LOG = LogFactory.getLog(RankIncidenceMatrixOptionSet.class);
/*    */   
/* 21 */   private String exportFile = "";
/*    */   
/*    */   public RankIncidenceMatrixOptionSet() {
/* 24 */     setLogOutput(!FilterFactory.getFilterProperties().isFiltered(IncidenceMatrixBasedFilterPreference.FILTER_IM_BASED_RANK_THEOREM.getKey()));
/*    */   }
/*    */   
/*    */   public void setExportFile(String _exportFile) {
/* 28 */     this.exportFile = _exportFile;
/*    */   }
/*    */   
/*    */   public String getExportFile() {
/* 32 */     return this.exportFile;
/*    */   }
/*    */ 
/*    */   
/*    */   public Properties getAsProperties() {
/* 37 */     return new Properties();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getHtmlInfo() {
/* 42 */     StringBuffer buf = new StringBuffer();
/* 43 */     buf.append("<html><table border=\"1px\">");
/* 44 */     buf.append("<tr><td width=\"200px\">");
/* 45 */     buf.append("Invariant options");
/* 46 */     buf.append("</td><td width=\"200px\"></td></tr>");
/* 47 */     buf.append("<tr><td>compute</td><td>");
/* 48 */     buf.append("rank of incidence matrix");
/* 49 */     buf.append("</td></tr>");
/* 50 */     buf.append("<tr><td>exportFile</td><td>");
/* 51 */     if (this.exportFile != null) {
/* 52 */       buf.append(this.exportFile);
/*    */     } else {
/* 54 */       buf.append("not set!");
/*    */     } 
/* 56 */     buf.append("</td></tr></table></html>");
/* 57 */     return buf.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean initByProperties(Properties props) {
/* 62 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean initializeByString(String parameters) {
/*    */     try {
/* 68 */       this.exportFile = getValue(parameters, "exportFile", this.exportFile);
/* 69 */     } catch (Exception e) {
/* 70 */       LOG.error(e.getMessage(), e);
/* 71 */       System.out.printf(getHelpString(), new Object[0]);
/* 72 */       return false;
/*    */     } 
/* 74 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     return RankIncidenceMatrixOptionSet.class.getName();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/RankIncidenceMatrixOptionSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */