/*     */ package charlie.analyzer.invariant;
/*     */ 
/*     */ import charlie.ds.sm.SparseMatrix;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvParser
/*     */ {
/*  17 */   private final Log LOG = LogFactory.getLog(InvParser.class);
/*     */   
/*     */   private String filename;
/*     */   
/*     */   private SparseMatrix invariants;
/*     */   private boolean transitions;
/*  23 */   private int currentLine = 0;
/*     */   
/*     */   private boolean invFinished = true;
/*  26 */   private PlaceTransitionNet pn = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InvParser(PlaceTransitionNet _pn, String filename) {
/*  34 */     this.pn = _pn;
/*  35 */     this.filename = filename;
/*     */   }
/*     */   
/*     */   private boolean readInv(StringTokenizer st, String line, int[] result) throws Exception {
/*  39 */     int id = -1;
/*  40 */     int val = -1;
/*  41 */     if (st.countTokens() != 3) {
/*  42 */       throw new Exception("parsing error in line " + this.currentLine);
/*     */     }
/*     */     
/*  45 */     int i = 1;
/*  46 */     while (st.hasMoreTokens()) {
/*  47 */       String str = st.nextToken();
/*  48 */       if (i == 2) {
/*  49 */         if (this.transitions) {
/*  50 */           id = this.pn.lookUpTransitionIndexbyName(str);
/*  51 */           if (id < 0) {
/*  52 */             throw new Exception("unknown transition in line " + this.currentLine + " : " + str);
/*     */           }
/*     */         } else {
/*  55 */           id = this.pn.lookUpPlaceIndexbyName(str);
/*  56 */           if (id < 0) {
/*  57 */             throw new Exception("unknown place in line " + this.currentLine + " : " + str);
/*     */           }
/*     */         } 
/*     */       }
/*  61 */       if (i == 3) {
/*     */         try {
/*  63 */           val = Integer.parseInt(str);
/*  64 */         } catch (NumberFormatException e) {
/*  65 */           throw new Exception("wrong occurance value in line " + this.currentLine + " : " + str);
/*     */         } 
/*     */       }
/*  68 */       i++;
/*     */     } 
/*     */     
/*  71 */     result[id] = val;
/*     */     
/*  73 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SparseMatrix readInvMatrix(String invFile) throws IOException, FileNotFoundException, Exception {
/*     */     BufferedReader br;
/*     */     try {
/*  91 */       if (invFile.endsWith(".res") || invFile.endsWith(".inv") || invFile.endsWith(".tinv") || invFile.endsWith(".pinv")) {
/*  92 */         br = new BufferedReader(new FileReader(invFile));
/*     */       } else {
/*  94 */         throw new FileNotFoundException("no invariant file");
/*     */       } 
/*  96 */     } catch (IOException ioe) {
/*  97 */       throw new IOException("cannot open file: " + invFile);
/*     */     } 
/*     */     
/* 100 */     String line = br.readLine();
/* 101 */     this.currentLine++;
/* 102 */     SparseMatrix sm = null;
/*     */     
/* 104 */     int[] inv = null;
/* 105 */     int length = 0;
/* 106 */     while (line != null) {
/* 107 */       if (line.equals("")) {
/* 108 */         line = br.readLine();
/* 109 */         this.currentLine++;
/*     */         continue;
/*     */       } 
/* 112 */       line = deleteSpace(line);
/*     */       
/* 114 */       if (this.LOG.isDebugEnabled()) {
/* 115 */         this.LOG.debug(line);
/*     */       }
/*     */ 
/*     */       
/* 119 */       StringBuffer stb = new StringBuffer();
/* 120 */       for (int i = 0; i < line.length(); i++) {
/* 121 */         if (line.charAt(i) != '|') {
/* 122 */           stb.append(line.charAt(i));
/*     */         } else {
/* 124 */           stb.append(line.substring(i + 1));
/*     */           break;
/*     */         } 
/*     */       } 
/* 128 */       line = stb.toString();
/*     */       
/* 130 */       StringTokenizer st = new StringTokenizer(line, ":.,\t");
/* 131 */       if (this.LOG.isDebugEnabled()) {
/* 132 */         this.LOG.debug(line + " : " + st.countTokens());
/*     */       }
/*     */       
/* 135 */       if (st.countTokens() == 1) {
/* 136 */         if (line.endsWith("=")) {
/* 137 */           if (line.contains("place")) {
/* 138 */             this.transitions = false;
/* 139 */             length = this.pn.places();
/* 140 */             sm = new PInvariantSet(length);
/* 141 */           } else if (line.contains("transition")) {
/* 142 */             this.transitions = true;
/* 143 */             length = this.pn.transitions();
/* 144 */             sm = new TInvariantSet(length);
/*     */           } else {
/* 146 */             throw new IOException("parsing error in line " + this.currentLine);
/*     */           } 
/* 148 */           inv = new int[length];
/*     */         }
/* 150 */         else if (deleteSpace(line).charAt(0) == '@') {
/* 151 */           return sm;
/*     */         } 
/*     */ 
/*     */         
/* 155 */         line = br.readLine();
/*     */         
/*     */         continue;
/*     */       } 
/* 159 */       if (st.countTokens() == 4) {
/* 160 */         if (this.invFinished) {
/* 161 */           this.invFinished = false;
/* 162 */           st.nextToken();
/*     */         } else {
/* 164 */           throw new Exception("parsing error: " + line);
/*     */         } 
/*     */       }
/*     */       
/* 168 */       readInv(st, line, inv);
/*     */       
/* 170 */       if (!line.endsWith(",")) {
/* 171 */         this.invFinished = true;
/* 172 */         sm.addRow(inv);
/*     */         
/* 174 */         inv = new int[length];
/*     */       } 
/*     */       
/* 177 */       line = br.readLine();
/* 178 */       this.currentLine++;
/*     */     } 
/*     */     
/* 181 */     return sm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse() throws IOException, Exception {
/* 191 */     this.currentLine++;
/* 192 */     this.invFinished = true;
/* 193 */     this.invariants = readInvMatrix(this.filename);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean transitions() {
/* 202 */     return this.transitions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SparseMatrix getInvariants() {
/* 211 */     return this.invariants;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String deleteSpace(String str) {
/* 222 */     StringBuffer sb = new StringBuffer();
/* 223 */     for (int i = 0; i < str.length(); i++) {
/* 224 */       if (str.charAt(i) != ' ' && str.charAt(i) != '\t') {
/* 225 */         sb.append(str.charAt(i));
/*     */       }
/*     */     } 
/* 228 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/InvParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */