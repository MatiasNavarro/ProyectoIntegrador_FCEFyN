/*    */ package charlie.analyzer.invariant;
/*    */ 
/*    */ import charlie.ds.sm.SparseMatrix;
/*    */ 
/*    */ public class DependentSet extends SparseMatrix {
/*  6 */   public static int STRONG_DEPENDENT_SET = 0;
/*  7 */   public static int ABSTRACT_DEPENDENT_SET = 1;
/*  8 */   public static int CONNECTED_ABSTRACT_DEPENDENT_SET = 2;
/*    */   
/*    */   int type;
/*    */ 
/*    */   
/*    */   public DependentSet() {}
/*    */   
/*    */   public DependentSet(int rowlength) {
/* 16 */     super(rowlength);
/*    */   }
/*    */ 
/*    */   
/*    */   public DependentSet(int[][] matrix) {
/* 21 */     super(matrix);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getType() {
/* 27 */     return this.type;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/DependentSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */