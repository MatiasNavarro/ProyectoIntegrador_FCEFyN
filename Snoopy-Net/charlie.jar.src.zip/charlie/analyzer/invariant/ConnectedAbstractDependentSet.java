/*    */ package charlie.analyzer.invariant;
/*    */ 
/*    */ 
/*    */ public class ConnectedAbstractDependentSet
/*    */   extends DependentSet
/*    */ {
/*    */   public ConnectedAbstractDependentSet() {
/*  8 */     this.type = DependentSet.CONNECTED_ABSTRACT_DEPENDENT_SET;
/*    */   }
/*    */   
/*    */   public ConnectedAbstractDependentSet(int rowlength) {
/* 12 */     super(rowlength);
/* 13 */     this.type = DependentSet.CONNECTED_ABSTRACT_DEPENDENT_SET;
/*    */   }
/*    */   
/*    */   public ConnectedAbstractDependentSet(int[][] matrix) {
/* 17 */     super(matrix);
/* 18 */     this.type = DependentSet.CONNECTED_ABSTRACT_DEPENDENT_SET;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/ConnectedAbstractDependentSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */