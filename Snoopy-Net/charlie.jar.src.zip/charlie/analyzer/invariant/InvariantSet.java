/*     */ package charlie.analyzer.invariant;
/*     */ 
/*     */ import GUI.util.TextFile;
/*     */ import charlie.ds.sm.ExtendedIncMatrix;
/*     */ import charlie.ds.sm.SparseMatrix;
/*     */ import charlie.pn.PlaceSet;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import java.io.File;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ public class InvariantSet extends SparseMatrix {
/*     */   public static final int PINVARIANT = 0;
/*     */   public static final int TINVARIANT = 1;
/*  14 */   public PlaceTransitionNet pn = null;
/*     */   
/*     */   protected int type;
/*     */   
/*  18 */   private int lines = 0;
/*     */ 
/*     */   
/*     */   public InvariantSet() {}
/*     */   
/*     */   public InvariantSet(int rowlength) {
/*  24 */     super(rowlength);
/*     */   }
/*     */   public InvariantSet(int[][] matrix) {
/*  27 */     super(matrix);
/*     */   }
/*     */   
/*     */   public int getType() {
/*  31 */     return this.type;
/*     */   }
/*     */   
/*     */   public void writeToFile(String filename, String title) {
/*  35 */     StringBuffer buf = new StringBuffer();
/*  36 */     this.lines = 0;
/*  37 */     buf.append(title);
/*  38 */     buf.append("\n");
/*  39 */     buf.append(matrixToString(this));
/*  40 */     TextFile.writeToFile(new File(filename), buf, true);
/*     */   }
/*     */   
/*     */   public void writeToFile(String filename, String title, SparseMatrix sm) {
/*  44 */     StringBuffer buf = new StringBuffer();
/*  45 */     this.lines = 0;
/*  46 */     buf.append(title);
/*  47 */     buf.append("\n");
/*  48 */     buf.append(matrixToString(sm));
/*  49 */     TextFile.writeToFile(new File(filename), buf, true);
/*     */   }
/*     */   
/*     */   public String matrixToString(SparseMatrix sm) {
/*  53 */     String res = "";
/*  54 */     this.lines = 0;
/*     */     try {
/*  56 */       for (int i = 0; i < sm.rows(); i++) {
/*  57 */         res = res + rowToString(sm, i, false);
/*     */       }
/*  59 */     } catch (Exception e) {
/*  60 */       e.printStackTrace();
/*     */     } 
/*  62 */     return res;
/*     */   }
/*     */   
/*     */   public String rowToString(SparseMatrix sm, int rowIndex, boolean support) {
/*  66 */     if (this.pn == null) return ""; 
/*  67 */     String res = "";
/*     */     try {
/*  69 */       String invariant = "" + ++this.lines;
/*  70 */       for (int j = 0; j < sm.elementsInRow(rowIndex); j++) {
/*  71 */         int id = sm.getIthColumnIndexInRow(rowIndex, j);
/*  72 */         if (support)
/*  73 */           id -= ((ExtendedIncMatrix)sm).realCols; 
/*  74 */         String name = null;
/*  75 */         if (this.type == 1) {
/*  76 */           name = this.pn.getTransition((short)id).getName();
/*  77 */           id = this.pn.getTransition((short)id).getOrgId();
/*     */         } else {
/*  79 */           name = this.pn.getPlaceByIndex((short)id).getName();
/*  80 */           id = this.pn.getPlaceByIndex((short)id).getOrgId();
/*     */         } 
/*  82 */         invariant = invariant + "\t|\t" + id + "." + name + "\t\t:" + sm.getIthColumnValueInRow(rowIndex, j);
/*     */         
/*  84 */         if (j < sm.elementsInRow(rowIndex) - 1) {
/*  85 */           invariant = invariant + ",";
/*     */         }
/*  87 */         invariant = invariant + "\n";
/*     */       } 
/*  89 */       res = res + invariant;
/*     */     }
/*  91 */     catch (Exception e) {
/*  92 */       e.printStackTrace();
/*     */     } 
/*  94 */     return res;
/*     */   }
/*     */   
/*     */   public HashSet<PlaceSet> getSupports() throws Exception {
/*  98 */     HashSet<PlaceSet> supports = new HashSet<>();
/*  99 */     for (int i = 0; i < rows(); i++) {
/* 100 */       supports.add(new PlaceSet(getSupport(i)));
/*     */     }
/*     */     
/* 103 */     return supports;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/InvariantSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */