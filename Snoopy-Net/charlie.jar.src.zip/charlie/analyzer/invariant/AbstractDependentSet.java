/*    */ package charlie.analyzer.invariant;
/*    */ 
/*    */ public class AbstractDependentSet
/*    */   extends DependentSet
/*    */ {
/*    */   public AbstractDependentSet() {
/*  7 */     this.type = DependentSet.ABSTRACT_DEPENDENT_SET;
/*    */   }
/*    */   public AbstractDependentSet(int rowlength) {
/* 10 */     super(rowlength);
/* 11 */     this.type = DependentSet.ABSTRACT_DEPENDENT_SET;
/*    */   }
/*    */   
/*    */   public AbstractDependentSet(int[][] matrix) {
/* 15 */     super(matrix);
/* 16 */     this.type = DependentSet.ABSTRACT_DEPENDENT_SET;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/AbstractDependentSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */