/*     */ package charlie.analyzer.invariant;
/*     */ 
/*     */ import GUI.preference.FilterFactory;
/*     */ import GUI.preference.IncidenceMatrixBasedFilterPreference;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvOptions
/*     */   extends OptionSet
/*     */ {
/*     */   private boolean transitions = true;
/*     */   public boolean deleteTrivial = false;
/*     */   public boolean coverage = true;
/*     */   public boolean extendedCoverage = false;
/*     */   public boolean enableMCSC = false;
/*  20 */   public String exportFile = null;
/*     */   
/*     */   public InvOptions(boolean t, boolean dt, boolean c, boolean ec, boolean emcsc, String exp) {
/*  23 */     this.transitions = t;
/*  24 */     this.deleteTrivial = dt;
/*  25 */     this.coverage = c;
/*  26 */     this.extendedCoverage = ec;
/*  27 */     this.enableMCSC = emcsc;
/*  28 */     this.exportFile = exp;
/*     */ 
/*     */     
/*  31 */     if (t) {
/*  32 */       setLogOutput(!FilterFactory.getFilterProperties().isFiltered(IncidenceMatrixBasedFilterPreference.FILTER_IM_BASED_T_INVARIANTS.getKey()));
/*     */     } else {
/*  34 */       setLogOutput(!FilterFactory.getFilterProperties().isFiltered(IncidenceMatrixBasedFilterPreference.FILTER_IM_BASED_P_INVARIANTS.getKey()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InvOptions() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComputeTInvariants(boolean _tinv) {
/*  48 */     this.transitions = _tinv;
/*     */ 
/*     */     
/*  51 */     if (_tinv) {
/*  52 */       setLogOutput(!FilterFactory.getFilterProperties().isFiltered(IncidenceMatrixBasedFilterPreference.FILTER_IM_BASED_T_INVARIANTS.getKey()));
/*     */     } else {
/*  54 */       setLogOutput(!FilterFactory.getFilterProperties().isFiltered(IncidenceMatrixBasedFilterPreference.FILTER_IM_BASED_P_INVARIANTS.getKey()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isComputeTInvariants() {
/*  64 */     return this.transitions;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  68 */     StringBuffer buf = new StringBuffer();
/*  69 */     buf.append("Invariant Options:\n");
/*  70 */     if (this.transitions) { buf.append("compute: T-Invariants\n"); }
/*  71 */     else { buf.append("compute: P-Invariants\n"); }
/*  72 */      buf.append("delete Trivial Invariants: ");
/*  73 */     if (this.deleteTrivial) { buf.append("yes\n"); }
/*  74 */     else { buf.append("no\n"); }
/*  75 */      buf.append("check coverage: ");
/*  76 */     if (this.coverage) { buf.append("yes\n"); }
/*  77 */     else { buf.append("no\n"); }
/*  78 */      buf.append("check extended coverage: ");
/*  79 */     if (this.extendedCoverage) { buf.append("yes\n"); }
/*  80 */     else { buf.append("no\n"); }
/*  81 */      buf.append("enable MCSC: ");
/*  82 */     if (this.enableMCSC) { buf.append("yes\n"); }
/*  83 */     else { buf.append("no\n"); }
/*  84 */      if (this.exportFile != null && 
/*  85 */       !this.exportFile.equals("")) {
/*  86 */       buf.append("exportFile: " + this.exportFile + "\n");
/*     */     }
/*     */     
/*  89 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getAsProperties() {
/*  98 */     return new Properties();
/*     */   }
/*     */   
/*     */   public boolean initByProperties(Properties props) {
/* 102 */     return true;
/*     */   }
/*     */   
/*     */   public String getHtmlInfo() {
/* 106 */     StringBuffer buf = new StringBuffer();
/* 107 */     buf.append("<html><table border=\"1px\">");
/* 108 */     buf.append("<tr><td width=\"200px\">");
/* 109 */     buf.append("Invariant options");
/* 110 */     buf.append("</td><td width=\"200px\"></td></tr>");
/* 111 */     buf.append("<tr><td>compute</td><td>");
/* 112 */     if (this.transitions) {
/* 113 */       buf.append("T-Invariants");
/*     */     } else {
/* 115 */       buf.append("P-Invariants");
/* 116 */     }  buf.append("</td></tr>");
/* 117 */     buf.append("<tr><td>exportFile</td><td>");
/* 118 */     if (this.exportFile != null) {
/* 119 */       buf.append(this.exportFile);
/*     */     } else {
/* 121 */       buf.append("not set!");
/* 122 */     }  buf.append("</td></tr><tr><td>deleteTrivial</td><td>");
/* 123 */     buf.append(Boolean.toString(this.deleteTrivial));
/* 124 */     buf.append("</td></tr><tr><td>check coverage</td><td>");
/* 125 */     buf.append(Boolean.toString(this.coverage));
/* 126 */     buf.append("</td></tr><tr><td>check extended coverage</td><td>");
/* 127 */     buf.append(Boolean.toString(this.extendedCoverage));
/* 128 */     buf.append("</td></tr><tr><td>enableMCSC</td><td>");
/* 129 */     buf.append(Boolean.toString(this.enableMCSC));
/* 130 */     buf.append("</td></tr></table></html>");
/* 131 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initializeByString(String parameters) {
/*     */     try {
/* 137 */       this.deleteTrivial = getValue(parameters, "deleteTrivial", this.deleteTrivial);
/* 138 */       this.coverage = getValue(parameters, "coverage", this.coverage);
/* 139 */       this.extendedCoverage = getValue(parameters, "extendedCoverage", this.extendedCoverage);
/* 140 */       this.enableMCSC = getValue(parameters, "enableMCSC", this.enableMCSC);
/* 141 */       this.exportFile = getValue(parameters, "exportFile", this.exportFile);
/* 142 */     } catch (Exception e) {
/* 143 */       e.printStackTrace();
/* 144 */       System.out.printf(getHelpString(), new Object[0]);
/* 145 */       return false;
/*     */     } 
/* 147 */     return true;
/*     */   }
/*     */   public static String getHelpString() {
/* 150 */     StringBuilder buf = new StringBuilder();
/* 151 */     buf.append("\nInvariant options\n");
/* 152 */     buf.append("-----------------\n");
/* 153 */     buf.append("Use --analyze=pinv or --analyze=tinv to invoke a invariant analysis\n");
/* 154 */     String fS = "%30s | %-30s\n";
/* 155 */     buf.append(String.format(fS, new Object[] { "Option name", "option values" }));
/* 156 */     buf.append(String.format(fS, new Object[] { "--deleteTrivial", "0 = no / 1 = yes " }));
/* 157 */     buf.append(String.format(fS, new Object[] { "", "delete trivial invariants " }));
/* 158 */     buf.append(String.format(fS, new Object[] { "--coverage", "0 = no / 1 = yes " }));
/* 159 */     buf.append(String.format(fS, new Object[] { "", "check if net is covered by invariants " }));
/* 160 */     buf.append(String.format(fS, new Object[] { "--enableMCSC", "0 = no / 1 = yes " }));
/* 161 */     buf.append(String.format(fS, new Object[] { "", "check strong coverage " }));
/* 162 */     buf.append(String.format(fS, new Object[] { "--exportFile", "path to a file to export invariants " }));
/* 163 */     buf.append("");
/* 164 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/InvOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */