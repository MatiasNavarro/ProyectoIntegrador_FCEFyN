/*     */ package charlie.analyzer.invariant;
/*     */ 
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.analyzer.algorithm.AlgorithmStatusController;
/*     */ import charlie.analyzer.algorithm.NotSolveableException;
/*     */ import charlie.analyzer.algorithm.SimplexAlgorithm;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StructurallyBoundedAnalyzer
/*     */   extends Analyzer
/*     */   implements AlgorithmStatusController
/*     */ {
/*  27 */   private static final Log LOG = LogFactory.getLog(StructurallyBoundedAnalyzer.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  32 */   private double solution = -1.0D;
/*     */ 
/*     */   
/*     */   public String getName() {
/*  36 */     return "Structurally Bounded Analyzer";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean continueWork() {
/*  46 */     return checkStatus();
/*     */   }
/*     */ 
/*     */   
/*     */   public void analyze() {
/*  51 */     PlaceTransitionNet pn = (PlaceTransitionNet)getObjectToAnalyze();
/*  52 */     double[][] incidenceMatrix = getIncidenceMatrix(pn);
/*     */     
/*  54 */     StructurallyBoundedSimplexAlgorithm simplexAlgorithm = new StructurallyBoundedSimplexAlgorithm(incidenceMatrix);
/*  55 */     simplexAlgorithm.setAlgorithmStatusController(this);
/*     */     try {
/*  57 */       simplexAlgorithm.solve();
/*  58 */     } catch (NotSolveableException e) {
/*  59 */       LOG.error(e.getMessage(), (Throwable)e);
/*     */     } 
/*     */     
/*  62 */     this.solution = simplexAlgorithm.getObjectiveFunctionSolution();
/*  63 */     LOG.debug(String.format("Value of the objective function: %f", new Object[] { Double.valueOf(this.solution) }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluate() {
/*  69 */     if (this.solution < 0.0D) {
/*  70 */       addResult(18, Boolean.valueOf(false));
/*  71 */     } else if (this.solution > 0.0D) {
/*  72 */       LOG.error("There is a bug in the simplex algorithm. The solution must not be positive.");
/*     */     } else {
/*  74 */       addResult(18, Boolean.valueOf(true));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double[][] getIncidenceMatrix(PlaceTransitionNet _pn) {
/*  86 */     double[][] incMatrix = new double[_pn.places()][_pn.transitions()];
/*     */     
/*  88 */     for (int i = 0; i < _pn.places(); i++) {
/*  89 */       for (int j = 0; j < _pn.transitions(); j++) {
/*  90 */         incMatrix[i][j] = _pn.changesTokenOn(_pn.getPlaceByIndex(i), _pn
/*  91 */             .getTransition((short)j));
/*     */       }
/*     */     } 
/*     */     
/*  95 */     return incMatrix;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {}
/*     */ 
/*     */   
/*     */   public Analyzer getNewInstance(OptionSet options) {
/* 104 */     return new StructurallyBoundedAnalyzer();
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeInfoStrings() {
/* 109 */     this.infoStrings = new String[2];
/* 110 */     this.infoStrings[0] = "time:";
/* 111 */     this.infoStrings[1] = getFormatedDuration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean register() {
/* 122 */     StructurallyBoundedAnalyzer sba = new StructurallyBoundedAnalyzer();
/* 123 */     PlaceTransitionNet pn = new PlaceTransitionNet();
/* 124 */     StructurallyBoundedResultSet resultSet = new StructurallyBoundedResultSet();
/*     */     
/* 126 */     return AnalyzerManagerFactory.getAnalyzerManager().register(sba, pn, resultSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class StructurallyBoundedSimplexAlgorithm
/*     */     extends SimplexAlgorithm
/*     */   {
/*     */     public StructurallyBoundedSimplexAlgorithm(double[][] _a) {
/* 142 */       this(_a.length, (_a[0]).length);
/*     */       
/* 144 */       initTableau(_a);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private StructurallyBoundedSimplexAlgorithm(int _col, int _row) {
/* 154 */       super(_row + _col + 1, 2 * _col + 1, _col, _col + _row);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void initTableau(double[][] _a) {
/* 171 */       int n = (_a[0]).length;
/* 172 */       int m = _a.length;
/*     */ 
/*     */       
/*     */       int i;
/*     */       
/* 177 */       for (i = 0; i < m; i++) {
/* 178 */         for (int j = 0; j < n; j++) {
/* 179 */           this.tableau[j][i] = _a[i][j];
/*     */         }
/*     */       } 
/*     */       
/* 183 */       for (i = 0; i < m; i++) {
/*     */         
/* 185 */         this.tableau[n + i][i] = 1.0D;
/*     */         
/* 187 */         this.tableau[n + i][m + i] = -1.0D;
/*     */ 
/*     */         
/* 190 */         this.tableau[n + i][2 * m] = 1.0D;
/*     */         
/* 192 */         this.tableau[n + m][i] = -1.0D;
/* 193 */         this.tableau[n + m][m + i] = 1.0D;
/* 194 */         this.tableau[n + m][2 * m] = -m;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 203 */     double[][] a = { { 1.0D, 3.0D, -3.0D, 0.0D, -2.0D }, { -2.0D, -3.0D, 3.0D, 1.0D, -2.0D }, { 1.0D, 0.0D, 0.0D, -2.0D, 5.0D } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     StructurallyBoundedAnalyzer ana = new StructurallyBoundedAnalyzer();
/* 210 */     ana.getClass(); StructurallyBoundedSimplexAlgorithm simplex = new StructurallyBoundedSimplexAlgorithm(a);
/* 211 */     simplex.printTableau();
/* 212 */     simplex.solve();
/* 213 */     simplex.printTableau();
/*     */     
/* 215 */     System.out.println(simplex.getObjectiveFunctionSolution());
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/StructurallyBoundedAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */