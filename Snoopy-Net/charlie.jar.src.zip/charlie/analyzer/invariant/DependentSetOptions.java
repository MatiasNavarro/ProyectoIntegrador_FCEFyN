/*     */ package charlie.analyzer.invariant;
/*     */ 
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.pn.NodeSet;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class DependentSetOptions
/*     */   extends OptionSet {
/*     */   public boolean decompose = false;
/*  10 */   public NodeSet ignore = null;
/*  11 */   public String sdsFile = "";
/*  12 */   public String adsFile = "";
/*  13 */   public String adsConFile = "";
/*     */   public boolean sds = true;
/*     */   public boolean ads = true;
/*     */   public boolean transitions;
/*     */   
/*     */   public DependentSetOptions() {
/*  19 */     OptionSet[] t = { new InvOptions() };
/*  20 */     this.beforeSet = t;
/*     */   }
/*     */   
/*     */   public DependentSetOptions(boolean supp, boolean occ, boolean decompose, NodeSet ignore, String suppFile, String occFile, String suppConFile, boolean transitions) {
/*  24 */     this();
/*  25 */     this.decompose = decompose;
/*  26 */     this.ads = supp;
/*  27 */     this.sds = occ;
/*  28 */     this.ignore = ignore;
/*  29 */     this.adsFile = suppFile;
/*  30 */     this.sdsFile = occFile;
/*  31 */     this.adsConFile = suppConFile;
/*  32 */     this.transitions = transitions;
/*     */   }
/*     */   public boolean getSupportOption() {
/*  35 */     return this.ads;
/*     */   }
/*     */   public boolean getOccuranceOption() {
/*  38 */     return this.sds;
/*     */   }
/*     */   public String getOccuranceFile() {
/*  41 */     return this.sdsFile;
/*     */   }
/*     */   public String getSupportFile() {
/*  44 */     return this.adsFile;
/*     */   }
/*     */   public String getDecompositionFile() {
/*  47 */     return this.adsConFile;
/*     */   }
/*     */   public boolean getDecompositionOption() {
/*  50 */     return this.decompose;
/*     */   } public OptionSet getInstance() {
/*  52 */     return this;
/*     */   } public Properties getAsProperties() {
/*  54 */     return new Properties();
/*     */   }
/*     */   public boolean initByProperties(Properties props) {
/*  57 */     return false;
/*     */   }
/*     */   public String getHtmlInfo() {
/*  60 */     StringBuffer buf = new StringBuffer();
/*  61 */     buf.append("<html><table border=\"1px\">");
/*  62 */     buf.append("<tr><td width=\"200px\">");
/*  63 */     buf.append("dependent set options");
/*  64 */     buf.append("</td><td width=\"200px\"></td></tr>");
/*  65 */     buf.append("<tr><td>strong dependent sets</td><td>");
/*  66 */     buf.append(Boolean.toString(this.sds));
/*  67 */     buf.append("</td></tr>");
/*  68 */     buf.append("<tr><td>sdsFile</td><td>");
/*  69 */     buf.append(this.sdsFile);
/*  70 */     buf.append("</td></tr><tr><td>abstract dependent sets</td><td>");
/*  71 */     buf.append(Boolean.toString(this.ads));
/*  72 */     buf.append("</td></tr><tr><td>ads file</td><td>");
/*  73 */     buf.append(this.adsFile);
/*  74 */     buf.append("</td></tr><tr><td>connected ads file</td><td>");
/*  75 */     buf.append(this.adsConFile);
/*  76 */     buf.append("</td></tr><tr><td>nodes to ignore</td><td>");
/*  77 */     if (this.ignore != null) {
/*  78 */       buf.append("yes");
/*     */     } else {
/*  80 */       buf.append("no");
/*  81 */     }  buf.append("</td></tr><tr><td>decompose</td><td>");
/*  82 */     buf.append(Boolean.toString(this.decompose));
/*  83 */     buf.append("</td></tr></table></html>");
/*  84 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initializeByString(String parameters) {
/*     */     try {
/*  90 */       this.decompose = getValue(parameters, "decompose", this.decompose);
/*     */       
/*  92 */       this.sdsFile = getValue(parameters, "sdsFile", this.sdsFile);
/*  93 */       this.adsFile = getValue(parameters, "adsFile", this.adsFile);
/*  94 */       this.adsConFile = getValue(parameters, "adsConFile", this.adsConFile);
/*  95 */       this.sds = getValue(parameters, "sds", this.sds);
/*  96 */       this.ads = getValue(parameters, "ads", this.ads);
/*     */     }
/*  98 */     catch (Exception e) {
/*     */       
/* 100 */       System.out.printf("Errormessage: " + e.getMessage() + "\n" + getHelpString(), new Object[0]);
/* 101 */       return false;
/*     */     } 
/* 103 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 108 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 110 */     buf.append("dependent set options\n");
/*     */     
/* 112 */     buf.append("strong dependent sets: ");
/* 113 */     buf.append(Boolean.toString(this.sds));
/* 114 */     buf.append("\n");
/* 115 */     buf.append("sdsFile : ");
/* 116 */     buf.append(this.sdsFile);
/* 117 */     buf.append("\nabstract dependent sets: ");
/* 118 */     buf.append(Boolean.toString(this.ads));
/* 119 */     buf.append("\nads file : ");
/* 120 */     buf.append(this.adsFile);
/* 121 */     buf.append("\nconnected ads file : ");
/* 122 */     buf.append(this.adsConFile);
/* 123 */     buf.append("\nnodes to ignore");
/* 124 */     if (this.ignore != null) {
/* 125 */       buf.append("yes");
/*     */     } else {
/* 127 */       buf.append("no");
/* 128 */     }  buf.append("\ndecompose");
/* 129 */     buf.append(Boolean.toString(this.decompose));
/* 130 */     buf.append("\n");
/* 131 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getHelpString() {
/* 136 */     StringBuilder buf = new StringBuilder();
/* 137 */     buf.append("\nDependent set options\n");
/* 138 */     buf.append("---------------------\n");
/* 139 */     buf.append("Invoke analysis by typing --analyze=dsets or --analyze=dependentsets \n\n");
/* 140 */     buf.append("Dependend set computation needs computation of invariants before, \n so put all options right behind invariant options\n\n");
/* 141 */     String fS = "%30s | %-30s\n";
/* 142 */     buf.append(String.format(fS, new Object[] { "option name", "option values" }));
/* 143 */     buf.append(String.format(fS, new Object[] { "--sds", "0 = no / 1 = yes" }));
/* 144 */     buf.append(String.format(fS, new Object[] { "", "compute the strong dependent sets" }));
/* 145 */     buf.append(String.format(fS, new Object[] { "--ads", "0 = no / 1 = yes" }));
/* 146 */     buf.append(String.format(fS, new Object[] { "", "compute the abstract dependent sets" }));
/* 147 */     buf.append(String.format(fS, new Object[] { "--decompose", "0 = no / 1 = yes" }));
/* 148 */     buf.append(String.format(fS, new Object[] { "", "decompose the abstract dependent sets" }));
/* 149 */     buf.append(String.format(fS, new Object[] { "--sdsFile", "path to a file, if the file exists" }));
/* 150 */     buf.append(String.format(fS, new Object[] { "", "it will be overwritten!" }));
/* 151 */     buf.append(String.format(fS, new Object[] { "--adsFile", "path to a file, if the file exists" }));
/* 152 */     buf.append(String.format(fS, new Object[] { "", "it will be overwritten!" }));
/* 153 */     buf.append(String.format(fS, new Object[] { "--adsConFile", "path to a file, if the file exists" }));
/* 154 */     buf.append(String.format(fS, new Object[] { "", "it will be overwritten!" }));
/* 155 */     buf.append("\n");
/* 156 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/invariant/DependentSetOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */