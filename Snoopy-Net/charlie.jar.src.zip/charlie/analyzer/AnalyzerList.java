/*    */ package charlie.analyzer;
/*    */ 
/*    */ import GUI.threadmanager.AnalyzerDialog;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class AnalyzerList
/*    */   implements Iterable<Analyzer> {
/*  9 */   private AnalyzerDialog dialog = null;
/* 10 */   private ArrayList<Analyzer> list = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addToDialog(AnalyzerDialog dialog) {
/* 18 */     this.dialog = dialog;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void add(Analyzer analyzer) {
/* 24 */     this.list.add(analyzer);
/* 25 */     if (this.dialog != null)
/*    */     {
/* 27 */       this.dialog.add(this, this.list.indexOf(analyzer));
/*    */     }
/*    */   }
/*    */   
/*    */   public Analyzer remove(int index) throws IndexOutOfBoundsException {
/* 32 */     if (index < 0 || index > this.list.size()) {
/* 33 */       throw new IndexOutOfBoundsException("AnalyzerList.remove: Index exceeded the allowed range 0 -> " + this.list.size());
/*    */     }
/* 35 */     Analyzer a = this.list.get(index);
/*    */     
/* 37 */     this.list.remove(index);
/* 38 */     if (this.dialog != null) {
/* 39 */       this.dialog.remove(this, index);
/*    */     }
/* 41 */     return a;
/*    */   }
/*    */   
/*    */   public Iterator<Analyzer> iterator() {
/* 45 */     return this.list.iterator();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean remove(Analyzer analyzer) {
/* 50 */     int index = this.list.indexOf(analyzer);
/* 51 */     boolean value = this.list.remove(analyzer);
/* 52 */     if (this.dialog != null && value) {
/* 53 */       this.dialog.remove(this, index);
/*    */     }
/* 55 */     return value;
/*    */   }
/*    */   
/*    */   public int size() {
/* 59 */     return this.list.size();
/*    */   }
/*    */   
/*    */   public Analyzer get(int index) throws IndexOutOfBoundsException {
/* 63 */     if (index < 0 || index > this.list.size()) {
/* 64 */       throw new IndexOutOfBoundsException("AnalyzerList.get(): Index exceeded the allowed range 0 -> " + this.list.size());
/*    */     }
/*    */     
/* 67 */     return this.list.get(index);
/*    */   }
/*    */   
/*    */   public void clear() {
/* 71 */     this.list.clear();
/* 72 */     if (this.dialog != null) {
/* 73 */       this.dialog.clear();
/*    */     }
/*    */   }
/*    */   
/*    */   public void update() {
/* 78 */     if (this.dialog != null)
/* 79 */       this.dialog.update(this, 0, this.list.size() - 1); 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/AnalyzerList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */