/*     */ package charlie.analyzer;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.pn.Out;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnalyzerManager
/*     */ {
/*  31 */   private static final Log LOG = LogFactory.getLog(AnalyzerManager.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   private List<AnalyzerSet> analyzerList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean register(Analyzer analyzer, OptionSet options) {
/*  54 */     if (LOG.isDebugEnabled()) {
/*  55 */       LOG.debug(String.format("Trying to register analyzer '%s' (%s) for option set '%s' for analyzing object '%s' and result object '%s'.", new Object[] { analyzer.getName(), analyzer.getClass().getName(), options
/*  56 */               .getClass().getName(), options
/*  57 */               .getObjectToAnalyze().getClass().getName(), options.getResultObject().getClass().getName() }));
/*     */     }
/*     */     
/*  60 */     if (getAnalyzer(options) == null) {
/*  61 */       if (LOG.isDebugEnabled()) {
/*  62 */         LOG.debug(String.format("Registering analyzer '%s' (%s) was successfull.", new Object[] { analyzer.getName(), analyzer.getClass().getName() }));
/*     */       }
/*     */       
/*  65 */       this.analyzerList.add(new AnalyzerSet(analyzer, options));
/*  66 */       return true;
/*     */     } 
/*  68 */     LOG.debug(String.format("There is already an analzyer registered for the type of option set '%s' and for analyzing object '%s' and result object '%s'.", new Object[] { options.getClass().getName(), options
/*  69 */             .getObjectToAnalyze().getClass().getName(), options.getResultObject().getClass().getName() }));
/*  70 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean register(Analyzer analyzer, Object objectToAnalyze, Object resultObject) {
/*  91 */     if (LOG.isDebugEnabled()) {
/*  92 */       LOG.debug(String.format("Trying to register analyzer '%s' (%s) for analyzing object '%s' and result object '%s'.", new Object[] { analyzer.getName(), analyzer.getClass().getName(), objectToAnalyze
/*  93 */               .getClass().getName(), resultObject.getClass().getName() }));
/*     */     }
/*     */     
/*  96 */     if (getAnalyzerByName(objectToAnalyze, resultObject) == null) {
/*  97 */       if (LOG.isDebugEnabled()) {
/*  98 */         LOG.debug(String.format("Registering analyzer '%s' (%s) was successfull.", new Object[] { analyzer.getName(), analyzer.getClass().getName() }));
/*     */       }
/*     */       
/* 101 */       this.analyzerList.add(new AnalyzerSet(analyzer, objectToAnalyze, resultObject));
/* 102 */       return true;
/*     */     } 
/* 104 */     LOG.debug(String.format("There is already an analzyer registered for analyzing object '%s' and result object '%s'.", new Object[] { objectToAnalyze
/* 105 */             .getClass().getName(), resultObject.getClass().getName() }));
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean compute(OptionSet options) {
/* 111 */     if (options == null) {
/* 112 */       LOG.warn("Option set is null.");
/* 113 */       return false;
/*     */     } 
/* 115 */     if (options.getObjectToAnalyze() == null) {
/* 116 */       LOG.warn("Analyzing object is null.");
/* 117 */       return false;
/*     */     } 
/* 119 */     if (options.getResultObject() == null) {
/* 120 */       LOG.warn("Result object is null.");
/* 121 */       return false;
/*     */     } 
/*     */     
/* 124 */     if (LOG.isDebugEnabled()) {
/* 125 */       LOG.debug(String.format("Trying to compute option set '%s' (analyzing object '%s'; result object '%s').", new Object[] { options
/* 126 */               .getClass().getName(), options.getObjectToAnalyze().getClass().getName(), options.getResultObject().getClass().getName() }));
/*     */     }
/*     */     
/* 129 */     Analyzer a = getAnalyzer(options);
/* 130 */     if (a == null) {
/* 131 */       Object objectToAnalyze = options.getObjectToAnalyze();
/* 132 */       Object resultObject = options.getResultObject();
/* 133 */       if (objectToAnalyze == null) {
/* 134 */         DebugCounter.inc("AnalyzerManager: objectToAnalyze is null for " + options.getClass().getName());
/* 135 */         return false;
/*     */       } 
/* 137 */       if (resultObject == null) {
/* 138 */         DebugCounter.inc("AnalyzerManager: resultObject is null for " + options.getClass().getName());
/* 139 */         return false;
/*     */       } 
/* 141 */       a = getAnalyzer(objectToAnalyze, resultObject);
/*     */     } 
/* 143 */     if (a != null) {
/* 144 */       Analyzer newAnalyzer = a.getNewInstance(options);
/* 145 */       if (newAnalyzer == null) {
/* 146 */         return false;
/*     */       }
/* 148 */       if (newAnalyzer.getStatus() != -1)
/*     */       {
/* 150 */         newAnalyzer.setup(options);
/*     */       }
/* 152 */       if (!(options.initiator instanceof charlie.Charlie))
/*     */       {
/* 154 */         ThreadManagerFactory.getThreadManager().createGui();
/*     */       }
/*     */       
/* 157 */       ThreadManagerFactory.getThreadManager().add(newAnalyzer);
/* 158 */       return true;
/*     */     } 
/*     */     
/* 161 */     DebugCounter.inc("AnalyzerManager.compute() newAnalyzer==null\n could not find analyzer for optionset:\n " + options.getClass().getName());
/*     */     
/* 163 */     return false;
/*     */   }
/*     */   
/*     */   public boolean compute(Object objectToAnalyze, Object resultObject, OptionSet options, Initiator initiator) {
/* 167 */     if (options == null) {
/* 168 */       LOG.warn("Option set is null.");
/* 169 */       return false;
/*     */     } 
/* 171 */     if (objectToAnalyze == null) {
/* 172 */       LOG.warn("Analyzing object is null.");
/* 173 */       return false;
/*     */     } 
/* 175 */     if (resultObject == null) {
/* 176 */       LOG.warn("Result object is null.");
/* 177 */       return false;
/*     */     } 
/*     */     
/* 180 */     if (LOG.isDebugEnabled()) {
/* 181 */       LOG.debug(String.format("Trying to compute option set '%s' (analyzing object '%s'; result object '%s').", new Object[] { options
/* 182 */               .getClass().getName(), objectToAnalyze
/* 183 */               .getClass().getName(), resultObject
/* 184 */               .getClass().getName() }));
/*     */     }
/*     */     
/* 187 */     Analyzer a = getAnalyzer(objectToAnalyze, resultObject);
/* 188 */     if (a != null) {
/* 189 */       Analyzer newAnalyzer = a.getNewInstance(options);
/* 190 */       if (newAnalyzer.getStatus() != -1) {
/* 191 */         newAnalyzer.setup(objectToAnalyze, options, resultObject);
/*     */       }
/* 193 */       if (initiator != null) {
/* 194 */         options.initiator = initiator;
/*     */       }
/* 196 */       if (!(initiator instanceof charlie.Charlie)) {
/* 197 */         ThreadManagerFactory.getThreadManager().createGui();
/*     */       }
/* 199 */       ThreadManagerFactory.getThreadManager().add(newAnalyzer);
/* 200 */       return true;
/*     */     } 
/*     */     
/* 203 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean compute(Object objectToAnalyze, Object resultObject, Initiator initiator) {
/* 220 */     if (objectToAnalyze == null) {
/* 221 */       LOG.warn("Analyzing object is null.");
/* 222 */       return false;
/*     */     } 
/* 224 */     if (resultObject == null) {
/* 225 */       LOG.warn("Result object is null.");
/* 226 */       return false;
/*     */     } 
/*     */     
/* 229 */     if (LOG.isDebugEnabled()) {
/* 230 */       LOG.debug(String.format("Trying to compute analyzing object '%s' and result object '%s'.", new Object[] { objectToAnalyze
/* 231 */               .getClass().getName(), resultObject.getClass().getName() }));
/*     */     }
/*     */     
/* 234 */     OptionSet options = new OptionSet()
/*     */       {
/*     */         private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public String toString() {
/* 243 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean initializeByString(String parameters) {
/* 248 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean initByProperties(Properties props) {
/* 253 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getHtmlInfo() {
/* 258 */           StringBuffer buf = new StringBuffer();
/* 259 */           buf.append("<html><table>");
/* 260 */           buf.append("<tr><td width=\"200px\">");
/* 261 */           buf.append("deadlock options");
/* 262 */           buf.append("</td><td width=\"200px\"></td></tr>");
/* 263 */           buf.append("</table></html>");
/* 264 */           return buf.toString();
/*     */         }
/*     */ 
/*     */         
/*     */         public Properties getAsProperties() {
/* 269 */           return null;
/*     */         }
/*     */       };
/*     */     
/* 273 */     return compute(objectToAnalyze, resultObject, options, initiator);
/*     */   }
/*     */   
/*     */   public void analyzerHasFinished(Analyzer finishedAnalyzer) {
/* 277 */     DebugCounter.inc("AnalyzerManager.analyzerHasFinished " + finishedAnalyzer.getName());
/* 278 */     Out.println("Analyzer has finished: " + finishedAnalyzer.getName());
/* 279 */     Out.println(finishedAnalyzer.getOutput() + "\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 286 */     OptionSet options = finishedAnalyzer.getOptionSet();
/* 287 */     ThreadManagerFactory.getThreadManager().setFinished(finishedAnalyzer);
/*     */     
/* 289 */     if (options.nextStage != null) {
/* 290 */       DebugCounter.inc("AnalyzerManager.analyzerHasFinished: there is a next stage!");
/*     */       
/* 292 */       OptionSet o = options.nextStage;
/* 293 */       Object objectToAnalyze = null;
/* 294 */       Object resultObject = finishedAnalyzer.getResultObject();
/*     */       
/* 296 */       if (o.getObjectToAnalyze() != null) {
/* 297 */         DebugCounter.inc("AnalyzerManager. next stage using defined objectToAnalyze : " + o.getObjectToAnalyze().getClass().getName());
/* 298 */         objectToAnalyze = o.getObjectToAnalyze();
/*     */       } else {
/*     */         
/* 301 */         DebugCounter.inc("AnalyzerManager. next stage using objectToAnalyze from previous analysis: " + finishedAnalyzer.getResultObject().getClass().getName());
/* 302 */         objectToAnalyze = finishedAnalyzer.getResultObject();
/*     */       } 
/*     */ 
/*     */       
/* 306 */       o.addPreviousResults(options);
/* 307 */       o.setObjectToAnalyze(objectToAnalyze);
/*     */       
/* 309 */       if (o.initiator == null) {
/* 310 */         if (options.initiator != null) {
/* 311 */           o.initiator = options.initiator;
/* 312 */         } else if (finishedAnalyzer.getInitiator() != null) {
/* 313 */           o.initiator = finishedAnalyzer.getInitiator();
/*     */         } 
/*     */       }
/*     */       
/* 317 */       if (o.getResultObject() != null && o.getObjectToAnalyze() != null) {
/* 318 */         DebugCounter.inc("AnalyzerManager. next stage start computation!\n try computing result:" + o.getResultObject().getClass().getName());
/* 319 */         DebugCounter.inc("from :" + o.getObjectToAnalyze().getClass().getName() + " \n" + o.getObjectToAnalyze().toString());
/* 320 */         if (!compute(o)) {
/* 321 */           DebugCounter.inc("Could not start next stage analysis, inform previous stage initiator!");
/* 322 */           if (options.initiator != null) {
/* 323 */             options.initiator.analyzerHasFinished(finishedAnalyzer);
/*     */           }
/*     */           return;
/*     */         } 
/*     */       } else {
/* 328 */         DebugCounter.inc("AnalyzerManager: next stage could not be started, resultObject=" + o.getResultObject() + " objToAnaly:" + o.getObjectToAnalyze());
/*     */       } 
/*     */     } else {
/* 331 */       DebugCounter.inc("AnalyzerManager.analyzerHasFinished: there is NO next stage!");
/*     */       
/* 333 */       Initiator initiator = finishedAnalyzer.getInitiator();
/* 334 */       if (initiator != null) {
/* 335 */         DebugCounter.inc("initiator class name:" + initiator.getClass().getName());
/* 336 */         initiator.analyzerHasFinished(finishedAnalyzer);
/*     */       } else {
/* 338 */         DebugCounter.inc("No Initiator defined on analyzer: " + finishedAnalyzer.getName());
/*     */       } 
/* 340 */       ThreadManagerFactory.getThreadManager().update();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Analyzer getAnalyzer(OptionSet options) {
/* 345 */     if (options == null) {
/* 346 */       return null;
/*     */     }
/* 348 */     String optionsClass = options.getClass().getName();
/*     */     
/* 350 */     for (AnalyzerSet set : this.analyzerList) {
/* 351 */       if (set.optionSet != null) {
/* 352 */         String setClass = set.optionSet.getClass().getName();
/* 353 */         if (optionsClass.equals(setClass)) {
/* 354 */           return set.analyzer;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 359 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Analyzer getAnalyzer(Object objectToAnalyze, Object resultObject) {
/* 373 */     if (objectToAnalyze == null || resultObject == null) {
/* 374 */       return null;
/*     */     }
/*     */     
/* 377 */     Analyzer analyzer = getAnalyzerByName(objectToAnalyze, resultObject);
/* 378 */     if (analyzer != null) {
/* 379 */       return analyzer;
/*     */     }
/*     */     
/* 382 */     for (AnalyzerSet set : this.analyzerList) {
/* 383 */       if (set.objectToAnalyze != null && set.resultObject != null && 
/* 384 */         set.resultObject.getClass().isAssignableFrom(resultObject.getClass()) && set.objectToAnalyze.getClass().isAssignableFrom(objectToAnalyze.getClass())) {
/* 385 */         return set.analyzer;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 390 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Analyzer getAnalyzerByName(Object objectToAnalyze, Object resultObject) {
/* 405 */     if (objectToAnalyze == null || resultObject == null) {
/* 406 */       return null;
/*     */     }
/*     */     
/* 409 */     for (AnalyzerSet set : this.analyzerList) {
/* 410 */       if (set.objectToAnalyze != null && set.resultObject != null && 
/* 411 */         set.resultObject.getClass().getName().equals(resultObject.getClass().getName()) && set.objectToAnalyze
/* 412 */         .getClass().getName().equals(objectToAnalyze.getClass().getName())) {
/* 413 */         return set.analyzer;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 418 */     return null;
/*     */   }
/*     */   
/*     */   public synchronized void resetAllAnalyzers() {
/* 422 */     for (AnalyzerSet set : this.analyzerList) {
/* 423 */       set.analyzer.reset();
/*     */     }
/* 425 */     ThreadManagerFactory.getThreadManager().reset();
/*     */   }
/*     */   
/*     */   private class AnalyzerSet {
/* 429 */     public Analyzer analyzer = null;
/* 430 */     public Object objectToAnalyze = null;
/* 431 */     public Object resultObject = null;
/* 432 */     public OptionSet optionSet = null;
/*     */     
/*     */     public AnalyzerSet(Analyzer analyzer, OptionSet set) {
/* 435 */       this.analyzer = analyzer;
/* 436 */       this.optionSet = set;
/*     */     }
/*     */     
/*     */     public AnalyzerSet(Analyzer analyzer, Object objectToAnalyze, Object resultObject) {
/* 440 */       this.analyzer = analyzer;
/* 441 */       this.objectToAnalyze = objectToAnalyze;
/* 442 */       this.resultObject = resultObject;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 447 */       if (this.analyzer != null && this.objectToAnalyze != null && this.resultObject != null)
/* 448 */         return "AnalyzerSet[analyzer=" + this.analyzer.getName() + " : objectToAnalyze= " + this.objectToAnalyze.getClass().getName() + " : resultObject= " + this.resultObject
/* 449 */           .getClass().getName() + "]"; 
/* 450 */       if (this.analyzer != null && this.optionSet != null) {
/* 451 */         return "AnalyzerSet[analyzer=" + this.analyzer.getName() + " : optionSet = " + this.optionSet.getClass().getName() + "]";
/*     */       }
/* 453 */       return "Analyzer set not initalized correctly";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/AnalyzerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */