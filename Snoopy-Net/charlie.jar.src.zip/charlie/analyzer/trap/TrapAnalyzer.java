/*     */ package charlie.analyzer.trap;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.pn.NodeSet;
/*     */ import charlie.pn.PlaceSet;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TrapAnalyzer
/*     */   extends Analyzer
/*     */ {
/*  17 */   private PlaceTransitionNet pn = null;
/*  18 */   private Trap ddl2 = null;
/*  19 */   private Trap old2 = null;
/*  20 */   private String info = "";
/*  21 */   private TrapOptions trapOptions = null;
/*     */   
/*     */   public TrapAnalyzer() {
/*  24 */     setUpdateInterval(250L);
/*  25 */     this.ddl2 = new Trap();
/*  26 */     this.old2 = new Trap();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  31 */     return "Trap Analyzer";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean register() {
/*  40 */     TrapAnalyzer ta = new TrapAnalyzer();
/*     */     
/*  42 */     return AnalyzerManagerFactory.getAnalyzerManager().register(ta, new PlaceTransitionNet(), new Trap());
/*     */   }
/*     */ 
/*     */   
/*     */   public Analyzer getNewInstance(OptionSet options) {
/*  47 */     TrapAnalyzer a = new TrapAnalyzer();
/*  48 */     a.setup(options);
/*  49 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeInfoStrings() {
/*  57 */     int count = 4;
/*  58 */     this.infoStrings = new String[count];
/*  59 */     this.infoStrings[0] = "minimal traps:";
/*  60 */     if (this.ddl2 != null) {
/*  61 */       this.infoStrings[1] = Integer.toString(this.ddl2.size());
/*     */     } else {
/*  63 */       this.infoStrings[1] = "0";
/*     */     } 
/*  65 */     this.infoStrings[2] = "time";
/*  66 */     this.infoStrings[3] = getFormatedDuration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void evaluate() {
/*  76 */     if (this.trapOptions == null && this.options != null && this.options instanceof TrapOptions) {
/*  77 */       this.trapOptions = (TrapOptions)this.options;
/*     */     }
/*  79 */     if (this.trapOptions.exportFile != null) {
/*  80 */       this.ddl2.writeToFile(this.trapOptions.exportFile.getAbsolutePath());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void analyze() {
/*  92 */     DebugCounter.inc("TrapAnalyzer run!\n");
/*  93 */     if (this.options instanceof TrapOptions) {
/*  94 */       this.trapOptions = (TrapOptions)this.options;
/*     */     } else {
/*  96 */       DebugCounter.inc("TrapAnalyzer initialized with wrong OptionSet\n " + this.options.getClass().getName());
/*     */       
/*     */       return;
/*     */     } 
/* 100 */     this.options.setResultObject(compute());
/* 101 */     if (this.trapOptions.export) {
/* 102 */       DebugCounter.inc("TrapAnalyzer export file: " + this.trapOptions.exportFile);
/*     */     }
/*     */   }
/*     */   
/*     */   private void add(HashSet<NodeSet> hs, NodeSet d) {
/* 107 */     if (hs == null || hs.iterator() == null) {
/*     */       return;
/*     */     }
/* 110 */     HashSet<NodeSet> del = new HashSet<>(); Iterator<NodeSet> it;
/* 111 */     for (it = hs.iterator(); it.hasNext(); ) {
/* 112 */       NodeSet ss = it.next();
/* 113 */       if (d.subSet(ss)) {
/* 114 */         del.add(ss); continue;
/* 115 */       }  if (ss.subSet(d)) {
/*     */         return;
/*     */       }
/*     */     } 
/* 119 */     for (it = del.iterator(); it.hasNext();) {
/* 120 */       hs.remove(it.next());
/*     */     }
/*     */     
/* 123 */     hs.add(d);
/*     */   }
/*     */   
/*     */   public Set<PlaceSet> compute() {
/* 127 */     addOutput("Trap Analyzer: \ncomputed minimal traps\n\t");
/* 128 */     this.pn = (PlaceTransitionNet)this.options.getObjectToAnalyze();
/* 129 */     this.ddl2.clear();
/* 130 */     this.old2.clear();
/* 131 */     traps((NodeSet)new PlaceSet(this.pn.places()), (NodeSet)new PlaceSet(this.pn.places(), this.pn.places()));
/* 132 */     addOutput("minimal traps:");
/*     */     
/* 134 */     if (this.trapOptions.properSets) {
/* 135 */       HashSet<PlaceSet> del = new HashSet<>(); Iterator<PlaceSet> it;
/* 136 */       for (it = this.ddl2.iterator(); it.hasNext(); ) {
/* 137 */         PlaceSet ps = it.next();
/* 138 */         if (!checkStatus()) {
/* 139 */           cleanup();
/* 140 */           return null;
/*     */         } 
/* 142 */         if (ps.isPinvariant()) {
/* 143 */           del.add(ps);
/*     */         }
/*     */       } 
/*     */       
/* 147 */       for (it = del.iterator(); it.hasNext(); ) {
/* 148 */         this.ddl2.remove(it.next());
/* 149 */         if (!checkStatus()) {
/* 150 */           cleanup();
/* 151 */           return null;
/*     */         } 
/*     */       } 
/* 154 */       this.info += this.ddl2.size() + " minimal proper traps computed in " + getFormatedDuration() + "\n";
/*     */     } else {
/* 156 */       this.info += this.ddl2.size() + " minimal traps computed in " + getFormatedDuration() + "\n";
/*     */     } 
/* 158 */     addOutput(this.info);
/* 159 */     this.options.setResultObject(this.ddl2);
/*     */     
/* 161 */     return this.ddl2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<PlaceSet> traps(NodeSet q, NodeSet r) {
/* 167 */     while (!r.isEmpty()) {
/* 168 */       if (!checkStatus()) {
/* 169 */         cleanup();
/* 170 */         return null;
/*     */       } 
/* 172 */       NodeSet d = q.copy();
/* 173 */       d.insert(r.first());
/* 174 */       boolean existD = false;
/* 175 */       for (Iterator<PlaceSet> it = this.ddl2.iterator(); it.hasNext(); ) {
/* 176 */         NodeSet ss = (NodeSet)it.next();
/* 177 */         if (ss.subSet(d)) {
/* 178 */           existD = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 182 */       if (!existD) {
/* 183 */         NodeSet df = d.getPost();
/* 184 */         NodeSet fd = d.getPre();
/* 185 */         if (df.subSet(fd)) {
/* 186 */           add(this.ddl2, d); continue;
/*     */         } 
/* 188 */         boolean existS = false;
/* 189 */         for (Iterator<PlaceSet> iterator = this.old2.iterator(); iterator.hasNext(); ) {
/* 190 */           NodeSet ss = (NodeSet)iterator.next();
/* 191 */           if (ss.subSet(d)) {
/* 192 */             existS = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 197 */         if (!existS) {
/*     */           
/* 199 */           df = d.getPost();
/* 200 */           df.diff(d.getPre());
/*     */           
/* 202 */           NodeSet postPlaces = df.getPost();
/* 203 */           postPlaces.diff(d);
/* 204 */           traps(d, postPlaces);
/* 205 */           if (getStatus() != 4) {
/* 206 */             add(this.old2, d);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 213 */     return this.ddl2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/* 219 */     this.ddl2 = null;
/* 220 */     this.old2 = null;
/* 221 */     System.gc();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/trap/TrapAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */