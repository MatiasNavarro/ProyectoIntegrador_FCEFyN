/*     */ package charlie.analyzer.trap;
/*     */ 
/*     */ import GUI.preference.FilterFactory;
/*     */ import GUI.preference.SiphonTrapFilterPreference;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import java.io.File;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class TrapOptions
/*     */   extends OptionSet
/*     */ {
/*     */   private boolean compute = false;
/*     */   public boolean export = false;
/*     */   public boolean properSets = false;
/*  15 */   public File exportFile = null;
/*     */   
/*     */   public TrapOptions() {
/*  18 */     setLogOutput(!FilterFactory.getFilterProperties().isFiltered(SiphonTrapFilterPreference.FILTER_SIPHON_TRAP_TRAP.getKey()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  23 */     String s = "TrapOptions:\n";
/*  24 */     s = s + "compute: " + Boolean.toString(this.compute) + "\n";
/*  25 */     s = s + "export: " + Boolean.toString(this.export) + "\n";
/*  26 */     s = s + "exportFile: ";
/*  27 */     if (this.exportFile != null) {
/*  28 */       s = s + this.exportFile.getAbsolutePath();
/*     */     } else {
/*  30 */       s = s + " not set!";
/*     */     } 
/*  32 */     s = s + "\n";
/*  33 */     s = s + "properSets: " + Boolean.toString(this.properSets);
/*  34 */     return s;
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties getAsProperties() {
/*  39 */     Properties p = new Properties();
/*  40 */     if (this.compute) {
/*  41 */       p.setProperty("trapOptions_compute", "true");
/*     */     } else {
/*  43 */       p.setProperty("trapOptions_compute", "false");
/*     */     } 
/*  45 */     if (this.export) {
/*  46 */       p.setProperty("trapOptions_export", "true");
/*     */     } else {
/*  48 */       p.setProperty("trapOptions_export", "false");
/*     */     } 
/*  50 */     if (this.properSets) {
/*  51 */       p.setProperty("trapOptions_properSets", "true");
/*     */     } else {
/*  53 */       p.setProperty("trapOptions_properSets", "false");
/*     */     } 
/*  55 */     if (this.exportFile != null) {
/*  56 */       p.setProperty("trapOptions_exportFile", this.exportFile.getAbsolutePath());
/*     */     }
/*  58 */     return p;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initByProperties(Properties p) {
/*  63 */     String s = p.getProperty("trapOptions_compute");
/*  64 */     if (s != null) {
/*  65 */       if (s.equals("true")) {
/*  66 */         this.compute = true;
/*  67 */       } else if (s.equals("false")) {
/*  68 */         this.compute = false;
/*     */       } 
/*     */     }
/*  71 */     s = null;
/*  72 */     s = p.getProperty("trapOptions_export");
/*  73 */     if (s != null) {
/*  74 */       if (s.equals("true")) {
/*  75 */         this.export = true;
/*  76 */       } else if (s.equals("false")) {
/*  77 */         this.export = false;
/*     */       } 
/*     */     }
/*     */     
/*  81 */     s = null;
/*  82 */     s = p.getProperty("trapOptions_properSets");
/*  83 */     if (s != null) {
/*  84 */       if (s.equals("true")) {
/*  85 */         this.properSets = true;
/*  86 */       } else if (s.equals("false")) {
/*  87 */         this.properSets = false;
/*     */       } 
/*     */     }
/*  90 */     s = null;
/*  91 */     s = p.getProperty("trapOptions_exportFile");
/*  92 */     if (s != null && 
/*  93 */       !s.equals("")) {
/*  94 */       this.exportFile = new File(s);
/*     */     }
/*     */     
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHtmlInfo() {
/* 102 */     StringBuffer buf = new StringBuffer();
/* 103 */     buf.append("<html><table>");
/* 104 */     buf.append("<tr><td width=\"200px\">");
/* 105 */     buf.append("trap options");
/* 106 */     buf.append("</td><td width=\"200px\"></td></tr>");
/* 107 */     buf.append("<tr><td>");
/* 108 */     buf.append("exportFile");
/* 109 */     buf.append("</td><td>");
/* 110 */     if (this.exportFile != null) {
/* 111 */       buf.append(this.exportFile.getName());
/*     */     } else {
/* 113 */       buf.append("not set!");
/*     */     } 
/* 115 */     buf.append("</td></tr>");
/*     */     
/* 117 */     buf.append("<tr><td>");
/* 118 */     buf.append("properSets");
/* 119 */     buf.append("</td><td>");
/* 120 */     buf.append(Boolean.toString(this.properSets));
/* 121 */     buf.append("</td></tr>");
/* 122 */     buf.append("<tr><td>");
/* 123 */     buf.append("export");
/* 124 */     buf.append("</td><td>");
/* 125 */     buf.append(Boolean.toString(this.export));
/* 126 */     buf.append("</td></tr>");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     buf.append("</table></html>");
/* 133 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initializeByString(String parameters) {
/*     */     try {
/* 139 */       this.compute = true;
/* 140 */       this.properSets = getValue(parameters, "properSets", this.properSets);
/* 141 */       this.exportFile = getValue(parameters, "exportFile", this.exportFile);
/* 142 */       if (this.exportFile != null && this.exportFile.exists()) {
/* 143 */         this.export = true;
/*     */       }
/* 145 */     } catch (Exception e) {
/* 146 */       e.printStackTrace();
/* 147 */       return false;
/*     */     } 
/* 149 */     return true;
/*     */   }
/*     */   
/*     */   public static String getHelpString() {
/* 153 */     StringBuilder buf = new StringBuilder();
/* 154 */     buf.append("\nTrap computation options\n");
/* 155 */     buf.append("------------------------\n");
/* 156 */     buf.append("Invoke analysis by typing --analyze=trap or --analyze=traps\n\n");
/* 157 */     String fS = "%30s | %-30s\n";
/* 158 */     buf.append(String.format(fS, new Object[] { "option name", "option values" }));
/* 159 */     buf.append(String.format(fS, new Object[] { "--properSets", "0 = no / 1 = yes" }));
/* 160 */     buf.append(String.format(fS, new Object[] { "", "compute proper sets" }));
/* 161 */     buf.append(String.format(fS, new Object[] { "--exportFile", "File to export the computed traps" }));
/* 162 */     buf.append("\n");
/*     */     
/* 164 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public boolean isCompute() {
/* 168 */     return this.compute;
/*     */   }
/*     */   
/*     */   public void setCompute(boolean _compute) {
/* 172 */     this.compute = _compute;
/*     */   }
/*     */   
/*     */   public boolean isExport() {
/* 176 */     return this.export;
/*     */   }
/*     */   
/*     */   public void setExport(boolean _export) {
/* 180 */     this.export = _export;
/*     */   }
/*     */   
/*     */   public boolean isProperSets() {
/* 184 */     return this.properSets;
/*     */   }
/*     */   
/*     */   public void setProperSets(boolean _properSets) {
/* 188 */     this.properSets = _properSets;
/*     */   }
/*     */   
/*     */   public File getExportFile() {
/* 192 */     return this.exportFile;
/*     */   }
/*     */   
/*     */   public void setExportFile(File _exportFile) {
/* 196 */     this.exportFile = _exportFile;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/trap/TrapOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */