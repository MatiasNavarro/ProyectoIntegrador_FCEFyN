/*    */ package charlie.analyzer.trap;
/*    */ 
/*    */ import GUI.util.TextFile;
/*    */ import charlie.pn.PlaceSet;
/*    */ import java.io.File;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Trap
/*    */   extends HashSet<PlaceSet>
/*    */ {
/*    */   private static final long serialVersionUID = -2848498050880399057L;
/*    */   public boolean proper = false;
/*    */   
/*    */   public void writeToFile(String filename) {
/* 25 */     if (filename == null) {
/*    */       return;
/*    */     }
/*    */     
/* 29 */     StringBuffer buf = new StringBuffer();
/* 30 */     if (this.proper) {
/* 31 */       buf.append(" minimal proper traps ( place )= ");
/*    */     } else {
/* 33 */       buf.append(" minimal traps ( place )= ");
/*    */     } 
/* 35 */     buf.append("\n");
/*    */     
/* 37 */     int i = 1;
/* 38 */     for (Iterator<PlaceSet> it = iterator(); it.hasNext(); ) {
/* 39 */       buf.append("\n" + i);
/* 40 */       PlaceSet ps = it.next();
/* 41 */       buf.append(ps.toString());
/* 42 */       i++;
/*    */     } 
/* 44 */     TextFile.writeToFile(new File(filename), buf, true);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/analyzer/trap/Trap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */