/*    */ package charlie.vis;
/*    */ 
/*    */ import edu.uci.ics.jung.graph.DirectedGraph;
/*    */ import edu.uci.ics.jung.graph.impl.SparseGraph;
/*    */ import java.util.Collection;
/*    */ import org.apache.commons.collections.Predicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiGraph
/*    */   extends SparseGraph
/*    */   implements DirectedGraph
/*    */ {
/*    */   public DiGraph() {
/* 48 */     Collection<Predicate> edge_predicates = getEdgeConstraints();
/* 49 */     edge_predicates.add(DIRECTED_EDGE);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/DiGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */