/*    */ package charlie.vis;
/*    */ 
/*    */ import edu.uci.ics.jung.graph.Vertex;
/*    */ import edu.uci.ics.jung.graph.decorators.VertexPaintFunction;
/*    */ import java.awt.Color;
/*    */ import java.awt.Paint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RGVertexPaintFunction
/*    */   implements VertexPaintFunction
/*    */ {
/*    */   ViewerInfo vi;
/*    */   private final Color[] blues;
/*    */   
/*    */   public RGVertexPaintFunction(ViewerInfo vi) {
/* 18 */     this.blues = new Color[] { new Color(0, 0, 0), new Color(0, 255, 255), new Color(0, 170, 255), new Color(0, 136, 255), new Color(0, 68, 255), new Color(0, 0, 255), new Color(0, 0, 170), new Color(0, 0, 88), new Color(0, 0, 68) };
/*    */     this.vi = vi;
/*    */   }
/*    */   public Paint getDrawPaint(Vertex vertex) {
/* 22 */     if (this.vi.isMarked((VisNode)vertex)) return Color.RED; 
/* 23 */     return Color.black;
/*    */   }
/*    */   
/*    */   public Paint getFillPaint(Vertex vertex) {
/* 27 */     VisNode v = (VisNode)vertex;
/* 28 */     if (this.vi.isMarked(v)) return Color.RED; 
/* 29 */     int commoness = this.vi.pathContains(v);
/*    */     
/* 31 */     if (commoness > 0)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 37 */       return this.blues[commoness];
/*    */     }
/*    */     
/* 40 */     if (this.vi.isFiltered(v)) return Options.filterColor; 
/* 41 */     if (this.vi.rg.getDeadStates().contains(v.getRGNode())) return Color.BLACK;
/*    */     
/* 43 */     return (Color)v.getUserDatum(RGVisualisation.VisColorKey);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/RGVertexPaintFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */