/*    */ package charlie.vis;
/*    */ 
/*    */ import edu.uci.ics.jung.graph.Edge;
/*    */ import edu.uci.ics.jung.graph.decorators.EdgePaintFunction;
/*    */ import java.awt.Color;
/*    */ import java.awt.Paint;
/*    */ 
/*    */ public class RGEdgePaintFunction
/*    */   implements EdgePaintFunction
/*    */ {
/*    */   ViewerInfo vi;
/*    */   
/*    */   public RGEdgePaintFunction(ViewerInfo vi) {
/* 14 */     this.vi = vi;
/*    */   }
/*    */   
/*    */   public Paint getDrawPaint(Edge e) {
/* 18 */     if (this.vi.markedEdges.contains(e))
/* 19 */       return Color.RED; 
/* 20 */     if (this.vi.getPath() != null && this.vi.pathEdges.contains(e)) {
/* 21 */       return Color.BLUE;
/*    */     }
/* 23 */     return Color.BLACK;
/*    */   }
/*    */ 
/*    */   
/*    */   public Paint getFillPaint(Edge e) {
/* 28 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/RGEdgePaintFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */