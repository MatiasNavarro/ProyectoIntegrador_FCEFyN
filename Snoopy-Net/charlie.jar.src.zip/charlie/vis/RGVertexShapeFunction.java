/*    */ package charlie.vis;
/*    */ 
/*    */ import edu.uci.ics.jung.graph.Vertex;
/*    */ import edu.uci.ics.jung.graph.decorators.AbstractVertexShapeFunction;
/*    */ import edu.uci.ics.jung.graph.decorators.VertexAspectRatioFunction;
/*    */ import edu.uci.ics.jung.graph.decorators.VertexSizeFunction;
/*    */ import java.awt.Shape;
/*    */ import java.awt.geom.Ellipse2D;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ import java.awt.geom.RoundRectangle2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RGVertexShapeFunction
/*    */   extends AbstractVertexShapeFunction
/*    */ {
/*    */   ViewerInfo vi;
/*    */   
/*    */   public RGVertexShapeFunction(VertexSizeFunction vsf, VertexAspectRatioFunction varf, ViewerInfo vi) {
/* 23 */     super(vsf, varf);
/* 24 */     this.vi = vi;
/*    */   }
/*    */ 
/*    */   
/*    */   private Rectangle2D getRectangle(Vertex v) {
/* 29 */     float width = this.vsf.getSize(v);
/* 30 */     float height = width * this.varf.getAspectRatio(v);
/* 31 */     float h_offset = -(width / 2.0F);
/* 32 */     float v_offset = -(height / 2.0F);
/* 33 */     return new Rectangle2D.Float(h_offset, v_offset, width, height);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Shape getShape(Vertex v) {
/* 39 */     if (this.vi.getPath() != null && (this.vi.getPath().isFirstNode(((VisNode)v).getRGNode()) || this.vi.getPath().isLastNode(((VisNode)v).getRGNode()))) return this.factory.getEllipse(v); 
/* 40 */     if (this.vi.isMarked((VisNode)v) || (this.vi.getPath() != null && this.vi.getPath().pathContains(((VisNode)v).getRGNode()))) return this.factory.getRegularPolygon(v, 8); 
/* 41 */     if (v instanceof VisNode && ((VisNode)v).isLogic()) {
/* 42 */       Ellipse2D ellipse2D = this.factory.getEllipse(v);
/*    */ 
/*    */       
/* 45 */       return ellipse2D;
/*    */     } 
/* 47 */     Rectangle2D frame = getRectangle(v);
/* 48 */     float arc_size = (float)Math.min(frame.getHeight(), frame.getWidth()) / 2.0F;
/* 49 */     RoundRectangle2D r = new RoundRectangle2D.Float(0.0F, 0.0F, 0.0F, 0.0F, arc_size, arc_size);
/* 50 */     r.setFrame(frame);
/* 51 */     return r;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/RGVertexShapeFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */