/*    */ package charlie.vis;
/*    */ 
/*    */ import edu.uci.ics.jung.graph.ArchetypeVertex;
/*    */ import edu.uci.ics.jung.graph.decorators.VertexStringer;
/*    */ 
/*    */ public class SimpleVertexStringer
/*    */   implements VertexStringer {
/*    */   ViewerInfo vi;
/*    */   
/*    */   public SimpleVertexStringer(ViewerInfo vi) {
/* 11 */     this.vi = vi;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getLabel(ArchetypeVertex v) {
/* 18 */     if (this.vi.isMarked((VisNode)v) || this.vi.pathContains((VisNode)v) > 0) {
/*    */       
/* 20 */       if (((VisNode)v).getRGNode().getStateNumber() > 0) {
/* 21 */         return ((VisNode)v).getRGNode().getStateNumber() + ":" + this.vi.pn.toLabel(((VisNode)v).getRGNode().getMarking());
/*    */       }
/* 23 */       return this.vi.pn.toLabel(((VisNode)v).getRGNode().getMarking());
/*    */     } 
/*    */     
/* 26 */     if (!Options.vertexLabels) return ""; 
/* 27 */     if (((VisNode)v).getRGNode().getStateNumber() > 0) {
/* 28 */       return ((VisNode)v).getRGNode().getStateNumber() + ":" + this.vi.pn.toLabel(((VisNode)v).getRGNode().getMarking());
/*    */     }
/* 30 */     return this.vi.pn.toLabel(((VisNode)v).getRGNode().getMarking());
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/SimpleVertexStringer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */