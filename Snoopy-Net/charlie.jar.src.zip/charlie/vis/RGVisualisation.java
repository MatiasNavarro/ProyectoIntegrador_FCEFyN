/*     */ package charlie.vis;
/*     */ 
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.State;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGEdge;
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import charlie.rg.SCC;
/*     */ import edu.uci.ics.jung.graph.Edge;
/*     */ import edu.uci.ics.jung.graph.Graph;
/*     */ import edu.uci.ics.jung.graph.Vertex;
/*     */ import edu.uci.ics.jung.graph.decorators.StringLabeller;
/*     */ import edu.uci.ics.jung.utils.UserData;
/*     */ import edu.uci.ics.jung.visualization.AbstractLayout;
/*     */ import edu.uci.ics.jung.visualization.Coordinates;
/*     */ import edu.uci.ics.jung.visualization.FRLayout;
/*     */ import edu.uci.ics.jung.visualization.ISOMLayout;
/*     */ import edu.uci.ics.jung.visualization.Layout;
/*     */ import edu.uci.ics.jung.visualization.SpringLayout;
/*     */ import edu.uci.ics.jung.visualization.contrib.CircleLayout;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RGVisualisation
/*     */ {
/*  34 */   private static final Log LOG = LogFactory.getLog(RGVisualisation.class);
/*     */   
/*  36 */   public static Object VisColorKey = "color";
/*     */   public static boolean condensed = false;
/*  38 */   private static HashSet visited = new HashSet();
/*     */   
/*  40 */   static double x = Options.x;
/*  41 */   static double y = Options.y;
/*  42 */   static double curX = x;
/*  43 */   static double curY = y;
/*     */ 
/*     */   
/*     */   private static void reset() {
/*  47 */     x = Options.x;
/*  48 */     y = Options.y;
/*  49 */     curX = x;
/*  50 */     curY = y;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Layout visualizeEnviroment(ViewerInfo vi, boolean visSCCofRoot) {
/*  56 */     if (condensed) {
/*  57 */       visSCCofRoot = true;
/*     */     }
/*  59 */     condensed = false;
/*  60 */     Layout layout = vi.layout;
/*  61 */     Object RG_Key = ((AbstractLayout)layout).getBaseKey();
/*  62 */     visited.clear();
/*  63 */     reset();
/*  64 */     visualize(vi, visSCCofRoot, true, null);
/*  65 */     Coordinates coord = (Coordinates)((VisNode)vi.visNodes().get(vi.first)).getUserDatum(RG_Key);
/*  66 */     x = coord.getX();
/*  67 */     curX = x;
/*  68 */     y = coord.getY();
/*  69 */     curY = y;
/*     */     
/*  71 */     return visualize(vi, visSCCofRoot, false, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Layout visualizeRG(ViewerInfo vi, boolean visSCCofRoot, boolean forward) {
/*  76 */     if (condensed) {
/*  77 */       visSCCofRoot = true;
/*     */     }
/*  79 */     condensed = false;
/*  80 */     visited.clear();
/*  81 */     reset();
/*     */     
/*  83 */     return visualize(vi, visSCCofRoot, forward, null);
/*     */   }
/*     */   
/*     */   public static Layout visualizePath(ViewerInfo vi, boolean visSCCofRoot, boolean forward, Path p) {
/*  87 */     if (condensed) {
/*  88 */       visSCCofRoot = true;
/*     */     }
/*  90 */     condensed = false;
/*  91 */     visited.clear();
/*  92 */     reset();
/*     */     
/*  94 */     return visualize(vi, visSCCofRoot, forward, p);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Layout visualizeCondensedRG(ViewerInfo vi, boolean visSCCofRoot, boolean forward) {
/*     */     try {
/* 101 */       RGraph rg = vi.rg;
/*     */       
/* 103 */       RGNode first = vi.first;
/* 104 */       PlaceTransitionNet pn = vi.pn;
/* 105 */       HashSet<SCC> toSCC = new HashSet();
/*     */ 
/*     */       
/* 108 */       DiGraph diGraph = new DiGraph();
/*     */       
/* 110 */       visited.clear();
/* 111 */       reset();
/* 112 */       int maxEdges = rg.getScc().size() - 1;
/* 113 */       for (Iterator<SCC> iterator1 = rg.getScc().values().iterator(); iterator1.hasNext(); ) {
/* 114 */         RGNode n = ((SCC)iterator1.next()).getRoot();
/* 115 */         VisNode f = new VisNode(n, 0);
/*     */         
/* 117 */         f.addUserDatum(VisColorKey, Colors.getColor(n.sccNumber()), UserData.CLONE);
/* 118 */         diGraph.addVertex((Vertex)f);
/* 119 */         vi.visNodes().put(n, f);
/*     */       } 
/*     */       
/* 122 */       for (Iterator<SCC> it = rg.getScc().values().iterator(); it.hasNext(); ) {
/* 123 */         SCC cur = it.next();
/* 124 */         toSCC.clear();
/* 125 */         toSCC.add(cur);
/* 126 */         int curEdges = 0;
/* 127 */         RGNode n = cur.getRoot();
/* 128 */         for (Iterator itCur = cur.iterator(); itCur.hasNext(); ) {
/* 129 */           RGEdge out = ((RGNode)itCur.next()).out;
/* 130 */           while (out != null && curEdges < maxEdges) {
/* 131 */             SCC dest = (SCC)rg.getScc().get(new Integer(out.node(n).sccNumber()));
/* 132 */             if (!toSCC.contains(dest)) {
/*     */               try {
/* 134 */                 diGraph.addEdge((Edge)new VisEdge((Vertex)vi.visNodes().get(n), (Vertex)vi.visNodes().get(dest.getRoot()), ""));
/* 135 */                 toSCC.add(dest);
/* 136 */               } catch (Exception e) {
/* 137 */                 LOG.error(e.getMessage(), e);
/*     */               } 
/*     */             }
/* 140 */             out = out.next();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 146 */       condensed = true;
/* 147 */       vi.layout = (Layout)new ISOMLayout((Graph)diGraph);
/* 148 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 151 */     return vi.layout;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Layout visualize(ViewerInfo vi, boolean visSCCofRoot, boolean forward, Path p) {
/*     */     SpringLayout springLayout;
/* 157 */     int maxNodes = ((Integer)Options.maxNodesO.getValue()).intValue();
/* 158 */     int maxLayer = ((Integer)Options.maxLayerO.getValue()).intValue();
/*     */ 
/*     */     
/* 161 */     boolean maximumReached = false;
/* 162 */     RGraph rg = vi.rg;
/* 163 */     RGNode first = vi.first;
/* 164 */     PlaceTransitionNet pn = vi.pn;
/* 165 */     Layout layout = vi.layout;
/* 166 */     HashSet<RGNode> nextLayer = new HashSet();
/* 167 */     HashSet<RGNode> currentLayer = new HashSet();
/*     */     
/* 169 */     int sccNumber = 0;
/* 170 */     int nodes = 1;
/*     */     
/* 172 */     int reduce = 0;
/* 173 */     int entries = 0;
/* 174 */     long currentTime = System.currentTimeMillis();
/*     */     
/* 176 */     int layer = 0;
/* 177 */     int l = 0;
/*     */     
/* 179 */     if (Options.vertical) {
/* 180 */       Coordinates coord = new Coordinates(50.0D, 250.0D);
/*     */     } else {
/* 182 */       Coordinates coord = new Coordinates(250.0D, 50.0D);
/*     */     } 
/* 184 */     Graph g = layout.getGraph();
/* 185 */     Object RG_Key = ((AbstractLayout)layout).getBaseKey();
/* 186 */     StringLabeller sl = StringLabeller.getLabeller(g);
/* 187 */     Vector<QueueEntry> st = new Vector();
/* 188 */     int edges = 0;
/* 189 */     int h = 0;
/* 190 */     RGNode n = first;
/* 191 */     RGNode to = null;
/* 192 */     RGNode from = null;
/* 193 */     RGEdge e = null;
/* 194 */     sccNumber = n.sccNumber();
/*     */ 
/*     */ 
/*     */     
/* 198 */     RGEdge next = n.out();
/* 199 */     if (!forward) {
/* 200 */       next = n.in();
/*     */     }
/* 202 */     while (next != null) {
/* 203 */       if (!next.node(n).equals(n)) {
/* 204 */         nextLayer.add(next.node(n));
/*     */       }
/*     */       
/* 207 */       st.add(new QueueEntry(n, next.node(n), next));
/* 208 */       entries++;
/* 209 */       next = next.next();
/*     */     } 
/*     */     
/* 212 */     if (Options.wholeGraph || p == null || (p != null && p.pathContains(n))) {
/*     */       Coordinates coordinates;
/* 214 */       VisNode f = new VisNode(n, layer);
/* 215 */       if (!Options.vertical) {
/* 216 */         coordinates = new Coordinates(curY, curX);
/*     */       } else {
/* 218 */         coordinates = new Coordinates(curX, curY);
/*     */       } 
/* 220 */       f.addUserDatum(RG_Key, coordinates, UserData.CLONE);
/* 221 */       f.addUserDatum(VisColorKey, Colors.getColor(n.sccNumber()), UserData.CLONE);
/*     */       
/* 223 */       changeCoord(forward, 45.0D, ((Integer)Options.vdO.getValue()).intValue());
/* 224 */       curX = x;
/* 225 */       vi.visNodes().put(n, f);
/* 226 */       visited.add(n);
/* 227 */       g.addVertex((Vertex)f);
/*     */       try {
/* 229 */         sl.setLabel((Vertex)f, pn.toLabel((State)n.getLabel()));
/* 230 */       } catch (edu.uci.ics.jung.graph.decorators.StringLabeller.UniqueLabelException ex) {
/* 231 */         ex.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/* 235 */     while (!st.isEmpty()) {
/*     */       
/* 237 */       if (h == 0 && currentLayer.size() == 0) {
/* 238 */         if (p != null) {
/* 239 */           int[] indices = new int[entries];
/* 240 */           int j = 0;
/* 241 */           for (int k = 0; k < entries && k < st.size(); k++) {
/* 242 */             RGNode rgn = ((QueueEntry)st.get(k)).to;
/* 243 */             if (p.pathContains(rgn))
/*     */             {
/* 245 */               indices[j++] = k + 1;
/*     */             }
/*     */           } 
/*     */           
/* 249 */           if (j > 0) {
/* 250 */             setToMid(st, indices, entries, nextLayer);
/*     */           }
/*     */         } 
/*     */         
/* 254 */         if (maxLayer > 0 && layer == maxLayer - 1) {
/* 255 */           return layout;
/*     */         }
/* 257 */         layer++;
/*     */         
/* 259 */         curX = x - (nextLayer.size() / 2 * ((Integer)Options.hdO.getValue()).intValue());
/* 260 */         if (forward) {
/*     */           
/* 262 */           curY += ((Integer)Options.vdO.getValue()).intValue();
/*     */         } else {
/* 264 */           curY -= ((Integer)Options.vdO.getValue()).intValue();
/*     */         } 
/*     */         
/* 267 */         h = nextLayer.size();
/* 268 */         currentLayer.clear();
/* 269 */         HashSet<RGNode> nextLayer2 = new HashSet();
/* 270 */         nextLayer2.addAll(nextLayer);
/* 271 */         currentLayer.addAll(nextLayer);
/* 272 */         nextLayer.clear();
/*     */         
/* 274 */         int i = 0;
/* 275 */         entries = 0;
/* 276 */         while (!nextLayer2.isEmpty()) {
/*     */           
/* 278 */           RGNode current = ((QueueEntry)st.get(i)).to;
/* 279 */           i++;
/* 280 */           nextLayer2.remove(current);
/* 281 */           if (!Options.wholeGraph && p != null && !p.pathContains(current)) {
/*     */             continue;
/*     */           }
/* 284 */           next = current.out();
/* 285 */           if (!forward) {
/* 286 */             next = current.in();
/*     */           }
/* 288 */           while (next != null) {
/* 289 */             if (!visited.contains(next.node(current)) && !currentLayer.contains(next.node(current)))
/*     */             {
/* 291 */               if (Options.wholeGraph || p == null || (p != null && p.pathContains(current))) {
/* 292 */                 nextLayer.add(next.node(current));
/*     */               }
/*     */             }
/*     */ 
/*     */             
/* 297 */             entries++;
/* 298 */             next = next.next();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 309 */       from = ((QueueEntry)st.get(0)).from;
/* 310 */       to = ((QueueEntry)st.get(0)).to;
/* 311 */       e = ((QueueEntry)st.get(0)).e;
/*     */       
/* 313 */       currentLayer.remove(to);
/*     */       
/* 315 */       st.remove(0);
/*     */       
/* 317 */       if ((!visSCCofRoot || (visSCCofRoot && n.sccNumber() == sccNumber)) && (maxNodes < 1 || (maxNodes >= 1 && maxNodes > nodes))) {
/* 318 */         VisNode vn2, vn = vi.visNodes().get(from);
/*     */         
/* 320 */         RGNode help = to;
/*     */         
/* 322 */         if (!visited.contains(help)) {
/* 323 */           RGEdge cur; h--;
/* 324 */           vn2 = new VisNode(help, layer);
/* 325 */           Coordinates coordinates = (Coordinates)vn.getUserDatum(RG_Key);
/* 326 */           if (!Options.vertical) {
/* 327 */             coordinates = new Coordinates(curY, curX);
/*     */           } else {
/* 329 */             coordinates = new Coordinates(curX, curY);
/*     */           } 
/* 331 */           vn2.addUserDatum(RG_Key, coordinates, UserData.CLONE);
/*     */           
/* 333 */           vn2.addUserDatum(VisColorKey, Colors.getColor(help.sccNumber()), UserData.CLONE);
/*     */ 
/*     */ 
/*     */           
/* 337 */           curX += ((Integer)Options.hdO.getValue()).intValue();
/*     */           
/* 339 */           if (maxNodes >= 1 && maxNodes > nodes) {
/* 340 */             vi.visNodes().put(help, vn2);
/* 341 */             g.addVertex((Vertex)vn2);
/* 342 */             nodes++;
/*     */             try {
/* 344 */               if (LOG.isDebugEnabled()) {
/* 345 */                 LOG.debug(String.format("help.getLabel() : %s\n", new Object[] { help.getLabel().toString() }));
/*     */               }
/* 347 */               sl.setLabel((Vertex)vn2, pn.toLabel((State)help.getLabel()));
/* 348 */             } catch (edu.uci.ics.jung.graph.decorators.StringLabeller.UniqueLabelException ex) {
/* 349 */               LOG.error(ex.getMessage(), (Throwable)ex);
/*     */             } 
/* 351 */             visited.add(help);
/*     */           } 
/*     */           
/* 354 */           if (forward) {
/* 355 */             cur = to.out();
/*     */           } else {
/* 357 */             cur = to.in();
/*     */           } 
/* 359 */           if (Options.wholeGraph || p == null || (p != null && p.pathContains(to))) {
/* 360 */             while (cur != null) {
/* 361 */               edges++;
/* 362 */               st.add(new QueueEntry(to, cur.node(to), cur));
/* 363 */               cur = cur.next();
/*     */             } 
/*     */           }
/*     */         } else {
/*     */           
/* 368 */           visited.add(help);
/* 369 */           int logicals = 0;
/* 370 */           vn2 = vi.visNodes().get(help);
/* 371 */           Coordinates coordinates1 = (Coordinates)vn.getUserDatum(RG_Key);
/* 372 */           Coordinates coord2 = (Coordinates)vn2.getUserDatum(RG_Key);
/* 373 */           if (Options.logicNodes && ((
/* 374 */             Math.abs(vn2.layer() - vn.layer()) != 1 && vn2.layer() - vn.layer() != 0) || coordinates1.getX() - coord2.getX() > (Options.hd * 2))) {
/* 375 */             vn2 = vn2.copy();
/* 376 */             coordinates1 = new Coordinates(coordinates1.getX() - 75.0D, coordinates1.getY() + 40.0D * ++logicals);
/* 377 */             vn2.addUserDatum(RG_Key, new Coordinates(coordinates1), UserData.CLONE);
/* 378 */             vn2.addUserDatum(VisColorKey, Colors.getColor(help.sccNumber()), UserData.CLONE);
/* 379 */             g.addVertex((Vertex)vn2);
/*     */           } 
/*     */         } 
/*     */         try {
/* 383 */           if (forward) {
/* 384 */             VisEdge toAdd = new VisEdge((Vertex)vn, (Vertex)vn2, e.getLabel(pn));
/* 385 */             g.addEdge((Edge)toAdd);
/*     */           } else {
/* 387 */             g.addEdge((Edge)new VisEdge((Vertex)vn2, (Vertex)vn, e.getLabel(pn)));
/*     */           } 
/* 389 */         } catch (Exception ex) {
/* 390 */           LOG.error(ex.getMessage(), ex);
/*     */         } 
/*     */       } 
/*     */       
/* 394 */       if (maxNodes >= 1 && maxNodes == nodes) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 400 */     switch (((Integer)Options.layoutO.getValue()).intValue()) {
/*     */ 
/*     */       
/*     */       case 1:
/* 404 */         vi.layout = (Layout)new ISOMLayout(g);
/*     */         break;
/*     */       case 2:
/* 407 */         vi.layout = (Layout)new FRLayout(g);
/*     */         break;
/*     */       case 3:
/* 410 */         springLayout = new SpringLayout(g);
/* 411 */         springLayout.setStretch(0.2D);
/* 412 */         springLayout.setRepulsionRange(200);
/* 413 */         springLayout.setForceMultiplier(0.2D);
/* 414 */         vi.layout = (Layout)springLayout;
/*     */         break;
/*     */       case 4:
/* 417 */         vi.layout = (Layout)new CircleLayout(g);
/*     */         break;
/*     */     } 
/* 420 */     return vi.layout;
/*     */   }
/*     */   
/*     */   private class StackEntry {
/*     */     RGNode n;
/*     */     Edge e;
/*     */     int l;
/*     */     
/*     */     StackEntry(RGNode v, Edge e1, int layer) {
/* 429 */       this.n = v;
/* 430 */       this.e = e1;
/* 431 */       this.l = layer;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setToMid(Vector<Object> v, int[] indices, int size, Set nextLayer) {
/* 439 */     HashSet<Object> otherNodes = new HashSet();
/* 440 */     int j = 0;
/*     */     
/* 442 */     while (otherNodes.size() < nextLayer.size() / 2) {
/* 443 */       Object o = ((QueueEntry)v.get(j)).to;
/* 444 */       j++;
/* 445 */       if (nextLayer.contains(o)) {
/* 446 */         otherNodes.add(o);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 451 */     for (int i = 0; i < size; i++) {
/* 452 */       if (indices[i] == 0 || indices[i] > j) {
/*     */         return;
/*     */       }
/*     */       
/* 456 */       Object o = v.get(indices[i] - 1);
/* 457 */       v.remove(indices[i] - 1);
/*     */       
/* 459 */       v.insertElementAt(o, j);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void changeCoord(boolean forward, double h, double v) {
/* 465 */     if (forward) {
/* 466 */       curY += v;
/* 467 */       x -= h;
/*     */     } else {
/* 469 */       curY -= v;
/* 470 */       x -= h;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/RGVisualisation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */