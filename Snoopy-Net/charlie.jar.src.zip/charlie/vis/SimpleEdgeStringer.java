/*    */ package charlie.vis;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import edu.uci.ics.jung.graph.ArchetypeEdge;
/*    */ import edu.uci.ics.jung.graph.decorators.EdgeStringer;
/*    */ 
/*    */ public class SimpleEdgeStringer
/*    */   implements EdgeStringer
/*    */ {
/*    */   PlaceTransitionNet pn;
/*    */   
/*    */   public SimpleEdgeStringer(PlaceTransitionNet pn) {
/* 13 */     this.pn = pn;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getLabel(ArchetypeEdge e) {
/* 21 */     if (!Options.edgeLabels) return ""; 
/* 22 */     return ((VisEdge)e).getLabel();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/SimpleEdgeStringer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */