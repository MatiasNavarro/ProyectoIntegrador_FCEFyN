/*    */ package charlie.vis;
/*    */ 
/*    */ import edu.uci.ics.jung.graph.Vertex;
/*    */ import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;
/*    */ import edu.uci.ics.jung.utils.UserData;
/*    */ 
/*    */ public class VisEdge
/*    */   extends DirectedSparseEdge
/*    */ {
/*    */   public static final String LABEL_KEY = "label";
/*    */   
/*    */   public VisEdge(Vertex from, Vertex to, String label) {
/* 13 */     super(from, to);
/*    */     
/* 15 */     setUserDatum("label", label, UserData.CLONE);
/*    */   }
/*    */   
/*    */   public String getLabel() {
/* 19 */     return (String)getUserDatum("label");
/*    */   }
/*    */   
/*    */   public short getId() {
/* 23 */     return 1;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/VisEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */