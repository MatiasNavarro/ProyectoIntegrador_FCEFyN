/*     */ package charlie.vis;
/*     */ 
/*     */ import charlie.rg.RGraph;
/*     */ import edu.uci.ics.jung.graph.Graph;
/*     */ import edu.uci.ics.jung.visualization.AbstractLayout;
/*     */ import edu.uci.ics.jung.visualization.Coordinates;
/*     */ import edu.uci.ics.jung.visualization.Layout;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GraphWriter
/*     */ {
/*  22 */   private static final Log LOG = LogFactory.getLog(GraphWriter.class);
/*     */   
/*     */   private Object key;
/*     */   private int nodes;
/*     */   private BufferedWriter out;
/*  27 */   private final Map<VisNode, Integer> visnodes = new HashMap<>();
/*     */   
/*     */   private final String netInfo;
/*     */ 
/*     */   
/*     */   public GraphWriter(File file, String netInfo) {
/*  33 */     this.nodes = 0;
/*  34 */     this.netInfo = removeWhiteSpace(netInfo);
/*     */     
/*     */     try {
/*  37 */       this.out = new BufferedWriter(new FileWriter(file));
/*  38 */     } catch (Exception e) {
/*  39 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public GraphWriter(String filename, String netInfo) {
/*  44 */     this.nodes = 0;
/*  45 */     this.netInfo = removeWhiteSpace(netInfo);
/*     */     
/*     */     try {
/*  48 */       this.out = new BufferedWriter(new FileWriter(filename));
/*  49 */     } catch (Exception e) {
/*  50 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void writeGraph(Layout l) {
/*  55 */     Graph g = l.getGraph();
/*  56 */     this.key = ((AbstractLayout)l).getBaseKey();
/*  57 */     VisNode cur = null;
/*     */     try {
/*  59 */       this.out.write("charlie-graph-v2.0", 0, 18);
/*  60 */       this.out.newLine();
/*  61 */       this.out.write(this.netInfo, 0, this.netInfo.length());
/*  62 */       this.out.newLine();
/*  63 */       this.out.write("nodes", 0, 5);
/*  64 */       this.out.newLine();
/*  65 */       for (Iterator<VisNode> iterator = g.getVertices().iterator(); iterator.hasNext(); ) {
/*  66 */         cur = iterator.next();
/*  67 */         this.visnodes.put(cur, new Integer(this.nodes));
/*  68 */         writeVisNode(this.nodes, cur);
/*  69 */         this.nodes++;
/*     */       } 
/*  71 */       this.out.write("edges", 0, 5);
/*  72 */       this.out.newLine();
/*  73 */       for (Iterator<VisEdge> it = g.getEdges().iterator(); it.hasNext();) {
/*  74 */         writeEdge(it.next());
/*     */       }
/*  76 */       this.out.write("end", 0, 3);
/*  77 */       this.out.close();
/*  78 */     } catch (Exception e) {
/*  79 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void writeNodes(RGraph rg) {
/*     */     try {
/*  85 */       this.out.write(rg.getNodesString());
/*  86 */       this.out.close();
/*  87 */     } catch (Exception e) {
/*  88 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeVisNode(int i, VisNode vn) {
/*     */     try {
/*  95 */       String value = "" + i;
/*  96 */       this.out.write(value, 0, value.length());
/*  97 */       this.out.newLine();
/*  98 */       Coordinates coord = (Coordinates)vn.getUserDatum(this.key);
/*     */       
/* 100 */       value = "" + coord.getX();
/* 101 */       this.out.write(value, 0, value.length());
/* 102 */       this.out.newLine();
/*     */       
/* 104 */       value = "" + coord.getY();
/* 105 */       this.out.write(value, 0, value.length());
/* 106 */       this.out.newLine();
/*     */       
/* 108 */       String label = vn.getRGNode().toString();
/* 109 */       this.out.write(label, 0, label.length());
/* 110 */       this.out.newLine();
/*     */       
/* 112 */       value = "" + vn.getColor();
/* 113 */       this.out.write(value, 0, value.length());
/* 114 */       this.out.newLine();
/*     */       
/* 116 */       value = "" + vn.layer;
/* 117 */       this.out.write(value, 0, value.length());
/* 118 */       this.out.newLine();
/* 119 */       value = "" + vn.cp;
/* 120 */       this.out.write(value, 0, value.length());
/* 121 */       this.out.newLine();
/*     */     }
/* 123 */     catch (Exception e) {
/* 124 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeEdge(VisEdge e) {
/*     */     try {
/* 131 */       this.out.write(e.getLabel(), 0, e.getLabel().length());
/* 132 */       this.out.newLine();
/* 133 */       String id = "" + e.getId();
/* 134 */       this.out.write(id, 0, id.length());
/* 135 */       this.out.newLine();
/* 136 */       String fromto = "" + this.visnodes.get(e.getSource()) + " " + this.visnodes.get(e.getDest());
/* 137 */       this.out.write(fromto, 0, fromto.length());
/* 138 */       this.out.newLine();
/* 139 */     } catch (Exception ex) {
/* 140 */       LOG.error(ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String removeWhiteSpace(String str) {
/* 145 */     StringTokenizer st = new StringTokenizer(str, " \n\t");
/* 146 */     StringBuffer sb = new StringBuffer();
/*     */     
/* 148 */     while (st.hasMoreTokens()) {
/* 149 */       sb.append(st.nextToken());
/*     */     }
/*     */     
/* 152 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/GraphWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */