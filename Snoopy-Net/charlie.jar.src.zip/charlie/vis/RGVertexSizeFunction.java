/*    */ package charlie.vis;
/*    */ 
/*    */ import edu.uci.ics.jung.graph.Vertex;
/*    */ import edu.uci.ics.jung.graph.decorators.VertexSizeFunction;
/*    */ 
/*    */ public class RGVertexSizeFunction
/*    */   implements VertexSizeFunction {
/*    */   ViewerInfo vi;
/*    */   
/*    */   public RGVertexSizeFunction(ViewerInfo vi) {
/* 11 */     this.vi = vi;
/*    */   }
/*    */   
/*    */   public int getSize(Vertex v) {
/* 15 */     if (this.vi.getPath() != null && this.vi.getPath().pathContains(((VisNode)v).getRGNode())) return 70; 
/* 16 */     return 50;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/RGVertexSizeFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */