/*     */ package charlie.vis;
/*     */ 
/*     */ import edu.uci.ics.jung.graph.Graph;
/*     */ import edu.uci.ics.jung.graph.Vertex;
/*     */ import edu.uci.ics.jung.utils.UserData;
/*     */ import edu.uci.ics.jung.visualization.AbstractLayout;
/*     */ import edu.uci.ics.jung.visualization.Coordinates;
/*     */ import java.awt.Dimension;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MyLayout
/*     */   extends AbstractLayout
/*     */ {
/*     */   public MyLayout(Graph g) {
/*  42 */     super(g);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStatus() {
/*  47 */     return "MyLayout";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIncremental() {
/*  54 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean incrementsAreDone() {
/*  61 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void orderVertices(Vertex[] vertices) {
/*  81 */     List<Vertex> list = Arrays.asList(vertices);
/*  82 */     Collections.shuffle(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize_local_vertex(Vertex v) {
/*  97 */     System.out.println("initloacal " + v + " " + getBaseKey());
/*  98 */     if (v.getUserDatum(getBaseKey()) == null) {
/*  99 */       v.addUserDatum(getBaseKey(), new Coordinates(0.0D, 0.0D), UserData.CLONE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize_local() {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initializeLocations() {
/* 110 */     Vertex[] vertices = (Vertex[])getVisibleVertices().toArray((Object[])new Vertex[0]);
/* 111 */     orderVertices(vertices);
/*     */     
/* 113 */     Dimension d = getCurrentSize();
/* 114 */     double height = d.getHeight();
/* 115 */     double width = d.getWidth();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     for (int i = 0; i < vertices.length; i++) {
/*     */       
/* 123 */       Coordinates coord = (Coordinates)vertices[i].getUserDatum(getBaseKey());
/*     */       
/* 125 */       if (coord == null) System.out.println("keine Coordinaten");
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Coordinates getMyData(Vertex v) {
/* 136 */     return (Coordinates)v.getUserDatum(getBaseKey());
/*     */   }
/*     */   
/*     */   public void advancePositions() {}
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/MyLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */