/*     */ package charlie.vis;
/*     */ 
/*     */ import GUI.rggui.RGListModel;
/*     */ import GUI.rggui.Viewer;
/*     */ import charlie.filter.Filter;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import edu.uci.ics.jung.graph.Edge;
/*     */ import edu.uci.ics.jung.graph.Graph;
/*     */ import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;
/*     */ import edu.uci.ics.jung.visualization.Layout;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewerInfo
/*     */ {
/*  30 */   private Viewer viewer = null;
/*     */   
/*  32 */   private RGListModel pathsModel = null;
/*  33 */   private RGListModel filterModel = null;
/*     */   
/*     */   private int currentPath;
/*     */   
/*     */   private String netInfo;
/*     */   public Layout layout;
/*  39 */   private final HashMap<RGNode, VisNode> visNodes = new HashMap<>();
/*  40 */   public final HashSet<Edge> markedEdges = new HashSet<>();
/*  41 */   public final HashSet<Edge> pathEdges = new HashSet<>();
/*     */   
/*  43 */   public final HashSet<VisNode> filteredNodes = new HashSet<>();
/*     */   
/*     */   public Filter currentFilter;
/*     */   
/*     */   private Path path;
/*     */   
/*     */   public RGNode current;
/*     */   
/*     */   public RGNode first;
/*     */   public RGraph rg;
/*     */   public PlaceTransitionNet pn;
/*  54 */   double scaleX = 0.0D;
/*  55 */   double scaleY = 0.0D;
/*     */   
/*     */   public ViewerInfo(RGraph rg) {
/*  58 */     this(rg, rg.first, rg.getNet());
/*     */   }
/*     */   
/*     */   public ViewerInfo(RGraph rg, RGNode first, PlaceTransitionNet pn) {
/*  62 */     this.netInfo = pn.getName() + " places (" + pn.places() + ") trans (" + pn.transitions() + ") rg (" + rg.size() + ")";
/*  63 */     if (rg.reducedSequences) {
/*  64 */       this.netInfo += "reduced_sequences";
/*     */     }
/*  66 */     this.path = null;
/*  67 */     this.layout = (Layout)new MyLayout((Graph)new DiGraph());
/*     */     
/*  69 */     this.rg = rg;
/*  70 */     this.pn = pn;
/*  71 */     this.first = first;
/*  72 */     this.current = null;
/*  73 */     this.currentPath = -1;
/*  74 */     this.currentFilter = null;
/*     */   }
/*     */   
/*     */   public void setViewer(Viewer v) {
/*  78 */     this.viewer = v;
/*  79 */     this.pathsModel = new RGListModel(v);
/*  80 */     this.filterModel = new RGListModel(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyFilter() {
/*  89 */     if (this.currentFilter == null)
/*     */       return; 
/*  91 */     this.filteredNodes.clear();
/*  92 */     for (Iterator<VisNode> it = this.visNodes.values().iterator(); it.hasNext(); ) {
/*  93 */       VisNode vn = it.next();
/*  94 */       if (this.currentFilter.filter(vn.getRGNode().getLabel())) {
/*  95 */         this.filteredNodes.add(vn);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public DefaultListModel getFilter() {
/* 101 */     return (DefaultListModel)this.filterModel;
/*     */   }
/*     */   
/*     */   public void setFilter(int i) {
/* 105 */     if (i < 0 || i > this.filterModel.size())
/*     */       return; 
/* 107 */     setFilter((Filter)this.filterModel.get(i));
/*     */   }
/*     */   
/*     */   public void setLayout(Layout l) {
/* 111 */     this.layout = l;
/* 112 */     applyFilter();
/*     */   }
/*     */   
/*     */   public void setFilter(Filter filter) {
/* 116 */     this.currentFilter = filter;
/* 117 */     applyFilter();
/*     */   }
/*     */   
/*     */   public void addFilter(Filter f) {
/* 121 */     if (this.filterModel == null) {
/* 122 */       if (this.viewer == null) {
/* 123 */         JOptionPane.showMessageDialog(null, "ViewerInfo.addFilter(Filter) \n could not apply filter, no viewer defined in viewerinfo");
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 128 */       this.filterModel = new RGListModel(this.viewer);
/*     */     } 
/* 130 */     this.currentFilter = f;
/* 131 */     this.filterModel.addElement(f);
/* 132 */     applyFilter();
/*     */   }
/*     */   
/*     */   public void removeFilter(int index) {
/* 136 */     if (index != -1) {
/* 137 */       this.currentFilter = null;
/* 138 */       this.filterModel.remove(index);
/* 139 */       this.filteredNodes.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isFiltered(VisNode v) {
/* 144 */     return this.filteredNodes.contains(v);
/*     */   }
/*     */   
/*     */   public HashMap<RGNode, VisNode> visNodes() {
/* 148 */     return this.visNodes;
/*     */   }
/*     */   
/*     */   public String netInfo() {
/* 152 */     return this.netInfo;
/*     */   }
/*     */   
/*     */   public boolean containsPathEdges(Edge e) {
/* 156 */     return this.pathEdges.contains(e);
/*     */   }
/*     */   
/*     */   public void addPathEdge(Edge e) {
/* 160 */     this.pathEdges.add(e);
/*     */   }
/*     */   
/*     */   public VisEdge getVisEdge(short id, RGNode dest) {
/* 164 */     return getVisEdge(id, this.visNodes.get(dest));
/*     */   }
/*     */   
/*     */   public VisEdge getVisEdge(short id, VisNode dest) {
/* 168 */     for (Iterator<VisEdge> it = dest.getOutEdges().iterator(); it.hasNext(); ) {
/* 169 */       VisEdge edge = it.next();
/* 170 */       if (id == edge.getId())
/* 171 */         return edge; 
/*     */     } 
/* 173 */     return null;
/*     */   }
/*     */   
/*     */   private void setPath(Path p) {
/* 177 */     this.path = p;
/* 178 */     this.pathEdges.clear();
/*     */     
/* 180 */     VisNode src = null;
/* 181 */     VisNode dest = null;
/* 182 */     Iterator<Object> it = this.path.iterator();
/* 183 */     if (it.hasNext())
/* 184 */       dest = this.visNodes.get(it.next()); 
/* 185 */     while (it.hasNext()) {
/* 186 */       src = this.visNodes.get(it.next());
/* 187 */       if (src == null)
/*     */         break; 
/* 189 */       Set<DirectedSparseEdge> currentEdges = src.getOutEdges();
/* 190 */       for (Iterator<DirectedSparseEdge> it2 = currentEdges.iterator(); it2.hasNext(); ) {
/* 191 */         DirectedSparseEdge e = it2.next();
/* 192 */         if (((VisNode)e.getDest()).equals(dest)) {
/* 193 */           this.pathEdges.add(e);
/*     */           break;
/*     */         } 
/*     */       } 
/* 197 */       dest = src;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addPath(Path p) {
/* 202 */     this.pathEdges.clear();
/* 203 */     this.path = p;
/* 204 */     this.pathsModel.addElement(p);
/* 205 */     this.currentPath = this.pathsModel.size() - 1;
/* 206 */     setPath(this.currentPath);
/*     */   }
/*     */   
/*     */   public DefaultListModel getPaths() {
/* 210 */     return (DefaultListModel)this.pathsModel;
/*     */   }
/*     */   
/*     */   public void setPath(int currentPath) {
/* 214 */     if (currentPath < 0 || currentPath >= this.pathsModel.size()) {
/*     */       return;
/*     */     }
/* 217 */     if (this.currentPath != currentPath || currentPath == 0) {
/*     */       
/* 219 */       this.currentPath = currentPath;
/* 220 */       setPath((Path)this.pathsModel.get(currentPath));
/*     */     } 
/*     */   }
/*     */   
/*     */   public Path getPath() {
/* 225 */     if (this.currentPath < 0)
/* 226 */       return null; 
/* 227 */     return (Path)this.pathsModel.get(this.currentPath);
/*     */   }
/*     */   
/*     */   public void clearEdges() {
/* 231 */     this.markedEdges.clear();
/*     */   }
/*     */   
/*     */   public int pathContains(VisNode v) {
/* 235 */     if (this.path == null)
/* 236 */       return 0; 
/* 237 */     return this.path.pathNodes.commoness(v.getRGNode());
/*     */   }
/*     */   
/*     */   public boolean isMarked(VisNode node) {
/* 241 */     if (this.current != null && this.current.equals(node.getRGNode()))
/* 242 */       return true; 
/* 243 */     return false;
/*     */   }
/*     */   
/*     */   public void mark(VisNode v) {
/* 247 */     clearEdges();
/* 248 */     if (v != null) {
/*     */       
/* 250 */       this.current = v.getRGNode();
/* 251 */       for (Iterator<VisEdge> it = v.getOutEdges().iterator(); it.hasNext(); ) {
/* 252 */         VisEdge ve = it.next();
/* 253 */         markEdge(ve);
/*     */       } 
/*     */       return;
/*     */     } 
/* 257 */     this.current = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void markEdge(VisEdge e) {
/* 262 */     this.markedEdges.add(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short extendsPath(VisNode node) {
/* 269 */     if (this.path == null)
/* 270 */       return -1; 
/* 271 */     return this.path.extendsPath(node.getRGNode());
/*     */   }
/*     */   
/*     */   public int deleteLast() {
/* 275 */     if (this.path == null)
/* 276 */       return -1; 
/* 277 */     VisNode dest = this.visNodes.get(this.path.last());
/* 278 */     int commoness = pathContains(dest);
/* 279 */     int ret = this.path.deleteLast();
/* 280 */     if (ret > 0) {
/* 281 */       VisNode src = this.visNodes.get(this.path.last());
/* 282 */       if (commoness == 1) {
/* 283 */         Set<DirectedSparseEdge> edges = src.getOutEdges();
/* 284 */         for (Iterator<DirectedSparseEdge> it = edges.iterator(); it.hasNext(); ) {
/* 285 */           DirectedSparseEdge e = it.next();
/* 286 */           if (((VisNode)e.getDest()).equals(dest)) {
/* 287 */             this.pathEdges.remove(e);
/* 288 */             return ret;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 293 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean checkAndAddNode(RGNode node) {
/* 297 */     VisNode vn = this.visNodes.get(node);
/* 298 */     if (vn != null)
/* 299 */       return checkAndAddNode(vn); 
/* 300 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkAndAddNode(VisNode node) {
/* 305 */     if (this.path != null) {
/* 306 */       RGNode last = this.path.last();
/* 307 */       boolean ret = this.path.checkAndAddNode(node.getRGNode());
/* 308 */       if (ret) {
/* 309 */         VisNode v = this.visNodes.get(last);
/* 310 */         Set<DirectedSparseEdge> edges = v.getOutEdges();
/* 311 */         for (Iterator<DirectedSparseEdge> it = edges.iterator(); it.hasNext(); ) {
/* 312 */           DirectedSparseEdge e = it.next();
/* 313 */           if (((VisNode)e.getDest()).equals(node)) {
/* 314 */             this.pathEdges.add(e);
/* 315 */             return true;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 319 */         return ret;
/*     */       } 
/*     */     } 
/* 322 */     return false;
/*     */   }
/*     */   
/*     */   public int getSelectedPathNumber() {
/* 326 */     return this.currentPath;
/*     */   }
/*     */   
/*     */   public void clearPath() {
/* 330 */     this.pathEdges.clear();
/* 331 */     if (this.currentPath < 0)
/*     */       return; 
/* 333 */     this.pathsModel.remove(this.currentPath);
/* 334 */     this.currentPath = -1;
/* 335 */     this.path = null;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/ViewerInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */