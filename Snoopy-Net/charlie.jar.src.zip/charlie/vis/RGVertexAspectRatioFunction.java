/*   */ package charlie.vis;
/*   */ 
/*   */ import edu.uci.ics.jung.graph.Vertex;
/*   */ import edu.uci.ics.jung.graph.decorators.VertexAspectRatioFunction;
/*   */ 
/*   */ public class RGVertexAspectRatioFunction implements VertexAspectRatioFunction {
/*   */   public float getAspectRatio(Vertex v) {
/* 8 */     return 0.3F;
/*   */   }
/*   */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/RGVertexAspectRatioFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */