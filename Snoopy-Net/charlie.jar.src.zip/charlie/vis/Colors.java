/*    */ package charlie.vis;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ class Colors
/*    */ {
/* 11 */   private static Random random = new Random();
/* 12 */   private static Map<Integer, Color> colorMap = new HashMap<>();
/* 13 */   private static final Color[] colors = new Color[] { Color.WHITE, Color.RED, Color.GREEN, Color.YELLOW, Color.LIGHT_GRAY, Color.GRAY, Color.PINK, Color.MAGENTA, Color.CYAN };
/* 14 */   private static int cur = 0;
/*    */   
/*    */   public static Color getColor() {
/* 17 */     if (cur < colors.length) {
/* 18 */       return colors[cur++];
/*    */     }
/* 20 */     return new Color(random.nextInt());
/*    */   }
/*    */   
/*    */   public static Color getColor(int i) {
/* 24 */     if (i == -1) {
/* 25 */       return Color.BLACK;
/*    */     }
/* 27 */     if (i >= colors.length) {
/* 28 */       Integer l_int = new Integer(i);
/* 29 */       Color col = colorMap.get(l_int);
/* 30 */       if (col == null) {
/* 31 */         col = new Color(random.nextInt());
/* 32 */         colorMap.put(l_int, col);
/*    */       } 
/* 34 */       return col;
/*    */     } 
/*    */     
/* 37 */     return colors[i];
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/Colors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */