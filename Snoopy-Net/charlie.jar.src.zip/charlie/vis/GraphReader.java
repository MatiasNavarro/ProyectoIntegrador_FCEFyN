/*     */ package charlie.vis;
/*     */ 
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import edu.uci.ics.jung.graph.Edge;
/*     */ import edu.uci.ics.jung.graph.Graph;
/*     */ import edu.uci.ics.jung.graph.Vertex;
/*     */ import edu.uci.ics.jung.utils.UserData;
/*     */ import edu.uci.ics.jung.visualization.Coordinates;
/*     */ import edu.uci.ics.jung.visualization.Layout;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class GraphReader
/*     */ {
/*     */   Object key;
/*     */   int nodes;
/*     */   BufferedReader in;
/*     */   RGraph rg;
/*     */   Vector visNodes;
/*     */   String netInfo;
/*     */   
/*     */   public GraphReader(File filename, RGraph rg, String netInfo) {
/*  28 */     this.nodes = 0;
/*  29 */     this.rg = rg;
/*  30 */     this.visNodes = new Vector();
/*  31 */     this.netInfo = removeWhiteSpace(netInfo);
/*     */     try {
/*  33 */       this.in = new BufferedReader(new FileReader(filename));
/*     */ 
/*     */     
/*     */     }
/*  37 */     catch (Exception e) {
/*  38 */       System.out.println(e);
/*  39 */       e.getLocalizedMessage();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GraphReader(String filename, RGraph rg, String netInfo) {
/*  46 */     this.nodes = 0;
/*  47 */     this.rg = rg;
/*  48 */     this.visNodes = new Vector();
/*  49 */     this.netInfo = removeWhiteSpace(netInfo);
/*     */     try {
/*  51 */       this.in = new BufferedReader(new FileReader(filename));
/*     */ 
/*     */     
/*     */     }
/*  55 */     catch (Exception e) {
/*  56 */       System.out.println(e);
/*  57 */       e.getLocalizedMessage();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Layout readGraph(Map<RGNode, VisNode> vis) {
/*  63 */     DiGraph diGraph = new DiGraph();
/*  64 */     MyLayout myLayout = new MyLayout((Graph)diGraph);
/*  65 */     this.key = myLayout.getBaseKey();
/*  66 */     VisNode cur = null;
/*     */     try {
/*  68 */       String line = this.in.readLine();
/*  69 */       if (!line.equals("charlie-graph-v2.0")) {
/*  70 */         System.out.println("no graph-file");
/*  71 */         return null;
/*     */       } 
/*  73 */       line = this.in.readLine();
/*  74 */       if (this.netInfo == null) {
/*  75 */         this.netInfo = removeWhiteSpace(line);
/*  76 */       } else if (!line.equals(this.netInfo)) {
/*  77 */         System.out.println("wrong netFile:");
/*  78 */         System.out.println("found net: " + line);
/*  79 */         System.out.println("expected net: " + this.netInfo);
/*  80 */         return null;
/*     */       } 
/*  82 */       while (!line.equals("nodes")) {
/*  83 */         line = this.in.readLine();
/*     */       }
/*  85 */       line = this.in.readLine();
/*  86 */       while (!line.equals("edges")) {
/*  87 */         VisNode vn = readVisNode(line);
/*  88 */         if (!vn.isLogic()) {
/*  89 */           vis.put(vn.getRGNode(), vn);
/*     */         }
/*  91 */         this.visNodes.add(vn);
/*  92 */         diGraph.addVertex((Vertex)vn);
/*  93 */         line = this.in.readLine();
/*     */       } 
/*  95 */       line = this.in.readLine();
/*  96 */       while (!line.equals("end")) {
/*  97 */         VisEdge ve = readVisEdge(line);
/*  98 */         diGraph.addEdge((Edge)ve);
/*  99 */         line = this.in.readLine();
/*     */       } 
/*     */ 
/*     */       
/* 103 */       this.in.close();
/* 104 */     } catch (Exception e) {
/* 105 */       System.out.println(e);
/* 106 */       e.getLocalizedMessage();
/*     */     } 
/* 108 */     return (Layout)myLayout;
/*     */   }
/*     */   
/*     */   private RGNode getRGNode(String label) {
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private VisNode readVisNode(String line) {
/*     */     try {
/* 119 */       int id = Integer.parseInt(line);
/* 120 */       line = this.in.readLine();
/* 121 */       double x = Double.parseDouble(line);
/* 122 */       line = this.in.readLine();
/* 123 */       double y = Double.parseDouble(line);
/* 124 */       String label = this.in.readLine();
/* 125 */       line = this.in.readLine();
/* 126 */       int col = Integer.parseInt(line);
/* 127 */       line = this.in.readLine();
/* 128 */       int layer = Integer.parseInt(line);
/* 129 */       line = this.in.readLine();
/* 130 */       int cp = Integer.parseInt(line);
/*     */       
/* 132 */       RGNode rgn = this.rg.getNode(label);
/*     */       
/* 134 */       VisNode vn = new VisNode(rgn, layer, cp);
/*     */       
/* 136 */       vn.addUserDatum(this.key, new Coordinates(x, y), UserData.CLONE);
/* 137 */       vn.addUserDatum(RGVisualisation.VisColorKey, Colors.getColor(rgn.sccNumber()), UserData.CLONE);
/*     */       
/* 139 */       return vn;
/*     */ 
/*     */     
/*     */     }
/* 143 */     catch (Exception e) {
/* 144 */       System.out.println(e);
/* 145 */       e.getLocalizedMessage();
/*     */       
/* 147 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private VisEdge readVisEdge(String line) {
/*     */     try {
/* 154 */       String label = line;
/* 155 */       line = this.in.readLine();
/* 156 */       short id = Short.parseShort(line);
/* 157 */       line = this.in.readLine();
/* 158 */       StringTokenizer st = new StringTokenizer(line, " ");
/* 159 */       VisNode src = this.visNodes.get(Integer.parseInt(st.nextToken()));
/*     */       
/* 161 */       VisNode dest = this.visNodes.get(Integer.parseInt(st.nextToken()));
/* 162 */       return new VisEdge((Vertex)src, (Vertex)dest, label);
/*     */ 
/*     */     
/*     */     }
/* 166 */     catch (Exception e) {
/* 167 */       System.out.println(e);
/* 168 */       e.getLocalizedMessage();
/*     */       
/* 170 */       return null;
/*     */     } 
/*     */   }
/*     */   private String removeWhiteSpace(String str) {
/* 174 */     StringTokenizer st = new StringTokenizer(str, " \n\t");
/* 175 */     StringBuffer sb = new StringBuffer();
/* 176 */     while (st.hasMoreTokens()) {
/* 177 */       sb.append(st.nextToken());
/*     */     }
/* 179 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/GraphReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */