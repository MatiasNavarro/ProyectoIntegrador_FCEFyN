/*     */ package charlie.vis;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ 
/*     */ 
/*     */ public class Zip
/*     */ {
/*     */   public static void zipDirectory(String dirName, String zipFile) {
/*     */     try {
/*  16 */       File dir = new File(dirName);
/*  17 */       if (!dir.isDirectory()) {
/*  18 */         System.out.println("error in zip");
/*     */         return;
/*     */       } 
/*  21 */       String[] fileList = dir.list();
/*  22 */       byte[] buf = new byte[4096];
/*  23 */       ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(zipFile));
/*  24 */       for (int i = 0; i < fileList.length; i++) {
/*  25 */         String fname = fileList[i];
/*  26 */         System.out.println("adding " + fname);
/*  27 */         FileInputStream in = new FileInputStream(dir.getAbsolutePath() + "/" + fname);
/*  28 */         zip.putNextEntry(new ZipEntry(fname));
/*     */         int len;
/*  30 */         while ((len = in.read(buf)) > 0) {
/*  31 */           zip.write(buf, 0, len);
/*     */         }
/*  33 */         in.close();
/*     */       } 
/*  35 */       zip.close();
/*     */     }
/*  37 */     catch (IOException e) {
/*  38 */       e.printStackTrace();
/*  39 */       System.err.println(e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String unZipDirectory(String filename) {
/*     */     try {
/*  46 */       if (!filename.endsWith(".zip")) {
/*  47 */         System.out.println("error in unzip");
/*  48 */         return null;
/*     */       } 
/*  50 */       String directory = filename.substring(0, filename.length() - 4);
/*  51 */       File dir = new File(directory);
/*  52 */       dir.mkdir();
/*     */       
/*  54 */       byte[] buf = new byte[4096];
/*  55 */       ZipInputStream zip = new ZipInputStream(new FileInputStream(filename));
/*  56 */       ZipEntry ze = zip.getNextEntry();
/*  57 */       while (ze != null) {
/*  58 */         String fname = directory + "/" + ze.getName();
/*  59 */         FileOutputStream out = new FileOutputStream(fname);
/*     */         int len;
/*  61 */         while ((len = zip.read(buf)) > 0) {
/*  62 */           out.write(buf, 0, len);
/*     */         }
/*  64 */         out.close();
/*  65 */         ze = zip.getNextEntry();
/*     */       } 
/*     */       
/*  68 */       zip.close();
/*  69 */       return dir.getAbsolutePath();
/*  70 */     } catch (IOException e) {
/*  71 */       e.printStackTrace();
/*  72 */       System.err.println(e.toString());
/*     */       
/*  74 */       return null;
/*     */     } 
/*     */   }
/*     */   public static String unZipDirectory(String filename, File dir) {
/*     */     try {
/*  79 */       if (!filename.endsWith(".zip")) {
/*  80 */         System.out.println("error in unzip");
/*  81 */         return null;
/*     */       } 
/*     */       
/*  84 */       byte[] buf = new byte[4096];
/*  85 */       ZipInputStream zip = new ZipInputStream(new FileInputStream(filename));
/*  86 */       ZipEntry ze = zip.getNextEntry();
/*  87 */       while (ze != null) {
/*  88 */         String fname = dir + "/" + ze.getName();
/*  89 */         FileOutputStream out = new FileOutputStream(fname);
/*     */         int len;
/*  91 */         while ((len = zip.read(buf)) > 0) {
/*  92 */           out.write(buf, 0, len);
/*     */         }
/*  94 */         out.close();
/*  95 */         ze = zip.getNextEntry();
/*     */       } 
/*     */       
/*  98 */       zip.close();
/*  99 */       return dir.getAbsolutePath();
/* 100 */     } catch (IOException e) {
/* 101 */       e.printStackTrace();
/* 102 */       System.err.println(e.toString());
/*     */       
/* 104 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/Zip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */