/*    */ package charlie.vis;
/*    */ 
/*    */ public class Options {
/*  4 */   public static int layout = 0;
/*  5 */   public static IntegerOption layoutO = new IntegerOption(0);
/*  6 */   public static int maxNodes = 500;
/*  7 */   public static int maxLayer = 0;
/*  8 */   public static IntegerOption maxNodesO = new IntegerOption(500);
/*  9 */   public static IntegerOption maxLayerO = new IntegerOption(0);
/* 10 */   public static int hd = 150;
/* 11 */   public static IntegerOption hdO = new IntegerOption(hd);
/* 12 */   public static int vd = 200;
/* 13 */   public static IntegerOption vdO = new IntegerOption(vd);
/* 14 */   public static double x = 250.0D;
/* 15 */   public static double y = 30.0D;
/*    */   public static boolean logicNodes = false;
/*    */   public static boolean wholeGraph = false;
/*    */   public static boolean nodeLabels = false;
/*    */   public static boolean edgeLabels = true;
/*    */   public static boolean customLayout = true;
/*    */   public static boolean vertexLabels = false;
/*    */   public static boolean vertical = true;
/* 23 */   public static final String[] layouts = new String[] { "TreeLayout", "ISOMLayout", "FRLayout", "SpringLayout", "CircleLayout" };
/* 24 */   public static Color filterColor = Color.GREEN;
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/Options.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */