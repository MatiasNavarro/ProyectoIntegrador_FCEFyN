/*     */ package charlie.vis;
/*     */ import GUI.debug.DebugCounter;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.rg.Path;
/*     */ import edu.uci.ics.jung.visualization.Layout;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Session {
/*  12 */   static int count = 0;
/*     */   
/*     */   Vector list;
/*     */   String titel;
/*     */   int pos;
/*     */   Layout current;
/*     */   RGraph rg;
/*     */   PlaceTransitionNet pn;
/*  20 */   File directory = null;
/*  21 */   GraphReader gr = null;
/*     */   public ViewerInfo vi;
/*  23 */   private static ArrayList<File> dirList = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public Session(ViewerInfo vi) {
/*  27 */     this.vi = vi;
/*  28 */     count++;
/*  29 */     this.list = new Vector();
/*  30 */     this.pn = vi.pn;
/*  31 */     this.pos = -1;
/*  32 */     this.current = null;
/*  33 */     this.rg = vi.rg;
/*  34 */     this.titel = this.pn.getName() + "_session" + count;
/*     */     
/*     */     try {
/*  37 */       this.directory = new File(this.titel);
/*  38 */       this.directory.mkdir();
/*  39 */       dirList.add(this.directory);
/*  40 */       this.directory.deleteOnExit();
/*     */     
/*     */     }
/*  43 */     catch (Exception exc) {
/*  44 */       System.out.println(exc);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void removeTempDirs() {
/*  50 */     for (File f : dirList) {
/*  51 */       DebugCounter.inc("Session.java:: removeTempDirs : removing " + f.getAbsolutePath());
/*  52 */       removeDirectory(f);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void removeDirectory(File resource) {
/*  58 */     if (resource.exists()) {
/*  59 */       if (resource.isDirectory()) {
/*  60 */         File[] childFiles = resource.listFiles();
/*  61 */         for (File child : childFiles) {
/*  62 */           removeDirectory(child);
/*     */         }
/*     */       } 
/*  65 */       resource.delete();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void save() {
/*  71 */     save(this.directory.getAbsolutePath() + ".zip");
/*     */   }
/*     */ 
/*     */   
/*     */   public void rename(String oldName, String newName) {
/*     */     try {
/*  77 */       File f = new File(this.directory.getAbsolutePath() + File.separator + oldName);
/*  78 */       f.renameTo(new File(this.directory.getAbsolutePath() + File.separator + newName));
/*  79 */     } catch (Exception e) {
/*  80 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void save(String fileName) {
/*  85 */     saveCurrent();
/*     */     
/*  87 */     String pathFileName = null;
/*     */     
/*  89 */     for (int i = 0; i < this.vi.getPaths().size(); i++) {
/*  90 */       Path toExport = this.vi.getPaths().elementAt(i);
/*  91 */       pathFileName = this.directory.getAbsolutePath() + File.separator + "path" + i + ".path";
/*  92 */       PathIO.exportNodes(pathFileName, toExport);
/*     */     } 
/*  94 */     Zip.zipDirectory(this.directory.getAbsolutePath(), fileName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Layout first() {
/* 100 */     if (this.list.isEmpty()) return null; 
/* 101 */     read(this.list.firstElement());
/* 102 */     this.pos = 0;
/* 103 */     return this.current;
/*     */   }
/*     */   
/*     */   public Layout back() {
/* 107 */     if (this.pos > 0) {
/* 108 */       saveCurrent();
/* 109 */       this.pos--;
/* 110 */       read(this.list.get(this.pos));
/*     */     } 
/* 112 */     return this.current;
/*     */   }
/*     */   
/*     */   public Layout next() {
/* 116 */     if (this.pos < this.list.size() - 1) {
/* 117 */       saveCurrent();
/* 118 */       this.pos++;
/* 119 */       read(this.list.get(this.pos));
/*     */     } 
/* 121 */     return this.current;
/*     */   }
/*     */   
/*     */   private void saveCurrent() {
/* 125 */     if (this.current != null) {
/* 126 */       write(this.list.get(this.pos), this.current);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void finalize() {}
/*     */   
/*     */   public void addEntry(Layout l) {
/* 134 */     if (this.current != null) saveCurrent(); 
/* 135 */     for (int i = this.list.size() - 1; i > this.pos; i--) {
/* 136 */       String name = this.list.get(i);
/* 137 */       this.list.remove(i);
/* 138 */       delete(name);
/*     */     } 
/* 140 */     if (this.list.isEmpty()) {
/*     */       
/* 142 */       this.pos = 0;
/*     */     } else {
/*     */       
/* 145 */       this.pos++;
/*     */     } 
/* 147 */     this.list.add(this.titel + File.separator + "graph" + this.pos + ".graph");
/* 148 */     write(this.titel + File.separator + "graph" + this.pos + "graph", l);
/* 149 */     this.current = l;
/*     */   }
/*     */ 
/*     */   
/*     */   private void read(String graph) {
/* 154 */     this.gr = new GraphReader(graph, this.rg, this.vi.netInfo());
/* 155 */     this.vi.visNodes().clear();
/* 156 */     this.current = this.gr.readGraph(this.vi.visNodes());
/* 157 */     this.vi.setLayout(this.current);
/*     */   }
/*     */   
/*     */   private void write(String name, Layout l) {
/* 161 */     GraphWriter gw = new GraphWriter(name, this.vi.netInfo());
/*     */     
/* 163 */     gw.writeGraph(l);
/*     */   }
/*     */   
/*     */   public void delete(String name) {
/*     */     try {
/* 168 */       File f = new File(this.directory.getAbsolutePath() + File.separator + name);
/*     */       
/* 170 */       f.delete();
/* 171 */     } catch (Exception e) {
/* 172 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Session load(String zipFileName) {
/* 181 */     Session session = new Session(this.vi);
/* 182 */     File dir = session.directory;
/* 183 */     Zip.unZipDirectory(zipFileName, dir);
/*     */     
/* 185 */     String[] files = dir.list();
/* 186 */     for (int i = 0; i < files.length; i++) {
/* 187 */       if (files[i].startsWith("graph")) {
/* 188 */         session.list.add(dir + File.separator + files[i]);
/* 189 */       } else if (files[i].endsWith(".path")) {
/* 190 */         System.out.println("pathFound:" + dir + File.separator + files[i]);
/* 191 */         Path p = PathIO.loadPath(dir + File.separator + files[i], this.rg);
/*     */         
/* 193 */         this.vi.addPath(p);
/*     */       } 
/*     */     } 
/*     */     
/* 197 */     String graph = session.list.firstElement();
/*     */     
/* 199 */     session.first();
/* 200 */     if (session.current == null) {
/* 201 */       System.out.println("error in load");
/* 202 */       System.out.println("delete: " + this.directory.toString());
/* 203 */       this.directory.delete();
/* 204 */       session.clear();
/* 205 */       session = null;
/*     */     } 
/* 207 */     return session;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*     */     try {
/* 214 */       File[] files = this.directory.listFiles();
/* 215 */       for (int i = 0; i < files.length; i++) {
/* 216 */         if (files[i] != null)
/* 217 */           files[i].delete(); 
/*     */       } 
/* 219 */       this.directory.delete();
/* 220 */       this.list.clear();
/* 221 */       this.current = null;
/* 222 */       this.pos = -1;
/* 223 */     } catch (Exception e) {
/* 224 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private String removeWhiteSpace(String str) {
/* 229 */     StringTokenizer st = new StringTokenizer(" \t\n");
/* 230 */     StringBuffer sb = new StringBuffer();
/* 231 */     while (st.hasMoreTokens()) {
/* 232 */       sb.append(st.nextToken());
/*     */     }
/* 234 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/Session.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */