/*     */ package charlie.vis;
/*     */ 
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.util.Iterator;
/*     */ import java.util.Stack;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ public class PathIO
/*     */ {
/*     */   public static void exportNodes(String filename, Path path) {
/*  18 */     if (path == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/*  23 */       Stack<RGNode> buffer = new Stack();
/*  24 */       FileWriter fout = new FileWriter(filename);
/*  25 */       BufferedWriter dout = new BufferedWriter(fout);
/*  26 */       StringBuffer strB = new StringBuffer();
/*  27 */       for (Iterator it = path.iterator(); it.hasNext();) {
/*  28 */         buffer.push(it.next());
/*     */       }
/*  30 */       while (!buffer.isEmpty()) {
/*     */ 
/*     */         
/*  33 */         String label = ((RGNode)buffer.pop()).getLabel().toString();
/*  34 */         strB.append(label);
/*  35 */         if (!buffer.isEmpty()) {
/*  36 */           strB.append(";");
/*     */         }
/*     */       } 
/*  39 */       String name = path.getName() + "\n";
/*  40 */       dout.write(name, 0, name.length());
/*  41 */       String output = strB.toString();
/*  42 */       dout.write(output, 0, output.length());
/*  43 */       dout.close();
/*  44 */       fout.close();
/*  45 */     } catch (Exception e) {
/*  46 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void exportTransitions(String filename, Path path) {
/*  51 */     if (path == null) {
/*     */       return;
/*     */     }
/*     */     try {
/*  55 */       Stack<Short> buffer = new Stack();
/*  56 */       FileWriter fout = new FileWriter(filename);
/*  57 */       BufferedWriter dout = new BufferedWriter(fout);
/*  58 */       StringBuffer strB = new StringBuffer();
/*  59 */       for (Iterator it = path.iteratorEdgeIds(); it.hasNext();) {
/*  60 */         buffer.push(it.next());
/*     */       }
/*  62 */       while (!buffer.isEmpty()) {
/*  63 */         String label = ((Short)buffer.pop()).toString();
/*  64 */         strB.append(label);
/*  65 */         if (!buffer.isEmpty()) {
/*  66 */           strB.append(";");
/*     */         }
/*     */       } 
/*  69 */       String output = strB.toString();
/*  70 */       dout.write(output, 0, output.length());
/*  71 */       dout.close();
/*  72 */       fout.close();
/*  73 */     } catch (Exception e) {
/*  74 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Path loadPath(String filename, RGraph rg) {
/*  79 */     Path path = null;
/*     */     try {
/*  81 */       FileReader fin = new FileReader(filename);
/*  82 */       BufferedReader din = new BufferedReader(fin);
/*  83 */       String name = din.readLine();
/*  84 */       path = readPath(din.readLine(), rg);
/*  85 */       path.setName(name);
/*  86 */       din.close();
/*  87 */       fin.close();
/*  88 */     } catch (Exception e) {
/*  89 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  92 */     return path;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Path readPath(String line, RGraph rg) {
/*  97 */     Path path = null;
/*  98 */     String token = null;
/*  99 */     RGNode node = null;
/*     */     try {
/* 101 */       StringTokenizer nodes = new StringTokenizer(line, ";");
/* 102 */       if (nodes.hasMoreTokens()) {
/* 103 */         token = nodes.nextToken();
/* 104 */         node = rg.getNode(token);
/* 105 */         path = new Path(node, rg);
/*     */       } else {
/* 107 */         return null;
/*     */       } 
/* 109 */       while (nodes.hasMoreTokens()) {
/* 110 */         token = nodes.nextToken();
/* 111 */         node = rg.getNode(token);
/*     */         
/* 113 */         path.checkAndAddNode(node);
/*     */       } 
/* 115 */     } catch (Exception e) {
/* 116 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 119 */     return path;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/PathIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */