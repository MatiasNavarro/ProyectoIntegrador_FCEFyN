/*    */ package charlie.vis;
/*    */ 
/*    */ import charlie.rg.RGNode;
/*    */ import edu.uci.ics.jung.graph.impl.DirectedSparseVertex;
/*    */ import edu.uci.ics.jung.utils.UserData;
/*    */ 
/*    */ public class VisNode
/*    */   extends DirectedSparseVertex
/*    */ {
/*    */   int copies;
/*    */   int cp;
/*    */   int layer;
/* 13 */   public static Object NODEKEY = "node";
/* 14 */   public static Object COLKEY = "vcolor";
/*    */   
/*    */   public VisNode(RGNode n, int l) {
/* 17 */     addUserDatum(NODEKEY, n, UserData.CLONE);
/* 18 */     this.layer = l;
/* 19 */     setColor(n.sccNumber());
/* 20 */     this.cp = 0;
/*    */   }
/*    */   
/*    */   public VisNode(RGNode n, int l, int copy) {
/* 24 */     addUserDatum(NODEKEY, n, UserData.CLONE);
/* 25 */     this.layer = l;
/* 26 */     setColor(n.sccNumber());
/* 27 */     this.cp = copy;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getColor() {
/* 32 */     Object col = getUserDatum(COLKEY);
/* 33 */     if (col == null) {
/* 34 */       return -1;
/*    */     }
/* 36 */     return ((Integer)col).intValue();
/*    */   }
/*    */   
/*    */   public void setColor(int c) {
/* 40 */     addUserDatum(COLKEY, new Integer(c), UserData.CLONE);
/*    */   }
/*    */   
/*    */   public RGNode getRGNode() {
/* 44 */     return (RGNode)getUserDatum(NODEKEY);
/*    */   }
/*    */   
/*    */   public boolean isLogic() {
/* 48 */     return (this.cp > 0);
/*    */   }
/*    */   
/*    */   public int layer() {
/* 52 */     return this.layer;
/*    */   }
/*    */   
/*    */   public VisNode copy() {
/* 56 */     if (this.cp > 0) {
/* 57 */       return null;
/*    */     }
/* 59 */     VisNode ret = new VisNode(getRGNode(), this.layer);
/*    */     
/* 61 */     ret.cp = ++this.copies;
/* 62 */     return ret;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 67 */     if (!(obj instanceof VisNode))
/* 68 */       return false; 
/* 69 */     if (this.cp != ((VisNode)obj).cp)
/* 70 */       return false; 
/* 71 */     return getRGNode().equals(((VisNode)obj).getRGNode());
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/vis/VisNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */