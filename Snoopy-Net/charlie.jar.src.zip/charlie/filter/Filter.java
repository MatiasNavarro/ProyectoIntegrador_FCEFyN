package charlie.filter;

import charlie.pn.Marking;

public interface Filter {
  boolean filter(Marking paramMarking);
  
  Marking createMarking() throws WrongFilterException;
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/Filter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */