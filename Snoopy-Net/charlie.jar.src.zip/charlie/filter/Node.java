/*    */ package charlie.filter;
/*    */ 
/*    */ 
/*    */ abstract class Node
/*    */ {
/*    */   boolean negate = false;
/*    */   
/*    */   public abstract Node right();
/*    */   
/*    */   public abstract Node left();
/*    */   
/*    */   public abstract void setRight(Node paramNode);
/*    */   
/*    */   public boolean negated() {
/* 15 */     return this.negate;
/*    */   } public abstract void setLeft(Node paramNode); public abstract String toString(); public abstract void setId(int paramInt);
/*    */   public abstract int getId();
/*    */   public abstract int op();
/*    */   public void negate() {
/* 20 */     this.negate = !this.negate;
/*    */   }
/*    */   
/*    */   public abstract Node copy();
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/Node.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */