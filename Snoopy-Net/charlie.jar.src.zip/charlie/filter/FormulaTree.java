/*     */ package charlie.filter;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ class FormulaTree
/*     */ {
/*  10 */   private static final Log LOG = LogFactory.getLog(FormulaTree.class);
/*     */   
/*  12 */   static int nodes = 0;
/*     */   Node[] nodeList;
/*  14 */   StringBuffer currentFormula = new StringBuffer();
/*  15 */   Node root = null;
/*     */   
/*  17 */   private Vector<String> v = new Vector<>();
/*     */   
/*     */   void init() {
/*  20 */     nodes = count();
/*  21 */     this.nodeList = new Node[nodes];
/*     */     
/*  23 */     travers(this.root);
/*  24 */     nodes = this.nodeList.length;
/*     */   }
/*     */   
/*     */   public void addFormula(String f) {
/*  28 */     this.v.add(f);
/*     */   }
/*     */   
/*     */   public String getCurrentFormula(int i) {
/*  32 */     return this.v.get(i);
/*     */   }
/*     */   
/*     */   void clear() {
/*  36 */     this.root = null;
/*  37 */     nodes = 0;
/*  38 */     this.nodeList = null;
/*  39 */     this.currentFormula = new StringBuffer();
/*     */   }
/*     */   
/*     */   public String getCurrentFormula() {
/*  43 */     return this.currentFormula.toString();
/*     */   }
/*     */   
/*     */   public void normNOT() {
/*  47 */     this.root = checkNOT(this.root);
/*     */     
/*  49 */     this.root = norm_(this.root);
/*     */     
/*  51 */     init();
/*     */   }
/*     */   
/*     */   private Node norm_(Node n) {
/*  55 */     if (n == null || n instanceof Leaf) {
/*  56 */       return n;
/*     */     }
/*  58 */     Node l = checkNOT(n.left());
/*  59 */     n.setLeft(norm_(l));
/*  60 */     Node r = checkNOT(n.right());
/*  61 */     n.setRight(norm_(r));
/*  62 */     return n;
/*     */   }
/*     */   
/*     */   void travers(Node r) {
/*  66 */     r.setId(--nodes);
/*  67 */     this.nodeList[nodes] = r;
/*  68 */     if (r instanceof Leaf) {
/*     */       return;
/*     */     }
/*  71 */     travers(r.left());
/*  72 */     if (r.right() != null) {
/*  73 */       travers(r.right());
/*     */     }
/*     */   }
/*     */   
/*     */   private int count() {
/*  78 */     int res = count_(this.root, 0);
/*     */     
/*  80 */     if (LOG.isDebugEnabled()) {
/*  81 */       LOG.debug("Nodes: " + res);
/*     */     }
/*     */     
/*  84 */     return res;
/*     */   }
/*     */   
/*     */   private int count_(Node n, int res) {
/*  88 */     if (n == null) {
/*  89 */       return res;
/*     */     }
/*  91 */     res = count_(n.left(), res);
/*  92 */     res = count_(n.right(), res);
/*  93 */     res++;
/*     */     
/*  95 */     return res;
/*     */   }
/*     */ 
/*     */   
/*     */   private Node negate(Node n) {
/* 100 */     return new InternalNode(n, 3, null);
/*     */   }
/*     */   
/*     */   private Node checkNOT(Node n) {
/* 104 */     if (n == null) {
/* 105 */       return n;
/*     */     }
/*     */     
/* 108 */     if (n.op() == 3) {
/* 109 */       Node left = n.left();
/* 110 */       if (left instanceof Leaf) {
/* 111 */         Leaf prop = (Leaf)left;
/* 112 */         int ident = prop.id();
/* 113 */         int value = prop.v();
/* 114 */         int newOp = -1;
/*     */         
/* 116 */         switch (prop.op()) {
/*     */           case 14:
/* 118 */             newOp = 12;
/*     */             break;
/*     */           case 13:
/* 121 */             newOp = 10;
/*     */             break;
/*     */           case 15:
/* 124 */             newOp = 11;
/*     */             break;
/*     */           case 11:
/* 127 */             newOp = 15;
/*     */             break;
/*     */           case 10:
/* 130 */             newOp = 13;
/*     */             break;
/*     */           case 12:
/* 133 */             newOp = 14;
/*     */             break;
/*     */         } 
/* 136 */         return new Leaf(ident, newOp, value, prop.isPlaceId);
/*     */       } 
/*     */       
/* 139 */       switch (left.op()) {
/*     */         case 3:
/* 141 */           return checkNOT(left.left());
/*     */         case 4:
/* 143 */           return new InternalNode(negate(left.left()), 5, negate(left.right()));
/*     */         case 5:
/* 145 */           return new InternalNode(negate(left.left()), 4, negate(left.right()));
/*     */       } 
/*     */     
/*     */     } 
/* 149 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getFormula(int id) {
/* 155 */     return this.nodeList[id];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String getString() {
/* 161 */     if (nodes > 0) {
/* 162 */       return this.nodeList[nodes - 1].toString();
/*     */     }
/* 164 */     return "FormulaTree is empty";
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/FormulaTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */