/*    */ package charlie.filter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Leaf
/*    */   extends Node
/*    */ {
/*    */   int identID;
/*    */   int operator;
/*    */   int value;
/*    */   boolean isPlaceId;
/*    */   int id;
/*    */   
/*    */   public Leaf(int id, int o, int v) {
/* 31 */     this.id = 0; this.identID = id; this.operator = o; this.value = v; this.isPlaceId = false; FormulaTree.nodes++; } public Leaf(int id, int o, int v, boolean isPlaceId) { this.id = 0; this.identID = id; this.operator = o; this.value = v; this.isPlaceId = isPlaceId; FormulaTree.nodes++; } public Leaf(boolean tf) { this.id = 0;
/*    */     this.identID = -1;
/*    */     FormulaTree.nodes++; }
/*    */    public void setId(int id) {
/* 35 */     this.id = id;
/*    */   }
/*    */   
/*    */   public int id() {
/* 39 */     return this.identID;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 44 */     String str = "";
/*    */     
/* 46 */     str = str + "place (" + this.identID + ") ";
/* 47 */     switch (this.operator) { case 13:
/* 48 */         str = str + ">"; break;
/* 49 */       case 14: str = str + "<"; break;
/* 50 */       case 12: str = str + ">="; break;
/* 51 */       case 10: str = str + "<="; break;
/* 52 */       case 11: str = str + "!="; break;
/* 53 */       case 15: str = str + "==";
/*    */         break; }
/*    */     
/* 56 */     if (!this.isPlaceId) {
/* 57 */       str = str + " " + this.value + " ";
/*    */     } else {
/* 59 */       str = str + " place (" + this.value + ") ";
/*    */     } 
/*    */     
/* 62 */     return str;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Node left() {
/* 68 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Node right() {
/* 73 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getId() {
/* 79 */     return this.id;
/*    */   }
/*    */ 
/*    */   
/*    */   public int op() {
/* 84 */     return this.operator;
/*    */   }
/*    */   
/*    */   public int v() {
/* 88 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setRight(Node n) {}
/*    */ 
/*    */   
/*    */   public void setLeft(Node n) {}
/*    */ 
/*    */   
/*    */   public Node copy() {
/* 99 */     return new Leaf(this.identID, this.operator, this.value, this.isPlaceId);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/Leaf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */