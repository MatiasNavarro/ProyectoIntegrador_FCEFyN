/*     */ package charlie.filter;
/*     */ import java.io.InputStream;
/*     */ import java_cup.runtime.Symbol;
/*     */ 
/*     */ class Yylex implements Scanner {
/*   6 */   private final int YY_BUFFER_SIZE = 512;
/*   7 */   private final int YY_F = -1;
/*   8 */   private final int YY_NO_STATE = -1;
/*   9 */   private final int YY_NOT_ACCEPT = 0;
/*  10 */   private final int YY_START = 1;
/*  11 */   private final int YY_END = 2;
/*  12 */   private final int YY_NO_ANCHOR = 4;
/*  13 */   private final int YY_BOL = 128;
/*  14 */   private final int YY_EOF = 129; private BufferedReader yy_reader;
/*     */   private int yy_buffer_index;
/*     */   private int yy_buffer_read;
/*     */   private int yy_buffer_start;
/*     */   private int yy_buffer_end;
/*     */   private char[] yy_buffer;
/*     */   private boolean yy_at_bol;
/*     */   private int yy_lexical_state;
/*     */   private boolean yy_eof_done;
/*     */   
/*     */   Yylex(Reader reader) {
/*  25 */     this();
/*  26 */     if (null == reader) {
/*  27 */       throw new Error("Error: Bad input stream initializer.");
/*     */     }
/*  29 */     this.yy_reader = new BufferedReader(reader);
/*     */   }
/*     */   private final int YYINITIAL = 0; private final int[] yy_state_dtrans; private boolean yy_last_was_cr; private final int YY_E_INTERNAL = 0; private final int YY_E_MATCH = 1; private String[] yy_error_string; private int[] yy_acpt; private int[] yy_cmap; private int[] yy_rmap; private int[][] yy_nxt;
/*     */   Yylex(InputStream instream) {
/*  33 */     this();
/*  34 */     if (null == instream) {
/*  35 */       throw new Error("Error: Bad input stream initializer.");
/*     */     }
/*  37 */     this.yy_reader = new BufferedReader(new InputStreamReader(instream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Yylex() {
/*  50 */     this.yy_eof_done = false;
/*  51 */     this.YYINITIAL = 0;
/*  52 */     this.yy_state_dtrans = new int[] { 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     this.yy_last_was_cr = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     this.YY_E_INTERNAL = 0;
/* 144 */     this.YY_E_MATCH = 1;
/* 145 */     this.yy_error_string = new String[] { "Error: Internal error.\n", "Error: Unmatched input.\n" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     this.yy_acpt = new int[] { 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 4, 0, 4, 4 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     this.yy_cmap = unpackFromString(1, 130, "18:9,22,19,18,22:2,18:18,22,5,18:3,11,7,18,1,2,8,10,18,16,18,17,20:10,18:2,14,15,13,18:2,21:26,3,18,4,12,21,18,21:26,18,9,18,6,18,0:2")[0];
/*     */ 
/*     */ 
/*     */     
/* 238 */     this.yy_rmap = unpackFromString(1, 39, "0,1:5,2,1,3,1,4,1:3,5,6,7,1,8,9,1:5,10,11,1:3,12,1:2,13:2,14,15,16,1")[0];
/*     */ 
/*     */     
/* 241 */     this.yy_nxt = unpackFromString(17, 23, "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,35,37,38,17,18,19,17,-1:38,20,-1:14,21,-1:24,22,-1:28,23,-1:20,24,-1,25,26,-1:19,27,-1,28,-1:27,18,-1:22,19:2,-1:14,31,-1:22,32,-1:10,30:18,-1,30:3,-1,34:7,36,34:14,-1:13,29,-1:10,34:7,36,34:8,33,34:5,-1:8,34,-1:8,30,-1:5");
/*     */     this.yy_buffer = new char[512];
/*     */     this.yy_buffer_read = 0;
/*     */     this.yy_buffer_index = 0;
/*     */     this.yy_buffer_start = 0;
/*     */     this.yy_buffer_end = 0;
/*     */     this.yy_at_bol = true;
/*     */     this.yy_lexical_state = 0;
/*     */   } private void yybegin(int state) { this.yy_lexical_state = state; } public Symbol next_token() throws IOException, ParseException, NoPlaceException {
/* 250 */     int yy_anchor = 4;
/* 251 */     int yy_state = this.yy_state_dtrans[this.yy_lexical_state];
/* 252 */     int yy_next_state = -1;
/* 253 */     int yy_last_accept_state = -1;
/* 254 */     boolean yy_initial = true;
/*     */ 
/*     */     
/* 257 */     yy_mark_start();
/* 258 */     int yy_this_accept = this.yy_acpt[yy_state];
/* 259 */     if (0 != yy_this_accept) {
/* 260 */       yy_last_accept_state = yy_state;
/* 261 */       yy_mark_end();
/*     */     }  while (true) {
/*     */       int yy_lookahead;
/* 264 */       if (yy_initial && this.yy_at_bol) { yy_lookahead = 128; }
/* 265 */       else { yy_lookahead = yy_advance(); }
/* 266 */        yy_next_state = -1;
/* 267 */       yy_next_state = this.yy_nxt[this.yy_rmap[yy_state]][this.yy_cmap[yy_lookahead]];
/* 268 */       if (129 == yy_lookahead && true == yy_initial)
/*     */       {
/* 270 */         return new Symbol(0);
/*     */       }
/* 272 */       if (-1 != yy_next_state) {
/* 273 */         yy_state = yy_next_state;
/* 274 */         yy_initial = false;
/* 275 */         yy_this_accept = this.yy_acpt[yy_state];
/* 276 */         if (0 != yy_this_accept) {
/* 277 */           yy_last_accept_state = yy_state;
/* 278 */           yy_mark_end();
/*     */         } 
/*     */         continue;
/*     */       } 
/* 282 */       if (-1 == yy_last_accept_state) {
/* 283 */         throw new Error("Lexical Error: Unmatched Input.");
/*     */       }
/*     */       
/* 286 */       yy_anchor = this.yy_acpt[yy_last_accept_state];
/* 287 */       if (0 != (0x2 & yy_anchor)) {
/* 288 */         yy_move_end();
/*     */       }
/* 290 */       yy_to_mark();
/* 291 */       switch (yy_last_accept_state) {
/*     */         case -2:
/*     */         case 1:
/*     */           break;
/*     */         
/*     */         case 2:
/* 297 */           return new Symbol(16);
/*     */         case -3:
/*     */           break;
/*     */         case 3:
/* 301 */           return new Symbol(17);
/*     */         case -4:
/*     */           break;
/*     */         case 4:
/* 305 */           return new Symbol(18);
/*     */         case -5:
/*     */           break;
/*     */         case 5:
/* 309 */           return new Symbol(19);
/*     */         case -6:
/*     */           break;
/*     */         case 6:
/* 313 */           return new Symbol(3);
/*     */         case -7:
/*     */           break;
/*     */         case 7:
/* 317 */           return new Symbol(3);
/*     */         case -8:
/*     */           break;
/*     */         case 8:
/* 321 */           return new Symbol(4);
/*     */         case -9:
/*     */           break;
/*     */         case 9:
/* 325 */           return new Symbol(4);
/*     */         case -10:
/*     */           break;
/*     */         case 10:
/* 329 */           return new Symbol(5);
/*     */         case -11:
/*     */           break;
/*     */         case 11:
/* 333 */           return new Symbol(5);
/*     */         case -12:
/*     */           break;
/*     */         case 12:
/* 337 */           return new Symbol(6);
/*     */         case -13:
/*     */           break;
/*     */         case 13:
/* 341 */           return new Symbol(6);
/*     */         case -14:
/*     */           break;
/*     */         case 14:
/* 345 */           return new Symbol(13);
/*     */         case -15:
/*     */           break;
/*     */         case 15:
/* 349 */           return new Symbol(14);
/*     */         case -16:
/*     */           break;
/*     */         case 16:
/* 353 */           System.err.println("Illegal character: " + yytext()); throw new ParseException();
/*     */         
/*     */         case -17:
/*     */         case -18:
/*     */         case 17:
/*     */           break;
/*     */         
/*     */         case 18:
/* 361 */           return new Symbol(20, new Integer(yytext()));
/*     */         case -19:
/*     */           break;
/*     */         case 19:
/* 365 */           return new Symbol(21, new String(yytext()));
/*     */         case -20:
/*     */           break;
/*     */         case 20:
/* 369 */           return new Symbol(11);
/*     */         case -21:
/*     */           break;
/*     */         case 21:
/* 373 */           return new Symbol(4);
/*     */         case -22:
/*     */           break;
/*     */         case 22:
/* 377 */           return new Symbol(5);
/*     */         case -23:
/*     */           break;
/*     */         case 23:
/* 381 */           return new Symbol(12);
/*     */         case -24:
/*     */           break;
/*     */         case 24:
/* 385 */           return new Symbol(11);
/*     */         case -25:
/*     */           break;
/*     */         case 25:
/* 389 */           return new Symbol(10);
/*     */         case -26:
/*     */           break;
/*     */         case 26:
/* 393 */           return new Symbol(8);
/*     */         case -27:
/*     */           break;
/*     */         case 27:
/* 397 */           return new Symbol(7);
/*     */         case -28:
/*     */           break;
/*     */         case 28:
/* 401 */           return new Symbol(15);
/*     */         case -29:
/*     */           break;
/*     */         case 29:
/* 405 */           return new Symbol(7);
/*     */         case -30:
/*     */           break;
/*     */         case 30:
/* 409 */           System.out.println("one line comment: " + yytext()); break;
/*     */         case -31:
/*     */           break;
/*     */         case 31:
/* 413 */           return new Symbol(9);
/*     */         case -32:
/*     */           break;
/*     */         case 32:
/* 417 */           return new Symbol(9);
/*     */         case -33:
/*     */           break;
/*     */         case 33:
/* 421 */           System.out.println("comment: " + yytext()); break;
/*     */         case -34:
/*     */           break;
/*     */         case 35:
/* 425 */           System.err.println("Illegal character: " + yytext()); throw new ParseException();
/*     */         case -35:
/*     */           break;
/*     */         case 37:
/* 429 */           System.err.println("Illegal character: " + yytext()); throw new ParseException();
/*     */         case -36:
/*     */           break;
/*     */         case 38:
/* 433 */           System.err.println("Illegal character: " + yytext()); throw new ParseException();
/*     */         case -37:
/*     */           break;
/*     */         default:
/* 437 */           yy_error(0, false); break;
/*     */         case -1:
/*     */           break;
/* 440 */       }  yy_initial = true;
/* 441 */       yy_state = this.yy_state_dtrans[this.yy_lexical_state];
/* 442 */       yy_next_state = -1;
/* 443 */       yy_last_accept_state = -1;
/* 444 */       yy_mark_start();
/* 445 */       yy_this_accept = this.yy_acpt[yy_state];
/* 446 */       if (0 != yy_this_accept) {
/* 447 */         yy_last_accept_state = yy_state;
/* 448 */         yy_mark_end();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int yy_advance() throws IOException {
/*     */     if (this.yy_buffer_index < this.yy_buffer_read)
/*     */       return this.yy_buffer[this.yy_buffer_index++]; 
/*     */     if (0 != this.yy_buffer_start) {
/*     */       int i = this.yy_buffer_start;
/*     */       int j = 0;
/*     */       while (i < this.yy_buffer_read) {
/*     */         this.yy_buffer[j] = this.yy_buffer[i];
/*     */         i++;
/*     */         j++;
/*     */       } 
/*     */       this.yy_buffer_end -= this.yy_buffer_start;
/*     */       this.yy_buffer_start = 0;
/*     */       this.yy_buffer_read = j;
/*     */       this.yy_buffer_index = j;
/*     */       int next_read = this.yy_reader.read(this.yy_buffer, this.yy_buffer_read, this.yy_buffer.length - this.yy_buffer_read);
/*     */       if (-1 == next_read)
/*     */         return 129; 
/*     */       this.yy_buffer_read += next_read;
/*     */     } 
/*     */     while (this.yy_buffer_index >= this.yy_buffer_read) {
/*     */       if (this.yy_buffer_index >= this.yy_buffer.length)
/*     */         this.yy_buffer = yy_double(this.yy_buffer); 
/*     */       int next_read = this.yy_reader.read(this.yy_buffer, this.yy_buffer_read, this.yy_buffer.length - this.yy_buffer_read);
/*     */       if (-1 == next_read)
/*     */         return 129; 
/*     */       this.yy_buffer_read += next_read;
/*     */     } 
/*     */     return this.yy_buffer[this.yy_buffer_index++];
/*     */   }
/*     */   
/*     */   private void yy_move_end() {
/*     */     if (this.yy_buffer_end > this.yy_buffer_start && '\n' == this.yy_buffer[this.yy_buffer_end - 1])
/*     */       this.yy_buffer_end--; 
/*     */     if (this.yy_buffer_end > this.yy_buffer_start && '\r' == this.yy_buffer[this.yy_buffer_end - 1])
/*     */       this.yy_buffer_end--; 
/*     */   }
/*     */   
/*     */   private void yy_mark_start() {
/*     */     this.yy_buffer_start = this.yy_buffer_index;
/*     */   }
/*     */   
/*     */   private void yy_mark_end() {
/*     */     this.yy_buffer_end = this.yy_buffer_index;
/*     */   }
/*     */   
/*     */   private void yy_to_mark() {
/*     */     this.yy_buffer_index = this.yy_buffer_end;
/*     */     this.yy_at_bol = (this.yy_buffer_end > this.yy_buffer_start && ('\r' == this.yy_buffer[this.yy_buffer_end - 1] || '\n' == this.yy_buffer[this.yy_buffer_end - 1] || '߬' == this.yy_buffer[this.yy_buffer_end - 1] || '߭' == this.yy_buffer[this.yy_buffer_end - 1]));
/*     */   }
/*     */   
/*     */   private String yytext() {
/*     */     return new String(this.yy_buffer, this.yy_buffer_start, this.yy_buffer_end - this.yy_buffer_start);
/*     */   }
/*     */   
/*     */   private int yylength() {
/*     */     return this.yy_buffer_end - this.yy_buffer_start;
/*     */   }
/*     */   
/*     */   private char[] yy_double(char[] buf) {
/*     */     char[] newbuf = new char[2 * buf.length];
/*     */     for (int i = 0; i < buf.length; i++)
/*     */       newbuf[i] = buf[i]; 
/*     */     return newbuf;
/*     */   }
/*     */   
/*     */   private void yy_error(int code, boolean fatal) {
/*     */     System.out.print(this.yy_error_string[code]);
/*     */     System.out.flush();
/*     */     if (fatal)
/*     */       throw new Error("Fatal Error.\n"); 
/*     */   }
/*     */   
/*     */   private int[][] unpackFromString(int size1, int size2, String st) {
/*     */     int colonIndex = -1;
/*     */     int sequenceLength = 0;
/*     */     int sequenceInteger = 0;
/*     */     int[][] res = new int[size1][size2];
/*     */     for (int i = 0; i < size1; i++) {
/*     */       for (int j = 0; j < size2; j++) {
/*     */         if (sequenceLength != 0) {
/*     */           res[i][j] = sequenceInteger;
/*     */           sequenceLength--;
/*     */         } else {
/*     */           int commaIndex = st.indexOf(',');
/*     */           String workString = (commaIndex == -1) ? st : st.substring(0, commaIndex);
/*     */           st = st.substring(commaIndex + 1);
/*     */           colonIndex = workString.indexOf(':');
/*     */           if (colonIndex == -1) {
/*     */             res[i][j] = Integer.parseInt(workString);
/*     */           } else {
/*     */             String lengthString = workString.substring(colonIndex + 1);
/*     */             sequenceLength = Integer.parseInt(lengthString);
/*     */             workString = workString.substring(0, colonIndex);
/*     */             sequenceInteger = Integer.parseInt(workString);
/*     */             res[i][j] = sequenceInteger;
/*     */             sequenceLength--;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     return res;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/Yylex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */