/*    */ package charlie.filter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WrongFilterException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 8090028714491470013L;
/*    */   
/*    */   public WrongFilterException() {}
/*    */   
/*    */   public WrongFilterException(String m) {
/* 14 */     super(m);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/WrongFilterException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */