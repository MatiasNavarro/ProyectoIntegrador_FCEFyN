/*     */ package charlie.filter;
/*     */ import charlie.ctl.Options;
/*     */ import charlie.pn.ExceedsByteException;
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.SafetyException;
/*     */ import charlie.pn.SortedElementsDynamic;
/*     */ import charlie.pn.SortedElementsFactory;
/*     */ import java.io.FileReader;
/*     */ 
/*     */ public class BinFilter implements Filter {
/*  12 */   public Node root = null;
/*  13 */   private final String er_msg = "filter must describe a unique marking: only use placenames, '==' and '*'";
/*     */   public BinFilter(String filterFile, PlaceTransitionNet pn) throws NoPlaceException, ParseException {
/*     */     try {
/*  16 */       FormulaTree ft = new FormulaTree();
/*  17 */       (new parser(new Yylex(new FileReader(filterFile)), ft)).parse();
/*  18 */       this.root = ft.root;
/*  19 */     } catch (NoPlaceException npe) {
/*  20 */       throw npe;
/*  21 */     } catch (ParseException pe) {
/*  22 */       throw pe;
/*  23 */     } catch (Exception e) {
/*     */       
/*  25 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean filter(Marking sp) {
/*  30 */     return check(sp, this.root);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  35 */     return this.root.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean check(Marking sp, Node n) {
/*  52 */     boolean ret = false;
/*  53 */     if (n instanceof Leaf) {
/*  54 */       Leaf l = (Leaf)n;
/*  55 */       return checkProp(sp, l);
/*     */     } 
/*  57 */     if (n instanceof InternalNode) {
/*     */       
/*  59 */       InternalNode i = (InternalNode)n;
/*  60 */       switch (i.op()) {
/*     */         case 4:
/*  62 */           ret = (check(sp, n.left()) && check(sp, n.right()));
/*     */           break;
/*     */         case 5:
/*  65 */           ret = (check(sp, n.left()) || check(sp, n.right()));
/*     */           break;
/*     */         case 3:
/*  68 */           ret = !check(sp, n.left());
/*     */           break;
/*     */       } 
/*     */     } 
/*  72 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkProp(Marking m, Leaf l) {
/*  78 */     boolean ret = false;
/*     */ 
/*     */ 
/*     */     
/*  82 */     int id = (byte)l.id();
/*  83 */     int value = (byte)l.v();
/*  84 */     if (l.isPlaceId) {
/*  85 */       if (Options.debug) System.out.println("placeID"); 
/*  86 */       value = m.getTokenById(value);
/*     */     } 
/*  88 */     byte token = (byte)m.getTokenById(id);
/*     */     
/*  90 */     switch (l.op()) {
/*     */       case 13:
/*  92 */         ret = (token > value);
/*     */         break;
/*     */       
/*     */       case 14:
/*  96 */         ret = (token < value);
/*     */         break;
/*     */       
/*     */       case 15:
/* 100 */         ret = (token == value);
/*     */         break;
/*     */       
/*     */       case 12:
/* 104 */         ret = (token >= value);
/*     */         break;
/*     */       
/*     */       case 10:
/* 108 */         ret = (token <= value);
/*     */         break;
/*     */       
/*     */       case 11:
/* 112 */         ret = (token != value);
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     return ret;
/*     */   }
/*     */   public Marking createMarking() throws WrongFilterException {
/*     */     Marking marking;
/* 124 */     SortedElementsDynamic sortedElementsDynamic = new SortedElementsDynamic(true);
/*     */     
/*     */     try {
/* 127 */       create_((Marking)sortedElementsDynamic, this.root);
/* 128 */       marking = sortedElementsDynamic.toArray();
/* 129 */     } catch (SafetyException se) {
/* 130 */       SortedElementsFactory.safeMode(false);
/*     */       
/* 132 */       marking = createMarking();
/*     */     }
/* 134 */     catch (ExceedsByteException se) {
/* 135 */       SortedElementsFactory.byteMode(false);
/*     */       
/* 137 */       marking = createMarking();
/*     */     }
/* 139 */     catch (WrongFilterException e) {
/* 140 */       throw e;
/*     */     } 
/* 142 */     SortedElementsFactory.safeMode(true);
/* 143 */     return marking;
/*     */   }
/*     */   
/*     */   public void create_(Marking sp, Node n) throws WrongFilterException, SafetyException, ExceedsByteException {
/* 147 */     if (n instanceof Leaf) {
/* 148 */       Leaf l = (Leaf)n;
/*     */       try {
/* 150 */         createPlace(sp, l);
/* 151 */       } catch (SafetyException e) {
/* 152 */         throw e;
/* 153 */       } catch (WrongFilterException ex) {
/* 154 */         throw ex;
/*     */       } 
/*     */       return;
/*     */     } 
/* 158 */     if (n instanceof InternalNode) {
/*     */       
/* 160 */       InternalNode i = (InternalNode)n;
/* 161 */       switch (i.op()) {
/*     */         case 4:
/* 163 */           create_(sp, n.left());
/* 164 */           create_(sp, n.right());
/*     */           break;
/*     */         case 5:
/* 167 */           throw new WrongFilterException("filter must describe a unique marking: only use placenames, '==' and '*'");
/*     */         
/*     */         case 3:
/* 170 */           throw new WrongFilterException("filter must describe a unique marking: only use placenames, '==' and '*'");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createPlace(Marking m, Leaf l) throws WrongFilterException, SafetyException, ExceedsByteException {
/* 180 */     int id = (byte)l.id();
/* 181 */     int value = (byte)l.v();
/* 182 */     if (l.isPlaceId) {
/* 183 */       throw new WrongFilterException();
/*     */     }
/*     */ 
/*     */     
/* 187 */     switch (l.op()) {
/*     */       
/*     */       case 15:
/*     */         try {
/* 191 */           m.addPlace(id, value);
/* 192 */         } catch (SafetyException e) {
/* 193 */           throw e;
/*     */         }  return;
/*     */     } 
/* 196 */     throw new WrongFilterException("filter must describe a unique marking: only use placenames, '==' and '*'");
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/BinFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */