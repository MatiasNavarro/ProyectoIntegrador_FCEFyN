/*    */ package charlie.filter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1498373369849048086L;
/*    */   
/*    */   public ParseException() {}
/*    */   
/*    */   public ParseException(String _message) {
/* 15 */     super(_message);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/ParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */