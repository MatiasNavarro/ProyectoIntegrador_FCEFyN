/*    */ package charlie.filter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InternalNode
/*    */   extends Node
/*    */ {
/*    */   private Node left;
/*    */   private Node right;
/*    */   private int v;
/*    */   int id;
/*    */   
/*    */   public InternalNode(Node l, int val, Node r) {
/* 17 */     this.id = 0; this.left = l;
/*    */     this.right = r;
/*    */     this.v = val;
/* 20 */     FormulaTree.nodes++; } public int op() { return this.v; }
/*    */ 
/*    */   
/*    */   public void setRight(Node n) {
/* 24 */     this.right = n; } public void setLeft(Node n) {
/* 25 */     this.left = n;
/*    */   }
/*    */   public Node copy() {
/* 28 */     Node r = null;
/* 29 */     if (this.right != null) r = this.right.copy(); 
/* 30 */     r.negate = this.negate;
/* 31 */     return new InternalNode(this.left.copy(), this.v, r);
/*    */   }
/*    */   
/*    */   public int getId() {
/* 35 */     return this.id;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setId(int id) {
/* 40 */     this.id = id;
/*    */   }
/*    */   
/*    */   public Node left() {
/* 44 */     return this.left;
/*    */   }
/*    */   
/*    */   public Node right() {
/* 48 */     return this.right;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 52 */     String n = "";
/*    */     
/* 54 */     String r = "";
/* 55 */     if (this.right != null) {
/* 56 */       r = this.right.toString();
/*    */     }
/*    */     
/* 59 */     String l = this.left.toString();
/* 60 */     switch (this.v) {
/*    */       case 4:
/* 62 */         return n + "(" + l + " * " + r + ")";
/* 63 */       case 5: return n + "(" + l + " + " + r + ")";
/* 64 */       case 3: return "! (" + l + ")";
/*    */     } 
/*    */     
/* 67 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/InternalNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */