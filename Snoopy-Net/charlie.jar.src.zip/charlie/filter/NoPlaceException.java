/*    */ package charlie.filter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoPlaceException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -2696919071311667354L;
/*    */   private final String place;
/*    */   
/*    */   public NoPlaceException(String place) {
/* 13 */     this.place = place;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 18 */     return "place '" + this.place + "' does not exist";
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/NoPlaceException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */