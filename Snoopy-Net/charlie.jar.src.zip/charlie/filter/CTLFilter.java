/*    */ package charlie.filter;
/*    */ 
/*    */ import charlie.ctl.ResultTable;
/*    */ import charlie.pn.Marking;
/*    */ 
/*    */ public class CTLFilter
/*    */   implements Filter {
/*    */   ResultTable rt;
/*    */   int formulaId;
/*    */   String name;
/*    */   
/*    */   public CTLFilter(ResultTable rt, int filterFormula, String name) {
/* 13 */     this.rt = rt;
/* 14 */     this.formulaId = filterFormula;
/* 15 */     this.name = name;
/*    */   }
/*    */   
/*    */   public void setFormulaId(int _formulaId) {
/* 19 */     this.formulaId = _formulaId;
/*    */   }
/*    */   
/*    */   public int getFormularId() {
/* 23 */     return this.formulaId;
/*    */   }
/*    */   
/*    */   public boolean filter(Marking m) {
/* 27 */     switch (this.rt.getResult(m, this.formulaId)) {
/*    */       case 1:
/* 29 */         return true;
/*    */       case 0:
/* 31 */         return false;
/*    */     } 
/* 33 */     System.out.println("Error");
/* 34 */     System.exit(1);
/*    */     
/* 36 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 41 */     return this.name;
/*    */   }
/*    */   
/*    */   public Marking createMarking() throws WrongFilterException {
/* 45 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/filter/CTLFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */