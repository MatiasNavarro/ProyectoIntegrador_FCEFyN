/*   */ package charlie.ltl;
/*   */ 
/*   */ public class Options {
/*   */   public static boolean debug = false;
/*   */   public static boolean onTheFly = false;
/*   */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/Options.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */