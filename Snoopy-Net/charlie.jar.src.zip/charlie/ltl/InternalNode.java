/*    */ package charlie.ltl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InternalNode
/*    */   extends Node
/*    */ {
/*    */   private Node left;
/*    */   private Node right;
/*    */   private int formulaId;
/*    */   int id;
/*    */   
/*    */   public InternalNode(Node l, int formulaId, Node r) {
/* 16 */     this.id = 0;
/*    */     this.left = l;
/*    */     this.right = r;
/* 19 */     this.formulaId = formulaId; } public int formulaId() { return this.formulaId; }
/*    */ 
/*    */   
/*    */   public void setRight(Node n) {
/* 23 */     this.right = n; } public void setLeft(Node n) {
/* 24 */     this.left = n;
/*    */   }
/*    */   public Node copy() {
/* 27 */     Node r = null;
/* 28 */     if (this.right != null) r = this.right.copy(); 
/* 29 */     r.negate = this.negate;
/* 30 */     return new InternalNode(this.left.copy(), this.formulaId, r);
/*    */   }
/*    */   
/*    */   public int getId() {
/* 34 */     return this.id;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setId(int id) {
/* 39 */     this.id = id;
/*    */   }
/*    */   
/*    */   public Node left() {
/* 43 */     return this.left;
/*    */   }
/*    */ 
/*    */   
/*    */   public Node right() {
/* 48 */     return this.right;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 52 */     String n = "";
/*    */     
/* 54 */     String r = "";
/* 55 */     if (this.right != null) {
/* 56 */       r = this.right.toString();
/*    */     }
/*    */     
/* 59 */     String l = this.left.toString();
/* 60 */     switch (FormulaTree.getProp(this.formulaId).op()) { case 6:
/* 61 */         return n + "(" + l + " * " + r + ")";
/* 62 */       case 7: return n + "(" + l + " + " + r + ")";
/* 63 */       case 12: return n + "[" + l + " U " + r + "]";
/* 64 */       case 13: return n + "[" + l + " R " + r + "]";
/* 65 */       case 16: return n + "X " + l;
/*    */       case 5:
/* 67 */         return "! " + l; }
/*    */     
/* 69 */     return n;
/*    */   }
/*    */ 
/*    */   
/*    */   public Node negate() {
/* 74 */     if (FormulaTree.getProp(formulaId()).op() == 16) {
/* 75 */       return new InternalNode(this.left.negate(), FormulaTree.getNegation(formulaId()), null);
/*    */     }
/* 77 */     return new InternalNode(this.left.negate(), FormulaTree.getNegation(formulaId()), this.right.negate());
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/InternalNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */