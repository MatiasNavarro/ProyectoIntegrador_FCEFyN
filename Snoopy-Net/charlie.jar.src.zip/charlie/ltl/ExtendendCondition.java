/*    */ package charlie.ltl;
/*    */ 
/*    */ import charlie.pn.Marking;
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ class ExtendendCondition
/*    */   implements Condition
/*    */ {
/*    */   public final boolean KON = true;
/*    */   public final boolean DIS = false;
/*    */   private boolean op = false;
/*    */   private Vector conditions;
/*    */   
/*    */   public ExtendendCondition() {
/* 16 */     this.conditions = new Vector();
/*    */   }
/*    */   
/*    */   public void setOp(boolean o) {
/* 20 */     this.op = o;
/*    */   }
/*    */   
/*    */   public void addCondition(Condition cond) {
/* 24 */     this.conditions.add(cond);
/*    */   }
/*    */   
/*    */   public boolean isSatisfied(Marking m) {
/* 28 */     for (Iterator<Condition> it = this.conditions.iterator(); it.hasNext(); ) {
/* 29 */       Condition c = it.next();
/* 30 */       if (!c.isSatisfied(m)) {
/* 31 */         return false;
/*    */       }
/*    */     } 
/* 34 */     return true;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 38 */     return "extendend";
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/ExtendendCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */