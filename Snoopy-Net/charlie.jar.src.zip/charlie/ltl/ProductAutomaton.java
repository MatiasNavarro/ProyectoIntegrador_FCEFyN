/*    */ package charlie.ltl;
/*    */ 
/*    */ import charlie.pn.DiGraph;
/*    */ import charlie.pn.Edge;
/*    */ import java.util.HashSet;
/*    */ 
/*    */ class ProductAutomaton extends DiGraph {
/*  8 */   private HashSet existentEdges = new HashSet();
/*    */   
/*    */   class ExistentEdge { ProductNode n;
/*    */     
/*    */     ExistentEdge(ProductNode f, ProductNode t) {
/* 13 */       this.n = f; this.m = t;
/*    */     }
/*    */     ProductNode m;
/*    */     public boolean euqals(Object obj) {
/* 17 */       ExistentEdge e = (ExistentEdge)obj;
/* 18 */       return (this.n.equals(e.n) && this.m.equals(e.m));
/*    */     }
/*    */     
/*    */     public int hashCode() {
/* 22 */       return this.n.hashCode() * this.m.hashCode();
/*    */     } }
/*    */ 
/*    */ 
/*    */   
/*    */   public ProductNode getNode(BNode bn) {
/* 28 */     Object o = getVertex(bn);
/* 29 */     if (o == null) return null; 
/* 30 */     return (ProductNode)o;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addNode(BNode bn, int num) {
/* 38 */     addVertex(bn, new ProductNode(bn, num));
/*    */   }
/*    */   
/*    */   public Edge addEdge(ProductNode from, ProductNode to) {
/* 42 */     ExistentEdge e = new ExistentEdge(from, to);
/* 43 */     if (this.existentEdges.contains(e)) return null; 
/* 44 */     this.existentEdges.add(e);
/* 45 */     Edge out = from.out();
/* 46 */     while (out != null) {
/* 47 */       if (from.getLabel().equals(out.node().getLabel())) return null; 
/* 48 */       out = out.next();
/*    */     } 
/*    */ 
/*    */     
/* 52 */     return addEdge(from, to);
/*    */   }
/*    */   
/*    */   public int edges() {
/* 56 */     return this.edges;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/ProductAutomaton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */