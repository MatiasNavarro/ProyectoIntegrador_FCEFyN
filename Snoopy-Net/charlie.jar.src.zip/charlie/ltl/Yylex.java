/*     */ package charlie.ltl;
/*     */ import java.io.InputStream;
/*     */ import java_cup.runtime.Symbol;
/*     */ 
/*     */ class Yylex implements Scanner {
/*   6 */   private final int YY_BUFFER_SIZE = 512;
/*   7 */   private final int YY_F = -1;
/*   8 */   private final int YY_NO_STATE = -1;
/*   9 */   private final int YY_NOT_ACCEPT = 0;
/*  10 */   private final int YY_START = 1;
/*  11 */   private final int YY_END = 2;
/*  12 */   private final int YY_NO_ANCHOR = 4;
/*  13 */   private final int YY_BOL = 128;
/*  14 */   private final int YY_EOF = 129; private BufferedReader yy_reader;
/*     */   private int yy_buffer_index;
/*     */   private int yy_buffer_read;
/*     */   private int yy_buffer_start;
/*     */   private int yy_buffer_end;
/*     */   private char[] yy_buffer;
/*     */   private boolean yy_at_bol;
/*     */   private int yy_lexical_state;
/*     */   private boolean yy_eof_done;
/*     */   
/*     */   Yylex(Reader reader) {
/*  25 */     this();
/*  26 */     if (null == reader) {
/*  27 */       throw new Error("Error: Bad input stream initializer.");
/*     */     }
/*  29 */     this.yy_reader = new BufferedReader(reader);
/*     */   }
/*     */   private final int YYINITIAL = 0; private final int[] yy_state_dtrans; private boolean yy_last_was_cr; private final int YY_E_INTERNAL = 0; private final int YY_E_MATCH = 1; private String[] yy_error_string; private int[] yy_acpt; private int[] yy_cmap; private int[] yy_rmap; private int[][] yy_nxt;
/*     */   Yylex(InputStream instream) {
/*  33 */     this();
/*  34 */     if (null == instream) {
/*  35 */       throw new Error("Error: Bad input stream initializer.");
/*     */     }
/*  37 */     this.yy_reader = new BufferedReader(new InputStreamReader(instream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Yylex() {
/*  50 */     this.yy_eof_done = false;
/*  51 */     this.YYINITIAL = 0;
/*  52 */     this.yy_state_dtrans = new int[] { 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     this.yy_last_was_cr = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     this.YY_E_INTERNAL = 0;
/* 144 */     this.YY_E_MATCH = 1;
/* 145 */     this.yy_error_string = new String[] { "Error: Internal error.\n", "Error: Unmatched input.\n" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     this.yy_acpt = new int[] { 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 4, 4, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     this.yy_cmap = unpackFromString(1, 130, "37:9,41,38,37,41:2,37:18,41,13,37:3,19,15,37,2,3,16,18,37,22,37,36,39:10,37,1,12,21,11,37:2,33,40:3,32,9,8,40:4,34,40:5,7,35,31,6,40:2,10,40:2,4,37,5,20,40,37,28,40:3,26,27,40:5,29,40:5,24,30,23,25,40:5,37,17,37,14,37,0:2")[0];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 260 */     this.yy_rmap = unpackFromString(1, 60, "0,1:6,2:3,3,2,4,5,6,1,7,1,8,1:3,9,10,1,11,1:3,12,1:5,13,1,2:2,14,2:2,14,15,16,17,18,19,1,20,21,22,23,24,25,26,2,27,28,29")[0];
/*     */ 
/*     */ 
/*     */     
/* 264 */     this.yy_nxt = unpackFromString(30, 42, "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,43,23,56:3,57,56:3,58,56:4,46,48,24,25,56,24,-1:48,56:5,-1:12,56:13,-1:3,56:2,-1:7,56:5,-1:12,56:10,59,56:2,-1:3,56:2,-1:22,26,-1:31,27,-1:9,28,29,-1:40,30,-1:35,31,-1:43,32,-1:45,33,-1:26,56:5,-1:12,56,51,56:11,-1:3,56:2,-1:40,25,-1:13,36,-1:31,35:37,-1,35:3,-1,42:15,45,42:25,-1:11,34,-1:36,56:5,-1:12,56:3,37,56:9,-1:3,56:2,-1:2,42:15,45,42:19,39,42:5,-1:16,42,-1:19,35,-1:11,56:5,-1:12,56:9,38,56:3,-1:3,56:2,-1:7,56:5,-1:12,56:9,40,56:3,-1:3,56:2,-1:7,56:5,-1:12,56:3,41,56:9,-1:3,56:2,-1:7,56:5,-1:12,56:2,44,56:10,-1:3,56:2,-1:7,56:5,-1:12,56:6,55,56:6,-1:3,56:2,-1:7,47,56:4,-1:12,56:13,-1:3,56:2,-1:7,56:5,-1:12,56:12,49,-1:3,56:2,-1:7,56:5,-1:12,56:7,50,56:5,-1:3,56:2,-1:7,56:5,-1:12,56:5,52,56:7,-1:3,56:2,-1:7,56,53,56:3,-1:12,56:13,-1:3,56:2,-1:7,56:5,-1:12,56:11,54,56,-1:3,56:2,-1");
/*     */     this.yy_buffer = new char[512];
/*     */     this.yy_buffer_read = 0;
/*     */     this.yy_buffer_index = 0;
/*     */     this.yy_buffer_start = 0;
/*     */     this.yy_buffer_end = 0;
/*     */     this.yy_at_bol = true;
/*     */     this.yy_lexical_state = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private void yybegin(int state) {
/*     */     this.yy_lexical_state = state;
/*     */   }
/*     */ 
/*     */   
/*     */   public Symbol next_token() throws IOException {
/* 281 */     int yy_anchor = 4;
/* 282 */     int yy_state = this.yy_state_dtrans[this.yy_lexical_state];
/* 283 */     int yy_next_state = -1;
/* 284 */     int yy_last_accept_state = -1;
/* 285 */     boolean yy_initial = true;
/*     */ 
/*     */     
/* 288 */     yy_mark_start();
/* 289 */     int yy_this_accept = this.yy_acpt[yy_state];
/* 290 */     if (0 != yy_this_accept) {
/* 291 */       yy_last_accept_state = yy_state;
/* 292 */       yy_mark_end();
/*     */     }  while (true) {
/*     */       int yy_lookahead; String text;
/* 295 */       if (yy_initial && this.yy_at_bol) { yy_lookahead = 128; }
/* 296 */       else { yy_lookahead = yy_advance(); }
/* 297 */        yy_next_state = -1;
/* 298 */       yy_next_state = this.yy_nxt[this.yy_rmap[yy_state]][this.yy_cmap[yy_lookahead]];
/* 299 */       if (129 == yy_lookahead && true == yy_initial)
/*     */       {
/* 301 */         return new Symbol(0);
/*     */       }
/* 303 */       if (-1 != yy_next_state) {
/* 304 */         yy_state = yy_next_state;
/* 305 */         yy_initial = false;
/* 306 */         yy_this_accept = this.yy_acpt[yy_state];
/* 307 */         if (0 != yy_this_accept) {
/* 308 */           yy_last_accept_state = yy_state;
/* 309 */           yy_mark_end();
/*     */         } 
/*     */         continue;
/*     */       } 
/* 313 */       if (-1 == yy_last_accept_state) {
/* 314 */         throw new Error("Lexical Error: Unmatched Input.");
/*     */       }
/*     */       
/* 317 */       yy_anchor = this.yy_acpt[yy_last_accept_state];
/* 318 */       if (0 != (0x2 & yy_anchor)) {
/* 319 */         yy_move_end();
/*     */       }
/* 321 */       yy_to_mark();
/* 322 */       switch (yy_last_accept_state) {
/*     */         case -2:
/*     */         case 1:
/*     */           break;
/*     */         
/*     */         case 2:
/* 328 */           FormulaTree.formula.append(yytext()); return new Symbol(2);
/*     */         case -3:
/*     */           break;
/*     */         case 3:
/* 332 */           FormulaTree.formula.append(yytext()); return new Symbol(23);
/*     */         case -4:
/*     */           break;
/*     */         case 4:
/* 336 */           FormulaTree.formula.append(yytext()); return new Symbol(24);
/*     */         case -5:
/*     */           break;
/*     */         case 5:
/* 340 */           FormulaTree.formula.append(yytext()); return new Symbol(25);
/*     */         case -6:
/*     */           break;
/*     */         case 6:
/* 344 */           FormulaTree.formula.append(yytext()); return new Symbol(26);
/*     */         case -7:
/*     */           break;
/*     */         case 7:
/* 348 */           FormulaTree.formula.append(yytext()); return new Symbol(12);
/*     */         case -8:
/*     */           break;
/*     */         case 8:
/* 352 */           FormulaTree.formula.append(yytext()); return new Symbol(13);
/*     */         case -9:
/*     */           break;
/*     */         case 9:
/* 356 */           FormulaTree.formula.append(yytext()); return new Symbol(15);
/*     */         case -10:
/*     */           break;
/*     */         case 10:
/* 360 */           FormulaTree.formula.append(yytext()); return new Symbol(14);
/*     */         case -11:
/*     */           break;
/*     */         case 11:
/* 364 */           FormulaTree.formula.append(yytext()); return new Symbol(16);
/*     */         case -12:
/*     */           break;
/*     */         case 12:
/* 368 */           FormulaTree.formula.append(yytext()); return new Symbol(20);
/*     */         case -13:
/*     */           break;
/*     */         case 13:
/* 372 */           FormulaTree.formula.append(yytext()); return new Symbol(21);
/*     */         case -14:
/*     */           break;
/*     */         case 14:
/* 376 */           FormulaTree.formula.append(yytext()); return new Symbol(5);
/*     */         case -15:
/*     */           break;
/*     */         case 15:
/* 380 */           FormulaTree.formula.append(yytext()); return new Symbol(5);
/*     */         case -16:
/*     */           break;
/*     */         case 16:
/* 384 */           FormulaTree.formula.append(yytext()); return new Symbol(6);
/*     */         case -17:
/*     */           break;
/*     */         case 17:
/* 388 */           FormulaTree.formula.append(yytext()); return new Symbol(6);
/*     */         case -18:
/*     */           break;
/*     */         case 18:
/* 392 */           FormulaTree.formula.append(yytext()); return new Symbol(7);
/*     */         case -19:
/*     */           break;
/*     */         case 19:
/* 396 */           FormulaTree.formula.append(yytext()); return new Symbol(7);
/*     */         case -20:
/*     */           break;
/*     */         case 20:
/* 400 */           FormulaTree.formula.append(yytext()); return new Symbol(8);
/*     */         case -21:
/*     */           break;
/*     */         case 21:
/* 404 */           FormulaTree.formula.append(yytext()); return new Symbol(8);
/*     */         case -22:
/*     */           break;
/*     */         case 22:
/* 408 */           System.err.println("Illegal character: " + yytext()); break;
/*     */         case -23:
/*     */           break;
/*     */         case 23:
/* 412 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -24:
/*     */           break;
/*     */         case 24:
/* 416 */           text = yytext(); if (!text.equals("\n")) FormulaTree.formula.append(yytext());  break;
/*     */         case -25:
/*     */           break;
/*     */         case 25:
/* 420 */           FormulaTree.formula.append(yytext()); return new Symbol(27, new Integer(yytext()));
/*     */         case -26:
/*     */           break;
/*     */         case 26:
/* 424 */           FormulaTree.formula.append(yytext()); return new Symbol(19);
/*     */         case -27:
/*     */           break;
/*     */         case 27:
/* 428 */           FormulaTree.formula.append(yytext()); return new Symbol(17);
/*     */         case -28:
/*     */           break;
/*     */         case 28:
/* 432 */           FormulaTree.formula.append(yytext()); return new Symbol(18);
/*     */         case -29:
/*     */           break;
/*     */         case 29:
/* 436 */           FormulaTree.formula.append(yytext()); return new Symbol(10);
/*     */         case -30:
/*     */           break;
/*     */         case 30:
/* 440 */           FormulaTree.formula.append(yytext()); return new Symbol(17);
/*     */         case -31:
/*     */           break;
/*     */         case 31:
/* 444 */           FormulaTree.formula.append(yytext()); return new Symbol(6);
/*     */         case -32:
/*     */           break;
/*     */         case 32:
/* 448 */           FormulaTree.formula.append(yytext()); return new Symbol(7);
/*     */         case -33:
/*     */           break;
/*     */         case 33:
/* 452 */           FormulaTree.formula.append(yytext()); return new Symbol(22);
/*     */         case -34:
/*     */           break;
/*     */         case 34:
/* 456 */           FormulaTree.formula.append(yytext()); return new Symbol(9);
/*     */         case -35:
/*     */           break;
/*     */         case 35:
/* 460 */           System.out.println("one line comment: " + yytext()); break;
/*     */         case -36:
/*     */           break;
/*     */         case 36:
/* 464 */           FormulaTree.formula.append(yytext()); return new Symbol(11);
/*     */         case -37:
/*     */           break;
/*     */         case 37:
/* 468 */           FormulaTree.formula.append(yytext()); return new Symbol(3);
/*     */         case -38:
/*     */           break;
/*     */         case 38:
/* 472 */           FormulaTree.formula.append(yytext()); return new Symbol(3);
/*     */         case -39:
/*     */           break;
/*     */         case 39:
/* 476 */           System.out.println("comment: " + yytext()); break;
/*     */         case -40:
/*     */           break;
/*     */         case 40:
/* 480 */           FormulaTree.formula.append(yytext()); return new Symbol(4);
/*     */         case -41:
/*     */           break;
/*     */         case 41:
/* 484 */           FormulaTree.formula.append(yytext()); return new Symbol(4);
/*     */         case -42:
/*     */           break;
/*     */         case 43:
/* 488 */           System.err.println("Illegal character: " + yytext()); break;
/*     */         case -43:
/*     */           break;
/*     */         case 44:
/* 492 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -44:
/*     */           break;
/*     */         case 46:
/* 496 */           System.err.println("Illegal character: " + yytext()); break;
/*     */         case -45:
/*     */           break;
/*     */         case 47:
/* 500 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -46:
/*     */           break;
/*     */         case 48:
/* 504 */           System.err.println("Illegal character: " + yytext()); break;
/*     */         case -47:
/*     */           break;
/*     */         case 49:
/* 508 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -48:
/*     */           break;
/*     */         case 50:
/* 512 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -49:
/*     */           break;
/*     */         case 51:
/* 516 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -50:
/*     */           break;
/*     */         case 52:
/* 520 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -51:
/*     */           break;
/*     */         case 53:
/* 524 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -52:
/*     */           break;
/*     */         case 54:
/* 528 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -53:
/*     */           break;
/*     */         case 55:
/* 532 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -54:
/*     */           break;
/*     */         case 56:
/* 536 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -55:
/*     */           break;
/*     */         case 57:
/* 540 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -56:
/*     */           break;
/*     */         case 58:
/* 544 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -57:
/*     */           break;
/*     */         case 59:
/* 548 */           FormulaTree.formula.append(yytext()); return new Symbol(28, new String(yytext()));
/*     */         case -58:
/*     */           break;
/*     */         default:
/* 552 */           yy_error(0, false); break;
/*     */         case -1:
/*     */           break;
/* 555 */       }  yy_initial = true;
/* 556 */       yy_state = this.yy_state_dtrans[this.yy_lexical_state];
/* 557 */       yy_next_state = -1;
/* 558 */       yy_last_accept_state = -1;
/* 559 */       yy_mark_start();
/* 560 */       yy_this_accept = this.yy_acpt[yy_state];
/* 561 */       if (0 != yy_this_accept) {
/* 562 */         yy_last_accept_state = yy_state;
/* 563 */         yy_mark_end();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int yy_advance() throws IOException {
/*     */     if (this.yy_buffer_index < this.yy_buffer_read)
/*     */       return this.yy_buffer[this.yy_buffer_index++]; 
/*     */     if (0 != this.yy_buffer_start) {
/*     */       int i = this.yy_buffer_start;
/*     */       int j = 0;
/*     */       while (i < this.yy_buffer_read) {
/*     */         this.yy_buffer[j] = this.yy_buffer[i];
/*     */         i++;
/*     */         j++;
/*     */       } 
/*     */       this.yy_buffer_end -= this.yy_buffer_start;
/*     */       this.yy_buffer_start = 0;
/*     */       this.yy_buffer_read = j;
/*     */       this.yy_buffer_index = j;
/*     */       int next_read = this.yy_reader.read(this.yy_buffer, this.yy_buffer_read, this.yy_buffer.length - this.yy_buffer_read);
/*     */       if (-1 == next_read)
/*     */         return 129; 
/*     */       this.yy_buffer_read += next_read;
/*     */     } 
/*     */     while (this.yy_buffer_index >= this.yy_buffer_read) {
/*     */       if (this.yy_buffer_index >= this.yy_buffer.length)
/*     */         this.yy_buffer = yy_double(this.yy_buffer); 
/*     */       int next_read = this.yy_reader.read(this.yy_buffer, this.yy_buffer_read, this.yy_buffer.length - this.yy_buffer_read);
/*     */       if (-1 == next_read)
/*     */         return 129; 
/*     */       this.yy_buffer_read += next_read;
/*     */     } 
/*     */     return this.yy_buffer[this.yy_buffer_index++];
/*     */   }
/*     */   
/*     */   private void yy_move_end() {
/*     */     if (this.yy_buffer_end > this.yy_buffer_start && '\n' == this.yy_buffer[this.yy_buffer_end - 1])
/*     */       this.yy_buffer_end--; 
/*     */     if (this.yy_buffer_end > this.yy_buffer_start && '\r' == this.yy_buffer[this.yy_buffer_end - 1])
/*     */       this.yy_buffer_end--; 
/*     */   }
/*     */   
/*     */   private void yy_mark_start() {
/*     */     this.yy_buffer_start = this.yy_buffer_index;
/*     */   }
/*     */   
/*     */   private void yy_mark_end() {
/*     */     this.yy_buffer_end = this.yy_buffer_index;
/*     */   }
/*     */   
/*     */   private void yy_to_mark() {
/*     */     this.yy_buffer_index = this.yy_buffer_end;
/*     */     this.yy_at_bol = (this.yy_buffer_end > this.yy_buffer_start && ('\r' == this.yy_buffer[this.yy_buffer_end - 1] || '\n' == this.yy_buffer[this.yy_buffer_end - 1] || '߬' == this.yy_buffer[this.yy_buffer_end - 1] || '߭' == this.yy_buffer[this.yy_buffer_end - 1]));
/*     */   }
/*     */   
/*     */   private String yytext() {
/*     */     return new String(this.yy_buffer, this.yy_buffer_start, this.yy_buffer_end - this.yy_buffer_start);
/*     */   }
/*     */   
/*     */   private int yylength() {
/*     */     return this.yy_buffer_end - this.yy_buffer_start;
/*     */   }
/*     */   
/*     */   private char[] yy_double(char[] buf) {
/*     */     char[] newbuf = new char[2 * buf.length];
/*     */     for (int i = 0; i < buf.length; i++)
/*     */       newbuf[i] = buf[i]; 
/*     */     return newbuf;
/*     */   }
/*     */   
/*     */   private void yy_error(int code, boolean fatal) {
/*     */     System.out.print(this.yy_error_string[code]);
/*     */     System.out.flush();
/*     */     if (fatal)
/*     */       throw new Error("Fatal Error.\n"); 
/*     */   }
/*     */   
/*     */   private int[][] unpackFromString(int size1, int size2, String st) {
/*     */     int colonIndex = -1;
/*     */     int sequenceLength = 0;
/*     */     int sequenceInteger = 0;
/*     */     int[][] res = new int[size1][size2];
/*     */     for (int i = 0; i < size1; i++) {
/*     */       for (int j = 0; j < size2; j++) {
/*     */         if (sequenceLength != 0) {
/*     */           res[i][j] = sequenceInteger;
/*     */           sequenceLength--;
/*     */         } else {
/*     */           int commaIndex = st.indexOf(',');
/*     */           String workString = (commaIndex == -1) ? st : st.substring(0, commaIndex);
/*     */           st = st.substring(commaIndex + 1);
/*     */           colonIndex = workString.indexOf(':');
/*     */           if (colonIndex == -1) {
/*     */             res[i][j] = Integer.parseInt(workString);
/*     */           } else {
/*     */             String lengthString = workString.substring(colonIndex + 1);
/*     */             sequenceLength = Integer.parseInt(lengthString);
/*     */             workString = workString.substring(0, colonIndex);
/*     */             sequenceInteger = Integer.parseInt(workString);
/*     */             res[i][j] = sequenceInteger;
/*     */             sequenceLength--;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     return res;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/Yylex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */