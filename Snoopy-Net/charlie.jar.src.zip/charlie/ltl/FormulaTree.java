/*     */ package charlie.ltl;
/*     */ import java.util.Vector;
/*     */ 
/*     */ class FormulaTree {
/*   5 */   static StringBuffer formula = new StringBuffer();
/*   6 */   static int untils = 0;
/*   7 */   static int nodes = 0;
/*     */   static Node[] nodeList;
/*   9 */   static int biggestLeafId = 0;
/*  10 */   static Node root = null;
/*  11 */   static Vector props = new Vector();
/*  12 */   static HashMap ids = new HashMap<>();
/*  13 */   static FormulaSet allProps = new FormulaSet();
/*     */   
/*     */   public static void reset() {
/*  16 */     allProps.clear();
/*  17 */     props.clear();
/*  18 */     ids.clear();
/*  19 */     formula = new StringBuffer();
/*     */   }
/*     */ 
/*     */   
/*     */   static void init() {
/*  24 */     biggestLeafId = 0;
/*  25 */     untils = 0;
/*  26 */     nodes = count();
/*  27 */     nodeList = new Node[nodes];
/*     */     
/*  29 */     travers(root);
/*  30 */     nodes = nodeList.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int add(Formula l) {
/*  37 */     if (ids.containsKey(l)) return ((Integer)ids.get(l)).intValue(); 
/*  38 */     int ret = props.size();
/*  39 */     props.add(l);
/*  40 */     Formula neg = negProp(l);
/*  41 */     props.add(neg);
/*  42 */     ids.put(l, new Integer(ret));
/*  43 */     ids.put(neg, new Integer(ret + 1));
/*  44 */     if (l instanceof Proposition && l.op() != 3 && l.op() != 4) {
/*  45 */       allProps.insert(ret);
/*  46 */       allProps.insert(ret + 1);
/*     */     } 
/*  48 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getNegation(int id) {
/*  54 */     Formula p = getProp(id);
/*  55 */     if (id > 0 && p.isNegationOf(getProp(id - 1))) {
/*  56 */       return id - 1;
/*     */     }
/*  58 */     if (id < props.size() && p.isNegationOf(getProp(id + 1))) {
/*  59 */       return id + 1;
/*     */     }
/*     */     
/*  62 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Formula getProp(int id) {
/*  67 */     return props.get(id);
/*     */   }
/*     */   
/*     */   public static Formula negProp(Formula f) {
/*  71 */     if (f instanceof Proposition) {
/*  72 */       Proposition prop = (Proposition)f;
/*  73 */       int ident = prop.ident();
/*  74 */       int value = prop.v();
/*  75 */       int newOp = -1;
/*  76 */       switch (prop.op()) { case 21:
/*  77 */           newOp = 19; break;
/*  78 */         case 20: newOp = 18; break;
/*  79 */         case 18: newOp = 20; break;
/*  80 */         case 19: newOp = 21; break;
/*  81 */         case 22: newOp = 17; break;
/*  82 */         case 17: newOp = 22; break;
/*  83 */         case 3: return new Proposition(false);
/*  84 */         case 4: return new Proposition(true); }
/*     */       
/*  86 */       return new Proposition(ident, newOp, value, prop.isPlaceId);
/*     */     } 
/*  88 */     NonProposition nonProp = (NonProposition)f;
/*  89 */     int newOP = -1;
/*  90 */     switch (nonProp.op()) { case 6:
/*  91 */         newOP = 7;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  98 */         return new NonProposition(getNegation(nonProp.left), newOP, getNegation(nonProp.right));case 7: newOP = 6; return new NonProposition(getNegation(nonProp.left), newOP, getNegation(nonProp.right));case 12: newOP = 13; return new NonProposition(getNegation(nonProp.left), newOP, getNegation(nonProp.right));case 13: newOP = 12; return new NonProposition(getNegation(nonProp.left), newOP, getNegation(nonProp.right));case 16: return new NonProposition(getNegation(nonProp.left), 16, -1); }  if (Options.debug) System.out.println("error");  return new NonProposition(getNegation(nonProp.left), newOP, getNegation(nonProp.right));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void normNOT() {
/* 103 */     root = checkNOT(root);
/*     */     
/* 105 */     root = norm_(root);
/*     */     
/* 107 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Node norm_(Node n) {
/* 112 */     if (n == null || n instanceof Leaf) return n; 
/* 113 */     Node l = checkNOT(n.left());
/* 114 */     n.setLeft(norm_(l));
/* 115 */     Node r = checkNOT(n.right());
/* 116 */     n.setRight(norm_(r));
/* 117 */     return n;
/*     */   }
/*     */   
/*     */   static void travers(Node r) {
/* 121 */     if (((Formula)props.get(r.formulaId())).op() == 12) untils++;
/*     */     
/* 123 */     r.setId(--nodes);
/* 124 */     nodeList[nodes] = r;
/* 125 */     if (r instanceof Leaf) {
/* 126 */       if (r.getId() > biggestLeafId) biggestLeafId = r.getId(); 
/*     */       return;
/*     */     } 
/* 129 */     travers(r.left());
/* 130 */     if (r.right() != null) {
/* 131 */       travers(r.right());
/*     */     }
/*     */   }
/*     */   
/*     */   private static int count() {
/* 136 */     int res = count_(root, 0);
/*     */     
/* 138 */     return res;
/*     */   }
/*     */   private static int count_(Node n, int res) {
/* 141 */     if (n == null) {
/* 142 */       return res;
/*     */     }
/* 144 */     res = count_(n.left(), res);
/* 145 */     res = count_(n.right(), res);
/* 146 */     res++;
/* 147 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Node checkNOT(Node n) {
/* 168 */     if (n == null) return n; 
/* 169 */     if (n.formulaId() == 5) {
/* 170 */       Node next, left = n.left();
/* 171 */       if (left instanceof Leaf) {
/* 172 */         return new Leaf(getNegation(left.formulaId()));
/*     */       }
/* 174 */       switch (left.formulaId()) {
/*     */         
/*     */         case 5:
/* 177 */           return checkNOT(left.left());
/*     */         
/*     */         case 6:
/* 180 */           return new InternalNode(left.left().negate(), 7, left.right().negate());
/*     */         
/*     */         case 7:
/* 183 */           return new InternalNode(left.left().negate(), 6, left.right().negate());
/*     */         
/*     */         case 12:
/* 186 */           return new InternalNode(left.left().negate(), 13, left.right().negate());
/*     */         
/*     */         case 16:
/* 189 */           next = left.left().negate();
/* 190 */           return new InternalNode(next, 16, null);
/*     */         
/*     */         case 13:
/* 193 */           return new InternalNode(left.left().negate(), 12, left.right().negate());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 200 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   public FormulaSet lookUpNegation(Formula f) {
/* 205 */     int op = f.op();
/* 206 */     int negOP = getNegation(op);
/* 207 */     FormulaSet fs = new FormulaSet();
/* 208 */     for (int i = 0; i < biggestLeafId; i++) {
/* 209 */       if (nodeList[i] instanceof Leaf && nodeList[i].formulaId() == negOP) {
/* 210 */         fs.insert(i);
/*     */       }
/*     */     } 
/* 213 */     return fs;
/*     */   }
/*     */ 
/*     */   
/*     */   public int untils() {
/* 218 */     return untils;
/*     */   }
/*     */   
/*     */   public Node getFormula(int id) {
/* 222 */     return nodeList[id];
/*     */   }
/*     */   
/*     */   public void printProps() {
/* 226 */     for (int i = 0; i < props.size(); i++) {
/* 227 */       System.out.println((new StringBuilder()).append(props.get(i)).append(" - ").append(ids.get(props.get(i))).toString());
/*     */     }
/* 229 */     System.out.println(props);
/*     */   }
/*     */   
/*     */   static String getString() {
/* 233 */     return nodeList[nodes - 1].toString();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/FormulaTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */