package charlie.ltl;

interface Formula {
  boolean isNegationOf(Formula paramFormula);
  
  int op();
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/Formula.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */