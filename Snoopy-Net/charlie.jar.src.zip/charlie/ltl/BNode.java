/*    */ package charlie.ltl;
/*    */ 
/*    */ import charlie.rg.RGNode;
/*    */ 
/*    */ public class BNode {
/*    */   RGNode node;
/*    */   
/*    */   BNode(RGNode n, int mb) {
/*  9 */     this.node = n;
/* 10 */     this.mba = mb;
/*    */   }
/*    */   int mba;
/*    */   public boolean equals(Object obj) {
/* 14 */     if (!(obj instanceof BNode)) return false; 
/* 15 */     BNode bm = (BNode)obj;
/*    */ 
/*    */     
/* 18 */     return (this.node.equals(bm.node) && this.mba == bm.mba);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 22 */     return this.node.getLabel().hashCode() * this.mba;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 26 */     System.out.printf("charlie.ltl.BNode.toString()", new Object[0]);
/* 27 */     return this.mba + ": ";
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/BNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */