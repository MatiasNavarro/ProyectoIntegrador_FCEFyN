/*    */ package charlie.ltl;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormulaTable
/*    */ {
/* 10 */   private HashMap<Object, FormulaSet> map = new HashMap<>();
/*    */ 
/*    */   
/*    */   public FormulaSet get(Object key) {
/* 14 */     FormulaSet result = this.map.get(key);
/* 15 */     if (result == null) {
/* 16 */       result = new FormulaSet();
/* 17 */       this.map.put(key, result);
/*    */     } 
/* 19 */     return result;
/*    */   }
/*    */   
/*    */   public void add(Object key, FormulaSet f) {
/* 23 */     this.map.put(key, f);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/FormulaTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */