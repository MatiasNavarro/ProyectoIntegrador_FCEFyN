/*      */ package charlie.ltl;
/*      */ 
/*      */ import charlie.ds.HashStack;
/*      */ import charlie.pn.Edge;
/*      */ import charlie.pn.PlaceTransitionNet;
/*      */ import charlie.pn.State;
/*      */ import charlie.pn.Transition;
/*      */ import charlie.rg.NoReduction;
/*      */ import charlie.rg.Path;
/*      */ import charlie.rg.RGEdge;
/*      */ import charlie.rg.RGNode;
/*      */ import charlie.rg.RGraph;
/*      */ import charlie.rg.Reduction;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Stack;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class BuechiDFS
/*      */ {
/*      */   private RGraph rg;
/*      */   private BuechiAutomaton bn;
/*      */   private Reduction reduction;
/*      */   private PlaceTransitionNet pn;
/*      */   private Vector acc;
/*      */   HashSet tree;
/*      */   private HashSet acceptingOnCircle;
/*      */   
/*      */   class StackEntry
/*      */   {
/*      */     int id;
/*      */     BNode bnode;
/*      */     BNode bnode2;
/*      */     RGEdge rge;
/*      */     
/*      */     StackEntry(BNode n, BNode n2, RGEdge e, int id) {
/*      */       this.id = id;
/*      */       this.bnode = n;
/*      */       this.rge = e;
/*      */       this.bnode2 = n2;
/*      */     }
/*      */   }
/*      */   
/*      */   class StackEntry2
/*      */   {
/*      */     BNode bnode;
/*      */     BNode bnode2;
/*      */     EdgeQueue eq;
/*      */     
/*      */     StackEntry2(BNode n, BNode n2, EdgeQueue e) {
/*      */       this.bnode = n;
/*      */       this.eq = e;
/*      */       this.bnode2 = n2;
/*      */     }
/*      */   }
/*      */   
/*      */   class StackEntry3
/*      */   {
/*      */     ProductNode s;
/*      */     ProductNode t;
/*      */     Edge e;
/*      */     
/*      */     StackEntry3(ProductNode n, ProductNode n2, Edge e) {
/*      */       this.s = n;
/*      */       this.e = e;
/*      */       this.t = n2;
/*      */     }
/*      */   }
/*      */   
/*      */   public BuechiDFS(BuechiAutomaton bn, RGraph rg, PlaceTransitionNet net) {
/*  244 */     this.tree = new HashSet();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  520 */     this.acceptingOnCircle = new HashSet(); this.rg = rg; this.bn = bn; this.pn = net; this.acc = new Vector(); for (int i = 0; i < bn.acc.size(); i++) this.acc.add(new FormulaSet());  this.reduction = (Reduction)new NoReduction(net);
/*      */   } public ProductAutomaton bfsTreeConstruction(BNode current, BNode target) { System.out.println(this.bn); boolean found = false; HashSet states = new HashSet(); HashSet<BNode> visited = new HashSet(); Vector<BNode> v = new Vector(); v.add(current); int m1 = -1; int count = 0; ProductAutomaton pa = new ProductAutomaton(); pa.addNode(current, count++); ProductNode src = null; ProductNode q = null; while (!v.isEmpty()) { current = v.get(0); src = pa.getNode(current); v.remove(0); int m = current.mba; RGNode n = current.node; EdgeQueue queue = getEdges1(current, true); while (!queue.isEmpty()) { BNode next = ((QueueEntry)queue.dequeue()).bn; ProductNode from = pa.getNode(current); if (!visited.contains(next)) { count++; v.add(next); pa.addNode(next, count); visited.add(next); ProductNode to = pa.getNode(next); pa.addEdge(from, to); }  }  }  if (!found) return null;  return pa; } public BNode spanningGraphConstruction(BNode current, BNode target, ProductAutomaton pa) { BNode acceptingState = null; boolean found = false; HashSet<BNode> visited = new HashSet(); Vector<BNode> v = new Vector(); v.add(current); int m1 = -1; int count = 0; pa.addNode(current, count++); ProductNode src = null; ProductNode q = null; while (!v.isEmpty()) { EdgeQueue queue; current = v.get(0); src = pa.getNode(current); v.remove(0); if (!Options.onTheFly) { queue = getEdges1(current, true); } else { queue = getEdges2(current, true); }  while (!queue.isEmpty()) { BNode next = ((QueueEntry)queue.dequeue()).bn; ProductNode from = pa.getNode(current); if (!visited.contains(next)) { count++; v.add(next); pa.addNode(next, count); visited.add(next); ProductNode to = pa.getNode(next); pa.addEdge(from, to); if (target == null) { if (this.acceptingOnCircle.contains(next)) { acceptingState = next; return acceptingState; }  continue; }  if (next.equals(target)) { acceptingState = next; return acceptingState; }  continue; }  if (target == null) { if (this.acceptingOnCircle.contains(next)) { ProductNode to = pa.getNode(next); pa.addEdge(from, to); acceptingState = next; return acceptingState; }  continue; }  if (next.equals(target)) { ProductNode to = pa.getNode(next); pa.addEdge(from, to); acceptingState = next; return acceptingState; }  }  }  if (!found)
/*      */       return null;  return acceptingState; }
/*  523 */   public HashSet getAccepting() { return this.acceptingOnCircle; }
/*      */   public void pathComputation(ProductAutomaton pa, ProductNode current, BNode target, Path p) { boolean finished = false; boolean v = false; ProductNode start = current; HashSet<ProductNode> visited = new HashSet(); RGNode n = current.bn.node; Stack<StackEntry3> st = new Stack(); HashSet deadNodes = new HashSet(); BNode old = null; RGEdge out = n.out(); Edge e = null; int bm = current.bn.mba; QueueEntry next = null; BNode nextBn = null; boolean ready = false; ProductNode q = null; StackEntry3 ste = null; int m1 = -1; int count = 0; boolean pn = false; do { if (!visited.contains(current)) { visited.add(current); n = current.bn.node; bm = current.bn.mba; e = current.out(); } else if (current.bn.node.equals(target)) { p.checkAndAddNode(current.bn.node); return; }  if (e != null) { q = (ProductNode)e.node(); nextBn = q.bn; if (!visited.contains(q)) { p.checkAndAddNode(q.bn.node); if (q.bn.equals(target))
/*      */             return;  st.push(new StackEntry3(current, q, e)); current = q; count++; } else if (nextBn.equals(target)) { p.checkAndAddNode(nextBn.node); return; }  } else { if (start.equals(current))
/*      */           finished = true;  if (!st.isEmpty()) { ste = st.pop(); current = ste.s; q = ste.t; if (!current.bn.node.equals(q.bn.node))
/*      */             p.deleteLast();  }
/*      */          e = ste.e.next(); }
/*      */        }
/*  530 */     while (!finished || !st.isEmpty()); } public BNode dfs(RGNode n, int baM0, boolean stop) { first = true;
/*  531 */     HashStack stack = new HashStack();
/*  532 */     Vector<Object> scc = new Vector();
/*  533 */     int e1 = 0;
/*  534 */     int e2 = 0;
/*  535 */     BNode accepting = null;
/*  536 */     boolean brute = true;
/*  537 */     boolean ba = true;
/*  538 */     boolean finished = false;
/*  539 */     boolean v = false;
/*  540 */     ProductAutomaton pa = new ProductAutomaton();
/*  541 */     HashSet<BNode> visited = new HashSet();
/*      */ 
/*      */     
/*  544 */     Stack<StackEntry2> st = new Stack();
/*  545 */     stack.clear();
/*  546 */     BNode current = new BNode(n, baM0);
/*  547 */     HashSet<ProductNode> deadNodes = new HashSet();
/*  548 */     BNode old = null;
/*  549 */     BNode start = current;
/*  550 */     RGEdge out = n.out();
/*  551 */     int bm = baM0;
/*  552 */     BNode next = null;
/*  553 */     ProductNode from = null;
/*  554 */     ProductNode to = null;
/*      */     
/*  556 */     boolean ready = false;
/*  557 */     StackEntry2 ste = null;
/*  558 */     int m1 = -1;
/*      */     
/*  560 */     int count = 0;
/*  561 */     EdgeQueue queue = null;
/*  562 */     pa.addNode(current, count);
/*  563 */     to = pa.getNode(current);
/*  564 */     stack.push(to);
/*      */ 
/*      */     
/*  567 */     boolean pn = false;
/*      */     
/*      */     do {
/*  570 */       if (!visited.contains(current)) {
/*      */         
/*  572 */         System.out.print("\r" + count);
/*  573 */         visited.add(current);
/*  574 */         n = current.node;
/*  575 */         from = pa.getNode(current);
/*      */         
/*  577 */         bm = current.mba;
/*      */ 
/*      */         
/*  580 */         if (!Options.onTheFly) {
/*  581 */           out = n.out();
/*  582 */           if (out == null) {
/*  583 */             deadNodes.add(from);
/*      */           }
/*  585 */           queue = getEdges1(current, false);
/*      */         }
/*      */         else {
/*      */           
/*  589 */           if (this.reduction.getTransitions((State)n.getLabel()).isEmpty()) {
/*  590 */             deadNodes.add(from);
/*      */           }
/*  592 */           queue = getEdges2(current, false);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  597 */       if (!queue.isEmpty()) {
/*  598 */         next = (BNode)queue.dequeue();
/*  599 */         from = pa.getNode(current);
/*      */         
/*  601 */         if (!visited.contains(next))
/*      */         {
/*  603 */           st.push(new StackEntry2(current, next, queue));
/*  604 */           current = next;
/*  605 */           n = current.node;
/*  606 */           count++;
/*  607 */           pa.addNode(next, count);
/*  608 */           to = pa.getNode(next);
/*  609 */           to.setNum(count);
/*  610 */           to.setLow(count);
/*  611 */           stack.push(to);
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*  616 */           to = pa.getNode(next);
/*      */ 
/*      */           
/*  619 */           if (stack.contains(to) && to.getNum() < from.getLow()) {
/*  620 */             from.setLow(to.getNum());
/*      */           }
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  627 */         if (!deadNodes.contains(from) && from.getLow() == from.getNum()) {
/*  628 */           boolean found = false;
/*      */           
/*  630 */           scc.clear();
/*      */           
/*  632 */           clearAcc();
/*      */           
/*  634 */           int poped = 0;
/*  635 */           ProductNode h = (ProductNode)stack.peek();
/*      */           
/*  637 */           while (!from.equals(h)) {
/*      */ 
/*      */             
/*  640 */             if (this.bn.isAccepting(h.bn.mba)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  647 */               accepting = h.bn;
/*  648 */               this.acceptingOnCircle.add(accepting);
/*  649 */               found = true;
/*      */             } 
/*  651 */             scc.add(stack.pop());
/*      */             
/*  653 */             poped++;
/*  654 */             h = (ProductNode)stack.peek();
/*      */           } 
/*  656 */           if (from.equals(h)) {
/*      */             
/*  658 */             Object o = stack.pop();
/*      */             
/*  660 */             if (this.bn.isAccepting(h.bn.mba) && poped > 0) {
/*  661 */               scc.add(o);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  668 */               accepting = h.bn;
/*  669 */               this.acceptingOnCircle.add(accepting);
/*  670 */               found = true;
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  678 */           if (this.bn.isAccepting(h.bn.mba) && from.hasEdgetoHimself()) {
/*      */ 
/*      */ 
/*      */             
/*  682 */             accepting = h.bn;
/*  683 */             this.acceptingOnCircle.add(accepting);
/*  684 */             found = true;
/*      */           } 
/*  686 */           if (found && stop) {
/*  687 */             return accepting;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  693 */         if (start.equals(current)) {
/*  694 */           finished = true;
/*      */         }
/*      */         
/*  697 */         if (!st.isEmpty()) {
/*  698 */           ste = st.pop();
/*  699 */           current = ste.bnode;
/*  700 */           next = ste.bnode2;
/*      */           
/*  702 */           n = current.node;
/*  703 */           queue = ste.eq;
/*      */           
/*  705 */           from = pa.getNode(current);
/*  706 */           to = pa.getNode(next);
/*  707 */           if (to.getLow() < from.getLow()) {
/*  708 */             from.setLow(to.getLow());
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  717 */     while (!finished || !st.isEmpty());
/*      */ 
/*      */     
/*  720 */     return accepting; }
/*      */   public boolean checkForAcceptingCirlce(ProductAutomaton pa) { boolean v = false; HashSet<ProductNode> deadNodes = new HashSet(); ProductNode q = (ProductNode)pa.getFirst(); ProductNode start = q; Stack<STE> st = new Stack(); HashStack stack = new HashStack(); HashSet<ProductNode> visited = new HashSet(); HashSet scc = new HashSet(); Edge out = q.out(); ProductNode q_ = (ProductNode)out.node(); int count = 0; STE ste = new STE(q, q_, out); st.push(ste); boolean finished = false; while (true) { if (!visited.contains(q)) { q.setNum(count); q.setLow(count); count++; q.pos = stack.size(); visited.add(q); stack.push(q); if (Options.debug) System.out.println("new: " + q);  out = q.out(); if (out == null) deadNodes.add(q);  }  if (out != null) { q_ = (ProductNode)out.node(); if (!visited.contains(q_)) { st.push(new STE(q, q_, out)); q = q_; } else { if (stack.contains(q_) && q_.getNum() < q.getLow()) q.setLow(q_.getNum());  out = out.next(); }  } else { if (!deadNodes.contains(q) && q.getLow() == q.getNum()) { clearAcc(); int poped = 0; ProductNode h = (ProductNode)stack.peek(); while (!q.equals(h)) { this.bn.isAccepting(h.bn.mba, this.acc); if (checkAcc()) return true;  stack.pop(); poped++; h = (ProductNode)stack.peek(); }  if (q.equals(h)) { stack.pop(); this.bn.isAccepting(h.bn.mba, this.acc); if (checkAcc() && poped > 0) return true;  }  this.bn.isAccepting(q.bn.mba, this.acc); if (checkAcc() && q.hasEdgetoHimself()) return true;  } else if (deadNodes.contains(q)) { stack.pop(); }  if (start.equals(q))
/*      */           finished = true;  if (!st.isEmpty()) { ste = st.pop(); q = ste.q; q_ = ste.q_; out = ste.e; out = out.next(); if (q_.getLow() < q.getLow())
/*      */             q.setLow(q_.getLow());  }  }  if (st.isEmpty() && finished)
/*      */         return false;  }  }
/*      */   private void clearAcc() { for (int i = 0; i < this.acc.size(); i++)
/*      */       ((FormulaSet)this.acc.get(i)).clear();  }
/*      */   private boolean checkAcc() { for (int i = 0; i < this.acc.size(); i++) { if (((FormulaSet)this.acc.get(i)).isEmpty())
/*      */         return false;  }  return true; }
/*      */   class STE {
/*  730 */     ProductNode q; ProductNode q_; Edge e; STE(ProductNode q, ProductNode q_, Edge e) { this.q = q; this.q_ = q_; this.e = e; } } private static boolean first = true; private EdgeQueue getEdges1(BNode current, boolean addTransition) { EdgeQueue queue = new EdgeQueue();
/*  731 */     RGNode n = current.node;
/*  732 */     int bm = current.mba;
/*  733 */     RGEdge out = n.out();
/*  734 */     int m1 = -1;
/*  735 */     if (current.node == this.rg.first && bm == 0) {
/*  736 */       first = true;
/*      */     }
/*  738 */     if (!first) {
/*  739 */       out = n.out();
/*  740 */       if (out == null) {
/*      */         
/*  742 */         BuechiState bs = this.bn.getState(bm);
/*  743 */         for (Iterator<BTransition> it = bs.transitions(); it.hasNext(); ) {
/*      */ 
/*      */           
/*  746 */           BTransition bt = it.next();
/*  747 */           m1 = bt.fire(bm, n.getLabel());
/*  748 */           if (m1 >= 0 && m1 != bm) {
/*  749 */             if (!addTransition) {
/*      */               
/*  751 */               queue.enqueue(new BNode(n, m1)); continue;
/*      */             } 
/*  753 */             queue.enqueue(new QueueEntry(new BNode(n, m1), '翿'));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  758 */       while (out != null) {
/*  759 */         BuechiState bs = this.bn.getState(bm);
/*  760 */         for (Iterator<BTransition> it = bs.transitions(); it.hasNext(); ) {
/*      */ 
/*      */           
/*  763 */           BTransition bt = it.next();
/*  764 */           m1 = bt.fire(bm, out.node(n).getLabel());
/*  765 */           if (m1 >= 0) {
/*  766 */             if (!addTransition) {
/*      */               
/*  768 */               queue.enqueue(new BNode(out.node(n), m1));
/*      */               continue;
/*      */             } 
/*  771 */             queue.enqueue(new QueueEntry(new BNode(out.node(n), m1), out.getId()));
/*      */           } 
/*      */         } 
/*      */         
/*  775 */         out = out.next();
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  784 */       BuechiState bs = this.bn.getState(bm);
/*  785 */       for (Iterator<BTransition> it = bs.transitions(); it.hasNext(); ) {
/*      */ 
/*      */         
/*  788 */         BTransition bt = it.next();
/*  789 */         m1 = bt.fire(bm, n.getLabel());
/*  790 */         if (m1 >= 0 && m1 != bm) {
/*  791 */           if (!addTransition) {
/*      */             
/*  793 */             queue.enqueue(new BNode(n, m1));
/*      */             continue;
/*      */           } 
/*  796 */           queue.enqueue(new QueueEntry(new BNode(n, m1), '翿'));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  801 */     first = false;
/*  802 */     return queue; }
/*      */ 
/*      */   
/*      */   private EdgeQueue getEdges2(BNode current, boolean addTransition) {
/*  806 */     EdgeQueue queue = new EdgeQueue();
/*  807 */     RGNode n = current.node;
/*  808 */     int bm = current.mba;
/*      */     
/*  810 */     int m1 = -1;
/*  811 */     if (current.node == this.rg.first && bm == 0) {
/*  812 */       first = true;
/*      */     }
/*  814 */     if (!first) {
/*  815 */       Collection c = this.reduction.getTransitions((State)n.getLabel());
/*  816 */       if (c.isEmpty()) {
/*      */         
/*  818 */         BuechiState bs = this.bn.getState(bm);
/*  819 */         for (Iterator<BTransition> it = bs.transitions(); it.hasNext(); ) {
/*      */ 
/*      */           
/*  822 */           BTransition bt = it.next();
/*  823 */           m1 = bt.fire(bm, n.getLabel());
/*  824 */           if (m1 >= 0 && m1 != bm) {
/*  825 */             if (!addTransition) {
/*      */               
/*  827 */               queue.enqueue(new BNode(n, m1)); continue;
/*      */             } 
/*  829 */             queue.enqueue(new QueueEntry(new BNode(n, m1), '翿'));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  834 */       for (Iterator<Transition> itc = c.iterator(); itc.hasNext(); ) {
/*  835 */         State nextState = null;
/*  836 */         RGNode next = null;
/*  837 */         Transition t = itc.next();
/*      */         try {
/*  839 */           nextState = t.fire((State)n.getLabel(), true, true);
/*      */         }
/*  841 */         catch (Exception e) {
/*  842 */           e.printStackTrace();
/*      */         } 
/*  844 */         next = this.rg.getNode(nextState);
/*  845 */         if (next == null) {
/*  846 */           next = new RGNode(this.pn, nextState);
/*  847 */           this.rg.addNode(next);
/*  848 */           System.out.print("\r" + this.rg.size());
/*      */         } 
/*  850 */         BuechiState bs = this.bn.getState(bm);
/*  851 */         for (Iterator<BTransition> it = bs.transitions(); it.hasNext(); ) {
/*      */ 
/*      */           
/*  854 */           BTransition bt = it.next();
/*  855 */           m1 = bt.fire(bm, nextState.getPlaceMarking());
/*  856 */           if (m1 >= 0) {
/*  857 */             if (!addTransition) {
/*      */               
/*  859 */               queue.enqueue(new BNode(next, m1));
/*      */               continue;
/*      */             } 
/*  862 */             queue.enqueue(new QueueEntry(new BNode(next, m1), t.getId()));
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/*  869 */       BuechiState bs = this.bn.getState(bm);
/*  870 */       for (Iterator<BTransition> it = bs.transitions(); it.hasNext(); ) {
/*      */ 
/*      */         
/*  873 */         BTransition bt = it.next();
/*  874 */         m1 = bt.fire(bm, n.getLabel());
/*  875 */         if (m1 >= 0 && m1 != bm) {
/*  876 */           if (!addTransition) {
/*      */             
/*  878 */             queue.enqueue(new BNode(n, m1));
/*      */             continue;
/*      */           } 
/*  881 */           queue.enqueue(new QueueEntry(new BNode(n, m1), '翿'));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  886 */     first = false;
/*  887 */     return queue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean dfs2(RGNode n, int baM0, Vector<RGNode> stack, Vector stack2) {
/*  893 */     first = true;
/*  894 */     boolean finished = false;
/*  895 */     boolean v = false;
/*      */     
/*  897 */     HashSet<BNode> visited = new HashSet();
/*      */ 
/*      */     
/*  900 */     Stack<StackEntry2> st = new Stack();
/*  901 */     stack.clear();
/*  902 */     BNode current = new BNode(n, baM0);
/*  903 */     HashSet deadNodes = new HashSet();
/*  904 */     BNode old = null;
/*  905 */     BNode start = current;
/*  906 */     RGEdge out = n.out();
/*  907 */     int bm = baM0;
/*  908 */     QueueEntry next = null;
/*  909 */     BNode nextBn = null;
/*  910 */     ProductNode from = null;
/*  911 */     ProductNode to = null;
/*      */     
/*  913 */     boolean ready = false;
/*  914 */     StackEntry2 ste = null;
/*  915 */     int m1 = -1;
/*      */     
/*  917 */     int count = 0;
/*  918 */     EdgeQueue queue = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  924 */     boolean pn = false;
/*      */     
/*      */     do {
/*  927 */       if (!visited.contains(current)) {
/*  928 */         if (this.bn.isAccepting(current.mba)) {
/*      */ 
/*      */           
/*  931 */           stack2.clear();
/*      */           
/*  933 */           if (dfs3(current, stack2)) {
/*  934 */             return true;
/*      */           }
/*      */         } 
/*      */         
/*  938 */         System.out.print("\r" + count);
/*  939 */         visited.add(current);
/*  940 */         n = current.node;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  946 */         bm = current.mba;
/*      */ 
/*      */         
/*  949 */         queue = getEdges1(current, true);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  954 */       if (!queue.isEmpty()) {
/*  955 */         next = (QueueEntry)queue.dequeue();
/*  956 */         nextBn = next.bn;
/*      */ 
/*      */         
/*  959 */         if (!visited.contains(nextBn))
/*      */         {
/*  961 */           st.push(new StackEntry2(current, nextBn, queue));
/*  962 */           current = nextBn;
/*  963 */           n = current.node;
/*  964 */           count++;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  970 */           stack.add(n);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  987 */         if (!stack.isEmpty()) {
/*  988 */           stack.remove(stack.size() - 1);
/*      */         }
/*  990 */         if (start.equals(current)) {
/*  991 */           finished = true;
/*      */         }
/*      */         
/*  994 */         if (!st.isEmpty()) {
/*  995 */           ste = st.pop();
/*  996 */           current = ste.bnode;
/*  997 */           nextBn = ste.bnode2;
/*      */           
/*  999 */           n = current.node;
/* 1000 */           queue = ste.eq;
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1011 */     while (!finished || !st.isEmpty());
/*      */     
/* 1013 */     stack.clear();
/* 1014 */     stack2.clear();
/* 1015 */     return false;
/*      */   }
/*      */   
/*      */   public boolean dfs3(BNode current, Vector<RGNode> stack) {
/* 1019 */     BNode seed = current;
/* 1020 */     boolean finished = false;
/* 1021 */     boolean v = false;
/*      */     
/* 1023 */     HashSet<BNode> visited = new HashSet();
/* 1024 */     RGNode n = current.node;
/*      */     
/* 1026 */     Stack<StackEntry2> st = new Stack();
/* 1027 */     stack.clear();
/* 1028 */     HashSet deadNodes = new HashSet();
/* 1029 */     BNode old = null;
/* 1030 */     RGEdge out = n.out();
/* 1031 */     int bm = current.mba;
/* 1032 */     QueueEntry next = null;
/* 1033 */     BNode nextBn = null;
/*      */ 
/*      */ 
/*      */     
/* 1037 */     boolean ready = false;
/* 1038 */     StackEntry2 ste = null;
/* 1039 */     int m1 = -1;
/*      */     
/* 1041 */     int count = 0;
/* 1042 */     EdgeQueue queue = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1048 */     boolean pn = false;
/*      */     
/*      */     do {
/* 1051 */       if (!visited.contains(current)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1056 */         visited.add(current);
/* 1057 */         n = current.node;
/*      */ 
/*      */ 
/*      */         
/* 1061 */         bm = current.mba;
/*      */ 
/*      */         
/* 1064 */         queue = getEdges1(current, true);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1069 */       if (!queue.isEmpty()) {
/* 1070 */         next = (QueueEntry)queue.dequeue();
/*      */ 
/*      */         
/* 1073 */         nextBn = next.bn;
/* 1074 */         if (!visited.contains(nextBn))
/*      */         {
/* 1076 */           st.push(new StackEntry2(current, nextBn, queue));
/* 1077 */           current = nextBn;
/* 1078 */           n = current.node;
/* 1079 */           count++;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1085 */           stack.add(n);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1093 */         else if (nextBn.equals(seed))
/*      */         {
/* 1095 */           stack.add(n);
/*      */ 
/*      */           
/* 1098 */           return true;
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1108 */         if (!stack.isEmpty()) {
/* 1109 */           stack.remove(stack.size() - 1);
/*      */         }
/* 1111 */         if (seed.equals(current)) {
/* 1112 */           finished = true;
/*      */         }
/*      */         
/* 1115 */         if (!st.isEmpty()) {
/* 1116 */           ste = st.pop();
/* 1117 */           current = ste.bnode;
/* 1118 */           nextBn = ste.bnode2;
/*      */           
/* 1120 */           n = current.node;
/* 1121 */           queue = ste.eq;
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1133 */     while (!finished || !st.isEmpty());
/*      */     
/* 1135 */     stack.clear();
/* 1136 */     return false;
/*      */   }
/*      */   
/*      */   class QueueEntry {
/*      */     BNode bn;
/*      */     short transition;
/*      */     
/*      */     public QueueEntry(BNode bn, short t) {
/* 1144 */       this.bn = bn;
/* 1145 */       this.transition = t;
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/BuechiDFS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */