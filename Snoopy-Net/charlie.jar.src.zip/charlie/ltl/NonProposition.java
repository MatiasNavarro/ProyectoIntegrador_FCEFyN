/*    */ package charlie.ltl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NonProposition
/*    */   implements Formula
/*    */ {
/*    */   int left;
/*    */   int operator;
/*    */   int right;
/*    */   int id;
/*    */   
/*    */   public NonProposition(int l, int o, int r) {
/* 16 */     this.id = 0;
/*    */     this.left = l;
/*    */     this.operator = o;
/* 19 */     this.right = r; } public void setId(int id) { this.id = id; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 25 */     String l = FormulaTree.getProp(this.left).toString();
/* 26 */     String r = "";
/* 27 */     if (this.right != -1) {
/* 28 */       r = FormulaTree.getProp(this.right).toString();
/*    */     }
/* 30 */     switch (this.operator) { case 6:
/* 31 */         return l + " * " + r;
/* 32 */       case 7: return l + " | " + r;
/* 33 */       case 12: return "< " + l + " U " + r + " >";
/* 34 */       case 13: return "< " + l + " R " + r + " >";
/* 35 */       case 16: return "X" + l; }
/*    */ 
/*    */ 
/*    */     
/* 39 */     return "";
/*    */   }
/*    */ 
/*    */   
/*    */   public int op() {
/* 44 */     return this.operator;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isNegationOf(Formula f) {
/* 50 */     if (!(f instanceof NonProposition)) return false; 
/* 51 */     NonProposition p = (NonProposition)f;
/* 52 */     if (p.op() == 16) {
/* 53 */       return (op() == 16 && this.left == FormulaTree.getNegation(p.left));
/*    */     }
/*    */     
/* 56 */     if (this.left != FormulaTree.getNegation(p.left) || this.right != FormulaTree.getNegation(p.right)) return false; 
/* 57 */     switch (this.operator) { case 6:
/* 58 */         return (p.op() == 7);
/* 59 */       case 7: return (p.op() == 6);
/* 60 */       case 12: return (p.op() == 13);
/* 61 */       case 13: return (p.op() == 12); }
/*    */     
/* 63 */     System.out.println("error");
/*    */ 
/*    */     
/* 66 */     return true;
/*    */   }
/*    */   
/*    */   public NonProposition copy() {
/* 70 */     return new NonProposition(this.left, this.operator, this.right);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 75 */     return toString().hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 79 */     if (!(obj instanceof NonProposition)) return false; 
/* 80 */     NonProposition p = (NonProposition)obj;
/* 81 */     if (this.left != p.left || this.right != p.right || this.operator != p.operator) return false; 
/* 82 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/NonProposition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */