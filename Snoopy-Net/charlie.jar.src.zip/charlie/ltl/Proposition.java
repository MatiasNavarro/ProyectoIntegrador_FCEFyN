/*     */ package charlie.ltl;
/*     */ 
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.UnsignedByte;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Proposition
/*     */   implements Formula, Condition
/*     */ {
/*     */   int ident;
/*     */   int operator;
/*     */   int value;
/*     */   boolean isPlaceId;
/*     */   int id;
/*     */   
/*     */   public boolean isSatisfied(Marking m) {
/*     */     int val = this.value;
/*     */     byte valM = (byte)m.getTokenById(this.ident);
/*     */     if (this.isPlaceId) {
/*     */       val = 0;
/*     */       val = m.getTokenById(this.value);
/*     */     } 
/*     */     switch (this.operator) {
/*     */       case 21:
/*     */         return (valM < val);
/*     */       case 20:
/*     */         return (valM > val);
/*     */       case 18:
/*     */         return (valM <= val);
/*     */       case 19:
/*     */         return (valM >= val);
/*     */       case 22:
/*     */         return (valM == val);
/*     */       case 17:
/*     */         return (valM != val);
/*     */     } 
/*     */     System.out.println("fatal error in condition- undifinied arithmetic operation");
/*     */     System.exit(1);
/*     */     return false;
/*     */   }
/*     */   
/*     */   public Proposition(int id, int o, int v) {
/*  69 */     this.id = 0; this.ident = id; this.operator = o; this.value = v; this.isPlaceId = false; } public Proposition(int id, int o, int v, boolean isPlaceId) { this.id = 0; this.ident = id; this.operator = o; this.value = v; this.isPlaceId = isPlaceId; } public Proposition(boolean tf) { this.id = 0; this.ident = UnsignedByte.zero; if (tf) { this.operator = 3; }
/*     */     else
/*     */     { this.operator = 4; }
/*  72 */      this.isPlaceId = false; } public void setId(int id) { this.id = id; }
/*     */ 
/*     */   
/*     */   public int ident() {
/*  76 */     return this.ident;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  81 */     String str = "";
/*     */ 
/*     */     
/*  84 */     if (this.ident < UnsignedByte.min) {
/*  85 */       str = "false";
/*  86 */       if (this.operator == 3) {
/*  87 */         str = "true";
/*     */       }
/*  89 */       return new String(str);
/*     */     } 
/*     */     
/*  92 */     str = str + this.ident + " ";
/*  93 */     switch (this.operator) {
/*     */       case 20:
/*  95 */         str = str + ">";
/*     */         break;
/*     */       case 21:
/*  98 */         str = str + "<";
/*     */         break;
/*     */       case 19:
/* 101 */         str = str + ">=";
/*     */         break;
/*     */       case 18:
/* 104 */         str = str + "<=";
/*     */         break;
/*     */       case 17:
/* 107 */         str = str + "!=";
/*     */         break;
/*     */       
/*     */       default:
/* 111 */         str = str + "=="; break;
/*     */     } 
/* 113 */     if (!this.isPlaceId) {
/* 114 */       str = str + " " + this.value + " ";
/*     */     } else {
/* 116 */       str = str + " " + this.value + " ";
/*     */     } 
/*     */     
/* 119 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   public int op() {
/* 124 */     return this.operator;
/*     */   }
/*     */   
/*     */   public int v() {
/* 128 */     return this.value;
/*     */   }
/*     */   
/*     */   public boolean isNegationOf(Formula f) {
/* 132 */     if (!(f instanceof Proposition)) {
/* 133 */       return false;
/*     */     }
/* 135 */     Proposition p = (Proposition)f;
/* 136 */     if (this.operator == 3) {
/* 137 */       return (p.operator == 4);
/*     */     }
/* 139 */     if (this.operator == 4) {
/* 140 */       return (p.operator == 3);
/*     */     }
/* 142 */     if (this.ident != p.ident || this.value != p.value || this.isPlaceId != p.isPlaceId) {
/* 143 */       return false;
/*     */     }
/* 145 */     switch (this.operator) {
/*     */       case 20:
/* 147 */         if (p.operator != 18) {
/* 148 */           return false;
/*     */         }
/*     */         break;
/*     */       case 21:
/* 152 */         if (p.operator != 19) {
/* 153 */           return false;
/*     */         }
/*     */         break;
/*     */       case 19:
/* 157 */         if (p.operator != 21) {
/* 158 */           return false;
/*     */         }
/*     */         break;
/*     */       case 18:
/* 162 */         if (p.operator != 20) {
/* 163 */           return false;
/*     */         }
/*     */         break;
/*     */       case 17:
/* 167 */         if (p.operator != 22) {
/* 168 */           return false;
/*     */         }
/*     */         break;
/*     */       case 22:
/* 172 */         if (p.operator != 17) {
/* 173 */           return false;
/*     */         }
/*     */         break;
/*     */     } 
/*     */     
/* 178 */     return true;
/*     */   }
/*     */   
/*     */   public Proposition copy() {
/* 182 */     return new Proposition(this.ident, this.operator, this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 188 */     return toString().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 193 */     if (!(obj instanceof Proposition)) {
/* 194 */       return false;
/*     */     }
/* 196 */     Proposition p = (Proposition)obj;
/* 197 */     if (this.ident != p.ident || this.value != p.value || this.operator != p.operator || this.isPlaceId != p.isPlaceId) {
/* 198 */       return false;
/*     */     }
/* 200 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/Proposition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */