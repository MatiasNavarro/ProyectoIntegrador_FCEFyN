/*   */ package charlie.ltl;
/*   */ 
/*   */ import charlie.pn.Marking;
/*   */ 
/*   */ abstract class BTransition {
/*   */   public BTransition(int src, int ident) {
/* 7 */     this.src = src;
/* 8 */     this.ident = ident;
/*   */   }
/*   */   
/*   */   int src;
/*   */   int ident;
/*   */   
/*   */   public abstract boolean checkConditions(Marking paramMarking);
/*   */   
/*   */   public abstract int fire(int paramInt, Marking paramMarking);
/*   */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/BTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */