/*    */ package charlie.ltl;
/*    */ 
/*    */ class EdgeQueue
/*    */ {
/*    */   Node first;
/*    */   
/*    */   public EdgeQueue() {
/*  8 */     this.first = new Node();
/*  9 */     this.last = new Node();
/* 10 */     this.first.next = this.last;
/* 11 */     this.last.next = this.first;
/* 12 */     this.size = 0;
/*    */   }
/*    */   Node last; int size;
/*    */   public boolean isEmpty() {
/* 16 */     return (this.first.next == this.last);
/*    */   }
/*    */   
/*    */   public int size() {
/* 20 */     return this.size;
/*    */   }
/*    */   
/*    */   public void enqueue(Object obj) {
/* 24 */     Node cur = new Node();
/* 25 */     cur.entry = obj;
/* 26 */     cur.next = this.last;
/* 27 */     this.last.next.next = cur;
/* 28 */     this.last.next = cur;
/* 29 */     this.size++;
/*    */   }
/*    */   
/*    */   public Object first() {
/* 33 */     if (isEmpty()) return null; 
/* 34 */     return this.first.next.entry;
/*    */   }
/*    */   
/*    */   public Object dequeue() {
/* 38 */     if (isEmpty()) return null; 
/* 39 */     Object ret = this.first.next.entry;
/* 40 */     this.first.next = this.first.next.next;
/* 41 */     this.size--;
/* 42 */     return ret;
/*    */   }
/*    */   
/*    */   class Node {
/*    */     Node next;
/*    */     Object entry;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/EdgeQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */