/*    */ package charlie.ltl;
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ class BuechiState {
/*  6 */   static int counter = 0;
/*    */   int ident;
/*    */   Integer c;
/*    */   boolean accepting;
/*    */   FormulaSet oldF;
/*    */   Vector transitions;
/*    */   
/*    */   public BuechiState(int id, FormulaSet old) {
/* 14 */     this.ident = id;
/* 15 */     this.oldF = old;
/* 16 */     this.accepting = false;
/* 17 */     this.transitions = new Vector();
/* 18 */     this.c = new Integer(counter++);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 23 */     return this.c.hashCode();
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 27 */     if (obj instanceof BuechiState && ((BuechiState)obj).c.equals(this.c)) return true; 
/* 28 */     return false;
/*    */   }
/*    */   
/*    */   public void addTransition(Object t) {
/* 32 */     this.transitions.add(t);
/*    */   }
/*    */   
/*    */   public Iterator transitions() {
/* 36 */     return this.transitions.iterator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getString(FormulaTree t) {
/* 43 */     String ret = "ident: " + this.ident + " acc: " + this.accepting + " Transitions: " + this.transitions + " old: " + this.oldF;
/*    */     
/* 45 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/BuechiState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */