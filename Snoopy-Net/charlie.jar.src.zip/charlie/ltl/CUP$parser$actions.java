/*     */ package charlie.ltl;
/*     */ 
/*     */ import charlie.ctl.NoPlaceException;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.UnsignedByte;
/*     */ import java.util.Stack;
/*     */ import java_cup.runtime.Symbol;
/*     */ import java_cup.runtime.lr_parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CUP$parser$actions
/*     */ {
/*     */   private final parser parser;
/*     */   
/*     */   CUP$parser$actions(parser parser1) {
/* 254 */     this.parser = parser1; } public final Symbol CUP$parser$do_action(int CUP$parser$act_num, lr_parser CUP$parser$parser, Stack CUP$parser$stack, int CUP$parser$top) throws Exception { Symbol CUP$parser$result; Node node2; Object object1; Node node1; Object RESULT; int i3; int i1; int ileft; int m; int qleft; int uleft; int pleft; int k; int j; int tleft; int c1left; int fleft; int start_valleft; int cleft; int i8; int i7; int iright; int i6; int qright; int uright; int pright; int i5; int i4; int tright; int c1right; int fright; int start_valright; int cright; String str1; Node node6; String i; Node node5; Object q; Object u; Node p; Node node4; Node node3; Node t; Node c1; Node f; Object start_val; Node c; int i12; int id; int opleft; int i11; int i10; int i9; int bleft; int opright; int i15; int i14; int i13; int bright; Object op; Object object2; Node node8; Node node7; Object b; int i2left; int nleft; int i16; Node ret; int c2left;
/*     */     int i2right;
/*     */     int nright;
/*     */     int c2right;
/*     */     String i2;
/*     */     Integer n;
/*     */     Node c2;
/*     */     int i17;
/*     */     Node ch1;
/*     */     int id2;
/*     */     Node ch2;
/*     */     Node and1;
/*     */     Node and2;
/*     */     Node ch3;
/*     */     Node ch4;
/* 269 */     switch (CUP$parser$act_num) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 33:
/* 274 */         node2 = null;
/* 275 */         i3 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left;
/* 276 */         i8 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).right;
/* 277 */         str1 = (String)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).value;
/* 278 */         i12 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left;
/* 279 */         opright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).right;
/* 280 */         op = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).value;
/* 281 */         i2left = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 282 */         i2right = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 283 */         i2 = (String)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/*     */         
/* 285 */         i17 = PlaceTransitionNet.getReference().lookUpPlaceIDbyName(str1);
/* 286 */         id2 = PlaceTransitionNet.getReference().lookUpPlaceIDbyName(i2);
/* 287 */         if (i17 == UnsignedByte.zero) throw new NoPlaceException(str1); 
/* 288 */         if (id2 == UnsignedByte.zero) throw new NoPlaceException(i2);
/*     */         
/* 290 */         node2 = new Leaf(FormulaTree.add(new Proposition(i17, ((Integer)op).intValue(), id2, true)));
/*     */         
/* 292 */         CUP$parser$result = new Symbol(8, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node2);
/*     */         
/* 294 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 32:
/* 299 */         node2 = null;
/* 300 */         i1 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left;
/* 301 */         i7 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).right;
/* 302 */         node6 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).value;
/* 303 */         node2 = node6;
/* 304 */         CUP$parser$result = new Symbol(8, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node2);
/*     */         
/* 306 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 31:
/* 311 */         node2 = null;
/* 312 */         ileft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 313 */         iright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 314 */         i = (String)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/*     */         
/* 316 */         id = PlaceTransitionNet.getReference().lookUpPlaceIDbyName(i);
/* 317 */         System.out.println(i + "id: " + id);
/* 318 */         if (id == UnsignedByte.zero) throw new NoPlaceException(i);
/*     */ 
/*     */         
/* 321 */         node2 = new Leaf(FormulaTree.add(new Proposition(id, 22, 1)));
/*     */         
/* 323 */         CUP$parser$result = new Symbol(8, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node2);
/*     */         
/* 325 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 30:
/* 330 */         node2 = null;
/* 331 */         ileft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left;
/* 332 */         iright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).right;
/* 333 */         i = (String)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).value;
/* 334 */         opleft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left;
/* 335 */         opright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).right;
/* 336 */         op = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).value;
/* 337 */         nleft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 338 */         nright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 339 */         n = (Integer)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/*     */         
/* 341 */         i17 = PlaceTransitionNet.getReference().lookUpPlaceIDbyName(i);
/* 342 */         System.out.println(i + "id: " + i17);
/* 343 */         if (i17 == UnsignedByte.zero) throw new NoPlaceException(i);
/*     */         
/* 345 */         node2 = new Leaf(FormulaTree.add(new Proposition(i17, ((Integer)op).intValue(), n.intValue())));
/*     */         
/* 347 */         CUP$parser$result = new Symbol(8, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node2);
/*     */         
/* 349 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 29:
/* 354 */         node2 = null;
/*     */         
/* 356 */         node2 = new Leaf(FormulaTree.add(new Proposition(true)));
/*     */         
/* 358 */         CUP$parser$result = new Symbol(8, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node2);
/*     */         
/* 360 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 28:
/* 365 */         node2 = null;
/*     */ 
/*     */         
/* 368 */         node2 = new Leaf(FormulaTree.add(new Proposition(false)));
/*     */ 
/*     */         
/* 371 */         CUP$parser$result = new Symbol(8, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node2);
/*     */         
/* 373 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 27:
/* 378 */         object1 = null;
/* 379 */         object1 = Integer.valueOf(17);
/* 380 */         CUP$parser$result = new Symbol(6, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 382 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 26:
/* 387 */         object1 = null;
/* 388 */         object1 = Integer.valueOf(19);
/* 389 */         CUP$parser$result = new Symbol(6, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 391 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 25:
/* 396 */         object1 = null;
/* 397 */         object1 = Integer.valueOf(22);
/* 398 */         CUP$parser$result = new Symbol(6, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 400 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 24:
/* 405 */         object1 = null;
/* 406 */         object1 = Integer.valueOf(18);
/* 407 */         CUP$parser$result = new Symbol(6, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 409 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 23:
/* 414 */         object1 = null;
/* 415 */         object1 = Integer.valueOf(21);
/* 416 */         CUP$parser$result = new Symbol(6, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 418 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 22:
/* 423 */         object1 = null;
/* 424 */         object1 = Integer.valueOf(20);
/* 425 */         CUP$parser$result = new Symbol(6, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 427 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 21:
/* 432 */         object1 = null;
/* 433 */         object1 = Integer.valueOf(13);
/* 434 */         CUP$parser$result = new Symbol(5, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 436 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 20:
/* 441 */         object1 = null;
/* 442 */         object1 = Integer.valueOf(12);
/* 443 */         CUP$parser$result = new Symbol(5, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 445 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 19:
/* 450 */         object1 = null;
/* 451 */         object1 = Integer.valueOf(16);
/* 452 */         CUP$parser$result = new Symbol(4, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 454 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 18:
/* 459 */         object1 = null;
/* 460 */         object1 = Integer.valueOf(15);
/* 461 */         CUP$parser$result = new Symbol(4, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 463 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 17:
/* 468 */         object1 = null;
/* 469 */         object1 = Integer.valueOf(14);
/* 470 */         CUP$parser$result = new Symbol(4, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 472 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 16:
/* 477 */         object1 = null;
/* 478 */         object1 = Integer.valueOf(11);
/* 479 */         CUP$parser$result = new Symbol(2, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 481 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 15:
/* 486 */         object1 = null;
/* 487 */         object1 = Integer.valueOf(10);
/* 488 */         CUP$parser$result = new Symbol(2, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 490 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 14:
/* 495 */         object1 = null;
/* 496 */         object1 = Integer.valueOf(9);
/* 497 */         CUP$parser$result = new Symbol(2, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 499 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 13:
/* 504 */         object1 = null;
/* 505 */         object1 = Integer.valueOf(5);
/* 506 */         CUP$parser$result = new Symbol(3, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, object1);
/*     */         
/* 508 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 12:
/* 513 */         node1 = null;
/* 514 */         m = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 3)).left;
/* 515 */         i6 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 3)).right;
/* 516 */         node5 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 3)).value;
/* 517 */         i11 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left;
/* 518 */         i15 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).right;
/* 519 */         object2 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).value;
/* 520 */         i16 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left;
/* 521 */         c2right = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).right;
/* 522 */         c2 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).value;
/*     */         
/* 524 */         if (((Integer)object2).intValue() == 12) {
/* 525 */           node1 = parser.makeU(node5, c2);
/*     */         } else {
/* 527 */           node1 = parser.makeR(node5, c2);
/*     */         } 
/* 529 */         CUP$parser$result = new Symbol(10, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 4)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 531 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 11:
/* 536 */         node1 = null;
/* 537 */         m = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 3)).left;
/* 538 */         i6 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 3)).right;
/* 539 */         node5 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 3)).value;
/* 540 */         i11 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left;
/* 541 */         i15 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).right;
/* 542 */         object2 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).value;
/* 543 */         i16 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left;
/* 544 */         c2right = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).right;
/* 545 */         c2 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).value;
/*     */         
/* 547 */         if (((Integer)object2).intValue() == 12) {
/* 548 */           node1 = parser.makeU(node5, c2);
/*     */         } else {
/* 550 */           node1 = parser.makeR(node5, c2);
/*     */         } 
/* 552 */         CUP$parser$result = new Symbol(10, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 4)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 554 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 10:
/* 559 */         node1 = null;
/* 560 */         qleft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left;
/* 561 */         qright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).right;
/* 562 */         q = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).value;
/* 563 */         i10 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 564 */         i14 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 565 */         node8 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/*     */         
/* 567 */         switch (((Integer)q).intValue()) {
/*     */           case 14:
/* 569 */             node1 = parser.makeF(node8);
/*     */             break;
/*     */           case 15:
/* 572 */             node1 = parser.makeG(node8);
/*     */             break;
/*     */           case 16:
/* 575 */             System.out.println("sym.NEXT found: 16");
/* 576 */             node1 = parser.makeX(node8);
/* 577 */             System.out.println("RESULT: " + node1);
/*     */             break;
/*     */         } 
/*     */ 
/*     */         
/* 582 */         CUP$parser$result = new Symbol(10, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 584 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 9:
/* 589 */         node1 = null;
/* 590 */         uleft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left;
/* 591 */         uright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).right;
/* 592 */         u = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).value;
/* 593 */         i10 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 594 */         i14 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 595 */         node8 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/*     */ 
/*     */         
/* 598 */         ret = node8.negate();
/* 599 */         FormulaTree.root = ret;
/* 600 */         node1 = ret;
/*     */         
/* 602 */         CUP$parser$result = new Symbol(10, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 604 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 8:
/* 609 */         node1 = null;
/* 610 */         pleft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 611 */         pright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 612 */         p = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/* 613 */         node1 = p;
/* 614 */         CUP$parser$result = new Symbol(10, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 616 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 7:
/* 621 */         node1 = null;
/* 622 */         k = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left;
/* 623 */         i5 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).right;
/* 624 */         node4 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).value;
/* 625 */         i10 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 626 */         i14 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 627 */         node8 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/* 628 */         node1 = parser.makeNode(node4, 6, node8);
/* 629 */         CUP$parser$result = new Symbol(11, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 631 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/* 636 */         node1 = null;
/* 637 */         j = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 638 */         i4 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 639 */         node3 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/* 640 */         node1 = node3;
/* 641 */         CUP$parser$result = new Symbol(11, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 643 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 5:
/* 648 */         node1 = null;
/* 649 */         j = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left;
/* 650 */         i4 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).right;
/* 651 */         node3 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).value;
/* 652 */         i9 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 653 */         i13 = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 654 */         node7 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/* 655 */         node1 = parser.makeNode(node3, 7, node7);
/* 656 */         CUP$parser$result = new Symbol(9, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 658 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 663 */         node1 = null;
/* 664 */         tleft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 665 */         tright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 666 */         t = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/* 667 */         node1 = t;
/* 668 */         CUP$parser$result = new Symbol(9, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 670 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/* 675 */         node1 = null;
/* 676 */         c1left = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left;
/* 677 */         c1right = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).right;
/* 678 */         c1 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).value;
/* 679 */         bleft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left;
/* 680 */         bright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).right;
/* 681 */         b = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).value;
/* 682 */         c2left = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 683 */         c2right = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 684 */         c2 = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/*     */         
/* 686 */         switch (((Integer)b).intValue()) {
/*     */           case 8:
/* 688 */             ch1 = c1.copy();
/* 689 */             ch2 = c2.copy();
/*     */             
/* 691 */             and1 = parser.makeNode(c1, 6, c2);
/*     */             
/* 693 */             and2 = parser.makeNode(ch2, 6, ch2);
/* 694 */             node1 = parser.makeNode(and1, 7, and2);
/*     */             break;
/*     */           case 9:
/* 697 */             ch1 = c1.negate();
/* 698 */             node1 = parser.makeNode(ch1, 7, c2);
/*     */             break;
/*     */           case 10:
/* 701 */             ch2 = c2.negate();
/* 702 */             node1 = parser.makeNode(c1, 7, ch2);
/*     */             break;
/*     */           
/*     */           case 11:
/* 706 */             ch1 = c1.negate();
/* 707 */             ch3 = parser.makeNode(ch1, 7, c2);
/* 708 */             ch2 = c2.negate();
/* 709 */             ch4 = parser.makeNode(c1, 7, ch2);
/* 710 */             node1 = parser.makeNode(ch3, 6, ch4);
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 717 */         CUP$parser$result = new Symbol(7, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 2)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 719 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 724 */         node1 = null;
/* 725 */         fleft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 726 */         fright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 727 */         f = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/* 728 */         node1 = f;
/* 729 */         CUP$parser$result = new Symbol(7, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, node1);
/*     */         
/* 731 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 736 */         RESULT = null;
/* 737 */         start_valleft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left;
/* 738 */         start_valright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).right;
/* 739 */         start_val = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).value;
/* 740 */         RESULT = start_val;
/* 741 */         CUP$parser$result = new Symbol(0, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 1)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, RESULT);
/*     */ 
/*     */         
/* 744 */         CUP$parser$parser.done_parsing();
/* 745 */         return CUP$parser$result;
/*     */ 
/*     */ 
/*     */       
/*     */       case 0:
/* 750 */         RESULT = null;
/* 751 */         cleft = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left;
/* 752 */         cright = ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right;
/* 753 */         c = (Node)((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).value;
/*     */         
/* 755 */         CUP$parser$result = new Symbol(1, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).left, ((Symbol)CUP$parser$stack.elementAt(CUP$parser$top - 0)).right, RESULT);
/*     */         
/* 757 */         return CUP$parser$result;
/*     */     } 
/*     */ 
/*     */     
/* 761 */     throw new Exception("Invalid action number found in internal parse table"); }
/*     */ 
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/CUP$parser$actions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */