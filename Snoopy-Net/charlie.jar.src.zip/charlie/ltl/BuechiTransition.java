/*    */ package charlie.ltl;
/*    */ 
/*    */ import charlie.pn.Marking;
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ class BuechiTransition
/*    */   extends BTransition {
/*    */   public boolean toError = false;
/* 10 */   FormulaSet formulae = new FormulaSet();
/*    */   Vector conditions;
/*    */   
/*    */   public BuechiTransition(int src, int ident, FormulaSet f) {
/* 14 */     super(src, ident);
/* 15 */     this.formulae = f;
/* 16 */     this.conditions = new Vector();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addFormulae(int f) {
/* 23 */     this.formulae.insert(f);
/*    */   }
/*    */   
/*    */   public void addCondition(Condition c) {
/* 27 */     this.conditions.add(c);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean checkConditions(Marking m) {
/* 32 */     for (Iterator<Condition> it = this.conditions.iterator(); it.hasNext(); ) {
/*    */       
/* 34 */       Condition c = it.next();
/*    */ 
/*    */       
/* 37 */       if (!c.isSatisfied(m)) {
/* 38 */         return false;
/*    */       }
/*    */     } 
/* 41 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int fire(int src, Marking mpn) {
/* 46 */     if (!checkConditions(mpn)) return -1; 
/* 47 */     if (src == this.src) return this.ident; 
/* 48 */     return -1;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 53 */     String ret = "dest" + this.ident;
/*    */     
/* 55 */     ret = ret + " - ";
/* 56 */     if (this.toError) {
/* 57 */       ret = ret + "err";
/*    */     }
/* 59 */     ret = ret + this.formulae.toString();
/*    */     
/* 61 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/BuechiTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */