/*     */ package charlie.ltl;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class BuechiConstruction {
/*     */   private Vector states;
/*     */   private Vector acc;
/*     */   private FormulaTree ltlFormula;
/*     */   private int idents;
/*     */   private int finalIdents;
/*  12 */   static FormulaTable oldF = new FormulaTable();
/*  13 */   FormulaTable newF = new FormulaTable();
/*  14 */   FormulaTable nextF = new FormulaTable();
/*  15 */   static FormulaTable pred = new FormulaTable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int iterations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BuechiAutomaton construct() {
/*  28 */     this.states.add(new BuechiState(0, new FormulaSet()));
/*  29 */     Vector<BuechiState> notready = new Vector();
/*  30 */     FormulaSet pred = new FormulaSet();
/*  31 */     pred.insert(0);
/*  32 */     FormulaSet n = new FormulaSet();
/*  33 */     n.insert(FormulaTree.root.formulaId());
/*  34 */     BuechiState q = new BuechiState(++this.idents, new FormulaSet());
/*  35 */     this.newF.add(q, n);
/*  36 */     this; BuechiConstruction.pred.get(q).insert(0);
/*     */     
/*  38 */     notready.add(q);
/*  39 */     expand(notready);
/*  40 */     this.newF = null;
/*  41 */     this.nextF = null;
/*  42 */     BuechiAutomaton ba = new BuechiAutomaton(this.states, this.ltlFormula);
/*  43 */     ba.acceptingStateSet(this.ltlFormula);
/*     */     
/*  45 */     return ba.getUBA();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void expand(Vector<BuechiState> notready) {
/*  54 */     Vector<BuechiState> ready = new Vector();
/*  55 */     label26: while (!notready.isEmpty()) {
/*  56 */       BuechiState q = notready.iterator().next();
/*     */ 
/*     */       
/*  59 */       notready.remove(q);
/*  60 */       while (!this.newF.get(q).isEmpty()) {
/*     */         FormulaSet and; BuechiState q_;
/*     */         FormulaSet h;
/*  63 */         int f = this.newF.get(q).first();
/*     */         
/*  65 */         oldF.get(q).insert(f);
/*     */         
/*  67 */         Formula formula = FormulaTree.getProp(f);
/*     */ 
/*     */         
/*  70 */         int negation = FormulaTree.getNegation(f);
/*     */         
/*  72 */         if (formula instanceof Proposition) {
/*     */           
/*  74 */           if (formula.op() == 4) {
/*     */             continue label26;
/*     */           }
/*     */           
/*  78 */           negation = FormulaTree.getNegation(f);
/*  79 */           if (oldF.get(q).member(negation)) {
/*     */             continue label26;
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/*  85 */         NonProposition non = (NonProposition)formula;
/*  86 */         switch (formula.op()) { case 16:
/*  87 */             this.nextF.get(q).insert(non.left);
/*     */           
/*     */           case 6:
/*  90 */             and = new FormulaSet();
/*  91 */             and.insert(non.left);
/*  92 */             and.insert(non.right);
/*  93 */             and.diff(q.oldF);
/*  94 */             this.newF.get(q).union(and);
/*     */ 
/*     */ 
/*     */           
/*     */           case 7:
/*     */           case 12:
/*     */           case 13:
/* 101 */             q_ = new BuechiState(++this.idents, new FormulaSet());
/* 102 */             oldF.add(q_, oldF.get(q).copy());
/* 103 */             pred.add(q_, pred.get(q).copy());
/* 104 */             this.nextF.add(q_, this.nextF.get(q).copy());
/* 105 */             this.newF.add(q_, this.newF.get(q).copy());
/*     */             
/* 107 */             h = new1(non);
/* 108 */             h.diff(oldF.get(q));
/* 109 */             this.newF.get(q).union(h);
/*     */             
/* 111 */             h = new2(non);
/*     */             
/* 113 */             h.diff(oldF.get(q_));
/*     */             
/* 115 */             this.newF.get(q_).union(h);
/*     */ 
/*     */             
/* 118 */             this.nextF.get(q_).union(next(f));
/*     */             
/* 120 */             notready.add(q_); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 129 */       ready.add(q);
/*     */     } 
/*     */ 
/*     */     
/* 133 */     putToFinal(ready);
/*     */   }
/* 135 */   public BuechiConstruction(FormulaTree ltl) { this.iterations = 0;
/*     */     this.ltlFormula = ltl;
/*     */     this.idents = 0;
/*     */     this.finalIdents = 1;
/*     */     this.states = new Vector();
/*     */     this.acc = new Vector(); } private void putToFinal(Vector ready) {
/* 141 */     Vector<BuechiState> notready = new Vector();
/* 142 */     for (Iterator<BuechiState> it = ready.iterator(); it.hasNext(); ) {
/* 143 */       boolean b = false;
/* 144 */       BuechiState q = it.next();
/*     */       
/* 146 */       for (Iterator<BuechiState> its = this.states.iterator(); its.hasNext(); ) {
/* 147 */         BuechiState q_ = its.next();
/*     */ 
/*     */         
/* 150 */         if (oldF.get(q).equals(oldF.get(q_)) && this.nextF.get(q).equals(this.nextF.get(q_))) {
/*     */           
/* 152 */           pred.get(q_).union(pred.get(q));
/* 153 */           b = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 162 */       q.oldF = oldF.get(q);
/* 163 */       this.states.add(q);
/*     */ 
/*     */       
/* 166 */       FormulaSet newPred = new FormulaSet();
/* 167 */       newPred.insert(q.ident);
/* 168 */       BuechiState q1 = new BuechiState(++this.idents, new FormulaSet());
/* 169 */       pred.add(q1, newPred);
/* 170 */       this.newF.add(q1, this.nextF.get(q).copy());
/* 171 */       notready.add(q1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     if (!notready.isEmpty()) {
/* 181 */       expand(notready);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void changeIdents(Vector ready) {
/* 190 */     for (Iterator<BuechiState> it = ready.iterator(); it.hasNext(); ) {
/* 191 */       BuechiState act = it.next();
/* 192 */       if (this.finalIdents < act.ident) {
/*     */         
/* 194 */         this.states.remove(act);
/* 195 */         int oldIdent = act.ident;
/*     */         
/* 197 */         act.ident = this.finalIdents;
/* 198 */         this.states.add(act);
/* 199 */         for (Iterator<BuechiState> it2 = ready.iterator(); it2.hasNext(); ) {
/* 200 */           BuechiState toChange = it2.next();
/*     */           
/* 202 */           if (pred.get(toChange).member(oldIdent)) {
/*     */             
/* 204 */             pred.get(toChange).delete(oldIdent);
/* 205 */             pred.get(toChange).insert(this.finalIdents);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 211 */       this.finalIdents++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private FormulaSet new1(NonProposition f) {
/* 216 */     FormulaSet ret = new FormulaSet();
/* 217 */     switch (f.op()) { case 7:
/* 218 */         ret.insert(f.left); break;
/* 219 */       case 12: ret.insert(f.right); break;
/* 220 */       case 13: ret.insert(f.right);
/* 221 */         ret.insert(f.left);
/*     */         break; }
/*     */     
/* 224 */     return ret;
/*     */   }
/*     */   
/*     */   private FormulaSet new2(NonProposition f) {
/* 228 */     FormulaSet ret = new FormulaSet();
/* 229 */     switch (f.op()) { case 7:
/* 230 */         ret.insert(f.right); break;
/* 231 */       case 12: ret.insert(f.left); break;
/* 232 */       case 13: ret.insert(f.right);
/*     */         break; }
/*     */     
/* 235 */     return ret;
/*     */   }
/*     */   
/*     */   private FormulaSet next(int formulaId) {
/* 239 */     FormulaSet ret = new FormulaSet();
/* 240 */     switch (FormulaTree.getProp(formulaId).op()) { case 12:
/*     */       case 13:
/* 242 */         ret.insert(formulaId);
/*     */         break; }
/*     */     
/* 245 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/BuechiConstruction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */