/*     */ package charlie.ltl;
/*     */ 
/*     */ import charlie.ctl.NoPlaceException;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGraph;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ 
/*     */ public class LTL_Main
/*     */ {
/*  12 */   public static String currentFormula = "";
/*     */   public static boolean currentResult = true;
/*  14 */   private static long start = 0L;
/*  15 */   public static StringBuffer out = new StringBuffer();
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkSyntax(StringReader sr) throws Exception, NoPlaceException {
/*     */     try {
/*  21 */       (new parser(new Yylex(sr))).parse();
/*  22 */     } catch (NoPlaceException npe) {
/*  23 */       throw npe;
/*  24 */     } catch (Exception e) {
/*  25 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Path checkFormulae(PlaceTransitionNet pn, RGraph rg, Reader ltl) throws Exception, NoPlaceException {
/*  32 */     Path p = null;
/*  33 */     out = new StringBuffer();
/*  34 */     FormulaTree.reset();
/*  35 */     FormulaTree t = new FormulaTree();
/*     */     try {
/*  37 */       (new parser(new Yylex(ltl))).parse();
/*  38 */     } catch (NoPlaceException npe) {
/*  39 */       throw npe;
/*  40 */     } catch (Exception e) {
/*  41 */       e.printStackTrace();
/*  42 */       throw e;
/*     */     } 
/*  44 */     currentFormula = FormulaTree.formula.toString();
/*  45 */     boolean changed = true;
/*  46 */     boolean result = false;
/*  47 */     out.append("formula: " + currentFormula + "\n");
/*     */     
/*  49 */     FormulaTree.root = FormulaTree.root.negate();
/*  50 */     FormulaTree.init();
/*  51 */     out.append("negation: " + FormulaTree.root + "\n");
/*     */ 
/*     */     
/*  54 */     BuechiConstruction bc = new BuechiConstruction(t);
/*  55 */     BuechiAutomaton ba = bc.construct();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     BuechiDFS dfs = new BuechiDFS(ba, rg, pn);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     BNode accepting = null;
/*     */     
/*  67 */     boolean stop = Options.onTheFly;
/*  68 */     accepting = dfs.dfs(rg.first, 0, stop);
/*  69 */     result = (accepting == null);
/*  70 */     out.append("the formula is: " + result + "\n");
/*     */     
/*  72 */     if (Options.debug) System.out.println("the formula is: " + result); 
/*  73 */     currentResult = result;
/*     */     
/*  75 */     System.out.println("accepting states : " + dfs.getAccepting().size());
/*  76 */     if (accepting != null) {
/*  77 */       accepting = null;
/*     */       
/*  79 */       BNode source = new BNode(rg.first, 0);
/*     */ 
/*     */ 
/*     */       
/*  83 */       ProductAutomaton pa = new ProductAutomaton();
/*  84 */       accepting = dfs.spanningGraphConstruction(source, accepting, pa);
/*  85 */       if (accepting == null) return p; 
/*  86 */       p = new Path(rg.first, rg);
/*  87 */       dfs.pathComputation(pa, (ProductNode)pa.getFirst(), accepting, p);
/*     */ 
/*     */       
/*  90 */       pa = new ProductAutomaton();
/*  91 */       accepting = dfs.spanningGraphConstruction(accepting, accepting, pa);
/*  92 */       if (accepting == null) return p;
/*     */       
/*  94 */       Path path2 = new Path(accepting.node, rg);
/*  95 */       if (pa != null) dfs.pathComputation(pa, (ProductNode)pa.getFirst(), accepting, path2);
/*     */       
/*  97 */       out.append("counter example:\n" + p.edgesToString() + " ( " + path2.edgesToString() + " )\n");
/*     */ 
/*     */ 
/*     */       
/* 101 */       p.appendPath(path2);
/*     */     } 
/*     */     
/* 104 */     System.gc();
/* 105 */     return p;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/LTL_Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */