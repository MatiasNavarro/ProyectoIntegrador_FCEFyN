/*    */ package charlie.ltl;
/*    */ 
/*    */ import charlie.pn.Marking;
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ class BuechiErrorTransition
/*    */   extends BTransition {
/*    */   Vector conditions;
/*    */   
/*    */   public BuechiErrorTransition(int src, int ident) {
/* 12 */     super(src, ident);
/* 13 */     this.conditions = new Vector();
/*    */   }
/*    */   
/*    */   public boolean checkConditions(Marking m) {
/* 17 */     for (Iterator<Condition> it = this.conditions.iterator(); it.hasNext(); ) {
/* 18 */       Condition c = it.next();
/*    */       
/* 20 */       if (c.isSatisfied(m) == true) {
/* 21 */         return false;
/*    */       }
/*    */     } 
/* 24 */     return true;
/*    */   }
/*    */   
/*    */   public void addCondition(Condition c) {
/* 28 */     this.conditions.add(c);
/*    */   }
/*    */ 
/*    */   
/*    */   public int fire(int src, Marking mpn) {
/* 33 */     if (!checkConditions(mpn)) return -1; 
/* 34 */     if (src == this.src) return this.ident; 
/* 35 */     return -1;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/BuechiErrorTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */