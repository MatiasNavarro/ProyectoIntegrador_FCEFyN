package charlie.ltl;

import charlie.rg.RGEdge;

class ProductEdgeInfo {
  RGEdge e;
  
  byte id;
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/ProductEdgeInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */