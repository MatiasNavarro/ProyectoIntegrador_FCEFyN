/*     */ package charlie.ltl;
/*     */ public class FormulaSet {
/*     */   private Node first;
/*     */   int size;
/*     */   
/*     */   private class Node {
/*     */     Node next;
/*     */     
/*     */     Node(int c, Node n) {
/*  10 */       this.content = c;
/*  11 */       this.next = n;
/*     */     }
/*     */     int content;
/*     */     Node copy() {
/*  15 */       return new Node(this.content, this.next);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FormulaSet() {
/*  22 */     this.first = new Node(-1, null);
/*  23 */     this.size = 0;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  27 */     this.size = 0;
/*  28 */     this.first = new Node(-1, null);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  32 */     return (this.size == 0);
/*     */   }
/*     */   
/*     */   public boolean equals(FormulaSet fs) {
/*  36 */     if (this.size != fs.size) return false; 
/*  37 */     Node cur1 = this.first;
/*  38 */     Node cur2 = fs.first;
/*  39 */     while (cur1.next != null) {
/*  40 */       if (cur1.next.content != cur2.next.content) return false; 
/*  41 */       cur1 = cur1.next;
/*  42 */       cur2 = cur2.next;
/*     */     } 
/*  44 */     return true;
/*     */   }
/*     */   
/*     */   public Iterator iterator() {
/*  48 */     return new FSIterator();
/*     */   }
/*     */   
/*     */   public void insert(int i) {
/*  52 */     Node current = this.first;
/*  53 */     while (current.next != null) {
/*  54 */       if (current.next.content < i) {
/*  55 */         current = current.next; continue;
/*  56 */       }  if (current.next.content > i) {
/*     */         break;
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*  62 */     Node n = new Node(i, current.next);
/*  63 */     current.next = n;
/*  64 */     this.size++;
/*     */   }
/*     */   
/*     */   public int first() {
/*  68 */     if (isEmpty()) return -1; 
/*  69 */     int ret = this.first.next.content;
/*  70 */     this.first.next = this.first.next.next;
/*  71 */     this.size--;
/*  72 */     return ret;
/*     */   }
/*     */   
/*     */   public void delete(int i) {
/*  76 */     Node current = this.first;
/*  77 */     while (current.next != null) {
/*  78 */       if (current.next.content < i) {
/*  79 */         current = current.next; continue;
/*  80 */       }  if (current.next.content == i) {
/*  81 */         current.next = current.next.next;
/*  82 */         this.size--;
/*     */         continue;
/*     */       } 
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean member(int i) {
/*  90 */     Node current = this.first;
/*  91 */     while (current.next != null) {
/*  92 */       if (current.next.content < i) {
/*  93 */         current = current.next; continue;
/*  94 */       }  if (current.next.content == i) {
/*  95 */         return true;
/*     */       }
/*  97 */       return false;
/*     */     } 
/*     */     
/* 100 */     return false;
/*     */   }
/*     */   
/*     */   public FormulaSet intersection(FormulaSet s2) {
/* 104 */     FormulaSet intersection = new FormulaSet();
/* 105 */     if (isEmpty() || s2.isEmpty()) return intersection; 
/* 106 */     Node cur = intersection.first;
/* 107 */     Node cur1 = this.first;
/* 108 */     Node cur2 = s2.first;
/* 109 */     while (cur1.next != null && cur2.next != null) {
/* 110 */       int c = cur1.next.content;
/* 111 */       while (cur2.next != null) {
/* 112 */         if (cur2.next.content == c) {
/* 113 */           cur.next = new Node(c, cur.next);
/* 114 */           intersection.size++;
/* 115 */           cur = cur.next;
/* 116 */           cur2 = cur2.next;
/* 117 */           cur1 = cur1.next;
/*     */           break;
/*     */         } 
/* 120 */         if (cur2.next.content < c) {
/* 121 */           cur2 = cur2.next; continue;
/*     */         } 
/* 123 */         cur1 = cur1.next;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 128 */     return intersection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void union(FormulaSet fs) {
/* 135 */     Node cur = this.first;
/* 136 */     Node cur2 = fs.first;
/* 137 */     label18: while (cur2.next != null) {
/* 138 */       int c = cur2.next.content;
/* 139 */       while (cur.next != null) {
/* 140 */         if (cur.next.content == c) {
/* 141 */           cur2 = cur2.next;
/*     */           continue label18;
/*     */         } 
/* 144 */         if (cur.next.content < c) {
/* 145 */           cur = cur.next; continue;
/*     */         } 
/* 147 */         Node node = new Node(c, cur.next);
/*     */         
/* 149 */         cur.next = node;
/* 150 */         cur2 = cur2.next;
/* 151 */         this.size++;
/*     */       } 
/*     */ 
/*     */       
/* 155 */       Node n = new Node(c, cur.next);
/* 156 */       cur.next = n;
/* 157 */       cur2 = cur2.next;
/* 158 */       this.size++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean subSet(FormulaSet fs) {
/* 164 */     Node cur = this.first;
/* 165 */     Node cur2 = fs.first;
/* 166 */     label19: while (cur.next != null) {
/* 167 */       int c = cur.next.content;
/* 168 */       while (cur2.next != null) {
/* 169 */         if (cur2.next.content == c) {
/* 170 */           cur = cur.next;
/* 171 */           cur2 = cur2.next;
/*     */           
/*     */           continue label19;
/*     */         } 
/* 175 */         if (cur2.next.content < c) {
/* 176 */           cur2 = cur2.next; continue;
/*     */         } 
/* 178 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 182 */       if (cur.next != null) return false; 
/* 183 */       cur = cur.next;
/*     */     } 
/* 185 */     return true;
/*     */   }
/*     */   
/*     */   public void diff(FormulaSet fs) {
/* 189 */     Node cur = this.first;
/* 190 */     Node cur2 = fs.first;
/* 191 */     label18: while (cur.next != null) {
/* 192 */       int c = cur.next.content;
/* 193 */       while (cur2.next != null) {
/* 194 */         if (cur2.next.content == c) {
/* 195 */           cur.next = cur.next.next;
/* 196 */           cur2 = cur2.next;
/* 197 */           this.size--;
/*     */           continue label18;
/*     */         } 
/* 200 */         if (cur2.next.content < c) {
/* 201 */           cur2 = cur2.next; continue;
/*     */         } 
/* 203 */         cur = cur.next;
/*     */       } 
/*     */ 
/*     */       
/* 207 */       cur = cur.next;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 215 */     String ret = "(";
/* 216 */     Node cur = this.first;
/* 217 */     while (cur.next != null) {
/* 218 */       ret = ret + cur.next.content;
/* 219 */       cur = cur.next;
/* 220 */       if (cur.next != null) ret = ret + " , ";
/*     */     
/*     */     } 
/* 223 */     ret = ret + ") ";
/* 224 */     return ret;
/*     */   }
/*     */   
/*     */   public FormulaSet copy() {
/* 228 */     FormulaSet ret = new FormulaSet();
/* 229 */     Node cur2 = ret.first;
/* 230 */     Node cur = this.first;
/* 231 */     while (cur.next != null) {
/* 232 */       cur2.next = cur.next.copy();
/* 233 */       cur2 = cur2.next;
/* 234 */       cur = cur.next;
/*     */     } 
/* 236 */     ret.size = this.size;
/* 237 */     return ret;
/*     */   }
/*     */   
/*     */   class FSIterator
/*     */     implements Iterator
/*     */   {
/* 243 */     FormulaSet.Node current = FormulaSet.this.first.next;
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 247 */       return (this.current != null);
/*     */     }
/*     */     
/*     */     public Object next() {
/* 251 */       if (hasNext()) {
/* 252 */         Integer ret = new Integer(this.current.content);
/* 253 */         this.current = this.current.next;
/* 254 */         return ret;
/*     */       } 
/* 256 */       return null;
/*     */     }
/*     */     
/*     */     public void remove() {}
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/FormulaSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */