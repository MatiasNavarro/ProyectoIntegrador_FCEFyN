package charlie.ltl;

import charlie.pn.Marking;

public interface Condition {
  boolean isSatisfied(Marking paramMarking);
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/Condition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */