/*    */ package charlie.ltl;
/*    */ 
/*    */ 
/*    */ 
/*    */ class Leaf
/*    */   extends Node
/*    */ {
/*    */   int prop;
/*    */   int id;
/*    */   
/*    */   public Leaf(int p) {
/* 12 */     this.id = 0;
/*    */     this.prop = p;
/*    */     FormulaTree.nodes++; } public void setId(int id) {
/* 15 */     this.id = id;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 21 */     return FormulaTree.getProp(this.prop).toString();
/*    */   }
/*    */   
/*    */   public Node left() {
/* 25 */     return null;
/*    */   }
/*    */   
/*    */   public Node right() {
/* 29 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getId() {
/* 34 */     return this.id;
/*    */   }
/*    */   
/*    */   public int formulaId() {
/* 38 */     return this.prop;
/*    */   }
/*    */   
/*    */   public void setRight(Node n) {}
/*    */   
/*    */   public void setLeft(Node n) {}
/*    */   
/*    */   public Node copy() {
/* 46 */     return new Leaf(this.prop);
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 50 */     if (!(obj instanceof Leaf)) return false; 
/* 51 */     return (this.prop == ((Leaf)obj).prop);
/*    */   }
/*    */   
/*    */   public Node negate() {
/* 55 */     return new Leaf(FormulaTree.getNegation(formulaId()));
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/Leaf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */