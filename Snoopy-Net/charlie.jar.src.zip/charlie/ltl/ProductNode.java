/*    */ package charlie.ltl;
/*    */ 
/*    */ import charlie.pn.Edge;
/*    */ import charlie.pn.Vertex;
/*    */ 
/*    */ class ProductNode
/*    */   extends Vertex {
/*    */   int num;
/*  9 */   int pos = -1; BNode bn; int low;
/*    */   ProductNode(BNode bn, int num) {
/* 11 */     super(bn);
/* 12 */     this.bn = bn;
/* 13 */     this.num = num;
/* 14 */     this.low = num;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNum() {
/* 19 */     return this.num;
/*    */   }
/*    */   
/*    */   public int getLow() {
/* 23 */     return this.low;
/*    */   }
/*    */   
/*    */   public BNode getBN() {
/* 27 */     return this.bn;
/*    */   }
/*    */   
/*    */   public void setLow(int low) {
/* 31 */     this.low = low;
/*    */   }
/*    */   
/*    */   public void setNum(int num) {
/* 35 */     this.num = num;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 39 */     ProductNode p = (ProductNode)obj;
/* 40 */     return this.bn.equals(p.bn);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 44 */     return this.bn.hashCode();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 48 */     System.out.println("ProductNode.toString()");
/* 49 */     return "ProductNode.toString()";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasEdgetoHimself() {
/* 54 */     Edge out = out();
/* 55 */     while (out != null) {
/* 56 */       if (out.node().equals(this)) return true; 
/* 57 */       out = out.next();
/*    */     } 
/* 59 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/ProductNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */