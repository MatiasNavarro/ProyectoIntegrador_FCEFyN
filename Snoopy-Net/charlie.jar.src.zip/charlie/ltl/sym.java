package charlie.ltl;

public class sym {
  public static final int RELEASES = 13;
  
  public static final int IMPLIEDBY = 10;
  
  public static final int AND = 6;
  
  public static final int LT = 21;
  
  public static final int NE = 17;
  
  public static final int RPAREN = 24;
  
  public static final int OR = 7;
  
  public static final int EQUAL = 22;
  
  public static final int SEMI = 2;
  
  public static final int NOT = 5;
  
  public static final int LPAREN1 = 25;
  
  public static final int TRUE = 3;
  
  public static final int IMPLIES = 9;
  
  public static final int LPAREN = 23;
  
  public static final int GT = 20;
  
  public static final int LE = 18;
  
  public static final int STRING = 28;
  
  public static final int GLOBALLY = 15;
  
  public static final int FINALY = 14;
  
  public static final int NUMBER = 27;
  
  public static final int EOF = 0;
  
  public static final int GE = 19;
  
  public static final int FALSE = 4;
  
  public static final int error = 1;
  
  public static final int IFF = 11;
  
  public static final int UNTIL = 12;
  
  public static final int XOR = 8;
  
  public static final int RPAREN1 = 26;
  
  public static final int NEXT = 16;
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/sym.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */