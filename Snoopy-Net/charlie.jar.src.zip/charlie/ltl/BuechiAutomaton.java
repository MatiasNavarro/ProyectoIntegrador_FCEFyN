/*     */ package charlie.ltl;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ class BuechiAutomaton {
/*     */   HashMap states;
/*  10 */   int accsizeVBA = 1; Vector acc; Vector transitions;
/*     */   FormulaTree ltlFormula;
/*  12 */   FormulaTable oldF = BuechiConstruction.oldF;
/*  13 */   FormulaTable pred = BuechiConstruction.pred;
/*     */   public BuechiAutomaton() {
/*  15 */     this.states = new HashMap<>();
/*     */     
/*  17 */     this.transitions = new Vector();
/*     */   }
/*     */ 
/*     */   
/*     */   public void isAccepting(int m, Vector<FormulaSet> acc) {
/*  22 */     for (int i = 0; i < this.acc.size(); i++) {
/*  23 */       if (((FormulaSet)this.acc.get(i)).member(m)) {
/*  24 */         ((FormulaSet)acc.get(i)).insert(m);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAccepting(int m) {
/*  33 */     if ((getState(m)).accepting) return true;
/*     */     
/*  35 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void reduce() {
/*  44 */     int oldsize = this.states.size();
/*  45 */     if (Options.debug) System.out.println("states before: " + this.states.size());
/*     */     
/*  47 */     HashSet<BuechiState> toDelete = new HashSet();
/*     */     
/*  49 */     for (int h = 1; h < oldsize; h++) {
/*  50 */       BuechiState del = null;
/*  51 */       BuechiState preserv = null;
/*  52 */       BuechiState current = (BuechiState)this.states.get(new Integer(h));
/*  53 */       if (current != null) {
/*  54 */         int j; label95: for (j = 1; j < oldsize; j++) {
/*  55 */           BuechiState compare = (BuechiState)this.states.get(new Integer(j));
/*  56 */           if (compare != null && 
/*  57 */             current.ident != compare.ident) {
/*     */             
/*  59 */             if (this.oldF.get(current).subSet(this.oldF.get(compare))) {
/*  60 */               del = compare;
/*  61 */               preserv = current;
/*  62 */             } else if (this.oldF.get(compare).subSet(this.oldF.get(current))) {
/*  63 */               del = current;
/*  64 */               preserv = compare;
/*  65 */             } else if (this.oldF.get(compare).equals(this.oldF.get(current))) {
/*  66 */               if (current.ident > compare.ident) {
/*  67 */                 del = current;
/*  68 */                 preserv = compare;
/*  69 */               } else if (current.ident < compare.ident) {
/*  70 */                 del = compare;
/*  71 */                 preserv = current;
/*     */               } 
/*     */             } 
/*  74 */             if (del != null && 
/*  75 */               del.ident != 0) {
/*     */               
/*  77 */               for (Iterator<FormulaSet> it3 = this.acc.iterator(); it3.hasNext(); ) {
/*  78 */                 FormulaSet f = it3.next();
/*  79 */                 if (f.member(current.ident) && !f.member(compare.ident)) {
/*     */                   continue label95;
/*     */                 }
/*     */                 
/*  83 */                 if (!f.member(current.ident) && f.member(compare.ident)) {
/*     */                   continue label95;
/*     */                 }
/*     */               } 
/*     */ 
/*     */               
/*  89 */               FormulaSet f1 = new FormulaSet();
/*  90 */               FormulaSet f2 = new FormulaSet();
/*  91 */               for (Iterator<BuechiTransition> iterator1 = current.transitions.iterator(); iterator1.hasNext(); ) {
/*  92 */                 BuechiTransition t = iterator1.next();
/*  93 */                 f1.insert(t.ident);
/*     */               } 
/*  95 */               for (Iterator<BuechiTransition> it4 = compare.transitions.iterator(); it4.hasNext(); ) {
/*  96 */                 BuechiTransition t = it4.next();
/*  97 */                 f2.insert(t.ident);
/*     */               } 
/*     */ 
/*     */               
/* 101 */               if (f1.equals(f2)) {
/*     */ 
/*     */                 
/* 104 */                 if (Options.debug) System.out.println("del: " + del.ident + " preserv: " + preserv.ident);
/*     */                 
/* 106 */                 toDelete.add(del);
/* 107 */                 for (Iterator<BuechiState> it5 = this.states.values().iterator(); it5.hasNext(); ) {
/* 108 */                   BuechiState cur = it5.next();
/* 109 */                   boolean preservFound = false;
/* 110 */                   boolean delFound = false;
/* 111 */                   for (int i = 0; i < cur.transitions.size(); i++) {
/* 112 */                     BuechiTransition t = cur.transitions.get(i);
/* 113 */                     if (t.ident == del.ident) {
/* 114 */                       if (preservFound) {
/* 115 */                         cur.transitions.remove(t);
/*     */                       } else {
/* 117 */                         t.ident = preserv.ident;
/* 118 */                         preservFound = true;
/*     */                       } 
/* 120 */                       delFound = true;
/* 121 */                     } else if (t.ident == preserv.ident) {
/* 122 */                       if (preservFound) {
/* 123 */                         cur.transitions.remove(t);
/*     */                       } else {
/* 125 */                         preservFound = true;
/*     */                       } 
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */ 
/*     */                 
/* 132 */                 for (Iterator<FormulaSet> iterator = this.acc.iterator(); iterator.hasNext(); ) {
/* 133 */                   FormulaSet f = iterator.next();
/* 134 */                   if (f.member(del.ident)) {
/* 135 */                     f.delete(del.ident);
/* 136 */                     f.insert(preserv.ident);
/*     */                   } 
/*     */                 } 
/*     */                 
/* 140 */                 this.states.remove(new Integer(del.ident));
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 150 */     if (Options.debug) System.out.println("states after: " + this.states.size());
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BuechiAutomaton(Vector states, FormulaTree ltl) {
/* 162 */     this.states = new HashMap<>();
/* 163 */     this.ltlFormula = ltl;
/*     */     
/* 165 */     this.transitions = new Vector();
/*     */     
/* 167 */     if (Options.debug) System.out.println("constructing automaton"); 
/* 168 */     Vector h = changeIdents(states);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     for (Iterator<BuechiState> iterator1 = h.iterator(); iterator1.hasNext(); ) {
/* 175 */       BuechiState q = iterator1.next();
/*     */       
/* 177 */       addState(q, this.pred.get(q));
/*     */     } 
/* 179 */     for (Iterator<BuechiState> it = h.iterator(); it.hasNext(); ) {
/* 180 */       BuechiState q = it.next();
/*     */ 
/*     */       
/* 183 */       while (!this.pred.get(q).isEmpty()) {
/* 184 */         int p = this.pred.get(q).first();
/* 185 */         addTransition(p, q.ident);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addState(BuechiState state, FormulaSet pred) {
/* 192 */     this.states.put(new Integer(state.ident), state);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Vector changeIdents(Vector ready) {
/* 198 */     int finalIdents = 0;
/* 199 */     Vector<BuechiState> states = new Vector();
/* 200 */     Vector help = new Vector();
/* 201 */     help.addAll(ready);
/* 202 */     for (Iterator<BuechiState> it = help.iterator(); it.hasNext(); ) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 208 */       BuechiState act = it.next();
/* 209 */       if (finalIdents < act.ident) {
/*     */         
/* 211 */         states.remove(act);
/* 212 */         int oldIdent = act.ident;
/* 213 */         if (this.pred.get(act).member(act.ident)) {
/*     */           
/* 215 */           this.pred.get(act).delete(act.ident);
/* 216 */           this.pred.get(act).insert(finalIdents);
/*     */         } 
/*     */         
/* 219 */         act.ident = finalIdents;
/* 220 */         states.add(act);
/* 221 */         for (Iterator<BuechiState> it2 = help.iterator(); it2.hasNext(); ) {
/* 222 */           BuechiState toChange = it2.next();
/*     */           
/* 224 */           if (this.pred.get(toChange).member(oldIdent))
/*     */           {
/* 226 */             this.pred.get(toChange).delete(oldIdent);
/* 227 */             this.pred.get(toChange).insert(finalIdents);
/*     */           }
/*     */         
/*     */         } 
/*     */       } else {
/*     */         
/* 233 */         states.add(act);
/*     */       } 
/* 235 */       finalIdents++;
/*     */     } 
/* 237 */     return states;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAcceptingStates(Vector acc) {
/* 243 */     this.acc = acc;
/*     */   }
/*     */   public int size() {
/* 246 */     return this.states.size();
/*     */   }
/*     */   
/*     */   public BuechiState getState(int ident) {
/* 250 */     return (BuechiState)this.states.get(new Integer(ident));
/*     */   }
/*     */ 
/*     */   
/*     */   private void addTransition(int from, int to) {
/* 255 */     BuechiState state = (BuechiState)this.states.get(new Integer(from));
/* 256 */     BuechiState toState = (BuechiState)this.states.get(new Integer(to));
/*     */     
/* 258 */     BuechiTransition t = new BuechiTransition(from, to, getPropositions(toState));
/*     */     
/* 260 */     for (Iterator<Integer> itcond = t.formulae.iterator(); itcond.hasNext();) {
/* 261 */       t.addCondition((Proposition)FormulaTree.getProp(((Integer)itcond.next()).intValue()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 266 */     state.addTransition(t);
/* 267 */     this.transitions.add(t);
/*     */   }
/*     */   
/*     */   public BTransition getTransition(int i) {
/* 271 */     return this.transitions.get(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public int transitions() {
/* 276 */     return this.transitions.size();
/*     */   }
/*     */   
/*     */   private void addTransition(int from, int to, Vector formulae) {
/* 280 */     BuechiState state = (BuechiState)this.states.get(new Integer(from));
/* 281 */     BuechiState toState = (BuechiState)this.states.get(new Integer(to));
/* 282 */     BuechiErrorTransition t = new BuechiErrorTransition(from, to);
/* 283 */     ExtendendCondition ec = new ExtendendCondition();
/* 284 */     for (Iterator<FormulaSet> itecond = formulae.iterator(); itecond.hasNext(); ) {
/* 285 */       FormulaSet f = itecond.next();
/* 286 */       for (Iterator<Integer> itcond = f.iterator(); itcond.hasNext();) {
/* 287 */         ec.addCondition((Proposition)FormulaTree.getProp(((Integer)itcond.next()).intValue()));
/*     */       }
/* 289 */       t.addCondition(ec);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 294 */     state.addTransition(t);
/* 295 */     this.transitions.add(t);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 299 */     String ret = "Buechiautomaton:\n";
/* 300 */     for (Iterator<BuechiState> it = this.states.values().iterator(); it.hasNext();) {
/* 301 */       ret = ret + ((BuechiState)it.next()).getString(this.ltlFormula) + "\n";
/*     */     }
/* 303 */     ret = ret + "F: ";
/* 304 */     ret = ret + this.acc;
/* 305 */     return ret;
/*     */   }
/*     */   
/*     */   private FormulaSet acc_(int pUq, int q) {
/* 309 */     FormulaSet ret = new FormulaSet();
/* 310 */     for (Iterator<BuechiState> it = this.states.values().iterator(); it.hasNext(); ) {
/* 311 */       BuechiState bs = it.next();
/* 312 */       if (bs.ident != 0 && (bs.oldF.member(q) || !bs.oldF.member(pUq))) {
/* 313 */         ret.insert(bs.ident);
/*     */       }
/*     */     } 
/* 316 */     return ret;
/*     */   }
/*     */   
/*     */   public FormulaSet getPropositions(BuechiState bs) {
/* 320 */     FormulaSet ret = new FormulaSet();
/*     */     
/* 322 */     for (Iterator<Integer> it = bs.oldF.iterator(); it.hasNext(); ) {
/* 323 */       int formula = ((Integer)it.next()).intValue();
/* 324 */       Formula f = FormulaTree.getProp(formula);
/* 325 */       if (f instanceof Proposition && f.op() != 3) {
/* 326 */         ret.insert(formula);
/*     */       }
/*     */     } 
/* 329 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptingStateSet(FormulaTree ltl) {
/* 335 */     this.acc = new Vector();
/* 336 */     for (int i = 0; i < FormulaTree.nodeList.length; i++) {
/* 337 */       int op = FormulaTree.nodeList[i].formulaId();
/* 338 */       Formula f = FormulaTree.getProp(op);
/* 339 */       if (f.op() == 12) {
/* 340 */         this.acc.add(acc_(op, ((NonProposition)FormulaTree.getProp(op)).right));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BuechiAutomaton getUBA() {
/* 350 */     BuechiAutomaton uba = new BuechiAutomaton();
/* 351 */     uba.ltlFormula = this.ltlFormula;
/*     */     
/* 353 */     uba.accsizeVBA = this.acc.size();
/*     */     
/* 355 */     if (this.acc.size() > 1) {
/* 356 */       if (Options.debug) System.out.println("states: " + this.states.size()); 
/* 357 */       int accSize = this.acc.size();
/* 358 */       int statesSize = this.states.size();
/* 359 */       for (int i = 0; i < accSize * this.states.size(); i++) {
/* 360 */         if (Options.debug) System.out.println("i: " + i + " ident: " + (i % statesSize)); 
/* 361 */         FormulaSet old = this.oldF.get(this.states.get(new Integer(i % statesSize))).copy();
/*     */         
/* 363 */         uba.addState(new BuechiState(i, old), new FormulaSet());
/*     */       } 
/*     */       
/* 366 */       for (Iterator<BuechiState> it = this.states.values().iterator(); it.hasNext(); ) {
/* 367 */         BuechiState from = it.next();
/* 368 */         for (int j = 0; j < accSize; j++) {
/* 369 */           for (Iterator it2 = from.transitions(); it2.hasNext(); ) {
/* 370 */             int to = ((BuechiTransition)it2.next()).ident;
/* 371 */             if (((FormulaSet)this.acc.get(j)).member(from.ident)) {
/* 372 */               uba.addTransition(from.ident + j * statesSize, to + (j + 1) % accSize * statesSize);
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 377 */             uba.addTransition(from.ident + j * statesSize, to + j * statesSize);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 382 */       uba.acc = new Vector();
/* 383 */       uba.acc.add(this.acc.get(0));
/*     */     } else {
/*     */       
/* 386 */       uba = this;
/*     */     } 
/*     */     
/* 389 */     if (this.acc.isEmpty()) {
/* 390 */       FormulaSet accepting = new FormulaSet();
/* 391 */       for (Iterator<BuechiState> it = uba.states.values().iterator(); it.hasNext(); ) {
/* 392 */         BuechiState cur = it.next();
/* 393 */         cur.accepting = true;
/* 394 */         accepting.insert(cur.ident);
/*     */       } 
/*     */ 
/*     */       
/* 398 */       uba.acc.add(accepting);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 421 */       FormulaSet accepting = new FormulaSet();
/* 422 */       if (!uba.acc.isEmpty()) {
/* 423 */         accepting = uba.acc.get(0);
/*     */       }
/* 425 */       for (Iterator<BuechiState> it = uba.states.values().iterator(); it.hasNext(); ) {
/* 426 */         BuechiState act = it.next();
/* 427 */         if (accepting.member(act.ident)) {
/* 428 */           act.accepting = true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 435 */     if (Options.debug) System.out.println("uba: " + uba);
/*     */ 
/*     */     
/* 438 */     return uba;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void changeIdents() {
/* 446 */     for (int i = 0; i < this.states.size(); i++) {
/*     */       
/* 448 */       BuechiState cur = (BuechiState)this.states.get(new Integer(i));
/* 449 */       if (cur == null) {
/* 450 */         int h = i;
/* 451 */         while (cur == null) {
/* 452 */           h++;
/* 453 */           cur = (BuechiState)this.states.get(new Integer(h));
/*     */         } 
/* 455 */         if (cur != null) {
/*     */           
/* 457 */           this.states.remove(new Integer(h));
/* 458 */           if (Options.debug) System.out.println("change: " + cur.ident + " to " + i); 
/* 459 */           cur.ident = i;
/* 460 */           this.states.put(new Integer(i), cur);
/* 461 */           for (Iterator<BuechiState> it = this.states.values().iterator(); it.hasNext(); ) {
/* 462 */             BuechiState cur2 = it.next();
/*     */             
/* 464 */             for (Iterator<BuechiTransition> it2 = cur2.transitions.iterator(); it2.hasNext(); ) {
/* 465 */               BuechiTransition t = it2.next();
/*     */               
/* 467 */               if (t.ident == h) {
/* 468 */                 t.ident = i;
/*     */               }
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 474 */           for (Iterator<FormulaSet> it3 = this.acc.iterator(); it3.hasNext(); ) {
/* 475 */             FormulaSet f = it3.next();
/* 476 */             if (f.member(h)) {
/* 477 */               f.delete(h);
/* 478 */               f.insert(i);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/BuechiAutomaton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */