/*   */ package charlie.ltl;
/*   */ 
/*   */ abstract class Node {
/*   */   boolean negate = false;
/*   */   
/*   */   public abstract Node right();
/*   */   
/*   */   public abstract Node left();
/*   */   
/*   */   public abstract void setRight(Node paramNode);
/*   */   
/*   */   public abstract void setLeft(Node paramNode);
/*   */   
/*   */   public abstract String toString();
/*   */   
/*   */   public abstract void setId(int paramInt);
/*   */   
/*   */   public abstract int getId();
/*   */   
/*   */   public abstract int formulaId();
/*   */   
/*   */   public abstract Node negate();
/*   */   
/*   */   public abstract Node copy();
/*   */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ltl/Node.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */