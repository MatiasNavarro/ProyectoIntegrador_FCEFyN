/*    */ package charlie.util;
/*    */ 
/*    */ import GUI.IDirector;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DirectorManager
/*    */ {
/* 15 */   private static final List<IDirector> directorList = new ArrayList<>();
/*    */   
/*    */   public static synchronized void registerDirector(IDirector _director) {
/* 18 */     directorList.add(_director);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean sendMessage(Class<? extends IDirector> _directorClass, int _messageType, Object _source, Object _object) {
/* 33 */     boolean ret = true;
/*    */     
/* 35 */     for (IDirector director : directorList) {
/* 36 */       Class<?>[] directorInterfaceArray = director.getClass().getInterfaces();
/*    */       
/* 38 */       for (Class<?> directorInterface : directorInterfaceArray) {
/* 39 */         if (directorInterface.isAssignableFrom(_directorClass)) {
/* 40 */           synchronized (directorList) {
/* 41 */             ret = (ret && director.sendMessage(_messageType, _source, _object));
/*    */           } 
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 47 */     return ret;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<Object> sendExternalMessage(Class<? extends IDirector> _directorClass, int _messageType, Object _source, Object _object) {
/* 61 */     List<Object> ret = new ArrayList();
/*    */     
/* 63 */     for (IDirector director : directorList) {
/* 64 */       Class<?>[] directorInterfaceArray = director.getClass().getInterfaces();
/*    */       
/* 66 */       for (Class<?> directorInterface : directorInterfaceArray) {
/* 67 */         if (directorInterface.isAssignableFrom(_directorClass)) {
/* 68 */           synchronized (directorList) {
/* 69 */             ret.add(director.externalMessage(_messageType, _source, _object));
/*    */           } 
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 75 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/DirectorManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */