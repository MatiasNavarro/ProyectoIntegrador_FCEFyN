package charlie.util;

public interface IProtocol {
  void print(Object paramObject);
  
  void println(Object paramObject);
  
  void errPrint(Object paramObject);
  
  void errPrintln(Object paramObject);
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/IProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */