/*    */ package charlie.util;
/*    */ 
/*    */ import GUI.ConsoleWindow;
/*    */ 
/*    */ public class ConsoleWindowProtocol
/*    */   implements IProtocol
/*    */ {
/*    */   public void print(Object _o) {
/*  9 */     if (_o != null) {
/* 10 */       ConsoleWindow.append(_o.toString(), true);
/*    */     } else {
/* 12 */       ConsoleWindow.append("null", true);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void println(Object _o) {
/* 18 */     if (_o != null) {
/* 19 */       ConsoleWindow.append(_o.toString() + "\n", true);
/*    */     } else {
/* 21 */       ConsoleWindow.append("null", true);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void errPrint(Object _o) {
/* 27 */     if (_o != null) {
/* 28 */       ConsoleWindow.append(_o.toString(), true);
/*    */     } else {
/* 30 */       ConsoleWindow.append("null", true);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void errPrintln(Object _o) {
/* 36 */     if (_o != null) {
/* 37 */       ConsoleWindow.append(_o.toString() + "\n", true);
/*    */     } else {
/* 39 */       ConsoleWindow.append("null", true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/ConsoleWindowProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */