/*    */ package charlie.util.arithmetic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Literal
/*    */   extends TerminalExpr
/*    */ {
/*    */   protected Number value;
/*    */   
/*    */   public Literal(Number val) {
/* 14 */     this.value = val;
/*    */   }
/*    */   
/*    */   public Literal(Literal other) {
/* 18 */     this.value = other.value;
/*    */   }
/*    */   
/*    */   public Number eval(ArgumentExpr args) {
/* 22 */     return this.value;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 26 */     return "" + this.value;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/arithmetic/Literal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */