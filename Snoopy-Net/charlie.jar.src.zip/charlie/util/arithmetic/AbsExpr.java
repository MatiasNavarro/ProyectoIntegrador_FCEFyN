/*    */ package charlie.util.arithmetic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AbsExpr
/*    */   extends NonTerminalExpr
/*    */ {
/*    */   public AbsExpr(AbstractExpr e) {
/* 12 */     this.exprs.add(e);
/*    */   }
/*    */   
/*    */   public Number eval(ArgumentExpr args) {
/* 16 */     Number arg = ((AbstractExpr)this.exprs.get(0)).eval(args);
/* 17 */     if (arg instanceof Double) {
/* 18 */       return Double.valueOf(Math.abs(arg.doubleValue()));
/*    */     }
/* 20 */     if (arg instanceof Float) {
/* 21 */       return Float.valueOf(Math.abs(arg.floatValue()));
/*    */     }
/* 23 */     if (arg instanceof Long) {
/* 24 */       return Long.valueOf(Math.abs(arg.longValue()));
/*    */     }
/* 26 */     if (arg instanceof Integer) {
/* 27 */       return Integer.valueOf(Math.abs(arg.intValue()));
/*    */     }
/* 29 */     if (arg instanceof Short) {
/* 30 */       return Integer.valueOf(Math.abs(arg.shortValue()));
/*    */     }
/* 32 */     if (arg instanceof Byte) {
/* 33 */       return Integer.valueOf(Math.abs(arg.byteValue()));
/*    */     }
/*    */     
/* 36 */     throw new RuntimeException("unknown type");
/*    */   }
/*    */   
/*    */   public String toString() {
/* 40 */     return "abs(" + ((AbstractExpr)this.exprs.get(0)).toString() + ")";
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/arithmetic/AbsExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */