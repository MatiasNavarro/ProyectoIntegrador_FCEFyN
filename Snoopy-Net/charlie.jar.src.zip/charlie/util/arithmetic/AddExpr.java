/*    */ package charlie.util.arithmetic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AddExpr
/*    */   extends NonTerminalExpr
/*    */ {
/*    */   public AddExpr(AbstractExpr l, AbstractExpr r) {
/* 12 */     this.exprs.add(l);
/* 13 */     this.exprs.add(r);
/*    */   }
/*    */   
/*    */   public AddExpr(AddExpr other) {
/* 17 */     super(other);
/*    */   }
/*    */   
/*    */   public Number eval(ArgumentExpr args) {
/* 21 */     Number argL = ((AbstractExpr)this.exprs.get(0)).eval(args);
/* 22 */     Number argR = ((AbstractExpr)this.exprs.get(1)).eval(args);
/* 23 */     if (argL instanceof Double || argR instanceof Double) {
/* 24 */       return Double.valueOf(argL.doubleValue() + argR.doubleValue());
/*    */     }
/* 26 */     if (argL instanceof Float || argR instanceof Float) {
/* 27 */       return Float.valueOf(argL.floatValue() + argR.floatValue());
/*    */     }
/* 29 */     if (argL instanceof Long || argR instanceof Long) {
/* 30 */       return Long.valueOf(argL.longValue() + argR.longValue());
/*    */     }
/* 32 */     if (argL instanceof Integer || argR instanceof Integer) {
/* 33 */       return Integer.valueOf(argL.intValue() + argR.intValue());
/*    */     }
/* 35 */     if (argL instanceof Short || argR instanceof Short) {
/* 36 */       return Integer.valueOf(argL.shortValue() + argR.shortValue());
/*    */     }
/* 38 */     if (argL instanceof Byte || argR instanceof Byte) {
/* 39 */       return Integer.valueOf(argL.byteValue() + argR.byteValue());
/*    */     }
/*    */     
/* 42 */     throw new RuntimeException("unknown type");
/*    */   }
/*    */   
/*    */   public String toString() {
/* 46 */     return "(" + ((AbstractExpr)this.exprs.get(0)).toString() + " + " + ((AbstractExpr)this.exprs.get(1)).toString() + ")";
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/arithmetic/AddExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */