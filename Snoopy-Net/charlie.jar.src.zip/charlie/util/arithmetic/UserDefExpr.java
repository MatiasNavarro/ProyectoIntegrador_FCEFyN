/*    */ package charlie.util.arithmetic;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UserDefExpr
/*    */   extends NonTerminalExpr
/*    */ {
/*    */   protected String name;
/*    */   protected AbstractExpr op;
/*    */   protected ArrayList<String> params;
/*    */   
/*    */   public UserDefExpr(String n, AbstractExpr o, ArrayList<String> p_names, ArrayList<AbstractExpr> p_exprs) {
/* 18 */     this.name = n;
/* 19 */     this.op = o;
/* 20 */     this.params = p_names;
/* 21 */     this.exprs = p_exprs;
/*    */   }
/*    */   
/*    */   public Number eval(ArgumentExpr args) {
/* 25 */     ArgumentExpr l_args = args;
/* 26 */     for (int i = 0; i < this.exprs.size(); i++) {
/* 27 */       Number res = ((AbstractExpr)this.exprs.get(i)).eval(args);
/* 28 */       l_args.put(this.params.get(i), res);
/*    */     } 
/* 30 */     return this.op.eval(l_args);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 34 */     String res = this.name + "(";
/* 35 */     for (int i = 0; i < this.exprs.size(); i++) {
/* 36 */       if (i > 0) {
/* 37 */         res = res + ",";
/*    */       }
/* 39 */       res = res + ((AbstractExpr)this.exprs.get(i)).toString();
/*    */     } 
/* 41 */     res = res + ")";
/* 42 */     return res;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/arithmetic/UserDefExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */