/*    */ package charlie.util.arithmetic;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class NonTerminalExpr
/*    */   implements AbstractExpr
/*    */ {
/* 13 */   protected ArrayList<AbstractExpr> exprs = new ArrayList<>();
/*    */   
/*    */   public NonTerminalExpr() {}
/*    */   
/*    */   public NonTerminalExpr(NonTerminalExpr other) {
/* 18 */     this.exprs = other.exprs;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/arithmetic/NonTerminalExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */