/*    */ package charlie.util.arithmetic;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ArgumentExpr
/*    */ {
/* 16 */   protected HashMap<String, Number> values = new HashMap<>();
/*    */ 
/*    */   
/*    */   public void put(String k, Number v) {
/* 20 */     this.values.put(k, v);
/*    */   }
/*    */   
/*    */   public boolean has(String k) {
/* 24 */     return this.values.containsKey(k);
/*    */   }
/*    */   
/*    */   public Number get(String k) {
/* 28 */     return this.values.get(k);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/arithmetic/ArgumentExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */