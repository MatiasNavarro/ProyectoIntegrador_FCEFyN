package charlie.util.arithmetic;

public interface AbstractExpr {
  Number eval(ArgumentExpr paramArgumentExpr);
  
  String toString();
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/arithmetic/AbstractExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */