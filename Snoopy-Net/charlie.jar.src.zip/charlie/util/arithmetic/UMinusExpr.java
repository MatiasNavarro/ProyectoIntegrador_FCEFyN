/*    */ package charlie.util.arithmetic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UMinusExpr
/*    */   extends NonTerminalExpr
/*    */ {
/*    */   public UMinusExpr(AbstractExpr e) {
/* 12 */     this.exprs.add(e);
/*    */   }
/*    */   
/*    */   public UMinusExpr(UMinusExpr other) {
/* 16 */     super(other);
/*    */   }
/*    */   
/*    */   public Number eval(ArgumentExpr args) {
/* 20 */     Number arg = ((AbstractExpr)this.exprs.get(0)).eval(args);
/* 21 */     if (arg instanceof Double) {
/* 22 */       return Double.valueOf(-arg.doubleValue());
/*    */     }
/* 24 */     if (arg instanceof Float) {
/* 25 */       return Float.valueOf(-arg.floatValue());
/*    */     }
/* 27 */     if (arg instanceof Long) {
/* 28 */       return Long.valueOf(-arg.longValue());
/*    */     }
/* 30 */     if (arg instanceof Integer) {
/* 31 */       return Integer.valueOf(-arg.intValue());
/*    */     }
/* 33 */     if (arg instanceof Short) {
/* 34 */       return Integer.valueOf(-arg.shortValue());
/*    */     }
/* 36 */     if (arg instanceof Byte) {
/* 37 */       return Integer.valueOf(-arg.byteValue());
/*    */     }
/*    */     
/* 40 */     throw new RuntimeException("unknown type");
/*    */   }
/*    */   
/*    */   public String toString() {
/* 44 */     return "-(" + ((AbstractExpr)this.exprs.get(0)).toString() + ")";
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/arithmetic/UMinusExpr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */