/*    */ package charlie.util.arithmetic;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Variable
/*    */   extends TerminalExpr
/*    */ {
/*    */   protected String name;
/*    */   
/*    */   public Variable(String n) {
/* 14 */     this.name = n;
/*    */   }
/*    */   
/*    */   public Variable(Variable other) {
/* 18 */     this.name = other.name;
/*    */   }
/*    */   
/*    */   public Number eval(ArgumentExpr args) {
/* 22 */     return args.get(this.name);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 26 */     return this.name;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/arithmetic/Variable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */