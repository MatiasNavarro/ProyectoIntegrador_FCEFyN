/*    */ package charlie.util;
/*    */ 
/*    */ import javax.swing.JTextArea;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextAreaProtocol
/*    */   implements IProtocol
/*    */ {
/*    */   private final JTextArea ta;
/*    */   
/*    */   public TextAreaProtocol(JTextArea _ta) {
/* 15 */     this.ta = _ta;
/*    */   }
/*    */ 
/*    */   
/*    */   public void print(Object _o) {
/* 20 */     if (_o != null) {
/* 21 */       this.ta.append(_o.toString());
/*    */     } else {
/* 23 */       this.ta.append("null");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void println(Object _o) {
/* 29 */     if (_o != null) {
/* 30 */       this.ta.append(_o.toString());
/* 31 */       this.ta.append("\n");
/*    */     } else {
/* 33 */       this.ta.append("null\n");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void errPrint(Object _o) {
/* 39 */     if (_o != null) {
/* 40 */       this.ta.append(_o.toString());
/*    */     } else {
/* 42 */       this.ta.append("null");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void errPrintln(Object _o) {
/* 48 */     if (_o != null) {
/* 49 */       this.ta.append(_o.toString());
/* 50 */       this.ta.append("\n");
/*    */     } else {
/* 52 */       this.ta.append("null\n");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/TextAreaProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */