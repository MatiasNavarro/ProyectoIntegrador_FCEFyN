/*    */ package charlie.util;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReaderFileImportMessage
/*    */ {
/*    */   private final String readerId;
/*    */   private final File file;
/*    */   
/*    */   public ReaderFileImportMessage(String _readerId, File _file) {
/* 25 */     this.readerId = _readerId;
/* 26 */     this.file = _file;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getReaderId() {
/* 35 */     return this.readerId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public File getFile() {
/* 44 */     return this.file;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/ReaderFileImportMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */