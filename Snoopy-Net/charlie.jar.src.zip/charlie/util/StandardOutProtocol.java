/*    */ package charlie.util;
/*    */ 
/*    */ public class StandardOutProtocol
/*    */   implements IProtocol
/*    */ {
/*    */   public void print(Object _o) {
/*  7 */     if (_o != null) {
/*  8 */       System.out.print(_o.toString());
/*    */     } else {
/* 10 */       System.out.print("null");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void println(Object _o) {
/* 16 */     if (_o != null) {
/* 17 */       System.out.println(_o.toString());
/*    */     } else {
/* 19 */       System.out.println("null");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void errPrint(Object _o) {
/* 25 */     if (_o != null) {
/* 26 */       System.err.print(_o.toString());
/*    */     } else {
/* 28 */       System.err.print("null");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void errPrintln(Object _o) {
/* 34 */     if (_o != null) {
/* 35 */       System.err.println(_o.toString());
/*    */     } else {
/* 37 */       System.err.println("null");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/util/StandardOutProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */