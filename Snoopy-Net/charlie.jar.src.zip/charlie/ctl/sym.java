package charlie.ctl;

public class sym {
  public static final int AG = 31;
  
  public static final int AF = 32;
  
  public static final int GE = 20;
  
  public static final int XOR = 8;
  
  public static final int LPAREN = 24;
  
  public static final int SEMI = 2;
  
  public static final int RPAREN = 25;
  
  public static final int NOT = 5;
  
  public static final int AND = 6;
  
  public static final int LT = 22;
  
  public static final int OR = 7;
  
  public static final int RPAREN1 = 27;
  
  public static final int IMPLIES = 9;
  
  public static final int LPAREN1 = 26;
  
  public static final int UNTIL = 14;
  
  public static final int NEXT = 17;
  
  public static final int LE = 18;
  
  public static final int EOF = 0;
  
  public static final int EQUAL = 23;
  
  public static final int TRUE = 3;
  
  public static final int error = 1;
  
  public static final int EX = 30;
  
  public static final int IMPLIEDBY = 10;
  
  public static final int NUMBER = 36;
  
  public static final int EU = 35;
  
  public static final int GLOBALY = 16;
  
  public static final int EG = 28;
  
  public static final int EF = 29;
  
  public static final int EXIST = 12;
  
  public static final int NE = 19;
  
  public static final int STRING = 37;
  
  public static final int AX = 33;
  
  public static final int ALL = 13;
  
  public static final int FINALY = 15;
  
  public static final int AU = 34;
  
  public static final int FALSE = 4;
  
  public static final int GT = 21;
  
  public static final int IFF = 11;
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/sym.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */