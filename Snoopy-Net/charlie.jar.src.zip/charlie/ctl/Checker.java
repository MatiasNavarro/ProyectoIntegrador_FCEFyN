/*    */ package charlie.ctl;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.rg.RGraph;
/*    */ 
/*    */ public class Checker extends Thread {
/*    */   private RGraph rg;
/*    */   private PlaceTransitionNet pn;
/*    */   private String ctlFile;
/* 10 */   private int formulae = 1;
/*    */   public Checker(RGraph rg, PlaceTransitionNet pn, String ctlFile) {
/* 12 */     this.rg = rg;
/* 13 */     this.pn = pn;
/* 14 */     this.ctlFile = ctlFile;
/*    */   }
/*    */   
/*    */   public void run() {}
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/Checker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */