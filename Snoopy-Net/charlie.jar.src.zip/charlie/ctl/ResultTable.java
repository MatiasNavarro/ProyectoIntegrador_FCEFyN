/*    */ package charlie.ctl;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class ResultTable
/*    */ {
/*    */   private HashMap results;
/*    */   private int length;
/*    */   
/*    */   public ResultTable(int length) {
/* 12 */     this.length = length;
/* 13 */     this.results = new HashMap<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(Object key) {
/* 18 */     return this.results.containsKey(key);
/*    */   }
/*    */   public byte getResult(Object key, int id) {
/* 21 */     if (!this.results.containsKey(key)) {
/* 22 */       this.results.put(key, new Result(this.length));
/*    */     }
/* 24 */     return ((Result)this.results.get(key)).getResult(id);
/*    */   }
/*    */   
/*    */   public void addResult(Object key, int id) {
/* 28 */     if (!this.results.containsKey(key)) {
/* 29 */       this.results.put(key, new Result(this.length));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean setResult(Object key, int id, boolean v) {
/* 34 */     if (!this.results.containsKey(key)) {
/* 35 */       this.results.put(key, new Result(this.length));
/*    */     }
/* 37 */     ((Result)this.results.get(key)).setResult(id, v);
/* 38 */     return v;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 43 */     StringBuffer stb = new StringBuffer();
/* 44 */     for (Iterator it = this.results.keySet().iterator(); it.hasNext(); ) {
/* 45 */       Object key = it.next();
/* 46 */       stb.append(key + "\n");
/*    */       
/* 48 */       stb.append((new StringBuilder()).append(this.results.get(key)).append("\n").toString());
/*    */     } 
/* 50 */     return stb.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/ResultTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */