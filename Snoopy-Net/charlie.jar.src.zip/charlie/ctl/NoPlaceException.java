/*    */ package charlie.ctl;
/*    */ 
/*    */ public class NoPlaceException
/*    */   extends Exception {
/*    */   public NoPlaceException(String place) {
/*  6 */     this.place = place;
/*    */   }
/*    */   String place;
/*    */   public String getMessage() {
/* 10 */     return "place " + this.place + " does not exist";
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/NoPlaceException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */