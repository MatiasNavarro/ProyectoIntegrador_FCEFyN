/*    */ package charlie.ctl;
/*    */ 
/*    */ public class Result {
/*    */   byte[] formulae;
/*    */   
/*    */   public Result(int length) {
/*  7 */     this.formulae = new byte[length];
/*  8 */     for (int i = 0; i < length; i++) {
/*  9 */       this.formulae[i] = 2;
/*    */     }
/*    */   }
/*    */   
/*    */   public byte getResult(int id) {
/* 14 */     return this.formulae[id];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean setResult(int id, boolean v) {
/* 20 */     if (v) {
/* 21 */       this.formulae[id] = 1;
/*    */     } else {
/*    */       
/* 24 */       this.formulae[id] = 0;
/*    */     } 
/*    */     
/* 27 */     return v;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 31 */     StringBuffer stb = new StringBuffer();
/* 32 */     for (int i = 0; i < this.formulae.length; i++) {
/* 33 */       stb.append(this.formulae[i] + " ");
/*    */     }
/* 35 */     return stb.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/Result.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */