/*    */ package charlie.ctl;
/*    */ 
/*    */ import charlie.rg.Path;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InternalNode
/*    */   extends Node
/*    */ {
/*    */   private Node left;
/*    */   private Node right;
/*    */   private int v;
/*    */   int id;
/*    */   
/*    */   public InternalNode(Node l, int val, Node r) {
/* 18 */     this.id = 0; this.left = l; this.right = r;
/*    */     this.v = val;
/*    */     FormulaTree.root = this;
/* 21 */     FormulaTree.nodes++; } public int op() { return this.v; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRight(Node n) {
/* 27 */     this.right = n; } public void setLeft(Node n) {
/* 28 */     this.left = n;
/*    */   }
/*    */   public Node copy() {
/* 31 */     Node r = null;
/* 32 */     if (this.right != null) r = this.right.copy(); 
/* 33 */     r.negate = this.negate;
/* 34 */     return new InternalNode(this.left.copy(), this.v, r);
/*    */   }
/*    */   
/*    */   public int getId() {
/* 38 */     return this.id;
/*    */   }
/*    */   
/*    */   public Path witness() {
/* 42 */     switch (this.v) {
/*    */     
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 51 */     return null;
/*    */   }
/*    */   
/*    */   public void setId(int id) {
/* 55 */     this.id = id;
/*    */   }
/*    */   
/*    */   public Node left() {
/* 59 */     return this.left;
/*    */   }
/*    */   
/*    */   public Node right() {
/* 63 */     return this.right;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 67 */     String n = "";
/*    */     
/* 69 */     String r = "";
/* 70 */     if (this.right != null) {
/* 71 */       r = this.right.toString();
/*    */     }
/*    */     
/* 74 */     String l = this.left.toString();
/* 75 */     switch (this.v) {
/*    */       case 6:
/* 77 */         return n + "(" + l + " * " + r + ")";
/* 78 */       case 7: return n + "(" + l + " + " + r + ")";
/* 79 */       case 34: return n + "A [" + l + " U " + r + "]";
/* 80 */       case 35: return n + "E [" + l + " U " + r + "]";
/* 81 */       case 30: return n + "EX " + l;
/* 82 */       case 33: return n + "AX " + l;
/* 83 */       case 5: return "! (" + l + ")";
/*    */     } 
/*    */     
/* 86 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/InternalNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */