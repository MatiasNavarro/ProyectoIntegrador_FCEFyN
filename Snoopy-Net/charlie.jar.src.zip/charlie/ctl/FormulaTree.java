/*     */ package charlie.ctl;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ class FormulaTree
/*     */ {
/*   7 */   static int nodes = 0;
/*     */   static Node[] nodeList;
/*   9 */   static StringBuffer currentFormula = new StringBuffer();
/*  10 */   static Node root = null;
/*     */   
/*     */   static void reset() {
/*  13 */     currentFormula = new StringBuffer();
/*  14 */     v.clear();
/*  15 */     nodeList = null;
/*  16 */     root = null;
/*  17 */     nodes = 0;
/*     */   }
/*     */   
/*     */   static void init() {
/*  21 */     nodes = count();
/*  22 */     nodeList = new Node[nodes];
/*  23 */     travers(root);
/*  24 */     nodes = nodeList.length;
/*     */   }
/*     */   
/*  27 */   private static Vector v = new Vector();
/*     */ 
/*     */   
/*     */   public static void addFormula(String f) {
/*  31 */     v.insertElementAt(f, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getCurrentFormula(int i) {
/*  36 */     return v.get(i);
/*     */   }
/*     */   
/*     */   static void clear() {
/*  40 */     root = null;
/*  41 */     nodes = 0;
/*  42 */     nodeList = null;
/*  43 */     currentFormula = new StringBuffer();
/*     */   }
/*     */   
/*     */   public static String getCurrentFormula() {
/*  47 */     return currentFormula.toString();
/*     */   }
/*     */   
/*     */   public static void normNOT() {
/*  51 */     root = checkNOT(root);
/*     */     
/*  53 */     root = norm_(root);
/*     */     
/*  55 */     init();
/*     */   }
/*     */ 
/*     */   
/*     */   private static Node norm_(Node n) {
/*  60 */     if (n == null || n instanceof Leaf) return n; 
/*  61 */     Node l = checkNOT(n.left());
/*  62 */     n.setLeft(norm_(l));
/*  63 */     Node r = checkNOT(n.right());
/*  64 */     n.setRight(norm_(r));
/*  65 */     return n;
/*     */   }
/*     */   
/*     */   static void travers(Node r) {
/*  69 */     r.setId(--nodes);
/*  70 */     nodeList[nodes] = r;
/*  71 */     if (r instanceof Leaf)
/*  72 */       return;  travers(r.left());
/*  73 */     if (r.right() != null) {
/*  74 */       travers(r.right());
/*     */     }
/*     */   }
/*     */   
/*     */   private static int count() {
/*  79 */     int res = count_(root, 0);
/*  80 */     if (Options.debug) System.out.println("Nodes: " + res); 
/*  81 */     return res;
/*     */   }
/*     */   
/*     */   private static int count_(Node n, int res) {
/*  85 */     if (n == null) {
/*  86 */       return res;
/*     */     }
/*  88 */     res = count_(n.left(), res);
/*  89 */     res = count_(n.right(), res);
/*  90 */     res++;
/*  91 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Node negate(Node n) {
/*  97 */     return new InternalNode(n, 5, null);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Node checkNOT(Node n) {
/* 102 */     if (n == null) return n; 
/* 103 */     if (n.op() == 5) {
/* 104 */       Node next; Leaf l; Node left = n.left();
/* 105 */       if (left instanceof Leaf) {
/* 106 */         Leaf prop = (Leaf)left;
/* 107 */         int ident = prop.id();
/* 108 */         int value = prop.v();
/* 109 */         int newOp = -1;
/* 110 */         switch (prop.op()) { case 22:
/* 111 */             newOp = 20; break;
/* 112 */           case 21: newOp = 18; break;
/* 113 */           case 23: newOp = 19; break;
/* 114 */           case 19: newOp = 23; break;
/* 115 */           case 18: newOp = 21; break;
/* 116 */           case 20: newOp = 22; break; }
/*     */         
/* 118 */         return new Leaf(ident, newOp, value, prop.isPlaceId);
/*     */       } 
/*     */       
/* 121 */       switch (left.op()) {
/*     */         
/*     */         case 5:
/* 124 */           return checkNOT(left.left());
/*     */         
/*     */         case 6:
/* 127 */           return new InternalNode(negate(left.left()), 7, negate(left.right()));
/*     */         
/*     */         case 7:
/* 130 */           return new InternalNode(negate(left.left()), 6, negate(left.right()));
/*     */ 
/*     */         
/*     */         case 17:
/* 134 */           next = negate(left.left());
/* 135 */           return new InternalNode(next, 17, null);
/*     */         case 3:
/* 137 */           l = (Leaf)left;
/* 138 */           return new Leaf(l.id(), 4, l.v());
/* 139 */         case 4: l = (Leaf)left;
/* 140 */           return new Leaf(l.id(), 3, l.v());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 148 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   private class IntWrapper
/*     */   {
/*     */     int val;
/*     */     
/*     */     IntWrapper(int val) {
/* 157 */       this.val = val;
/*     */     }
/*     */     
/*     */     int value() {
/* 161 */       return this.val;
/*     */     }
/*     */     
/*     */     void setValue(int val) {
/* 165 */       this.val = val;
/*     */     }
/*     */     
/*     */     void inc() {
/* 169 */       this.val++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void postLin_(Node n, Node[] lin, IntWrapper cur) {
/* 176 */     if (n == null)
/* 177 */       return;  postLin_(n.left(), lin, cur);
/* 178 */     postLin_(n.right(), lin, cur);
/* 179 */     lin[cur.value()] = n;
/* 180 */     cur.inc();
/*     */   }
/*     */ 
/*     */   
/*     */   public Node[] postLin() {
/* 185 */     Node[] lin = new Node[nodes];
/* 186 */     postLin_(root, lin, new IntWrapper(0));
/* 187 */     return lin;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getFormula(int id) {
/* 193 */     return nodeList[id];
/*     */   }
/*     */ 
/*     */   
/*     */   static String getString() {
/* 198 */     if (nodes > 0) {
/* 199 */       return nodeList[nodes - 1].toString();
/*     */     }
/* 201 */     return "FormulaTree is empty";
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/FormulaTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */