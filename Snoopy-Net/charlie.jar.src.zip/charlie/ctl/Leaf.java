/*     */ package charlie.ctl;
/*     */ 
/*     */ import charlie.pn.UnsignedByte;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Leaf
/*     */   extends Node
/*     */ {
/*     */   int identID;
/*     */   int operator;
/*     */   int value;
/*     */   boolean isPlaceId;
/*     */   int id;
/*     */   
/*     */   public Leaf(int id, int o, int v) {
/*  37 */     this.id = 0; this.identID = id; this.operator = o; this.value = v; this.isPlaceId = false; FormulaTree.nodes++; } public Leaf(int id, int o, int v, boolean isPlaceId) { this.id = 0; this.identID = id; this.operator = o; this.value = v; this.isPlaceId = isPlaceId; FormulaTree.nodes++; } public Leaf(boolean tf) { this.id = 0; this.identID = UnsignedByte.zero; if (tf) {
/*     */       this.operator = 3;
/*     */     } else {
/*     */       this.operator = 4;
/*  41 */     }  FormulaTree.nodes++; } public void setId(int id) { this.id = id; }
/*     */ 
/*     */   
/*     */   public int id() {
/*  45 */     return this.identID;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  50 */     String str = "";
/*     */     
/*  52 */     if (this.identID == UnsignedByte.zero) {
/*  53 */       str = "false";
/*  54 */       if (this.operator == 3) {
/*  55 */         str = "true";
/*     */       }
/*  57 */       return new String(str);
/*     */     } 
/*  59 */     str = str + "place (" + this.identID + ") ";
/*     */     
/*  61 */     switch (this.operator) { case 21:
/*  62 */         str = str + ">"; break;
/*  63 */       case 22: str = str + "<"; break;
/*  64 */       case 20: str = str + ">="; break;
/*  65 */       case 18: str = str + "<="; break;
/*  66 */       case 19: str = str + "!="; break;
/*  67 */       case 23: str = str + "==";
/*     */         break; }
/*     */     
/*  70 */     if (!this.isPlaceId) {
/*  71 */       str = str + " " + this.value + " ";
/*     */     } else {
/*  73 */       str = str + " place (" + this.value + ") ";
/*     */     } 
/*     */     
/*  76 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node left() {
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node right() {
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getId() {
/*  93 */     return this.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public int op() {
/*  98 */     return this.operator;
/*     */   }
/*     */   
/*     */   public int v() {
/* 102 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRight(Node n) {}
/*     */ 
/*     */   
/*     */   public void setLeft(Node n) {}
/*     */ 
/*     */   
/*     */   public Node copy() {
/* 113 */     return new Leaf(this.identID, this.operator, this.value, this.isPlaceId);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/Leaf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */