/*     */ package charlie.ctl;
/*     */ import java.io.InputStream;
/*     */ import java_cup.runtime.Symbol;
/*     */ 
/*     */ class Yylex implements Scanner {
/*   6 */   private final int YY_BUFFER_SIZE = 512;
/*   7 */   private final int YY_F = -1;
/*   8 */   private final int YY_NO_STATE = -1;
/*   9 */   private final int YY_NOT_ACCEPT = 0;
/*  10 */   private final int YY_START = 1;
/*  11 */   private final int YY_END = 2;
/*  12 */   private final int YY_NO_ANCHOR = 4;
/*  13 */   private final int YY_BOL = 128;
/*  14 */   private final int YY_EOF = 129; private BufferedReader yy_reader;
/*     */   private int yy_buffer_index;
/*     */   private int yy_buffer_read;
/*     */   private int yy_buffer_start;
/*     */   private int yy_buffer_end;
/*     */   private char[] yy_buffer;
/*     */   private boolean yy_at_bol;
/*     */   private int yy_lexical_state;
/*     */   private boolean yy_eof_done;
/*     */   
/*     */   Yylex(Reader reader) {
/*  25 */     this();
/*  26 */     if (null == reader) {
/*  27 */       throw new Error("Error: Bad input stream initializer.");
/*     */     }
/*  29 */     this.yy_reader = new BufferedReader(reader);
/*     */   }
/*     */   private final int YYINITIAL = 0; private final int[] yy_state_dtrans; private boolean yy_last_was_cr; private final int YY_E_INTERNAL = 0; private final int YY_E_MATCH = 1; private String[] yy_error_string; private int[] yy_acpt; private int[] yy_cmap; private int[] yy_rmap; private int[][] yy_nxt;
/*     */   Yylex(InputStream instream) {
/*  33 */     this();
/*  34 */     if (null == instream) {
/*  35 */       throw new Error("Error: Bad input stream initializer.");
/*     */     }
/*  37 */     this.yy_reader = new BufferedReader(new InputStreamReader(instream));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Yylex() {
/*  50 */     this.yy_eof_done = false;
/*  51 */     this.YYINITIAL = 0;
/*  52 */     this.yy_state_dtrans = new int[] { 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     this.yy_last_was_cr = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     this.YY_E_INTERNAL = 0;
/* 144 */     this.YY_E_MATCH = 1;
/* 145 */     this.yy_error_string = new String[] { "Error: Internal error.\n", "Error: Unmatched input.\n" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     this.yy_acpt = new int[] { 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 4, 4, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 262 */     this.yy_cmap = unpackFromString(1, 130, "37:9,41,38,37,41:2,37:18,41,12,37:3,18,14,37,2,3,15,17,37,23,37,36,39:10,37,1,21,22,20,37:2,6,40:3,7,10,9,40:4,34,40:5,33,35,32,8,40:2,11,40:2,4,37,5,19,40,37,29,40:3,27,28,40:5,30,40:5,25,31,24,26,40:5,37,16,37,13,37,0:2")[0];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 267 */     this.yy_rmap = unpackFromString(1, 67, "0,1:6,2,3,4:2,5,1,6,1,7,1:3,8,9,10,1,11,4:6,1:5,12,13,1:3,14,1:2,4:2,15,4:2,15,16,17,18,19,20,21,1,22,23,24,25,26,27,28,29,30,31,32")[0];
/*     */ 
/*     */ 
/*     */     
/* 271 */     this.yy_nxt = unpackFromString(33, 42, "1,2,3,4,5,6,7,8,9,10,65,10,11,12,13,14,15,16,17,18,19,20,21,50,61,10:3,66,10:3,62,10:3,53,55,22,23,10,22,-1:48,10:3,24,25,26,-1:12,10:12,-1:3,10:2,-1:7,10:3,27,28,29,-1:12,10:12,-1:3,10:2,-1:7,10:6,-1:12,10:12,-1:3,10:2,-1:23,30,-1:33,31,-1:43,32,-1:47,33,-1:39,34,-1,35,36,-1:38,37,-1,38,-1:58,23,-1:22,41,-1:41,42,-1:22,40:37,-1,40:3,-1,48:14,51,48:26,-1:6,10:6,-1:12,10:3,43,10:8,-1:3,10:2,-1:21,39,-1:22,48:14,51,48:20,45,48:5,-1:6,10,44,10:4,-1:12,10:12,-1:3,10:2,-1:16,48,-1:20,40,-1:11,10,46,10:4,-1:12,10:12,-1:3,10:2,-1:7,10:6,-1:12,10:3,47,10:8,-1:3,10:2,-1:7,10:6,-1:12,10:2,49,10:9,-1:3,10:2,-1:7,10:2,52,10:3,-1:12,10:12,-1:3,10:2,-1:7,10:6,-1:12,10:11,54,-1:3,10:2,-1:7,10:6,-1:12,10:7,56,10:4,-1:3,10:2,-1:7,10:6,-1:12,10,57,10:10,-1:3,10:2,-1:7,10:6,-1:12,10:9,58,10:2,-1:3,10:2,-1:7,10:6,-1:12,10:10,59,10,-1:3,10:2,-1:7,10:6,-1:12,10:6,60,10:5,-1:3,10:2,-1:7,63,10:5,-1:12,10:12,-1:3,10:2,-1:7,10:6,-1:12,10:5,64,10:6,-1:3,10:2,-1");
/*     */     this.yy_buffer = new char[512];
/*     */     this.yy_buffer_read = 0;
/*     */     this.yy_buffer_index = 0;
/*     */     this.yy_buffer_start = 0;
/*     */     this.yy_buffer_end = 0;
/*     */     this.yy_at_bol = true;
/*     */     this.yy_lexical_state = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void yybegin(int state) {
/*     */     this.yy_lexical_state = state;
/*     */   }
/*     */ 
/*     */   
/*     */   public Symbol next_token() throws IOException, ParseException {
/* 289 */     int yy_anchor = 4;
/* 290 */     int yy_state = this.yy_state_dtrans[this.yy_lexical_state];
/* 291 */     int yy_next_state = -1;
/* 292 */     int yy_last_accept_state = -1;
/* 293 */     boolean yy_initial = true;
/*     */ 
/*     */     
/* 296 */     yy_mark_start();
/* 297 */     int yy_this_accept = this.yy_acpt[yy_state];
/* 298 */     if (0 != yy_this_accept) {
/* 299 */       yy_last_accept_state = yy_state;
/* 300 */       yy_mark_end();
/*     */     }  while (true) {
/*     */       int yy_lookahead;
/* 303 */       if (yy_initial && this.yy_at_bol) { yy_lookahead = 128; }
/* 304 */       else { yy_lookahead = yy_advance(); }
/* 305 */        yy_next_state = -1;
/* 306 */       yy_next_state = this.yy_nxt[this.yy_rmap[yy_state]][this.yy_cmap[yy_lookahead]];
/* 307 */       if (129 == yy_lookahead && true == yy_initial)
/*     */       {
/* 309 */         return new Symbol(0);
/*     */       }
/* 311 */       if (-1 != yy_next_state) {
/* 312 */         yy_state = yy_next_state;
/* 313 */         yy_initial = false;
/* 314 */         yy_this_accept = this.yy_acpt[yy_state];
/* 315 */         if (0 != yy_this_accept) {
/* 316 */           yy_last_accept_state = yy_state;
/* 317 */           yy_mark_end();
/*     */         } 
/*     */         continue;
/*     */       } 
/* 321 */       if (-1 == yy_last_accept_state) {
/* 322 */         throw new Error("Lexical Error: Unmatched Input.");
/*     */       }
/*     */       
/* 325 */       yy_anchor = this.yy_acpt[yy_last_accept_state];
/* 326 */       if (0 != (0x2 & yy_anchor)) {
/* 327 */         yy_move_end();
/*     */       }
/* 329 */       yy_to_mark();
/* 330 */       switch (yy_last_accept_state) {
/*     */         case -2:
/*     */         case 1:
/*     */           break;
/*     */         
/*     */         case 2:
/* 336 */           FormulaTree.currentFormula.append(yytext());
/* 337 */           FormulaTree.addFormula(FormulaTree.currentFormula.toString());
/* 338 */           FormulaTree.currentFormula = new StringBuffer();
/* 339 */           return new Symbol(2);
/*     */         case -3:
/*     */           break;
/*     */         case 3:
/* 343 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(24);
/*     */         case -4:
/*     */           break;
/*     */         case 4:
/* 347 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(25);
/*     */         case -5:
/*     */           break;
/*     */         case 5:
/* 351 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(26);
/*     */         case -6:
/*     */           break;
/*     */         case 6:
/* 355 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(27);
/*     */         case -7:
/*     */           break;
/*     */         case 7:
/* 359 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(34);
/*     */         case -8:
/*     */           break;
/*     */         case 8:
/* 363 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(35);
/*     */         case -9:
/*     */           break;
/*     */         case 9:
/* 367 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(14);
/*     */         case -10:
/*     */           break;
/*     */         case 10:
/* 371 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -11:
/*     */           break;
/*     */         case 11:
/* 375 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(5);
/*     */         case -12:
/*     */           break;
/*     */         case 12:
/* 379 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(5);
/*     */         case -13:
/*     */           break;
/*     */         case 13:
/* 383 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(6);
/*     */         case -14:
/*     */           break;
/*     */         case 14:
/* 387 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(6);
/*     */         case -15:
/*     */           break;
/*     */         case 15:
/* 391 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(7);
/*     */         case -16:
/*     */           break;
/*     */         case 16:
/* 395 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(7);
/*     */         case -17:
/*     */           break;
/*     */         case 17:
/* 399 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(8);
/*     */         case -18:
/*     */           break;
/*     */         case 18:
/* 403 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(8);
/*     */         case -19:
/*     */           break;
/*     */         case 19:
/* 407 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(21);
/*     */         case -20:
/*     */           break;
/*     */         case 20:
/* 411 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(22);
/*     */         case -21:
/*     */           break;
/*     */         case 21:
/* 415 */           System.err.println("Illegal character: " + yytext()); throw new ParseException();
/*     */         case -22:
/*     */           break;
/*     */         case 22:
/* 419 */           if (!yytext().equals("\n")) FormulaTree.currentFormula.append(yytext());  break;
/*     */         case -23:
/*     */           break;
/*     */         case 23:
/* 423 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(36, new Integer(yytext()));
/*     */         case -24:
/*     */           break;
/*     */         case 24:
/* 427 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(31);
/*     */         case -25:
/*     */           break;
/*     */         case 25:
/* 431 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(32);
/*     */         case -26:
/*     */           break;
/*     */         case 26:
/* 435 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(33);
/*     */         case -27:
/*     */           break;
/*     */         case 27:
/* 439 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(28);
/*     */         case -28:
/*     */           break;
/*     */         case 28:
/* 443 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(29);
/*     */         case -29:
/*     */           break;
/*     */         case 29:
/* 447 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(30);
/*     */         case -30:
/*     */           break;
/*     */         case 30:
/* 451 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(19);
/*     */         case -31:
/*     */           break;
/*     */         case 31:
/* 455 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(6);
/*     */         case -32:
/*     */           break;
/*     */         case 32:
/* 459 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(7);
/*     */         case -33:
/*     */           break;
/*     */         case 33:
/* 463 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(20);
/*     */         case -34:
/*     */           break;
/*     */         case 34:
/* 467 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(19);
/*     */         case -35:
/*     */           break;
/*     */         case 35:
/* 471 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(18);
/*     */         case -36:
/*     */           break;
/*     */         case 36:
/* 475 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(10);
/*     */         case -37:
/*     */           break;
/*     */         case 37:
/* 479 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(9);
/*     */         case -38:
/*     */           break;
/*     */         case 38:
/* 483 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(23);
/*     */         case -39:
/*     */           break;
/*     */         case 39:
/* 487 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(9);
/*     */         case -40:
/*     */           break;
/*     */         case 40:
/* 491 */           System.out.println("one line comment: " + yytext()); break;
/*     */         case -41:
/*     */           break;
/*     */         case 41:
/* 495 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(11);
/*     */         case -42:
/*     */           break;
/*     */         case 42:
/* 499 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(11);
/*     */         case -43:
/*     */           break;
/*     */         case 43:
/* 503 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(3);
/*     */         case -44:
/*     */           break;
/*     */         case 44:
/* 507 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(3);
/*     */         case -45:
/*     */           break;
/*     */         case 45:
/* 511 */           System.out.println("comment: " + yytext()); break;
/*     */         case -46:
/*     */           break;
/*     */         case 46:
/* 515 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(4);
/*     */         case -47:
/*     */           break;
/*     */         case 47:
/* 519 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(4);
/*     */         case -48:
/*     */           break;
/*     */         case 49:
/* 523 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -49:
/*     */           break;
/*     */         case 50:
/* 527 */           System.err.println("Illegal character: " + yytext()); throw new ParseException();
/*     */         case -50:
/*     */           break;
/*     */         case 52:
/* 531 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -51:
/*     */           break;
/*     */         case 53:
/* 535 */           System.err.println("Illegal character: " + yytext()); throw new ParseException();
/*     */         case -52:
/*     */           break;
/*     */         case 54:
/* 539 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -53:
/*     */           break;
/*     */         case 55:
/* 543 */           System.err.println("Illegal character: " + yytext()); throw new ParseException();
/*     */         case -54:
/*     */           break;
/*     */         case 56:
/* 547 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -55:
/*     */           break;
/*     */         case 57:
/* 551 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -56:
/*     */           break;
/*     */         case 58:
/* 555 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -57:
/*     */           break;
/*     */         case 59:
/* 559 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -58:
/*     */           break;
/*     */         case 60:
/* 563 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -59:
/*     */           break;
/*     */         case 61:
/* 567 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -60:
/*     */           break;
/*     */         case 62:
/* 571 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -61:
/*     */           break;
/*     */         case 63:
/* 575 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -62:
/*     */           break;
/*     */         case 64:
/* 579 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -63:
/*     */           break;
/*     */         case 65:
/* 583 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -64:
/*     */           break;
/*     */         case 66:
/* 587 */           FormulaTree.currentFormula.append(yytext()); return new Symbol(37, new String(yytext()));
/*     */         case -65:
/*     */           break;
/*     */         default:
/* 591 */           yy_error(0, false); break;
/*     */         case -1:
/*     */           break;
/* 594 */       }  yy_initial = true;
/* 595 */       yy_state = this.yy_state_dtrans[this.yy_lexical_state];
/* 596 */       yy_next_state = -1;
/* 597 */       yy_last_accept_state = -1;
/* 598 */       yy_mark_start();
/* 599 */       yy_this_accept = this.yy_acpt[yy_state];
/* 600 */       if (0 != yy_this_accept) {
/* 601 */         yy_last_accept_state = yy_state;
/* 602 */         yy_mark_end();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int yy_advance() throws IOException {
/*     */     if (this.yy_buffer_index < this.yy_buffer_read)
/*     */       return this.yy_buffer[this.yy_buffer_index++]; 
/*     */     if (0 != this.yy_buffer_start) {
/*     */       int i = this.yy_buffer_start;
/*     */       int j = 0;
/*     */       while (i < this.yy_buffer_read) {
/*     */         this.yy_buffer[j] = this.yy_buffer[i];
/*     */         i++;
/*     */         j++;
/*     */       } 
/*     */       this.yy_buffer_end -= this.yy_buffer_start;
/*     */       this.yy_buffer_start = 0;
/*     */       this.yy_buffer_read = j;
/*     */       this.yy_buffer_index = j;
/*     */       int next_read = this.yy_reader.read(this.yy_buffer, this.yy_buffer_read, this.yy_buffer.length - this.yy_buffer_read);
/*     */       if (-1 == next_read)
/*     */         return 129; 
/*     */       this.yy_buffer_read += next_read;
/*     */     } 
/*     */     while (this.yy_buffer_index >= this.yy_buffer_read) {
/*     */       if (this.yy_buffer_index >= this.yy_buffer.length)
/*     */         this.yy_buffer = yy_double(this.yy_buffer); 
/*     */       int next_read = this.yy_reader.read(this.yy_buffer, this.yy_buffer_read, this.yy_buffer.length - this.yy_buffer_read);
/*     */       if (-1 == next_read)
/*     */         return 129; 
/*     */       this.yy_buffer_read += next_read;
/*     */     } 
/*     */     return this.yy_buffer[this.yy_buffer_index++];
/*     */   }
/*     */   
/*     */   private void yy_move_end() {
/*     */     if (this.yy_buffer_end > this.yy_buffer_start && '\n' == this.yy_buffer[this.yy_buffer_end - 1])
/*     */       this.yy_buffer_end--; 
/*     */     if (this.yy_buffer_end > this.yy_buffer_start && '\r' == this.yy_buffer[this.yy_buffer_end - 1])
/*     */       this.yy_buffer_end--; 
/*     */   }
/*     */   
/*     */   private void yy_mark_start() {
/*     */     this.yy_buffer_start = this.yy_buffer_index;
/*     */   }
/*     */   
/*     */   private void yy_mark_end() {
/*     */     this.yy_buffer_end = this.yy_buffer_index;
/*     */   }
/*     */   
/*     */   private void yy_to_mark() {
/*     */     this.yy_buffer_index = this.yy_buffer_end;
/*     */     this.yy_at_bol = (this.yy_buffer_end > this.yy_buffer_start && ('\r' == this.yy_buffer[this.yy_buffer_end - 1] || '\n' == this.yy_buffer[this.yy_buffer_end - 1] || '߬' == this.yy_buffer[this.yy_buffer_end - 1] || '߭' == this.yy_buffer[this.yy_buffer_end - 1]));
/*     */   }
/*     */   
/*     */   private String yytext() {
/*     */     return new String(this.yy_buffer, this.yy_buffer_start, this.yy_buffer_end - this.yy_buffer_start);
/*     */   }
/*     */   
/*     */   private int yylength() {
/*     */     return this.yy_buffer_end - this.yy_buffer_start;
/*     */   }
/*     */   
/*     */   private char[] yy_double(char[] buf) {
/*     */     char[] newbuf = new char[2 * buf.length];
/*     */     for (int i = 0; i < buf.length; i++)
/*     */       newbuf[i] = buf[i]; 
/*     */     return newbuf;
/*     */   }
/*     */   
/*     */   private void yy_error(int code, boolean fatal) {
/*     */     System.out.print(this.yy_error_string[code]);
/*     */     System.out.flush();
/*     */     if (fatal)
/*     */       throw new Error("Fatal Error.\n"); 
/*     */   }
/*     */   
/*     */   private int[][] unpackFromString(int size1, int size2, String st) {
/*     */     int colonIndex = -1;
/*     */     int sequenceLength = 0;
/*     */     int sequenceInteger = 0;
/*     */     int[][] res = new int[size1][size2];
/*     */     for (int i = 0; i < size1; i++) {
/*     */       for (int j = 0; j < size2; j++) {
/*     */         if (sequenceLength != 0) {
/*     */           res[i][j] = sequenceInteger;
/*     */           sequenceLength--;
/*     */         } else {
/*     */           int commaIndex = st.indexOf(',');
/*     */           String workString = (commaIndex == -1) ? st : st.substring(0, commaIndex);
/*     */           st = st.substring(commaIndex + 1);
/*     */           colonIndex = workString.indexOf(':');
/*     */           if (colonIndex == -1) {
/*     */             res[i][j] = Integer.parseInt(workString);
/*     */           } else {
/*     */             String lengthString = workString.substring(colonIndex + 1);
/*     */             sequenceLength = Integer.parseInt(lengthString);
/*     */             workString = workString.substring(0, colonIndex);
/*     */             sequenceInteger = Integer.parseInt(workString);
/*     */             res[i][j] = sequenceInteger;
/*     */             sequenceLength--;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     return res;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/Yylex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */