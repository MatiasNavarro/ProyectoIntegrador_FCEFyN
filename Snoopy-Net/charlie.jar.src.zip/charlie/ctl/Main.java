/*    */ package charlie.ctl;
/*    */ 
/*    */ import GUI.debug.DebugCounter;
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.rg.NoReduction;
/*    */ import charlie.rg.RGraph;
/*    */ import charlie.rg.Reduction;
/*    */ import java.io.Reader;
/*    */ import java.io.StringReader;
/*    */ import java.util.Vector;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ public class Main {
/* 14 */   public static StringBuffer resultText = new StringBuffer(); public static RGraph rg;
/*    */   static Vector filter;
/*    */   static PlaceTransitionNet pn;
/*    */   static long currentTime;
/* 18 */   static int formulae = 1;
/*    */   
/*    */   public static void checkSyntax(StringReader sr) throws Exception, ParseException, NoPlaceException {
/* 21 */     resultText = new StringBuffer();
/* 22 */     if (rg == null)
/* 23 */       DebugCounter.inc("ctl.Main.checkSyntax(...): rg == null"); 
/*    */     try {
/* 25 */       (new parser(new Yylex(sr), false)).parse();
/* 26 */     } catch (ParseException pe) {
/* 27 */       throw pe;
/* 28 */     } catch (NoPlaceException npe) {
/* 29 */       throw npe;
/* 30 */     } catch (Exception e) {
/* 31 */       throw e;
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void checkFormulae(PlaceTransitionNet pn, RGraph r, Reader str, Vector v) throws Exception, NoPlaceException {
/*    */     try {
/* 37 */       filter = v;
/*    */ 
/*    */ 
/*    */       
/* 41 */       DebugCounter.inc("Main.java::checkFormulae(...)");
/* 42 */       FormulaTree.reset();
/* 43 */       rg = r;
/* 44 */       if (rg == null) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 51 */         DebugCounter.inc("Please construct a reachability graph first!");
/* 52 */         JOptionPane.showMessageDialog(null, "<html><p>Please construct a reachability graph before checking a formula!</p><p>No reachability graph set in formula checker.</p></html>");
/*    */       } 
/* 54 */       formulae = 1;
/* 55 */       (new parser(new Yylex(str))).parse();
/* 56 */       DebugCounter.inc("Main.java::checkFormulae() resultText: " + resultText);
/* 57 */     } catch (NoPlaceException npe) {
/*    */       
/* 59 */       throw npe;
/* 60 */     } catch (Exception e) {
/*    */       
/* 62 */       throw e;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void check() {
/* 68 */     DebugCounter.inc("ctl.Main.java::check()  - check formula " + formulae);
/* 69 */     String currentFormula = FormulaTree.getCurrentFormula(formulae - 1);
/* 70 */     DebugCounter.inc(currentFormula);
/* 71 */     formulae++;
/*    */     
/* 73 */     FormulaTree.init();
/* 74 */     LocalCTLChecker ch = new LocalCTLChecker(rg, new FormulaTree(), (Reduction)new NoReduction(pn));
/*    */     
/* 76 */     boolean res = ch.check(rg.getFirst(), FormulaTree.nodes - 1);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 84 */     resultText.append("the ctl formula \n" + currentFormula + "\n is " + res + "\n");
/* 85 */     String current = currentFormula + "<p>is " + res + "<p>";
/* 86 */     DebugCounter.inc("currentFormula : " + currentFormula);
/* 87 */     DebugCounter.inc(FormulaTree.getString() + " -- " + res);
/* 88 */     resultText.append(FormulaTree.getString() + " -- " + res + "\n");
/* 89 */     FormulaTree.clear();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */