/*     */ package charlie.ctl;
/*     */ 
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.State;
/*     */ import charlie.rg.RGEdge;
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import charlie.rg.Reduction;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Stack;
/*     */ import java.util.Vector;
/*     */ 
/*     */ class LocalCTLChecker
/*     */ {
/*  17 */   int calls = 0;
/*     */   private Stack decisions;
/*     */   private ResultTable rt;
/*  20 */   private Stack lastSequenz = null;
/*  21 */   private int lastFormula = -1;
/*  22 */   private Stack auStack = new Stack();
/*     */   private RGraph rg;
/*  24 */   private RGNode firstNode = null;
/*  25 */   private int firstFormula = -1;
/*  26 */   public final byte TRUE = 1;
/*  27 */   public final byte UNCHECKED = 2;
/*  28 */   public final byte FALSE = 0;
/*     */   private Reduction r;
/*  30 */   public PlaceTransitionNet pn = null;
/*     */   private int resultLength;
/*     */   private FormulaTree formula;
/*  33 */   public static Vector path = new Vector();
/*     */ 
/*     */   
/*     */   private class StackEntryCheck
/*     */   {
/*     */     RGNode n;
/*     */     int formulaId;
/*     */     
/*     */     StackEntryCheck(RGNode n, int id) {
/*  42 */       this.n = n;
/*  43 */       this.formulaId = id;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector path() {
/*  49 */     return path;
/*     */   }
/*     */   
/*     */   public LocalCTLChecker(RGraph rg, FormulaTree ft, Reduction reduction) {
/*  53 */     this.decisions = new Stack();
/*  54 */     this.formula = ft;
/*  55 */     this.rg = rg;
/*  56 */     this.pn = rg.getNet();
/*  57 */     this.r = reduction;
/*  58 */     this.resultLength = FormulaTree.nodes;
/*  59 */     this.rt = new ResultTable(FormulaTree.nodes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void check_(Node n) {
/*  68 */     if (n == null)
/*  69 */       return;  check_(n.left());
/*  70 */     check_(n.right());
/*     */     
/*  72 */     for (Iterator<RGNode> it = this.rg.iterator(); it.hasNext(); ) {
/*  73 */       RGNode m = it.next();
/*     */       
/*  75 */       boolean bool = check(m, n.getId());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkGlobally() {
/*  84 */     check_(FormulaTree.root);
/*  85 */     return check(this.rg.first, FormulaTree.nodes - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultTable getResultTable() {
/*  90 */     return this.rt;
/*     */   }
/*     */   
/*     */   public boolean check(RGNode node, int formulaId) {
/*  94 */     if (this.calls == 0) {
/*  95 */       this.firstFormula = formulaId;
/*  96 */       this.firstNode = node;
/*     */     } 
/*  98 */     this.calls++;
/*     */     
/* 100 */     if (this.rt.getResult(node.getLabel(), formulaId) != 2) {
/* 101 */       if (this.rt.getResult(node.getLabel(), formulaId) == 0) return false; 
/* 102 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 107 */     if (path == null) path = new Vector(); 
/* 108 */     int startId = formulaId;
/* 109 */     RGNode start = node;
/* 110 */     Stack<StackEntryCheck> stack = new Stack();
/* 111 */     HashSet toproove = new HashSet();
/* 112 */     boolean saveq = false;
/* 113 */     Marking m = node.getLabel();
/* 114 */     Node n = this.formula.getFormula(formulaId);
/* 115 */     boolean ret = false;
/* 116 */     StackEntryCheck sec = new StackEntryCheck(node, formulaId);
/* 117 */     stack.add(sec);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     label138: while (true) {
/* 124 */       m = node.getLabel();
/* 125 */       n = this.formula.getFormula(formulaId);
/*     */ 
/*     */ 
/*     */       
/* 129 */       if (n instanceof Leaf) {
/* 130 */         Leaf l = (Leaf)n;
/* 131 */         this.rt.setResult(node.getLabel(), formulaId, checkProp(node, l));
/*     */       } 
/* 133 */       if (n instanceof InternalNode) {
/*     */         byte left, right; RGEdge out;
/* 135 */         InternalNode i = (InternalNode)n;
/* 136 */         switch (i.op()) {
/*     */           
/*     */           case 6:
/* 139 */             left = this.rt.getResult(node.getLabel(), i.left().getId());
/* 140 */             right = this.rt.getResult(node.getLabel(), i.right().getId());
/* 141 */             if (left == 2) {
/* 142 */               stack.add(new StackEntryCheck(node, formulaId));
/* 143 */               formulaId = i.left().getId();
/*     */               break;
/*     */             } 
/* 146 */             if (left == 0) {
/* 147 */               ret = false;
/* 148 */               this.rt.setResult(m, formulaId, ret);
/*     */             } else {
/*     */               
/* 151 */               if (right == 2) {
/* 152 */                 stack.add(new StackEntryCheck(node, formulaId));
/* 153 */                 formulaId = i.right().getId();
/*     */                 
/*     */                 break;
/*     */               } 
/* 157 */               if (right == 0)
/* 158 */               { ret = false;
/* 159 */                 this.rt.setResult(m, formulaId, ret);
/*     */                 
/*     */                  }
/*     */               
/*     */               else
/*     */               
/*     */               { 
/*     */                 
/* 167 */                 ret = true;
/* 168 */                 this.rt.setResult(m, formulaId, ret); } 
/*     */             } 
/*     */           case 7:
/* 171 */             left = this.rt.getResult(m, i.left().getId());
/* 172 */             right = this.rt.getResult(m, i.right().getId());
/* 173 */             if (left == 2) {
/* 174 */               stack.add(new StackEntryCheck(node, formulaId));
/* 175 */               formulaId = i.left().getId();
/*     */               break;
/*     */             } 
/* 178 */             if (left == 1) {
/* 179 */               ret = true;
/* 180 */               this.rt.setResult(m, formulaId, ret);
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 185 */               if (right == 2) {
/* 186 */                 stack.add(new StackEntryCheck(node, formulaId));
/* 187 */                 formulaId = i.right().getId();
/*     */                 
/*     */                 break;
/*     */               } 
/* 191 */               if (right == 1)
/* 192 */               { ret = true;
/* 193 */                 this.rt.setResult(m, formulaId, ret); }
/*     */               else
/*     */               
/* 196 */               { ret = false;
/*     */                 
/* 198 */                 this.rt.setResult(m, formulaId, ret); } 
/*     */             } 
/*     */           case 34:
/* 201 */             if (this.rt.getResult(node.getLabel(), formulaId) == 1) {
/* 202 */               ret = true;
/* 203 */             } else if (this.rt.getResult(node.getLabel(), formulaId) == 0) {
/* 204 */               ret = false;
/*     */             } else {
/* 206 */               Stack ce = new Stack();
/* 207 */               ret = checkAU(node, formulaId, ce, new Stack(), new HashSet());
/* 208 */               this.lastFormula = formulaId;
/* 209 */               if (!ce.isEmpty()) {
/* 210 */                 this.lastSequenz = ce;
/*     */               } else {
/*     */                 
/* 213 */                 ce = null;
/*     */               } 
/*     */             } 
/*     */ 
/*     */ 
/*     */           
/*     */           case 35:
/* 220 */             if (this.rt.getResult(node.getLabel(), formulaId) == 1) {
/* 221 */               ret = true;
/* 222 */             } else if (this.rt.getResult(node.getLabel(), formulaId) == 0) {
/* 223 */               ret = false;
/*     */             } else {
/* 225 */               Stack witness = new Stack();
/* 226 */               ret = checkEU(node, formulaId, witness, new Stack(), new HashSet());
/* 227 */               this.lastFormula = formulaId;
/* 228 */               if (!witness.isEmpty()) {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 233 */                 this.lastSequenz = witness;
/*     */               } else {
/* 235 */                 this.lastSequenz = null;
/*     */               } 
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 30:
/* 243 */             ret = false;
/* 244 */             out = node.out();
/* 245 */             while (out != null) {
/* 246 */               RGNode next = out.node(node);
/* 247 */               Marking m1 = next.getLabel();
/*     */               
/* 249 */               byte ok = this.rt.getResult(m1, i.left().getId());
/* 250 */               if (ok == 2) {
/* 251 */                 stack.add(new StackEntryCheck(node, formulaId));
/*     */                 
/* 253 */                 node = next;
/* 254 */                 formulaId = i.left().getId();
/*     */                 continue label138;
/*     */               } 
/* 257 */               if (ok == 1) {
/* 258 */                 ret = true;
/* 259 */                 this.decisions.push(new Decision(node.getLabel(), formulaId, next.getLabel()));
/*     */                 break;
/*     */               } 
/* 262 */               out = out.next();
/*     */             } 
/* 264 */             this.rt.setResult(m, formulaId, ret);
/*     */           
/*     */           case 33:
/* 267 */             ret = true;
/* 268 */             out = node.out();
/* 269 */             if (out == null) {
/* 270 */               byte ok = this.rt.getResult(m, i.left().getId());
/* 271 */               if (ok == 0) {
/* 272 */                 ret = false;
/* 273 */               } else if (ok == 1) {
/* 274 */                 ret = true;
/*     */               }
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 280 */               while (out != null) {
/* 281 */                 RGNode next = out.node(node);
/* 282 */                 Marking m1 = next.getLabel();
/*     */                 
/* 284 */                 byte ok = this.rt.getResult(m1, i.left().getId());
/* 285 */                 if (ok == 2) {
/* 286 */                   stack.add(new StackEntryCheck(node, formulaId));
/*     */                   
/* 288 */                   node = next;
/* 289 */                   formulaId = i.left().getId();
/*     */                   continue label138;
/*     */                 } 
/* 292 */                 if (ok == 0) {
/* 293 */                   ret = false;
/* 294 */                   this.decisions.push(new Decision(node.getLabel(), formulaId, next.getLabel()));
/*     */                   break;
/*     */                 } 
/* 297 */                 out = out.next();
/*     */               } 
/*     */             } 
/* 300 */             this.rt.setResult(m, formulaId, ret);
/*     */           
/*     */           case 5:
/* 303 */             if (this.rt.getResult(node.getLabel(), n.left().getId()) == 1) {
/* 304 */               ret = false;
/* 305 */             } else if (this.rt.getResult(node.getLabel(), n.left().getId()) == 0) {
/* 306 */               ret = true;
/*     */             } else {
/* 308 */               stack.add(new StackEntryCheck(node, formulaId));
/* 309 */               formulaId = n.left().getId();
/*     */               break;
/*     */             } 
/* 312 */             this.rt.setResult(node.getLabel(), formulaId, ret);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           default:
/* 318 */             sec = stack.pop();
/* 319 */             formulaId = sec.formulaId;
/* 320 */             node = sec.n; break;
/* 321 */         }  if (this.rt.getResult(start.getLabel(), startId) != 2) {
/* 322 */           if (this.rt.getResult(start.getLabel(), startId) == 1) { ret = true; }
/* 323 */           else { ret = false; }
/* 324 */            if (node.equals(this.firstNode) && this.firstFormula == formulaId) {
/* 325 */             if (Options.debug) System.out.println("decisions:");
/*     */ 
/*     */             
/* 328 */             m = this.firstNode.getLabel();
/* 329 */             while (!this.decisions.isEmpty()) {
/* 330 */               Decision decision = this.decisions.pop();
/* 331 */               if (decision.begin.equals(m)) {
/* 332 */                 if (Options.debug) System.out.println(decision); 
/* 333 */                 m = decision.end;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 341 */           return ret;
/*     */         } 
/*     */       } 
/*     */     }  } private String printStack(Stack st) {
/* 345 */     StringBuffer ret = new StringBuffer();
/* 346 */     for (Iterator<StackEntry> it = st.iterator(); it.hasNext(); ) {
/* 347 */       StackEntry ste = it.next();
/*     */       
/* 349 */       ret.append(this.pn.toLabel((State)ste.n.getLabel()));
/* 350 */       ret.append(";");
/*     */     } 
/* 352 */     return ret.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkAU(RGNode node, int formulaId, Stack<StackEntry> auStack, Stack<RGNode> stack, HashSet<RGNode> visited) {
/* 357 */     RGNode start = node;
/* 358 */     boolean ret = false;
/* 359 */     RGEdge out = node.out;
/* 360 */     auStack.push(new StackEntry(node, out));
/*     */     
/* 362 */     int count = 0;
/* 363 */     boolean finished = false;
/*     */     while (true) {
/* 365 */       boolean jump = false;
/* 366 */       if (!visited.contains(node)) {
/*     */         
/* 368 */         stack.push(node);
/*     */         
/* 370 */         Marking m = node.getLabel();
/*     */         
/* 372 */         visited.add(node);
/*     */         
/* 374 */         Node n = this.formula.getFormula(formulaId);
/* 375 */         InternalNode i = (InternalNode)n;
/*     */         
/* 377 */         if (this.rt.getResult(m, formulaId) == 1) {
/* 378 */           out = null;
/*     */         }
/* 380 */         else if (check(node, i.right().getId())) {
/* 381 */           out = null;
/*     */         } else {
/*     */           
/* 384 */           ret = check(node, i.left().getId());
/* 385 */           if (!ret || out == null) {
/* 386 */             this.rt.setResult(node.getLabel(), formulaId, false);
/* 387 */             RGNode q = null;
/*     */             
/* 389 */             for (Iterator<StackEntry> it = auStack.iterator(); it.hasNext(); ) {
/* 390 */               StackEntry auSte = it.next();
/* 391 */               this.rt.setResult(auSte.n.getLabel(), formulaId, false);
/*     */             } 
/*     */             
/* 394 */             this.decisions.push(new Decision(start.getLabel(), formulaId, node.getLabel()));
/* 395 */             return false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 402 */       if (out != null)
/* 403 */       { RGNode next = out.node(node);
/* 404 */         Marking m1 = next.getLabel();
/* 405 */         if (!visited.contains(next)) {
/* 406 */           auStack.push(new StackEntry(node, out));
/* 407 */           node = next;
/* 408 */           out = next.out;
/*     */         } else {
/* 410 */           if (this.rt.getResult(next.getLabel(), formulaId) != 1) {
/* 411 */             this.rt.setResult(node.getLabel(), formulaId, false);
/* 412 */             RGNode q = null;
/*     */             
/* 414 */             for (Iterator<StackEntry> it = auStack.iterator(); it.hasNext(); ) {
/* 415 */               StackEntry auSte = it.next();
/* 416 */               this.rt.setResult(auSte.n.getLabel(), formulaId, false);
/*     */             } 
/*     */             
/* 419 */             this.decisions.push(new Decision(start.getLabel(), formulaId, node.getLabel()));
/* 420 */             return false;
/*     */           } 
/*     */           
/* 423 */           out = out.next();
/*     */         }  }
/* 425 */       else { this.rt.setResult(node.getLabel(), formulaId, true);
/* 426 */         if (node.equals(start)) finished = true;
/*     */         
/* 428 */         StackEntry ste = auStack.pop();
/* 429 */         node = ste.n;
/* 430 */         out = ste.e;
/* 431 */         if (out != null) {
/* 432 */           out = out.next();
/*     */         } }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 438 */       if (finished && auStack.isEmpty()) {
/* 439 */         return this.rt.setResult(node.getLabel(), formulaId, true);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkEU(RGNode node, int formulaId, Stack<StackEntry> euStack, Stack<RGNode> stack, HashSet<RGNode> visited) {
/* 447 */     RGNode start = node;
/* 448 */     int startId = formulaId;
/*     */     
/* 450 */     boolean ret = false;
/* 451 */     RGEdge out = node.out;
/* 452 */     euStack.push(new StackEntry(node, out));
/* 453 */     int count = 0;
/* 454 */     boolean finished = false;
/*     */     
/*     */     do {
/* 457 */       ret = true;
/* 458 */       if (!visited.contains(node)) {
/*     */         
/* 460 */         stack.push(node);
/* 461 */         visited.add(node);
/* 462 */         Node n = this.formula.getFormula(formulaId);
/*     */         
/* 464 */         if (this.rt.getResult(node.getLabel(), formulaId) != 0) {
/*     */           
/* 466 */           if (this.rt.getResult(node.getLabel(), formulaId) == 1) {
/* 467 */             RGNode q = null;
/* 468 */             euStack.push(new StackEntry(node, null));
/* 469 */             for (Iterator<StackEntry> it = euStack.iterator(); it.hasNext(); ) {
/* 470 */               StackEntry euSte = it.next();
/* 471 */               this.rt.setResult(euSte.n.getLabel(), formulaId, true);
/*     */             } 
/* 473 */             this.decisions.push(new Decision(start.getLabel(), formulaId, node.getLabel()));
/* 474 */             return true;
/*     */           } 
/* 476 */           ret = check(node, n.right().getId());
/* 477 */           if (ret) {
/*     */             
/* 479 */             RGNode q = null;
/* 480 */             euStack.push(new StackEntry(node, null));
/* 481 */             for (Iterator<StackEntry> it = euStack.iterator(); it.hasNext(); ) {
/* 482 */               StackEntry euSte = it.next();
/* 483 */               this.rt.setResult(euSte.n.getLabel(), formulaId, true);
/*     */             } 
/* 485 */             this.decisions.push(new Decision(start.getLabel(), formulaId, node.getLabel()));
/* 486 */             return this.rt.setResult(node.getLabel(), formulaId, true);
/*     */           } 
/* 488 */           ret = check(node, n.left().getId());
/*     */           
/* 490 */           if (!ret) return this.rt.setResult(node.getLabel(), formulaId, false);
/*     */         
/*     */         } 
/*     */       } 
/* 494 */       if (out != null) {
/*     */         
/* 496 */         RGNode next = out.node(node);
/* 497 */         Marking m1 = next.getLabel();
/* 498 */         byte nextResult = this.rt.getResult(next.getLabel(), formulaId);
/* 499 */         if (nextResult == 1) {
/*     */           
/* 501 */           this.rt.setResult(node.getLabel(), formulaId, true);
/* 502 */           RGNode q = null;
/* 503 */           euStack.push(new StackEntry(node, null));
/* 504 */           for (Iterator<StackEntry> it = euStack.iterator(); it.hasNext(); ) {
/* 505 */             StackEntry euSte = it.next();
/* 506 */             this.rt.setResult(euSte.n.getLabel(), formulaId, true);
/*     */           } 
/* 508 */           this.decisions.push(new Decision(start.getLabel(), formulaId, node.getLabel()));
/* 509 */           return true;
/* 510 */         }  if (nextResult == 0) {
/* 511 */           visited.add(next);
/*     */         }
/* 513 */         if (!visited.contains(next)) {
/* 514 */           euStack.push(new StackEntry(node, out));
/* 515 */           node = next;
/* 516 */           out = next.out;
/*     */         } else {
/*     */           
/* 519 */           out = out.next();
/*     */         } 
/*     */       } else {
/* 522 */         if (node.equals(start)) finished = true; 
/* 523 */         RGNode top = ((StackEntry)euStack.peek()).n;
/* 524 */         if (node.sccNumber != top.sccNumber) {
/* 525 */           RGNode q = null;
/* 526 */           if (!stack.isEmpty())
/* 527 */             q = stack.pop(); 
/* 528 */           while (!stack.isEmpty() && !node.equals(q)) {
/* 529 */             q = stack.peek();
/* 530 */             stack.pop();
/* 531 */             Marking mq = q.getLabel();
/* 532 */             this.rt.setResult(mq, formulaId, false);
/*     */           } 
/*     */         } 
/* 535 */         StackEntry ste = euStack.pop();
/* 536 */         node = ste.n;
/* 537 */         out = ste.e;
/* 538 */         if (out != null) {
/* 539 */           out = out.next();
/*     */         }
/*     */       }
/*     */     
/*     */     }
/* 544 */     while (!finished || !euStack.isEmpty());
/*     */     
/* 546 */     return this.rt.setResult(node.getLabel(), formulaId, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkProp(RGNode node, Leaf l) {
/* 551 */     boolean ret = false;
/* 552 */     Marking m = node.getLabel();
/* 553 */     if (l.op() == 3) {
/* 554 */       ret = true;
/* 555 */     } else if (l.op() == 4) {
/* 556 */       ret = false;
/*     */     } else {
/*     */       
/* 559 */       int id = l.id();
/* 560 */       int value = l.v();
/* 561 */       if (l.isPlaceId) {
/* 562 */         if (Options.debug) System.out.println("placeID"); 
/* 563 */         value = m.getTokenById(value);
/*     */       } 
/* 565 */       int token = m.getTokenById(id);
/*     */ 
/*     */       
/* 568 */       switch (l.op()) {
/*     */         case 21:
/* 570 */           ret = (token > value);
/*     */           break;
/*     */         
/*     */         case 22:
/* 574 */           ret = (token < value);
/*     */           break;
/*     */         
/*     */         case 23:
/* 578 */           ret = (token == value);
/*     */           break;
/*     */         
/*     */         case 20:
/* 582 */           ret = (token >= value);
/*     */           break;
/*     */         
/*     */         case 18:
/* 586 */           ret = (token <= value);
/*     */           break;
/*     */         
/*     */         case 19:
/* 590 */           ret = (token != value);
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 598 */     return ret;
/*     */   }
/*     */   
/*     */   private class StackEntry
/*     */   {
/*     */     RGEdge e;
/*     */     RGNode n;
/*     */     
/*     */     public StackEntry(RGNode n, RGEdge e) {
/* 607 */       this.e = e;
/* 608 */       this.n = n;
/*     */     }
/*     */   }
/*     */   
/*     */   public class Decision {
/*     */     Marking begin;
/*     */     int formula;
/*     */     Marking end;
/*     */     
/*     */     public Decision(Marking b, int f, Marking e) {
/* 618 */       this.begin = b;
/* 619 */       this.formula = f;
/* 620 */       this.end = e;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/LocalCTLChecker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */