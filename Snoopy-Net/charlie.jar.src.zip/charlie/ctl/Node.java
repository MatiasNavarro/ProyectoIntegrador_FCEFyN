/*    */ package charlie.ctl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class Node
/*    */ {
/*    */   boolean negate = false;
/*    */   
/*    */   public abstract Node right();
/*    */   
/*    */   public abstract Node left();
/*    */   
/*    */   public abstract void setRight(Node paramNode);
/*    */   
/*    */   public boolean negated() {
/* 18 */     return this.negate;
/*    */   } public abstract void setLeft(Node paramNode); public abstract void setId(int paramInt); public abstract int getId();
/*    */   public abstract int op();
/*    */   public void negate() {
/* 22 */     this.negate = !this.negate;
/*    */   }
/*    */   
/*    */   public abstract Node copy();
/*    */   
/*    */   public abstract String toString();
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/ctl/Node.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */