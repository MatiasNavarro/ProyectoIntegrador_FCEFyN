/*     */ package charlie;
/*     */ import GUI.App;
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.preference.CharlieFilterProperties;
/*     */ import GUI.preference.FilterFactory;
/*     */ import GUI.preference.FilterProperties;
/*     */ import GUI.util.TextFile;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.Initiator;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.analyzer.deadlock.DeadlockAnalyzer;
/*     */ import charlie.analyzer.deadlock.DeadlockOptions;
/*     */ import charlie.analyzer.deadlock.DeadlockSet;
/*     */ import charlie.analyzer.invariant.DependentSet;
/*     */ import charlie.analyzer.invariant.DependentSetAnalyzer;
/*     */ import charlie.analyzer.invariant.DependentSetOptions;
/*     */ import charlie.analyzer.invariant.InvOptions;
/*     */ import charlie.analyzer.invariant.InvariantAnalyzer;
/*     */ import charlie.analyzer.invariant.PInvariantSet;
/*     */ import charlie.analyzer.invariant.TInvariantSet;
/*     */ import charlie.analyzer.mc.Formula;
/*     */ import charlie.analyzer.mc.MCAnalyzer;
/*     */ import charlie.analyzer.mc.MCOptions;
/*     */ import charlie.analyzer.path.PathComputationOptions;
/*     */ import charlie.analyzer.path.PathConstruction;
/*     */ import charlie.analyzer.rg.ConstructionOptions;
/*     */ import charlie.analyzer.rg.RGAnalyzer;
/*     */ import charlie.analyzer.structural.StructuralAnalyzer;
/*     */ import charlie.analyzer.structural.StructuralOptionSet;
/*     */ import charlie.analyzer.trap.Trap;
/*     */ import charlie.analyzer.trap.TrapAnalyzer;
/*     */ import charlie.analyzer.trap.TrapOptions;
/*     */ import charlie.plugin.Plugin;
/*     */ import charlie.plugin.PluginLoader;
/*     */ import charlie.plugin.analyzer.PluginAnalyzer;
/*     */ import charlie.plugin.analyzer.PluginOptionSet;
/*     */ import charlie.plugin.analyzer.PluginResult;
/*     */ import charlie.plugin.analyzer.PluginRuleExtender;
/*     */ import charlie.pn.ConstantInterface;
/*     */ import charlie.pn.DefaultConstantInterface;
/*     */ import charlie.pn.Out;
/*     */ import charlie.pn.PetriNetReader;
/*     */ import charlie.pn.PetriNetReaderFactory;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.ResultContradictionException;
/*     */ import charlie.pn.ResultManager;
/*     */ import charlie.pn.Results;
/*     */ import charlie.pn.rules.Rule;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGraph;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class Charlie implements Initiator {
/*  62 */   private static final Log LOG = LogFactory.getLog(Charlie.class);
/*     */   
/*     */   static final String TRAP = "Traps trap traps Trap TRAP";
/*     */   
/*     */   static final String DEADLOCK = "Deadlock deadlocks Siphon siphon Siphons siphons";
/*     */   
/*     */   static final String PINVARIANT = "PInvariants PInvariant p-invariant pinv pInvariant";
/*     */   static final String TINVARIANT = "TInvariant t-invariant tinv tInvariant";
/*     */   static final String DEPENDENT = "dependentsets DependentSets dependent-sets dependentsets dsets";
/*     */   static final String RGRAPH = "Rgraph RG rg";
/*     */   static final String TIMED_RGRAPH = "tRGraph tRG tRg trg";
/*     */   static final String NETFILE = "netfile";
/*     */   static final String STRUCTURAL = "PROPS props";
/*     */   static final String PATH = "path PATH Path ";
/*     */   static final String MC = "mc MC modelchecking formula";
/*  77 */   private String[] arguments = null;
/*     */   private boolean sequential = true;
/*  79 */   private StringBuffer output = new StringBuffer();
/*  80 */   private PlaceTransitionNet pn = null;
/*  81 */   private Results results = new Results();
/*  82 */   private int waitCount = 0;
/*     */   private boolean waiting = true;
/*  84 */   private File outputFile = null;
/*     */   
/*  86 */   private final String versionString = String.format("Charlie V2.0 - (%s)", new Object[] { App.class
/*  87 */         .getPackage().getImplementationVersion() });
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private final List<PluginAnalyzer> loadedPluginAnalyzerList = new ArrayList<>();
/*     */   
/*     */   public Charlie(String[] arguments) {
/*  95 */     this.arguments = arguments;
/*  96 */     initialize();
/*  97 */     DebugCounter.printImmediately = false;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 101 */     if (args.length == 0) {
/* 102 */       Out.errPrintln("No options: use /? or --help to display a help screen!");
/* 103 */       System.exit(1);
/*     */     } 
/*     */     
/* 106 */     Charlie c = new Charlie(args);
/* 107 */     c.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 115 */     FilterFactory.setFilterProperties((FilterProperties)new CharlieFilterProperties());
/*     */     
/* 117 */     RGAnalyzer.register();
/* 118 */     TrapAnalyzer.register();
/* 119 */     DeadlockAnalyzer.register();
/* 120 */     InvariantAnalyzer.register();
/* 121 */     DependentSetAnalyzer.register();
/* 122 */     MCAnalyzer.register();
/* 123 */     PathConstruction.register();
/* 124 */     StructuralAnalyzer.register();
/* 125 */     ResultManager.gui = false;
/*     */ 
/*     */     
/* 128 */     initializePlugins();
/*     */   }
/*     */   
/*     */   private void initializePlugins() {
/* 132 */     PluginLoader pluginLoader = new PluginLoader();
/* 133 */     List<Plugin> pluginList = pluginLoader.getPluginList();
/*     */     
/* 135 */     for (Plugin plugin : pluginList) {
/* 136 */       for (String clazzName : plugin.getAnalyzerClassNameList()) {
/* 137 */         PluginAnalyzer analyzer = plugin.getNewAnalyzer(clazzName);
/* 138 */         if (!analyzer.registerAnalyzer()) {
/*     */           
/* 140 */           Out.errPrint(String.format("The analyzer '%s' (%s) could not register itself.\n", new Object[] { analyzer
/* 141 */                   .getName(), analyzer
/* 142 */                   .getClass().getName() }));
/* 143 */           Out.errPrintln("Stopped trying to load the plugin.");
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 149 */         this.loadedPluginAnalyzerList.add(analyzer);
/*     */         
/* 151 */         if (LOG.isDebugEnabled()) {
/* 152 */           LOG.debug("Added analyzer: " + analyzer.getName());
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 157 */       for (String clazzName : plugin.getRuleEnhancerClassNameList()) {
/* 158 */         PluginRuleExtender ruleEnhancer = plugin.getNewRuleEnhancer(clazzName);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 163 */         for (PluginResult result : ruleEnhancer.getAddionionalResults()) {
/* 164 */           if (!Results.addFurtherResults(result.getKey(), result.getAbbreviation(), result.getTooltip(), result.getDescription(), result.isVisible())) {
/* 165 */             Out.errPrintln(String.format("The further result %s could not be added.", new Object[] { result.toString() }));
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 173 */         for (Rule rule : ruleEnhancer.getAdditionalRules()) {
/* 174 */           ResultManager.addRule(rule);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void start() {
/* 181 */     PetriNetReaderFactory.initReaders();
/* 182 */     ArrayList<OptionSet> optionList = new ArrayList<>();
/* 183 */     ArrayList<String> stringList = new ArrayList<>();
/* 184 */     String s = "";
/* 185 */     Out.println("passed parameters:\n");
/* 186 */     for (String string : this.arguments) {
/* 187 */       s = s + string + " ";
/*     */     }
/* 189 */     if (s.contains("/?") || s.contains("--help")) {
/* 190 */       String v = "";
/* 191 */       v = OptionSet.getValue(s, "help", v);
/* 192 */       help(v);
/*     */       
/* 194 */       System.exit(0);
/* 195 */     } else if (s.contains("--version")) {
/* 196 */       version();
/*     */       
/* 198 */       System.exit(0);
/*     */     } 
/* 200 */     Out.println(s);
/* 201 */     File netFile = null;
/* 202 */     netFile = OptionSet.getValue(s, "netfile", netFile);
/* 203 */     if (netFile == null) {
/* 204 */       Out.println("Error No net-file specified. or netfile cannot be found\nUse --netfile=<file> !");
/* 205 */       System.exit(2);
/*     */     } else {
/* 207 */       Out.println("NETFILE : " + netFile.toString());
/* 208 */       this.pn = loadNet(netFile);
/* 209 */       if (this.pn == null) {
/* 210 */         Out.errPrintln("Could not read netfile: " + netFile.toString() + "!");
/* 211 */         help(null);
/*     */         
/* 213 */         System.exit(3);
/*     */       } 
/*     */     } 
/* 216 */     String outputfilestring = OptionSet.getValue(s, "outputfile", "");
/* 217 */     Out.println("outputfilestring = " + outputfilestring + "\n");
/* 218 */     if (outputfilestring != null && outputfilestring.length() > 0) {
/* 219 */       this.outputFile = new File(outputfilestring);
/*     */     }
/* 221 */     if (this.outputFile != null) {
/* 222 */       Out.print(String.format("Using outputfile: %s%n", new Object[] { this.outputFile.getName() }));
/*     */     }
/* 224 */     else if (s.contains("--outputfile=")) {
/* 225 */       int index = s.indexOf("--outputfile=");
/* 226 */       int index2 = s.indexOf("--", index + 1);
/* 227 */       String fN = s.substring("--outputfile=".length(), index2);
/* 228 */       Out.print(String.format("outputfile: %s%n", new Object[] { fN }));
/* 229 */       this.outputFile = new File(fN);
/* 230 */       if (this.outputFile == null) {
/* 231 */         Out.println("could not determine outputfile location!");
/* 232 */         System.exit(4);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 237 */     this.sequential = OptionSet.getValue(s, "sequential", true);
/*     */     
/* 239 */     int nIndex = s.indexOf("--sequential=");
/* 240 */     int sIndex = s.indexOf("--", nIndex + 2) - 1;
/* 241 */     if (sIndex < 0) {
/* 242 */       sIndex = s.length() - 1;
/*     */     } else {
/* 244 */       sIndex--;
/*     */     } 
/* 246 */     if (nIndex >= 0 && sIndex >= 0) {
/* 247 */       s = s.substring(0, nIndex) + s.substring(sIndex + 1);
/*     */     }
/* 249 */     s = s.trim();
/*     */ 
/*     */ 
/*     */     
/* 253 */     Out.print(String.format("parameterstring before tokenizer: %s%n", new Object[] { s }));
/* 254 */     stringList = createAnalyzerParameterList(s);
/* 255 */     Out.print(String.format("stringlist: %s%n", new Object[] { stringList.toString() }));
/* 256 */     int j = 0;
/* 257 */     OptionSet options = null;
/* 258 */     OptionSet firstOptions = null;
/* 259 */     OptionSet lastOptions = null;
/* 260 */     for (String str : stringList) {
/* 261 */       j++;
/*     */ 
/*     */       
/* 264 */       String analyze = null;
/* 265 */       analyze = OptionSet.getValue(str, "analyze", analyze);
/* 266 */       if (analyze == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 270 */       Out.println("analyze = " + analyze);
/* 271 */       options = getOptionSet(analyze);
/* 272 */       if (options != null) {
/*     */         
/* 274 */         if (!options.initializeByString(str)) {
/* 275 */           Out.print(String.format("OptionSet could not be initialized by arguments:\nOptionSet: %s\nparamaters: %s\n", new Object[] { options
/* 276 */                   .getClass().getName(), str }));
/* 277 */           System.exit(5); continue;
/*     */         } 
/* 279 */         options.initiator = this;
/*     */         
/* 281 */         if (options.beforeSet == null) {
/* 282 */           options.setObjectToAnalyze(this.pn);
/*     */         }
/* 284 */         if (options.beforeSet != null) {
/*     */           
/* 286 */           if (!this.sequential) {
/*     */ 
/*     */             
/* 289 */             OptionSet temp = optionList.get(optionList.size() - 1);
/* 290 */             for (OptionSet oBeforeSet : options.beforeSet) {
/* 291 */               if (temp.nextStage == null && 
/* 292 */                 oBeforeSet != null) {
/* 293 */                 if (temp != null && temp
/* 294 */                   .getClass().getName().equals(oBeforeSet.getClass().getName())) {
/* 295 */                   temp.nextStage = options;
/*     */                 } else {
/* 297 */                   Out.errPrint(String.format("optionset %s requires a %s as before-option set%n", new Object[] { options
/* 298 */                           .getClass().getName(), oBeforeSet
/* 299 */                           .getClass().getName() }));
/* 300 */                   System.exit(6);
/*     */                 } 
/*     */               }
/*     */             } 
/*     */           } else {
/*     */             
/* 306 */             for (OptionSet oBeforeSet : options.beforeSet) {
/* 307 */               if (lastOptions.nextStage == null && 
/* 308 */                 oBeforeSet != null) {
/* 309 */                 if (lastOptions != null && lastOptions
/* 310 */                   .getClass().getName().equals(oBeforeSet.getClass().getName())) {
/* 311 */                   lastOptions.nextStage = options;
/*     */                 } else {
/* 313 */                   Out.errPrint(String.format("optionset %s requires a %s as before-option set%n", new Object[] { options
/* 314 */                           .getClass().getName(), oBeforeSet
/* 315 */                           .getClass().getName() }));
/* 316 */                   System.exit(7);
/*     */                 }
/*     */               
/*     */               }
/*     */             } 
/*     */           } 
/* 322 */         } else if (!this.sequential) {
/* 323 */           optionList.add(options);
/*     */         } else {
/* 325 */           if (firstOptions == null) {
/* 326 */             firstOptions = options;
/*     */           }
/* 328 */           if (lastOptions == null) {
/* 329 */             lastOptions = options;
/*     */           } else {
/* 331 */             lastOptions.nextStage = options;
/* 332 */             lastOptions = options;
/*     */           } 
/*     */         } 
/* 335 */         Out.print(String.format("analyzing: %s%n", new Object[] { analyze }));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 344 */     if (this.sequential) {
/* 345 */       this.waitCount = 1;
/* 346 */       if (firstOptions != null) {
/* 347 */         AnalyzerManagerFactory.getAnalyzerManager().compute(firstOptions);
/*     */       } else {
/* 349 */         Out.errPrintln("nothing to compute, quitting");
/* 350 */         System.exit(10);
/*     */       } 
/*     */     } else {
/* 353 */       Out.println("computing parallel");
/* 354 */       this.waitCount = optionList.size();
/* 355 */       if (this.waitCount == 0) {
/* 356 */         Out.errPrintln("nothing to compute, quitting");
/* 357 */         System.exit(10);
/*     */       } 
/*     */       
/* 360 */       for (OptionSet set : optionList) {
/* 361 */         AnalyzerManagerFactory.getAnalyzerManager().compute(set);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 366 */     while (this.waiting) {
/* 367 */       wait(3000L);
/* 368 */       Out.print(".");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 373 */     if (this.outputFile != null) {
/* 374 */       Out.print(String.format("Writing output to file: %s%n", new Object[] { this.outputFile.getName() }));
/* 375 */       TextFile.writeToFile(this.outputFile, this.output.toString(), true);
/*     */     }
/*     */     else {
/*     */       
/* 379 */       Out.println("Displaying net properties");
/* 380 */       Out.println(this.results.toString());
/*     */     } 
/* 382 */     Out.println("All analyzers have finished Goodbye!");
/*     */ 
/*     */ 
/*     */     
/* 386 */     System.exit(0);
/*     */   }
/*     */   public OptionSet getOptionSet(String analyze) {
/*     */     PluginOptionSet pluginOptionSet;
/* 390 */     OptionSet options = null;
/* 391 */     if ("Traps trap traps Trap TRAP".contains(analyze)) {
/* 392 */       TrapOptions trapOptions = new TrapOptions();
/* 393 */       trapOptions.setResultObject(new Trap());
/* 394 */     } else if ("Deadlock deadlocks Siphon siphon Siphons siphons".contains(analyze)) {
/* 395 */       DeadlockOptions deadlockOptions = new DeadlockOptions();
/* 396 */       deadlockOptions.setResultObject(new DeadlockSet());
/* 397 */     } else if ("PInvariants PInvariant p-invariant pinv pInvariant".contains(analyze)) {
/* 398 */       InvOptions invOptions = new InvOptions();
/* 399 */       invOptions.setComputeTInvariants(false);
/* 400 */       invOptions.setResultObject(new PInvariantSet());
/* 401 */     } else if ("TInvariant t-invariant tinv tInvariant".contains(analyze)) {
/* 402 */       InvOptions invOptions = new InvOptions();
/* 403 */       invOptions.setComputeTInvariants(true);
/* 404 */       invOptions.setResultObject(new TInvariantSet());
/* 405 */     } else if ("dependentsets DependentSets dependent-sets dependentsets dsets".contains(analyze)) {
/* 406 */       DependentSetOptions dependentSetOptions = new DependentSetOptions();
/* 407 */       dependentSetOptions.setResultObject(new DependentSet());
/* 408 */       dependentSetOptions.setObjectToAnalyze(null);
/* 409 */     } else if ("Rgraph RG rg".contains(analyze)) {
/* 410 */       ConstructionOptions constructionOptions = new ConstructionOptions();
/* 411 */       constructionOptions.setResultObject(new RGraph());
/* 412 */     } else if ("PROPS props".contains(analyze)) {
/* 413 */       StructuralOptionSet structuralOptionSet = new StructuralOptionSet();
/* 414 */       structuralOptionSet.setResultObject(this.pn);
/* 415 */     } else if ("mc MC modelchecking formula".contains(analyze)) {
/* 416 */       MCOptions mCOptions = new MCOptions();
/* 417 */       mCOptions.setResultObject(new Formula());
/* 418 */       mCOptions.setObjectToAnalyze(null);
/* 419 */     } else if ("path PATH Path ".contains(analyze)) {
/* 420 */       PathComputationOptions pathComputationOptions = new PathComputationOptions();
/* 421 */       pathComputationOptions.setResultObject(new Path());
/* 422 */       pathComputationOptions.setObjectToAnalyze(null);
/*     */     } else {
/*     */       
/* 425 */       boolean found = false;
/* 426 */       for (PluginAnalyzer analyzer : this.loadedPluginAnalyzerList) {
/* 427 */         String[] invokedBy = analyzer.invokedBy();
/* 428 */         for (String s : invokedBy) {
/* 429 */           if (s.equals(analyze) || s.equals("--" + analyze) || s.equals("-" + analyze)) {
/* 430 */             found = true;
/* 431 */             pluginOptionSet = analyzer.setupPluginOptionSet(this, this.pn);
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 437 */       if (!found) {
/* 438 */         Out.errPrintln("error : could not identify analyzer: " + analyze);
/* 439 */         return null;
/*     */       } 
/*     */     } 
/* 442 */     return (OptionSet)pluginOptionSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void version() {
/* 449 */     Out.println(this.versionString);
/*     */   }
/*     */   
/*     */   public void help(String whichHelp) {
/* 453 */     if (whichHelp == null || (whichHelp != null && whichHelp.equals(""))) {
/*     */       
/* 455 */       InputStream is = ClassLoader.getSystemResourceAsStream("resources/help.txt");
/* 456 */       if (is == null) {
/* 457 */         is = ClassLoader.getSystemResourceAsStream("jar:file:text_charliev1_1.jar!/resources/help.txt");
/*     */       }
/*     */       try {
/* 460 */         if (is != null) {
/* 461 */           BufferedReader br = new BufferedReader(new InputStreamReader(is));
/* 462 */           String s = br.readLine();
/* 463 */           while (s != null) {
/* 464 */             s = br.readLine();
/* 465 */             Out.println(s);
/*     */           } 
/*     */         } else {
/* 468 */           Out.println("help.txt not found in resources/help.txt");
/*     */         } 
/* 470 */       } catch (Exception e) {
/* 471 */         Out.println("help.txt not found in resources/help.txt\n" + e.getMessage());
/*     */       } 
/*     */       
/* 474 */       Out.println("single option set help(s)\n");
/* 475 */       Out.println(StructuralOptionSet.getHelpString());
/* 476 */       Out.println(ConstructionOptions.getHelpString());
/* 477 */       Out.println(InvOptions.getHelpString());
/* 478 */       Out.println(DependentSetOptions.getHelpString());
/* 479 */       Out.println(DeadlockOptions.getHelpString());
/* 480 */       Out.println(TrapOptions.getHelpString());
/* 481 */       Out.println(PathComputationOptions.getHelpString());
/* 482 */       Out.println(MCOptions.getHelpString());
/*     */       
/* 484 */       printPluginHelp();
/*     */     } else {
/* 486 */       OptionSet o = getOptionSet(whichHelp);
/* 487 */       if (o != null) {
/* 488 */         if (o instanceof StructuralOptionSet) {
/* 489 */           Out.println(StructuralOptionSet.getHelpString());
/* 490 */         } else if (o instanceof ConstructionOptions) {
/* 491 */           Out.println(ConstructionOptions.getHelpString());
/* 492 */         } else if (o instanceof InvOptions) {
/* 493 */           Out.println(InvOptions.getHelpString());
/* 494 */         } else if (o instanceof DependentSetOptions) {
/* 495 */           Out.println(DependentSetOptions.getHelpString());
/* 496 */         } else if (o instanceof DeadlockOptions) {
/* 497 */           Out.println(DeadlockOptions.getHelpString());
/* 498 */         } else if (o instanceof TrapOptions) {
/* 499 */           Out.println(TrapOptions.getHelpString());
/* 500 */         } else if (o instanceof PathComputationOptions) {
/* 501 */           Out.println(PathComputationOptions.getHelpString());
/* 502 */         } else if (o instanceof MCOptions) {
/* 503 */           Out.println(MCOptions.getHelpString());
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 508 */         boolean found = false;
/* 509 */         for (PluginAnalyzer analyzer : this.loadedPluginAnalyzerList) {
/* 510 */           String[] invokedBy = analyzer.invokedBy();
/* 511 */           for (String s : invokedBy) {
/* 512 */             if (s.equals(whichHelp) || s.equals("--" + whichHelp) || s.equals("-" + whichHelp)) {
/* 513 */               found = true;
/* 514 */               printPluginHelp(analyzer);
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */           
/* 521 */           if (found) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 526 */         if (!found) {
/* 527 */           help(null);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void printPluginHelp() {
/* 535 */     for (PluginAnalyzer analyzer : this.loadedPluginAnalyzerList) {
/* 536 */       printPluginHelp(analyzer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void printPluginHelp(PluginAnalyzer _analyzer) {
/* 543 */     PluginOptionSet optionSet = _analyzer.setupPluginOptionSet(this, this.pn);
/*     */ 
/*     */ 
/*     */     
/* 547 */     String headline = _analyzer.getName() + " options";
/* 548 */     Out.println(headline);
/*     */     
/* 550 */     for (int i = 0; i < headline.length(); i++) {
/* 551 */       System.out.print("-");
/*     */     }
/* 553 */     Out.println();
/*     */     
/* 555 */     if ((_analyzer.invokedBy()).length > 0) {
/* 556 */       StringBuffer buffer = new StringBuffer();
/* 557 */       buffer.append("Invoke analysis by typing ");
/* 558 */       for (int k = 0; k < (_analyzer.invokedBy()).length - 1; k++) {
/* 559 */         buffer.append(String.format("--analyze=%s or ", new Object[] { _analyzer.invokedBy()[k] }));
/*     */       } 
/* 561 */       buffer.append(String.format("--analyze=%s\n", new Object[] { _analyzer.invokedBy()[(_analyzer.invokedBy()).length - 1] }));
/* 562 */       Out.println(breakLine(buffer.toString(), 0, 80));
/*     */     } else {
/* 564 */       Out.println("There is no way to invoke this analyzer via the command line.");
/*     */     } 
/* 566 */     Out.println();
/*     */ 
/*     */ 
/*     */     
/* 570 */     String description = (String)optionSet.getHelpMap().get("description");
/*     */     
/* 572 */     String[] descr = description.split("\n");
/* 573 */     for (int j = 0; j < descr.length; j++) {
/* 574 */       Out.println(breakLine(descr[j], 0, 80));
/*     */     }
/* 576 */     Out.println();
/*     */ 
/*     */ 
/*     */     
/* 580 */     String fS = "%30s | %-30s\n";
/* 581 */     Out.print(String.format(fS, new Object[] { "option name", "option values" }));
/* 582 */     for (String key : optionSet.getHelpMap().keySet()) {
/*     */       
/* 584 */       if ("description".equals(key)) {
/*     */         continue;
/*     */       }
/*     */       
/* 588 */       String[] optionDescription = breakLine((String)optionSet.getHelpMap().get(key), 0, 30).split("\n");
/* 589 */       if (!key.startsWith("-"))
/*     */       {
/* 591 */         key = String.format("--%s", new Object[] { key });
/*     */       }
/* 593 */       Out.print(String.format(fS, new Object[] { key, optionDescription[0] }));
/* 594 */       for (int k = 1; k < optionDescription.length; k++) {
/* 595 */         Out.print(String.format(fS, new Object[] { "", optionDescription[k] }));
/*     */       } 
/*     */     } 
/* 598 */     Out.println();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String breakLine(String _line, int _startAt, int _maxWidth) {
/* 611 */     if (_startAt + _maxWidth > _line.length())
/*     */     {
/*     */       
/* 614 */       return _line;
/*     */     }
/*     */     
/* 617 */     StringBuffer buffer = new StringBuffer(_line);
/* 618 */     int breakpoint = _line.lastIndexOf(' ', _startAt + _maxWidth - 1);
/*     */ 
/*     */     
/* 621 */     if (breakpoint < _startAt)
/*     */     {
/*     */       
/* 624 */       return buffer.toString();
/*     */     }
/*     */     
/* 627 */     buffer.replace(breakpoint, breakpoint + 1, "\n");
/*     */     
/* 629 */     return breakLine(buffer.toString(), breakpoint, _maxWidth);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void analyzerHasFinished(Analyzer finished) {
/* 634 */     notify();
/* 635 */     if (this.waitCount > 0) {
/* 636 */       Out.print(String.format("\n----" + Integer.toString(this.waitCount) + " ----------------------\nanalyzerHasFinished: %s%n-------------------------------%n", new Object[] { finished.getName() }));
/* 637 */       if (!this.sequential) {
/* 638 */         this.output.append("\nResults:\n" + finished.getResults().toString() + "\n");
/* 639 */         this.output.append("\nOutput:\n" + finished.getResults().getOutput() + "\n");
/* 640 */         this.results.mergeWith(finished.getResults());
/*     */         
/* 642 */         Results applied = null;
/*     */         try {
/* 644 */           applied = ResultManager.applyRules(this.results, this.pn);
/* 645 */         } catch (ResultContradictionException e) {
/* 646 */           e.printStackTrace();
/*     */         } 
/* 648 */         if (applied != null) {
/* 649 */           this.results.mergeWith(applied);
/*     */         }
/*     */       } else {
/* 652 */         for (OptionSet set : finished.getOptionSet().getPreviousOptionSets()) {
/* 653 */           this.output.append("\nResults:\n" + set.getResults().toString() + "\n");
/* 654 */           this.output.append("\nOutput:\n" + set.getResults().getOutput() + "\n");
/* 655 */           this.results.mergeWith(set.getResults());
/* 656 */           Results results = null;
/*     */           try {
/* 658 */             results = ResultManager.applyRules(this.results, this.pn);
/* 659 */           } catch (ResultContradictionException e) {
/* 660 */             e.printStackTrace();
/*     */           } 
/* 662 */           if (results != null) {
/* 663 */             this.results.mergeWith(results);
/*     */           }
/*     */         } 
/* 666 */         this.output.append("\nResults:\n" + finished.getResults().toString() + "\n");
/* 667 */         this.output.append("\nOutput:\n" + finished.getResults().getOutput() + "\n");
/* 668 */         this.results.mergeWith(finished.getResults());
/* 669 */         Results applied = null;
/*     */         try {
/* 671 */           applied = ResultManager.applyRules(this.results, this.pn);
/* 672 */         } catch (ResultContradictionException e) {
/* 673 */           e.printStackTrace();
/*     */         } 
/* 675 */         if (applied != null) {
/* 676 */           this.results.mergeWith(applied);
/*     */         }
/*     */       } 
/*     */       
/* 680 */       this.output.append("\n----------------------\n");
/* 681 */       this.waitCount--;
/*     */     } 
/*     */     
/* 684 */     if (this.waitCount == 0) {
/* 685 */       this.waiting = false;
/*     */     }
/*     */   }
/*     */   
/*     */   private PlaceTransitionNet loadNet(File file) {
/* 690 */     PlaceTransitionNet pNet = null;
/* 691 */     String fileName = file.getName();
/* 692 */     String extension = fileName.substring(fileName.lastIndexOf("."));
/* 693 */     Out.println("try loading file: " + file.getAbsolutePath());
/* 694 */     Out.println("looking for reader for a " + extension + " file.");
/*     */     try {
/* 696 */       PetriNetReader pnr = PetriNetReaderFactory.getReader(extension);
/* 697 */       Out.println("Reader found :" + pnr.getClass().getName());
/* 698 */       pnr.init(file.getAbsolutePath(), (ConstantInterface)new DefaultConstantInterface());
/* 699 */       pnr.readNet();
/* 700 */       pNet = pnr.getPlaceTransitionNet();
/* 701 */       return pNet;
/* 702 */     } catch (Exception e) {
/* 703 */       Out.errPrintln("Could not load net, no reader found file:" + file.getName());
/* 704 */       PetriNetReaderFactory.printInfo();
/* 705 */       System.exit(1);
/* 706 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<String> createAnalyzerParameterList(String s) {
/* 714 */     ArrayList<String> list = new ArrayList<>();
/* 715 */     ArrayList<Integer> indexList = new ArrayList<>();
/* 716 */     int index = 0;
/*     */     
/* 718 */     while (index >= 0) {
/* 719 */       index = s.indexOf("--analyze=", index + 1);
/*     */       
/* 721 */       if (index >= 0) {
/* 722 */         indexList.add(new Integer(index));
/*     */       }
/*     */     } 
/*     */     
/* 726 */     index = 0;
/* 727 */     while (index + 1 < indexList.size()) {
/* 728 */       String tString = s.substring(((Integer)indexList.get(index)).intValue(), ((Integer)indexList.get(index + 1)).intValue() - 1);
/* 729 */       list.add(tString);
/* 730 */       index++;
/*     */     } 
/* 732 */     if (indexList.size() > 0 && (
/* 733 */       (Integer)indexList.get(indexList.size() - 1)).intValue() < s.length()) {
/* 734 */       list.add(s.substring(((Integer)indexList.get(indexList.size() - 1)).intValue()));
/*     */     }
/*     */     
/* 737 */     return list;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/Charlie.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */