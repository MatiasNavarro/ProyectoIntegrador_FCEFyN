/*     */ package charlie;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateCharlie
/*     */ {
/*  27 */   private static final Log LOG = LogFactory.getLog(UpdateCharlie.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String propertyFile = "resources/update.properties";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String VERSION_KEY = "version";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String UPDATE_SITE_KEY = "update.site";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private String updateSite = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String version;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private String availableVersion = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadProperties() throws IOException, UpdateFailedException {
/*  65 */     Properties props = new Properties();
/*  66 */     props.load(new FileInputStream("resources/update.properties"));
/*     */     
/*  68 */     this.version = props.getProperty("version");
/*  69 */     this.updateSite = props.getProperty("update.site", null);
/*     */     
/*  71 */     if (this.version == null) {
/*  72 */       throw new UpdateFailedException("Could not find the currently used version.");
/*     */     }
/*     */     
/*  75 */     if (this.updateSite == null) {
/*  76 */       throw new UpdateFailedException("Could not fine the site to get the updates from.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAvailableVersion() {
/*  86 */     return this.availableVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isUpdateAvailable() throws IOException {
/*  95 */     URL url = new URL(this.updateSite + "/version");
/*  96 */     BufferedReader versionReader = new BufferedReader(new InputStreamReader(url.openConnection().getInputStream()));
/*     */     
/*  98 */     this.availableVersion = null;
/*  99 */     String line = null;
/* 100 */     while ((line = versionReader.readLine()) != null) {
/* 101 */       if (!line.trim().equals("") && !line.startsWith("#")) {
/*     */         
/* 103 */         this.availableVersion = line;
/*     */         break;
/*     */       } 
/*     */     } 
/* 107 */     versionReader.close();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     if (this.availableVersion == null || compareVersion(this.version, this.availableVersion) >= 0) {
/* 113 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 117 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getNewFileName() throws IOException {
/* 127 */     URL url = new URL(this.updateSite + "/update");
/* 128 */     BufferedReader versionReader = new BufferedReader(new InputStreamReader(url.openConnection().getInputStream()));
/*     */     
/* 130 */     String updateName = null;
/* 131 */     String line = null;
/* 132 */     while ((line = versionReader.readLine()) != null) {
/* 133 */       if (!line.trim().equals("") && !line.startsWith("#")) {
/*     */         
/* 135 */         updateName = line;
/*     */         break;
/*     */       } 
/*     */     } 
/* 139 */     versionReader.close();
/*     */     
/* 141 */     if (updateName == null)
/*     */     {
/* 143 */       throw new IOException("Could not find the file name of the new version.");
/*     */     }
/*     */     
/* 146 */     return updateName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int compareVersion(String _oldVersion, String _newVersion) {
/* 159 */     if (_oldVersion.equals(_newVersion)) {
/* 160 */       return 0;
/*     */     }
/*     */     
/* 163 */     String[] vOld = _oldVersion.split("-");
/* 164 */     String[] vNew = _newVersion.split("-");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     Integer cOld = Integer.valueOf(vOld[1].replaceAll("\\D", ""));
/* 170 */     Integer cNew = Integer.valueOf(vNew[1].replaceAll("\\D", ""));
/*     */     
/* 172 */     return cOld.compareTo(cNew);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int performUpdate() throws IOException, UpdateFailedException {
/* 186 */     String updatedVersionName = getNewFileName();
/* 187 */     File downloadedFile = downloadAndStoreFile(updatedVersionName);
/*     */ 
/*     */ 
/*     */     
/* 191 */     Process p = Runtime.getRuntime().exec(new String[] { "java", "-jar", downloadedFile.getAbsolutePath() });
/*     */     try {
/* 193 */       return p.waitFor();
/* 194 */     } catch (InterruptedException ie) {
/* 195 */       LOG.error(ie.getMessage(), ie);
/*     */       
/* 197 */       p.destroy();
/*     */ 
/*     */       
/* 200 */       return -2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkForUpdates() throws IOException, UpdateFailedException {
/* 214 */     loadProperties();
/*     */ 
/*     */     
/* 217 */     return isUpdateAvailable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File downloadAndStoreFile(String _file) throws IOException {
/* 230 */     URL url = new URL(this.updateSite + "/" + _file);
/*     */     
/* 232 */     File tempFile = File.createTempFile("dl-", ".jar");
/*     */     
/* 234 */     InputStream input = new BufferedInputStream(url.openStream());
/* 235 */     OutputStream output = new BufferedOutputStream(new FileOutputStream(tempFile));
/*     */     
/*     */     try {
/* 238 */       byte[] buffer = new byte[1024];
/* 239 */       int read = -1;
/* 240 */       while ((read = input.read(buffer)) != -1) {
/* 241 */         output.write(buffer, 0, read);
/*     */       }
/*     */     } finally {
/* 244 */       input.close();
/* 245 */       output.close();
/*     */     } 
/*     */     
/* 248 */     return tempFile;
/*     */   }
/*     */   
/*     */   private String findCharlieJar() {
/* 252 */     String jarFile = ClassLoader.getSystemResource("charlie/" + UpdateCharlie.class.getSimpleName() + ".class").toString();
/*     */     
/* 254 */     if (jarFile.startsWith("jar://")) {
/* 255 */       jarFile.replace("jar://", "");
/*     */ 
/*     */       
/* 258 */       jarFile = jarFile.substring(jarFile.indexOf('!'));
/*     */     } 
/*     */     
/* 261 */     return jarFile;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 265 */     UpdateCharlie updater = new UpdateCharlie();
/* 266 */     updater.checkForUpdates();
/* 267 */     updater.performUpdate();
/*     */     
/* 269 */     System.out.println(updater.findCharlieJar());
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/UpdateCharlie.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */