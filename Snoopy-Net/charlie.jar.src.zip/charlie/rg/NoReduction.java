/*    */ package charlie.rg;
/*    */ 
/*    */ import charlie.ds.Stack;
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.pn.State;
/*    */ import charlie.pn.Transition;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoReduction
/*    */   implements Reduction
/*    */ {
/*    */   private final PlaceTransitionNet pn;
/*    */   
/*    */   public NoReduction(PlaceTransitionNet pn) {
/* 21 */     this.pn = pn;
/*    */   }
/*    */   
/*    */   public Collection<Transition> getTransitions(State m) {
/* 25 */     Collection<Transition> c = new Vector<>();
/* 26 */     for (Iterator<Transition> it = this.pn.getTransitions().iterator(); it.hasNext(); ) {
/* 27 */       Transition t = it.next();
/* 28 */       if (t.canFire(m)) {
/* 29 */         c.add(t);
/*    */       }
/*    */     } 
/* 32 */     return c;
/*    */   }
/*    */   
/*    */   public int getTransitions(State m, Stack<Transition> transitions) {
/* 36 */     int transitionsAdded = 0;
/* 37 */     for (Iterator<Transition> it = this.pn.getTransitions().iterator(); it.hasNext(); ) {
/* 38 */       Transition t = it.next();
/* 39 */       if (t.canFire(m)) {
/* 40 */         transitions.push(t);
/* 41 */         transitionsAdded++;
/*    */       } 
/*    */     } 
/* 44 */     return transitionsAdded;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/NoReduction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */