/*    */ package charlie.rg;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.pn.Transition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RGEdge
/*    */ {
/*    */   RGEdge next;
/*    */   RGNode dest;
/*    */   RGNode src;
/*    */   private final PlaceTransitionNet pn;
/*    */   
/*    */   public abstract String getLabel(PlaceTransitionNet paramPlaceTransitionNet);
/*    */   
/*    */   public abstract short getId();
/*    */   
/*    */   public abstract Transition[] getTransitions();
/*    */   
/*    */   public abstract int getDistance();
/*    */   
/*    */   public RGEdge(PlaceTransitionNet _pn, RGNode src, RGNode dest) {
/* 43 */     this.next = null;
/* 44 */     this.pn = _pn;
/* 45 */     this.dest = dest;
/* 46 */     this.src = src;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PlaceTransitionNet getPN() {
/* 55 */     return this.pn;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean isEqual(RGEdge paramRGEdge);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RGEdge next() {
/* 67 */     return this.next;
/*    */   }
/*    */   
/*    */   public void setNext(RGNode src, RGEdge next) {
/* 71 */     this.next = next;
/*    */   }
/*    */   
/*    */   public RGNode node(RGNode v) {
/* 75 */     return this.dest;
/*    */   }
/*    */   
/*    */   public RGNode getDestinationNode() {
/* 79 */     return this.dest;
/*    */   }
/*    */   
/*    */   public RGNode getSourceNode() {
/* 83 */     return this.src;
/*    */   }
/*    */   
/*    */   public abstract RGEdge copy();
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/RGEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */