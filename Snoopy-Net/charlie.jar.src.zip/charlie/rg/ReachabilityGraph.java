package charlie.rg;

import charlie.pn.ExceedsByteException;
import charlie.pn.SafetyException;
import java.util.Iterator;

public interface ReachabilityGraph {
  RGNode getFirst();
  
  RGNode getInitialState();
  
  int getNumberOfNodes();
  
  int getNumberOfEdges();
  
  int getNumberOfDeadStates();
  
  int getNumberOfStronglyConnectedComponents();
  
  Iterator iterator();
  
  RGNode getNode(String paramString) throws SafetyException, ExceedsByteException;
  
  void reduceSequences();
  
  void expandSequences() throws SafetyException, ExceedsByteException;
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/ReachabilityGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */