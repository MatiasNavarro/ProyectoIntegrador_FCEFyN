/*    */ package charlie.rg;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ 
/*    */ class ConcurrentEdge
/*    */   extends MultipleEdge
/*    */ {
/*    */   public ConcurrentEdge(PlaceTransitionNet _pn, RGNode from, RGNode to, RGEdge[] e) {
/*  9 */     super(_pn, from, to, e);
/*    */   }
/*    */ 
/*    */   
/*    */   public RGEdge copy() {
/* 14 */     return new ConcurrentEdge(getPN(), this.dest, this.d, this.edges);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getLabel(PlaceTransitionNet pn) {
/* 20 */     StringBuffer buf = new StringBuffer();
/* 21 */     buf.append("(");
/* 22 */     for (int i = 0; i < this.edges.length; i++) {
/* 23 */       buf.append(this.edges[i].getLabel(pn));
/* 24 */       if (i < this.edges.length - 1) {
/* 25 */         buf.append(" | ");
/*    */       }
/*    */     } 
/* 28 */     buf.append(")");
/* 29 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/ConcurrentEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */