/*     */ package charlie.rg;
/*     */ 
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimedEdge
/*     */   extends SimpleEdge
/*     */ {
/*  14 */   protected int timeTransition = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean infinite;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInfinite() {
/*  25 */     return this.infinite;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInfinite(boolean infinite) {
/*  35 */     this.infinite = infinite;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimedEdge(PlaceTransitionNet _pn, RGNode src, RGNode dest, short id, int timeTransition) {
/*  53 */     super(_pn, src, dest, id);
/*     */     
/*  55 */     this.timeTransition = timeTransition;
/*  56 */     this.src = src;
/*  57 */     this.infinite = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTimeTransition() {
/*  66 */     return this.timeTransition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeTransition(int timeTransition) {
/*  76 */     this.timeTransition = timeTransition;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel(PlaceTransitionNet pn) {
/*  82 */     String retString = "";
/*  83 */     if (this.timeTransition > 0) {
/*  84 */       retString = "[" + this.timeTransition + "] ";
/*     */     }
/*  86 */     if (this.id >= 0) {
/*  87 */       retString = retString + pn.getTransition(this.id).getName();
/*     */     }
/*  89 */     if (this.infinite) {
/*  90 */       retString = retString + "oo";
/*     */     }
/*  92 */     return retString;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object edge) {
/*  97 */     if (!(edge instanceof TimedEdge)) {
/*  98 */       return false;
/*     */     }
/* 100 */     TimedEdge timedEdge = (TimedEdge)edge;
/* 101 */     if (timedEdge.dest.equals(this.dest) && timedEdge.src.equals(this.src) && timedEdge.getId() == this.id && timedEdge.getTimeTransition() == this.timeTransition) {
/* 102 */       return true;
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqual(RGEdge e) {
/* 109 */     if (!(e instanceof TimedEdge)) {
/* 110 */       return false;
/*     */     }
/* 112 */     TimedEdge timedEdge = (TimedEdge)e;
/* 113 */     if (timedEdge.dest == this.dest && timedEdge.src == this.src && timedEdge.getId() == this.id && timedEdge.getTimeTransition() == this.timeTransition) {
/* 114 */       return true;
/*     */     }
/* 116 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 121 */     return "ID: " + getId() + "Zeit: " + getTimeTransition() + ", From Node:\n" + this.src.toString() + "\nto Node:\n" + this.dest.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDistance() {
/* 126 */     return this.timeTransition;
/*     */   }
/*     */ 
/*     */   
/*     */   public RGEdge copy() {
/* 131 */     return new TimedEdge(getPN(), this.src, this.dest, this.id, this.timeTransition);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/TimedEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */