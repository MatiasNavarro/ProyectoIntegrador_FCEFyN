/*    */ package charlie.rg;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.pn.Transition;
/*    */ 
/*    */ public class DestinationEdge
/*    */   extends RGEdge
/*    */ {
/*    */   short id;
/*    */   
/*    */   public Transition[] getTransitions() {
/* 12 */     Transition[] t = new Transition[1];
/* 13 */     if (this.id < 0) {
/* 14 */       return null;
/*    */     }
/* 16 */     t[0] = getPN().getTransition(this.id);
/* 17 */     return t;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDistance() {
/* 22 */     return 0;
/*    */   }
/*    */   
/*    */   public DestinationEdge(PlaceTransitionNet _pn, RGNode _src, RGNode _dest, short _id) {
/* 26 */     super(_pn, _src, _dest);
/* 27 */     this.id = _id;
/* 28 */     this.dest = _dest;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RGEdge copy() {
/* 34 */     return new DestinationEdge(getPN(), null, this.dest, this.id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isEqual(RGEdge e) {
/* 40 */     if (!(e instanceof DestinationEdge)) {
/* 41 */       return false;
/*    */     }
/* 43 */     if (this.id != ((DestinationEdge)e).id || this.dest != ((DestinationEdge)e).dest) {
/* 44 */       return false;
/*    */     }
/* 46 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public short getId() {
/* 51 */     return this.id;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getLabel(PlaceTransitionNet pn) {
/* 56 */     if (this.id < 0) {
/* 57 */       return "";
/*    */     }
/* 59 */     return pn.getTransition(this.id).getName();
/*    */   }
/*    */   
/*    */   public Transition getTransition(PlaceTransitionNet pn) {
/* 63 */     if (this.id < 0) {
/* 64 */       return null;
/*    */     }
/* 66 */     return pn.getTransition(this.id);
/*    */   }
/*    */ 
/*    */   
/*    */   public RGNode node(RGNode v) {
/* 71 */     return this.dest;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 76 */     if (!(o instanceof DestinationEdge)) {
/* 77 */       return false;
/*    */     }
/*    */     
/* 80 */     if (this.id != ((DestinationEdge)o).id || !this.dest.equals(((DestinationEdge)o).dest)) {
/* 81 */       return false;
/*    */     }
/* 83 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/DestinationEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */