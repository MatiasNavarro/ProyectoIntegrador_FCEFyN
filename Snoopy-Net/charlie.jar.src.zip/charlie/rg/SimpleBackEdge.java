/*    */ package charlie.rg;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.pn.Transition;
/*    */ 
/*    */ 
/*    */ public class SimpleBackEdge
/*    */   extends RGBackEdge
/*    */ {
/*    */   private short id;
/*    */   
/*    */   public Transition[] getTransitions() {
/* 13 */     Transition[] t = new Transition[1];
/* 14 */     if (this.id < 0) {
/* 15 */       return null;
/*    */     }
/* 17 */     t[0] = getPN().getTransition(this.id);
/* 18 */     return t;
/*    */   }
/*    */   
/*    */   public SimpleBackEdge(PlaceTransitionNet _pn, RGNode src, RGNode dest, short id) {
/* 22 */     super(_pn, src, dest);
/* 23 */     this.id = id;
/*    */   }
/*    */ 
/*    */   
/*    */   public RGEdge copy() {
/* 28 */     return new SimpleBackEdge(getPN(), null, this.prev, this.id);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public short getId() {
/* 34 */     return this.id;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getLabel(PlaceTransitionNet pn) {
/* 39 */     if (this.id < 0) {
/* 40 */       return "";
/*    */     }
/* 42 */     return pn.getTransition(this.id).getName();
/*    */   }
/*    */   
/*    */   public Transition getTransition(PlaceTransitionNet pn) {
/* 46 */     if (this.id < 0) {
/* 47 */       return null;
/*    */     }
/* 49 */     return pn.getTransition(this.id);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEqual(RGEdge e) {
/* 54 */     if (!(e instanceof SimpleBackEdge)) {
/* 55 */       return false;
/*    */     }
/* 57 */     if (this.id != ((SimpleBackEdge)e).id || this.dest != ((SimpleBackEdge)e).dest) {
/* 58 */       return false;
/*    */     }
/* 60 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 65 */     if (!(o instanceof SimpleBackEdge)) {
/* 66 */       return false;
/*    */     }
/* 68 */     if (this.id != ((SimpleBackEdge)o).id || !this.dest.equals(((SimpleBackEdge)o).dest)) {
/* 69 */       return false;
/*    */     }
/* 71 */     return true;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/SimpleBackEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */