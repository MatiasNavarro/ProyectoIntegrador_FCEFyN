/*    */ package charlie.rg;
/*    */ 
/*    */ import charlie.pn.ExceedsByteException;
/*    */ import charlie.pn.Marking;
/*    */ import charlie.pn.SafetyException;
/*    */ import charlie.pn.State;
/*    */ import charlie.pn.Transition;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleFireRule
/*    */ {
/*    */   public static Collection<State> simpleFire(Collection<Transition> transitions, Marking m) throws SafetyException, ExceedsByteException {
/* 17 */     Collection<State> states = new Vector<>();
/* 18 */     for (Iterator<Transition> it = transitions.iterator(); it.hasNext();) {
/* 19 */       states.add(((Transition)it.next()).fire((State)m, true, true));
/*    */     }
/*    */     
/* 22 */     return states;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/SimpleFireRule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */