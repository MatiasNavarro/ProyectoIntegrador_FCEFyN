/*     */ package charlie.rg;
/*     */ 
/*     */ import charlie.ds.HashStack;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Transition;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Path
/*     */ {
/*     */   public static final int FINITE_PATH = 0;
/*     */   public static final int INFINITE_CYCLE = 1;
/*     */   public static final int INFINITE_TIME_EDGE = 2;
/*  20 */   private int infinityState = 0;
/*  21 */   public RGraph rg = null;
/*     */   RGNode start;
/*     */   private String name;
/*  24 */   public HashStack edgeIds = new HashStack();
/*  25 */   public HashStack pathNodes = new HashStack();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path(RGNode firstNode, RGraph rg) {
/*  36 */     this.name = super.toString();
/*  37 */     this.rg = rg;
/*     */     
/*  39 */     this.edgeIds = new HashStack();
/*  40 */     this.start = firstNode;
/*  41 */     addNode(firstNode);
/*     */   }
/*     */   
/*     */   public Iterator<Object> NodeIterator() {
/*  45 */     return this.pathNodes.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  50 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  54 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  58 */     StringTokenizer strT = new StringTokenizer(name);
/*  59 */     this.name = "";
/*  60 */     while (strT.hasMoreTokens()) {
/*  61 */       this.name += strT.nextToken();
/*     */     }
/*     */   }
/*     */   
/*     */   public Iterator<Object> iterator() {
/*  66 */     return this.pathNodes.iterator();
/*     */   }
/*     */   
/*     */   public Iterator<Object> iteratorEdgeIds() {
/*  70 */     return this.edgeIds.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWayLength() {
/*  78 */     if (this.edgeIds.peek() instanceof RGEdge) {
/*     */       
/*  80 */       int count = 0;
/*  81 */       for (Iterator<Object> it = this.edgeIds.iterator(); it.hasNext();) {
/*  82 */         count += ((RGEdge)it.next()).getDistance();
/*     */       }
/*  84 */       return count;
/*     */     } 
/*     */ 
/*     */     
/*  88 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean pathContains(RGNode node) {
/*  95 */     return this.pathNodes.contains(node);
/*     */   }
/*     */   
/*     */   public boolean checkAndAddNode(RGNode node) {
/*  99 */     short id = extendsPath(node);
/* 100 */     if (id >= 0) {
/* 101 */       addNode(node);
/* 102 */       this.edgeIds.push(new Short(id));
/* 103 */       return true;
/*     */     } 
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkAndAddNode(RGNode node, RGEdge edge) {
/* 110 */     addNode(node);
/* 111 */     if (edge != null) {
/* 112 */       this.edgeIds.push(edge);
/*     */     }
/* 114 */     return true;
/*     */   }
/*     */   
/*     */   private void addNode(RGNode node) {
/* 118 */     if (this.pathNodes.isEmpty()) {
/* 119 */       this.start = node;
/*     */     }
/* 121 */     this.pathNodes.push(node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short extendsPath(RGNode node) {
/* 129 */     if (this.pathNodes.isEmpty()) {
/* 130 */       return -1;
/*     */     }
/* 132 */     short b = -1;
/* 133 */     RGNode last = (RGNode)this.pathNodes.peek();
/* 134 */     RGEdge e = last.out();
/* 135 */     while (b < 0 && e != null) {
/* 136 */       if (node.getSuccessor(e, this.rg).equals(node)) {
/* 137 */         b = e.getId();
/*     */       }
/* 139 */       e = e.next();
/*     */     } 
/* 141 */     return b;
/*     */   }
/*     */   
/*     */   public void clear() {
/* 145 */     while (deleteLast() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLastNode(RGNode node) {
/* 151 */     if (this.pathNodes.isEmpty()) {
/* 152 */       return false;
/*     */     }
/* 154 */     return node.equals(this.pathNodes.peek());
/*     */   }
/*     */   
/*     */   public boolean isFirstNode(RGNode node) {
/* 158 */     if (this.pathNodes.isEmpty()) {
/* 159 */       return false;
/*     */     }
/* 161 */     return node.equals(this.start);
/*     */   }
/*     */   
/*     */   public RGNode last() {
/* 165 */     if (this.pathNodes.isEmpty()) {
/* 166 */       return null;
/*     */     }
/* 168 */     return (RGNode)this.pathNodes.peek();
/*     */   }
/*     */   
/*     */   public RGNode first() {
/* 172 */     if (this.pathNodes.isEmpty()) {
/* 173 */       return null;
/*     */     }
/* 175 */     return this.start;
/*     */   }
/*     */ 
/*     */   
/*     */   public int deleteLast() {
/* 180 */     if (length() > 0) {
/* 181 */       this.pathNodes.pop();
/* 182 */       this.edgeIds.pop();
/*     */     } 
/*     */     
/* 185 */     return this.pathNodes.size();
/*     */   }
/*     */   
/*     */   public int length() {
/* 189 */     return this.edgeIds.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString() {
/* 194 */     return "edges\n" + edgesToString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String edgesToString() {
/* 199 */     String res = "";
/* 200 */     int wayDistance = getWayLength();
/* 201 */     for (Iterator<Object> it = this.edgeIds.iterator(); it.hasNext(); ) {
/* 202 */       Object o = it.next();
/* 203 */       String name = "";
/* 204 */       if (o instanceof RGEdge) {
/*     */         
/* 206 */         Transition[] transitions = ((RGEdge)o).getTransitions();
/* 207 */         if (transitions != null) {
/* 208 */           for (int i = 0; i < transitions.length; i++) {
/*     */             
/* 210 */             name = name + transitions[i].getName();
/* 211 */             if (i < transitions.length - 1 || (transitions.length > 0 && wayDistance > 0)) {
/* 212 */               name = name + ", ";
/*     */             }
/*     */           } 
/*     */         }
/* 216 */         if (wayDistance > 0) {
/* 217 */           name = name + "Distance: " + ((RGEdge)o).getDistance();
/*     */         }
/*     */       } else {
/* 220 */         name = ((Short)o).toString();
/*     */       } 
/* 222 */       if (it.hasNext()) {
/* 223 */         name = " -> " + name;
/*     */       }
/* 225 */       res = name + res;
/*     */     } 
/* 227 */     return res;
/*     */   }
/*     */   
/*     */   public void appendPath(Path p) {
/* 231 */     Stack<Object> st = new Stack();
/* 232 */     for (Iterator<Object> it = p.pathNodes.iterator(); it.hasNext();) {
/* 233 */       st.push(it.next());
/*     */     }
/* 235 */     while (!st.isEmpty()) {
/* 236 */       checkAndAddNode((RGNode)st.pop());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toTransitionSequence(PlaceTransitionNet pn) {
/* 243 */     String res = new String();
/*     */     
/* 245 */     for (Iterator<Object> it = this.edgeIds.iterator(); it.hasNext(); ) {
/* 246 */       Object o = it.next();
/* 247 */       String name = "";
/* 248 */       if (o instanceof RGEdge) {
/*     */         
/* 250 */         Transition[] transitions = ((RGEdge)o).getTransitions();
/* 251 */         if (transitions != null) {
/* 252 */           for (int i = 0; i < transitions.length; i++) {
/* 253 */             name = name + transitions[i].getName() + " ,";
/*     */           }
/*     */         }
/* 256 */         name = name + "Distance: " + ((RGEdge)o).getDistance();
/*     */       } else {
/* 258 */         System.out.println(o.getClass());
/* 259 */         short index = ((Short)o).shortValue();
/* 260 */         Transition t = pn.getTransition(index);
/* 261 */         if (t != null) {
/* 262 */           name = t.getName();
/*     */         }
/*     */       } 
/* 265 */       if (it.hasNext()) {
/* 266 */         name = "\n" + name;
/*     */       }
/* 268 */       res = name + res;
/*     */     } 
/*     */     
/* 271 */     res = res + "\n\\end";
/* 272 */     res = pn.toLabel(this.start.getMarking()) + "\n" + res;
/* 273 */     res = "\\begin{transition_sequence}\n" + res;
/*     */     
/* 275 */     return res;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toMarkingSequence(PlaceTransitionNet pn) {
/* 280 */     String res = new String();
/*     */     
/* 282 */     for (Iterator<Object> it = this.pathNodes.iterator(); it.hasNext(); ) {
/* 283 */       String name = pn.toLabel(((RGNode)it.next()).getMarking());
/* 284 */       if (it.hasNext()) {
/* 285 */         name = "\n" + name;
/*     */       }
/* 287 */       res = name + res;
/*     */     } 
/*     */     
/* 290 */     res = res + "\n\\end";
/* 291 */     res = "\\begin{marking_sequence}\n" + res;
/*     */     
/* 293 */     return res;
/*     */   }
/*     */   
/*     */   public String toParikhVector(PlaceTransitionNet pn) {
/* 297 */     List<Transition> transitionVector = pn.getTransitions();
/*     */     
/* 299 */     String res = new String("parikh vector transition=\n1");
/* 300 */     int n = transitionVector.size();
/* 301 */     int[] occurenceField = new int[n];
/*     */     
/* 303 */     for (Iterator<Object> it = this.edgeIds.iterator(); it.hasNext(); ) {
/* 304 */       Object o = it.next();
/* 305 */       if (o instanceof RGEdge) {
/*     */         
/* 307 */         Transition[] transitions = ((RGEdge)o).getTransitions();
/* 308 */         if (transitions != null)
/*     */         {
/* 310 */           for (int k = 0; k < transitions.length; k++)
/* 311 */             occurenceField[transitions[k].getId()] = occurenceField[transitions[k].getId()] + 1; 
/*     */         }
/*     */         continue;
/*     */       } 
/* 315 */       occurenceField[((Short)o).shortValue()] = occurenceField[((Short)o).shortValue()] + 1;
/*     */     } 
/*     */ 
/*     */     
/* 319 */     int j = 0;
/*     */     
/* 321 */     for (int i = 0; i < n; ) {
/* 322 */       if (occurenceField[i] > 0) {
/* 323 */         j = i + 1;
/* 324 */         while (j < n && occurenceField[j] == 0) {
/* 325 */           j++;
/*     */         }
/* 327 */         res = res + "\t|\t" + i + "." + ((Transition)transitionVector.get((short)i)).getName() + "\t\t:" + occurenceField[i];
/* 328 */         if (j < n) {
/* 329 */           res = res + ",";
/*     */         }
/* 331 */         res = res + "\n";
/* 332 */         i = j; continue;
/*     */       } 
/* 334 */       i++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 339 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInfinityState() {
/* 348 */     return this.infinityState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInfinityState(int infinityState) {
/* 357 */     this.infinityState = infinityState;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/Path.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */