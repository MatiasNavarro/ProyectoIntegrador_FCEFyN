/*    */ package charlie.rg;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ 
/*    */ public class SequenceEdge
/*    */   extends MultipleEdge
/*    */ {
/*    */   public SequenceEdge(PlaceTransitionNet _pn, RGNode from, RGNode to, RGEdge[] e) {
/*  9 */     super(_pn, from, to, e);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RGEdge copy() {
/* 15 */     return new SequenceEdge(getPN(), this.dest, this.d, this.edges);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getLabel(PlaceTransitionNet pn) {
/* 21 */     StringBuffer buf = new StringBuffer();
/* 22 */     buf.append("(");
/* 23 */     for (int i = 0; i < this.edges.length; i++) {
/* 24 */       buf.append(this.edges[i].getLabel(pn));
/* 25 */       if (i < this.edges.length - 1) {
/* 26 */         buf.append("->");
/*    */       }
/*    */     } 
/* 29 */     buf.append(")");
/* 30 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/SequenceEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */