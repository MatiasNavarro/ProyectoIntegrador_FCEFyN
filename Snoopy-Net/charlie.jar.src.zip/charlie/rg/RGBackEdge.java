/*    */ package charlie.rg;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ 
/*    */ public abstract class RGBackEdge
/*    */   extends RGEdge {
/*    */   public RGNode prev;
/*    */   
/*    */   public RGBackEdge(PlaceTransitionNet _pn, RGNode src, RGNode d) {
/* 10 */     super(_pn, src, d);
/*    */     
/* 12 */     this.prev = d;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RGNode node(RGNode v) {
/* 18 */     return this.prev;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getDistance() {
/* 24 */     return 0;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/RGBackEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */