/*     */ package charlie.rg;
/*     */ 
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Transition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipleTimedEdge
/*     */   extends TimedEdge
/*     */ {
/*     */   private Transition[] transitions;
/*     */   
/*     */   public MultipleTimedEdge(PlaceTransitionNet _pn, RGNode src, RGNode dest, short id, int timeTransition, Transition[] transitions) {
/*  34 */     super(_pn, src, dest, id, timeTransition);
/*  35 */     this.transitions = transitions;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  40 */     String retString = super.toString();
/*  41 */     retString = retString + "mit Transitionen: ";
/*  42 */     for (int i = 0; i < this.transitions.length; i++) {
/*  43 */       if (this.transitions[i] != null) {
/*  44 */         retString = retString + this.transitions[i].getName() + ", ";
/*     */       }
/*     */     } 
/*  47 */     return retString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel(PlaceTransitionNet pn) {
/*  52 */     String retString = "";
/*  53 */     if (this.timeTransition > 0) {
/*  54 */       retString = "[" + this.timeTransition + "] ";
/*     */     }
/*  56 */     for (int i = 0; i < this.transitions.length; i++) {
/*  57 */       if (this.transitions[i] != null) {
/*  58 */         retString = retString + this.transitions[i].getName();
/*     */       }
/*     */     } 
/*  61 */     return retString;
/*     */   }
/*     */ 
/*     */   
/*     */   public Transition[] getTransitions() {
/*  66 */     return this.transitions;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  72 */     boolean ret = true;
/*  73 */     if (!(o instanceof MultipleTimedEdge)) {
/*  74 */       return false;
/*     */     }
/*  76 */     MultipleTimedEdge tempEdge = (MultipleTimedEdge)o;
/*  77 */     for (int i = 0; i < (tempEdge.getTransitions()).length; i++) {
/*  78 */       if (!containsTransition(tempEdge.getTransitions()[i])) {
/*  79 */         ret = false;
/*     */       }
/*     */     } 
/*  82 */     if (!this.dest.equals(tempEdge.dest) || !this.src.equals(tempEdge.src) || this.timeTransition != tempEdge.getTimeTransition() || tempEdge.transitions.length != this.transitions.length) {
/*  83 */       ret = false;
/*     */     }
/*  85 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqual(RGEdge e) {
/*  90 */     boolean ret = true;
/*  91 */     if (!(e instanceof MultipleTimedEdge)) {
/*  92 */       return false;
/*     */     }
/*  94 */     MultipleTimedEdge tempEdge = (MultipleTimedEdge)e;
/*  95 */     for (int i = 0; i < (tempEdge.getTransitions()).length; i++) {
/*  96 */       if (!containsTransition(tempEdge.getTransitions()[i])) {
/*  97 */         ret = false;
/*     */       }
/*     */     } 
/* 100 */     if (this.dest != tempEdge.dest || this.src != tempEdge.src || this.timeTransition != tempEdge.getTimeTransition() || tempEdge.transitions.length != this.transitions.length) {
/* 101 */       ret = false;
/*     */     }
/* 103 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean containsTransition(Transition transition) {
/* 110 */     for (int i = 0; i < this.transitions.length; i++) {
/* 111 */       if (this.transitions[i].equals(transition)) {
/* 112 */         return true;
/*     */       }
/*     */     } 
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public RGEdge copy() {
/* 120 */     return new MultipleTimedEdge(getPN(), this.src, this.dest, this.id, this.timeTransition, this.transitions);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/MultipleTimedEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */