/*    */ package charlie.rg;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.pn.Transition;
/*    */ 
/*    */ 
/*    */ public class SimpleEdge
/*    */   extends RGEdge
/*    */ {
/*    */   short id;
/*    */   
/*    */   public Transition[] getTransitions() {
/* 13 */     Transition[] t = new Transition[1];
/* 14 */     if (this.id < 0) {
/* 15 */       return new Transition[0];
/*    */     }
/* 17 */     t[0] = getPN().getTransition(this.id);
/* 18 */     return t;
/*    */   }
/*    */   
/*    */   public SimpleEdge(PlaceTransitionNet _pn, RGNode src, RGNode dest, short id) {
/* 22 */     super(_pn, src, dest);
/* 23 */     this.id = id;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public RGEdge copy() {
/* 29 */     return new SimpleEdge(getPN(), null, this.dest, this.id);
/*    */   }
/*    */ 
/*    */   
/*    */   public short getId() {
/* 34 */     return this.id;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getLabel(PlaceTransitionNet pn) {
/* 39 */     if (this.id < 0) {
/* 40 */       return "";
/*    */     }
/* 42 */     return pn.getTransition(this.id).getName();
/*    */   }
/*    */   
/*    */   public Transition getTransition(PlaceTransitionNet pn) {
/* 46 */     if (this.id < 0) {
/* 47 */       return null;
/*    */     }
/* 49 */     return pn.getTransition(this.id);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEqual(RGEdge e) {
/* 54 */     if (!(e instanceof SimpleEdge)) {
/* 55 */       return false;
/*    */     }
/* 57 */     if (this.id != ((SimpleEdge)e).id || this.dest != ((SimpleEdge)e).dest) {
/* 58 */       return false;
/*    */     }
/* 60 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 65 */     if (!(o instanceof SimpleEdge)) {
/* 66 */       return false;
/*    */     }
/* 68 */     if (this.id != ((SimpleEdge)o).id || !this.dest.equals(((SimpleEdge)o).dest)) {
/* 69 */       return false;
/*    */     }
/* 71 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDistance() {
/* 76 */     return 0;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/SimpleEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */