/*      */ package charlie.rg;
/*      */ 
/*      */ import charlie.filter.Filter;
/*      */ import charlie.pn.ExceedsByteException;
/*      */ import charlie.pn.Marking;
/*      */ import charlie.pn.PlaceTransitionNet;
/*      */ import charlie.pn.SafetyException;
/*      */ import charlie.pn.SortedElementsByteArray;
/*      */ import charlie.pn.SortedElementsFactory;
/*      */ import charlie.pn.State;
/*      */ import charlie.pn.Transition;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RGraph
/*      */   implements ReachabilityGraph
/*      */ {
/*   30 */   private static final Log LOG = LogFactory.getLog(RGraph.class);
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean safe = true;
/*      */ 
/*      */   
/*   37 */   private int maxTokenCount = -1;
/*      */   public boolean complete = false;
/*      */   public RGNode first;
/*   40 */   protected final Map<Object, RGNode> vertices = new HashMap<>();
/*      */   protected int edges;
/*      */   protected int size;
/*      */   private PlaceTransitionNet pn;
/*      */   private int outgoingedges;
/*   45 */   private int minout = 10000;
/*   46 */   private int minin = 10000;
/*   47 */   private int maxin = -1;
/*   48 */   private int maxout = -1;
/*      */   private int ingoingedges;
/*      */   private boolean backEdges = true;
/*   51 */   private final Map<Integer, SCC> Scc = new HashMap<>();
/*   52 */   private final Set<RGNode> deadStates = new HashSet<>();
/*   53 */   private final Set<Integer> finalScc = new HashSet<>();
/*   54 */   private HashSet<RGNode> reducedNodes = new HashSet<>();
/*      */   
/*   56 */   private int dStates = 0;
/*      */   private int scc;
/*      */   private boolean dcFree;
/*      */   public boolean reducedSequences = false;
/*   60 */   private long constructionTime = -1L;
/*   61 */   private String constructionTimeString = "";
/*   62 */   public byte timeDesignation = -1;
/*   63 */   public byte timedNetType = 4;
/*   64 */   public byte clockHandling = -1;
/*      */ 
/*      */   
/*      */   public RGraph() {}
/*      */ 
/*      */   
/*      */   public RGraph(PlaceTransitionNet pn) {
/*   71 */     this.pn = pn;
/*   72 */     this.dcFree = true;
/*   73 */     this.scc = 0;
/*   74 */     this.edges = 0;
/*   75 */     this.size = 0;
/*   76 */     this.first = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<RGNode> getSatisfyingStates(Filter f) {
/*   87 */     Vector<RGNode> v = new Vector<>();
/*   88 */     for (Iterator<RGNode> it = this.vertices.values().iterator(); it.hasNext(); ) {
/*   89 */       RGNode n = it.next();
/*   90 */       if (f.filter(n.getLabel())) {
/*   91 */         v.add(n);
/*      */       }
/*      */     } 
/*   94 */     return v;
/*      */   }
/*      */   
/*      */   public PlaceTransitionNet getNet() {
/*   98 */     return this.pn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vector<RGNode> getSatisfyingStates(State m) {
/*  109 */     Vector<RGNode> v = new Vector<>();
/*  110 */     for (Iterator<RGNode> it = this.vertices.values().iterator(); it.hasNext(); ) {
/*  111 */       RGNode n = it.next();
/*  112 */       if (m.equals(n.getLabel())) {
/*  113 */         v.add(n);
/*      */       }
/*      */     } 
/*  116 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBackEdgeOption(boolean b) {
/*  121 */     this.backEdges = b;
/*      */   }
/*      */   
/*      */   public boolean backEdges() {
/*  125 */     return this.backEdges;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfNodes() {
/*  131 */     return size();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNumberOfStronglyConnectedComponents() {
/*  136 */     return this.scc;
/*      */   }
/*      */   
/*      */   public int getNumberOfEdges() {
/*  140 */     return this.edges;
/*      */   }
/*      */   
/*      */   public RGNode getInitialState() {
/*  144 */     return getFirst();
/*      */   }
/*      */   
/*      */   public boolean safe() {
/*  148 */     return this.safe;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDCFree(boolean b) {
/*  153 */     this.dcFree = b;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDCFree() {
/*  158 */     return this.dcFree;
/*      */   }
/*      */ 
/*      */   
/*      */   public RGNode getFirst() {
/*  163 */     return this.first;
/*      */   }
/*      */   
/*      */   public int size() {
/*  167 */     return this.size;
/*      */   }
/*      */   
/*      */   public Collection<RGNode> getDeadStates() {
/*  171 */     return this.deadStates;
/*      */   }
/*      */   
/*      */   public int getNumberOfDeadStates() {
/*  175 */     return this.dStates;
/*      */   }
/*      */   
/*      */   public Set<Integer> getNumbersOfFinalScc() {
/*  179 */     return this.finalScc;
/*      */   }
/*      */   
/*      */   public Map<Integer, SCC> getScc() {
/*  183 */     return this.Scc;
/*      */   }
/*      */   
/*      */   public int getNumberOfScc() {
/*  187 */     return this.scc;
/*      */   }
/*      */   
/*      */   public void addScc(SCC c) {
/*  191 */     this.Scc.put(new Integer(c.number()), c);
/*      */   }
/*      */   
/*      */   public void removeScc(SCC c) {
/*  195 */     this.Scc.remove(new Integer(c.number()));
/*      */   }
/*      */   
/*      */   public void incScc() {
/*  199 */     this.scc++;
/*      */   }
/*      */   
/*      */   public void decScc() {
/*  203 */     this.scc--;
/*      */   }
/*      */   
/*      */   public int verticesSize() {
/*  207 */     return this.vertices.values().size();
/*      */   }
/*      */   
/*      */   public Iterator<RGNode> iterator() {
/*  211 */     return this.vertices.values().iterator();
/*      */   }
/*      */   
/*      */   public Iterator<RGNode> verticesIterator() {
/*  215 */     return iterator();
/*      */   }
/*      */   
/*      */   public long getConstructionTime() {
/*  219 */     return this.constructionTime;
/*      */   }
/*      */   
/*      */   public String getConstructionTimeString() {
/*  223 */     return this.constructionTimeString;
/*      */   }
/*      */   
/*      */   public void setConstructionTime(long time) {
/*  227 */     this.constructionTime = time;
/*      */   }
/*      */   
/*      */   public void setConstructionTime(String t) {
/*  231 */     this.constructionTimeString = t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxTokenCount() {
/*  240 */     return this.maxTokenCount;
/*      */   }
/*      */   
/*      */   public RGNode addNode(RGNode v) {
/*  244 */     Object key = v.getMarking();
/*  245 */     if (this.vertices.isEmpty()) {
/*  246 */       this.first = v;
/*      */     }
/*      */     
/*  249 */     if (this.maxTokenCount < Integer.MAX_VALUE) {
/*  250 */       int max = v.getLabel().getMaxToken();
/*  251 */       if (this.safe && 
/*  252 */         !(v.getLabel() instanceof charlie.pn.SortedElementsBitSet) && 
/*  253 */         max > 1) {
/*  254 */         this.safe = false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  259 */       if (max > this.maxTokenCount) {
/*  260 */         this.maxTokenCount = max;
/*      */       }
/*      */     } 
/*      */     
/*  264 */     Object o = this.vertices.get(key);
/*  265 */     if (o == null) {
/*  266 */       this.vertices.put(key, v);
/*  267 */       this.size++;
/*  268 */       return null;
/*      */     } 
/*  270 */     return (RGNode)o;
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeNode(RGNode v) {
/*  275 */     RGEdge out = v.out();
/*  276 */     while (out != null) {
/*  277 */       removeEdge(v, out, out.node(v));
/*  278 */       out = out.next();
/*      */     } 
/*  280 */     RGEdge in = v.in();
/*  281 */     while (in != null) {
/*  282 */       RGNode src = in.node(v);
/*  283 */       out = src.out();
/*  284 */       while (out != null) {
/*  285 */         if (out.node(src).equals(v)) {
/*  286 */           removeEdge(src, out, v);
/*      */         }
/*  288 */         out = out.next();
/*      */       } 
/*  290 */       in = in.next();
/*      */     } 
/*  292 */     v.setInEdge(null);
/*  293 */     this.size--;
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeNodeFully(RGNode v, boolean removeSCC) {
/*  298 */     Object key = v.getMarking();
/*  299 */     Object o = this.vertices.get(key);
/*  300 */     if (o != null) {
/*  301 */       removeNode(v);
/*  302 */       this.vertices.remove(key);
/*  303 */       SCC tempScc = getScc().get(Integer.valueOf(v.sccNumber()));
/*  304 */       if (tempScc == null) {
/*      */         return;
/*      */       }
/*      */       
/*  308 */       if (removeSCC) {
/*  309 */         if (tempScc.size() > 1) {
/*  310 */           tempScc.remove(v);
/*      */         } else {
/*  312 */           tempScc.remove(v);
/*  313 */           getScc().remove(Integer.valueOf(tempScc.number()));
/*  314 */           decScc();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public RGNode getNode(Object key) {
/*  322 */     if (this.vertices == null) {
/*  323 */       return null;
/*      */     }
/*      */     
/*  326 */     return this.vertices.get(key);
/*      */   }
/*      */   
/*      */   public RGNode getNode(String label) throws SafetyException, ExceedsByteException {
/*  330 */     StringTokenizer st = new StringTokenizer(label, "_ ");
/*  331 */     Marking m = SortedElementsFactory.getSortedPlaces(st.countTokens() / 2);
/*  332 */     m.name = " RGraph.getNode " + label;
/*  333 */     while (st.hasMoreTokens()) {
/*  334 */       int id = Integer.parseInt(st.nextToken());
/*  335 */       if (!st.hasMoreTokens()) {
/*  336 */         LOG.error("error in getVertex by label");
/*  337 */         return null;
/*      */       } 
/*  339 */       int token = Integer.parseInt(st.nextToken());
/*      */       try {
/*  341 */         m.addPlace(id, token);
/*  342 */       } catch (SafetyException e) {
/*  343 */         SortedElementsFactory.safeMode(false);
/*  344 */         RGNode ret = getNode(label);
/*  345 */         SortedElementsFactory.safeMode(true);
/*  346 */         return ret;
/*      */       } 
/*      */     } 
/*      */     
/*  350 */     return this.vertices.get(m);
/*      */   }
/*      */   
/*      */   public void removeReducedEdge(TimedEdge e) {
/*  354 */     TimedEdge inEdge = (TimedEdge)e.src.out();
/*  355 */     TimedEdge edgeBefore = null;
/*  356 */     while (inEdge != null) {
/*  357 */       if (inEdge.isEqual(e)) {
/*  358 */         if (edgeBefore == null) {
/*  359 */           e.src.out = inEdge.next();
/*      */         } else {
/*  361 */           edgeBefore.next = inEdge.next();
/*      */         } 
/*  363 */         this.edges--;
/*      */         break;
/*      */       } 
/*  366 */       edgeBefore = inEdge;
/*  367 */       inEdge = (TimedEdge)inEdge.next();
/*      */     } 
/*  369 */     edgeBefore = null;
/*  370 */     inEdge = (TimedEdge)e.dest.inEdge();
/*  371 */     while (inEdge != null) {
/*  372 */       if (inEdge.isEqual(e)) {
/*  373 */         if (edgeBefore == null) {
/*  374 */           e.dest.setInEdge(inEdge.next()); break;
/*      */         } 
/*  376 */         edgeBefore.next = inEdge.next();
/*      */         
/*      */         break;
/*      */       } 
/*  380 */       edgeBefore = inEdge;
/*  381 */       inEdge = (TimedEdge)inEdge.next();
/*      */     } 
/*  383 */     if (e.src == e.dest) {
/*  384 */       e.src.resetCycleEdge();
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeEdge(TimedEdge e) {
/*  389 */     if (!this.vertices.containsKey(e.src.getMarking()) || !this.vertices.containsKey(e.dest.getMarking())) {
/*      */       return;
/*      */     }
/*  392 */     TimedEdge inEdge = (TimedEdge)e.src.out();
/*  393 */     TimedEdge edgeBefore = null;
/*  394 */     while (inEdge != null) {
/*  395 */       if (inEdge.isEqual(e)) {
/*  396 */         if (edgeBefore == null) {
/*  397 */           e.src.out = inEdge.next();
/*      */         } else {
/*  399 */           edgeBefore.next = inEdge.next();
/*      */         } 
/*  401 */         if (e.src.lastOut.isEqual(e)) {
/*  402 */           e.src.lastOut = edgeBefore;
/*      */         }
/*  404 */         this.edges--;
/*      */         break;
/*      */       } 
/*  407 */       edgeBefore = inEdge;
/*  408 */       inEdge = (TimedEdge)inEdge.next();
/*      */     } 
/*  410 */     edgeBefore = null;
/*  411 */     inEdge = (TimedEdge)e.dest.inEdge();
/*  412 */     while (inEdge != null) {
/*  413 */       if (inEdge.isEqual(e)) {
/*  414 */         if (edgeBefore == null) {
/*  415 */           e.dest.setInEdge(inEdge.next());
/*      */         } else {
/*  417 */           edgeBefore.next = inEdge.next();
/*      */         } 
/*  419 */         if (e.dest.lastInEdge.isEqual(e)) {
/*  420 */           e.dest.lastInEdge = edgeBefore;
/*      */         }
/*      */         break;
/*      */       } 
/*  424 */       edgeBefore = inEdge;
/*  425 */       inEdge = (TimedEdge)inEdge.next();
/*      */     } 
/*  427 */     if (e.src == e.dest) {
/*  428 */       e.src.resetCycleEdge();
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeEdge(RGNode from, RGEdge e, RGNode to) {
/*  433 */     if (!this.vertices.containsKey(from.getMarking()) || !this.vertices.containsKey(to.getMarking())) {
/*      */       return;
/*      */     }
/*      */     
/*  437 */     from.removePost(e, to);
/*  438 */     this.edges--;
/*  439 */     RGEdge edgeBefore = null;
/*  440 */     RGEdge inEdge = e.dest.inEdge();
/*  441 */     while (inEdge != null) {
/*  442 */       if (inEdge.isEqual(e)) {
/*  443 */         if (edgeBefore == null) {
/*  444 */           e.dest.setInEdge(inEdge.next()); break;
/*      */         } 
/*  446 */         edgeBefore.next = inEdge.next();
/*      */         
/*      */         break;
/*      */       } 
/*  450 */       edgeBefore = inEdge;
/*  451 */       inEdge = inEdge.next();
/*      */     } 
/*  453 */     if (e.src == e.dest) {
/*  454 */       e.src.resetCycleEdge();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public RGEdge addEdge(RGNode from, RGNode to, short id, boolean unbound) {
/*  460 */     if (!unbound) {
/*  461 */       return addEdge(from, to, id);
/*      */     }
/*      */     
/*  464 */     int out = 0;
/*  465 */     int in = 0;
/*  466 */     RGEdge outEdge = new DestinationEdge(this.pn, from, to, id);
/*  467 */     out = from.addOutgoing(outEdge);
/*  468 */     to.addIngoingEdge(new DestinationEdge(this.pn, from, to, id));
/*  469 */     DestinationEdge sE = null;
/*  470 */     if (this.backEdges) {
/*  471 */       sE = new DestinationEdge(this.pn, to, from, id);
/*      */     }
/*  473 */     in = to.addIngoing(sE);
/*  474 */     this.outgoingedges++;
/*      */     
/*  476 */     if (out < this.minout) {
/*  477 */       this.minout = out;
/*      */     }
/*  479 */     if (out > this.maxout) {
/*  480 */       this.maxout = out;
/*      */     }
/*      */     
/*  483 */     this.ingoingedges++;
/*  484 */     if (in < this.minin) {
/*  485 */       this.minin = in;
/*      */     }
/*  487 */     if (in > this.maxin) {
/*  488 */       this.maxin = in;
/*      */     }
/*  490 */     this.edges++;
/*  491 */     if (from == to) {
/*  492 */       from.resetCycleEdge();
/*      */     }
/*  494 */     return outEdge;
/*      */   }
/*      */   
/*      */   public RGEdge addEdge(RGNode from, RGNode to, short id, int timeTransition) {
/*  498 */     int out = 0;
/*  499 */     int in = 0;
/*      */     
/*  501 */     RGEdge outEdge = new TimedEdge(getNet(), from, to, id, timeTransition);
/*      */     
/*  503 */     out = from.addOutgoing(outEdge);
/*  504 */     DestinationEdge sE = null;
/*  505 */     if (this.backEdges) {
/*  506 */       sE = new DestinationEdge(this.pn, to, from, id);
/*      */     }
/*  508 */     in = to.addIngoing(sE);
/*  509 */     to.addIngoingEdge(new TimedEdge(getNet(), from, to, id, timeTransition));
/*  510 */     this.outgoingedges++;
/*      */     
/*  512 */     if (out < this.minout) {
/*  513 */       this.minout = out;
/*      */     }
/*  515 */     if (out > this.maxout) {
/*  516 */       this.maxout = out;
/*      */     }
/*      */     
/*  519 */     this.ingoingedges++;
/*  520 */     if (in < this.minin) {
/*  521 */       this.minin = in;
/*      */     }
/*  523 */     if (in > this.maxin) {
/*  524 */       this.maxin = in;
/*      */     }
/*  526 */     this.edges++;
/*  527 */     if (from == to) {
/*  528 */       from.resetCycleEdge();
/*      */     }
/*      */     
/*  531 */     return outEdge;
/*      */   }
/*      */   
/*      */   public RGEdge addEdge(RGNode from, RGNode to, short id, int timeTransition, Transition[] transitions) {
/*  535 */     int out = 0;
/*  536 */     int in = 0;
/*      */     
/*  538 */     RGEdge outEdge = new MultipleTimedEdge(this.pn, from, to, id, timeTransition, transitions);
/*      */     
/*  540 */     out = from.addOutgoing(outEdge);
/*  541 */     DestinationEdge sE = null;
/*  542 */     if (this.backEdges) {
/*  543 */       sE = new DestinationEdge(this.pn, to, from, id);
/*      */     }
/*  545 */     in = to.addIngoing(sE);
/*  546 */     to.addIngoingEdge(new MultipleTimedEdge(this.pn, from, to, id, timeTransition, transitions));
/*  547 */     this.outgoingedges++;
/*      */     
/*  549 */     if (out < this.minout) {
/*  550 */       this.minout = out;
/*      */     }
/*  552 */     if (out > this.maxout) {
/*  553 */       this.maxout = out;
/*      */     }
/*      */     
/*  556 */     this.ingoingedges++;
/*  557 */     if (in < this.minin) {
/*  558 */       this.minin = in;
/*      */     }
/*  560 */     if (in > this.maxin) {
/*  561 */       this.maxin = in;
/*      */     }
/*  563 */     this.edges++;
/*  564 */     if (from == to) {
/*  565 */       from.resetCycleEdge();
/*      */     }
/*  567 */     return outEdge;
/*      */   }
/*      */   
/*      */   public RGEdge addEdge(RGNode from, RGNode to, short id) {
/*  571 */     int out = 0;
/*  572 */     int in = 0;
/*      */ 
/*      */ 
/*      */     
/*  576 */     RGEdge outEdge = new DestinationEdge(this.pn, from, to, id);
/*  577 */     to.addIngoingEdge(new DestinationEdge(this.pn, from, to, id));
/*  578 */     out = from.addOutgoing(outEdge);
/*  579 */     DestinationEdge sE = null;
/*  580 */     if (this.backEdges) {
/*  581 */       sE = new DestinationEdge(this.pn, to, from, id);
/*      */     }
/*  583 */     in = to.addIngoing(sE);
/*  584 */     this.outgoingedges++;
/*      */     
/*  586 */     if (out < this.minout) {
/*  587 */       this.minout = out;
/*      */     }
/*  589 */     if (out > this.maxout) {
/*  590 */       this.maxout = out;
/*      */     }
/*      */     
/*  593 */     this.ingoingedges++;
/*  594 */     if (in < this.minin) {
/*  595 */       this.minin = in;
/*      */     }
/*  597 */     if (in > this.maxin) {
/*  598 */       this.maxin = in;
/*      */     }
/*  600 */     this.edges++;
/*  601 */     if (from == to) {
/*  602 */       from.resetCycleEdge();
/*      */     }
/*      */     
/*  605 */     return outEdge;
/*      */   }
/*      */   
/*      */   public RGEdge addEdge(RGNode from, RGNode to, RGEdge[] ids) {
/*  609 */     int out = 0;
/*  610 */     int in = 0;
/*  611 */     RGEdge outEdge = new SequenceEdge(getNet(), from, to, ids);
/*  612 */     out = from.addOutgoing(outEdge);
/*  613 */     SequenceEdge sE = null;
/*  614 */     if (this.backEdges) {
/*  615 */       sE = new SequenceEdge(getNet(), to, from, ids);
/*      */     }
/*  617 */     in = to.addIngoing(sE);
/*      */     
/*  619 */     to.addIngoingEdge(new SequenceEdge(getNet(), from, to, ids));
/*      */     
/*  621 */     this.outgoingedges++;
/*      */     
/*  623 */     if (out < this.minout) {
/*  624 */       this.minout = out;
/*      */     }
/*  626 */     if (out > this.maxout) {
/*  627 */       this.maxout = out;
/*      */     }
/*      */     
/*  630 */     this.ingoingedges++;
/*  631 */     if (in < this.minin) {
/*  632 */       this.minin = in;
/*      */     }
/*  634 */     if (in > this.maxin) {
/*  635 */       this.maxin = in;
/*      */     }
/*  637 */     this.edges++;
/*  638 */     if (from == to) {
/*  639 */       from.resetCycleEdge();
/*      */     }
/*      */     
/*  642 */     return outEdge;
/*      */   }
/*      */   
/*      */   public RGEdge addEdge(RGNode from, RGNode to, RGEdge[] ids, boolean concurrent) {
/*  646 */     if (!concurrent) {
/*  647 */       return addEdge(from, to, ids);
/*      */     }
/*  649 */     int out = 0;
/*  650 */     int in = 0;
/*  651 */     RGEdge outEdge = new ConcurrentEdge(getNet(), from, to, ids);
/*  652 */     out = from.addOutgoing(outEdge);
/*  653 */     to.addIngoingEdge(new ConcurrentEdge(getNet(), from, to, ids));
/*  654 */     ConcurrentEdge sE = null;
/*  655 */     if (this.backEdges) {
/*  656 */       sE = new ConcurrentEdge(getNet(), to, from, ids);
/*      */     }
/*  658 */     in = to.addIngoing(sE);
/*      */     
/*  660 */     this.outgoingedges++;
/*      */     
/*  662 */     if (out < this.minout) {
/*  663 */       this.minout = out;
/*      */     }
/*  665 */     if (out > this.maxout) {
/*  666 */       this.maxout = out;
/*      */     }
/*      */     
/*  669 */     this.ingoingedges++;
/*  670 */     if (in < this.minin) {
/*  671 */       this.minin = in;
/*      */     }
/*  673 */     if (in > this.maxin) {
/*  674 */       this.maxin = in;
/*      */     }
/*  676 */     this.edges++;
/*  677 */     if (from == to) {
/*  678 */       from.resetCycleEdge();
/*      */     }
/*      */     
/*  681 */     return outEdge;
/*      */   }
/*      */   
/*      */   public RGEdge addEdge(RGNode from, RGNode to, Short[] ids) {
/*  685 */     int out = 0;
/*  686 */     int in = 0;
/*  687 */     RGEdge outEdge = new MaximumEdge(this.pn, from, to, ids);
/*  688 */     out = from.addOutgoing(outEdge);
/*  689 */     to.addIngoingEdge(new MaximumEdge(this.pn, from, to, ids));
/*  690 */     MaximumEdge sE = null;
/*  691 */     if (this.backEdges) {
/*  692 */       sE = new MaximumEdge(this.pn, to, from, ids);
/*      */     }
/*  694 */     in = to.addIngoing(sE);
/*  695 */     this.outgoingedges++;
/*      */     
/*  697 */     if (out < this.minout) {
/*  698 */       this.minout = out;
/*      */     }
/*  700 */     if (out > this.maxout) {
/*  701 */       this.maxout = out;
/*      */     }
/*      */     
/*  704 */     this.ingoingedges++;
/*  705 */     if (in < this.minin) {
/*  706 */       this.minin = in;
/*      */     }
/*  708 */     if (in > this.maxin) {
/*  709 */       this.maxin = in;
/*      */     }
/*  711 */     this.edges++;
/*  712 */     if (from == to) {
/*  713 */       from.resetCycleEdge();
/*      */     }
/*      */     
/*  716 */     return outEdge;
/*      */   }
/*      */   
/*      */   public RGEdge addEdgeUniversal(RGNode from, RGNode to, RGEdge edge) {
/*  720 */     if (from == null || to == null) {
/*  721 */       return null;
/*      */     }
/*  723 */     int out = 0;
/*  724 */     int in = 0;
/*  725 */     edge.setNext(from, null);
/*  726 */     edge.dest = to;
/*  727 */     out = from.addOutgoing(edge);
/*  728 */     RGEdge sE = null;
/*  729 */     if (this.backEdges)
/*      */     {
/*  731 */       in = to.addIngoing(sE);
/*      */     }
/*      */     
/*  734 */     in = to.addIngoingEdge(new MultipleTimedEdge(this.pn, from, to, edge.getId(), edge.getDistance(), edge.getTransitions()));
/*  735 */     this.outgoingedges++;
/*  736 */     if (out < this.minout) {
/*  737 */       this.minout = out;
/*      */     }
/*  739 */     if (out > this.maxout) {
/*  740 */       this.maxout = out;
/*      */     }
/*  742 */     this.ingoingedges++;
/*  743 */     if (in < this.minin) {
/*  744 */       this.minin = in;
/*      */     }
/*  746 */     if (in > this.maxin) {
/*  747 */       this.maxin = in;
/*      */     }
/*  749 */     this.edges++;
/*  750 */     if (from == to) {
/*  751 */       from.resetCycleEdge();
/*      */     }
/*  753 */     return edge;
/*      */   }
/*      */   
/*      */   public int edges() {
/*  757 */     return this.edges;
/*      */   }
/*      */   
/*      */   public int outavarage() {
/*  761 */     return this.outgoingedges / size();
/*      */   }
/*      */   
/*      */   public int inavarage() {
/*  765 */     return this.ingoingedges / size();
/*      */   }
/*      */   
/*      */   public int minout() {
/*  769 */     return this.minout;
/*      */   }
/*      */   
/*      */   public int maxout() {
/*  773 */     return this.maxout;
/*      */   }
/*      */   
/*      */   public int minin() {
/*  777 */     return this.minin;
/*      */   }
/*      */   
/*      */   public int maxin() {
/*  781 */     return this.maxin;
/*      */   }
/*      */   
/*      */   public void addDeadState(RGNode n) {
/*  785 */     this.deadStates.add(n);
/*      */   }
/*      */   
/*      */   public void determineTerminalSCCs() {
/*  789 */     for (int i = 0; i < this.scc; i++) {
/*  790 */       this.finalScc.add(new Integer(i));
/*      */     }
/*  792 */     for (Iterator<RGNode> it2 = this.vertices.values().iterator(); it2.hasNext(); ) {
/*  793 */       RGNode n = it2.next();
/*  794 */       RGEdge out = n.out();
/*  795 */       while (out != null) {
/*  796 */         if ((out.node(n)).sccNumber != n.sccNumber()) {
/*  797 */           this.finalScc.remove(new Integer(n.sccNumber));
/*      */           break;
/*      */         } 
/*  800 */         if (out instanceof DestinationEdge) {
/*  801 */           ((DestinationEdge)out).getTransition(this.pn).addSZK(n.sccNumber());
/*      */         }
/*  803 */         if (out instanceof TimedEdge);
/*      */         
/*  805 */         if (out instanceof SimpleEdge) {
/*  806 */           if (out instanceof TimedEdge) {
/*  807 */             if (out instanceof MultipleTimedEdge) {
/*  808 */               Transition[] field = ((MultipleTimedEdge)out).getTransitions();
/*  809 */               for (int j = 0; j < field.length; j++) {
/*  810 */                 field[j].addSZK(n.sccNumber());
/*      */               }
/*      */             }
/*  813 */             else if (out.getId() >= 0) {
/*  814 */               ((TimedEdge)out).getTransition(this.pn).addSZK(n.sccNumber());
/*      */             } 
/*      */           } else {
/*      */             
/*  818 */             ((SimpleEdge)out).getTransition(this.pn).addSZK(n.sccNumber());
/*      */           } 
/*      */         }
/*      */         
/*  822 */         out = out.next();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public RGNode getRGNode(String label) throws SafetyException, ExceedsByteException {
/*  828 */     StringTokenizer st = new StringTokenizer(label, " ");
/*  829 */     SortedElementsByteArray sortedElementsByteArray = new SortedElementsByteArray(st.countTokens() / 2);
/*  830 */     ((Marking)sortedElementsByteArray).name = " RGraph getRGNode";
/*  831 */     while (st.hasMoreTokens()) {
/*  832 */       byte id = Byte.parseByte(st.nextToken());
/*  833 */       if (!st.hasMoreTokens()) {
/*  834 */         LOG.error("error in getRGNode by label");
/*  835 */         return null;
/*      */       } 
/*  837 */       byte token = Byte.parseByte(st.nextToken());
/*      */       try {
/*  839 */         sortedElementsByteArray.addPlace(id, token);
/*  840 */       } catch (SafetyException e) {
/*  841 */         RGNode ret = getNode(label);
/*  842 */         return ret;
/*      */       }
/*  844 */       catch (ExceedsByteException ebe) {
/*  845 */         RGNode ret = getNode(label);
/*  846 */         return ret;
/*      */       } 
/*      */     } 
/*  849 */     return getNode(sortedElementsByteArray);
/*      */   }
/*      */   
/*      */   private void reduceSequences2(RGNode n, RGEdge cur, RGNode q, Collection<Pair> reducedEdges, Collection<RGNode> reducedNodes) {
/*  853 */     if (!q.equals(this.first)) {
/*  854 */       RGNode src = n;
/*  855 */       RGEdge store = cur;
/*  856 */       Vector<RGEdge> ids = new Vector<>();
/*  857 */       reducedNodes.add(q);
/*  858 */       ids.add(store);
/*      */       
/*  860 */       RGNode next = q.out().node(q);
/*  861 */       RGNode prev = q;
/*  862 */       store = q.out();
/*  863 */       while (!next.equals(this.first) && next.outDegree == 1) {
/*  864 */         reducedNodes.add(next);
/*  865 */         ids.add(store);
/*  866 */         reducedEdges.add(new Pair(prev, store, next));
/*  867 */         prev = next;
/*  868 */         store = next.out();
/*  869 */         next = next.out().node(next);
/*      */       } 
/*  871 */       reducedEdges.add(new Pair(prev, store, next));
/*  872 */       ids.add(store);
/*  873 */       RGEdge[] ids2 = new RGEdge[ids.size()];
/*  874 */       for (int i = 0; i < ids.size(); i++) {
/*  875 */         ids2[i] = ids.get(i);
/*      */       }
/*  877 */       addEdge(src, next, ids2);
/*  878 */       removeEdge(n, cur, q);
/*      */     } 
/*      */   }
/*      */   
/*      */   class Pair {
/*      */     private final RGNode src;
/*      */     private final RGNode dest;
/*      */     private final RGEdge edge;
/*      */     
/*      */     public Pair(RGNode s, RGEdge e, RGNode d) {
/*  888 */       this.src = s;
/*  889 */       this.dest = d;
/*  890 */       this.edge = e;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  896 */       return this.src.hashCode() * this.dest.hashCode();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/*  901 */       if (!(obj instanceof Pair)) {
/*  902 */         return false;
/*      */       }
/*  904 */       Pair p = (Pair)obj;
/*      */       
/*  906 */       return (p.src.equals(this.src) && p.dest.equals(this.dest) && p.edge.isEqual(this.edge));
/*      */     }
/*      */   }
/*      */   
/*      */   public void reduceSequences() {
/*  911 */     HashSet<Pair> reducedEdges = new HashSet<>();
/*  912 */     HashSet<RGNode> vS = new HashSet<>();
/*  913 */     Stack<StackEntry> st = new Stack<>();
/*  914 */     this.reducedNodes.clear();
/*  915 */     RGNode n = this.first;
/*      */     
/*  917 */     RGEdge cur = n.out();
/*  918 */     StackEntry ste = new StackEntry(n, cur);
/*  919 */     st.push(ste);
/*      */ 
/*      */     
/*      */     while (true) {
/*  923 */       if (!vS.contains(n)) {
/*  924 */         vS.add(n);
/*  925 */         cur = n.out();
/*      */       } 
/*  927 */       if (cur != null) {
/*  928 */         RGNode q = cur.node(n);
/*  929 */         if (q.outDegree == 1 && !this.reducedNodes.contains(n)) {
/*  930 */           reduceSequences2(n, cur, q, reducedEdges, this.reducedNodes);
/*      */         }
/*  932 */         if (!vS.contains(q)) {
/*      */           
/*  934 */           st.push(new StackEntry(n, cur));
/*  935 */           n = q;
/*      */         }
/*      */         else {
/*      */           
/*  939 */           cur = cur.next();
/*      */         } 
/*      */       } else {
/*  942 */         ste = st.pop();
/*  943 */         n = ste.n;
/*  944 */         cur = ste.e.next();
/*      */       } 
/*      */ 
/*      */       
/*  948 */       if (st.isEmpty()) {
/*  949 */         for (Iterator<Pair> iterator = reducedEdges.iterator(); iterator.hasNext(); ) {
/*  950 */           Pair e = iterator.next();
/*  951 */           removeEdge(e.src, e.edge, e.dest);
/*      */         } 
/*  953 */         for (Iterator<RGNode> it = this.reducedNodes.iterator(); it.hasNext(); ) {
/*  954 */           n = it.next();
/*  955 */           removeNode(n);
/*      */         } 
/*  957 */         this.reducedSequences = true;
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   } public void expandSequences() throws SafetyException, ExceedsByteException {
/*  962 */     HashSet<RGNode> copy = new HashSet<>();
/*  963 */     HashSet<Pair> addedEdges = new HashSet<>(); Iterator<RGNode> it;
/*  964 */     for (it = iterator(); it.hasNext();) {
/*  965 */       copy.add(it.next());
/*      */     }
/*      */     
/*  968 */     for (it = this.reducedNodes.iterator(); it.hasNext();) {
/*  969 */       addNode(it.next());
/*      */     }
/*  971 */     this.reducedNodes.clear();
/*      */     
/*  973 */     for (it = copy.iterator(); it.hasNext(); ) {
/*  974 */       RGNode q = it.next();
/*  975 */       RGEdge out = q.out();
/*  976 */       while (out != null) {
/*  977 */         RGNode dest = out.node(q);
/*  978 */         if (out instanceof SequenceEdge) {
/*  979 */           removeEdge(q, out, dest);
/*  980 */           RGEdge[] ids = ((SequenceEdge)out).getIds();
/*  981 */           RGNode cur = q;
/*      */           
/*  983 */           for (int i = 0; i < ids.length; i++) {
/*  984 */             State m = this.pn.getTransition(ids[i].getId()).fire((State)cur.getLabel(), true, true);
/*  985 */             RGNode n = getNode(m);
/*  986 */             Pair toInsert = new Pair(cur, ids[i], n);
/*  987 */             if (!addedEdges.contains(toInsert)) {
/*  988 */               addNode(n);
/*  989 */               addEdge(cur, n, ids[i].getId());
/*  990 */               addedEdges.add(toInsert);
/*      */             } 
/*  992 */             cur = n;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  997 */         out = out.next();
/*      */       } 
/*      */     } 
/*      */     
/* 1001 */     this.reducedSequences = false;
/*      */   }
/*      */   
/*      */   public void reduceInterleaving() {
/* 1005 */     HashSet<RGNode> vS = new HashSet<>();
/* 1006 */     Vector<RGNode> queue = new Vector<>();
/* 1007 */     queue.add(this.first);
/*      */     
/* 1009 */     Vector<RGEdge> reduceableEdges = new Vector<>();
/* 1010 */     while (!queue.isEmpty()) {
/* 1011 */       RGNode n = queue.firstElement();
/* 1012 */       if (!vS.contains(n)) {
/* 1013 */         vS.add(n);
/* 1014 */         queue.remove(n);
/* 1015 */         RGEdge cur = n.out();
/* 1016 */         while (cur != null) {
/* 1017 */           reduceableEdges.clear();
/* 1018 */           RGNode q = n.getSuccessor(cur, this);
/* 1019 */           RGEdge next = cur.next;
/* 1020 */           RGNode q2 = n.getSuccessor(next, this);
/* 1021 */           if (next != null && q.equals(q2)) {
/* 1022 */             reduceableEdges.add(cur);
/*      */           }
/* 1024 */           while (next != null && q.equals(q2)) {
/* 1025 */             reduceableEdges.add(next);
/* 1026 */             next = next.next;
/*      */           } 
/* 1028 */           if (!reduceableEdges.isEmpty()) {
/* 1029 */             RGEdge[] edges = new RGEdge[reduceableEdges.size()];
/* 1030 */             int i = 0;
/* 1031 */             for (Iterator<RGEdge> it = reduceableEdges.iterator(); it.hasNext(); ) {
/* 1032 */               RGEdge e = it.next();
/* 1033 */               edges[i++] = e;
/* 1034 */               removeEdge(n, e, n.getSuccessor(e, this));
/*      */             } 
/* 1036 */             addEdge(n, q, edges, true);
/*      */           } 
/* 1038 */           cur = next;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private class StackEntry {
/*      */     RGNode n;
/*      */     RGEdge e;
/*      */     
/*      */     StackEntry(RGNode v, RGEdge e1) {
/* 1049 */       this.n = v;
/* 1050 */       this.e = e1;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1056 */     StringBuilder buf = new StringBuilder();
/* 1057 */     buf.append("nodes:" + Integer.toString(getNumberOfNodes()));
/* 1058 */     buf.append(" edges:" + Integer.toString(getNumberOfEdges()));
/* 1059 */     buf.append(" scc's:" + Integer.toString(getNumberOfScc()));
/* 1060 */     buf.append(" dst's:" + Integer.toString(getNumberOfDeadStates()));
/* 1061 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfPMarkings() {
/* 1071 */     Vector<Marking> allPMarkings = new Vector<>();
/* 1072 */     for (Iterator<RGNode> it = this.vertices.values().iterator(); it.hasNext(); ) {
/* 1073 */       Marking pMarking = ((RGNode)it.next()).getLabel();
/* 1074 */       if (!allPMarkings.contains(pMarking)) {
/* 1075 */         allPMarkings.add(pMarking);
/*      */       }
/*      */     } 
/* 1078 */     return allPMarkings.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean edgeExists(RGNode start, RGNode end, RGEdge edge) {
/* 1094 */     if (getNode(start.getMarking()) == null || getNode(end.getMarking()) == null) {
/* 1095 */       return false;
/*      */     }
/* 1097 */     RGEdge outEdge = start.out();
/* 1098 */     while (outEdge != null) {
/* 1099 */       if (outEdge.equals(edge)) {
/* 1100 */         return true;
/*      */       }
/* 1102 */       outEdge = outEdge.next();
/*      */     } 
/* 1104 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RGNode getNodeByNumber(int stateNumber) {
/* 1115 */     for (Iterator<RGNode> it = this.vertices.values().iterator(); it.hasNext(); ) {
/* 1116 */       RGNode node = it.next();
/* 1117 */       if (node.getStateNumber() == stateNumber) {
/* 1118 */         return node;
/*      */       }
/*      */     } 
/* 1121 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTimedGraph() {
/* 1130 */     if (this.first != null) {
/* 1131 */       return this.first.getMarking() instanceof charlie.pn.TimedState;
/*      */     }
/* 1133 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNodesString() {
/* 1144 */     StringBuffer stb = new StringBuffer();
/* 1145 */     stb.append("\\begin{Nodes}\n");
/* 1146 */     RGNode[] nodeField = new RGNode[this.vertices.size()];
/* 1147 */     for (Iterator<RGNode> it = this.vertices.values().iterator(); it.hasNext(); ) {
/* 1148 */       RGNode node = it.next();
/* 1149 */       nodeField[node.getStateNumber() - 1] = node;
/*      */     } 
/* 1151 */     for (int i = 0; i < nodeField.length; i++) {
/* 1152 */       stb.append(nodeField[i].getStateNumber() + " - " + this.pn.toLabel(nodeField[i].getMarking()));
/* 1153 */       stb.append("\n");
/*      */     } 
/* 1155 */     stb.append("\\end{Nodes}");
/* 1156 */     return stb.toString();
/*      */   }
/*      */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/RGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */