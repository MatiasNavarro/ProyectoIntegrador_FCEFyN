/*     */ package charlie.rg;
/*     */ 
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Transition;
/*     */ 
/*     */ class MaximumEdge extends RGEdge {
/*     */   RGNode dest;
/*     */   Short[] ids;
/*     */   
/*     */   public MaximumEdge(PlaceTransitionNet _pn, RGNode from, RGNode to, Short[] ids) {
/*  11 */     super(_pn, from, to);
/*  12 */     this.ids = ids;
/*  13 */     this.dest = to;
/*     */   }
/*     */ 
/*     */   
/*     */   public RGEdge copy() {
/*  18 */     return new MaximumEdge(getPN(), this.dest, this.dest, this.ids);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Transition[] getTransitions() {
/*  24 */     Transition[] t = new Transition[this.ids.length];
/*  25 */     for (int i = 0; i < this.ids.length; i++) {
/*  26 */       t[i] = getPN().getTransition(this.ids[i].shortValue());
/*     */     }
/*  28 */     return t;
/*     */   }
/*     */ 
/*     */   
/*     */   public Short[] getIds() {
/*  33 */     return this.ids;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqual(RGEdge e) {
/*  38 */     if (!(e instanceof MaximumEdge)) {
/*  39 */       return false;
/*     */     }
/*  41 */     MaximumEdge me = (MaximumEdge)e;
/*  42 */     if (this.ids.length != me.ids.length) {
/*  43 */       return false;
/*     */     }
/*  45 */     for (int i = 0; i < this.ids.length; ) {
/*  46 */       if (this.ids[i].equals(me.ids[i])) {
/*     */         i++; continue;
/*  48 */       }  return false;
/*     */     } 
/*     */     
/*  51 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  56 */     if (!(o instanceof MaximumEdge)) {
/*  57 */       return false;
/*     */     }
/*  59 */     MaximumEdge me = (MaximumEdge)o;
/*  60 */     if (this.ids.length != me.ids.length) {
/*  61 */       return false;
/*     */     }
/*  63 */     for (int i = 0; i < this.ids.length; ) {
/*  64 */       if (this.ids[i].equals(me.ids[i])) {
/*     */         i++; continue;
/*  66 */       }  return false;
/*     */     } 
/*     */     
/*  69 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getId() {
/*  76 */     return this.ids[0].shortValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel(PlaceTransitionNet pn) {
/*  82 */     StringBuffer buf = new StringBuffer();
/*  83 */     buf.append("(");
/*  84 */     for (int i = 0; i < this.ids.length; i++) {
/*  85 */       buf.append(pn.getTransition(this.ids[i].shortValue()).getName());
/*  86 */       if (i < this.ids.length - 1) {
/*  87 */         buf.append(" | ");
/*     */       }
/*     */     } 
/*  90 */     buf.append(")");
/*  91 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public RGNode node(RGNode v) {
/*  96 */     return this.dest;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDistance() {
/* 101 */     return 0;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/MaximumEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */