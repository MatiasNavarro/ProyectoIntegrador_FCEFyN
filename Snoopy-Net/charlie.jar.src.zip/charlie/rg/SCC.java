/*    */ package charlie.rg;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SCC
/*    */ {
/*    */   private int sccNumber;
/*    */   private RGNode root;
/*    */   private HashSet<RGNode> nodes;
/*    */   
/*    */   public SCC(int sccNumber, RGNode root) {
/* 16 */     this.sccNumber = sccNumber;
/* 17 */     this.nodes = new HashSet<>();
/*    */     
/* 19 */     add(root);
/*    */   }
/*    */   
/*    */   public RGNode getRoot() {
/* 23 */     return this.root;
/*    */   }
/*    */   
/*    */   public int number() {
/* 27 */     return this.sccNumber;
/*    */   }
/*    */   
/*    */   public int size() {
/* 31 */     return this.nodes.size();
/*    */   }
/*    */   
/*    */   public boolean contains(RGNode node) {
/* 35 */     return this.nodes.contains(node);
/*    */   }
/*    */   
/*    */   public void add(RGNode node) {
/* 39 */     if (this.nodes.isEmpty()) {
/* 40 */       this.root = node;
/*    */     }
/* 42 */     this.nodes.add(node);
/*    */   }
/*    */   
/*    */   public Iterator<RGNode> iterator() {
/* 46 */     return this.nodes.iterator();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 51 */     return "#: " + number() + " nodes: " + this.nodes.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public void remove(RGNode node) {
/* 56 */     this.nodes.remove(node);
/* 57 */     if (this.nodes.isEmpty())
/* 58 */       this.root = null; 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/SCC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */