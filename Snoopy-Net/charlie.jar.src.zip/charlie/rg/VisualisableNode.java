package charlie.rg;

public interface VisualisableNode {
  int getColorNumber();
  
  RGNode getRGNode();
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/VisualisableNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */