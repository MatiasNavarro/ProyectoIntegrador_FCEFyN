/*     */ package charlie.rg;
/*     */ 
/*     */ import charlie.ds.Stack;
/*     */ import charlie.pn.Place;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.State;
/*     */ import charlie.pn.Transition;
/*     */ import charlie.pn.TransitionExtended;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ public class StubbornReduction
/*     */   implements Reduction
/*     */ {
/*  19 */   private static final Log LOG = LogFactory.getLog(StubbornReduction.class);
/*     */   
/*     */   private PlaceTransitionNet pn;
/*  22 */   private Collection<Transition> c1 = new HashSet<>();
/*     */   
/*     */   public StubbornReduction(PlaceTransitionNet pn) {
/*  25 */     this.pn = pn;
/*     */   }
/*     */   
/*     */   public Collection<Transition> getTransitions(State m) {
/*  29 */     Transition t = null;
/*  30 */     Transition t2 = null;
/*  31 */     int size = 0;
/*  32 */     Collection<Transition> c = new HashSet<>();
/*  33 */     for (Iterator<Transition> it = this.pn.getTransitions().iterator(); it.hasNext(); ) {
/*  34 */       Object o = it.next();
/*     */       
/*     */       try {
/*  37 */         TransitionExtended transitionExtended = (TransitionExtended)o;
/*  38 */       } catch (ClassCastException e) {
/*  39 */         t2 = (Transition)o;
/*     */       } 
/*     */       
/*  42 */       if (t2.canFire(m)) {
/*  43 */         if (t == null) {
/*  44 */           t = t2;
/*     */         }
/*  46 */         if (t2.getConflicts().size() < t.getConflicts().size()) {
/*  47 */           t = t2;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  52 */     if (t == null) {
/*  53 */       return c;
/*     */     }
/*  55 */     c.add(t);
/*     */     
/*  57 */     c.addAll(t.getConflicts());
/*  58 */     int placeId = -1;
/*  59 */     int preSize = 10000;
/*  60 */     this.c1.clear();
/*     */     
/*  62 */     while (size != c.size()) {
/*  63 */       size = c.size(); Iterator<Transition> iterator;
/*  64 */       for (iterator = c.iterator(); iterator.hasNext(); ) {
/*  65 */         Object o = iterator.next();
/*     */         
/*     */         try {
/*  68 */           TransitionExtended transitionExtended = (TransitionExtended)o;
/*  69 */         } catch (ClassCastException e) {
/*  70 */           t = (Transition)o;
/*     */         } 
/*  72 */         if (!t.canFire(m)) {
/*  73 */           Collection<? extends Number> sg = t.getScapeGoats(m.getPlaceMarking());
/*  74 */           for (Iterator<? extends Number> it2 = sg.iterator(); it2.hasNext(); ) {
/*  75 */             Place p = this.pn.getPlaceById(((Number)it2.next()).intValue());
/*     */             
/*  77 */             int pfsize = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*  91 */             pfsize = p.preNodes().size();
/*     */             
/*  93 */             if (pfsize < preSize) {
/*  94 */               placeId = p.getId();
/*  95 */               preSize = pfsize;
/*     */             } 
/*     */           } 
/*     */           
/*  99 */           if (this.c1 == null) {
/* 100 */             this.c1 = new HashSet<>();
/*     */           }
/* 102 */           for (Iterator<Integer> it_trans = this.pn.getPlaceById(placeId).preNodes().iterator(); it_trans.hasNext(); ) {
/* 103 */             short tid = (short)((Integer)it_trans.next()).intValue();
/* 104 */             this.c1.add(this.pn.getTransition(tid));
/*     */           } 
/*     */         } 
/*     */       } 
/* 108 */       if (this.c1 != null) {
/* 109 */         for (iterator = this.c1.iterator(); iterator.hasNext(); ) {
/* 110 */           Transition t1 = iterator.next();
/*     */           
/* 112 */           if (t1.canFire(m)) {
/* 113 */             c.add(t1);
/*     */           }
/*     */         } 
/*     */         
/* 117 */         this.c1.clear();
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     if (LOG.isDebugEnabled()) {
/* 122 */       LOG.debug(c);
/*     */     }
/*     */     
/* 125 */     return c;
/*     */   }
/*     */   
/*     */   public int getTransitions(State m, Stack<Transition> transitions) {
/* 129 */     int transitionsAdded = 0;
/* 130 */     for (Iterator<Transition> it = getTransitions(m).iterator(); it.hasNext(); ) {
/* 131 */       Transition t = it.next();
/* 132 */       if (t.canFire(m)) {
/* 133 */         transitions.push(t);
/* 134 */         transitionsAdded++;
/*     */       } 
/*     */     } 
/* 137 */     return transitionsAdded;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/StubbornReduction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */