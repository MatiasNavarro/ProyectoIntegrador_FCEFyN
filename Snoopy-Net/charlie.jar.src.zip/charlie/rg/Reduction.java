package charlie.rg;

import charlie.ds.Stack;
import charlie.pn.State;
import charlie.pn.Transition;
import java.util.Collection;

public interface Reduction {
  Collection<Transition> getTransitions(State paramState);
  
  int getTransitions(State paramState, Stack<Transition> paramStack);
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/Reduction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */