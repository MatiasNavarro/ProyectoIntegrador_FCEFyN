/*     */ package charlie.rg;
/*     */ 
/*     */ import charlie.pn.ExceedsByteException;
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.SafetyException;
/*     */ import charlie.pn.State;
/*     */ import charlie.pn.TimedTransition;
/*     */ import charlie.pn.Transition;
/*     */ import java.util.Vector;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ public class RGNode
/*     */   implements VisualisableNode
/*     */ {
/*  18 */   private static final Log LOG = LogFactory.getLog(RGNode.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final PlaceTransitionNet pn;
/*     */ 
/*     */   
/*  25 */   public int transitions = 0;
/*  26 */   public RGEdge out = null;
/*  27 */   public RGEdge in = null;
/*  28 */   private RGEdge inEdge = null;
/*  29 */   public RGEdge lastOut = null;
/*  30 */   public RGEdge lastInEdge = null;
/*  31 */   private byte inEdgeDegree = 0;
/*  32 */   public byte inDegree = 0;
/*  33 */   public byte outDegree = 0;
/*  34 */   public int sccNumber = -1;
/*     */   
/*     */   public boolean hasTimeEdgeOut = false;
/*     */   
/*     */   private State marking;
/*     */   
/*     */   private Boolean cycleEdge;
/*     */   
/*  42 */   private int stateNumber = 0;
/*     */   
/*     */   boolean finished;
/*     */   
/*     */   public RGNode(PlaceTransitionNet _pn, State _marking) {
/*  47 */     if (_marking == null) {
/*  48 */       throw new NullPointerException("marking must not be null");
/*     */     }
/*     */     
/*  51 */     this.pn = _pn;
/*     */     
/*  53 */     this.marking = _marking;
/*  54 */     this.cycleEdge = null;
/*  55 */     this.finished = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlaceTransitionNet getPN() {
/*  64 */     return this.pn;
/*     */   }
/*     */   
/*     */   public RGEdge out() {
/*  68 */     return this.out;
/*     */   }
/*     */   
/*     */   public RGEdge in() {
/*  72 */     return this.in;
/*     */   }
/*     */   
/*     */   public RGEdge inEdge() {
/*  76 */     return this.inEdge;
/*     */   }
/*     */   public void setInEdge(RGEdge in) {
/*  79 */     this.inEdge = in;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColorNumber() {
/*  84 */     return sccNumber();
/*     */   }
/*     */   
/*     */   public RGNode getRGNode() {
/*  88 */     return this;
/*     */   }
/*     */   
/*     */   public boolean isDeadState() {
/*  92 */     return (this.out == null);
/*     */   }
/*     */   
/*     */   public Marking getLabel() {
/*  96 */     return this.marking.getPlaceMarking();
/*     */   }
/*     */   
/*     */   public RGNode getSuccessor(RGEdge out, RGraph rg) {
/*     */     try {
/* 101 */       if (out == null) {
/* 102 */         return null;
/*     */       }
/* 104 */       if (out instanceof SimpleEdge) {
/* 105 */         Transition t = getPN().getTransition(out.getId());
/*     */         
/* 107 */         return rg.getNode(t.fire((State)getLabel(), true, true));
/*     */       } 
/* 109 */       if (out instanceof TimedEdge) {
/* 110 */         TimedTransition timedTransition = (TimedTransition)getPN().getTransition(out.getId());
/*     */       }
/* 112 */       return out.node(null);
/* 113 */     } catch (SafetyException se) {
/* 114 */       LOG.error(se.getMessage(), (Throwable)se);
/* 115 */     } catch (ExceedsByteException ebe) {
/* 116 */       LOG.error(ebe.getMessage(), (Throwable)ebe);
/*     */     } 
/*     */     
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 124 */     if (!(obj instanceof RGNode)) {
/* 125 */       return false;
/*     */     }
/* 127 */     return getMarking().equals(((RGNode)obj).getMarking());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 132 */     return getLabel().hashCode();
/*     */   }
/*     */   
/*     */   public int addIngoing(RGEdge inRGEdge) {
/* 136 */     if (inRGEdge != null) {
/* 137 */       inRGEdge.setNext(this, this.in);
/* 138 */       this.in = inRGEdge;
/*     */     } 
/* 140 */     this.inDegree = (byte)(this.inDegree + 1);
/*     */     
/* 142 */     return this.inDegree;
/*     */   }
/*     */   
/*     */   public int addIngoingEdge(RGEdge inRGEdge) {
/* 146 */     if (inRGEdge instanceof TimedEdge && ((TimedEdge)inRGEdge).getTimeTransition() > 0 && inRGEdge.getId() == -1) {
/* 147 */       if (this.inEdge == null) {
/* 148 */         this.lastInEdge = inRGEdge;
/*     */       }
/* 150 */       if (inRGEdge != null) {
/* 151 */         inRGEdge.setNext(this, this.inEdge);
/* 152 */         this.inEdge = inRGEdge;
/*     */       }
/*     */     
/* 155 */     } else if (this.lastInEdge == null) {
/*     */       
/* 157 */       this.lastInEdge = inRGEdge;
/* 158 */       this.inEdge = inRGEdge;
/*     */     } else {
/*     */       
/* 161 */       this.lastInEdge.next = inRGEdge;
/* 162 */       this.lastInEdge = inRGEdge;
/*     */     } 
/*     */     
/* 165 */     this.inEdgeDegree = (byte)(this.inEdgeDegree + 1);
/*     */     
/* 167 */     return this.inEdgeDegree;
/*     */   }
/*     */   
/*     */   public int addOutgoing(RGEdge outRGEdge) {
/* 171 */     if (outRGEdge instanceof TimedEdge && ((TimedEdge)outRGEdge).getTimeTransition() > 0 && outRGEdge.getId() == -1) {
/* 172 */       outRGEdge.next = this.out;
/* 173 */       this.out = outRGEdge;
/* 174 */       if (this.out.next() == null) {
/* 175 */         this.lastOut = this.out;
/*     */       }
/*     */     }
/* 178 */     else if (this.lastOut == null) {
/* 179 */       this.lastOut = outRGEdge;
/* 180 */       this.out = outRGEdge;
/*     */     } else {
/* 182 */       this.lastOut.next = outRGEdge;
/* 183 */       this.lastOut = outRGEdge;
/*     */     } 
/*     */     
/* 186 */     this.outDegree = (byte)(this.outDegree + 1);
/*     */     
/* 188 */     return this.outDegree;
/*     */   }
/*     */   
/*     */   public RGNode copy() {
/* 192 */     RGNode copy = new RGNode(getPN(), getMarking());
/* 193 */     return copy;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 198 */     return getMarking().toString();
/*     */   }
/*     */   
/*     */   public int sccNumber() {
/* 202 */     return this.sccNumber;
/*     */   }
/*     */   
/*     */   public void setSccNumber(int scc) {
/* 206 */     this.sccNumber = scc;
/*     */   }
/*     */   
/*     */   public void removePre(RGEdge e, RGNode from) {
/* 210 */     RGEdge prev = this.in;
/* 211 */     while (prev != null) {
/* 212 */       RGNode node = prev.node(null);
/* 213 */       if (!node.equals(from) || !e.isEqual(prev)) {
/* 214 */         prev = prev.next();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 219 */     if (prev == null) {
/*     */       return;
/*     */     }
/* 222 */     RGNode src = prev.node(null);
/* 223 */     RGEdge preOut = src.out;
/* 224 */     if (preOut != null && preOut.node(src).equals(this)) {
/* 225 */       (prev.node(null)).out = preOut.next();
/* 226 */       from.outDegree = (byte)(from.outDegree - 1);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 231 */     while (preOut != null && preOut.next() != null) {
/* 232 */       if (preOut.next().node(src).equals(this)) {
/* 233 */         preOut.setNext(this, preOut.next().next());
/* 234 */         from.outDegree = (byte)(from.outDegree - 1);
/*     */         
/*     */         return;
/*     */       } 
/* 238 */       preOut = preOut.next();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removePost(RGEdge e, RGNode to) {
/* 243 */     RGEdge post = this.out;
/* 244 */     while (post != null) {
/*     */       
/* 246 */       RGNode node = post.node(this);
/* 247 */       if (!node.equals(to) || !e.isEqual(post)) {
/* 248 */         post = post.next();
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 254 */     if (post == null) {
/*     */       return;
/*     */     }
/* 257 */     RGEdge preIn = (post.node(this)).in;
/* 258 */     boolean b = true;
/* 259 */     if (to.equals(this)) {
/* 260 */       b = false;
/* 261 */       this.inDegree = (byte)(this.inDegree - 1);
/*     */     } 
/* 263 */     if (b && preIn != null && preIn.node(null).equals(this)) {
/* 264 */       (post.node(this)).in = preIn.next();
/* 265 */       to.inDegree = (byte)(to.inDegree - 1);
/* 266 */       b = false;
/*     */     } 
/* 268 */     while (b && preIn != null && preIn.next() != null) {
/*     */       
/* 270 */       if (preIn.next().node(null).equals(this)) {
/* 271 */         preIn.setNext(this, preIn.next().next());
/* 272 */         to.inDegree = (byte)(to.inDegree - 1);
/*     */         
/* 274 */         b = false;
/*     */       } 
/* 276 */       preIn = preIn.next();
/*     */     } 
/*     */ 
/*     */     
/* 280 */     post = this.out;
/*     */     
/* 282 */     if (post != null && post.node(this).equals(to)) {
/* 283 */       this.out = this.out.next();
/* 284 */       this.outDegree = (byte)(this.outDegree - 1);
/*     */       return;
/*     */     } 
/* 287 */     while (post != null && post.next() != null) {
/*     */       
/* 289 */       if (post.next().node(this).equals(to)) {
/* 290 */         post.setNext(this, post.next().next());
/* 291 */         this.outDegree = (byte)(this.outDegree - 1);
/*     */         
/*     */         return;
/*     */       } 
/* 295 */       post = post.next();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public State getMarking() {
/* 305 */     return this.marking;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStateNumber() {
/* 314 */     return this.stateNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStateNumber(int stateNumber) {
/* 323 */     this.stateNumber = stateNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasCycleEdge() {
/* 332 */     if (this.cycleEdge != null) {
/* 333 */       return this.cycleEdge.booleanValue();
/*     */     }
/* 335 */     RGEdge outEdge = out();
/* 336 */     while (outEdge != null) {
/*     */       
/* 338 */       if (outEdge.dest == this) {
/*     */         
/* 340 */         this.cycleEdge = new Boolean(true);
/* 341 */         return true;
/*     */       } 
/* 343 */       outEdge = outEdge.next();
/*     */     } 
/* 345 */     this.cycleEdge = new Boolean(false);
/* 346 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetCycleEdge() {
/* 353 */     this.cycleEdge = null;
/* 354 */     hasCycleEdge();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector<RGEdge> getAllOutEdges() {
/* 363 */     Vector<RGEdge> tEdges = new Vector<>();
/* 364 */     RGEdge e = out();
/* 365 */     while (e != null) {
/* 366 */       tEdges.add(e);
/* 367 */       e = e.next();
/*     */     } 
/* 369 */     return tEdges;
/*     */   }
/*     */   
/*     */   public boolean finished() {
/* 373 */     return (this.transitions == 0 && this.hasTimeEdgeOut);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/RGNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */