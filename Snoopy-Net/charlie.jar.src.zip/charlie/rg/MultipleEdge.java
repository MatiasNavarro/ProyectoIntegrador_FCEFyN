/*    */ package charlie.rg;
/*    */ 
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.pn.Transition;
/*    */ 
/*    */ public abstract class MultipleEdge
/*    */   extends RGEdge
/*    */ {
/*    */   RGNode d;
/*    */   protected RGEdge[] edges;
/*    */   
/*    */   public MultipleEdge(PlaceTransitionNet _pn, RGNode from, RGNode to, RGEdge[] e) {
/* 13 */     super(_pn, from, to);
/* 14 */     this.edges = e;
/* 15 */     this.d = to;
/*    */   }
/*    */ 
/*    */   
/*    */   public Transition[] getTransitions() {
/* 20 */     Transition[] t = new Transition[this.edges.length];
/* 21 */     for (int i = 0; i < this.edges.length; i++) {
/* 22 */       t[i] = getPN().getTransition(this.edges[i].getId());
/*    */     }
/* 24 */     return t;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDistance() {
/* 29 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 34 */     if (!(o instanceof MultipleEdge)) {
/* 35 */       return false;
/*    */     }
/* 37 */     MultipleEdge me = (MultipleEdge)o;
/* 38 */     if (this.edges.length != me.edges.length) {
/* 39 */       return false;
/*    */     }
/* 41 */     for (int i = 0; i < this.edges.length; ) {
/* 42 */       if (this.edges[i].equals(me.edges[i])) {
/*    */         i++; continue;
/* 44 */       }  return false;
/*    */     } 
/*    */     
/* 47 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEqual(RGEdge e) {
/* 52 */     if (!(e instanceof MultipleEdge)) {
/* 53 */       return false;
/*    */     }
/* 55 */     MultipleEdge me = (MultipleEdge)e;
/* 56 */     if (this.edges.length != me.edges.length) {
/* 57 */       return false;
/*    */     }
/* 59 */     for (int i = 0; i < this.edges.length; ) {
/* 60 */       if (this.edges[i].isEqual(me.edges[i])) {
/*    */         i++; continue;
/*    */       } 
/* 63 */       return false;
/*    */     } 
/*    */     
/* 66 */     return true;
/*    */   }
/*    */   
/*    */   public RGEdge[] getIds() {
/* 70 */     return this.edges;
/*    */   }
/*    */ 
/*    */   
/*    */   public short getId() {
/* 75 */     return -1;
/*    */   }
/*    */ 
/*    */   
/*    */   public RGNode node(RGNode v) {
/* 80 */     return this.d;
/*    */   }
/*    */   
/*    */   public abstract String getLabel(PlaceTransitionNet paramPlaceTransitionNet);
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/rg/MultipleEdge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */