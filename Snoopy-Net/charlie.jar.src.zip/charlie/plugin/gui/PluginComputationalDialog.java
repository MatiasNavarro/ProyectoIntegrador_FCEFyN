/*    */ package charlie.plugin.gui;
/*    */ 
/*    */ import GUI.IDirector;
/*    */ import GUI.app_components.ComputationalDialog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PluginComputationalDialog
/*    */   extends ComputationalDialog
/*    */ {
/*    */   private static final long serialVersionUID = 566807309555148196L;
/*    */   
/*    */   protected PluginComputationalDialog(IDirector director) {
/* 23 */     super(director);
/*    */   }
/*    */   
/*    */   public abstract String getDescription();
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/gui/PluginComputationalDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */