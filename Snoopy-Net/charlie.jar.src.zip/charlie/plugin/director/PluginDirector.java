/*     */ package charlie.plugin.director;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import java.io.File;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PluginDirector
/*     */   implements IDirector
/*     */ {
/*  19 */   private static final Log LOG = LogFactory.getLog(PluginDirector.class);
/*     */   
/*  21 */   private PlaceTransitionNet pn = null;
/*     */ 
/*     */ 
/*     */   
/*     */   protected PluginDirector(IDirector director, JFrame parent) {}
/*     */ 
/*     */   
/*     */   protected PlaceTransitionNet getLoadedPlaceTransitionNet() {
/*  29 */     return this.pn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void initialize();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getDescription();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getSessionPropertyName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getSessionFileExtension();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JPanel getExternalDialog();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean sendMessage(int _messageType, Object _source, Object _object) {
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object externalMessage(int _messageTpe, Object _source, Object _object) {
/*     */     OptionSet options;
/*     */     String[] values;
/*  99 */     switch (_messageTpe) {
/*     */       case 12:
/* 101 */         doDebugNet();
/* 102 */         return null;
/*     */       case 11:
/* 104 */         options = (OptionSet)_object;
/* 105 */         doAnalyzeNet(options);
/* 106 */         return null;
/*     */       case 7:
/* 108 */         values = (String[])_object;
/* 109 */         if (values.length <= 1) {
/* 110 */           throw new RuntimeException("If a property shall be set there must be at least two string parameters.");
/*     */         }
/*     */         
/* 113 */         if (values[0] != null) {
/* 114 */           values[0] = values[0].trim();
/*     */         }
/* 116 */         if (values[1] != null) {
/* 117 */           values[1] = values[1].trim();
/*     */         }
/* 119 */         return doSetProperty(values[0], values[1]);
/*     */       case 6:
/* 121 */         return doWindowNormalized();
/*     */       case 1:
/* 123 */         return doNetLoaded((File)_object);
/*     */       case 14:
/* 125 */         return setNet((PlaceTransitionNet)_object);
/*     */       case 0:
/* 127 */         return netUpdated((PlaceTransitionNet)_object);
/*     */       case 3:
/* 129 */         doExit();
/* 130 */         return null;
/*     */       case 5:
/* 132 */         return doFocus();
/*     */       case 4:
/* 134 */         return doReloadNet();
/*     */       case 8:
/* 136 */         return doSaveSession((File)_object);
/*     */       case 9:
/* 138 */         return doLoadSession((File)_object);
/*     */       case 13:
/* 140 */         return doWriteLogFile();
/*     */     } 
/*     */     
/* 143 */     LOG.warn(String.format("Received message (%d, %s, %s) but could not handle this message.", new Object[] {
/* 144 */             Integer.valueOf(_messageTpe), _source, _object
/*     */           }));
/*     */ 
/*     */     
/* 148 */     return null;
/*     */   }
/*     */   
/*     */   protected Object doWriteLogFile() {
/* 152 */     return null;
/*     */   }
/*     */   
/*     */   protected Object doLoadSession(File object) {
/* 156 */     return null;
/*     */   }
/*     */   
/*     */   protected Object doSaveSession(File object) {
/* 160 */     return null;
/*     */   }
/*     */   
/*     */   protected Object doReloadNet() {
/* 164 */     return null;
/*     */   }
/*     */   
/*     */   protected Object doFocus() {
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void doExit();
/*     */ 
/*     */ 
/*     */   
/*     */   private Object netUpdated(PlaceTransitionNet _pn) {
/* 178 */     this.pn = _pn;
/*     */     
/* 180 */     return doNetUpdated(_pn);
/*     */   }
/*     */   
/*     */   protected Object doNetUpdated(PlaceTransitionNet _pn) {
/* 184 */     return null;
/*     */   }
/*     */   
/*     */   private Object setNet(PlaceTransitionNet _pn) {
/* 188 */     this.pn = _pn;
/*     */     
/* 190 */     return doSetNet(_pn);
/*     */   }
/*     */   
/*     */   protected Object doSetNet(PlaceTransitionNet _pn) {
/* 194 */     return null;
/*     */   }
/*     */   
/*     */   protected Object doNetLoaded(File object) {
/* 198 */     return null;
/*     */   }
/*     */   
/*     */   protected Object doWindowNormalized() {
/* 202 */     return null;
/*     */   }
/*     */   
/*     */   protected Object doSetProperty(String string, String string2) {
/* 206 */     return null;
/*     */   }
/*     */   
/*     */   protected void doAnalyzeNet(OptionSet options) {}
/*     */   
/*     */   protected void doDebugNet() {}
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/director/PluginDirector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */