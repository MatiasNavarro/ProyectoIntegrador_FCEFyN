/*     */ package charlie.plugin.director;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import GUI.preference.FilterFactory;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PluginFilterPreferencePanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = -6627790094838525956L;
/*     */   private final IDirector director;
/*     */   
/*     */   protected PluginFilterPreferencePanel(IDirector _director) {
/*  37 */     if (_director == null) {
/*  38 */       throw new IllegalArgumentException("The director must not be null.");
/*     */     }
/*  40 */     this.director = _director;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDirector getDirector() {
/*  49 */     return this.director;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getAnalyzerName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() {
/*  65 */     setLayout(new BorderLayout());
/*     */     
/*  67 */     add(new JLabel("unselect checkboxes to filter output"), "North");
/*     */     
/*  69 */     if (getSettingLabelsTree() == null) {
/*     */       
/*  71 */       double[][] size = new double[2][];
/*  72 */       (new double[3])[0] = 5.0D; (new double[3])[1] = -1.0D; (new double[3])[2] = 5.0D; size[0] = new double[3];
/*  73 */       size[1] = new double[2 + (getSettingKeys()).length];
/*  74 */       size[1][0] = 5.0D;
/*  75 */       size[1][(getSettingKeys()).length] = 5.0D;
/*  76 */       for (int i = 0; i < (getSettingKeys()).length; i++) {
/*  77 */         size[1][i + 1] = 25.0D;
/*     */       }
/*     */       
/*  80 */       TableLayout layout = new TableLayout(size);
/*     */       
/*  82 */       JPanel settingsPanel = new JPanel();
/*  83 */       settingsPanel.setLayout((LayoutManager)layout);
/*     */ 
/*     */       
/*  86 */       for (int j = 0; j < (getSettingLabels()).length; j++) {
/*     */         
/*  88 */         final String key = getSettingKeys()[j];
/*     */         
/*  90 */         boolean filterEnabled = FilterFactory.getFilterProperties().isFiltered(key);
/*     */ 
/*     */         
/*  93 */         final JCheckBox checkbox = new JCheckBox(getSettingLabels()[j]);
/*     */ 
/*     */         
/*  96 */         checkbox.setSelected(!filterEnabled);
/*     */         
/*  98 */         if (getToolTips() != null)
/*     */         {
/* 100 */           checkbox.setToolTipText(getToolTips()[j]);
/*     */         }
/*     */ 
/*     */         
/* 104 */         checkbox.addActionListener(new ActionListener()
/*     */             {
/*     */               
/*     */               public void actionPerformed(ActionEvent e)
/*     */               {
/* 109 */                 FilterFactory.getFilterProperties().setProperty(key, Boolean.toString(!checkbox.isSelected()));
/*     */               }
/*     */             });
/*     */ 
/*     */         
/* 114 */         settingsPanel.add(checkbox, "1," + (j + 1));
/* 115 */         add(settingsPanel, "Center");
/*     */       } 
/*     */     } else {
/*     */       
/* 119 */       int treesize = 0;
/* 120 */       for (int i = 0; i < (getSettingLabelsTree()).length; i++) {
/* 121 */         treesize += (getSettingLabelsTree()[i]).length;
/*     */       }
/*     */ 
/*     */       
/* 125 */       double[][] size = new double[2][];
/* 126 */       (new double[3])[0] = 5.0D; (new double[3])[1] = -1.0D; (new double[3])[2] = 5.0D; size[0] = new double[3];
/* 127 */       size[1] = new double[2 + treesize];
/* 128 */       size[1][0] = 5.0D;
/* 129 */       size[1][(getSettingKeys()).length] = 5.0D;
/* 130 */       for (int j = 0; j < treesize; j++) {
/* 131 */         size[1][j + 1] = 25.0D;
/*     */       }
/*     */       
/* 134 */       TableLayout layout = new TableLayout(size);
/*     */       
/* 136 */       JPanel settingsPanel = new JPanel();
/* 137 */       settingsPanel.setLayout((LayoutManager)layout);
/*     */ 
/*     */       
/* 140 */       for (int k = 0; k < (getSettingLabelsTree()).length; k++) {
/* 141 */         for (int m = 0; m < (getSettingLabelsTree()[k]).length; m++) {
/*     */           
/* 143 */           final String key = getSettingKeysTree()[k][m];
/*     */           
/* 145 */           boolean filterEnabled = FilterFactory.getFilterProperties().isFiltered(key);
/*     */ 
/*     */           
/* 148 */           final JCheckBox checkbox = new JCheckBox(getSettingLabelsTree()[k][m]);
/*     */ 
/*     */           
/* 151 */           checkbox.setSelected(!filterEnabled);
/*     */           
/* 153 */           if (getToolTips() != null)
/*     */           {
/* 155 */             checkbox.setToolTipText(getToolTips()[k]);
/*     */           }
/*     */ 
/*     */           
/* 159 */           checkbox.addActionListener(new ActionListener()
/*     */               {
/*     */                 
/*     */                 public void actionPerformed(ActionEvent e)
/*     */                 {
/* 164 */                   FilterFactory.getFilterProperties().setProperty(key, Boolean.toString(!checkbox.isSelected()));
/*     */                 }
/*     */               });
/*     */ 
/*     */           
/* 169 */           if (m > 0) {
/*     */             
/* 171 */             JPanel p = new JPanel(new FlowLayout(0));
/* 172 */             p.add(new JLabel("-"));
/* 173 */             p.add(checkbox);
/*     */ 
/*     */             
/* 176 */             settingsPanel.add(p, "1," + (k + m + 1));
/*     */           } else {
/*     */             
/* 179 */             settingsPanel.add(checkbox, "1," + (k + 1));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 184 */       add(settingsPanel, "Center");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String[] getSettingLabels();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String[] getSettingKeys();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[][] getSettingLabelsTree() {
/* 217 */     return (String[][])null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[][] getSettingKeysTree() {
/* 229 */     return (String[][])null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getToolTips() {
/* 239 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/director/PluginFilterPreferencePanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */