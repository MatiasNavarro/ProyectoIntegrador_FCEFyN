/*    */ package charlie.plugin;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PluginClassLoaderManager
/*    */ {
/* 26 */   private static final Log LOG = LogFactory.getLog(PluginClassLoaderManager.class);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 31 */   private static final Map<String, Class<?>> clazzMap = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   private static final Set<PluginLibClassLoader> libClassLoaderSet = new HashSet<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void register(PluginLibClassLoader _classLoader) {
/* 47 */     libClassLoaderSet.add(_classLoader);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addClass(String _name, Class<?> _clazz) {
/* 57 */     clazzMap.put(_name, _clazz);
/*    */   }
/*    */   
/*    */   public Class<?> findClass(String _name, PluginLibClassLoader _loader) throws ClassNotFoundException {
/* 61 */     if (clazzMap.containsKey(_name)) {
/* 62 */       return clazzMap.get(_name);
/*    */     }
/*    */     
/* 65 */     for (PluginLibClassLoader loader : libClassLoaderSet) {
/* 66 */       if (!_loader.equals(loader)) {
/*    */         try {
/* 68 */           Class<?> clazz = loader.getClass(_name);
/* 69 */           return clazz;
/* 70 */         } catch (ClassNotFoundException e) {
/*    */           
/* 72 */           if (LOG.isDebugEnabled()) {
/* 73 */             LOG.debug(e.getMessage(), e);
/*    */           }
/*    */         } 
/*    */       }
/*    */     } 
/*    */     
/* 79 */     return _loader.getParent().loadClass(_name);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/PluginClassLoaderManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */