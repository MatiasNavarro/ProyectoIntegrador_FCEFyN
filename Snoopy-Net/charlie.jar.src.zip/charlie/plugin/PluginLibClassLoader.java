/*     */ package charlie.plugin;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipException;
/*     */ import java.util.zip.ZipFile;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PluginLibClassLoader
/*     */   extends URLClassLoader
/*     */ {
/*  29 */   private static final Log LOG = LogFactory.getLog(PluginLibClassLoader.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  34 */   private final Map<String, Class<?>> clazzMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   private final Map<String, Class<?>> libClazzMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final PluginClassLoaderManager manager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PluginLibClassLoader(PluginClassLoaderManager _manager, URL _archiveURL) {
/*  52 */     super(new URL[] { _archiveURL });
/*     */     
/*  54 */     this.manager = _manager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getArchive() {
/*  63 */     return getURLs()[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getClass(String _name) throws ClassNotFoundException {
/*  73 */     if (this.clazzMap.containsKey(_name)) {
/*  74 */       return this.clazzMap.get(_name);
/*     */     }
/*  76 */     Class<?> clazz = findClass(_name);
/*  77 */     this.clazzMap.put(_name, clazz);
/*  78 */     this.manager.addClass(_name, clazz);
/*     */     
/*  80 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> loadClass(String _name) throws ClassNotFoundException {
/*  87 */     if (this.clazzMap.containsKey(_name))
/*  88 */       return this.clazzMap.get(_name); 
/*  89 */     if (this.libClazzMap.containsKey(_name)) {
/*  90 */       return this.libClazzMap.get(_name);
/*     */     }
/*     */     
/*  93 */     if (LOG.isTraceEnabled()) {
/*  94 */       LOG.trace("Try loading class: " + _name);
/*     */     }
/*     */     
/*     */     try {
/*  98 */       Class<?> clazz = findClass(_name);
/*  99 */       this.clazzMap.put(_name, clazz);
/* 100 */       this.manager.addClass(_name, clazz);
/*     */       
/* 102 */       if (LOG.isDebugEnabled()) {
/* 103 */         LOG.debug("loaded class: " + _name);
/*     */       }
/*     */       
/* 106 */       return clazz;
/* 107 */     } catch (ClassNotFoundException e) {
/*     */       try {
/* 109 */         Class<?> clazz = findLibClassInZip(_name);
/* 110 */         this.libClazzMap.put(_name, clazz);
/*     */         
/* 112 */         if (LOG.isDebugEnabled()) {
/* 113 */           LOG.debug("loaded class: " + _name);
/*     */         }
/*     */         
/* 116 */         return clazz;
/* 117 */       } catch (ClassNotFoundException e2) {
/* 118 */         return this.manager.findClass(_name, this);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> findLibClassInZip(String _name) throws ClassNotFoundException {
/* 134 */     String path = _name.replace('.', '/') + ".class";
/* 135 */     String libPath = "lib/" + path;
/*     */     
/*     */     try {
/* 138 */       ZipFile zipFile = new ZipFile(new File(getArchive().toURI()));
/* 139 */       Enumeration<? extends ZipEntry> enumeration = zipFile.entries();
/* 140 */       while (enumeration.hasMoreElements()) {
/* 141 */         ZipEntry entry = enumeration.nextElement();
/* 142 */         if (entry.getName().equals(libPath)) {
/*     */           
/* 144 */           InputStream inputStream = zipFile.getInputStream(entry);
/* 145 */           Class<?> clazz = readClass(_name, inputStream);
/* 146 */           inputStream.close();
/* 147 */           zipFile.close();
/*     */           
/* 149 */           return clazz;
/* 150 */         }  if (entry.getName().endsWith(".zip") || entry.getName().endsWith(".jar")) {
/*     */ 
/*     */           
/* 153 */           ZipInputStream inputStream = new ZipInputStream(zipFile.getInputStream(entry));
/*     */           
/*     */           ZipEntry entryInZip;
/* 156 */           while ((entryInZip = inputStream.getNextEntry()) != null) {
/* 157 */             if (entryInZip.getName().equals(path)) {
/* 158 */               Class<?> clazz = readClass(_name, inputStream);
/* 159 */               inputStream.close();
/* 160 */               zipFile.close();
/*     */               
/* 162 */               return clazz;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 169 */       zipFile.close();
/* 170 */     } catch (URISyntaxException uRISyntaxException) {
/*     */     
/* 172 */     } catch (ZipException zipException) {
/*     */     
/* 174 */     } catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     throw new ClassNotFoundException(String.format("Could not find the class '%s'.", new Object[] { _name }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> readClass(String _className, InputStream _input) throws IOException {
/* 198 */     byte[] buffer = new byte[8192];
/*     */     
/* 200 */     int count = 0;
/*     */     
/* 202 */     byte[] b = new byte[4096];
/* 203 */     int read = _input.read(b);
/* 204 */     while (read > 0) {
/* 205 */       if (count + read > buffer.length) {
/*     */         
/* 207 */         byte[] tmp = new byte[2 * buffer.length];
/* 208 */         System.arraycopy(buffer, 0, tmp, 0, buffer.length);
/* 209 */         buffer = tmp;
/*     */       } 
/*     */       
/* 212 */       System.arraycopy(b, 0, buffer, count, read);
/*     */       
/* 214 */       count += read;
/*     */ 
/*     */       
/* 217 */       read = _input.read(b);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 222 */     return defineClass(_className, buffer, 0, count);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 227 */     int prime = 31;
/* 228 */     int result = 1;
/* 229 */     result = 31 * result + ((getArchive() == null) ? 0 : getArchive().hashCode());
/* 230 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 235 */     if (this == obj) {
/* 236 */       return true;
/*     */     }
/* 238 */     if (obj == null) {
/* 239 */       return false;
/*     */     }
/* 241 */     if (getClass() != obj.getClass()) {
/* 242 */       return false;
/*     */     }
/* 244 */     PluginLibClassLoader other = (PluginLibClassLoader)obj;
/* 245 */     return other.getArchive().equals(getArchive());
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/PluginLibClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */