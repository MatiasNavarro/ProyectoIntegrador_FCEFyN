/*    */ package charlie.plugin.analyzer;
/*    */ 
/*    */ import charlie.pn.rules.Rule;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PluginRuleExtender
/*    */ {
/*    */   public List<Rule> getAdditionalRules() {
/* 38 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<PluginResult> getAddionionalResults() {
/* 49 */     return Collections.emptyList();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/analyzer/PluginRuleExtender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */