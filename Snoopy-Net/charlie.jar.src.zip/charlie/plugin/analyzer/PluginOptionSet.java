/*    */ package charlie.plugin.analyzer;
/*    */ 
/*    */ import charlie.analyzer.OptionSet;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PluginOptionSet
/*    */   extends OptionSet
/*    */ {
/*    */   public static final String DESCRIPTION = "description";
/*    */   
/*    */   public Map<String, String> getHelpMap() {
/* 32 */     Map<String, String> helpMap = new HashMap<>();
/* 33 */     helpMap.put("description", "There is no help available for the analyzer.");
/*    */     
/* 35 */     return helpMap;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/analyzer/PluginOptionSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */