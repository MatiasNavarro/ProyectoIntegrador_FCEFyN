/*     */ package charlie.plugin.analyzer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PluginResult
/*     */ {
/*     */   private final String key;
/*     */   private final String abbreviation;
/*     */   private final String tooltip;
/*     */   private final String description;
/*     */   
/*     */   public PluginResult(String _key, String _abbreviation, String _tooltip, String _description) {
/*  35 */     if (_key == null) {
/*  36 */       throw new IllegalArgumentException("The key must not be null.");
/*     */     }
/*  38 */     if (_abbreviation == null) {
/*  39 */       throw new IllegalArgumentException("The abbreviation must not be null.");
/*     */     }
/*     */     
/*  42 */     this.key = _key;
/*  43 */     this.abbreviation = _abbreviation;
/*  44 */     this.tooltip = _tooltip;
/*  45 */     this.description = _description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PluginResult(String _key, String _abbreviation, String _tooltip) {
/*  60 */     this(_key, _abbreviation, _tooltip, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAbbreviation() {
/*  70 */     return this.abbreviation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTooltip() {
/*  79 */     return this.tooltip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  88 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  97 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/* 107 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/analyzer/PluginResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */