/*    */ package charlie.plugin.analyzer;
/*    */ 
/*    */ import charlie.analyzer.Analyzer;
/*    */ import charlie.analyzer.Initiator;
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PluginAnalyzer
/*    */   extends Analyzer
/*    */ {
/*    */   public abstract String getName();
/*    */   
/*    */   public abstract boolean registerAnalyzer();
/*    */   
/*    */   public PluginOptionSet setupPluginOptionSet(Initiator _initiator, PlaceTransitionNet _pn) {
/* 62 */     return new PluginOptionSet()
/*    */       {
/*    */         public String toString()
/*    */         {
/* 66 */           return PluginAnalyzer.this.getName();
/*    */         }
/*    */ 
/*    */         
/*    */         public boolean initializeByString(String parameters) {
/* 71 */           return false;
/*    */         }
/*    */ 
/*    */         
/*    */         public boolean initByProperties(Properties props) {
/* 76 */           return false;
/*    */         }
/*    */ 
/*    */         
/*    */         public String getHtmlInfo() {
/* 81 */           return "";
/*    */         }
/*    */ 
/*    */         
/*    */         public Properties getAsProperties() {
/* 86 */           return null;
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] invokedBy() {
/* 99 */     return new String[0];
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/analyzer/PluginAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */