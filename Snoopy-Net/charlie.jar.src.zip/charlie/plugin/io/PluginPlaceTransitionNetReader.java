/*    */ package charlie.plugin.io;
/*    */ 
/*    */ import charlie.pn.PetriNetReader;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PluginPlaceTransitionNetReader
/*    */   extends PetriNetReader
/*    */ {
/*    */   public abstract List<String> getLoadableExtensions();
/*    */   
/*    */   public abstract List<String> getDescription();
/*    */   
/*    */   public String getId() {
/* 47 */     return getClass().getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public void readNet() throws Exception {
/* 52 */     read();
/* 53 */     initNet();
/*    */   }
/*    */   
/*    */   protected abstract void read() throws IOException;
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/io/PluginPlaceTransitionNetReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */