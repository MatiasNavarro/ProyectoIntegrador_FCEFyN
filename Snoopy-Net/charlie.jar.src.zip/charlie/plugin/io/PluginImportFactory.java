/*     */ package charlie.plugin.io;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PluginImportFactory
/*     */ {
/*  18 */   private final List<String> readerList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  23 */   private final Map<String, PluginPlaceTransitionNetReader> readerMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  28 */   private static PluginImportFactory reference = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized PluginImportFactory getInstance() {
/*  42 */     if (reference == null) {
/*  43 */       reference = new PluginImportFactory();
/*     */     }
/*     */     
/*  46 */     return reference;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerReader(PluginPlaceTransitionNetReader _reader) {
/*  55 */     this.readerList.add(_reader.getId());
/*  56 */     this.readerMap.put(_reader.getId(), _reader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PluginPlaceTransitionNetReader getReader(String _id) {
/*  67 */     return this.readerMap.get(_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getReaderIdList() {
/*  76 */     return this.readerList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getLoadableExtensions() {
/*  85 */     List<String> extensionList = new ArrayList<>();
/*  86 */     for (String id : this.readerList) {
/*  87 */       extensionList.addAll(((PluginPlaceTransitionNetReader)this.readerMap.get(id)).getLoadableExtensions());
/*     */     }
/*     */     
/*  90 */     return extensionList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getDescriptions() {
/*  99 */     List<String> extensionList = new ArrayList<>();
/* 100 */     for (String id : this.readerList) {
/* 101 */       extensionList.addAll(((PluginPlaceTransitionNetReader)this.readerMap.get(id)).getDescription());
/*     */     }
/*     */     
/* 104 */     return extensionList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 113 */     return this.readerList.size();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/io/PluginImportFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */