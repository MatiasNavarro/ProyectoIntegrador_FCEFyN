/*     */ package charlie.plugin;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import charlie.plugin.analyzer.PluginAnalyzer;
/*     */ import charlie.plugin.analyzer.PluginRuleExtender;
/*     */ import charlie.plugin.director.PluginDirector;
/*     */ import charlie.plugin.director.PluginFilterPreferencePanel;
/*     */ import charlie.plugin.gui.PluginComputationalDialog;
/*     */ import charlie.plugin.io.PluginPlaceTransitionNetReader;
/*     */ import java.io.File;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JFrame;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Plugin
/*     */ {
/*  24 */   private static final Log LOG = LogFactory.getLog(Plugin.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final String name;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String version;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String zipFile;
/*     */ 
/*     */ 
/*     */   
/*  40 */   private final List<String> analyzerClassNameList = new ArrayList<>();
/*  41 */   private final List<String> dialogClassNameList = new ArrayList<>();
/*  42 */   private final List<String> ruleEnhancerClassNameList = new ArrayList<>();
/*  43 */   private final List<String> directorClassNameList = new ArrayList<>();
/*  44 */   private final List<String> filterPreferenceClassNameList = new ArrayList<>();
/*  45 */   private final List<String> readerClassNameList = new ArrayList<>();
/*     */   
/*  47 */   private PluginLibClassLoader pluginLibClassLoader = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Plugin(PluginClassLoaderManager _manager, String _zipFile, String _name, String _version, List<String> _analyzerClazzList, List<String> _dialogClazzList, List<String> _ruleExtenderClazzList, List<String> _directorClazzList, List<String> _filterPreferenceClassList, List<String> _readerClassList) {
/*  64 */     this.name = _name;
/*  65 */     this.version = _version;
/*  66 */     this.zipFile = _zipFile;
/*  67 */     this.analyzerClassNameList.addAll(_analyzerClazzList);
/*  68 */     this.dialogClassNameList.addAll(_dialogClazzList);
/*  69 */     this.ruleEnhancerClassNameList.addAll(_ruleExtenderClazzList);
/*  70 */     this.directorClassNameList.addAll(_directorClazzList);
/*  71 */     this.filterPreferenceClassNameList.addAll(_filterPreferenceClassList);
/*  72 */     this.readerClassNameList.addAll(_readerClassList);
/*     */     
/*  74 */     File archiveFile = new File(this.zipFile);
/*     */     try {
/*  76 */       this.pluginLibClassLoader = new PluginLibClassLoader(_manager, archiveFile.toURI().toURL());
/*  77 */     } catch (MalformedURLException e) {
/*  78 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getZipFile() {
/*  83 */     return this.zipFile;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  87 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getVersion() {
/*  91 */     return this.version;
/*     */   }
/*     */   
/*     */   public List<String> getAnalyzerClassNameList() {
/*  95 */     return this.analyzerClassNameList;
/*     */   }
/*     */   
/*     */   public List<String> getDialogClassNameList() {
/*  99 */     return this.dialogClassNameList;
/*     */   }
/*     */   
/*     */   public List<String> getRuleEnhancerClassNameList() {
/* 103 */     return this.ruleEnhancerClassNameList;
/*     */   }
/*     */   
/*     */   public List<String> getDirectorClassList() {
/* 107 */     return this.directorClassNameList;
/*     */   }
/*     */   
/*     */   public List<String> getFilterPreferenceClassList() {
/* 111 */     return this.filterPreferenceClassNameList;
/*     */   }
/*     */   
/*     */   public List<String> getPlaceTransitionNetReaderClassList() {
/* 115 */     return this.readerClassNameList;
/*     */   }
/*     */   
/*     */   public PluginAnalyzer getNewAnalyzer(String _analyzerClassName) {
/* 119 */     if (this.analyzerClassNameList.isEmpty()) {
/* 120 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 124 */       Class<? extends PluginAnalyzer> clazz = Class.forName(_analyzerClassName, true, this.pluginLibClassLoader).asSubclass(PluginAnalyzer.class);
/* 125 */       return clazz.newInstance();
/* 126 */     } catch (ClassNotFoundException e) {
/* 127 */       LOG.error(e.getMessage(), e);
/* 128 */     } catch (ClassCastException e) {
/* 129 */       LOG.error(e.getMessage(), e);
/* 130 */     } catch (InstantiationException e) {
/* 131 */       LOG.error(e.getMessage(), e);
/* 132 */     } catch (IllegalAccessException e) {
/* 133 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   public PluginComputationalDialog getNewDialog(IDirector _director, String _dialogClassName) {
/* 140 */     if (this.dialogClassNameList.isEmpty()) {
/* 141 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 145 */       Class<? extends PluginComputationalDialog> clazz = Class.forName(_dialogClassName, true, this.pluginLibClassLoader).asSubclass(PluginComputationalDialog.class);
/* 146 */       PluginComputationalDialog dialog = clazz.getConstructor(new Class[] { IDirector.class }).newInstance(new Object[] { _director });
/*     */       
/* 148 */       return dialog;
/* 149 */     } catch (ClassNotFoundException e) {
/* 150 */       LOG.error(e.getMessage(), e);
/* 151 */     } catch (ClassCastException e) {
/* 152 */       LOG.error(e.getMessage(), e);
/* 153 */     } catch (InstantiationException e) {
/* 154 */       LOG.error(e.getMessage(), e);
/* 155 */     } catch (IllegalAccessException e) {
/* 156 */       LOG.error(e.getMessage(), e);
/* 157 */     } catch (IllegalArgumentException e) {
/* 158 */       LOG.error(e.getMessage(), e);
/* 159 */     } catch (SecurityException e) {
/* 160 */       LOG.error(e.getMessage(), e);
/* 161 */     } catch (InvocationTargetException e) {
/* 162 */       LOG.error(e.getMessage(), e);
/* 163 */     } catch (NoSuchMethodException e) {
/* 164 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 167 */     return null;
/*     */   }
/*     */   
/*     */   public PluginRuleExtender getNewRuleEnhancer(String _ruleEnhancerClassName) {
/* 171 */     if (this.ruleEnhancerClassNameList.isEmpty())
/*     */     {
/* 173 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 177 */       Class<? extends PluginRuleExtender> clazz = Class.forName(_ruleEnhancerClassName, true, this.pluginLibClassLoader).asSubclass(PluginRuleExtender.class);
/* 178 */       return clazz.newInstance();
/* 179 */     } catch (ClassNotFoundException e) {
/* 180 */       LOG.error(e.getMessage(), e);
/* 181 */     } catch (ClassCastException e) {
/* 182 */       LOG.error(e.getMessage(), e);
/* 183 */     } catch (InstantiationException e) {
/* 184 */       LOG.error(e.getMessage(), e);
/* 185 */     } catch (IllegalAccessException e) {
/* 186 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 189 */     return null;
/*     */   }
/*     */   
/*     */   public PluginDirector getNewDirector(IDirector _parentDirector, JFrame _parent, String _directorClassName) {
/* 193 */     if (this.directorClassNameList.isEmpty()) {
/* 194 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 198 */       Class<? extends PluginDirector> clazz = Class.forName(_directorClassName, true, this.pluginLibClassLoader).asSubclass(PluginDirector.class);
/* 199 */       PluginDirector dialog = clazz.getConstructor(new Class[] { IDirector.class, JFrame.class }).newInstance(new Object[] { _parentDirector, _parent });
/* 200 */       return dialog;
/* 201 */     } catch (ClassNotFoundException e) {
/* 202 */       LOG.error(e.getMessage(), e);
/* 203 */     } catch (ClassCastException e) {
/* 204 */       LOG.error(e.getMessage(), e);
/* 205 */     } catch (InstantiationException e) {
/* 206 */       LOG.error(e.getMessage(), e);
/* 207 */     } catch (IllegalAccessException e) {
/* 208 */       LOG.error(e.getMessage(), e);
/* 209 */     } catch (IllegalArgumentException e) {
/* 210 */       LOG.error(e.getMessage(), e);
/* 211 */     } catch (SecurityException e) {
/* 212 */       LOG.error(e.getMessage(), e);
/* 213 */     } catch (InvocationTargetException e) {
/* 214 */       LOG.error(e.getMessage(), e);
/* 215 */     } catch (NoSuchMethodException e) {
/* 216 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 219 */     return null;
/*     */   }
/*     */   
/*     */   public PluginFilterPreferencePanel getNewFilterPreferencePanel(IDirector _parentDirector, String _preferenceClassName) {
/* 223 */     if (this.filterPreferenceClassNameList.isEmpty()) {
/* 224 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 228 */       Class<? extends PluginFilterPreferencePanel> clazz = Class.forName(_preferenceClassName, true, this.pluginLibClassLoader).asSubclass(PluginFilterPreferencePanel.class);
/* 229 */       PluginFilterPreferencePanel panel = clazz.getConstructor(new Class[] { IDirector.class }).newInstance(new Object[] { _parentDirector });
/* 230 */       return panel;
/* 231 */     } catch (ClassNotFoundException e) {
/* 232 */       LOG.error(e.getMessage(), e);
/* 233 */     } catch (ClassCastException e) {
/* 234 */       LOG.error(e.getMessage(), e);
/* 235 */     } catch (InstantiationException e) {
/* 236 */       LOG.error(e.getMessage(), e);
/* 237 */     } catch (IllegalAccessException e) {
/* 238 */       LOG.error(e.getMessage(), e);
/* 239 */     } catch (IllegalArgumentException e) {
/* 240 */       LOG.error(e.getMessage(), e);
/* 241 */     } catch (SecurityException e) {
/* 242 */       LOG.error(e.getMessage(), e);
/* 243 */     } catch (InvocationTargetException e) {
/* 244 */       LOG.error(e.getMessage(), e);
/* 245 */     } catch (NoSuchMethodException e) {
/* 246 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 249 */     return null;
/*     */   }
/*     */   
/*     */   public PluginPlaceTransitionNetReader getNewPlaceTransitionNetReader(String _readerClassName) {
/* 253 */     if (this.readerClassNameList.isEmpty())
/*     */     {
/* 255 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 259 */       Class<? extends PluginPlaceTransitionNetReader> clazz = Class.forName(_readerClassName, true, this.pluginLibClassLoader).asSubclass(PluginPlaceTransitionNetReader.class);
/* 260 */       return clazz.newInstance();
/* 261 */     } catch (ClassNotFoundException e) {
/* 262 */       LOG.error(e.getMessage(), e);
/* 263 */     } catch (ClassCastException e) {
/* 264 */       LOG.error(e.getMessage(), e);
/* 265 */     } catch (InstantiationException e) {
/* 266 */       LOG.error(e.getMessage(), e);
/* 267 */     } catch (IllegalAccessException e) {
/* 268 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 271 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/Plugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */