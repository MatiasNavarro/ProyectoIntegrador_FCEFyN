/*     */ package charlie.plugin;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PluginLoader
/*     */ {
/*  41 */   private static final Log LOG = LogFactory.getLog(PluginLoader.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PLUGIN_SUFFIX = ".zip";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PLUGIN_META_FILE_NAME = "charlie.meta";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PLUGIN_DEVEL_FILE_NAME = "plugin.devel.properties";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private static final File PLUGIN_PATH = getPluginPath();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private final List<String> pluginFileList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private final List<Plugin> pluginList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private final PluginClassLoaderManager manager = new PluginClassLoaderManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static File getPluginPath() {
/*     */     try {
/*  89 */       String path, pluginUrlPath = PluginLoader.class.getResource("PluginLoader.class").toString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  97 */       if (pluginUrlPath.contains("!")) {
/*     */ 
/*     */         
/* 100 */         path = pluginUrlPath.substring(4, pluginUrlPath.lastIndexOf('/', pluginUrlPath.indexOf('!')));
/*     */       }
/*     */       else {
/*     */         
/* 104 */         path = pluginUrlPath.replace("charlie/plugin/PluginLoader.class", "");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 109 */       File pluginDirectory = new File(new URI(path + "/plugin"));
/* 110 */       if (!pluginDirectory.exists()) {
/* 111 */         pluginDirectory = new File(new URI(path + "/../plugin"));
/*     */       }
/*     */       
/* 114 */       return pluginDirectory;
/* 115 */     } catch (URISyntaxException e) {
/* 116 */       LOG.error(e.getMessage(), e);
/*     */ 
/*     */ 
/*     */       
/* 120 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Plugin> getPluginList() {
/* 132 */     searchPlugins();
/*     */     
/* 134 */     return this.pluginList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void searchPlugins() {
/* 141 */     buildDevelopmentPlugins(PLUGIN_PATH);
/* 142 */     searchPlugins(PLUGIN_PATH);
/* 143 */     inspectFiles();
/*     */   }
/*     */   
/*     */   private void searchPlugins(File _directory) {
/* 147 */     if (_directory.isFile()) {
/*     */       
/* 149 */       if (_directory.getName().endsWith(".zip"))
/*     */       {
/* 151 */         this.pluginFileList.add(_directory.getAbsolutePath());
/*     */       }
/* 153 */     } else if (_directory.isDirectory()) {
/*     */       
/* 155 */       LOG.debug(String.format("Looking in directory %s for plugins.", new Object[] { _directory.getAbsolutePath() }));
/*     */ 
/*     */       
/* 158 */       for (File f : _directory.listFiles()) {
/* 159 */         searchPlugins(f);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void inspectFiles() {
/* 165 */     Iterator<String> iter = this.pluginFileList.iterator();
/* 166 */     while (iter.hasNext()) {
/* 167 */       String zipFileName = iter.next();
/*     */       
/*     */       try {
/* 170 */         boolean hasMeta = false;
/*     */         
/* 172 */         ZipFile zipFile = new ZipFile(zipFileName);
/* 173 */         Enumeration<? extends ZipEntry> entryEnumer = zipFile.entries();
/*     */         
/* 175 */         while (entryEnumer.hasMoreElements() && !hasMeta) {
/* 176 */           ZipEntry entry = entryEnumer.nextElement();
/* 177 */           if (entry.getName().equalsIgnoreCase("charlie.meta")) {
/*     */ 
/*     */             
/* 180 */             hasMeta = true;
/*     */             
/* 182 */             BufferedReader reader = new BufferedReader(new InputStreamReader(zipFile.getInputStream(entry)));
/* 183 */             List<String> analyzerClassNameList = new ArrayList<>();
/* 184 */             List<String> dialogClassNameList = new ArrayList<>();
/* 185 */             List<String> ruleEnhancerClassNameList = new ArrayList<>();
/* 186 */             List<String> directorClassNameList = new ArrayList<>();
/* 187 */             List<String> filterPrefClassNameList = new ArrayList<>();
/* 188 */             List<String> readerClassNameList = new ArrayList<>();
/*     */             
/* 190 */             String name = zipFileName;
/* 191 */             String version = "";
/*     */             
/* 193 */             String line = null;
/* 194 */             while ((line = reader.readLine()) != null) {
/*     */               
/* 196 */               if ("".equals(line.trim()) || line.startsWith("#")) {
/*     */                 continue;
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 202 */               String[] keyValue = line.split("=");
/* 203 */               if ("analyzer".equals(keyValue[0].trim())) {
/* 204 */                 analyzerClassNameList.add(keyValue[1].trim()); continue;
/* 205 */               }  if ("dialog".equals(keyValue[0].trim())) {
/* 206 */                 dialogClassNameList.add(keyValue[1].trim()); continue;
/* 207 */               }  if ("rule".equals(keyValue[0].trim())) {
/* 208 */                 ruleEnhancerClassNameList.add(keyValue[1].trim()); continue;
/* 209 */               }  if ("director".equals(keyValue[0].trim())) {
/* 210 */                 directorClassNameList.add(keyValue[1].trim()); continue;
/* 211 */               }  if ("prefs".equals(keyValue[0].trim())) {
/* 212 */                 filterPrefClassNameList.add(keyValue[1]); continue;
/* 213 */               }  if ("name".equals(keyValue[0].trim())) {
/* 214 */                 name = keyValue[1].trim(); continue;
/* 215 */               }  if ("version".equals(keyValue[0].trim())) {
/* 216 */                 version = keyValue[1].trim(); continue;
/* 217 */               }  if ("reader".equals(keyValue[0].trim())) {
/* 218 */                 readerClassNameList.add(keyValue[1]);
/*     */               }
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 224 */             Plugin p = new Plugin(this.manager, zipFileName, name, version, analyzerClassNameList, dialogClassNameList, ruleEnhancerClassNameList, directorClassNameList, filterPrefClassNameList, readerClassNameList);
/*     */ 
/*     */ 
/*     */             
/* 228 */             this.pluginList.add(p);
/*     */             
/* 230 */             LOG.debug(String.format("Found plugin %s.", new Object[] { zipFileName }));
/*     */           } 
/*     */         } 
/* 233 */         zipFile.close();
/* 234 */       } catch (IOException ioe) {
/* 235 */         LOG.error(ioe.getMessage(), ioe);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 240 */       iter.remove();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildDevelopmentPlugins(File _pluginPath) {
/* 250 */     File pluginPropertiesFile = new File(_pluginPath.getAbsolutePath() + File.separator + "plugin.devel.properties");
/*     */     
/* 252 */     if (pluginPropertiesFile.exists()) {
/*     */       try {
/* 254 */         BufferedReader reader = new BufferedReader(new FileReader(pluginPropertiesFile));
/* 255 */         String line = null;
/* 256 */         while ((line = reader.readLine()) != null) {
/*     */           
/* 258 */           if ("".equals(line.trim()) || line.startsWith("#")) {
/*     */             continue;
/*     */           }
/*     */           
/* 262 */           String zipFileName = _pluginPath.getAbsolutePath() + File.separator + line.replace('/', '_').replace('\\', '_') + ".zip";
/*     */           
/* 264 */           LOG.info(String.format("Creating plugin: %s", new Object[] { zipFileName }));
/*     */           
/* 266 */           ZipOutputStream output = new ZipOutputStream(new FileOutputStream(zipFileName));
/*     */ 
/*     */           
/* 269 */           zip(output, line, line);
/*     */ 
/*     */           
/* 272 */           output.finish();
/* 273 */           output.close();
/*     */         } 
/* 275 */         reader.close();
/* 276 */       } catch (FileNotFoundException e) {
/* 277 */         LOG.error(e.getMessage(), e);
/* 278 */       } catch (IOException e) {
/* 279 */         LOG.error(e.getMessage(), e);
/* 280 */       } catch (Exception e) {
/* 281 */         LOG.error(e.getMessage(), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void zip(ZipOutputStream _output, String _path, String _origPath) throws IOException {
/* 287 */     File pathFile = new File(_path);
/* 288 */     for (File toZip : pathFile.listFiles()) {
/*     */       
/* 290 */       String fileNameInZip = toZip.getAbsolutePath().replace(_origPath, "/");
/*     */       
/* 292 */       while (fileNameInZip.startsWith("/")) {
/* 293 */         fileNameInZip = fileNameInZip.substring(1);
/*     */       }
/*     */       
/* 296 */       if (toZip.isDirectory()) {
/*     */         
/* 298 */         ZipEntry entry = new ZipEntry(fileNameInZip + "/");
/* 299 */         _output.putNextEntry(entry);
/*     */         
/* 301 */         _output.closeEntry();
/*     */ 
/*     */         
/* 304 */         zip(_output, toZip.getAbsolutePath(), _origPath);
/*     */       } else {
/* 306 */         ZipEntry entry = new ZipEntry(fileNameInZip);
/* 307 */         _output.putNextEntry(entry);
/*     */         
/* 309 */         FileInputStream input = new FileInputStream(toZip);
/*     */         
/* 311 */         int bufferSize = 1024;
/* 312 */         byte[] data = new byte[bufferSize]; int count;
/* 313 */         while ((count = input.read(data, 0, bufferSize)) != -1) {
/* 314 */           _output.write(data, 0, count);
/*     */         }
/* 316 */         input.close();
/*     */         
/* 318 */         _output.closeEntry();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/plugin/PluginLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */