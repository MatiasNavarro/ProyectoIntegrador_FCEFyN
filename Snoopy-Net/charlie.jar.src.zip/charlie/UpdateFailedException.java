/*    */ package charlie;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UpdateFailedException
/*    */   extends Exception
/*    */ {
/*    */   public UpdateFailedException(String message) {
/* 11 */     super(message);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/charlie/UpdateFailedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */