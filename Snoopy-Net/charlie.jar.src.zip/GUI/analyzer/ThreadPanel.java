/*     */ package GUI.analyzer;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.MyButton;
/*     */ import GUI.util.ResourceLoader;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.MouseInfo;
/*     */ import java.awt.Point;
/*     */ import java.awt.PointerInfo;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.net.URL;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreadPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 2300566585506425010L;
/*  36 */   private static Color FINISHED = new Color(168, 255, 149);
/*  37 */   private static Color RUNNING = new Color(149, 208, 255);
/*  38 */   private static Color PAUSED = new Color(255, 166, 106);
/*  39 */   private static Color CANCELLED = new Color(255, 150, 207);
/*     */ 
/*     */ 
/*     */   
/*  43 */   private JLabel timeLabel = null;
/*  44 */   private JLabel analyzerLabel = null;
/*  45 */   private String analyzerName = null;
/*  46 */   private MyButton optionButton = null;
/*  47 */   private MyButton statsButton = null;
/*  48 */   private MyButton startPauseButton = null;
/*  49 */   private MyButton stopButton = null;
/*  50 */   private String options = null;
/*  51 */   public static double height = 60.0D;
/*  52 */   private Analyzer analyzer = null;
/*     */ 
/*     */   
/*     */   public ThreadPanel(Analyzer a) {
/*  56 */     this.analyzer = a;
/*  57 */     this.analyzerName = a.getName();
/*     */     
/*  59 */     if (a.getOptionSet() != null) {
/*  60 */       this.options = a.getOptionSet().getHtmlInfo();
/*     */     } else {
/*  62 */       this.options = "";
/*     */     } 
/*  64 */     initialize();
/*  65 */     this.analyzer.setPanel(this);
/*  66 */     setStatus(a.getStatus());
/*     */   }
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  71 */     this.timeLabel = new JLabel("00:00");
/*     */ 
/*     */     
/*  74 */     double[][] size = { { 5.0D, -1.0D, 5.0D, 20.0D, 20.0D, 20.0D, 20.0D, 5.0D }, { 2.0D, 20.0D, 26.0D, 2.0D } };
/*  75 */     TableLayout layout = new TableLayout(size);
/*  76 */     setBorder(BorderFactory.createLineBorder(Color.BLACK));
/*  77 */     setLayout((LayoutManager)layout);
/*  78 */     this.analyzerLabel = new JLabel(this.analyzerName);
/*     */     
/*  80 */     add(this.analyzerLabel, "1,1");
/*  81 */     add(this.timeLabel, "1,2");
/*  82 */     this.startPauseButton = new MyButton(ResourceLoader.getURL("resources/tp/play.jpg"), "play/pause")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e) {
/*  85 */           System.out.println("play/pause pressed!");
/*  86 */           ThreadPanel.this.setStatusPaused();
/*     */         }
/*     */       };
/*     */     
/*  90 */     this.statsButton = new MyButton(ResourceLoader.getURL("resources/tp/statistic.jpg"), "statistics")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e)
/*     */         {
/*  94 */           ThreadPanel.this.showStatus();
/*  95 */           JComponent b = (JComponent)e.getSource();
/*  96 */           JPopupMenu m = b.getComponentPopupMenu();
/*  97 */           PointerInfo info = MouseInfo.getPointerInfo();
/*  98 */           Point p = info.getLocation();
/*  99 */           p.setLocation(p.getX() - 10.0D, p.getY() - 10.0D);
/* 100 */           if (m != null) {
/* 101 */             m.setLocation(p);
/* 102 */             m.pack();
/* 103 */             m.setVisible(true);
/* 104 */             m.grabFocus();
/*     */           } else {
/* 106 */             DebugCounter.inc("No popupmenu on Jcomponent");
/*     */           } 
/*     */         }
/*     */       };
/* 110 */     this.stopButton = new MyButton(ResourceLoader.getURL("resources/tp/stop.jpg"), "stop")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e)
/*     */         {
/* 114 */           System.out.println("stop pressed!");
/* 115 */           ThreadPanel.this.setStatusCancelled();
/*     */         }
/*     */       };
/* 118 */     this.optionButton = new MyButton(ResourceLoader.getURL("resources/tp/options.jpg"), "options")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e)
/*     */         {
/* 122 */           ThreadPanel.this.showOptions();
/*     */           
/* 124 */           JComponent b = (JComponent)e.getSource();
/* 125 */           JPopupMenu m = b.getComponentPopupMenu();
/* 126 */           PointerInfo info = MouseInfo.getPointerInfo();
/* 127 */           Point p = info.getLocation();
/* 128 */           p.setLocation(p.getX() - 10.0D, p.getY() - 10.0D);
/* 129 */           if (m != null) {
/* 130 */             m.setLocation(p);
/* 131 */             m.pack();
/* 132 */             m.setVisible(true);
/* 133 */             m.grabFocus();
/*     */           } else {
/* 135 */             DebugCounter.inc("No popupmenu on Jcomponent");
/*     */           } 
/*     */         }
/*     */       };
/* 139 */     this.startPauseButton.setEnabled(true);
/* 140 */     add((Component)this.startPauseButton, "3,1");
/* 141 */     add((Component)this.stopButton, "4,1");
/* 142 */     add((Component)this.statsButton, "5,1");
/* 143 */     add((Component)this.optionButton, "6,1");
/* 144 */     Dimension d = layout.preferredLayoutSize(this);
/* 145 */     setPreferredSize(d);
/* 146 */     setSize(d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStatus(int status) {
/* 153 */     switch (status) {
/*     */       case 1:
/* 155 */         setStatusPaused(); break;
/*     */       case 4:
/* 157 */         setStatusCancelled();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStatusPaused() {
/* 167 */     DebugCounter.inc("Threadpanel setStatusPaused() - called");
/* 168 */     setOpaque(true);
/* 169 */     if (this.analyzer != null) {
/* 170 */       int status = this.analyzer.getStatus();
/* 171 */       switch (status) {
/*     */         case 2:
/* 173 */           setBackground(PAUSED);
/* 174 */           this.analyzer.pause();
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 186 */           this.analyzer.resume();
/* 187 */           setBackground(RUNNING);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStatusRunning() {
/* 197 */     setOpaque(true);
/* 198 */     setBackground(RUNNING);
/* 199 */     setToolTipText("analyzer is running");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStatusCancelled() {
/* 204 */     setOpaque(true);
/* 205 */     if (this.analyzer != null) {
/* 206 */       setBackground(CANCELLED);
/* 207 */       this.analyzer.cancel();
/* 208 */       this.startPauseButton.setEnabled(false);
/* 209 */       this.stopButton.setEnabled(false);
/* 210 */       setToolTipText("analyzer was cancelled");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPopupMenu(JComponent c, String title, String text) {
/* 216 */     JPopupMenu popup = new JPopupMenu();
/* 217 */     popup.add(new JLabel(title));
/* 218 */     popup.addSeparator();
/* 219 */     popup.add(new JLabel(text));
/* 220 */     popup.addSeparator();
/* 221 */     JMenuItem close = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 227 */             JMenuItem i = (JMenuItem)e.getSource();
/* 228 */             if (i.getParent() instanceof JPopupMenu) {
/* 229 */               i.getParent().setVisible(false);
/*     */             } else {
/* 231 */               DebugCounter.inc("parent of close item = " + i.getParent().getClass().getName());
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 236 */     popup.add(close);
/* 237 */     c.setComponentPopupMenu(popup);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void showOptions() {
/* 243 */     addPopupMenu((JComponent)this.optionButton, "options", this.options);
/*     */   }
/*     */   public void showStatus() {
/* 246 */     addPopupMenu((JComponent)this.statsButton, "statistics", this.analyzer.getHtmlInfoString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStatusFinished() {
/* 253 */     this.startPauseButton.setEnabled(false);
/* 254 */     this.stopButton.setEnabled(false);
/* 255 */     setOpaque(true);
/* 256 */     DebugCounter.inc("setting color to finished");
/* 257 */     setBackground(FINISHED);
/* 258 */     setToolTipText("analyzer has finished");
/*     */   }
/*     */ 
/*     */   
/*     */   public JLabel getTimeLabel() {
/* 263 */     if (this.timeLabel == null) {
/* 264 */       initialize();
/*     */     }
/* 266 */     return this.timeLabel;
/*     */   }
/*     */   
/*     */   public void setTimeText(String text) {
/* 270 */     if (this.timeLabel != null)
/* 271 */       this.timeLabel.setText(text); 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/analyzer/ThreadPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */