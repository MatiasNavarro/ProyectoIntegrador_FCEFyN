/*    */ package GUI.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import javax.swing.JCheckBoxMenuItem;
/*    */ 
/*    */ public class ExportJCheckBoxMenuItem
/*    */   extends JCheckBoxMenuItem
/*    */ {
/*  9 */   String suggestedFileName = null;
/* 10 */   String tooltipText = null;
/* 11 */   String path = null;
/* 12 */   String text = null;
/* 13 */   File file = null;
/* 14 */   ExportFileAction action = null;
/*    */   
/*    */   public ExportJCheckBoxMenuItem(String text, String suggestedFileName, String tooltipText, String path) {
/* 17 */     initialize(text, suggestedFileName, tooltipText, path);
/*    */   }
/*    */   
/*    */   public ExportJCheckBoxMenuItem(String text, File file, String tooltipText) {
/* 21 */     if (file != null)
/* 22 */       initialize(text, file.getName(), tooltipText, file.getPath()); 
/*    */   }
/*    */   
/*    */   public void initialize() {
/* 26 */     this.action = new ExportFileAction(this.text, this.suggestedFileName, this.tooltipText, this.path);
/* 27 */     setAction(this.action);
/*    */   }
/*    */   
/*    */   public void initialize(String text, String suggestedFileName, String tooltipText, String path) {
/* 31 */     this.suggestedFileName = suggestedFileName;
/* 32 */     this.tooltipText = tooltipText;
/* 33 */     this.path = path;
/* 34 */     this.text = text;
/* 35 */     initialize();
/*    */   }
/*    */   
/*    */   public void setFile(String suggestedFileName, String path) {
/* 39 */     this.suggestedFileName = suggestedFileName;
/* 40 */     if (path == null || path.equals("")) { this.path = System.getProperty("user.dir"); }
/* 41 */     else { this.path = path; }
/*    */     
/* 43 */     this.file = new File(path, suggestedFileName);
/* 44 */     this.action.setFile(this.file);
/*    */   }
/*    */   
/*    */   public File getFile() {
/* 48 */     this.file = this.action.getFile();
/* 49 */     return this.file;
/*    */   }
/*    */   
/*    */   public String getFileName() {
/* 53 */     this.file = this.action.getFile();
/* 54 */     if (this.file != null) {
/* 55 */       return this.file.getName();
/*    */     }
/* 57 */     return null;
/*    */   }
/*    */   
/*    */   public String getPath() {
/* 61 */     this.file = this.action.getFile();
/* 62 */     if (this.file != null) {
/* 63 */       return this.file.getPath();
/*    */     }
/* 65 */     return null;
/*    */   }
/*    */   public String getAbsoluteFileName() {
/* 68 */     this.file = this.action.getFile();
/* 69 */     if (this.file != null) {
/* 70 */       return this.file.getAbsolutePath();
/*    */     }
/* 72 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/ExportJCheckBoxMenuItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */