/*    */ package GUI.util;
/*    */ import GUI.debug.DebugCounter;
/*    */ import java.io.File;
/*    */ import java.net.URL;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class ResourceLoader {
/*  8 */   private static final Log LOG = LogFactory.getLog(ResourceLoader.class);
/*    */   
/*    */   public static URL getURL(String urlString) {
/* 11 */     LOG.debug("Loading " + urlString);
/*    */ 
/*    */     
/* 14 */     URL url = ClassLoader.getSystemResource(urlString);
/* 15 */     if (url != null) {
/* 16 */       LOG.debug(String.format("Found resource and loading '%s'.", new Object[] { url }));
/* 17 */       return url;
/*    */     } 
/*    */     
/* 20 */     File file = new File(urlString);
/* 21 */     if (file != null && file.exists()) {
/*    */       try {
/* 23 */         url = file.toURI().toURL();
/* 24 */       } catch (Exception e) {
/* 25 */         LOG.error(e.getMessage(), e);
/*    */       } 
/* 27 */       if (url != null) {
/* 28 */         LOG.debug(String.format("Found resource and loading '%s'.", new Object[] { url }));
/* 29 */         return url;
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 34 */     url = ClassLoader.getSystemResource("charlie/Charlie.class");
/* 35 */     DebugCounter.inc("url = " + url.toString());
/*    */     
/* 37 */     if (url != null) {
/* 38 */       if (url.toString().lastIndexOf(".jar!") >= 0) {
/*    */         
/* 40 */         String urlS = url.toString().replace("charlie.jar!/charlie/Charlie.class", "");
/* 41 */         urlS = urlS.replace("jar:", "");
/*    */         
/* 43 */         urlS = urlS + urlString;
/* 44 */         DebugCounter.inc("urlS= " + urlS);
/*    */         try {
/* 46 */           url = new URL(urlS);
/* 47 */         } catch (Exception e) {
/* 48 */           LOG.error(e.getMessage(), e);
/*    */         } 
/*    */       } else {
/* 51 */         String urlS = url.toString().replace("charlie.jar!/charlie/Charlie.class", "");
/* 52 */         urlS = urlS.replace("jar:", "");
/*    */         
/* 54 */         urlS = urlS + urlString;
/* 55 */         DebugCounter.inc("urlS= " + urlS);
/*    */         try {
/* 57 */           url = new URL(urlS);
/* 58 */         } catch (Exception e) {
/* 59 */           LOG.error(e.getMessage(), e);
/*    */         } 
/*    */       } 
/*    */     }
/*    */     
/* 64 */     LOG.debug(String.format("Found resource and loading '%s'.", new Object[] { url }));
/* 65 */     return url;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/ResourceLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */