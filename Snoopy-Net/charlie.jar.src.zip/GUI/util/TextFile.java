/*    */ package GUI.util;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.File;
/*    */ import java.io.FileReader;
/*    */ import java.io.FileWriter;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ public class TextFile
/*    */ {
/* 14 */   private static final Log LOG = LogFactory.getLog(TextFile.class);
/*    */   
/*    */   public static boolean writeToFile(File f, String buf, boolean overwrite) {
/* 17 */     LOG.debug("writing " + f.getAbsolutePath());
/*    */     
/*    */     try {
/* 20 */       if (f.exists() && overwrite) {
/* 21 */         f.delete();
/* 22 */         f.createNewFile();
/* 23 */       } else if (!f.exists()) {
/* 24 */         f.createNewFile();
/*    */       } 
/* 26 */       BufferedWriter bw = new BufferedWriter(new FileWriter(f, true));
/* 27 */       bw.write(buf, 0, buf.length());
/* 28 */       bw.flush();
/* 29 */       bw.close();
/* 30 */       return true;
/* 31 */     } catch (Exception e) {
/* 32 */       LOG.error(e.getMessage(), e);
/*    */       
/* 34 */       return false;
/*    */     } 
/*    */   }
/*    */   public static boolean writeToFile(File f, StringBuffer buf, boolean overwrite) {
/* 38 */     return writeToFile(f, buf.toString(), overwrite);
/*    */   }
/*    */   
/*    */   public static String readTextFile(File f) {
/* 42 */     if (f == null || !f.exists()) {
/* 43 */       return null;
/*    */     }
/* 45 */     StringBuilder buf = new StringBuilder();
/*    */     try {
/* 47 */       BufferedReader br = new BufferedReader(new FileReader(f));
/*    */       
/* 49 */       String s = br.readLine();
/* 50 */       while (s != null) {
/*    */         
/* 52 */         buf.append(s);
/* 53 */         buf.append("\n");
/* 54 */         s = br.readLine();
/*    */       } 
/* 56 */       br.close();
/* 57 */     } catch (Exception e) {
/* 58 */       LOG.error(String.format("could not read file : %s", new Object[] { f.getName() }));
/* 59 */       LOG.error(e.getMessage(), e);
/* 60 */       return "";
/*    */     } 
/* 62 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/TextFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */