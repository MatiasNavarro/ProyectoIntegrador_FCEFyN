/*     */ package GUI.util;
/*     */ 
/*     */ import GUI.dialog.BaseDialog;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.Timer;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileLoadingProgressListener
/*     */   implements IProgressListener<File>
/*     */ {
/*  25 */   private ProgressMonitor monitor = null;
/*     */   
/*  27 */   private JFrame parent = null;
/*     */   
/*     */   public FileLoadingProgressListener(JFrame _parent) {
/*  30 */     this.parent = _parent;
/*  31 */     this.monitor = new ProgressMonitor(this.parent);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInformation(File _file) {
/*  36 */     this.monitor.setLoadingFile(_file);
/*  37 */     SwingUtilities.invokeLater(new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  41 */             FileLoadingProgressListener.this.monitor.init();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void processStarted() {
/*  48 */     this.monitor.setMillisToPopup(200);
/*  49 */     this.monitor.setProgress(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void processFinished() {
/*  54 */     this.monitor.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public void processProgess(int _progress) {
/*  59 */     this.monitor.setProgress(_progress);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class ProgressMonitor
/*     */     extends JDialog
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*  69 */     private String message = null;
/*     */     
/*  71 */     private JProgressBar progressBar = new JProgressBar();
/*     */     
/*  73 */     private Boolean stillAlive = Boolean.valueOf(true);
/*     */     
/*     */     public ProgressMonitor(JFrame _parent) {
/*  76 */       super(_parent, false);
/*  77 */       setAlwaysOnTop(true);
/*  78 */       setUndecorated(true);
/*  79 */       getRootPane().setWindowDecorationStyle(0);
/*     */     }
/*     */     
/*     */     public void setLoadingFile(File _file) {
/*  83 */       this.message = "loading file: " + _file.getName();
/*     */     }
/*     */     
/*     */     public void init() {
/*  87 */       setAlwaysOnTop(true);
/*  88 */       setDefaultCloseOperation(0);
/*     */       
/*  90 */       this.progressBar.setMinimum(0);
/*  91 */       this.progressBar.setMaximum(100);
/*  92 */       this.progressBar.setIndeterminate(true);
/*     */       
/*  94 */       JPanel panel = new JPanel(new BorderLayout());
/*  95 */       panel.setBackground(BaseDialog.minColor);
/*  96 */       panel.setBorder(BorderFactory.createCompoundBorder(
/*  97 */             BorderFactory.createBevelBorder(0), 
/*  98 */             BorderFactory.createBevelBorder(1)));
/*     */ 
/*     */       
/* 101 */       JLabel messageLabel = new JLabel(this.message);
/* 102 */       messageLabel.setBorder(new EmptyBorder(2, 6, 2, 6));
/* 103 */       panel.add(messageLabel, "North");
/* 104 */       panel.add(this.progressBar, "Center");
/*     */       
/* 106 */       getContentPane().add(panel);
/*     */       
/* 108 */       pack();
/*     */     }
/*     */     
/*     */     public void setMillisToPopup(int _millis) {
/* 112 */       Timer timer = new Timer(_millis, new ActionListener()
/*     */           {
/*     */             public void actionPerformed(ActionEvent _ae) {
/* 115 */               synchronized (FileLoadingProgressListener.ProgressMonitor.this.stillAlive) {
/* 116 */                 if (FileLoadingProgressListener.ProgressMonitor.this.stillAlive.booleanValue()) {
/* 117 */                   FileLoadingProgressListener.ProgressMonitor.this.setLocationRelativeTo(FileLoadingProgressListener.this.parent);
/* 118 */                   FileLoadingProgressListener.ProgressMonitor.this.setVisible(true);
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           });
/* 123 */       timer.start();
/*     */     }
/*     */     
/*     */     public void setProgress(int _progress) {
/* 127 */       this.progressBar.setIndeterminate(false);
/* 128 */       this.progressBar.setValue(_progress);
/*     */     }
/*     */     
/*     */     public void close() {
/* 132 */       synchronized (this.stillAlive) {
/* 133 */         this.stillAlive = Boolean.valueOf(false);
/* 134 */         setVisible(false);
/* 135 */         dispose();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/FileLoadingProgressListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */