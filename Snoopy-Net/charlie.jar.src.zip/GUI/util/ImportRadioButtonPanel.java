/*    */ package GUI.util;
/*    */ 
/*    */ import GUI.io.FileSaver;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.File;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.filechooser.FileNameExtensionFilter;
/*    */ 
/*    */ public class ImportRadioButtonPanel
/*    */   extends ExportButtonPanel
/*    */ {
/*    */   public ImportRadioButtonPanel(String buttonText, String extension, int width) {
/* 13 */     this.extension = extension;
/* 14 */     this.buttonText = buttonText;
/* 15 */     this.width = width;
/* 16 */     initialize();
/*    */   }
/*    */   
/*    */   public ImportRadioButtonPanel(String buttonText, String extension, String suggestedFileName, int width) {
/* 20 */     this.extension = extension;
/* 21 */     this.buttonText = buttonText;
/* 22 */     this.suggestedFileName = suggestedFileName;
/* 23 */     this.width = width;
/* 24 */     initialize();
/*    */   }
/*    */ 
/*    */   
/*    */   private void initialize() {
/* 29 */     AbstractAction a = new AbstractAction()
/*    */       {
/*    */         public void actionPerformed(ActionEvent e) {
/* 32 */           FileSaver fs = new FileSaver();
/* 33 */           if (ImportRadioButtonPanel.this.file == null && !ImportRadioButtonPanel.this.suggestedFileName.equals("")) {
/* 34 */             ImportRadioButtonPanel.this.file = new File(FileSaver.lastSaveDir + System.getProperty("file.separator") + ImportRadioButtonPanel.this.suggestedFileName);
/*    */           }
/*    */ 
/*    */           
/* 38 */           ImportRadioButtonPanel.this.file = fs.showOpenDialog(ImportRadioButtonPanel.this.file, new FileNameExtensionFilter(ImportRadioButtonPanel.this.extension, new String[0]));
/* 39 */           if (ImportRadioButtonPanel.this.file != null) {
/* 40 */             if (!ImportRadioButtonPanel.this.tooltipText.equals("")) {
/* 41 */               ImportRadioButtonPanel.this.button.setToolTipText("<html><p>" + ImportRadioButtonPanel.this.tooltipText + "</p><p>Path: " + ImportRadioButtonPanel.this.file.getParent() + "<br>File: " + ImportRadioButtonPanel.this.file.getName() + " </p></html");
/*    */             } else {
/* 43 */               ImportRadioButtonPanel.this.button.setToolTipText("<html><p>Path: " + ImportRadioButtonPanel.this.file.getParent() + "<br>File: " + ImportRadioButtonPanel.this.file.getName() + " </p></html");
/*    */             } 
/* 45 */             ImportRadioButtonPanel.this.checkbox.setSelected(true);
/*    */           } else {
/* 47 */             ImportRadioButtonPanel.this.checkbox.setSelected(false);
/*    */           } 
/*    */         }
/*    */       };
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/ImportRadioButtonPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */