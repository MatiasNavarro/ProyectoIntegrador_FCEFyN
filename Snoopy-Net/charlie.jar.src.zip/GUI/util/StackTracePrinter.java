/*    */ package GUI.util;
/*    */ 
/*    */ 
/*    */ public class StackTracePrinter
/*    */ {
/*    */   public static String getStackTrace(Throwable e) {
/*  7 */     StringBuilder sb = new StringBuilder();
/*  8 */     StackTraceElement[] stack = e.getStackTrace();
/*  9 */     sb.append(e.getMessage() + "\n");
/*    */     
/* 11 */     for (StackTraceElement st : stack) {
/*    */ 
/*    */       
/* 14 */       sb.append(String.format("\tat %s.%s(%s:%d)\n", new Object[] { st.getClassName(), st.getMethodName(), st.getFileName(), Integer.valueOf(st.getLineNumber()) }));
/*    */     } 
/* 16 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/StackTracePrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */