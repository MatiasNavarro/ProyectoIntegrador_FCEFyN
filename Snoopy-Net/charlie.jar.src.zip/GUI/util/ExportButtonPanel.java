/*     */ package GUI.util;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.io.FileSaver;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JPanel;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportButtonPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  25 */   protected AbstractButton checkbox = null;
/*  26 */   protected JButton button = null;
/*  27 */   protected String oldDir = null;
/*  28 */   protected String myDir = null;
/*  29 */   protected String buttonText = null;
/*  30 */   protected String extension = null;
/*  31 */   protected TableLayout layout = null;
/*  32 */   protected File file = null;
/*  33 */   protected String tooltipText = "";
/*  34 */   protected String suggestedFileName = "";
/*  35 */   protected int width = 100;
/*     */ 
/*     */   
/*     */   public ExportButtonPanel() {}
/*     */   
/*     */   public ExportButtonPanel(String buttonText, String extension, int width) {
/*  41 */     this.extension = extension;
/*  42 */     this.buttonText = buttonText;
/*  43 */     this.width = width;
/*  44 */     initialize();
/*     */   }
/*     */ 
/*     */   
/*     */   public ExportButtonPanel(String buttonText, String extension, String suggestedFileName, int width) {
/*  49 */     this.extension = extension;
/*  50 */     this.buttonText = buttonText;
/*  51 */     this.suggestedFileName = suggestedFileName;
/*  52 */     this.width = width;
/*  53 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  59 */     this.checkbox = new JCheckBox();
/*  60 */     this.checkbox.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/*  63 */             if (((JCheckBox)e.getSource()).isSelected()) {
/*  64 */               FileSaver fs = new FileSaver();
/*  65 */               if (ExportButtonPanel.this.file == null && !ExportButtonPanel.this.suggestedFileName.equals("")) {
/*  66 */                 ExportButtonPanel.this.file = new File(FileSaver.lastSaveDir + System.getProperty("file.separator") + ExportButtonPanel.this.suggestedFileName);
/*     */               }
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/*  72 */     this.button = new JButton(new AbstractAction()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/*  75 */             FileSaver fs = new FileSaver();
/*  76 */             if (ExportButtonPanel.this.file == null && !ExportButtonPanel.this.suggestedFileName.equals("")) {
/*  77 */               ExportButtonPanel.this.file = new File(FileSaver.lastSaveDir + System.getProperty("file.separator") + ExportButtonPanel.this.suggestedFileName);
/*     */             }
/*     */ 
/*     */             
/*  81 */             ExportButtonPanel.this.file = fs.saveNewFile(ExportButtonPanel.this.file, "Do you want to overwrite this file?");
/*  82 */             DebugCounter.inc("nach fs.showSaveDialog...");
/*  83 */             if (ExportButtonPanel.this.file != null) {
/*  84 */               if (!ExportButtonPanel.this.tooltipText.equals("")) {
/*  85 */                 ExportButtonPanel.this.button.setToolTipText("<html><p>" + ExportButtonPanel.this.tooltipText + "</p><p>Path: " + ExportButtonPanel.this.file.getParent() + "<br>File: " + ExportButtonPanel.this.file.getName() + " </p></html");
/*     */               } else {
/*  87 */                 ExportButtonPanel.this.button.setToolTipText("<html><p>Path: " + ExportButtonPanel.this.file.getParent() + "<br>File: " + ExportButtonPanel.this.file.getName() + " </p></html");
/*     */               } 
/*  89 */               ExportButtonPanel.this.checkbox.setSelected(true);
/*     */             } else {
/*  91 */               ExportButtonPanel.this.checkbox.setSelected(false);
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/*  96 */     double[][] size = { { 20.0D, 2.0D, this.width - 22.0D }, { 25.0D } };
/*     */     
/*  98 */     this.layout = new TableLayout(size);
/*  99 */     setLayout((LayoutManager)this.layout);
/* 100 */     add(this.checkbox, "0,0");
/* 101 */     this.button.setText(this.buttonText);
/* 102 */     add(this.button, "2,0");
/* 103 */     Dimension preferred = this.layout.preferredLayoutSize(this);
/* 104 */     setSize(preferred);
/* 105 */     setPreferredSize(preferred);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelected() {
/* 112 */     if (this.checkbox != null) {
/* 113 */       return this.checkbox.isSelected();
/*     */     }
/* 115 */     return false;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean b) {
/* 119 */     if (this.checkbox != null)
/* 120 */       this.checkbox.setEnabled(b); 
/* 121 */     if (this.button != null)
/* 122 */       this.button.setEnabled(b); 
/*     */   }
/*     */   
/*     */   public void setToolTipText(String text) {
/* 126 */     this.tooltipText = text;
/* 127 */     if (this.button != null)
/* 128 */       this.button.setToolTipText(text); 
/* 129 */     if (this.checkbox != null)
/* 130 */       this.checkbox.setToolTipText("enable/disable " + text); 
/*     */   }
/*     */   
/*     */   public File getFile() {
/* 134 */     return this.file;
/*     */   }
/*     */   
/*     */   public String getFileName() {
/* 138 */     if (this.file != null) {
/* 139 */       return this.file.getName();
/*     */     }
/* 141 */     return null;
/*     */   }
/*     */   
/*     */   public String getAbsolutePath() {
/* 145 */     if (this.file != null) {
/* 146 */       return this.file.getAbsolutePath();
/*     */     }
/* 148 */     return null;
/*     */   }
/*     */   
/*     */   public void setSuggestedFileName(String name) {
/* 152 */     if (name != null) {
/* 153 */       this.suggestedFileName = name;
/* 154 */       this.file = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addToButtonGroup(ButtonGroup bg) {
/* 159 */     if (this.checkbox != null)
/* 160 */       bg.add(this.checkbox); 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/ExportButtonPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */