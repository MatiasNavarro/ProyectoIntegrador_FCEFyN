/*    */ package GUI.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import org.w3c.dom.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLParser
/*    */ {
/*    */   public static Document parseFile(File xmlFile) {
/* 13 */     Document xmlDocument = null;
/* 14 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 15 */     DocumentBuilder builder = null;
/*    */     try {
/* 17 */       builder = factory.newDocumentBuilder();
/* 18 */     } catch (Exception e) {
/* 19 */       System.out.println(e);
/*    */     } 
/* 21 */     if (xmlFile.exists())
/*    */       try {
/* 23 */         xmlDocument = builder.parse(xmlFile);
/* 24 */         return xmlDocument;
/* 25 */       } catch (Exception e) {
/* 26 */         System.out.println(e);
/* 27 */         return null;
/*    */       }  
/* 29 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/XMLParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */