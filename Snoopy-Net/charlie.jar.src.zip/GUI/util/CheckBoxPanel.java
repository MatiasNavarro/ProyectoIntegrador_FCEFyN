/*    */ package GUI.util;
/*    */ 
/*    */ import charlie.ds.Option;
/*    */ import charlie.ds.OptionListener;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JCheckBox;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ class CheckBoxPanel extends JPanel implements OptionListener {
/*    */   private JCheckBox cB;
/*    */   
/*    */   private void init(String title, boolean b) {
/* 14 */     setLayout(new BorderLayout());
/*    */     
/* 16 */     this.cB = new JCheckBox(title, b);
/* 17 */     add(this.cB, "West");
/*    */   }
/*    */   private Option o;
/*    */   
/*    */   public CheckBoxPanel(String title, boolean b) {
/* 22 */     init(title, b);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CheckBoxPanel(String title, boolean b, ActionListener al) {
/* 31 */     init(title, b);
/* 32 */     this.cB.addActionListener(al);
/*    */   }
/*    */ 
/*    */   
/*    */   public CheckBoxPanel(String title, Option o, ActionListener al) {
/* 37 */     this.o = o;
/* 38 */     init(title, ((Boolean)o.getValue()).booleanValue());
/*    */     
/* 40 */     this.cB.addActionListener(al);
/*    */   }
/*    */   
/*    */   public void setEnabled(boolean enable) {
/* 44 */     this.cB.setEnabled(enable);
/*    */   }
/*    */   
/*    */   public boolean isSelected() {
/* 48 */     return this.cB.isSelected();
/*    */   }
/*    */   
/*    */   public void setSelected(boolean b) {
/* 52 */     this.cB.setSelected(b);
/*    */   }
/*    */   
/*    */   public JCheckBox getCheckBox() {
/* 56 */     return this.cB;
/*    */   }
/*    */   
/*    */   public void reactOnChange(Option o) {
/* 60 */     this.cB.setSelected(((Boolean)o.getValue()).booleanValue());
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/CheckBoxPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */