/*    */ package GUI.util;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ import javax.swing.JComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiLineToolTip
/*    */ {
/*    */   public static String generateText(String s) {
/* 11 */     StringBuffer buffer = new StringBuffer();
/* 12 */     String E_O_L = System.getProperty("line.separator");
/* 13 */     StringTokenizer st = new StringTokenizer(s, E_O_L);
/*    */     
/* 15 */     buffer.append("<html><p><b>");
/* 16 */     int tokenCount = st.countTokens();
/* 17 */     for (int i = 0; i < tokenCount; i++) {
/* 18 */       String ss = st.nextToken();
/* 19 */       buffer.append(ss);
/* 20 */       if (i == 0) buffer.append("</b>"); 
/* 21 */       buffer.append("</p><p>");
/*    */     } 
/* 23 */     buffer.append("</p></html>");
/* 24 */     return buffer.toString();
/*    */   }
/*    */   
/*    */   public static void setMultiLineToolTip(JComponent component, String text) {
/* 28 */     component.setToolTipText(generateText(text));
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/MultiLineToolTip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */