/*    */ package GUI.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringHashMap<V>
/*    */   extends HashMap<String, V>
/*    */ {
/*    */   private static final long serialVersionUID = -6719515980255963711L;
/* 14 */   public ArrayList<String> strings = new ArrayList<>(16);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StringHashMap(int initialCapacity) {
/* 25 */     super(initialCapacity);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringHashMap(int initialCapacity, float loadFactor) {
/* 31 */     super(initialCapacity, loadFactor);
/*    */   }
/*    */   
/*    */   public StringHashMap(Map<? extends String, ? extends V> m) {
/* 35 */     super(m);
/*    */   }
/*    */ 
/*    */   
/*    */   public V put(String s, V value) {
/* 40 */     if (!containsKey(s)) {
/* 41 */       this.strings.add(s);
/* 42 */       return super.put(s, value);
/*    */     } 
/*    */     
/* 45 */     for (String lString : this.strings) {
/* 46 */       if (s.equals(lString)) {
/* 47 */         return super.put(lString, value);
/*    */       }
/*    */     } 
/*    */     
/* 51 */     return null;
/*    */   }
/*    */   
/*    */   public V get(String s) {
/* 55 */     int i = 0;
/* 56 */     while (i < this.strings.size()) {
/* 57 */       String tString = this.strings.get(i);
/* 58 */       if (tString.equals(s)) {
/* 59 */         return get(tString);
/*    */       }
/* 61 */       i++;
/*    */     } 
/*    */     
/* 64 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void clear() {
/* 69 */     this.strings.clear();
/* 70 */     super.clear();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean containsKey(Object key) {
/* 75 */     if (key instanceof String) {
/* 76 */       return containsKey((String)key);
/*    */     }
/* 78 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean containsKey(String key) {
/* 83 */     for (int i = 0; i < this.strings.size(); i++) {
/* 84 */       String s = this.strings.get(i);
/* 85 */       if (s.equals(key)) {
/* 86 */         return true;
/*    */       }
/*    */     } 
/* 89 */     return false;
/*    */   }
/*    */   
/*    */   public StringHashMap() {}
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/StringHashMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */