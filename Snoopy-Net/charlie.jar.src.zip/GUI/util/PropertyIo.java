/*    */ package GUI.util;
/*    */ 
/*    */ import GUI.debug.DebugCounter;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class PropertyIo
/*    */ {
/* 15 */   private static final Log LOG = LogFactory.getLog(PropertyIo.class);
/*    */   
/*    */   public static Properties loadProperties(File propFile) throws IOException {
/* 18 */     if (propFile.isDirectory()) {
/* 19 */       return null;
/*    */     }
/*    */     
/* 22 */     Properties props = new Properties();
/* 23 */     if (propFile.exists()) {
/* 24 */       FileInputStream fis = new FileInputStream(propFile);
/* 25 */       if (fis != null) {
/* 26 */         props.loadFromXML(fis);
/* 27 */         fis.close();
/*    */       } 
/*    */     } 
/* 30 */     return props;
/*    */   }
/*    */   
/*    */   public static Properties loadProperties(String fileName) throws IOException {
/* 34 */     Properties props = new Properties();
/* 35 */     File f = null;
/* 36 */     if (fileName.startsWith("file:")) {
/*    */       try {
/* 38 */         f = new File((new URL(fileName)).toURI());
/* 39 */       } catch (Exception e) {
/* 40 */         return props;
/*    */       } 
/*    */     } else {
/* 43 */       f = new File(fileName);
/*    */     } 
/*    */     
/* 46 */     if (f.exists()) {
/* 47 */       FileInputStream fis = new FileInputStream(f);
/* 48 */       if (fis != null) {
/* 49 */         props.loadFromXML(fis);
/* 50 */         fis.close();
/*    */       } 
/*    */     } else {
/* 53 */       LOG.warn("Propertyfile " + fileName + " doesnt exist !\n");
/*    */     } 
/* 55 */     return props;
/*    */   }
/*    */   
/*    */   public static void storeProperties(Properties props, String fileName, String title) throws IOException {
/* 59 */     File propFile = null;
/*    */     
/* 61 */     if (fileName.startsWith("file:")) {
/*    */       try {
/* 63 */         propFile = new File((new URL(fileName)).toURI());
/* 64 */       } catch (Exception e) {
/* 65 */         DebugCounter.inc("PropertyIO.storeProperties(...) Cannot store properties, provided URL was malformed!\n" + fileName);
/*    */         return;
/*    */       } 
/*    */     } else {
/* 69 */       propFile = new File(fileName);
/*    */     } 
/*    */     
/* 72 */     if (!propFile.exists()) {
/* 73 */       (new File(propFile.getParent())).mkdirs();
/* 74 */       propFile.createNewFile();
/*    */     } 
/*    */     
/*    */     try {
/* 78 */       FileOutputStream fos = new FileOutputStream(propFile);
/* 79 */       props.storeToXML(fos, title);
/* 80 */       fos.close();
/* 81 */     } catch (IOException fileException) {
/* 82 */       fileException.printStackTrace();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void storeProperties(Properties props, File file, String title) throws IOException {
/* 88 */     if (!file.exists()) {
/* 89 */       (new File(file.getParent())).mkdirs();
/* 90 */       file.createNewFile();
/*    */     } 
/*    */     
/* 93 */     FileOutputStream fos = new FileOutputStream(file);
/* 94 */     props.storeToXML(fos, title);
/* 95 */     fos.close();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/PropertyIo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */