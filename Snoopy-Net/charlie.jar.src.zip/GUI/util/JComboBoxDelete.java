/*    */ package GUI.util;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.util.Vector;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.ComboBoxModel;
/*    */ import javax.swing.JComboBox;
/*    */ import javax.swing.JMenuItem;
/*    */ import javax.swing.JPopupMenu;
/*    */ import javax.swing.KeyStroke;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JComboBoxDelete
/*    */   extends JComboBox
/*    */ {
/*    */   public JComboBoxDelete(String toolTip, boolean editable, Dimension size) {
/* 20 */     initialize(toolTip, editable, size);
/*    */   }
/*    */   
/*    */   public JComboBoxDelete(String toolTip, boolean editable, Dimension size, Object[] items) {
/* 24 */     super((E[])items);
/* 25 */     initialize(toolTip, editable, size);
/*    */   }
/*    */ 
/*    */   
/*    */   public JComboBoxDelete(String toolTip, boolean editable, Dimension size, Vector<?> items) {
/* 30 */     super((Vector)items);
/* 31 */     initialize(toolTip, editable, size);
/*    */   }
/*    */   
/*    */   public JComboBoxDelete(String toolTip, boolean editable, Dimension size, ComboBoxModel<E> aModel) {
/* 35 */     initialize(toolTip, editable, size);
/* 36 */     if (aModel != null) {
/* 37 */       setModel(aModel);
/*    */     }
/*    */   }
/*    */   
/*    */   public void initialize(String toolTip, boolean editable, Dimension size) {
/* 42 */     if (toolTip != null && !toolTip.equals(""))
/* 43 */       MultiLineToolTip.setMultiLineToolTip(this, toolTip); 
/* 44 */     setEditable(editable);
/* 45 */     setPreferredSize(size);
/* 46 */     if (size != null)
/* 47 */       setSize(size); 
/* 48 */     if (!editable) {
/* 49 */       getInputMap().put(KeyStroke.getKeyStroke(127, 0), "delete");
/* 50 */       getActionMap().put("delete", new AbstractAction()
/*    */           {
/*    */             public void actionPerformed(ActionEvent e) {
/* 53 */               JComboBox box = (JComboBox)e.getSource();
/* 54 */               Object o = box.getSelectedItem();
/* 55 */               if (o != null) {
/*    */                 
/* 57 */                 box.removeItem(o);
/* 58 */                 if (box.getItemCount() > 0) {
/* 59 */                   Object o2 = box.getItemAt(0);
/* 60 */                   box.setSelectedItem(o2);
/*    */                 } 
/*    */               } 
/*    */             }
/*    */           });
/*    */     } else {
/* 66 */       addPopupMenu();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void addPopupMenu() {
/* 73 */     JPopupMenu popup = new JPopupMenu();
/* 74 */     JMenuItem removeItem = new JMenuItem(new AbstractAction("remove item") {
/*    */           public void actionPerformed(ActionEvent e) {
/* 76 */             JComboBox c = (JComboBox)e.getSource();
/* 77 */             Object o = c.getSelectedItem();
/* 78 */             c.removeItem(o);
/*    */           }
/*    */         });
/*    */     
/* 82 */     setComponentPopupMenu(popup);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static JComboBoxDelete generateComboBox(String toolTip, boolean editable, Dimension size) {
/* 93 */     JComboBoxDelete c = new JComboBoxDelete(toolTip, editable, size);
/* 94 */     return c;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/JComboBoxDelete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */