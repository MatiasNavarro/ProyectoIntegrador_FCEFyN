/*    */ package GUI.util;
/*    */ 
/*    */ import GUI.debug.DebugCounter;
/*    */ import GUI.io.FileSaver;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.File;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.AbstractButton;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExportFileAction
/*    */   extends AbstractAction
/*    */ {
/* 15 */   String suggestedFileName = null;
/* 16 */   String tooltipText = null;
/* 17 */   String path = null;
/* 18 */   File file = null;
/* 19 */   FileSaver fs = new FileSaver();
/*    */   public ExportFileAction(String text, String suggestedFileName, String tooltipText, String path) {
/* 21 */     putValue("Name", text);
/* 22 */     putValue("ShortDescription", tooltipText);
/* 23 */     this.suggestedFileName = suggestedFileName;
/* 24 */     this.tooltipText = tooltipText;
/* 25 */     this.path = path;
/* 26 */     this.file = new File(path + File.separatorChar + suggestedFileName);
/*    */   }
/*    */ 
/*    */   
/*    */   public ExportFileAction(String text, File file, String tooltipText) {
/* 31 */     putValue("Name", text);
/* 32 */     putValue("ShortDescription", tooltipText);
/* 33 */     this.file = file;
/* 34 */     this.tooltipText = tooltipText;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 38 */     AbstractButton button = (AbstractButton)e.getSource();
/* 39 */     if (this.fs.isVisible()) {
/* 40 */       DebugCounter.inc("filesaver visible");
/*    */       return;
/*    */     } 
/* 43 */     if (!button.isSelected()) {
/*    */ 
/*    */       
/* 46 */       button.setSelected(false);
/*    */       return;
/*    */     } 
/* 49 */     if (this.file == null && !this.suggestedFileName.equals("")) {
/* 50 */       if (this.path != null && !this.path.equals("")) {
/* 51 */         this.file = new File(this.path + System.getProperty("file.separator") + this.suggestedFileName);
/*    */       } else {
/* 53 */         this.file = new File(FileSaver.lastSaveDir + System.getProperty("file.separator") + this.suggestedFileName);
/*    */       } 
/*    */     }
/*    */     
/* 57 */     this.file = this.fs.saveNewFile(this.file, "Do you want to overwrite this file?");
/*    */     
/* 59 */     setTooltipText(this.tooltipText, this.file);
/* 60 */     if (this.file != null) {
/* 61 */       button.setSelected(true);
/*    */     } else {
/* 63 */       button.setSelected(false);
/*    */     } 
/*    */   }
/*    */   private void setTooltipText(String pre, File file) {
/* 67 */     if (file != null) {
/* 68 */       if (!this.tooltipText.equals("")) {
/* 69 */         putValue("ShortDescription", "<html><p>" + this.tooltipText + "</p><p>Path: " + file.getParent() + "<br>File: " + file.getName() + " </p></html");
/*    */       } else {
/* 71 */         putValue("ShortDescription", "<html><p>Path: " + file.getParent() + "<br>File: " + file.getName() + " </p></html");
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   public File getFile() {
/* 77 */     return this.file;
/*    */   }
/*    */   
/*    */   public void setFile(File f) {
/* 81 */     this.file = f;
/* 82 */     setTooltipText(this.tooltipText, f);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/ExportFileAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */