/*    */ package GUI.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.StringWriter;
/*    */ import java.util.StringTokenizer;
/*    */ import javax.swing.JEditorPane;
/*    */ import javax.swing.text.EditorKit;
/*    */ import javax.swing.text.html.HTMLDocument;
/*    */ 
/*    */ public class HTML
/*    */ {
/*    */   public static String htmltotext(String htmlText) {
/* 15 */     Html2Text parser = new Html2Text();
/* 16 */     String txtText = parser.parseHtml(htmlText);
/* 17 */     return txtText;
/*    */   }
/*    */   
/*    */   public static String htmltotext(HTMLDocument doc) {
/*    */     try {
/* 22 */       StringWriter sw = new StringWriter();
/* 23 */       JEditorPane outputArea = new JEditorPane();
/* 24 */       outputArea.setContentType("text/html; charset=EUC-JP ");
/* 25 */       EditorKit kit = outputArea.getEditorKit();
/* 26 */       kit.write(sw, doc, 0, doc.getLength());
/* 27 */       StringTokenizer st = new StringTokenizer(sw.toString(), "\n");
/*    */ 
/*    */       
/* 30 */       return htmltotext(sw.toString());
/* 31 */     } catch (Exception e) {
/* 32 */       e.printStackTrace();
/* 33 */       return "";
/*    */     } 
/*    */   }
/*    */   
/*    */   public static boolean storeDocumentAsHTML(HTMLDocument doc, File file) {
/*    */     try {
/* 39 */       FileOutputStream fos = new FileOutputStream(file);
/* 40 */       OutputStreamWriter oos = new OutputStreamWriter(fos);
/* 41 */       EditorKit kit = JEditorPane.createEditorKitForContentType("text/html");
/* 42 */       kit.write(oos, doc, 0, doc.getLength());
/*    */ 
/*    */       
/* 45 */       oos.close();
/* 46 */       return true;
/* 47 */     } catch (Exception e) {
/* 48 */       e.printStackTrace();
/* 49 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean storeDocumentAsText(HTMLDocument doc, File file) {
/*    */     try {
/* 57 */       String txtText = htmltotext(doc);
/* 58 */       FileOutputStream fos = new FileOutputStream(file);
/* 59 */       OutputStreamWriter oos = new OutputStreamWriter(fos);
/* 60 */       oos.write(txtText, 0, txtText.length());
/* 61 */       oos.close();
/* 62 */       return true;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     }
/* 69 */     catch (Exception e) {
/* 70 */       e.printStackTrace();
/* 71 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/HTML.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */