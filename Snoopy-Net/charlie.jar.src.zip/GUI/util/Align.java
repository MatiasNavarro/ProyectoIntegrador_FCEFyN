/*    */ package GUI.util;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.Toolkit;
/*    */ 
/*    */ public class Align
/*    */ {
/*    */   public static void alignToParentWindow(Container child, Container parent) {
/*    */     Rectangle r;
/* 12 */     if (child == null)
/*    */       return; 
/* 14 */     if (parent != null) {
/* 15 */       r = parent.getBounds();
/*    */     } else {
/*    */       return;
/*    */     } 
/* 19 */     int posx = (int)(r.getX() + r.getWidth());
/* 20 */     int posy = (int)r.getY();
/* 21 */     child.setLocation(posx, posy);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void toCenter(Container frame) {
/* 26 */     if (frame == null)
/* 27 */       return;  Rectangle r = frame.getBounds();
/* 28 */     Toolkit tKit = Toolkit.getDefaultToolkit();
/* 29 */     Dimension dim = tKit.getScreenSize();
/* 30 */     int y = (int)(dim.getHeight() / 2.0D - r.getHeight() / 2.0D);
/* 31 */     int x = (int)(dim.getWidth() / 2.0D - r.getWidth() / 2.0D);
/* 32 */     frame.setLocation(x, y);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void toTopRight(Container frame) {
/* 38 */     Toolkit tKit = Toolkit.getDefaultToolkit();
/* 39 */     if (frame == null)
/* 40 */       return;  Rectangle r = frame.getBounds();
/* 41 */     Dimension dim = tKit.getScreenSize();
/* 42 */     int x = (int)(dim.getWidth() - r.getWidth());
/*    */     
/* 44 */     frame.setLocation(x, 0);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/Align.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */