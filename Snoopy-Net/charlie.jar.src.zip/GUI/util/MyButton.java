/*     */ package GUI.util;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.net.URL;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ 
/*     */ public abstract class MyButton
/*     */   extends JLabel implements MouseListener {
/*  13 */   private Icon actual = null;
/*  14 */   private Icon standard = null;
/*  15 */   private Icon rollOver = null;
/*     */   
/*     */   public MyButton(URL url, String toolTip) {
/*  18 */     if (url != null)
/*  19 */       this.standard = new ImageIcon(url); 
/*  20 */     this.actual = this.standard;
/*  21 */     setIcon(this.standard);
/*  22 */     Dimension d = null;
/*  23 */     if (this.standard != null) {
/*  24 */       d = new Dimension(this.standard.getIconHeight(), this.standard.getIconWidth());
/*     */     } else {
/*  26 */       d = new Dimension(20, 20);
/*  27 */     }  toolTip.replace('\n', ' ');
/*  28 */     toolTip = "<html><p>" + toolTip + "</p></html>";
/*  29 */     setToolTipText(toolTip);
/*  30 */     setIconTextGap(0);
/*     */     
/*  32 */     setPreferredSize(d);
/*  33 */     setSize(d);
/*  34 */     addMouseListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MyButton(String icon, String toolTip) {
/*  39 */     this.standard = new ImageIcon(icon);
/*  40 */     this.actual = this.standard;
/*  41 */     setIcon(this.standard);
/*  42 */     Dimension d = new Dimension(this.standard.getIconHeight(), this.standard.getIconWidth());
/*  43 */     toolTip.replace('\n', ' ');
/*  44 */     toolTip = "<html><p>" + toolTip + "</p></html>";
/*  45 */     setToolTipText(toolTip);
/*  46 */     setIconTextGap(0);
/*     */     
/*  48 */     setPreferredSize(d);
/*  49 */     setSize(d);
/*  50 */     addMouseListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MyButton(URL icon, URL iconRo, String toolTip) {
/*  55 */     if (icon != null) {
/*  56 */       this.standard = new ImageIcon(icon);
/*     */     }
/*  58 */     this.actual = this.standard;
/*  59 */     if (iconRo != null)
/*  60 */       this.rollOver = new ImageIcon(iconRo); 
/*  61 */     setIcon(this.standard);
/*  62 */     Dimension d = null;
/*  63 */     if (icon != null && iconRo != null) {
/*  64 */       d = new Dimension(this.standard.getIconHeight(), this.standard.getIconWidth());
/*     */     } else {
/*  66 */       d = new Dimension(20, 20);
/*  67 */     }  toolTip.replace('\n', ' ');
/*  68 */     toolTip = "<html><p>" + toolTip + "</p></html>";
/*  69 */     setToolTipText(toolTip);
/*  70 */     setIconTextGap(0);
/*     */     
/*  72 */     setPreferredSize(d);
/*  73 */     setSize(d);
/*  74 */     addMouseListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MyButton(String icon, String iconRo, String toolTip) {
/*  79 */     if (icon != null) {
/*  80 */       this.standard = new ImageIcon(icon);
/*     */     }
/*  82 */     this.actual = this.standard;
/*  83 */     if (iconRo != null)
/*  84 */       this.rollOver = new ImageIcon(iconRo); 
/*  85 */     setIcon(this.standard);
/*  86 */     Dimension d = null;
/*  87 */     if (icon != null && iconRo != null) {
/*  88 */       d = new Dimension(this.standard.getIconHeight(), this.standard.getIconWidth());
/*     */     } else {
/*  90 */       d = new Dimension(20, 20);
/*  91 */     }  toolTip.replace('\n', ' ');
/*  92 */     toolTip = "<html><p>" + toolTip + "</p></html>";
/*  93 */     setToolTipText(toolTip);
/*  94 */     setIconTextGap(0);
/*     */     
/*  96 */     setPreferredSize(d);
/*  97 */     setSize(d);
/*  98 */     addMouseListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void mouseClicked(MouseEvent paramMouseEvent);
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {
/* 108 */     if (this.rollOver != null) setIcon(this.rollOver); 
/* 109 */     revalidate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseExited(MouseEvent e) {
/* 114 */     if (this.rollOver != null) setIcon(this.standard); 
/* 115 */     revalidate();
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent e) {}
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {}
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/MyButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */