/*     */ package GUI.util;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.Timer;
/*     */ 
/*     */ public class ElapsedTime
/*     */   implements Runnable, ActionListener {
/*     */   JLabel label;
/*     */   String text;
/*  17 */   Timer timer = null;
/*     */   Date startDate;
/*  19 */   long startTime = 0L;
/*  20 */   long stopTime = 0L;
/*  21 */   long resumeTime = 0L;
/*  22 */   long pauseTime = 0L;
/*  23 */   long endTime = 0L;
/*  24 */   int[] time = new int[] { 0, 0, 0, 0, 0 };
/*  25 */   GregorianCalendar gStart = new GregorianCalendar();
/*  26 */   GregorianCalendar gEnd = new GregorianCalendar();
/*     */   
/*     */   String initialText;
/*     */   
/*     */   public ElapsedTime(JLabel label, int delay) {
/*  31 */     this.startTime = Calendar.getInstance().getTimeInMillis();
/*     */     
/*  33 */     this.gStart.setTimeInMillis(this.startTime);
/*  34 */     this.time[0] = this.gStart.get(5);
/*  35 */     this.time[1] = this.gStart.get(11);
/*  36 */     this.time[2] = this.gStart.get(12);
/*  37 */     this.time[3] = this.gStart.get(13);
/*  38 */     this.time[4] = this.gStart.get(14);
/*     */     
/*  40 */     if (delay > 0) {
/*  41 */       this.timer = new Timer(delay, this);
/*     */     }
/*  43 */     this.endTime = this.startTime;
/*  44 */     this.label = label;
/*  45 */     if (label != null)
/*  46 */       this.initialText = label.getText(); 
/*     */   }
/*     */   
/*     */   public ElapsedTime(String text, JLabel label) {
/*  50 */     this.label = label;
/*  51 */     this.text = text;
/*     */   }
/*     */   
/*     */   public void setText(String text) {
/*  55 */     this.text = text;
/*     */   }
/*     */   public void run() {
/*  58 */     if (this.label != null) {
/*  59 */       this.label.setText(this.text);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void invokeLater(String text, JLabel label) {
/*  64 */     SwingUtilities.invokeLater(new ElapsedTime(text, label));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getElapsedTime(long time) {
/*  77 */     return getElapsedTime(new Date(0L), new Date(time));
/*     */   }
/*     */   
/*     */   public static String getElapsedTime(Date startTime, Date currentTime) {
/*  81 */     long start = startTime.getTime();
/*  82 */     long current = currentTime.getTime();
/*  83 */     long diff = current - start;
/*  84 */     SimpleDateFormat df = new SimpleDateFormat();
/*  85 */     df.applyPattern("hh:mm:ss:SSS");
/*  86 */     String ret2 = df.format(new Date(diff));
/*  87 */     String ret = "" + (diff / 60000L);
/*  88 */     ret = ret + " m ";
/*  89 */     ret = ret + ((diff % 60000L) / 1000.0D);
/*  90 */     ret = ret + " s ";
/*     */     
/*  92 */     return ret2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getElapsedTime() {
/*  98 */     if (this.endTime < this.startTime || !this.timer.isRunning()) {
/*  99 */       this.gEnd.setTimeInMillis(this.endTime - this.pauseTime);
/*     */     } else {
/* 101 */       this.gEnd.setTimeInMillis(System.currentTimeMillis() - this.pauseTime);
/* 102 */     }  GregorianCalendar gDiff = new GregorianCalendar();
/* 103 */     gDiff.setTimeInMillis(this.gEnd.getTime().getTime() - this.gStart.getTime().getTime());
/* 104 */     int days = gDiff.get(5) - 1;
/* 105 */     int hours = days * 24 + gDiff.get(11) - 1;
/* 106 */     int minutes = gDiff.get(12);
/* 107 */     int seconds = gDiff.get(13);
/* 108 */     int milliseconds = gDiff.get(14);
/*     */     
/* 110 */     String s = String.format("%02d:%02d:%02d:%03d", new Object[] { Integer.valueOf(hours), Integer.valueOf(minutes), Integer.valueOf(seconds), Integer.valueOf(milliseconds) });
/*     */     
/* 112 */     return s;
/*     */   }
/*     */   
/*     */   public static ElapsedTime getElapsedTimer(JLabel label, int delay, boolean start) {
/* 116 */     if (delay < 0) delay = 125; 
/* 117 */     ElapsedTime e = new ElapsedTime(label, delay);
/* 118 */     if (start) e.start(); 
/* 119 */     return e;
/*     */   }
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 123 */     if (this.label != null) {
/* 124 */       this.label.setText(this.initialText + getElapsedTime());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void pause() {
/* 130 */     if (this.timer != null && this.timer.isRunning()) {
/* 131 */       this.timer.stop();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 137 */       this.stopTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void resume() {
/* 143 */     if (this.timer != null && !this.timer.isRunning()) {
/* 144 */       this.timer.start();
/* 145 */       this.resumeTime = System.currentTimeMillis();
/* 146 */       this.pauseTime += this.resumeTime - this.stopTime;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stop() {
/* 151 */     if (this.timer != null && this.timer.isRunning()) {
/* 152 */       this.timer.stop();
/* 153 */       this.endTime = System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void start() {
/* 158 */     if (this.timer != null && !this.timer.isRunning()) {
/* 159 */       this.timer.start();
/*     */     }
/* 161 */     else if (this.timer.isRunning()) {
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/* 169 */     return this.timer.isRunning();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/ElapsedTime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */