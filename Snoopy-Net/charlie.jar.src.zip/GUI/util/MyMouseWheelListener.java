/*     */ package GUI.util;
/*     */ 
/*     */ import GUI.dialog.DialogPanel;
/*     */ import java.awt.event.MouseWheelEvent;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JSpinner;
/*     */ 
/*     */ public class MyMouseWheelListener
/*     */   implements MouseWheelListener
/*     */ {
/*  14 */   int increment = 1;
/*     */   
/*     */   public MyMouseWheelListener(int increment) {
/*  17 */     if (increment != 0) {
/*  18 */       if (increment < 0) {
/*  19 */         increment = -1 * increment;
/*     */       }
/*  21 */       this.increment = increment;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseWheelMoved(MouseWheelEvent e) {
/*  26 */     Object source = e.getSource();
/*  27 */     if (source instanceof JSpinner) {
/*  28 */       spinner(e);
/*  29 */     } else if (source instanceof JSlider) {
/*  30 */       slider(e);
/*  31 */     } else if (source instanceof JComboBox) {
/*  32 */       combobox(e);
/*  33 */     } else if (source instanceof DialogPanel) {
/*  34 */       dialogpanel(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void spinner(MouseWheelEvent e) {
/*  39 */     JSpinner spin = (JSpinner)e.getSource();
/*  40 */     int value = e.getWheelRotation();
/*  41 */     if (value > 1 || value < -1) {
/*  42 */       value *= this.increment;
/*     */     }
/*  44 */     Object o = null;
/*  45 */     while (value > 0) {
/*  46 */       o = spin.getPreviousValue();
/*  47 */       value--;
/*     */     } 
/*     */     
/*  50 */     while (value < 0) {
/*  51 */       o = spin.getNextValue();
/*  52 */       value++;
/*     */     } 
/*  54 */     if (o != null) {
/*  55 */       spin.setValue(o);
/*     */     }
/*     */   }
/*     */   
/*     */   private void slider(MouseWheelEvent e) {
/*  60 */     JSlider slide = (JSlider)e.getSource();
/*  61 */     int value = e.getWheelRotation();
/*  62 */     if (value > 1 || value < -1) {
/*  63 */       value *= this.increment;
/*     */     }
/*     */ 
/*     */     
/*  67 */     value *= -1;
/*  68 */     slide.setValue(slide.getValue() + value);
/*     */   }
/*     */   
/*     */   private void combobox(MouseWheelEvent e) {
/*  72 */     JComboBox combo = (JComboBox)e.getSource();
/*  73 */     int value = e.getWheelRotation();
/*  74 */     if (value > 1 || value < -1) {
/*  75 */       value *= this.increment;
/*     */     }
/*  77 */     int index = combo.getSelectedIndex();
/*  78 */     int max = combo.getItemCount();
/*  79 */     index += value;
/*  80 */     if (index < 0)
/*     */       return; 
/*  82 */     if (index >= max) {
/*  83 */       combo.setSelectedIndex(max - 1);
/*     */     } else {
/*  85 */       combo.setSelectedIndex(index);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void dialogpanel(MouseWheelEvent e) {
/*  90 */     DialogPanel p = (DialogPanel)e.getSource();
/*  91 */     int value = e.getWheelRotation();
/*  92 */     int index = p.getMaximizedIndex();
/*  93 */     int max = p.getDialogCount();
/*  94 */     if (index >= max - 1 && value > 0) {
/*     */       return;
/*     */     }
/*  97 */     index += value;
/*     */     
/*  99 */     if (index < 0)
/*     */       return; 
/* 101 */     if (index >= max) {
/* 102 */       p.minimizeAllBut(max - 1);
/*     */     } else {
/* 104 */       p.minimizeAllBut(index);
/*     */     } 
/* 106 */     p.redraw();
/*     */   }
/*     */   
/*     */   public static MouseWheelListener get(int increment) {
/* 110 */     MyMouseWheelListener mw = new MyMouseWheelListener(increment);
/* 111 */     return mw;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static JComponent attach(JComponent c, int increment) {
/* 117 */     if (c != null) {
/* 118 */       c.addMouseWheelListener(get(increment));
/*     */     }
/* 120 */     return c;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/MyMouseWheelListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */