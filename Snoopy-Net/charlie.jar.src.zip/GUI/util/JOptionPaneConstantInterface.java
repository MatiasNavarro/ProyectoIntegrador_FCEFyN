/*    */ package GUI.util;
/*    */ 
/*    */ import charlie.pn.Constant;
/*    */ import charlie.pn.ConstantInterface;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ public class JOptionPaneConstantInterface
/*    */   implements ConstantInterface
/*    */ {
/*    */   public void askForValue(Constant c) {
/* 11 */     String ret = JOptionPane.showInputDialog("constant without value: " + c.getName());
/* 12 */     c.setValue(ret);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/JOptionPaneConstantInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */