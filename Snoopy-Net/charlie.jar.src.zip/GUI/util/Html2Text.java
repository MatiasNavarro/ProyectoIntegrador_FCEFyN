/*    */ package GUI.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ import java.io.StringReader;
/*    */ import javax.swing.text.MutableAttributeSet;
/*    */ import javax.swing.text.html.HTML;
/*    */ import javax.swing.text.html.HTMLEditorKit;
/*    */ import javax.swing.text.html.parser.ParserDelegator;
/*    */ 
/*    */ public class Html2Text
/*    */   extends HTMLEditorKit.ParserCallback
/*    */ {
/*    */   StringBuffer s;
/*    */   
/*    */   public void parse(Reader in) throws IOException {
/* 17 */     this.s = new StringBuffer();
/* 18 */     ParserDelegator delegator = new ParserDelegator();
/*    */     
/* 20 */     delegator.parse(in, this, Boolean.TRUE.booleanValue());
/*    */   }
/*    */   
/*    */   public void handleText(char[] text, int pos) {
/* 24 */     this.s.append(text);
/*    */   }
/*    */   
/*    */   public void handleEndTag(HTML.Tag t, int pos) {
/* 28 */     if (t.isBlock()) {
/* 29 */       this.s.append("\n\n");
/* 30 */     } else if (t.breaksFlow()) {
/* 31 */       this.s.append("\n");
/*    */     } 
/*    */   }
/*    */   
/*    */   public void handleSimpleTag(HTML.Tag t, MutableAttributeSet a, int pos) {
/* 36 */     if (t.isBlock()) {
/* 37 */       this.s.append("\n\n");
/* 38 */     } else if (t.breaksFlow()) {
/* 39 */       this.s.append("\n");
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getText() {
/* 44 */     return this.s.toString();
/*    */   }
/*    */   
/*    */   public String parseHtml(String htmlString) {
/*    */     try {
/* 49 */       StringReader in = new StringReader(htmlString);
/* 50 */       parse(in);
/* 51 */       in.close();
/* 52 */       return getText();
/* 53 */     } catch (Exception e) {
/* 54 */       e.printStackTrace();
/*    */       
/* 56 */       return "";
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/Html2Text.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */