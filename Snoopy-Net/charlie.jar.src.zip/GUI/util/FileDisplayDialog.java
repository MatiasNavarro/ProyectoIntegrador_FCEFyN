/*     */ package GUI.util;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.MouseInfo;
/*     */ import java.awt.Point;
/*     */ import java.awt.PointerInfo;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileDisplayDialog
/*     */   extends JDialog
/*     */ {
/*  24 */   private final JTextArea area = new JTextArea();
/*  25 */   private Point p = null;
/*     */   private File file;
/*     */   
/*     */   public FileDisplayDialog(File f) {
/*  29 */     this.file = f;
/*  30 */     PointerInfo pi = MouseInfo.getPointerInfo();
/*  31 */     this.p = pi.getLocation();
/*  32 */     this.p.x += 20;
/*  33 */     this.p.y += 20;
/*  34 */     initialize();
/*     */   }
/*     */   
/*     */   public FileDisplayDialog(Point p, File f) {
/*  38 */     this.file = f;
/*  39 */     this.p = p;
/*  40 */     initialize();
/*     */   }
/*     */ 
/*     */   
/*     */   public FileDisplayDialog(String text) {
/*  45 */     this((MouseInfo.getPointerInfo().getLocation()).x, (MouseInfo.getPointerInfo().getLocation()).y, text);
/*     */   }
/*     */   
/*     */   public FileDisplayDialog(String text, String title) {
/*  49 */     this((MouseInfo.getPointerInfo().getLocation()).x, (MouseInfo.getPointerInfo().getLocation()).y, text);
/*  50 */     setTitle(title);
/*     */   }
/*     */   
/*     */   public FileDisplayDialog(int x, int y, File f) {
/*  54 */     this.file = f;
/*  55 */     this.p = new Point(x, y);
/*  56 */     initialize();
/*     */   }
/*     */   
/*     */   public FileDisplayDialog(int x, int y, String text) {
/*  60 */     this.p = new Point(x, y);
/*  61 */     initializeText(text);
/*     */   }
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  66 */     JDialog f = this;
/*     */     
/*  68 */     f.setTitle(this.file.getName());
/*  69 */     f.setLayout(new BorderLayout());
/*  70 */     f.setModal(false);
/*  71 */     ArrayList<String> lines = new ArrayList<>();
/*  72 */     String text = TextFile.readTextFile(this.file);
/*  73 */     if (text != null) {
/*  74 */       this.area.setText(text);
/*  75 */       JScrollPane scroll = new JScrollPane(this.area);
/*  76 */       scroll.setPreferredSize(new Dimension(200, 200));
/*  77 */       f.getContentPane().add(scroll, "Center");
/*  78 */       f.setLocation(this.p);
/*  79 */       ActionListener listener = new ActionListener()
/*     */         {
/*     */           public final void actionPerformed(ActionEvent e) {
/*  82 */             FileDisplayDialog.this.setVisible(false);
/*  83 */             FileDisplayDialog.this.dispose();
/*     */           }
/*     */         };
/*     */       
/*  87 */       KeyStroke keyStroke = KeyStroke.getKeyStroke(27, 0, true);
/*  88 */       getRootPane().registerKeyboardAction(listener, keyStroke, 1);
/*     */       
/*  90 */       f.pack();
/*  91 */       f.setVisible(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void initializeText(String text) {
/*  97 */     JDialog f = this;
/*     */     
/*  99 */     f.setIconImage(Toolkit.getDefaultToolkit().getImage(ResourceLoader.getURL("resources/icon.png")));
/* 100 */     f.setLayout(new BorderLayout());
/* 101 */     f.setModal(false);
/* 102 */     this.area.setText(text);
/* 103 */     this.area.setEditable(false);
/* 104 */     this.area.setFont(new Font("Monospaced", 0, 12));
/* 105 */     JScrollPane scroll = new JScrollPane(this.area);
/* 106 */     scroll.setPreferredSize(new Dimension(200, 200));
/* 107 */     f.getContentPane().add(scroll, "Center");
/* 108 */     f.setLocation(this.p);
/* 109 */     f.pack();
/* 110 */     f.setVisible(true);
/*     */   }
/*     */   
/*     */   public void updateText(String _text) {
/* 114 */     this.area.setText(_text);
/*     */   }
/*     */   
/*     */   public static FileDisplayDialog getDialog(File file) {
/* 118 */     return new FileDisplayDialog(file);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/FileDisplayDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */