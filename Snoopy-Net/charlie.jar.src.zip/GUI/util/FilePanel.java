/*     */ package GUI.util;
/*     */ 
/*     */ import GUI.io.FileSaver;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.TitledBorder;
/*     */ 
/*     */ public class FilePanel extends JPanel implements ActionListener {
/*     */   private Component f;
/*     */   private JButton choose;
/*  18 */   private String defaultString = "";
/*     */   private Vector<String> filterList;
/*     */   private JTextField path;
/*     */   
/*     */   public FilePanel(Component owner, String filter, String defaultString, String title) {
/*  23 */     this.defaultString = defaultString;
/*  24 */     this.choose = new JButton("...");
/*  25 */     this.filterList = new Vector<>();
/*  26 */     this.filterList.add(filter);
/*     */ 
/*     */ 
/*     */     
/*  30 */     this.path = new JTextField();
/*  31 */     this.path.setText(defaultString);
/*     */ 
/*     */ 
/*     */     
/*  35 */     add(this.path);
/*  36 */     this.choose.addActionListener(this);
/*     */ 
/*     */ 
/*     */     
/*  40 */     this.path.setPreferredSize(new Dimension(250, 25));
/*  41 */     this.path.setPreferredSize(new Dimension(250, 25));
/*     */     
/*  43 */     add(this.choose);
/*  44 */     if (title != null && !title.equals("")) setBorder(new TitledBorder(title)); 
/*     */   }
/*     */   
/*     */   public void showDefaultString() {
/*  48 */     this.path.setText(this.defaultString);
/*     */   }
/*     */   
/*     */   public void addActionListener(ActionListener al) {
/*  52 */     this.choose.addActionListener(al);
/*     */   }
/*     */   
/*     */   public void clearFilterList() {
/*  56 */     this.filterList.clear();
/*     */   }
/*     */   
/*     */   public JButton getChooseButton() {
/*  60 */     return this.choose;
/*     */   }
/*     */   
/*     */   public void addFilter(String filter) {
/*  64 */     this.filterList.add(filter);
/*     */   }
/*     */   
/*     */   public FilePanel(Component owner, String filter, String defaultString, String title, boolean showDefaultString) {
/*  68 */     this.filterList = new Vector<>();
/*  69 */     this.defaultString = defaultString;
/*  70 */     this.choose = new JButton("...");
/*  71 */     this.filterList.add(filter);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     this.path = new JTextField();
/*  77 */     if (showDefaultString) this.path.setText(defaultString);
/*     */ 
/*     */ 
/*     */     
/*  81 */     add(this.path);
/*  82 */     this.choose.addActionListener(this);
/*     */ 
/*     */ 
/*     */     
/*  86 */     this.path.setPreferredSize(new Dimension(250, 25));
/*  87 */     this.path.setPreferredSize(new Dimension(250, 25));
/*     */     
/*  89 */     add(this.choose);
/*  90 */     if (title != null && !title.equals("")) setBorder(new TitledBorder(title)); 
/*     */   }
/*     */   
/*     */   public JButton getButton() {
/*  94 */     return this.choose;
/*     */   }
/*     */   
/*     */   public String getPath() {
/*  98 */     return this.path.getText();
/*     */   }
/*     */   
/*     */   public void clearPath() {
/* 102 */     this.path.setText("");
/*     */   }
/*     */   
/*     */   public String nameWithoutExtension() {
/* 106 */     if (this.path.getText().equals("")) return this.path.getText(); 
/* 107 */     String filename = (new File(this.path.getText())).getName();
/* 108 */     int index = filename.indexOf(".");
/* 109 */     return filename.substring(0, index);
/*     */   }
/*     */   
/*     */   public void setPath(String path) {
/* 113 */     this.path.setText(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 118 */     FileSaver fs = new FileSaver();
/* 119 */     for (String s : this.filterList) {
/* 120 */       fs.applyFilter(s);
/*     */     }
/* 122 */     File f = null;
/* 123 */     if (this.path.getText().equals("")) {
/* 124 */       f = fs.showSaveDialog(new File(this.defaultString), "", "");
/*     */     } else {
/* 126 */       f = fs.showSaveDialog(new File(this.defaultString), "", "");
/* 127 */     }  if (f != null)
/* 128 */       this.path.setText(f.getAbsolutePath()); 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/FilePanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */