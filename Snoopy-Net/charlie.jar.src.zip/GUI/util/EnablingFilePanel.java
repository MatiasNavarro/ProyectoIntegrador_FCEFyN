/*    */ package GUI.util;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.BorderFactory;
/*    */ import javax.swing.JCheckBox;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ public class EnablingFilePanel
/*    */   extends JPanel {
/*    */   FilePanel filePanel;
/*    */   String title;
/*    */   
/*    */   public EnablingFilePanel(Component owner, String filter, String defaultString, String title, boolean enabled) {
/* 16 */     this.title = title;
/* 17 */     this.defaultString = defaultString;
/* 18 */     setBorder(BorderFactory.createTitledBorder(title));
/* 19 */     this.filePanel = new FilePanel(owner, filter, defaultString, "", enabled);
/* 20 */     this.enable = new CheckBoxPanel("", enabled, new ActionListener() {
/*    */           public void actionPerformed(ActionEvent e) {
/* 22 */             EnablingFilePanel.this.activate(((JCheckBox)e.getSource()).isSelected());
/*    */           }
/*    */         });
/*    */     
/* 26 */     add(this.enable);
/* 27 */     add(this.filePanel);
/*    */   }
/*    */   String defaultString;
/*    */   CheckBoxPanel enable;
/*    */   
/*    */   public void activate(boolean b) {
/* 33 */     if (b) {
/* 34 */       if (getPath().equals(""))
/* 35 */         setPath(this.defaultString); 
/*    */     } else {
/* 37 */       this.filePanel.setPath("");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSelected(boolean b) {
/* 44 */     this.enable.setSelected(b);
/* 45 */     activate(b);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSelected() {
/* 50 */     return this.enable.isSelected();
/*    */   }
/*    */   
/*    */   public String getPath() {
/* 54 */     if (this.enable.isSelected()) {
/* 55 */       return this.filePanel.getPath();
/*    */     }
/* 57 */     return "";
/*    */   }
/*    */   
/*    */   public void setPath(String path) {
/* 61 */     this.filePanel.setPath(path);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/util/EnablingFilePanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */