/*    */ package GUI.app_components;
/*    */ 
/*    */ import GUI.rggui.ReachabilityGraphDialog;
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.GridLayout;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultDialog
/*    */   extends JPanel
/*    */ {
/*    */   private static final long serialVersionUID = 1519632248667841070L;
/* 17 */   ReachabilityGraphDialog rgp = null;
/* 18 */   NetPropertiesDialog np = null;
/*    */ 
/*    */ 
/*    */   
/*    */   public void resultDialog() {
/* 23 */     setLayout(new GridLayout(2, 1));
/* 24 */     this.rgp = new ReachabilityGraphDialog(null);
/* 25 */     this.rgp.initialize();
/* 26 */     this.rgp.setVisible(true);
/*    */     
/* 28 */     this.np = new NetPropertiesDialog();
/* 29 */     this.np.setVisible(true);
/*    */     
/* 31 */     add((Component)this.rgp, (Object)null);
/* 32 */     add(this.np, (Object)null);
/* 33 */     setSize(300, 200);
/* 34 */     setPreferredSize(new Dimension(300, 200));
/* 35 */     setVisible(true);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/ResultDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */