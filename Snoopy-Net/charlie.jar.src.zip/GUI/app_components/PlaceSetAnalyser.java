/*     */ package GUI.app_components;
/*     */ 
/*     */ import charlie.pn.NodeSet;
/*     */ import charlie.pn.Out;
/*     */ import charlie.pn.PlaceSet;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.TransitionSet;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButtonMenuItem;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlaceSetAnalyser
/*     */   extends JDialog
/*     */ {
/*     */   private static final long serialVersionUID = 2539154715572129512L;
/*     */   private final NodeSetPanel placePanel;
/*  38 */   JTextArea ta = new JTextArea();
/*     */   JButton choose;
/*     */   JList placeList;
/*  41 */   JCheckBox trap = new JCheckBox("trap", false);
/*  42 */   JCheckBox siphon = new JCheckBox("siphon", false);
/*  43 */   JCheckBox badSiphon = new JCheckBox("bad siphon", false);
/*  44 */   JButton maxTrap = new JButton("maximal trap");
/*  45 */   JList postTransitions = new JList();
/*  46 */   JList preTransitions = new JList();
/*     */   PlaceTransitionNet pn;
/*  48 */   JPanel boxes = new JPanel();
/*     */   
/*     */   PlaceSet temp;
/*     */   
/*     */   NodeSet pre;
/*     */   
/*     */   NodeSet post;
/*     */ 
/*     */   
/*     */   class NodeSetPanel
/*     */     extends JPanel
/*     */   {
/*     */     private static final long serialVersionUID = -8485621504889273546L;
/*     */     
/*     */     private JList nodeList;
/*     */     
/*     */     private JList postTransitions;
/*     */     
/*     */     private JList preTransitions;
/*     */     
/*     */     private JPanel boxes;
/*     */     
/*     */     private NodeSet temp;
/*     */     
/*     */     private NodeSet pre;
/*     */     
/*     */     private NodeSet post;
/*     */     private String[] placeNames;
/*     */     private String[] placeIds;
/*     */     private String[] placeIdAndName;
/*     */     
/*     */     public class CustomListSelectionListener
/*     */       implements ListSelectionListener
/*     */     {
/*     */       public void valueChanged(ListSelectionEvent e) {
/*  83 */         PlaceSetAnalyser.NodeSetPanel.this.temp.clear();
/*  84 */         int[] indices = ((JList)e.getSource()).getSelectedIndices();
/*  85 */         for (int i = 0; i < indices.length; i++) {
/*  86 */           PlaceSetAnalyser.NodeSetPanel.this.temp.insert(indices[i]);
/*     */         }
/*  88 */         PlaceSetAnalyser.NodeSetPanel.this.pre = PlaceSetAnalyser.NodeSetPanel.this.temp.getPre();
/*  89 */         PlaceSetAnalyser.NodeSetPanel.this.post = PlaceSetAnalyser.NodeSetPanel.this.temp.getPost();
/*  90 */         PlaceSetAnalyser.NodeSetPanel.this.postTransitions.setListData(PlaceSetAnalyser.NodeSetPanel.this.post.getNameArray());
/*  91 */         PlaceSetAnalyser.NodeSetPanel.this.preTransitions.setListData(PlaceSetAnalyser.NodeSetPanel.this.pre.getNameArray());
/*     */       }
/*     */     }
/*     */     
/*     */     public JList getNodeSet() {
/*  96 */       return this.nodeList; } public NodeSetPanel(PlaceTransitionNet pn, boolean transitions) { TransitionSet transitionSet; this.postTransitions = new JList(); this.preTransitions = new JList();
/*     */       this.boxes = new JPanel();
/*     */       this.placeNames = null;
/*     */       this.placeIds = null;
/*     */       this.placeIdAndName = null;
/* 101 */       if (!transitions) {
/* 102 */         this.temp = (NodeSet)new PlaceSet(pn.places());
/* 103 */         PlaceSet placeSet = new PlaceSet(pn.places(), pn.places());
/*     */       } else {
/* 105 */         this.temp = (NodeSet)new TransitionSet(pn.transitions());
/* 106 */         transitionSet = new TransitionSet(pn.transitions(), pn.transitions());
/*     */       } 
/* 108 */       this.placeNames = transitionSet.getNameArray();
/* 109 */       this.placeIds = transitionSet.getOrigIdArray();
/* 110 */       this.placeIdAndName = new String[this.placeNames.length];
/*     */       
/* 112 */       for (int i = 0; i < transitionSet.size(); i++) {
/* 113 */         this.placeIdAndName[i] = String.format("%s (%s)", new Object[] { this.placeNames[i], this.placeIds[i] });
/*     */       } 
/*     */       
/* 116 */       this.nodeList = new JList();
/*     */       
/* 118 */       setPlaceNaming(true, false);
/*     */       
/* 120 */       this.nodeList.addListSelectionListener(new CustomListSelectionListener());
/* 121 */       setLayout(new BorderLayout());
/* 122 */       JPanel placesPanel = new JPanel();
/* 123 */       placesPanel.setLayout(new GridLayout(1, 3));
/* 124 */       this.boxes.setLayout(new GridLayout(1, 2));
/* 125 */       JPanel labels = new JPanel();
/* 126 */       labels.setLayout(new GridLayout(1, 3));
/*     */       
/* 128 */       labels.add(new JLabel("node set Q"));
/* 129 */       placesPanel.add(new JScrollPane(this.nodeList));
/* 130 */       labels.add(new JLabel("FQ"));
/* 131 */       placesPanel.add(new JScrollPane(this.preTransitions));
/* 132 */       labels.add(new JLabel("QF"));
/* 133 */       placesPanel.add(new JScrollPane(this.postTransitions));
/*     */       
/* 135 */       add(labels, "North");
/*     */       
/* 137 */       add(placesPanel, "Center"); }
/*     */ 
/*     */     
/*     */     public void addListSelectionListener(ListSelectionListener ls) {
/* 141 */       this.nodeList.addListSelectionListener(ls);
/*     */     }
/*     */     
/*     */     public NodeSet getSelectedNodes() {
/* 145 */       return this.temp;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setPlaceNaming(boolean _showNames, boolean _showIds) {
/* 150 */       int[] selectedItems = this.nodeList.getSelectedIndices();
/*     */       
/* 152 */       if (_showNames && _showIds) {
/* 153 */         this.nodeList.setListData(this.placeIdAndName);
/* 154 */       } else if (_showNames) {
/* 155 */         this.nodeList.setListData(this.placeNames);
/* 156 */       } else if (_showIds) {
/* 157 */         this.nodeList.setListData(this.placeIds);
/*     */       } 
/*     */       
/* 160 */       this.nodeList.setSelectedIndices(selectedItems);
/*     */     }
/*     */   }
/*     */   
/*     */   public class CustomListSelectionListener
/*     */     implements ListSelectionListener {
/*     */     public void valueChanged(ListSelectionEvent e) {
/* 167 */       PlaceSetAnalyser.this.temp = (PlaceSet)PlaceSetAnalyser.this.placePanel.getSelectedNodes();
/* 168 */       PlaceSetAnalyser.this.pre = PlaceSetAnalyser.this.temp.getPre();
/* 169 */       PlaceSetAnalyser.this.post = PlaceSetAnalyser.this.temp.getPost();
/*     */       
/* 171 */       PlaceSetAnalyser.this.trap.setSelected(PlaceSetAnalyser.this.temp.isTrap());
/* 172 */       PlaceSetAnalyser.this.siphon.setSelected(PlaceSetAnalyser.this.temp.isDeadlock());
/* 173 */       boolean isBadDeadlock = (PlaceSetAnalyser.this.temp.isDeadlock() && PlaceSetAnalyser.this.temp.maxTrap().isEmpty());
/* 174 */       PlaceSetAnalyser.this.badSiphon.setSelected(isBadDeadlock);
/* 175 */       PlaceSetAnalyser.this.postTransitions.setListData(PlaceSetAnalyser.this.post.getNameArray());
/* 176 */       PlaceSetAnalyser.this.preTransitions.setListData(PlaceSetAnalyser.this.pre.getNameArray());
/*     */     }
/*     */   }
/*     */   
/*     */   public class TrapActionListener implements ActionListener {
/*     */     public void actionPerformed(ActionEvent e) {
/* 182 */       PlaceSetAnalyser.this.temp = (PlaceSet)PlaceSetAnalyser.this.placePanel.getSelectedNodes();
/* 183 */       if (PlaceSetAnalyser.this.temp.isEmpty()) {
/*     */         return;
/*     */       }
/* 186 */       Out.println("maximal trap in place set:");
/* 187 */       Out.println(PlaceSetAnalyser.this.temp.toString());
/* 188 */       PlaceSetAnalyser.this.temp = PlaceSetAnalyser.this.temp.maxTrap();
/* 189 */       Out.println("is");
/* 190 */       Out.println(PlaceSetAnalyser.this.temp.toString());
/* 191 */       Out.println("======\n");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlaceSetAnalyser(PlaceTransitionNet pn) {
/* 201 */     setTitle("place set analyzer");
/* 202 */     setModal(true);
/* 203 */     this.pn = pn;
/* 204 */     this.trap.setEnabled(false);
/* 205 */     this.siphon.setEnabled(false);
/* 206 */     this.badSiphon.setEnabled(false);
/* 207 */     this.temp = new PlaceSet(pn.places());
/* 208 */     PlaceSet all = new PlaceSet(pn.places(), pn.places());
/* 209 */     String[] placeNames = all.getNameArray();
/* 210 */     this.placeList = new JList<>(placeNames);
/* 211 */     this.placeList.addListSelectionListener(new CustomListSelectionListener());
/* 212 */     getContentPane().setLayout(new BorderLayout());
/*     */     
/* 214 */     this.boxes.add(this.trap);
/* 215 */     this.boxes.add(this.siphon);
/* 216 */     this.boxes.add(this.badSiphon);
/* 217 */     this.boxes.add(this.maxTrap);
/* 218 */     this.maxTrap.addActionListener(new TrapActionListener());
/* 219 */     getContentPane().add(this.boxes, "South");
/* 220 */     this.placePanel = new NodeSetPanel(pn, false);
/* 221 */     this.placePanel.addListSelectionListener(new CustomListSelectionListener());
/* 222 */     getContentPane().add(this.placePanel);
/*     */     
/* 224 */     initMenuBar();
/*     */   }
/*     */ 
/*     */   
/*     */   private void initMenuBar() {
/* 229 */     JMenuBar bar = new JMenuBar();
/* 230 */     JMenu menu = new JMenu("Place Settings");
/* 231 */     final JRadioButtonMenuItem itemRadioNamesAndIds = new JRadioButtonMenuItem("Show name and id of places");
/* 232 */     final JRadioButtonMenuItem itemRadioNames = new JRadioButtonMenuItem("Show only name of places");
/* 233 */     final JRadioButtonMenuItem itemRadioIds = new JRadioButtonMenuItem("Show only id of places");
/*     */     
/* 235 */     ButtonGroup placeSettingsRadioButtonGroup = new ButtonGroup();
/* 236 */     placeSettingsRadioButtonGroup.add(itemRadioNamesAndIds);
/* 237 */     placeSettingsRadioButtonGroup.add(itemRadioNames);
/* 238 */     placeSettingsRadioButtonGroup.add(itemRadioIds);
/*     */     
/* 240 */     itemRadioNames.setSelected(true);
/*     */     
/* 242 */     ActionListener radioButtonSelectionListener = new ActionListener()
/*     */       {
/*     */         public void actionPerformed(ActionEvent e) {
/* 245 */           if (e.getSource() == itemRadioNamesAndIds) {
/* 246 */             PlaceSetAnalyser.this.placePanel.setPlaceNaming(true, true);
/* 247 */           } else if (e.getSource() == itemRadioNames) {
/* 248 */             PlaceSetAnalyser.this.placePanel.setPlaceNaming(true, false);
/* 249 */           } else if (e.getSource() == itemRadioIds) {
/* 250 */             PlaceSetAnalyser.this.placePanel.setPlaceNaming(false, true);
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 255 */     itemRadioNamesAndIds.addActionListener(radioButtonSelectionListener);
/* 256 */     itemRadioNames.addActionListener(radioButtonSelectionListener);
/* 257 */     itemRadioIds.addActionListener(radioButtonSelectionListener);
/*     */     
/* 259 */     menu.add(itemRadioNamesAndIds);
/* 260 */     menu.add(itemRadioNames);
/* 261 */     menu.add(itemRadioIds);
/*     */     
/* 263 */     bar.add(menu);
/*     */     
/* 265 */     setJMenuBar(bar);
/*     */   }
/*     */   
/*     */   public NodeSet getSelectedPlaces() {
/* 269 */     return (NodeSet)this.temp;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/PlaceSetAnalyser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */