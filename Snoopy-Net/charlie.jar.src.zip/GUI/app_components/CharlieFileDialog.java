/*     */ package GUI.app_components;
/*     */ 
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ public class CharlieFileDialog
/*     */   extends JPanel {
/*     */   private static final long serialVersionUID = 1L;
/*  14 */   private JTextField jTextField = null;
/*  15 */   private JButton jButton = null;
/*  16 */   private JLabel jLabel = null;
/*  17 */   private JList jListRecentFiles = null;
/*  18 */   private JLabel jLabel1 = null;
/*  19 */   private JButton jButtonOpenFile = null;
/*  20 */   private JButton jButtonReload = null;
/*  21 */   private JButton jButtonReplay = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharlieFileDialog() {
/*  27 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  36 */     this.jLabel1 = new JLabel();
/*  37 */     this.jLabel1.setBounds(new Rectangle(7, 126, 229, 24));
/*  38 */     this.jLabel1.setText("Recently opened Files:");
/*  39 */     this.jLabel = new JLabel();
/*  40 */     this.jLabel.setBounds(new Rectangle(10, 12, 278, 24));
/*  41 */     this.jLabel.setText("File to open:");
/*  42 */     setLayout((LayoutManager)null);
/*  43 */     setSize(300, 330);
/*  44 */     add(getJTextField(), (Object)null);
/*  45 */     add(getJButton(), (Object)null);
/*  46 */     add(this.jLabel, (Object)null);
/*  47 */     add(getJListRecentFiles(), (Object)null);
/*  48 */     add(this.jLabel1, (Object)null);
/*  49 */     add(getJButtonOpenFile(), (Object)null);
/*  50 */     add(getJButtonReload(), (Object)null);
/*  51 */     add(getJButtonReplay(), (Object)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JTextField getJTextField() {
/*  60 */     if (this.jTextField == null) {
/*  61 */       this.jTextField = new JTextField();
/*  62 */       this.jTextField.setBounds(new Rectangle(10, 35, 237, 25));
/*     */     } 
/*  64 */     return this.jTextField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButton() {
/*  73 */     if (this.jButton == null) {
/*  74 */       this.jButton = new JButton();
/*  75 */       this.jButton.setBounds(new Rectangle(247, 35, 40, 24));
/*  76 */       this.jButton.setText("Choose File");
/*     */     } 
/*  78 */     return this.jButton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JList getJListRecentFiles() {
/*  87 */     if (this.jListRecentFiles == null) {
/*  88 */       this.jListRecentFiles = new JList();
/*  89 */       this.jListRecentFiles.setBounds(new Rectangle(5, 152, 230, 140));
/*     */     } 
/*  91 */     return this.jListRecentFiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonOpenFile() {
/* 100 */     if (this.jButtonOpenFile == null) {
/* 101 */       this.jButtonOpenFile = new JButton();
/* 102 */       this.jButtonOpenFile.setBounds(new Rectangle(10, 60, 80, 25));
/* 103 */       this.jButtonOpenFile.setText("Open");
/*     */     } 
/* 105 */     return this.jButtonOpenFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonReload() {
/* 114 */     if (this.jButtonReload == null) {
/* 115 */       this.jButtonReload = new JButton();
/* 116 */       this.jButtonReload.setBounds(new Rectangle(91, 60, 80, 25));
/* 117 */       this.jButtonReload.setText("Reload");
/*     */     } 
/* 119 */     return this.jButtonReload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonReplay() {
/* 128 */     if (this.jButtonReplay == null) {
/* 129 */       this.jButtonReplay = new JButton();
/* 130 */       this.jButtonReplay.setBounds(new Rectangle(172, 60, 80, 25));
/* 131 */       this.jButtonReplay.setText("Replay");
/*     */     } 
/* 133 */     return this.jButtonReplay;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/CharlieFileDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */