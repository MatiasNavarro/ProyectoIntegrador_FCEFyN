/*     */ package GUI.app_components;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.TextFile;
/*     */ import charlie.pn.ResultManager;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.HyperlinkEvent;
/*     */ import javax.swing.event.HyperlinkListener;
/*     */ import javax.swing.text.html.HTMLDocument;
/*     */ import javax.swing.text.html.HTMLEditorKit;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StartDialog
/*     */   extends JDialog
/*     */   implements HyperlinkListener
/*     */ {
/*     */   private static final long serialVersionUID = -4229797706465879709L;
/*  37 */   JEditorPane pane = null;
/*  38 */   Component parent = null;
/*  39 */   public JPanel p = null;
/*  40 */   JScrollPane sp = null;
/*  41 */   TableLayout layout = null;
/*  42 */   String contentString = null;
/*  43 */   StartDialog thisDialog = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private int lastLinkClicked = -1;
/*     */ 
/*     */   
/*     */   public StartDialog(boolean showDialog, Component parent) {
/*  52 */     this.parent = parent;
/*  53 */     this.thisDialog = this;
/*  54 */     initialize(showDialog);
/*     */   }
/*     */ 
/*     */   
/*     */   public StartDialog(boolean showDialog) {
/*  59 */     this.thisDialog = this;
/*  60 */     initialize(showDialog);
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize(boolean showDialog) {
/*  65 */     JPanel contentPane = new JPanel();
/*  66 */     contentPane.setLayout(new BorderLayout());
/*  67 */     this.pane = new JEditorPane();
/*  68 */     this.pane.setEditable(false);
/*  69 */     this.pane.setEditorKit(new HTMLEditorKit());
/*  70 */     this.pane.addHyperlinkListener(this);
/*  71 */     this.p = new JPanel();
/*  72 */     double[][] size = { { -2.0D }, { -2.0D } };
/*  73 */     this.layout = new TableLayout(size);
/*  74 */     this.p.setLayout((LayoutManager)this.layout);
/*  75 */     contentPane.add(this.p, "Center");
/*  76 */     setContentPane(contentPane);
/*  77 */     this.p.add(this.pane, "0,0");
/*  78 */     setUndecorated(true);
/*     */     
/*  80 */     if (showDialog)
/*     */     {
/*  82 */       setVisible(true);
/*     */     }
/*  84 */     Dimension d = this.layout.preferredLayoutSize(this.p);
/*  85 */     this.p.setSize(d);
/*  86 */     this.p.setPreferredSize(d);
/*     */   }
/*     */   
/*     */   public void pack() {
/*  90 */     Dimension d = this.layout.preferredLayoutSize(this.p);
/*     */     
/*  92 */     Insets inset = Toolkit.getDefaultToolkit().getScreenInsets(getGraphicsConfiguration());
/*  93 */     Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
/*  94 */     screen.height = screen.height - inset.top - inset.bottom;
/*  95 */     screen.width = screen.width - inset.left - inset.right;
/*  96 */     if (d.height >= screen.height - 50) {
/*     */       
/*  98 */       this.layout.removeLayoutComponent(this.pane);
/*  99 */       this.layout.setRow(0, (screen.height - 50));
/* 100 */       this.sp = new JScrollPane();
/* 101 */       this.sp.setPreferredSize(d);
/* 102 */       this.sp.setSize(d);
/* 103 */       this.sp.setViewportView(this.pane);
/* 104 */       this.p.add(this.sp, "0,0");
/* 105 */       this.layout.invalidateLayout(this.p);
/*     */     }
/* 107 */     else if (this.sp != null) {
/* 108 */       this.layout.removeLayoutComponent(this.sp);
/* 109 */       this.sp = null;
/* 110 */       this.p.add(this.pane, "0,0");
/*     */     } 
/*     */     
/* 113 */     d = this.layout.preferredLayoutSize(this.p);
/* 114 */     this.p.setPreferredSize(d);
/* 115 */     this.p.setSize(d);
/* 116 */     this.p.invalidate();
/* 117 */     super.pack();
/*     */     
/* 119 */     Toolkit tKit = Toolkit.getDefaultToolkit();
/* 120 */     Dimension dim = tKit.getScreenSize();
/* 121 */     if (dim.getHeight() < 2.0D) dim.height = 100; 
/* 122 */     if (dim.getWidth() < 2.0D) dim.width = 100; 
/* 123 */     int y = (int)dim.getHeight() / 2 - getHeight() / 2;
/* 124 */     int x = (int)dim.getWidth() / 2 - getWidth() / 2;
/* 125 */     setLocation(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void showStartDialog(String additionalMessage) {
/* 130 */     StartDialog s = new StartDialog(false);
/* 131 */     s.setVisible(true);
/*     */   }
/*     */   
/*     */   public void setContent(File htmlFile) {
/* 135 */     if (htmlFile != null && htmlFile.exists()) {
/*     */       try {
/* 137 */         URL u = (new File(htmlFile.getParent())).toURI().toURL();
/*     */         
/* 139 */         getDocument().setBase(u);
/* 140 */       } catch (Exception e) {
/* 141 */         System.out.printf("could not retrieve URL from file %s \n", new Object[] { htmlFile.getName() });
/* 142 */         e.printStackTrace();
/*     */         
/*     */         return;
/*     */       } 
/* 146 */       this.contentString = TextFile.readTextFile(htmlFile);
/* 147 */       if (this.contentString != null) {
/*     */ 
/*     */         
/* 150 */         this.pane.setText(this.contentString);
/*     */       } else {
/* 152 */         DebugCounter.inc("StartDialog.setContent() cannot, set Content to panel! string = " + this.contentString);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendListToContent(String marker, String listTitle, String[] list) {
/* 160 */     if (marker == null || marker.length() == 0)
/* 161 */       return;  StringBuffer sb = new StringBuffer();
/* 162 */     int markerPos = this.contentString.indexOf(marker);
/* 163 */     int markerEndPos = markerPos + marker.length();
/* 164 */     if (markerPos >= 0) {
/* 165 */       sb.append(this.contentString.substring(0, markerPos));
/*     */     } else {
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 172 */     if (markerEndPos > 0 && markerEndPos < this.contentString.length()) {
/* 173 */       sb.append("<p>" + listTitle + "</p>\n");
/* 174 */       sb.append("<ul>\n");
/* 175 */       int count = 0;
/* 176 */       boolean opened = false;
/* 177 */       for (String s : list) {
/* 178 */         s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
/*     */ 
/*     */         
/* 181 */         if (opened && !s.startsWith("++ ")) {
/* 182 */           sb.append("</ul>");
/* 183 */           opened = false;
/*     */         } 
/*     */         
/* 186 */         if (s.equals(ResultManager.DESCRIPTION_SEPARATOR)) {
/* 187 */           sb.append("</ul><ul>");
/* 188 */         } else if (s.startsWith("** ")) {
/*     */           
/* 190 */           sb.append(String.format("<li><a style='color:#FFFFFF' href='#%d'>%s</a></li>\n", new Object[] {
/* 191 */                   Integer.valueOf(count), s
/* 192 */                   .replace("\n", "").replace("** ", "") }));
/* 193 */           count++;
/*     */         } else {
/* 195 */           if (!opened && s.startsWith("++ ")) {
/* 196 */             sb.append("<ul>");
/* 197 */             opened = true;
/*     */           } 
/*     */ 
/*     */           
/* 201 */           if (s.startsWith("++ ")) {
/* 202 */             s = s.replace("++ ", "");
/*     */           }
/*     */           
/* 205 */           sb.append(String.format("<li>%s</li>\n", new Object[] { s }));
/*     */         } 
/*     */       } 
/* 208 */       sb.append("</ul>\n");
/*     */ 
/*     */       
/* 211 */       sb.append(this.contentString.substring(markerEndPos, this.contentString.length()));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 216 */     this.pane.setText(sb.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HTMLDocument getDocument() {
/* 224 */     return (HTMLDocument)this.pane.getDocument();
/*     */   }
/*     */   
/*     */   public static void showClosableAbout(File htmlFile, Component parent) {
/* 228 */     StartDialog s = new StartDialog(false, parent);
/* 229 */     s.setContent(htmlFile);
/*     */     
/* 231 */     s.addCloseButton();
/* 232 */     s.pack();
/*     */     
/* 234 */     s.setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCloseButton() {
/* 239 */     JButton closeButton = new JButton(new AbstractAction("close")
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e) {
/* 254 */             StartDialog.this.thisDialog.setVisible(false);
/*     */           }
/*     */         });
/* 257 */     closeButton.setMnemonic(67);
/*     */     
/* 259 */     closeButton.setPreferredSize(new Dimension(100, 25));
/* 260 */     closeButton.setPreferredSize(closeButton.getPreferredSize());
/* 261 */     getContentPane().add(closeButton, "South");
/* 262 */     closeButton.setFocusable(true);
/* 263 */     closeButton.grabFocus();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void showStart(File htmlFile, String additionalMessage) {
/*     */     try {
/* 271 */       getDocument().setBase(new URL("file:/"));
/*     */       
/* 273 */       setContent(htmlFile);
/* 274 */     } catch (Exception e) {
/* 275 */       System.out.printf("could not retrieve URL from file %s \n", new Object[] { htmlFile.getName() });
/* 276 */       e.printStackTrace();
/*     */       return;
/*     */     } 
/* 279 */     JTextArea textArea = new JTextArea(additionalMessage);
/* 280 */     this.p.add(textArea, "0,1");
/* 281 */     pack();
/* 282 */     setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hyperlinkUpdate(HyperlinkEvent e) {
/* 309 */     if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
/* 310 */       int info = Integer.parseInt(e.getDescription().substring(1));
/*     */       
/* 312 */       if (info == this.lastLinkClicked) {
/* 313 */         appendListToContent("<!-- ruleList -->", "list of rules that can be applied", 
/* 314 */             ResultManager.getRuleDescriptions(-1));
/* 315 */         this.lastLinkClicked = -1;
/*     */       } else {
/* 317 */         appendListToContent("<!-- ruleList -->", "list of rules that can be applied", 
/* 318 */             ResultManager.getRuleDescriptions(info));
/* 319 */         this.lastLinkClicked = info;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/StartDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */