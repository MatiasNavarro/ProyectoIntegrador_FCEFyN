/*    */ package GUI.app_components;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.GridLayout;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTextField;
/*    */ 
/*    */ public class GuiFileDialog
/*    */   extends JPanel {
/* 12 */   JTextField TextFieldFileOpen = new JTextField(25);
/*    */   public GuiFileDialog() {
/* 14 */     super(new GridLayout(3, 1));
/*    */ 
/*    */     
/* 17 */     JPanel FirstPanel = new JPanel();
/* 18 */     FirstPanel.add(new JLabel("File Menu"));
/* 19 */     FirstPanel.add(new JLabel("up"));
/* 20 */     FirstPanel.add(new JLabel("down"));
/*    */     
/* 22 */     FirstPanel.setBackground(Color.green);
/* 23 */     add(FirstPanel);
/* 24 */     JPanel SecPanel = new JPanel();
/* 25 */     SecPanel.add(this.TextFieldFileOpen);
/* 26 */     SecPanel.add(new JButton("..."));
/* 27 */     SecPanel.setBackground(Color.blue);
/*    */ 
/*    */ 
/*    */     
/* 31 */     add(SecPanel);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 36 */     setVisible(true);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/GuiFileDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */