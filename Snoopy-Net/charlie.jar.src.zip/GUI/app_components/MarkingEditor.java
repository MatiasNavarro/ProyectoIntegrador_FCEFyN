/*     */ package GUI.app_components;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ public class MarkingEditor
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  18 */   private JComboBox jComboBoxMarkings = null;
/*  19 */   private JLabel jLabelMarkings = null;
/*  20 */   private JTable jTablePlaces = null;
/*  21 */   private JLabel jLabelPlaces = null;
/*  22 */   private JButton jButtonRememberMarking = null;
/*  23 */   private JLabel jLabelSaveMarkings = null;
/*  24 */   private JTextField jTextFieldSaveMarkings = null;
/*  25 */   private JButton jButtonSave = null;
/*  26 */   private JButton jButtonChooseFile = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkingEditor() {
/*  32 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  41 */     GridBagConstraints gridBagConstraints9 = new GridBagConstraints();
/*  42 */     gridBagConstraints9.gridx = 1;
/*  43 */     gridBagConstraints9.insets = new Insets(2, 0, 2, 5);
/*  44 */     gridBagConstraints9.gridy = 6;
/*  45 */     GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
/*  46 */     gridBagConstraints8.gridx = 0;
/*  47 */     gridBagConstraints8.fill = 2;
/*  48 */     gridBagConstraints8.insets = new Insets(0, 5, 0, 5);
/*  49 */     gridBagConstraints8.gridy = 7;
/*  50 */     GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
/*  51 */     gridBagConstraints7.fill = 1;
/*  52 */     gridBagConstraints7.gridy = 6;
/*  53 */     gridBagConstraints7.weightx = 1.0D;
/*  54 */     gridBagConstraints7.insets = new Insets(2, 5, 2, 5);
/*  55 */     gridBagConstraints7.gridx = 0;
/*  56 */     GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
/*  57 */     gridBagConstraints6.gridx = 0;
/*  58 */     gridBagConstraints6.fill = 2;
/*  59 */     gridBagConstraints6.insets = new Insets(0, 5, 0, 5);
/*  60 */     gridBagConstraints6.gridwidth = 2;
/*  61 */     gridBagConstraints6.gridy = 5;
/*  62 */     this.jLabelSaveMarkings = new JLabel();
/*  63 */     this.jLabelSaveMarkings.setText("Save Markings in File");
/*  64 */     GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
/*  65 */     gridBagConstraints5.gridx = 0;
/*  66 */     gridBagConstraints5.fill = 2;
/*  67 */     gridBagConstraints5.insets = new Insets(0, 5, 0, 5);
/*  68 */     gridBagConstraints5.gridwidth = 2;
/*  69 */     gridBagConstraints5.gridy = 4;
/*  70 */     GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
/*  71 */     gridBagConstraints4.gridx = 0;
/*  72 */     gridBagConstraints4.fill = 2;
/*  73 */     gridBagConstraints4.insets = new Insets(0, 5, 0, 5);
/*  74 */     gridBagConstraints4.gridwidth = 2;
/*  75 */     gridBagConstraints4.gridy = 2;
/*  76 */     this.jLabelPlaces = new JLabel();
/*  77 */     this.jLabelPlaces.setText("Places in the currently loaded net (use Tooltip!)");
/*  78 */     GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
/*  79 */     gridBagConstraints3.fill = 1;
/*  80 */     gridBagConstraints3.gridy = 3;
/*  81 */     gridBagConstraints3.weightx = 1.0D;
/*  82 */     gridBagConstraints3.weighty = 1.0D;
/*  83 */     gridBagConstraints3.insets = new Insets(0, 5, 0, 5);
/*  84 */     gridBagConstraints3.gridwidth = 2;
/*  85 */     gridBagConstraints3.gridx = 0;
/*  86 */     GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
/*  87 */     gridBagConstraints1.gridx = 0;
/*  88 */     gridBagConstraints1.fill = 2;
/*  89 */     gridBagConstraints1.insets = new Insets(0, 5, 0, 5);
/*  90 */     gridBagConstraints1.gridwidth = 2;
/*  91 */     gridBagConstraints1.gridy = 0;
/*  92 */     this.jLabelMarkings = new JLabel();
/*  93 */     this.jLabelMarkings.setText("Previously edited Markings");
/*  94 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*  95 */     gridBagConstraints.fill = 1;
/*  96 */     gridBagConstraints.gridy = 1;
/*  97 */     gridBagConstraints.weightx = 1.0D;
/*  98 */     gridBagConstraints.insets = new Insets(0, 5, 0, 5);
/*  99 */     gridBagConstraints.gridwidth = 2;
/* 100 */     gridBagConstraints.gridx = 0;
/* 101 */     setSize(300, 200);
/* 102 */     setPreferredSize(new Dimension(300, 200));
/* 103 */     setLayout(new GridBagLayout());
/* 104 */     add(getJComboBoxMarkings(), gridBagConstraints);
/* 105 */     add(this.jLabelMarkings, gridBagConstraints1);
/*     */     
/* 107 */     add(getJTablePlaces(), gridBagConstraints3);
/* 108 */     add(this.jLabelPlaces, gridBagConstraints4);
/* 109 */     add(getJButtonRememberMarking(), gridBagConstraints5);
/* 110 */     add(this.jLabelSaveMarkings, gridBagConstraints6);
/* 111 */     add(getJTextFieldSaveMarkings(), gridBagConstraints7);
/* 112 */     add(getJButtonSave(), gridBagConstraints8);
/* 113 */     add(getJButtonChooseFile(), gridBagConstraints9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JTable getJTablePlaces() {
/* 122 */     if (this.jTablePlaces == null) {
/* 123 */       String[] columnNames = { "Placename", "#-Token" };
/* 124 */       String[][] rows = { { "p1", "1" }, { "p2", "2" } };
/* 125 */       this.jTablePlaces = new JTable((Object[][])rows, (Object[])columnNames);
/*     */     } 
/*     */     
/* 128 */     return this.jTablePlaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JComboBox getJComboBoxMarkings() {
/* 139 */     if (this.jComboBoxMarkings == null) {
/* 140 */       this.jComboBoxMarkings = new JComboBox();
/*     */     }
/* 142 */     return this.jComboBoxMarkings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonRememberMarking() {
/* 151 */     if (this.jButtonRememberMarking == null) {
/* 152 */       this.jButtonRememberMarking = new JButton();
/* 153 */       this.jButtonRememberMarking.setText("Remember Marking");
/*     */     } 
/* 155 */     return this.jButtonRememberMarking;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JTextField getJTextFieldSaveMarkings() {
/* 164 */     if (this.jTextFieldSaveMarkings == null) {
/* 165 */       this.jTextFieldSaveMarkings = new JTextField();
/*     */     }
/* 167 */     return this.jTextFieldSaveMarkings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonSave() {
/* 176 */     if (this.jButtonSave == null) {
/* 177 */       this.jButtonSave = new JButton();
/* 178 */       this.jButtonSave.setText("Save Markings");
/*     */     } 
/* 180 */     return this.jButtonSave;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonChooseFile() {
/* 189 */     if (this.jButtonChooseFile == null) {
/* 190 */       this.jButtonChooseFile = new JButton();
/* 191 */       this.jButtonChooseFile.setText("...");
/*     */     } 
/* 193 */     return this.jButtonChooseFile;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/MarkingEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */