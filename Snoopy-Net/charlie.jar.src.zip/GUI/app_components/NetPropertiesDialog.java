/*     */ package GUI.app_components;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.FileDisplayDialog;
/*     */ import GUI.util.MyButton;
/*     */ import GUI.util.ResourceLoader;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.Initiator;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.analyzer.structural.StructuralAnalyzer;
/*     */ import charlie.analyzer.structural.StructuralOptionSet;
/*     */ import charlie.pn.Out;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Result;
/*     */ import charlie.pn.ResultContradictionException;
/*     */ import charlie.pn.ResultManager;
/*     */ import charlie.pn.Results;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Point;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.Popup;
/*     */ import javax.swing.PopupFactory;
/*     */ import javax.swing.border.LineBorder;
/*     */ import layout.TableLayout;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class NetPropertiesDialog extends JPanel implements Initiator {
/*  43 */   private static final Log LOG = LogFactory.getLog(NetPropertiesDialog.class);
/*     */   
/*  45 */   private Results results = new Results();
/*  46 */   private final ArrayList<DisplayedResults> resultList = new ArrayList<>();
/*  47 */   private PlaceTransitionNet pn = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private DisplayedResults displayedResults = null;
/*     */   
/*     */   private MyButton start;
/*     */   private MyButton end;
/*  56 */   private JLabel indexLabel = null; private MyButton backward; private MyButton forward;
/*     */   private static final long serialVersionUID = 1L;
/*  58 */   private JLabel[] labels = new JLabel[Results.getVisibleListSize()];
/*  59 */   private int width = 320;
/*  60 */   private int height = 150;
/*     */   
/*  62 */   private FileDisplayDialog dialog = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public static Color gray = Color.GRAY;
/*     */ 
/*     */ 
/*     */   
/*     */   private StartDialog helpDialog;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NetPropertiesDialog() {
/*  77 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Results getResults() {
/*  86 */     return ((DisplayedResults)this.resultList.get(this.resultList.size() - 1)).getResults();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  93 */     StructuralAnalyzer.register();
/*  94 */     ResultManager.initialize();
/*  95 */     double f = 59.0D;
/*  96 */     double[][] size = new double[2][];
/*  97 */     (new double[6])[0] = f; (new double[6])[1] = f; (new double[6])[2] = f; (new double[6])[3] = f; (new double[6])[4] = f; (new double[6])[5] = f; size[0] = new double[6];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     size[1] = new double[(int)Math.ceil(Results.getAmountOfResults() / 5.0D) * 2 + 2 + 1];
/*     */     
/* 105 */     size[1][0] = 5.0D;
/* 106 */     size[1][(size[1]).length - 1] = 5.0D;
/* 107 */     for (int i = 1; i < (size[1]).length - 1; i++) {
/* 108 */       if (i % 2 == 0) {
/* 109 */         size[1][i] = 25.0D;
/*     */       } else {
/* 111 */         size[1][i] = 2.0D;
/*     */       } 
/*     */     } 
/*     */     
/* 115 */     TableLayout layout = new TableLayout(size);
/*     */     
/* 117 */     int row = 0;
/* 118 */     Dimension d = new Dimension(56, 25);
/* 119 */     this.resultList.add(new DisplayedResults(this.results, 0));
/* 120 */     setLayout((LayoutManager)layout);
/* 121 */     setSize(this.width, this.height);
/* 122 */     setPreferredSize(new Dimension(this.width, this.height));
/* 123 */     gray = getBackground();
/*     */     
/* 125 */     int count = 0;
/* 126 */     for (String key : Results.getVisibleList()) {
/* 127 */       if (count % 5 == 0)
/*     */       {
/*     */         
/* 130 */         row += 2;
/*     */       }
/*     */       
/* 133 */       this.labels[count] = new ResultLabel(Results.getResultString(key));
/* 134 */       this.labels[count].setToolTipText(Results.getTooltipText(key));
/* 135 */       this.labels[count].setOpaque(true);
/* 136 */       this.labels[count].setSize(d);
/* 137 */       this.labels[count].setPreferredSize(d);
/* 138 */       this.labels[count].setBackground(gray);
/* 139 */       this.labels[count].setBorder(new LineBorder(Color.LIGHT_GRAY));
/* 140 */       this.labels[count].addMouseListener(new DescriptionMouseListener(Results.getDescription(key)));
/* 141 */       String pos = Integer.toString(count % 5) + "," + Integer.toString(row) + ",C,C";
/* 142 */       add(this.labels[count], pos);
/*     */       
/* 144 */       count++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 149 */     row += 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     add(getPlayPanel(), "0," + row + ",5," + row);
/* 156 */     layout.insertColumn(0, 5.0D);
/* 157 */     layout.insertColumn(7, 5.0D);
/* 158 */     displayResults(this.results);
/*     */   }
/*     */   
/*     */   private JPanel getPlayPanel() {
/* 162 */     JPanel p = new JPanel();
/* 163 */     double[][] size = { { 10.0D, 30.0D, 30.0D, 30.0D, 30.0D, -2.0D, 5.0D, 90.0D, 30.0D, 10.0D }, { 25.0D } };
/*     */ 
/*     */     
/* 166 */     TableLayout layout = new TableLayout(size);
/* 167 */     p.setLayout((LayoutManager)layout);
/* 168 */     p.setBackground(gray);
/*     */     
/* 170 */     this.start = new MyButton(ResourceLoader.getURL("resources/start.png"), "go to the first resultset")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e) {
/* 173 */           if (!isEnabled()) {
/*     */             return;
/*     */           }
/* 176 */           if (NetPropertiesDialog.this.resultList.size() > 0) {
/* 177 */             NetPropertiesDialog.this.displayedResults = NetPropertiesDialog.this.resultList.get(0);
/* 178 */             NetPropertiesDialog.this.displayResults(NetPropertiesDialog.this.displayedResults.getResults());
/*     */             
/* 180 */             NetPropertiesDialog.this.updateOutputWindow();
/*     */             
/* 182 */             NetPropertiesDialog.this.backward.setEnabled(false);
/* 183 */             NetPropertiesDialog.this.start.setEnabled(false);
/* 184 */             NetPropertiesDialog.this.forward.setEnabled(true);
/* 185 */             NetPropertiesDialog.this.end.setEnabled(true);
/*     */           } 
/*     */         }
/*     */       };
/* 189 */     p.add((Component)this.start, "1,0");
/* 190 */     this.backward = new MyButton(ResourceLoader.getURL("resources/backward.png"), "go a step backwards in resultset")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e) {
/* 193 */           if (!isEnabled()) {
/*     */             return;
/*     */           }
/* 196 */           if (NetPropertiesDialog.this.displayedResults == null) {
/* 197 */             NetPropertiesDialog.this.displayedResults = NetPropertiesDialog.this.resultList.get(NetPropertiesDialog.this.resultList.size() - 1);
/*     */           }
/* 199 */           int index = NetPropertiesDialog.this.resultList.indexOf(NetPropertiesDialog.this.displayedResults);
/* 200 */           if (index > 0) {
/* 201 */             index--;
/* 202 */             NetPropertiesDialog.this.displayedResults = NetPropertiesDialog.this.resultList.get(index);
/* 203 */             DebugCounter.inc("backward index = " + Integer.toString(index));
/* 204 */             NetPropertiesDialog.this.displayResults(NetPropertiesDialog.this.displayedResults.getResults());
/*     */             
/* 206 */             NetPropertiesDialog.this.updateOutputWindow();
/*     */             
/* 208 */             NetPropertiesDialog.this.forward.setEnabled(true);
/* 209 */             NetPropertiesDialog.this.end.setEnabled(true);
/* 210 */           } else if (index == 0) {
/* 211 */             NetPropertiesDialog.this.start.mouseClicked(e);
/*     */           } 
/*     */         }
/*     */       };
/* 215 */     p.add((Component)this.backward, "2,0");
/* 216 */     this.forward = new MyButton(ResourceLoader.getURL("resources/forward.png"), "go a step ahead in resultset")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e) {
/* 219 */           if (!isEnabled()) {
/*     */             return;
/*     */           }
/* 222 */           if (NetPropertiesDialog.this.displayedResults == null) {
/* 223 */             NetPropertiesDialog.this.displayedResults = NetPropertiesDialog.this.resultList.get(NetPropertiesDialog.this.resultList.size() - 1);
/*     */           }
/* 225 */           int index = NetPropertiesDialog.this.resultList.indexOf(NetPropertiesDialog.this.displayedResults);
/* 226 */           if (index < NetPropertiesDialog.this.resultList.size() - 1) {
/* 227 */             index++;
/* 228 */             NetPropertiesDialog.this.displayedResults = NetPropertiesDialog.this.resultList.get(index);
/* 229 */             DebugCounter.inc("forward index = " + 
/* 230 */                 Integer.toString(index));
/*     */             
/* 232 */             NetPropertiesDialog.this.displayResults(NetPropertiesDialog.this.displayedResults.getResults());
/*     */             
/* 234 */             NetPropertiesDialog.this.updateOutputWindow();
/*     */             
/* 236 */             NetPropertiesDialog.this.backward.setEnabled(true);
/* 237 */             NetPropertiesDialog.this.start.setEnabled(true);
/* 238 */           } else if (index == NetPropertiesDialog.this.resultList.size() - 1) {
/*     */             
/* 240 */             NetPropertiesDialog.this.end.mouseClicked(e);
/*     */           } 
/*     */         }
/*     */       };
/* 244 */     p.add((Component)this.forward, "3,0");
/* 245 */     this.end = new MyButton(ResourceLoader.getURL("resources/end.png"), "go to the last resultset")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e) {
/* 248 */           if (!isEnabled()) {
/*     */             return;
/*     */           }
/* 251 */           if (NetPropertiesDialog.this.resultList.size() > 0) {
/* 252 */             NetPropertiesDialog.this.displayedResults = NetPropertiesDialog.this.resultList.get(NetPropertiesDialog.this.resultList.size() - 1);
/* 253 */             NetPropertiesDialog.this.displayResults(NetPropertiesDialog.this.displayedResults.getResults());
/*     */             
/* 255 */             NetPropertiesDialog.this.updateOutputWindow();
/*     */             
/* 257 */             NetPropertiesDialog.this.backward.setEnabled(true);
/* 258 */             NetPropertiesDialog.this.start.setEnabled(true);
/* 259 */             NetPropertiesDialog.this.forward.setEnabled(false);
/* 260 */             NetPropertiesDialog.this.end.setEnabled(false);
/*     */           } 
/*     */         }
/*     */       };
/* 264 */     p.add((Component)this.end, "4,0");
/* 265 */     this.indexLabel = new JLabel("0(0)");
/* 266 */     p.add(this.indexLabel, "5,0");
/* 267 */     MyButton showOutput = new MyButton(ResourceLoader.getURL("resources/output.png"), "shows the output belonging to the displayed result set")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e) {
/* 270 */           if (NetPropertiesDialog.this.displayedResults != null) {
/* 271 */             if (NetPropertiesDialog.this.dialog == null) {
/* 272 */               NetPropertiesDialog.this.dialog = new FileDisplayDialog(NetPropertiesDialog.this.displayedResults.getResults().getOutput() + "\n\nResults:\n" + NetPropertiesDialog.this
/*     */                   
/* 274 */                   .displayedResults.getResults().toStringOnlySet(), "Output of analysis");
/*     */             } else {
/*     */               
/* 277 */               NetPropertiesDialog.this.dialog.setVisible(!NetPropertiesDialog.this.dialog.isValid());
/*     */             } 
/*     */           }
/*     */         }
/*     */       };
/*     */     
/* 283 */     showOutput.setPreferredSize(new Dimension(90, 25));
/* 284 */     showOutput.setSize(showOutput.getPreferredSize());
/*     */     
/* 286 */     p.add((Component)showOutput, "7,0");
/* 287 */     MyButton helpButton = new MyButton(ResourceLoader.getURL("resources/help.png"), "show net properties help dialog")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e)
/*     */         {
/* 291 */           File helpFile = null;
/* 292 */           URL url = null;
/*     */           
/*     */           try {
/* 295 */             helpFile = new File("resources" + System.getProperty("file.separator") + "help_net_properties.html");
/*     */             
/* 297 */             if (!helpFile.exists()) {
/* 298 */               url = ResourceLoader.getURL("resources/help_net_properties.html");
/* 299 */               DebugCounter.inc("helpFile url:" + url.toString());
/* 300 */               URI uri = url.toURI();
/* 301 */               DebugCounter.inc("helpFile uri:" + uri.toString());
/* 302 */               helpFile = new File(uri);
/*     */             } 
/* 304 */           } catch (Exception ex) {
/* 305 */             NetPropertiesDialog.LOG.error(ex.getMessage(), ex);
/* 306 */             String fileName = url.toString();
/* 307 */             fileName = fileName.substring("jar:file:/".length());
/* 308 */             fileName = fileName.replace("charlie.jar!/", "");
/* 309 */             DebugCounter.inc("fileName : " + fileName);
/*     */             
/*     */             try {
/* 312 */               URI uri = new URI("file:/" + fileName);
/* 313 */               helpFile = new File(uri);
/* 314 */               if (!helpFile.exists()) {
/* 315 */                 NetPropertiesDialog.LOG.error("Sorry cannot find help file, see log file for error description.");
/* 316 */                 JOptionPane.showMessageDialog(null, "Sorry cannot find help file, see log file for error description.");
/*     */ 
/*     */                 
/*     */                 return;
/*     */               } 
/* 321 */             } catch (Exception ex2) {
/* 322 */               NetPropertiesDialog.LOG.error(ex2.getMessage(), ex2);
/*     */               return;
/*     */             } 
/*     */           } 
/* 326 */           if (helpFile != null && helpFile.exists()) {
/* 327 */             if (NetPropertiesDialog.this.helpDialog == null) {
/* 328 */               NetPropertiesDialog.this.helpDialog = new StartDialog(false, (Component)this);
/* 329 */               NetPropertiesDialog.this.helpDialog.setTitle("brief help");
/* 330 */               NetPropertiesDialog.this.helpDialog.setContent(helpFile);
/* 331 */               NetPropertiesDialog.this.helpDialog.appendListToContent("<!-- ruleList -->", "list of rules that can be applied", 
/* 332 */                   ResultManager.getRuleDescriptions());
/* 333 */               NetPropertiesDialog.this.helpDialog.addCloseButton();
/* 334 */               NetPropertiesDialog.this.helpDialog.setModal(false);
/* 335 */               NetPropertiesDialog.this.helpDialog.setUndecorated(false);
/* 336 */               NetPropertiesDialog.this.helpDialog.pack();
/*     */             } 
/*     */             
/* 339 */             NetPropertiesDialog.this.helpDialog.setVisible(!NetPropertiesDialog.this.helpDialog.isVisible());
/*     */           } 
/*     */         }
/*     */       };
/* 343 */     p.add((Component)helpButton, "8,0,C,C");
/*     */     
/* 345 */     Dimension d = layout.preferredLayoutSize(p);
/* 346 */     p.setSize(d);
/* 347 */     p.setPreferredSize(d);
/* 348 */     setPlayButtonsEnabled(false);
/* 349 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateOutputWindow() {
/* 356 */     if (this.displayedResults != null && this.dialog != null) {
/* 357 */       this.dialog.updateText(this.displayedResults.getResults().getOutput() + "\n\nResults:\n" + this.displayedResults
/*     */           
/* 359 */           .getResults().toStringOnlySet());
/*     */     }
/*     */   }
/*     */   
/*     */   private void setPlayButtonsEnabled(boolean b) {
/* 364 */     this.start.setEnabled(b);
/* 365 */     this.end.setEnabled(b);
/* 366 */     this.forward.setEnabled(b);
/* 367 */     this.backward.setEnabled(b);
/*     */   }
/*     */   
/*     */   public void setPN(PlaceTransitionNet pn) {
/* 371 */     if (pn != null) {
/*     */       
/* 373 */       DebugCounter.inc("NetPropertiesDialog.setNet()");
/* 374 */       this.pn = pn;
/* 375 */       this.results = new Results();
/* 376 */       this.resultList.clear();
/* 377 */       this.resultList.add(new DisplayedResults(this.results));
/*     */ 
/*     */ 
/*     */       
/* 381 */       int count = 0;
/* 382 */       for (String key : Results.getVisibleList()) {
/* 383 */         this.labels[count].setText(Results.getResultString(key));
/* 384 */         this.labels[count].setToolTipText(Results.getTooltipText(key));
/* 385 */         this.labels[count].setBorder(new LineBorder(Color.LIGHT_GRAY));
/*     */         
/* 387 */         count++;
/*     */       } 
/* 389 */       AnalyzerManagerFactory.getAnalyzerManager().compute(this.pn, this.pn, (OptionSet)new StructuralOptionSet(), this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getResultTable() {
/* 394 */     return this.results.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void netUpdated(String message) {
/* 400 */     DebugCounter.inc("NetPropertiesDialog.netUpdated()");
/* 401 */     Results newLastResults = new Results();
/* 402 */     newLastResults.appendOutput(message);
/* 403 */     this.resultList.add(new DisplayedResults(newLastResults));
/* 404 */     this.results = newLastResults;
/*     */     
/* 406 */     AnalyzerManagerFactory.getAnalyzerManager().compute(this.pn, this.pn, (OptionSet)new StructuralOptionSet(), this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void analyzerHasFinished(Analyzer finished) {
/* 411 */     LOG.debug("update");
/* 412 */     Out.println("Structural Analysis Results:\n" + finished.getResults().toString());
/* 413 */     update(finished.getResults());
/*     */   }
/*     */   
/*     */   private void updatePlayControls() {
/* 417 */     if (this.displayedResults != null) {
/* 418 */       int index = this.resultList.indexOf(this.displayedResults);
/* 419 */       setPlayButtonsEnabled(true);
/* 420 */       if (index == 0) {
/* 421 */         this.backward.setEnabled(false);
/* 422 */         this.start.setEnabled(false);
/*     */       } 
/* 424 */       if (index == this.resultList.size() - 1) {
/* 425 */         this.forward.setEnabled(false);
/* 426 */         this.end.setEnabled(false);
/*     */       } 
/* 428 */       if (index == 0 && index == this.resultList.size() - 1) {
/* 429 */         setPlayButtonsEnabled(false);
/*     */       }
/* 431 */       this.indexLabel.setText("" + Integer.toString(index + 1) + " (" + 
/* 432 */           Integer.toString(this.resultList.size()) + ")");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(Results rs) {
/* 441 */     this.displayedResults = new DisplayedResults(rs, this.resultList.size() - 1);
/*     */     
/* 443 */     Results tempresults = new Results();
/* 444 */     tempresults.mergeWith(this.results);
/*     */     
/*     */     try {
/* 447 */       tempresults.mergeWithCheckForContradiction(rs);
/*     */       
/* 449 */       Results appliedResults = ResultManager.applyRules(tempresults, this.pn);
/* 450 */       if (appliedResults != null) {
/* 451 */         DebugCounter.inc("Applied results: " + appliedResults.toString());
/*     */         
/* 453 */         rs.mergeWith(appliedResults);
/* 454 */         Out.println("AppliedResults output:\n" + appliedResults.getOutput());
/* 455 */         Out.println(appliedResults.toString());
/* 456 */         this.displayedResults = new DisplayedResults(rs, this.resultList.size() - 1);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 461 */       this.results.mergeWithCheckForContradiction(rs);
/* 462 */     } catch (ResultContradictionException e) {
/* 463 */       LOG.error(e.getMessage(), (Throwable)e);
/* 464 */       JOptionPane.showMessageDialog(getParent(), 
/* 465 */           String.format("The rule contradicts a previously set result.%n%s%nThe results are not applied.", new Object[] { e.getMessage() }), "Contradiction in the Rule Set!", 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 471 */     this.resultList.add(this.resultList.size() - 1, this.displayedResults);
/*     */     
/* 473 */     displayResults(rs);
/*     */   }
/*     */ 
/*     */   
/*     */   private void displayResults(Results results) {
/* 478 */     if (results != null) {
/* 479 */       this.indexLabel.setText("" + (this.resultList.indexOf(results) + 1) + " (" + 
/* 480 */           Integer.toString(this.resultList.size()) + ")");
/*     */       
/* 482 */       int counter = 0;
/* 483 */       for (String key : Results.getVisibleList()) {
/* 484 */         Result r = results.getResult(key);
/* 485 */         this.labels[counter].setForeground(Color.BLACK);
/* 486 */         if (r != null) {
/*     */ 
/*     */           
/* 489 */           this.labels[counter].setToolTipText(String.format("%s (%s)", new Object[] { Results.getTooltipText(key), r.toString() }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 496 */           switch (r.getType()) {
/*     */             case 0:
/* 498 */               this.labels[counter].setText(Results.getResultString(key) + "(" + r.getValue() + ")");
/* 499 */               if (counter == 22) {
/* 500 */                 if (Integer.parseInt(r.getValue()) == 0) {
/* 501 */                   this.labels[counter].setBackground(Color.GREEN);
/* 502 */                   this.labels[counter].setBorder(new LineBorder(Color.GREEN)); break;
/*     */                 } 
/* 504 */                 this.labels[counter].setBackground(Color.RED);
/* 505 */                 this.labels[counter].setBorder(new LineBorder(Color.RED));
/*     */                 break;
/*     */               } 
/* 508 */               this.labels[counter].setBackground(Color.YELLOW);
/* 509 */               this.labels[counter].setBorder(new LineBorder(Color.YELLOW));
/*     */               break;
/*     */             
/*     */             case 2:
/* 513 */               this.labels[counter].setText(Results.getResultString(key) + "(" + r
/* 514 */                   .getValue() + ")");
/* 515 */               this.labels[counter].setBackground(Color.YELLOW);
/*     */               break;
/*     */             case 1:
/* 518 */               if (r.getValue().equals(" Y ")) {
/* 519 */                 this.labels[counter].setBackground(Color.GREEN);
/* 520 */                 this.labels[counter].setBorder(new LineBorder(Color.GREEN)); break;
/*     */               } 
/* 522 */               this.labels[counter].setBackground(Color.RED);
/* 523 */               this.labels[counter].setBorder(new LineBorder(Color.RED));
/*     */               break;
/*     */ 
/*     */             
/*     */             default:
/* 528 */               this.labels[counter].setBackground(gray);
/*     */               break;
/*     */           } 
/*     */         } else {
/* 532 */           this.labels[counter].setBackground(gray);
/* 533 */           this.labels[counter].setForeground(gray.darker());
/*     */         } 
/*     */         
/* 536 */         counter++;
/*     */       } 
/* 538 */       updatePlayControls();
/* 539 */       updateOutputWindow();
/*     */     } else {
/* 541 */       DebugCounter.inc("NetPropertiesDialog.displayResults( null )");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DisplayedResults
/*     */   {
/* 552 */     private static int MAX_INDEX = 0;
/*     */     
/*     */     private final Results results;
/*     */     private final int index;
/*     */     
/*     */     public DisplayedResults(Results _results, int _index) {
/* 558 */       this.results = _results;
/* 559 */       this.index = _index;
/*     */ 
/*     */       
/* 562 */       if (this.index == 0) {
/* 563 */         MAX_INDEX = 0;
/* 564 */       } else if (this.index >= MAX_INDEX) {
/* 565 */         MAX_INDEX = this.index + 1;
/*     */       } 
/*     */     }
/*     */     
/*     */     public DisplayedResults(Results _results) {
/* 570 */       this.results = _results;
/* 571 */       this.index = MAX_INDEX;
/* 572 */       MAX_INDEX++;
/*     */     }
/*     */     
/*     */     public Results getResults() {
/* 576 */       return this.results;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 581 */       int prime = 31;
/* 582 */       int result = 1;
/* 583 */       result = 31 * result + this.index;
/*     */       
/* 585 */       result = 31 * result + ((this.results == null) ? 0 : this.results.hashCode());
/* 586 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 591 */       if (this == obj) {
/* 592 */         return true;
/*     */       }
/* 594 */       if (obj == null) {
/* 595 */         return false;
/*     */       }
/* 597 */       if (getClass() != obj.getClass()) {
/* 598 */         return false;
/*     */       }
/* 600 */       DisplayedResults other = (DisplayedResults)obj;
/* 601 */       if (this.index != other.index) {
/* 602 */         return false;
/*     */       }
/* 604 */       if (this.results == null) {
/* 605 */         if (other.results != null) {
/* 606 */           return false;
/*     */         }
/* 608 */       } else if (!this.results.equals(other.results)) {
/* 609 */         return false;
/*     */       } 
/* 611 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DescriptionMouseListener
/*     */     extends MouseAdapter
/*     */   {
/*     */     private final String description;
/*     */ 
/*     */     
/* 624 */     private Popup popup = null;
/*     */ 
/*     */ 
/*     */     
/* 628 */     private static final Color BACKGROUND = new Color(208, 205, 255);
/*     */     
/*     */     public DescriptionMouseListener(String _description) {
/* 631 */       this.description = _description;
/*     */     }
/*     */ 
/*     */     
/*     */     public void mousePressed(MouseEvent _e) {
/* 636 */       JLabel label = (JLabel)_e.getSource();
/* 637 */       JLabel descriptionLabel = new JLabel(this.description);
/* 638 */       descriptionLabel.setBackground(BACKGROUND);
/* 639 */       descriptionLabel.setOpaque(true);
/* 640 */       descriptionLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
/*     */       
/* 642 */       int width = descriptionLabel.getFontMetrics(descriptionLabel.getFont()).stringWidth(this.description);
/*     */       
/* 644 */       int x = _e.getXOnScreen() - Math.round(width / 2.0F);
/* 645 */       int y = _e.getYOnScreen() + 20;
/*     */       
/* 647 */       double screenWidth = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
/*     */ 
/*     */       
/* 650 */       int diff = (int)Math.ceil(screenWidth - x - width);
/* 651 */       if (diff <= 0)
/*     */       {
/* 653 */         x += diff - 10;
/*     */       }
/* 655 */       if (x < 0) {
/* 656 */         x = 10;
/*     */       }
/*     */       
/* 659 */       this.popup = PopupFactory.getSharedInstance().getPopup(label, descriptionLabel, x, y);
/* 660 */       this.popup.show();
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseReleased(MouseEvent _e) {
/* 665 */       this.popup.hide();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ResultLabel
/*     */     extends JLabel
/*     */   {
/*     */     public ResultLabel(String _resultText) {
/* 678 */       super(_resultText, 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Point getToolTipLocation(MouseEvent _e) {
/* 691 */       int width = getFontMetrics(getFont()).stringWidth(getToolTipText());
/*     */       
/* 693 */       return new Point(_e.getX() - Math.round(width / 2.0F), _e.getY() + 20);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/NetPropertiesDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */