/*     */ package GUI.app_components;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.io.FileSaver;
/*     */ import GUI.preference.FilterFactory;
/*     */ import GUI.preference.SiphonTrapFilterPreference;
/*     */ import GUI.util.ExportButtonPanel;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.analyzer.deadlock.DeadlockAnalyzer;
/*     */ import charlie.analyzer.deadlock.DeadlockOptions;
/*     */ import charlie.analyzer.deadlock.DeadlockSet;
/*     */ import charlie.analyzer.invariant.InvParser;
/*     */ import charlie.analyzer.invariant.PInvariantSet;
/*     */ import charlie.analyzer.trap.Trap;
/*     */ import charlie.analyzer.trap.TrapAnalyzer;
/*     */ import charlie.analyzer.trap.TrapOptions;
/*     */ import charlie.pn.Out;
/*     */ import charlie.pn.PlaceSet;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.util.HashSet;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ public class DeadlockTrapComputationDialog
/*     */   extends ComputationalDialog {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   private JRadioButton jRadioDeadlock = null;
/*  42 */   private JRadioButton jRadioTraps = null;
/*  43 */   private JCheckBox jCheckTrapProperSets = new JCheckBox("proper sets");
/*  44 */   private JCheckBox jCheckDeadlockProperSets = new JCheckBox("proper sets");
/*     */ 
/*     */ 
/*     */   
/*  48 */   private JRadioButton jRadioDTP = new JRadioButton("stp");
/*     */ 
/*     */ 
/*     */   
/*  52 */   private JRadioButton jRadioCheckSiphon = new JRadioButton("compute all");
/*     */   
/*  54 */   private JCheckBox jCheckBadSiphons = new JCheckBox("bad siphons");
/*  55 */   private JCheckBox jCheckSoundSiphons = new JCheckBox("sound siphons");
/*  56 */   private ExportButtonPanel trapExport = null;
/*  57 */   private ExportButtonPanel deadlockExport = null;
/*  58 */   private JButton showPlaceSetAnalyzer = null;
/*  59 */   private JButton buttonCompute = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeadlockTrapComputationDialog(IDirector director) {
/*  65 */     super(director);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() {
/*  73 */     double p = -2.0D;
/*  74 */     double[][] size = { { 5.0D, 122.0D, 5.0D, 165.0D, 5.0D }, { 5.0D, p, p, p, p, p, p, p, p, p, 5.0D } };
/*  75 */     TableLayout layout = new TableLayout(size);
/*  76 */     setLayout((LayoutManager)layout);
/*  77 */     createTrapPanel();
/*  78 */     createDeadlockPanel();
/*  79 */     ButtonGroup g = new ButtonGroup();
/*  80 */     g.add(this.jRadioDeadlock);
/*  81 */     g.add(this.jRadioTraps);
/*  82 */     this.jRadioTraps.setSelected(false);
/*  83 */     this.jRadioDeadlock.setSelected(true);
/*  84 */     enableTrapControls(true);
/*  85 */     createPlaceSetAnalyzerButton();
/*  86 */     createComputeButton();
/*  87 */     Dimension d = layout.preferredLayoutSize(this);
/*  88 */     setSize(d);
/*  89 */     setPreferredSize(d);
/*  90 */     enableControls(false);
/*  91 */     this.jRadioDeadlock.setEnabled(false);
/*  92 */     this.jRadioTraps.setEnabled(false);
/*     */ 
/*     */     
/*  95 */     DeadlockAnalyzer.register();
/*  96 */     TrapAnalyzer.register();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handlePlaceTransitionNetNull() {
/* 101 */     this.jRadioDeadlock.setEnabled(false);
/* 102 */     this.jRadioTraps.setEnabled(false);
/* 103 */     enableControls(false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handlePlaceTransitionNetNotNull() {
/* 108 */     this.deadlockExport.setSuggestedFileName(getPN().getName() + "_DLS.res");
/* 109 */     this.trapExport.setSuggestedFileName(getPN().getName() + "_TPS.res");
/* 110 */     enableControls(true);
/* 111 */     this.jRadioDeadlock.setEnabled(true);
/* 112 */     this.jRadioTraps.setEnabled(true);
/*     */   }
/*     */   
/*     */   public void enableTrapControls(boolean b) {
/* 116 */     this.trapExport.setEnabled(b);
/* 117 */     this.jCheckTrapProperSets.setEnabled(b);
/*     */   }
/*     */   
/*     */   public void enableDeadlockControls(boolean b) {
/* 121 */     if (b) {
/* 122 */       if (this.jRadioDTP.isSelected()) {
/* 123 */         enableSTPControls(true);
/* 124 */         enableCheckControls(false);
/* 125 */       } else if (this.jRadioCheckSiphon.isSelected()) {
/* 126 */         enableSTPControls(false);
/* 127 */         enableCheckControls(true);
/*     */       } 
/*     */     } else {
/* 130 */       this.jCheckBadSiphons.setEnabled(b);
/* 131 */       this.jCheckSoundSiphons.setEnabled(b);
/* 132 */       this.jCheckDeadlockProperSets.setEnabled(b);
/*     */     } 
/*     */ 
/*     */     
/* 136 */     this.deadlockExport.setEnabled(b);
/* 137 */     this.jRadioDTP.setEnabled(b);
/* 138 */     this.jRadioCheckSiphon.setEnabled(b);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void enableSTPControls(boolean _b) {}
/*     */ 
/*     */   
/*     */   private void enableCheckControls(boolean _b) {
/* 147 */     this.jCheckDeadlockProperSets.setEnabled(_b);
/* 148 */     this.jCheckBadSiphons.setEnabled(_b);
/* 149 */     this.jCheckSoundSiphons.setEnabled(_b);
/*     */   }
/*     */ 
/*     */   
/*     */   private void createDeadlockPanel() {
/* 154 */     this.jRadioDeadlock = new JRadioButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 161 */             JRadioButton c = (JRadioButton)e.getSource();
/* 162 */             boolean value = c.isSelected();
/* 163 */             DeadlockTrapComputationDialog.this.enableTrapControls(!value);
/* 164 */             DeadlockTrapComputationDialog.this.enableDeadlockControls(value);
/* 165 */             if (value || DeadlockTrapComputationDialog.this.jRadioTraps.isSelected()) {
/* 166 */               DeadlockTrapComputationDialog.this.buttonCompute.setEnabled(true);
/*     */             } else {
/* 168 */               DeadlockTrapComputationDialog.this.buttonCompute.setEnabled(false);
/*     */             } 
/*     */           }
/*     */         });
/* 172 */     add(this.jRadioDeadlock, "1,3");
/*     */     
/* 174 */     this.deadlockExport = new ExportButtonPanel("export siphons", "dl", 165);
/* 175 */     this.deadlockExport.setEnabled(false);
/* 176 */     add((Component)this.deadlockExport, "3,3");
/*     */ 
/*     */     
/* 179 */     this.jRadioDTP.setEnabled(false);
/* 180 */     this.jRadioDTP.setSelected(true);
/* 181 */     this.jRadioDTP.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 184 */             if (DeadlockTrapComputationDialog.this.jRadioDTP.isSelected()) {
/* 185 */               DeadlockTrapComputationDialog.this.enableSTPControls(true);
/* 186 */               DeadlockTrapComputationDialog.this.enableCheckControls(false);
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 191 */     this.jRadioCheckSiphon.setEnabled(false);
/* 192 */     this.jRadioCheckSiphon.setSelected(false);
/* 193 */     this.jRadioCheckSiphon.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 196 */             if (DeadlockTrapComputationDialog.this.jRadioCheckSiphon.isSelected()) {
/* 197 */               DeadlockTrapComputationDialog.this.enableSTPControls(false);
/* 198 */               DeadlockTrapComputationDialog.this.enableCheckControls(true);
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 203 */     this.jCheckBadSiphons.setToolTipText("enable to compute bad siphons only");
/* 204 */     this.jCheckBadSiphons.setEnabled(false);
/* 205 */     this.jCheckBadSiphons.setSelected(false);
/*     */     
/* 207 */     this.jCheckSoundSiphons.setToolTipText("enable to compute sound siphons only");
/* 208 */     this.jCheckSoundSiphons.setEnabled(false);
/* 209 */     this.jCheckSoundSiphons.setSelected(false);
/*     */     
/* 211 */     add(this.jRadioDTP, "1,4");
/*     */     
/* 213 */     add(this.jRadioCheckSiphon, "1,5");
/*     */     
/* 215 */     this.jCheckDeadlockProperSets.setToolTipText("<html>enable to compute proper sets. <font color='#ff0000'>it is required to load p-invariants</font></html>");
/* 216 */     this.jCheckDeadlockProperSets.setEnabled(false);
/* 217 */     add(this.jCheckDeadlockProperSets, "3,5");
/* 218 */     add(this.jCheckBadSiphons, "3,6");
/* 219 */     add(this.jCheckSoundSiphons, "3,7");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     ButtonGroup siphonGroup = new ButtonGroup();
/* 226 */     siphonGroup.add(this.jRadioDTP);
/* 227 */     siphonGroup.add(this.jRadioCheckSiphon);
/*     */   }
/*     */ 
/*     */   
/*     */   private void createTrapPanel() {
/* 232 */     this.jRadioTraps = new JRadioButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 239 */             JRadioButton c = (JRadioButton)e.getSource();
/*     */             
/* 241 */             boolean value = c.isSelected();
/*     */             
/* 243 */             DeadlockTrapComputationDialog.this.enableTrapControls(value);
/* 244 */             DeadlockTrapComputationDialog.this.enableDeadlockControls(!value);
/* 245 */             if (value || DeadlockTrapComputationDialog.this.jRadioDeadlock.isSelected()) {
/* 246 */               DeadlockTrapComputationDialog.this.buttonCompute.setEnabled(true);
/*     */             } else {
/* 248 */               DeadlockTrapComputationDialog.this.buttonCompute.setEnabled(false);
/*     */             } 
/*     */           }
/*     */         });
/* 252 */     add(this.jRadioTraps, "1,1");
/*     */     
/* 254 */     this.trapExport = new ExportButtonPanel("export traps", "traps", 165);
/* 255 */     this.trapExport.setEnabled(false);
/* 256 */     add((Component)this.trapExport, "3,1");
/*     */     
/* 258 */     this.jCheckTrapProperSets.setEnabled(false);
/* 259 */     add(this.jCheckTrapProperSets, "1,2,3,2");
/*     */   }
/*     */ 
/*     */   
/*     */   private void createComputeButton() {
/* 264 */     this.buttonCompute = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 271 */             if (DeadlockTrapComputationDialog.this.getPN() == null) {
/* 272 */               JOptionPane.showMessageDialog(null, "Please load a net before computing traps/siphons!");
/*     */               
/*     */               return;
/*     */             } 
/* 276 */             if (DeadlockTrapComputationDialog.this.jRadioDeadlock.isSelected()) {
/* 277 */               DeadlockOptions o = new DeadlockOptions();
/* 278 */               o.compute = true;
/* 279 */               o.breakDtpComputation = !DeadlockTrapComputationDialog.this.deadlockExport.isSelected();
/*     */               
/* 281 */               if (DeadlockTrapComputationDialog.this.deadlockExport.isSelected()) {
/* 282 */                 o.export = true;
/* 283 */                 o.exportFile = DeadlockTrapComputationDialog.this.deadlockExport.getFile();
/*     */               } 
/* 285 */               if (DeadlockTrapComputationDialog.this.jRadioDTP.isSelected()) {
/* 286 */                 o.computeDtp = true;
/*     */                 
/* 288 */                 if (FilterFactory.getFilterProperties().isFiltered(SiphonTrapFilterPreference.FILTER_SIPHON_TRAP_STP.getKey())) {
/* 289 */                   o.setLogOutput(false);
/*     */                 }
/* 291 */               } else if (DeadlockTrapComputationDialog.this.jRadioCheckSiphon.isSelected()) {
/*     */ 
/*     */                 
/* 294 */                 o.breakDtpComputation = false;
/*     */                 
/* 296 */                 if (DeadlockTrapComputationDialog.this.jCheckDeadlockProperSets.isSelected()) {
/* 297 */                   o.properSets = true;
/* 298 */                   o.invSupports = DeadlockTrapComputationDialog.this.getSupports();
/*     */                 } 
/* 300 */                 if (DeadlockTrapComputationDialog.this.jCheckBadSiphons.isSelected()) {
/* 301 */                   o.computeBadSiphons = true;
/*     */                 }
/* 303 */                 if (DeadlockTrapComputationDialog.this.jCheckSoundSiphons.isSelected()) {
/* 304 */                   o.computeSoundSiphons = true;
/*     */                 }
/*     */                 
/* 307 */                 if (FilterFactory.getFilterProperties().isFiltered(SiphonTrapFilterPreference.FILTER_SIPHON_TRAP_SIPHON.getKey())) {
/* 308 */                   o.setLogOutput(false);
/*     */                 }
/*     */               } 
/*     */               
/* 312 */               DeadlockTrapComputationDialog.this.computeDeadlocks(DeadlockTrapComputationDialog.this.getPN(), o);
/*     */             } 
/*     */             
/* 315 */             if (DeadlockTrapComputationDialog.this.jRadioTraps.isSelected()) {
/* 316 */               TrapOptions o = new TrapOptions();
/* 317 */               o.setCompute(true);
/* 318 */               if (DeadlockTrapComputationDialog.this.trapExport.isSelected()) {
/* 319 */                 o.export = true;
/* 320 */                 o.exportFile = DeadlockTrapComputationDialog.this.trapExport.getFile();
/*     */               } 
/* 322 */               if (DeadlockTrapComputationDialog.this.jCheckTrapProperSets.isSelected()) {
/* 323 */                 o.properSets = true;
/*     */               }
/*     */               
/* 326 */               if (FilterFactory.getFilterProperties().isFiltered(SiphonTrapFilterPreference.FILTER_SIPHON_TRAP_TRAP.getKey())) {
/* 327 */                 o.setLogOutput(false);
/*     */               }
/*     */               
/* 330 */               DeadlockTrapComputationDialog.this.computeTraps(DeadlockTrapComputationDialog.this.getPN(), o);
/*     */             } 
/*     */           }
/*     */         });
/* 334 */     add(this.buttonCompute, "1,8,1,3");
/*     */   }
/*     */ 
/*     */   
/*     */   private void createPlaceSetAnalyzerButton() {
/* 339 */     this.showPlaceSetAnalyzer = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 346 */             if (DeadlockTrapComputationDialog.this.getPN() == null) {
/* 347 */               JOptionPane.showMessageDialog(null, "Please load a net before computing traps/siphons!");
/*     */               
/*     */               return;
/*     */             } 
/* 351 */             PlaceSetAnalyser psa = new PlaceSetAnalyser(DeadlockTrapComputationDialog.this.getPN());
/* 352 */             psa.setSize(500, 400);
/* 353 */             psa.setVisible(true);
/*     */           }
/*     */         });
/*     */     
/* 357 */     add(this.showPlaceSetAnalyzer, "3,8,3,3");
/*     */   }
/*     */   
/*     */   public void computeDeadlocks(PlaceTransitionNet pn, DeadlockOptions o) {
/* 361 */     DebugCounter.inc("Computing Siphons");
/*     */     
/* 363 */     AnalyzerManagerFactory.getAnalyzerManager().compute(pn, new DeadlockSet(), (OptionSet)o, this);
/*     */   }
/*     */   
/*     */   public void computeTraps(PlaceTransitionNet pn, TrapOptions o) {
/* 367 */     DebugCounter.inc("Computing Traps");
/*     */     
/* 369 */     AnalyzerManagerFactory.getAnalyzerManager().compute(pn, new Trap(), (OptionSet)o, this);
/*     */   }
/*     */   
/*     */   public void enableControls(boolean b) {
/* 373 */     if (!b) {
/* 374 */       enableTrapControls(false);
/* 375 */       enableDeadlockControls(false);
/*     */     }
/* 377 */     else if (this.jRadioTraps.isSelected()) {
/* 378 */       enableTrapControls(true);
/* 379 */       enableDeadlockControls(false);
/*     */     } else {
/* 381 */       enableTrapControls(false);
/* 382 */       enableDeadlockControls(true);
/*     */     } 
/*     */     
/* 385 */     this.buttonCompute.setEnabled(b);
/* 386 */     this.showPlaceSetAnalyzer.setEnabled(b);
/*     */   }
/*     */   
/*     */   private HashSet<PlaceSet> getSupports() {
/* 390 */     JOptionPane.showMessageDialog(null, "The pruning of non proper sets requires to load the p-invariants!", "", 1);
/*     */     
/* 392 */     FileSaver fs = new FileSaver();
/* 393 */     fs.addChoosableFileFilter(new FileNameExtensionFilter("Invariant file .inv", new String[] { "inv" }));
/*     */     
/* 395 */     File invFile = fs.showOpenDialog(null, null);
/* 396 */     if (invFile != null) {
/* 397 */       InvParser ip = new InvParser(getPN(), invFile.getPath());
/*     */       try {
/* 399 */         ip.parse();
/* 400 */       } catch (Exception ex) {
/* 401 */         JOptionPane.showMessageDialog(null, "Could not load invariant file, check contents!\nError message: " + ex.getMessage());
/* 402 */         return null;
/*     */       } 
/* 404 */       if (ip.transitions()) {
/* 405 */         return null;
/*     */       }
/* 407 */       PInvariantSet pInvariants = (PInvariantSet)ip.getInvariants();
/* 408 */       if (pInvariants != null) {
/* 409 */         Out.println("loaded p-invariants from file: " + invFile.getName() + "\n# of invariants: " + pInvariants.rows());
/*     */         try {
/* 411 */           return pInvariants.getSupports();
/* 412 */         } catch (Exception e) {
/* 413 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 419 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/DeadlockTrapComputationDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */