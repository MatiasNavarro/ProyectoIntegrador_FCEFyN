/*    */ package GUI.app_components;
/*    */ 
/*    */ import GUI.IDirector;
/*    */ import charlie.analyzer.Analyzer;
/*    */ import charlie.analyzer.Initiator;
/*    */ import charlie.analyzer.OptionSet;
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.pn.Results;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ComputationalDialog
/*    */   extends JPanel
/*    */   implements Initiator
/*    */ {
/*    */   private static final long serialVersionUID = -4740855430333187895L;
/*    */   private final IDirector director;
/* 22 */   private PlaceTransitionNet pn = null;
/*    */   
/*    */   protected ComputationalDialog(IDirector _director) {
/* 25 */     this.director = _director;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract void initialize();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected IDirector getDirector() {
/* 39 */     return this.director;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setPN(PlaceTransitionNet _pn) {
/* 48 */     this.pn = _pn;
/*    */     
/* 50 */     if (this.pn != null) {
/* 51 */       handlePlaceTransitionNetNotNull();
/*    */     } else {
/* 53 */       handlePlaceTransitionNetNull();
/*    */     } 
/*    */   }
/*    */   
/*    */   public PlaceTransitionNet getPN() {
/* 58 */     return this.pn;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void handlePlaceTransitionNetNull() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void handlePlaceTransitionNetNotNull() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void analyzerHasFinished(Analyzer finished) {
/* 85 */     Object resultObject = finished.getResultObject();
/* 86 */     OptionSet options = finished.getOptionSet();
/* 87 */     Results results = finished.getResults();
/*    */     
/* 89 */     handleResult(resultObject, results);
/*    */     
/* 91 */     this.director.sendMessage(11, this, options);
/*    */   }
/*    */   
/*    */   protected void handleResult(Object _resultObject, Results _results) {}
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/ComputationalDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */