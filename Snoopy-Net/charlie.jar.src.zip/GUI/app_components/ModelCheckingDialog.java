/*     */ package GUI.app_components;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ public class ModelCheckingDialog
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  18 */   private JButton jButtonChooseCtlFile = null;
/*  19 */   private JTextField jTextFieldFileName = null;
/*  20 */   private JLabel jLabelCtlFile = null;
/*  21 */   private JLabel jLabelLastCtlFiles = null;
/*  22 */   private JList jListLastUsedCtlFiles = null;
/*  23 */   private JButton jButton = null;
/*  24 */   private JButton jButtonCheckCtlFormula = null;
/*  25 */   private JButton jButtonOpenCtlFile = null;
/*  26 */   private JRadioButton jRadioButtonInternalChecker = null;
/*  27 */   private JRadioButton jRadioButtonExternalChecker = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModelCheckingDialog() {
/*  34 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  43 */     GridBagConstraints gridBagConstraints21 = new GridBagConstraints();
/*  44 */     gridBagConstraints21.gridx = 0;
/*  45 */     gridBagConstraints21.fill = 2;
/*  46 */     gridBagConstraints21.gridy = 8;
/*  47 */     GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
/*  48 */     gridBagConstraints11.gridx = 0;
/*  49 */     gridBagConstraints11.fill = 2;
/*  50 */     gridBagConstraints11.gridy = 7;
/*  51 */     GridBagConstraints gridBagConstraints7 = new GridBagConstraints();
/*  52 */     gridBagConstraints7.gridx = 0;
/*  53 */     gridBagConstraints7.fill = 2;
/*  54 */     gridBagConstraints7.insets = new Insets(0, 2, 0, 0);
/*  55 */     gridBagConstraints7.gridy = 3;
/*  56 */     GridBagConstraints gridBagConstraints6 = new GridBagConstraints();
/*  57 */     gridBagConstraints6.gridx = 0;
/*  58 */     gridBagConstraints6.fill = 2;
/*  59 */     gridBagConstraints6.insets = new Insets(0, 2, 0, 0);
/*  60 */     gridBagConstraints6.gridy = 6;
/*  61 */     GridBagConstraints gridBagConstraints5 = new GridBagConstraints();
/*  62 */     gridBagConstraints5.gridx = 0;
/*  63 */     gridBagConstraints5.fill = 2;
/*  64 */     gridBagConstraints5.insets = new Insets(0, 2, 0, 0);
/*  65 */     gridBagConstraints5.gridy = 0;
/*  66 */     GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
/*  67 */     gridBagConstraints4.fill = 1;
/*  68 */     gridBagConstraints4.gridy = 5;
/*  69 */     gridBagConstraints4.weightx = 1.0D;
/*  70 */     gridBagConstraints4.weighty = 1.0D;
/*  71 */     gridBagConstraints4.gridheight = 1;
/*  72 */     gridBagConstraints4.insets = new Insets(0, 2, 5, 0);
/*  73 */     gridBagConstraints4.gridx = 0;
/*  74 */     GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
/*  75 */     gridBagConstraints3.gridx = 0;
/*  76 */     gridBagConstraints3.anchor = 17;
/*  77 */     gridBagConstraints3.fill = 2;
/*  78 */     gridBagConstraints3.insets = new Insets(0, 2, 0, 0);
/*  79 */     gridBagConstraints3.gridy = 4;
/*  80 */     this.jLabelLastCtlFiles = new JLabel();
/*  81 */     this.jLabelLastCtlFiles.setText("Lately used ... Files");
/*  82 */     GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
/*  83 */     gridBagConstraints2.gridx = 0;
/*  84 */     gridBagConstraints2.anchor = 17;
/*  85 */     gridBagConstraints2.fill = 2;
/*  86 */     gridBagConstraints2.insets = new Insets(0, 2, 0, 0);
/*  87 */     gridBagConstraints2.gridy = 1;
/*  88 */     this.jLabelCtlFile = new JLabel();
/*  89 */     this.jLabelCtlFile.setText("Choose CTL Formula File");
/*  90 */     GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
/*  91 */     gridBagConstraints1.fill = 1;
/*  92 */     gridBagConstraints1.gridy = 2;
/*  93 */     gridBagConstraints1.weightx = 1.0D;
/*  94 */     gridBagConstraints1.insets = new Insets(0, 2, 0, 0);
/*  95 */     gridBagConstraints1.gridx = 0;
/*  96 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*  97 */     gridBagConstraints.gridx = 1;
/*  98 */     gridBagConstraints.gridy = 2;
/*  99 */     setSize(300, 382);
/* 100 */     setPreferredSize(new Dimension(300, 382));
/* 101 */     setLayout(new GridBagLayout());
/* 102 */     add(getJButtonChooseCtlFile(), gridBagConstraints);
/* 103 */     add(getJTextFieldFileName(), gridBagConstraints1);
/* 104 */     add(this.jLabelCtlFile, gridBagConstraints2);
/* 105 */     add(this.jLabelLastCtlFiles, gridBagConstraints3);
/* 106 */     add(getJListLastUsedCtlFiles(), gridBagConstraints4);
/* 107 */     add(getJButton(), gridBagConstraints5);
/* 108 */     add(getJButtonCheckCtlFormula(), gridBagConstraints6);
/* 109 */     add(getJButtonOpenCtlFile(), gridBagConstraints7);
/* 110 */     add(getJRadioButtonInternalChecker(), gridBagConstraints11);
/* 111 */     add(getJRadioButtonExternalChecker(), gridBagConstraints21);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonChooseCtlFile() {
/* 120 */     if (this.jButtonChooseCtlFile == null) {
/* 121 */       this.jButtonChooseCtlFile = new JButton();
/* 122 */       this.jButtonChooseCtlFile.setText("...");
/*     */     } 
/* 124 */     return this.jButtonChooseCtlFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JTextField getJTextFieldFileName() {
/* 133 */     if (this.jTextFieldFileName == null) {
/* 134 */       this.jTextFieldFileName = new JTextField();
/*     */     }
/* 136 */     return this.jTextFieldFileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JList getJListLastUsedCtlFiles() {
/* 145 */     if (this.jListLastUsedCtlFiles == null) {
/* 146 */       this.jListLastUsedCtlFiles = new JList();
/*     */     }
/* 148 */     return this.jListLastUsedCtlFiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButton() {
/* 157 */     if (this.jButton == null) {
/* 158 */       this.jButton = new JButton();
/* 159 */       this.jButton.setText("Open ... Formula Editor");
/*     */     } 
/* 161 */     return this.jButton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonCheckCtlFormula() {
/* 170 */     if (this.jButtonCheckCtlFormula == null) {
/* 171 */       this.jButtonCheckCtlFormula = new JButton();
/* 172 */       this.jButtonCheckCtlFormula.setText("Check Formula");
/*     */     } 
/* 174 */     return this.jButtonCheckCtlFormula;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonOpenCtlFile() {
/* 183 */     if (this.jButtonOpenCtlFile == null) {
/* 184 */       this.jButtonOpenCtlFile = new JButton();
/* 185 */       this.jButtonOpenCtlFile.setText("Open .. File");
/*     */     } 
/* 187 */     return this.jButtonOpenCtlFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JRadioButton getJRadioButtonInternalChecker() {
/* 196 */     if (this.jRadioButtonInternalChecker == null) {
/* 197 */       this.jRadioButtonInternalChecker = new JRadioButton();
/* 198 */       this.jRadioButtonInternalChecker.setText("use Internal Checker");
/*     */     } 
/* 200 */     return this.jRadioButtonInternalChecker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JRadioButton getJRadioButtonExternalChecker() {
/* 209 */     if (this.jRadioButtonExternalChecker == null) {
/* 210 */       this.jRadioButtonExternalChecker = new JRadioButton();
/* 211 */       this.jRadioButtonExternalChecker.setText("use External Checker");
/*     */     } 
/* 213 */     return this.jRadioButtonExternalChecker;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/ModelCheckingDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */