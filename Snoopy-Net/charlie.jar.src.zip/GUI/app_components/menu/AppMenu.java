/*     */ package GUI.app_components.menu;
/*     */ 
/*     */ import GUI.IAppDirector;
/*     */ import GUI.IDirector;
/*     */ import GUI.app_actions.FileOpenAction;
/*     */ import GUI.app_actions.FilesAction;
/*     */ import GUI.app_actions.ReloadFileAction;
/*     */ import GUI.app_components.StartDialog;
/*     */ import GUI.io.FileSaver;
/*     */ import GUI.preference.FilterPreferenceDialog;
/*     */ import GUI.preference.Preference;
/*     */ import GUI.preference.PreferenceFactory;
/*     */ import GUI.util.ResourceLoader;
/*     */ import charlie.plugin.io.PluginImportFactory;
/*     */ import charlie.plugin.io.PluginPlaceTransitionNetReader;
/*     */ import charlie.util.DirectorManager;
/*     */ import charlie.util.ReaderFileImportMessage;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.help.CSH;
/*     */ import javax.help.HelpBroker;
/*     */ import javax.help.HelpSet;
/*     */ import javax.help.HelpSetException;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JCheckBoxMenuItem;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AppMenu
/*     */   extends JMenuBar
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  52 */   private static Log LOG = LogFactory.getLog(AppMenu.class);
/*     */   
/*  54 */   IDirector director = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private LastFilesMenu lastFiles = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JMenuItem reloadFileItem;
/*     */ 
/*     */ 
/*     */   
/*     */   File netFile;
/*     */ 
/*     */ 
/*     */   
/*  72 */   private JMenu helpMenu = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private FilterPreferenceDialog filterDialog = null;
/*     */ 
/*     */   
/*     */   public AppMenu(IDirector d) {
/*  81 */     this.director = d;
/*     */   }
/*     */   
/*     */   public void createMenu(final JFrame _owner) {
/*  85 */     LOG.debug("creating menu");
/*     */     
/*  87 */     AppMenu menu = this;
/*     */ 
/*     */     
/*  90 */     JMenu fileMenu = new JMenu("file");
/*  91 */     fileMenu.setMnemonic(70);
/*  92 */     menu.add(fileMenu);
/*  93 */     this.lastFiles = new LastFilesMenu("recent files", new LastFilesListModel(5));
/*  94 */     FilesAction fa = new FilesAction("recent files", this.director, this.lastFiles);
/*  95 */     this.lastFiles.setAction((Action)fa);
/*     */     
/*  97 */     JMenuItem fileOpenItem = new JMenuItem((Action)new FileOpenAction(this.director, this.lastFiles));
/*  98 */     fileOpenItem.setMnemonic(79);
/*  99 */     fileOpenItem.setAccelerator(KeyStroke.getKeyStroke(79, 128));
/* 100 */     fileMenu.add(fileOpenItem);
/*     */ 
/*     */     
/* 103 */     if (PluginImportFactory.getInstance().size() > 0) {
/* 104 */       JMenuItem fileImportMenu = new JMenuItem("import ...");
/* 105 */       fileOpenItem.setMnemonic(73);
/* 106 */       fileImportMenu.addActionListener(new ActionListener()
/*     */           {
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 110 */               JFileChooser chooser = new JFileChooser(FileSaver.lastSaveDir);
/* 111 */               chooser.setMultiSelectionEnabled(false);
/* 112 */               chooser.setAcceptAllFileFilterUsed(false);
/*     */               
/* 114 */               for (String id : PluginImportFactory.getInstance().getReaderIdList()) {
/* 115 */                 PluginPlaceTransitionNetReader reader = PluginImportFactory.getInstance().getReader(id);
/*     */                 
/* 117 */                 for (int i = 0; i < reader.getDescription().size(); i++) {
/* 118 */                   String description = reader.getDescription().get(i);
/* 119 */                   String extension = reader.getLoadableExtensions().get(i);
/* 120 */                   chooser.addChoosableFileFilter(new AppMenu.ImportFileFilter(reader.getId(), description, extension));
/*     */                 } 
/*     */               } 
/*     */               
/* 124 */               int returnVal = chooser.showOpenDialog(null);
/* 125 */               if (returnVal == 0) {
/*     */                 
/* 127 */                 String id = ((AppMenu.ImportFileFilter)chooser.getFileFilter()).getId();
/* 128 */                 File file = chooser.getSelectedFile();
/*     */ 
/*     */                 
/* 131 */                 FileSaver.lastSaveDir = file.getParent();
/*     */                 
/* 133 */                 DirectorManager.sendMessage(IAppDirector.class, 17, this, new ReaderFileImportMessage(id, file));
/*     */               } 
/*     */             }
/*     */           });
/*     */       
/* 138 */       fileMenu.add(fileImportMenu);
/*     */     } 
/*     */     
/* 141 */     this.reloadFileItem = new JMenuItem((Action)new ReloadFileAction(this.director));
/* 142 */     this.reloadFileItem.setEnabled(false);
/* 143 */     this.reloadFileItem.setMnemonic(82);
/* 144 */     this.reloadFileItem.setAccelerator(KeyStroke.getKeyStroke(82, 128));
/* 145 */     fileMenu.add(this.reloadFileItem);
/*     */     
/* 147 */     fileMenu.addSeparator();
/*     */     
/* 149 */     JMenuItem loadSession = new JMenuItem(new AbstractAction("load session ...")
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 158 */             FileSaver fs = new FileSaver();
/* 159 */             File openFile = fs.showOpenDialog(null, new FileNameExtensionFilter("app-session file", new String[] { ".app_session" }));
/* 160 */             if (openFile != null) {
/* 161 */               FileSaver.lastSaveDir = openFile.getParent();
/* 162 */               AppMenu.this.director.sendMessage(9, this, openFile);
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 167 */     loadSession.setMnemonic(76);
/* 168 */     fileMenu.add(loadSession);
/* 169 */     JMenuItem saveSession = new JMenuItem(new AbstractAction("save session ...")
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 178 */             FileSaver fs = new FileSaver();
/* 179 */             File saveFile = fs.showSaveDialog(null, "", "app_session");
/* 180 */             if (saveFile != null) {
/* 181 */               FileSaver.lastSaveDir = saveFile.getParent();
/* 182 */               AppMenu.this.director.sendMessage(8, this, saveFile);
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 188 */     saveSession.setMnemonic(83);
/* 189 */     fileMenu.add(saveSession);
/*     */     
/* 191 */     fileMenu.addSeparator();
/*     */     
/* 193 */     this.lastFiles.setMnemonic(69);
/* 194 */     this.lastFiles.setToolTipText("a list of recently opened files; reopen a file by clicking on it");
/* 195 */     fileMenu.add(this.lastFiles);
/*     */     
/* 197 */     fileMenu.addSeparator();
/*     */     
/* 199 */     JMenuItem exitApp = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 205 */             AppMenu.this.director.sendMessage(3, null, null);
/*     */           }
/*     */         });
/* 208 */     exitApp.setMnemonic(88);
/* 209 */     exitApp.setToolTipText("exits the program");
/* 210 */     exitApp.setAccelerator(KeyStroke.getKeyStroke(81, 128));
/* 211 */     fileMenu.add(exitApp);
/*     */ 
/*     */     
/* 214 */     JMenu showMenu = new JMenu("show");
/* 215 */     showMenu.setMnemonic(83);
/*     */     
/* 217 */     JMenuItem snoopy = new JMenuItem("show in snoopy");
/* 218 */     snoopy.setAction(new AbstractAction("show in snoopy")
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 221 */             if (!AppMenu.this.director.sendMessage(10, this, null)) {
/* 222 */               int answ = JOptionPane.showConfirmDialog((JMenuItem)e.getSource(), "Could not show net in snoopy!\n Check if a net is loaded !\n or \nDo you want to specify the path to snoopy executable?", "Question", 0);
/*     */ 
/*     */               
/* 225 */               if (answ == 0) {
/* 226 */                 FileSaver fs = new FileSaver();
/* 227 */                 String lastDir = FileSaver.lastSaveDir;
/* 228 */                 File f = fs.showOpenDialog(new File(System.getProperty("user.home")), null);
/* 229 */                 FileSaver.lastSaveDir = lastDir;
/* 230 */                 if (f != null && f.exists()) {
/* 231 */                   String[] s = new String[2];
/* 232 */                   s[0] = "snoopy_file";
/* 233 */                   s[1] = f.getAbsolutePath();
/* 234 */                   AppMenu.this.director.sendMessage(7, this, s);
/* 235 */                   actionPerformed(e);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 242 */     snoopy.setMnemonic(83);
/* 243 */     snoopy.setToolTipText("shows the net in snoopy");
/* 244 */     showMenu.add(snoopy);
/* 245 */     JMenuItem debugNet = new JMenuItem("debug pn");
/* 246 */     debugNet.setAction(new AbstractAction("debug pn") {
/*     */           public void actionPerformed(ActionEvent e) {
/* 248 */             AppMenu.this.director.sendMessage(12, null, null);
/*     */           }
/*     */         });
/* 251 */     debugNet.setMnemonic(68);
/* 252 */     debugNet.setToolTipText("shows some debug information about the net");
/* 253 */     showMenu.add(debugNet);
/* 254 */     menu.add(showMenu);
/*     */ 
/*     */     
/* 257 */     JMenu settingsMenu = new JMenu("preferences");
/* 258 */     settingsMenu.setMnemonic(80);
/*     */     
/* 260 */     final JCheckBoxMenuItem applyRulesCheckbox = new JCheckBoxMenuItem("always apply rules");
/* 261 */     applyRulesCheckbox.setMnemonic(82);
/* 262 */     applyRulesCheckbox.setToolTipText("option for switching always applying rule on or off");
/* 263 */     applyRulesCheckbox.setSelected(Boolean.parseBoolean(PreferenceFactory.getPreferenceProperties().getProperty(Preference.APPLY_RULES_PROPERTY.getKey(), Preference.APPLY_RULES_PROPERTY.getDefault())));
/* 264 */     applyRulesCheckbox.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 267 */             PreferenceFactory.getPreferenceProperties().setProperty(Preference.APPLY_RULES_PROPERTY.getKey(), Boolean.toString(applyRulesCheckbox.isSelected()));
/*     */           }
/*     */         });
/*     */     
/* 271 */     settingsMenu.add(applyRulesCheckbox);
/*     */ 
/*     */     
/* 274 */     final JCheckBoxMenuItem writeLogFileCheckbox = new JCheckBoxMenuItem("write log file");
/* 275 */     writeLogFileCheckbox.setMnemonic(87);
/* 276 */     writeLogFileCheckbox.setToolTipText("option for switching to write log file on or off");
/* 277 */     writeLogFileCheckbox.setSelected(Boolean.parseBoolean(PreferenceFactory.getPreferenceProperties().getProperty(Preference.WRITE_LOG_FILE.getKey(), Preference.WRITE_LOG_FILE.getDefault())));
/* 278 */     writeLogFileCheckbox.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 281 */             PreferenceFactory.getPreferenceProperties().setProperty(Preference.WRITE_LOG_FILE.getKey(), Boolean.toString(writeLogFileCheckbox.isSelected()));
/*     */           }
/*     */         });
/* 284 */     settingsMenu.add(writeLogFileCheckbox);
/*     */     
/* 286 */     settingsMenu.addSeparator();
/*     */     
/* 288 */     JMenuItem filterSettings = new JMenuItem("filter output ...");
/* 289 */     filterSettings.setMnemonic(70);
/* 290 */     filterSettings.setToolTipText("opens a dialog to set output filter options");
/* 291 */     filterSettings.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 294 */             if (AppMenu.this.filterDialog == null) {
/* 295 */               AppMenu.this.filterDialog = new FilterPreferenceDialog(_owner, AppMenu.this.director);
/* 296 */               AppMenu.this.filterDialog.initialize();
/*     */               
/* 298 */               AppMenu.this.filterDialog.setModal(false);
/* 299 */               AppMenu.this.filterDialog.setSize(380, 400);
/* 300 */               AppMenu.this.filterDialog.setLocation(AppMenu.this.filterDialog.getParent().getX() + 20, AppMenu.this.filterDialog.getParent().getY() + 20);
/* 301 */               AppMenu.this.filterDialog.setVisible(true);
/*     */             } else {
/* 303 */               AppMenu.this.filterDialog.setVisible(!AppMenu.this.filterDialog.isVisible());
/*     */             } 
/*     */           }
/*     */         });
/* 307 */     settingsMenu.add(filterSettings);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     JMenu updateMenu = new JMenu("update");
/*     */     
/* 314 */     final JCheckBoxMenuItem autoUpdateCheckbox = new JCheckBoxMenuItem("automatically check for updates");
/* 315 */     autoUpdateCheckbox.setMnemonic(85);
/* 316 */     autoUpdateCheckbox.setToolTipText("option for switching to automatically check for new updates on startup on or off");
/* 317 */     autoUpdateCheckbox.setSelected(Boolean.parseBoolean(PreferenceFactory.getPreferenceProperties().getProperty(Preference.AUTO_CHECK_FOR_UPDATES.getKey(), "false")));
/* 318 */     autoUpdateCheckbox.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 321 */             PreferenceFactory.getPreferenceProperties().setProperty(Preference.AUTO_CHECK_FOR_UPDATES.getKey(), Boolean.toString(autoUpdateCheckbox.isSelected()));
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 326 */     JMenuItem updateItem = new JMenuItem("check for updates");
/* 327 */     updateItem.setMnemonic(67);
/* 328 */     updateItem.setToolTipText("checks if there are new updates available");
/* 329 */     updateItem.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 332 */             AppMenu.this.director.sendMessage(16, this, "");
/*     */           }
/*     */         });
/*     */     
/* 336 */     updateMenu.add(updateItem);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 342 */     menu.add(settingsMenu);
/*     */ 
/*     */     
/* 345 */     JMenu helpMenu = new JMenu("help");
/* 346 */     helpMenu.setMnemonic(72);
/*     */     
/*     */     try {
/* 349 */       JMenuItem helpItem = new JMenuItem("help");
/* 350 */       helpItem.setMnemonic(72);
/* 351 */       helpItem.setToolTipText("shows the help dialog");
/* 352 */       helpItem.setAccelerator(KeyStroke.getKeyStroke(112, 0, true));
/*     */       
/* 354 */       URL hsURL = ResourceLoader.getURL("help/system/jhelpset.hs");
/* 355 */       HelpSet hs = new HelpSet(null, hsURL);
/* 356 */       HelpBroker hb = hs.createHelpBroker();
/* 357 */       CSH.setHelpIDString(helpItem, "index");
/* 358 */       helpItem.addActionListener((ActionListener)new CSH.DisplayHelpFromSource(hb));
/* 359 */       helpMenu.add(helpItem);
/*     */       
/* 361 */       helpMenu.addSeparator();
/* 362 */     } catch (HelpSetException e) {
/* 363 */       LOG.error(e.getMessage(), (Throwable)e);
/*     */     } 
/*     */     
/* 366 */     JMenuItem aboutItem = new JMenuItem("about");
/* 367 */     aboutItem.setAction(new AbstractAction("about") {
/*     */           public void actionPerformed(ActionEvent e) {
/* 369 */             URL url = ResourceLoader.getURL("resources/about.html");
/*     */             try {
/* 371 */               AppMenu.LOG.info(url.toURI().toString());
/* 372 */               StartDialog.showClosableAbout(new File(url.toURI()), new JFrame());
/* 373 */             } catch (URISyntaxException ex) {
/* 374 */               AppMenu.LOG.error(ex.getMessage(), ex);
/*     */             } 
/*     */           }
/*     */         });
/* 378 */     aboutItem.setMnemonic(65);
/* 379 */     aboutItem.setToolTipText("shows the about dialog");
/* 380 */     helpMenu.add(aboutItem);
/* 381 */     menu.add(helpMenu);
/* 382 */     menu.setHelpMenu(helpMenu);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JMenu getHelpMenu() {
/* 391 */     return this.helpMenu;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHelpMenu(JMenu _helpMenu) {
/* 400 */     this.helpMenu = _helpMenu;
/*     */   }
/*     */   
/*     */   public static AppMenu createJMenu(JFrame _owner, IDirector d) {
/* 404 */     AppMenu menu = new AppMenu(d);
/* 405 */     menu.createMenu(_owner);
/* 406 */     return menu;
/*     */   }
/*     */   
/*     */   public void addLastFile(File lastFile) {
/* 410 */     this.lastFiles.addFile(lastFile);
/*     */   }
/*     */   
/*     */   public List<? extends File> getLastFileList() {
/* 414 */     return this.lastFiles.getFileList();
/*     */   }
/*     */   
/*     */   public void enableReload() {
/* 418 */     this.reloadFileItem.setEnabled(true);
/*     */   }
/*     */   
/*     */   private class ImportFileFilter
/*     */     extends FileFilter {
/*     */     private final String id;
/*     */     private final String description;
/* 425 */     private final List<String> extensionList = new ArrayList<>();
/*     */     
/*     */     public ImportFileFilter(String _id, String _description, String _acceptedExtension) {
/* 428 */       this.id = _id;
/* 429 */       this.description = _description;
/* 430 */       for (String s : _acceptedExtension.split("\\s*,\\s*")) {
/* 431 */         this.extensionList.add(s);
/*     */       }
/*     */     }
/*     */     
/*     */     public String getId() {
/* 436 */       return this.id;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDescription() {
/* 441 */       return this.description + " (" + this.extensionList + ")";
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean accept(File _f) {
/* 446 */       if (_f != null) {
/* 447 */         if (_f.isDirectory()) {
/* 448 */           return true;
/*     */         }
/*     */         
/* 451 */         for (String extension : this.extensionList) {
/* 452 */           if (_f.getName().toLowerCase().endsWith(extension)) {
/* 453 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 458 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/menu/AppMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */