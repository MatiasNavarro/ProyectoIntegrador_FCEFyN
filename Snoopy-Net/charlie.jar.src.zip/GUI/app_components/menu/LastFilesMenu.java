/*     */ package GUI.app_components.menu;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.List;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.ListModel;
/*     */ import javax.swing.event.ListDataEvent;
/*     */ import javax.swing.event.ListDataListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LastFilesMenu
/*     */   extends JMenu
/*     */   implements ListDataListener
/*     */ {
/*     */   private static final long serialVersionUID = -2374021932577072688L;
/*  20 */   public static String PREQUEL = "fileList_";
/*     */   
/*     */   public static final int maxFiles = 5;
/*  23 */   LastFilesListModel listModel = null;
/*  24 */   Action fileAction = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LastFilesMenu() {
/*  31 */     setEnabled(false);
/*  32 */     this.listModel = new LastFilesListModel(5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LastFilesMenu(Action a) {
/*  41 */     super(a);
/*  42 */     this.fileAction = a;
/*  43 */     setEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LastFilesMenu(String s, LastFilesListModel model) {
/*  53 */     super(s);
/*  54 */     setEnabled(false);
/*  55 */     this.listModel = model;
/*  56 */     this.listModel.addListDataListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LastFilesMenu(String s, boolean b) {
/*  68 */     super(s, b);
/*  69 */     setEnabled(false);
/*     */   }
/*     */   
/*     */   public ListModel getListModel() {
/*  73 */     return this.listModel;
/*     */   }
/*     */   
/*     */   public void contentsChanged(ListDataEvent e) {
/*  77 */     createMenu();
/*     */   }
/*     */   
/*     */   public void intervalAdded(ListDataEvent e) {
/*  81 */     createMenu();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void intervalRemoved(ListDataEvent e) {}
/*     */ 
/*     */   
/*     */   public void setAction(Action a) {
/*  90 */     this.fileAction = a;
/*  91 */     createMenu();
/*     */   }
/*     */   
/*     */   public File addFile(File file) {
/*  95 */     return this.listModel.addFile(file);
/*     */   }
/*     */   
/*     */   public List<? extends File> getFileList() {
/*  99 */     return (List)this.listModel.getList();
/*     */   }
/*     */ 
/*     */   
/*     */   public void createMenu() {
/* 104 */     removeAll();
/* 105 */     for (int i = 0; i < this.listModel.getSize(); i++) {
/* 106 */       JMenuItem item = new JMenuItem(this.fileAction);
/* 107 */       item.setActionCommand(PREQUEL + Integer.toString(i));
/* 108 */       item.setText(this.listModel.getElementAt(i).toString());
/* 109 */       item.setToolTipText(String.format("<html>click to load the file '%s'<br/>&nbsp;<br/>complete path: %s</html>", new Object[] { this.listModel.getElementAt(i).toString(), this.listModel.getElementAt(i).getAbsolutePath() }));
/* 110 */       add(item);
/*     */     } 
/*     */     
/* 113 */     if (this.listModel.getSize() > 0) {
/* 114 */       setEnabled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   public File getFileByIndex(int index) {
/* 119 */     if (index >= 0 && index < this.listModel.getSize()) {
/* 120 */       File f = this.listModel.getElementAt(index);
/* 121 */       if (f.exists()) {
/* 122 */         return f;
/*     */       }
/*     */     } 
/* 125 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/menu/LastFilesMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */