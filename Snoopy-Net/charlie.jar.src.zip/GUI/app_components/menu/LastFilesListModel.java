/*    */ package GUI.app_components.menu;
/*    */ 
/*    */ import GUI.app_components.MyFile;
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import javax.swing.AbstractListModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LastFilesListModel
/*    */   extends AbstractListModel
/*    */ {
/*    */   private static final long serialVersionUID = -7668867071705900833L;
/* 17 */   private ArrayList<MyFile> fileList = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 22 */   private int maxFiles = 1;
/*    */   
/*    */   public LastFilesListModel(int capacity) {
/* 25 */     this.maxFiles = capacity;
/*    */   }
/*    */   
/*    */   public File addFile(File file) {
/* 29 */     if (!file.exists()) {
/* 30 */       return null;
/*    */     }
/*    */     
/* 33 */     MyFile f = MyFile.createMyFile(file);
/*    */     
/* 35 */     int fileIndex = this.fileList.indexOf(file);
/* 36 */     if (fileIndex >= 0) {
/*    */ 
/*    */ 
/*    */       
/* 40 */       this.fileList.remove(fileIndex);
/* 41 */       this.fileList.add(0, f);
/*    */ 
/*    */       
/* 44 */       fireContentsChanged(this, 0, this.fileList.size() - 1);
/*    */       
/* 46 */       return (File)this.fileList.get(fileIndex);
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 51 */     if (this.maxFiles > this.fileList.size()) {
/* 52 */       this.fileList.add(0, f);
/* 53 */       fireContentsChanged(this, 0, this.fileList.size() - 1);
/*    */     } else {
/*    */       
/* 56 */       this.fileList.remove(this.maxFiles - 1);
/* 57 */       this.fileList.add(0, f);
/* 58 */       fireContentsChanged(this, 0, this.fileList.size() - 1);
/*    */     } 
/* 60 */     return file;
/*    */   }
/*    */ 
/*    */   
/*    */   public File getElementAt(int i) {
/* 65 */     return (File)this.fileList.get(i);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSize() {
/* 70 */     return this.fileList.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public ArrayList<MyFile> getList() {
/* 75 */     return this.fileList;
/*    */   }
/*    */   
/*    */   public void setList(ArrayList<MyFile> newList) {
/* 79 */     if (newList != null) {
/* 80 */       this.fileList = newList;
/* 81 */       fireContentsChanged(this, 0, this.fileList.size() - 1);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/menu/LastFilesListModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */