/*    */ package GUI.app_components;
/*    */ 
/*    */ import GUI.preference.FilterFactory;
/*    */ import GUI.preference.IncidenceMatrixBasedFilterPreference;
/*    */ import charlie.analyzer.OptionSet;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ public class StructurallyBoundedOptionSet
/*    */   extends OptionSet
/*    */ {
/* 14 */   private static final Log LOG = LogFactory.getLog(StructurallyBoundedOptionSet.class);
/*    */   
/* 16 */   private String exportFile = "";
/*    */   
/*    */   public StructurallyBoundedOptionSet() {
/* 19 */     setLogOutput(!FilterFactory.getFilterProperties().isFiltered(IncidenceMatrixBasedFilterPreference.FILTER_IM_BASED_STRUCTURAL_BOUNDEDNESS.getKey()));
/*    */   }
/*    */   
/*    */   public void setExportFile(String _exportFile) {
/* 23 */     this.exportFile = _exportFile;
/*    */   }
/*    */   
/*    */   public String getExportFile() {
/* 27 */     return this.exportFile;
/*    */   }
/*    */ 
/*    */   
/*    */   public Properties getAsProperties() {
/* 32 */     return new Properties();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getHtmlInfo() {
/* 37 */     StringBuffer buf = new StringBuffer();
/* 38 */     buf.append("<html><table border=\"1px\">");
/* 39 */     buf.append("<tr><td width=\"200px\">");
/* 40 */     buf.append("Invariant options");
/* 41 */     buf.append("</td><td width=\"200px\"></td></tr>");
/* 42 */     buf.append("<tr><td>compute</td><td>");
/* 43 */     buf.append("rank of incidence matrix");
/* 44 */     buf.append("</td></tr>");
/* 45 */     buf.append("<tr><td>exportFile</td><td>");
/* 46 */     if (this.exportFile != null) {
/* 47 */       buf.append(this.exportFile);
/*    */     } else {
/* 49 */       buf.append("not set!");
/* 50 */     }  buf.append("</td></tr></table></html>");
/* 51 */     return buf.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean initByProperties(Properties props) {
/* 56 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean initializeByString(String parameters) {
/*    */     try {
/* 62 */       this.exportFile = getValue(parameters, "exportFile", this.exportFile);
/* 63 */     } catch (Exception e) {
/* 64 */       LOG.error(e.getMessage(), e);
/* 65 */       System.out.printf(getHelpString(), new Object[0]);
/* 66 */       return false;
/*    */     } 
/* 68 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 73 */     return StructurallyBoundedOptionSet.class.getName();
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/StructurallyBoundedOptionSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */