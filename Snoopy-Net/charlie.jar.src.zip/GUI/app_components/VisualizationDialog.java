/*     */ package GUI.app_components;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ public class VisualizationDialog
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  16 */   private JLabel jLabelTitle = null;
/*  17 */   private JLabel jLabelChooseLayout = null;
/*  18 */   private JComboBox jComboBoxChooseLayout = null;
/*  19 */   private JCheckBox jCheckBoxLogicStates = null;
/*  20 */   private JCheckBox jCheckBoxVertical = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VisualizationDialog() {
/*  27 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  36 */     GridBagConstraints gridBagConstraints4 = new GridBagConstraints();
/*  37 */     gridBagConstraints4.gridx = 1;
/*  38 */     gridBagConstraints4.fill = 2;
/*  39 */     gridBagConstraints4.gridy = 3;
/*  40 */     GridBagConstraints gridBagConstraints3 = new GridBagConstraints();
/*  41 */     gridBagConstraints3.gridx = 0;
/*  42 */     gridBagConstraints3.fill = 2;
/*  43 */     gridBagConstraints3.gridy = 3;
/*  44 */     GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
/*  45 */     gridBagConstraints2.fill = 2;
/*  46 */     gridBagConstraints2.gridy = 2;
/*  47 */     gridBagConstraints2.weightx = 0.0D;
/*  48 */     gridBagConstraints2.insets = new Insets(0, 0, 0, 0);
/*  49 */     gridBagConstraints2.ipady = 0;
/*  50 */     gridBagConstraints2.gridwidth = 1;
/*  51 */     gridBagConstraints2.gridx = 0;
/*  52 */     GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
/*  53 */     gridBagConstraints1.gridx = 0;
/*  54 */     gridBagConstraints1.fill = 2;
/*  55 */     gridBagConstraints1.gridy = 1;
/*  56 */     this.jLabelChooseLayout = new JLabel();
/*  57 */     this.jLabelChooseLayout.setText("choose Layout");
/*  58 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*  59 */     gridBagConstraints.gridx = 0;
/*  60 */     gridBagConstraints.gridy = 0;
/*  61 */     this.jLabelTitle = new JLabel();
/*  62 */     this.jLabelTitle.setText("Visualisation Options");
/*  63 */     setSize(300, 90);
/*  64 */     setPreferredSize(new Dimension(300, 90));
/*  65 */     setLayout(new GridBagLayout());
/*  66 */     add(this.jLabelTitle, gridBagConstraints);
/*  67 */     add(this.jLabelChooseLayout, gridBagConstraints1);
/*  68 */     add(getJComboBoxChooseLayout(), gridBagConstraints2);
/*  69 */     add(getJCheckBoxLogicStates(), gridBagConstraints3);
/*  70 */     add(getJCheckBoxVertical(), gridBagConstraints4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JComboBox getJComboBoxChooseLayout() {
/*  79 */     if (this.jComboBoxChooseLayout == null) {
/*  80 */       this.jComboBoxChooseLayout = new JComboBox();
/*     */     }
/*  82 */     return this.jComboBoxChooseLayout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JCheckBox getJCheckBoxLogicStates() {
/*  91 */     if (this.jCheckBoxLogicStates == null) {
/*  92 */       this.jCheckBoxLogicStates = new JCheckBox();
/*  93 */       this.jCheckBoxLogicStates.setText("logic states");
/*     */     } 
/*  95 */     return this.jCheckBoxLogicStates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JCheckBox getJCheckBoxVertical() {
/* 104 */     if (this.jCheckBoxVertical == null) {
/* 105 */       this.jCheckBoxVertical = new JCheckBox();
/* 106 */       this.jCheckBoxVertical.setText("vertical");
/*     */     } 
/* 108 */     return this.jCheckBoxVertical;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/VisualizationDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */