/*    */ package GUI.app_components;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.net.URI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MyFile
/*    */   extends File
/*    */ {
/*    */   private static final long serialVersionUID = -4768651599475343171L;
/*    */   
/*    */   MyFile(File parent, String child) {
/* 22 */     super(parent, child);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   MyFile(String pathname) {
/* 32 */     super(pathname);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   MyFile(String parent, String child) {
/* 44 */     super(parent, child);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   MyFile(URI uri) {
/* 54 */     super(uri);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     return getName();
/*    */   }
/*    */   
/*    */   public static MyFile createMyFile(File f) {
/* 63 */     return new MyFile(f.getAbsolutePath());
/*    */   }
/*    */   
/*    */   public boolean equals(MyFile f) {
/* 67 */     if (f == null) {
/* 68 */       return false;
/*    */     }
/*    */     
/* 71 */     if (getAbsolutePath().equals(f.getAbsolutePath())) {
/* 72 */       return true;
/*    */     }
/* 74 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/MyFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */