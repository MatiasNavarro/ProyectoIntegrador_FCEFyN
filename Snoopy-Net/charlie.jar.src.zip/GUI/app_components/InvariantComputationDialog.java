/*      */ package GUI.app_components;
/*      */ 
/*      */ import GUI.IDirector;
/*      */ import GUI.debug.DebugCounter;
/*      */ import GUI.io.FileSaver;
/*      */ import GUI.preference.Preference;
/*      */ import GUI.preference.PreferenceFactory;
/*      */ import GUI.util.ExportJCheckBoxMenuItem;
/*      */ import GUI.util.TextFile;
/*      */ import charlie.analyzer.AnalyzerManagerFactory;
/*      */ import charlie.analyzer.Initiator;
/*      */ import charlie.analyzer.OptionSet;
/*      */ import charlie.analyzer.algorithm.GaussAlgorithm;
/*      */ import charlie.analyzer.invariant.DependentSet;
/*      */ import charlie.analyzer.invariant.DependentSetAnalyzer;
/*      */ import charlie.analyzer.invariant.DependentSetOptions;
/*      */ import charlie.analyzer.invariant.InvOptions;
/*      */ import charlie.analyzer.invariant.InvParser;
/*      */ import charlie.analyzer.invariant.InvariantAnalyzer;
/*      */ import charlie.analyzer.invariant.InvariantSet;
/*      */ import charlie.analyzer.invariant.PInvariantSet;
/*      */ import charlie.analyzer.invariant.RankAnalyzer;
/*      */ import charlie.analyzer.invariant.RankIncidenceMatrixOptionSet;
/*      */ import charlie.analyzer.invariant.RankResultSet;
/*      */ import charlie.analyzer.invariant.StructurallyBoundedAnalyzer;
/*      */ import charlie.analyzer.invariant.StructurallyBoundedResultSet;
/*      */ import charlie.analyzer.invariant.TInvariantSet;
/*      */ import charlie.pn.Out;
/*      */ import charlie.pn.PlaceTransitionNetUtils;
/*      */ import charlie.pn.Results;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.MouseInfo;
/*      */ import java.awt.Point;
/*      */ import java.awt.PointerInfo;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.io.File;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javax.swing.AbstractAction;
/*      */ import javax.swing.ButtonGroup;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JCheckBoxMenuItem;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JRadioButton;
/*      */ import javax.swing.JTextArea;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.filechooser.FileFilter;
/*      */ import javax.swing.filechooser.FileNameExtensionFilter;
/*      */ import layout.TableLayout;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ public class InvariantComputationDialog
/*      */   extends ComputationalDialog
/*      */ {
/*   71 */   private static final Log LOG = LogFactory.getLog(InvariantComputationDialog.class);
/*      */   
/*      */   private static final String TINV_EXT = "_T.inv";
/*      */   
/*      */   private static final String PINV_EXT = "_P.inv";
/*      */   private static final long serialVersionUID = 1L;
/*   77 */   private JRadioButton jRadioButtonPInvariants = null;
/*   78 */   private JRadioButton jRadioButtonTInvariants = null;
/*   79 */   private JRadioButton jRadioButtonRankIncidence = null;
/*   80 */   private JRadioButton jRadioButtonStructurallyBounded = null;
/*   81 */   private JButton jButtonLoadInvariants = null;
/*   82 */   private JButton exportButton = null;
/*      */   private boolean loadedFlag = false;
/*   84 */   private JCheckBox jCheckBoxDependentSets = null;
/*   85 */   private JButton jButtonCompute = null;
/*   86 */   private JButton jButtonIncMatlab = null;
/*   87 */   private JButton dependentSetOptionsButton = null;
/*   88 */   private JButton invariantOptionsButton = null;
/*   89 */   private TInvariantSet tInvariants = null;
/*   90 */   private PInvariantSet pInvariants = null;
/*      */ 
/*      */   
/*   93 */   private JCheckBoxMenuItem deleteTrivialInvariants = null;
/*   94 */   private JCheckBoxMenuItem checkCoverage = null;
/*   95 */   private JCheckBoxMenuItem checkStrongCoverage = null;
/*   96 */   private ExportJCheckBoxMenuItem sdsFileItem = null;
/*   97 */   private ExportJCheckBoxMenuItem adsFileItem = null;
/*   98 */   private ExportJCheckBoxMenuItem adsConFileItem = null;
/*   99 */   private ExportJCheckBoxMenuItem invExportFileItem = null;
/*      */ 
/*      */   
/*  102 */   private JCheckBoxMenuItem strongDependentSets = null;
/*  103 */   private JCheckBoxMenuItem abstractDependentSets = null;
/*  104 */   private JCheckBoxMenuItem connectedADS = null;
/*      */   
/*  106 */   private Initiator thisInitiator = null;
/*      */   
/*      */   public InvariantComputationDialog(IDirector director) {
/*  109 */     super(director);
/*      */     
/*  111 */     this.thisInitiator = this;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void handlePlaceTransitionNetNull() {
/*  116 */     enableControls(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handlePlaceTransitionNetNotNull() {
/*  123 */     this.sdsFileItem.setFile(getPN().getName() + ".sds", FileSaver.lastSaveDir);
/*  124 */     this.adsConFileItem.setFile(getPN().getName() + ".cads", FileSaver.lastSaveDir);
/*      */     
/*  126 */     this.adsFileItem.setFile(getPN().getName() + ".ads", FileSaver.lastSaveDir);
/*  127 */     if (this.jRadioButtonPInvariants.isSelected()) {
/*  128 */       this.invExportFileItem.setFile(getPN().getName() + "_P.inv", FileSaver.lastSaveDir);
/*      */     } else {
/*      */       
/*  131 */       this.invExportFileItem.setFile(getPN().getName() + "_T.inv", FileSaver.lastSaveDir);
/*      */     } 
/*      */ 
/*      */     
/*  135 */     enableControls(true);
/*      */   }
/*      */ 
/*      */   
/*      */   public void initialize() {
/*  140 */     double[][] size = { { 5.0D, -1.0D, 130.0D, 5.0D }, { 5.0D, 25.0D, 25.0D, 25.0D, 25.0D, 25.0D, 25.0D, 25.0D, 25.0D, 5.0D } };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  145 */     LOG.debug("InvariantComputationDialog: registering InvariantAnalyzer");
/*  146 */     InvariantAnalyzer.register();
/*  147 */     LOG.debug("InvariantComputationDialog: InvariantAnalyzer registered");
/*  148 */     LOG.debug("InvariantComputationDialog: registering DependentSetAnalyzer");
/*  149 */     DependentSetAnalyzer.register();
/*  150 */     LOG.debug("InvariantComputationDialog: DependentSetAnalyzer registered");
/*  151 */     RankAnalyzer.register();
/*  152 */     LOG.debug("InvariantComputationDialog: RankAnalyzer registered");
/*  153 */     StructurallyBoundedAnalyzer.register();
/*  154 */     LOG.debug("InvariantComputationDialog: StructurallyBoundedAnalyzer registered");
/*  155 */     TableLayout layout = new TableLayout(size);
/*      */     
/*  157 */     setLayout((LayoutManager)layout);
/*  158 */     add(getJRadioButtonRankIncidenceMatrix(), "1,1,2,1");
/*  159 */     add(getJRadioButtonStructurallyBounded(), "1,2,2,2");
/*  160 */     add(getJRadioButtonPInvariants(), "1,3");
/*  161 */     add(getLoadInvariantsButton(), "2,3");
/*  162 */     add(getJRadioButtonTInvariants(), "1,4");
/*  163 */     add(getJButtonInvariantOptions(), "2,4");
/*  164 */     createExportButton();
/*  165 */     add(getJCheckBoxDependentSets(), "1,6");
/*  166 */     add(getJButtonDependentSetOptions(), "2,6");
/*  167 */     this.dependentSetOptionsButton.setEnabled(false);
/*  168 */     add(getJButtonCompute(), "1,7,2,7");
/*  169 */     add(getJButtonMatlab(), "1,8,2,8");
/*  170 */     Dimension d = layout.preferredLayoutSize(this);
/*  171 */     setSize(d);
/*  172 */     setPreferredSize(d);
/*      */     
/*  174 */     ButtonGroup group = new ButtonGroup();
/*  175 */     group.add(this.jRadioButtonPInvariants);
/*  176 */     group.add(this.jRadioButtonTInvariants);
/*  177 */     group.add(this.jRadioButtonRankIncidence);
/*  178 */     group.add(this.jRadioButtonStructurallyBounded);
/*      */     
/*  180 */     this.jRadioButtonRankIncidence.setSelected(true);
/*      */     
/*  182 */     enableControls(false);
/*      */   }
/*      */   
/*      */   private void enableControls(boolean b) {
/*  186 */     this.jRadioButtonPInvariants.setEnabled(b);
/*  187 */     this.jRadioButtonTInvariants.setEnabled(b);
/*  188 */     this.jRadioButtonRankIncidence.setEnabled(b);
/*  189 */     this.jRadioButtonStructurallyBounded.setEnabled(b);
/*  190 */     this.exportButton.setEnabled(b);
/*  191 */     this.jButtonCompute.setEnabled(b);
/*  192 */     this.jButtonIncMatlab.setEnabled(b);
/*      */     
/*  194 */     setDependentSetsEnabled(b);
/*      */   }
/*      */ 
/*      */   
/*      */   private JButton createExportButton() {
/*  199 */     this.exportButton = new JButton(new AbstractAction()
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/*  207 */             String invTitle = "minimal semipositive";
/*  208 */             if (InvariantComputationDialog.this.jRadioButtonPInvariants.isSelected()) {
/*  209 */               if (InvariantComputationDialog.this.pInvariants != null && InvariantComputationDialog.this.pInvariants.rows() > 0) {
/*      */ 
/*      */                 
/*  212 */                 File exportFile = new File(FileSaver.lastSaveDir + System.getProperty("file.separator") + InvariantComputationDialog.this.getPN().getName() + "_P.inv");
/*  213 */                 FileSaver fs = new FileSaver();
/*  214 */                 exportFile = fs.showSaveDialog(exportFile, "", ".inv");
/*  215 */                 if (exportFile != null) {
/*  216 */                   InvariantComputationDialog.this.pInvariants.writeToFile(exportFile.getPath(), invTitle + " place invariants=");
/*      */                 
/*      */                 }
/*      */               
/*      */               }
/*      */               else {
/*      */ 
/*      */                 
/*  224 */                 File exportFile = new File(FileSaver.lastSaveDir + System.getProperty("file.separator") + InvariantComputationDialog.this.getPN().getName() + "_P.inv");
/*  225 */                 FileSaver fs = new FileSaver();
/*  226 */                 fs.showSaveDialog(exportFile, "", ".inv");
/*      */               } 
/*      */             }
/*  229 */             if (InvariantComputationDialog.this.jRadioButtonTInvariants.isSelected()) {
/*  230 */               if (InvariantComputationDialog.this.tInvariants != null && InvariantComputationDialog.this.tInvariants.rows() > 0) {
/*      */ 
/*      */                 
/*  233 */                 File exportFile = new File(FileSaver.lastSaveDir + System.getProperty("file.separator") + InvariantComputationDialog.this.getPN().getName() + "_T.inv");
/*  234 */                 FileSaver fs = new FileSaver();
/*  235 */                 exportFile = fs.showSaveDialog(exportFile, "", ".inv");
/*  236 */                 if (exportFile != null) {
/*  237 */                   InvariantComputationDialog.this.tInvariants.writeToFile(exportFile.getPath(), invTitle + " transition invariants=");
/*      */                 }
/*      */               }
/*  240 */               else if (InvariantComputationDialog.this.tInvariants == null || InvariantComputationDialog.this.tInvariants.rows() == 0) {
/*  241 */                 InvariantComputationDialog.LOG.warn("No  transition invariants to export, please load/compute t-invarinats before");
/*      */                 
/*  243 */                 JOptionPane.showMessageDialog(null, "No  transition invariants to export, please load/compute t-invarinats before");
/*      */               } 
/*      */             }
/*      */             
/*  247 */             if (InvariantComputationDialog.this.jRadioButtonRankIncidence.isSelected());
/*      */ 
/*      */             
/*  250 */             if (InvariantComputationDialog.this.jRadioButtonStructurallyBounded.isSelected());
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/*  256 */     return this.exportButton;
/*      */   }
/*      */ 
/*      */   
/*      */   private JButton getLoadInvariantsButton() {
/*  261 */     this.jButtonLoadInvariants = new JButton(new AbstractAction()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/*  268 */             FileSaver fs = new FileSaver();
/*  269 */             fs.addChoosableFileFilter(new FileNameExtensionFilter("P-Invariant file _P.inv", new String[] { "inv" }));
/*  270 */             fs.addChoosableFileFilter(new FileNameExtensionFilter("t-Invariant file _T.inv", new String[] { "inv" }));
/*  271 */             fs.addChoosableFileFilter(new FileNameExtensionFilter("Invariant file .inv", new String[] { "inv" }));
/*  272 */             File invFile = fs.showOpenDialog(null, null);
/*  273 */             if (invFile != null) {
/*  274 */               InvParser ip = new InvParser(InvariantComputationDialog.this.getPN(), invFile.getPath());
/*      */               try {
/*  276 */                 ip.parse();
/*  277 */               } catch (Exception ex) {
/*  278 */                 JOptionPane.showMessageDialog(null, "Could not load invariant file, check contents!\nError message: " + ex
/*      */                     
/*  280 */                     .getMessage());
/*      */                 return;
/*      */               } 
/*  283 */               if (ip.transitions()) {
/*  284 */                 InvariantComputationDialog.this.tInvariants = (TInvariantSet)ip.getInvariants();
/*  285 */                 if (InvariantComputationDialog.this.tInvariants != null) {
/*  286 */                   Out.println("loaded t-invariants from file: " + invFile
/*  287 */                       .getName() + "\n# of invariants: " + InvariantComputationDialog.this
/*      */                       
/*  289 */                       .tInvariants.rows());
/*  290 */                   InvariantComputationDialog.this.jRadioButtonTInvariants.setSelected(true);
/*  291 */                   JOptionPane.showMessageDialog(null, "loaded t-invariants from file: " + invFile
/*      */                       
/*  293 */                       .getName() + "\n# of invariants: " + InvariantComputationDialog.this
/*      */                       
/*  295 */                       .tInvariants.rows());
/*  296 */                   InvariantComputationDialog.this.loadedFlag = true;
/*      */                 } 
/*      */               } else {
/*  299 */                 InvariantComputationDialog.this.pInvariants = (PInvariantSet)ip.getInvariants();
/*  300 */                 if (InvariantComputationDialog.this.pInvariants != null) {
/*  301 */                   Out.println("loaded p-invariants from file: " + invFile
/*  302 */                       .getName() + "\n# of invariants: " + InvariantComputationDialog.this
/*      */                       
/*  304 */                       .pInvariants.rows());
/*  305 */                   InvariantComputationDialog.this.jRadioButtonPInvariants.setSelected(true);
/*  306 */                   JOptionPane.showMessageDialog(null, "loaded p-invariants from file: " + invFile
/*      */                       
/*  308 */                       .getName() + "\n# of invariants: " + InvariantComputationDialog.this
/*      */                       
/*  310 */                       .pInvariants.rows());
/*  311 */                   InvariantComputationDialog.this.loadedFlag = true;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  321 */     return this.jButtonLoadInvariants;
/*      */   }
/*      */   
/*      */   private String createPath(File f) {
/*  325 */     if (f == null) {
/*  326 */       return FileSaver.lastSaveDir;
/*      */     }
/*  328 */     return f.getParent();
/*      */   }
/*      */ 
/*      */   
/*      */   private String createFileName(File file, boolean p) {
/*      */     String filename;
/*  334 */     if (file != null) {
/*      */       
/*  336 */       filename = file.getName();
/*  337 */       int extensionIndex = filename.indexOf("_P.inv");
/*  338 */       if (extensionIndex < 0) {
/*  339 */         extensionIndex = filename.indexOf("_T.inv");
/*      */       }
/*  341 */       if (extensionIndex < 0) {
/*      */         
/*  343 */         filename = FileSaver.lastSaveDir + File.separator + getPN().getName();
/*      */       } else {
/*  345 */         filename = filename.substring(0, extensionIndex);
/*      */       } 
/*      */     } else {
/*  348 */       filename = getPN().getName();
/*      */     } 
/*  350 */     if (p) {
/*  351 */       filename = filename + "_P.inv";
/*      */     } else {
/*  353 */       filename = filename + "_T.inv";
/*      */     } 
/*      */     
/*  356 */     return filename;
/*      */   }
/*      */ 
/*      */   
/*      */   private JRadioButton getJRadioButtonPInvariants() {
/*  361 */     this.jRadioButtonPInvariants = new JRadioButton(new AbstractAction("p-invariants")
/*      */         {
/*      */           public void actionPerformed(ActionEvent e) {
/*  364 */             JRadioButton b = (JRadioButton)e.getSource();
/*  365 */             if (b.isSelected()) {
/*      */ 
/*      */               
/*  368 */               InvariantComputationDialog.this.deleteTrivialInvariants.setEnabled(false);
/*      */               
/*  370 */               InvariantComputationDialog.this.checkStrongCoverage.setEnabled(false);
/*      */               
/*  372 */               InvariantComputationDialog.this.setDependentSetsEnabled(true);
/*      */               
/*  374 */               File file = InvariantComputationDialog.this.invExportFileItem.getFile();
/*  375 */               InvariantComputationDialog.this.invExportFileItem.setFile(InvariantComputationDialog.this.createFileName(file, true), InvariantComputationDialog.this.createPath(file));
/*      */             } 
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  381 */     return this.jRadioButtonPInvariants;
/*      */   }
/*      */ 
/*      */   
/*      */   private JRadioButton getJRadioButtonTInvariants() {
/*  386 */     this.jRadioButtonTInvariants = new JRadioButton(new AbstractAction("t-invariants")
/*      */         {
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/*  390 */             JRadioButton b = (JRadioButton)e.getSource();
/*  391 */             if (b.isSelected()) {
/*      */               
/*  393 */               InvariantComputationDialog.this.deleteTrivialInvariants.setEnabled(true);
/*  394 */               InvariantComputationDialog.this.checkStrongCoverage.setEnabled(true);
/*      */               
/*  396 */               InvariantComputationDialog.this.setDependentSetsEnabled(true);
/*      */               
/*  398 */               File file = InvariantComputationDialog.this.invExportFileItem.getFile();
/*  399 */               InvariantComputationDialog.this.invExportFileItem.setFile(InvariantComputationDialog.this.createFileName(file, false), InvariantComputationDialog.this.createPath(file));
/*      */             } 
/*      */           }
/*      */         });
/*  403 */     return this.jRadioButtonTInvariants;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JRadioButton getJRadioButtonRankIncidenceMatrix() {
/*  413 */     this.jRadioButtonRankIncidence = new JRadioButton(new AbstractAction("rank theorem")
/*      */         {
/*      */           public void actionPerformed(ActionEvent e) {
/*  416 */             JRadioButton b = (JRadioButton)e.getSource();
/*  417 */             if (b.isSelected()) {
/*  418 */               InvariantComputationDialog.this.setDependentSetsEnabled(false);
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  423 */     return this.jRadioButtonRankIncidence;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JRadioButton getJRadioButtonStructurallyBounded() {
/*  433 */     this.jRadioButtonStructurallyBounded = new JRadioButton(new AbstractAction("check structural boundedness")
/*      */         {
/*      */           public void actionPerformed(ActionEvent e) {
/*  436 */             JRadioButton b = (JRadioButton)e.getSource();
/*  437 */             if (b.isSelected()) {
/*  438 */               InvariantComputationDialog.this.setDependentSetsEnabled(false);
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  443 */     return this.jRadioButtonStructurallyBounded;
/*      */   }
/*      */ 
/*      */   
/*      */   private JButton getJButtonInvariantOptions() {
/*  448 */     JButton invariantOptions = new JButton("options");
/*  449 */     final JPopupMenu menu = new JPopupMenu();
/*  450 */     menu.add(new JMenuItem("invariant computation options"));
/*  451 */     menu.addSeparator();
/*      */     
/*  453 */     this.deleteTrivialInvariants = new JCheckBoxMenuItem("delete trivial invariants");
/*      */     
/*  455 */     menu.add(this.deleteTrivialInvariants);
/*  456 */     this.checkCoverage = new JCheckBoxMenuItem(new AbstractAction()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/*  463 */             JCheckBoxMenuItem i = (JCheckBoxMenuItem)e.getSource();
/*  464 */             if (!i.getState()) {
/*  465 */               InvariantComputationDialog.this.checkStrongCoverage.setState(false);
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  470 */     this.checkCoverage.setState(true);
/*  471 */     menu.add(this.checkCoverage);
/*  472 */     this.checkStrongCoverage = new JCheckBoxMenuItem(new AbstractAction()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/*  479 */             JCheckBoxMenuItem i = (JCheckBoxMenuItem)e.getSource();
/*  480 */             if (i.getState()) {
/*  481 */               InvariantComputationDialog.this.checkCoverage.setState(true);
/*      */             }
/*      */           }
/*      */         });
/*      */     
/*  486 */     menu.add(this.checkStrongCoverage);
/*  487 */     this.invExportFileItem = new ExportJCheckBoxMenuItem("export invariants to file", "invariant.inv", "export invariants to file:", FileSaver.lastSaveDir);
/*      */ 
/*      */     
/*  490 */     menu.add((JMenuItem)this.invExportFileItem);
/*  491 */     menu.addSeparator();
/*  492 */     menu.add(new JMenuItem(new AbstractAction("close")
/*      */           {
/*      */             public void actionPerformed(ActionEvent e) {
/*  495 */               menu.setVisible(false);
/*      */             }
/*      */           }));
/*      */ 
/*      */     
/*  500 */     menu.addFocusListener(new FocusListener()
/*      */         {
/*      */           public void focusGained(FocusEvent e) {}
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void focusLost(FocusEvent e) {
/*  508 */             menu.setVisible(false);
/*      */           }
/*      */         });
/*      */     
/*  512 */     invariantOptions.setComponentPopupMenu(menu);
/*  513 */     invariantOptions.setAction(new AbstractAction("options")
/*      */         {
/*      */           public void actionPerformed(ActionEvent e) {
/*  516 */             JButton b = (JButton)e.getSource();
/*  517 */             JPopupMenu m = b.getComponentPopupMenu();
/*  518 */             PointerInfo info = MouseInfo.getPointerInfo();
/*  519 */             Point p = info.getLocation();
/*  520 */             p.setLocation(p.getX() - 10.0D, p.getY() - 10.0D);
/*  521 */             if (m != null) {
/*  522 */               m.setLocation(p);
/*  523 */               m.pack();
/*  524 */               m.setVisible(true);
/*  525 */               m.grabFocus();
/*      */             } 
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  531 */     this.invariantOptionsButton = invariantOptions;
/*  532 */     return invariantOptions;
/*      */   }
/*      */ 
/*      */   
/*      */   private JCheckBox getJCheckBoxDependentSets() {
/*  537 */     this.jCheckBoxDependentSets = new JCheckBox(new AbstractAction("dependent sets")
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/*  547 */             if (InvariantComputationDialog.this.dependentSetOptionsButton != null) {
/*  548 */               if (((JCheckBox)e.getSource()).isSelected()) {
/*  549 */                 InvariantComputationDialog.this.dependentSetOptionsButton.setEnabled(true);
/*      */               } else {
/*  551 */                 InvariantComputationDialog.this.dependentSetOptionsButton.setEnabled(false);
/*      */               } 
/*      */             }
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  560 */     this.jCheckBoxDependentSets.setEnabled(false);
/*  561 */     return this.jCheckBoxDependentSets;
/*      */   }
/*      */ 
/*      */   
/*      */   private JButton getJButtonDependentSetOptions() {
/*  566 */     this.dependentSetOptionsButton = new JButton("dependent set options");
/*  567 */     final JPopupMenu menu = new JPopupMenu();
/*  568 */     menu.add(new JMenuItem("depentent set computation options"));
/*  569 */     menu.addSeparator();
/*  570 */     this.strongDependentSets = new JCheckBoxMenuItem(new AbstractAction()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/*  577 */             JCheckBoxMenuItem i = (JCheckBoxMenuItem)e.getSource();
/*  578 */             if (i.getState()) {
/*  579 */               InvariantComputationDialog.this.abstractDependentSets.setState(true);
/*  580 */             } else if (!i.getState() && !InvariantComputationDialog.this.connectedADS.getState()) {
/*  581 */               InvariantComputationDialog.this.abstractDependentSets.setState(false);
/*      */             } 
/*      */           }
/*      */         });
/*      */     
/*  586 */     menu.add(this.strongDependentSets);
/*  587 */     this.sdsFileItem = new ExportJCheckBoxMenuItem("export sds to file", new File("strong_ds.sds"), "strong dependent sets file: ");
/*      */     
/*  589 */     menu.add((JMenuItem)this.sdsFileItem);
/*  590 */     this.abstractDependentSets = new JCheckBoxMenuItem(new AbstractAction()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/*  597 */             JCheckBoxMenuItem i = (JCheckBoxMenuItem)e.getSource();
/*  598 */             if (!i.getState()) {
/*  599 */               InvariantComputationDialog.this.strongDependentSets.setState(false);
/*  600 */               InvariantComputationDialog.this.connectedADS.setState(false);
/*      */             } 
/*      */           }
/*      */         });
/*      */     
/*  605 */     this.abstractDependentSets.setSelected(true);
/*  606 */     menu.add(this.abstractDependentSets);
/*  607 */     this.adsFileItem = new ExportJCheckBoxMenuItem("export ads to file", new File("abstract_ds.ads"), "abstract dependent sets file: ");
/*      */     
/*  609 */     menu.add((JMenuItem)this.adsFileItem);
/*  610 */     this.connectedADS = new JCheckBoxMenuItem(new AbstractAction()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/*  617 */             JCheckBoxMenuItem i = (JCheckBoxMenuItem)e.getSource();
/*  618 */             if (i.getState()) {
/*  619 */               InvariantComputationDialog.this.abstractDependentSets.setState(true);
/*  620 */             } else if (!i.getState() && !InvariantComputationDialog.this.strongDependentSets.getState()) {
/*  621 */               InvariantComputationDialog.this.abstractDependentSets.setState(false);
/*      */             } 
/*      */           }
/*      */         });
/*      */     
/*  626 */     menu.add(this.connectedADS);
/*  627 */     this.adsConFileItem = new ExportJCheckBoxMenuItem("export cads to file", new File("connected_abstrac_ds.cads"), "connected abstract dependent sets file: ");
/*      */ 
/*      */     
/*  630 */     menu.add((JMenuItem)this.adsConFileItem);
/*  631 */     menu.addSeparator();
/*  632 */     menu.add(new JMenuItem(new AbstractAction("close")
/*      */           {
/*      */             public void actionPerformed(ActionEvent e) {
/*  635 */               menu.setVisible(false);
/*      */             }
/*      */           }));
/*      */     
/*  639 */     this.dependentSetOptionsButton.setComponentPopupMenu(menu);
/*  640 */     this.dependentSetOptionsButton.setAction(new AbstractAction("dependent set options")
/*      */         {
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/*  644 */             JButton b = (JButton)e.getSource();
/*  645 */             JPopupMenu m = b.getComponentPopupMenu();
/*  646 */             PointerInfo info = MouseInfo.getPointerInfo();
/*  647 */             Point p = info.getLocation();
/*  648 */             p.setLocation(p.getX() - 10.0D, p.getY() - 10.0D);
/*  649 */             if (m != null) {
/*  650 */               m.setLocation(p);
/*  651 */               m.pack();
/*  652 */               m.setVisible(true);
/*      */             } else {
/*  654 */               JOptionPane.showMessageDialog(null, "no popupmenu");
/*      */             } 
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/*  661 */     this.dependentSetOptionsButton.setToolTipText("dependent set options");
/*  662 */     return this.dependentSetOptionsButton;
/*      */   }
/*      */ 
/*      */   
/*      */   private JButton getJButtonMatlab() {
/*  667 */     JButton export = new JButton("export incidence matrix");
/*      */     
/*  669 */     MouseListener exportListener = new MouseAdapter()
/*      */       {
/*      */         public void mouseReleased(MouseEvent _m)
/*      */         {
/*  673 */           if (SwingUtilities.isLeftMouseButton(_m)) {
/*  674 */             showExport();
/*  675 */           } else if (SwingUtilities.isRightMouseButton(_m)) {
/*      */             
/*  677 */             final JPopupMenu menu = new JPopupMenu();
/*  678 */             JMenuItem exportMenuItem = new JMenuItem("export incidence matrix");
/*  679 */             exportMenuItem.addActionListener(new ActionListener()
/*      */                 {
/*      */                   public void actionPerformed(ActionEvent e) {
/*  682 */                     menu.setVisible(false);
/*  683 */                     InvariantComputationDialog.null.this.showExport();
/*      */                   }
/*      */                 });
/*      */             
/*  687 */             JMenuItem showMenuItem = new JMenuItem("show incidence matrix");
/*  688 */             showMenuItem.addActionListener(new ActionListener()
/*      */                 {
/*      */                   public void actionPerformed(ActionEvent e) {
/*  691 */                     menu.setVisible(false);
/*  692 */                     InvariantComputationDialog.null.this.showMatrix(false, false);
/*      */                   }
/*      */                 });
/*      */             
/*  696 */             JMenuItem showNamesMenuItem = new JMenuItem("show incidence matrix (with names)");
/*  697 */             showNamesMenuItem.addActionListener(new ActionListener()
/*      */                 {
/*      */                   public void actionPerformed(ActionEvent e) {
/*  700 */                     menu.setVisible(false);
/*  701 */                     InvariantComputationDialog.null.this.showMatrix(true, false);
/*      */                   }
/*      */                 });
/*      */             
/*  705 */             JMenuItem showRankMenuItem = new JMenuItem("show incidence matrix (and compute rank)");
/*  706 */             showRankMenuItem.addActionListener(new ActionListener()
/*      */                 {
/*      */                   public void actionPerformed(ActionEvent e) {
/*  709 */                     menu.setVisible(false);
/*  710 */                     InvariantComputationDialog.null.this.showMatrix(false, true);
/*      */                   }
/*      */                 });
/*      */ 
/*      */             
/*  715 */             JMenuItem closeMenuItem = new JMenuItem("close");
/*  716 */             closeMenuItem.addActionListener(new ActionListener()
/*      */                 {
/*      */                   public void actionPerformed(ActionEvent e) {
/*  719 */                     menu.setVisible(false);
/*      */                   }
/*      */                 });
/*      */             
/*  723 */             menu.add(exportMenuItem);
/*  724 */             menu.add(showMenuItem);
/*  725 */             menu.add(showNamesMenuItem);
/*  726 */             menu.add(showRankMenuItem);
/*  727 */             menu.addSeparator();
/*  728 */             menu.add(closeMenuItem);
/*      */             
/*  730 */             menu.show(_m.getComponent(), _m.getX(), _m.getY());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private void showMatrix(boolean _showNames, boolean _computeRank) {
/*  740 */           JDialog dialog = new JDialog();
/*  741 */           dialog.setModal(false);
/*  742 */           dialog.setTitle("Incidence Matrix");
/*  743 */           dialog.setSize(320, 200);
/*  744 */           dialog.setLocationRelativeTo((Component)null);
/*      */           
/*  746 */           HumanReadableFormatFileFilter humanReadable = new HumanReadableFormatFileFilter();
/*  747 */           String content = humanReadable.getContent(_showNames);
/*      */ 
/*      */           
/*  750 */           PlaceTransitionNetUtils pnUtils = new PlaceTransitionNetUtils(InvariantComputationDialog.this.getPN());
/*  751 */           int[][] im = pnUtils.getIncidenceMatrix();
/*      */           
/*  753 */           if (_computeRank) {
/*  754 */             GaussAlgorithm algo = new GaussAlgorithm(im);
/*  755 */             algo.solve();
/*  756 */             content = content + "\n\nrank: " + algo.getRank();
/*  757 */             content = content + "\n#P: " + InvariantComputationDialog.this.getPN().places();
/*  758 */             content = content + "\n#T: " + InvariantComputationDialog.this.getPN().transitions();
/*      */           } 
/*      */           
/*  761 */           JTextArea textArea = new JTextArea();
/*  762 */           textArea.setText(content);
/*  763 */           textArea.setFont(Font.getFont("Monospace"));
/*      */           
/*  765 */           dialog.add(textArea);
/*  766 */           dialog.setVisible(true);
/*      */         }
/*      */         
/*      */         private void showExport() {
/*  770 */           if (InvariantComputationDialog.this.getPN() != null) {
/*      */             int lastUsedFilter;
/*  772 */             File file = new File(FileSaver.lastSaveDir + File.separator + InvariantComputationDialog.this.getPN().getName() + "_incidenceMatrix.txt");
/*      */             
/*  774 */             JFileChooser fs = new JFileChooser();
/*  775 */             fs.setAcceptAllFileFilterUsed(false);
/*      */             
/*  777 */             int counter = 0;
/*      */             
/*      */             try {
/*  780 */               lastUsedFilter = Integer.parseInt(PreferenceFactory.getPreferenceProperties().getProperty(Preference.IM_LAST_FILE_FORMAT_FILTER));
/*  781 */             } catch (NumberFormatException nfe) {
/*      */               
/*  783 */               lastUsedFilter = 0;
/*      */ 
/*      */               
/*  786 */               InvariantComputationDialog.LOG.error(nfe.getMessage(), nfe);
/*      */             } 
/*      */             
/*  789 */             for (FileFilter ff : getFileFormatList()) {
/*  790 */               fs.addChoosableFileFilter(ff);
/*  791 */               if (counter == lastUsedFilter) {
/*  792 */                 fs.setFileFilter(ff);
/*      */               }
/*  794 */               counter++;
/*      */             } 
/*  796 */             fs.setSelectedFile(file);
/*      */             
/*  798 */             int answ = fs.showSaveDialog(null);
/*  799 */             if (answ == 0) {
/*  800 */               file = fs.getSelectedFile();
/*      */               
/*  802 */               FormatFileFilter filter = (FormatFileFilter)fs.getFileFilter();
/*      */               
/*  804 */               if (!file.getName().endsWith(filter.getExtension()))
/*      */               {
/*  806 */                 file = new File(file.getAbsolutePath() + filter.getExtension());
/*      */               }
/*      */               
/*  809 */               TextFile.writeToFile(file, filter.getContent(true), true);
/*      */             } 
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         abstract class FormatFileFilter
/*      */           extends FileFilter
/*      */         {
/*      */           private final String extension;
/*      */ 
/*      */ 
/*      */           
/*      */           private final String description;
/*      */ 
/*      */ 
/*      */           
/*      */           public String getExtension() {
/*  829 */             return this.extension;
/*      */           }
/*      */ 
/*      */           
/*      */           public abstract String getContent(boolean param2Boolean);
/*      */           
/*      */           public boolean accept(File _file) {
/*  836 */             if (_file.isDirectory()) {
/*  837 */               return true;
/*      */             }
/*  839 */             if (_file.getName().toLowerCase().endsWith(this.extension.toLowerCase())) {
/*  840 */               return true;
/*      */             }
/*      */             
/*  843 */             return false;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getDescription() {
/*  848 */             return this.description;
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         final class MatlabFormatFileFilter
/*      */           extends FormatFileFilter
/*      */         {
/*      */           public String getContent(boolean _names) {
/*  871 */             PlaceTransitionNetUtils pnUtils = new PlaceTransitionNetUtils(InvariantComputationDialog.this.getPN());
/*      */             
/*  873 */             int[][] im = pnUtils.getIncidenceMatrix();
/*  874 */             StringBuffer buffer = new StringBuffer();
/*      */             
/*  876 */             if (_names) {
/*      */               
/*  878 */               buffer.append("placeNames = {"); int j;
/*  879 */               for (j = 0; j < InvariantComputationDialog.this.getPN().places(); j++) {
/*  880 */                 buffer.append(InvariantComputationDialog.this.getPN().getPlaceByIndex(j).getName());
/*  881 */                 buffer.append(" ");
/*      */               } 
/*  883 */               buffer.append("};\n");
/*      */               
/*  885 */               buffer.append("transitionNames = {");
/*  886 */               for (j = 0; j < InvariantComputationDialog.this.getPN().transitions(); j++) {
/*  887 */                 buffer.append(InvariantComputationDialog.this.getPN().getTransition((short)j).getName());
/*  888 */                 buffer.append(" ");
/*      */               } 
/*  890 */               buffer.append("};\n");
/*      */             } 
/*      */ 
/*      */             
/*  894 */             buffer.append("C=[\n");
/*  895 */             for (int i = 0; i < im.length; i++) {
/*  896 */               for (int j = 0; j < (im[0]).length; j++) {
/*  897 */                 buffer.append(Integer.toString(im[i][j]));
/*  898 */                 buffer.append(" ");
/*      */               } 
/*  900 */               buffer.append(";\n");
/*      */             } 
/*  902 */             buffer.append("];\n");
/*      */             
/*  904 */             return buffer.toString();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         final class CSVFormatFileFilter
/*      */           extends FormatFileFilter
/*      */         {
/*  915 */           private char separator = ',';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void setSeparator(char _separator) {
/*  927 */             this.separator = _separator;
/*      */           }
/*      */ 
/*      */           
/*      */           public String getContent(boolean _names) {
/*  932 */             return getCommaSeparatedValueContent(_names, this.separator);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private String getCommaSeparatedValueContent(boolean _names, char _separator) {
/*  944 */             PlaceTransitionNetUtils pnUtils = new PlaceTransitionNetUtils(InvariantComputationDialog.this.getPN());
/*      */             
/*  946 */             int[][] im = pnUtils.getIncidenceMatrix();
/*  947 */             StringBuffer buffer = new StringBuffer();
/*      */             
/*  949 */             if (_names) {
/*      */               
/*  951 */               buffer.append("transition/place");
/*  952 */               buffer.append(_separator);
/*  953 */               for (int j = 0; j < InvariantComputationDialog.this.getPN().places(); j++) {
/*  954 */                 buffer.append(InvariantComputationDialog.this.getPN().getPlaceByIndex(j).getName());
/*  955 */                 buffer.append(_separator);
/*      */               } 
/*  957 */               buffer.append("\n");
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  962 */             for (int i = 0; i < im.length; i++) {
/*      */               
/*  964 */               if (_names) {
/*  965 */                 buffer.append(InvariantComputationDialog.this.getPN().getTransition(i).getName());
/*  966 */                 buffer.append(_separator);
/*      */               } 
/*  968 */               for (int j = 0; j < (im[0]).length; j++) {
/*  969 */                 buffer.append(Integer.toString(im[i][j]));
/*  970 */                 buffer.append(_separator);
/*      */               } 
/*  972 */               buffer.append("\n");
/*      */             } 
/*      */             
/*  975 */             return buffer.toString();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         final class HumanReadableFormatFileFilter
/*      */           extends FormatFileFilter
/*      */         {
/*      */           public String getContent(boolean _names) {
/*  998 */             PlaceTransitionNetUtils pnUtils = new PlaceTransitionNetUtils(InvariantComputationDialog.this.getPN());
/*      */             
/* 1000 */             int[][] im = pnUtils.getIncidenceMatrix();
/*      */             
/* 1002 */             StringBuffer buffer = new StringBuffer();
/* 1003 */             if (_names) {
/*      */               
/* 1005 */               buffer.append("place/trans");
/* 1006 */               for (int j = 0; j < InvariantComputationDialog.this.getPN().transitions(); j++) {
/* 1007 */                 String name = InvariantComputationDialog.this.getPN().getTransition(j).getName();
/* 1008 */                 if (name == null || name.trim().equals("")) {
/* 1009 */                   name = InvariantComputationDialog.this.getPN().getTransition(j).getIdentifier();
/* 1010 */                   buffer.append(" ");
/*      */                 } 
/* 1012 */                 buffer.append(String.format("%5s", new Object[] { name }));
/* 1013 */                 buffer.append(" ");
/*      */               } 
/* 1015 */               buffer.append("\n");
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/* 1020 */             for (int i = 0; i < im.length; i++) {
/*      */               
/* 1022 */               if (_names) {
/* 1023 */                 String name = InvariantComputationDialog.this.getPN().getPlaceByIndex(i).getName();
/* 1024 */                 if (name == null || name.trim().equals("")) {
/* 1025 */                   name = InvariantComputationDialog.this.getPN().getPlaceByIndex(i).getIdentifier();
/*      */                 }
/* 1027 */                 buffer.append(String.format("%11s", new Object[] { name }));
/* 1028 */                 buffer.append(" ");
/*      */               } 
/* 1030 */               for (int j = 0; j < (im[0]).length; j++) {
/* 1031 */                 buffer.append(String.format("%5d", new Object[] { Integer.valueOf(im[i][j]) }));
/* 1032 */                 buffer.append(" ");
/*      */               } 
/* 1034 */               buffer.append("\n");
/*      */             } 
/*      */             
/* 1037 */             return buffer.toString();
/*      */           }
/*      */         }
/*      */         
/*      */         private List<FileFilter> getFileFormatList() {
/* 1042 */           List<FileFilter> fileFilterList = new ArrayList<>();
/* 1043 */           fileFilterList.add(new MatlabFormatFileFilter());
/* 1044 */           fileFilterList.add(new CSVFormatFileFilter());
/* 1045 */           fileFilterList.add(new HumanReadableFormatFileFilter());
/*      */           
/* 1047 */           return fileFilterList;
/*      */         }
/*      */       };
/*      */     
/* 1051 */     export.addMouseListener(exportListener);
/*      */     
/* 1053 */     this.jButtonIncMatlab = export;
/* 1054 */     return export;
/*      */   }
/*      */ 
/*      */   
/*      */   private JButton getJButtonCompute() {
/* 1059 */     JButton compute = new JButton(new AbstractAction("compute") {
/*      */           public void actionPerformed(ActionEvent e) {
/* 1061 */             OptionSet computeOptionSet = null;
/* 1062 */             Object target = null;
/* 1063 */             if (InvariantComputationDialog.this.getPN() != null) {
/* 1064 */               if (InvariantComputationDialog.this.jRadioButtonPInvariants.isSelected() || InvariantComputationDialog.this.jRadioButtonTInvariants.isSelected()) {
/* 1065 */                 OptionSet optionSet; PInvariantSet pInvariantSet; InvOptions io = new InvOptions();
/* 1066 */                 InvOptions invOptions1 = io;
/* 1067 */                 InvariantSet invariant = null;
/* 1068 */                 if (InvariantComputationDialog.this.loadedFlag) {
/* 1069 */                   InvariantComputationDialog.this.loadedFlag = false;
/* 1070 */                   if (InvariantComputationDialog.this.jRadioButtonTInvariants.isSelected()) {
/* 1071 */                     io.setComputeTInvariants(true);
/* 1072 */                     int answ = JOptionPane.showConfirmDialog(null, "Evaluate loaded t-invariants?", "Question", 0);
/*      */ 
/*      */                     
/* 1075 */                     if (answ == 0) {
/* 1076 */                       TInvariantSet tInvariantSet = InvariantComputationDialog.this.tInvariants;
/*      */                     } else {
/* 1078 */                       TInvariantSet tInvariantSet = new TInvariantSet();
/*      */                     } 
/*      */                   } 
/* 1081 */                   if (InvariantComputationDialog.this.jRadioButtonPInvariants.isSelected()) {
/* 1082 */                     io.setComputeTInvariants(false);
/* 1083 */                     int answ = JOptionPane.showConfirmDialog(null, "Evaluate loaded p-invariants?", "Question", 0);
/*      */ 
/*      */                     
/* 1086 */                     if (answ == 0) {
/* 1087 */                       pInvariantSet = InvariantComputationDialog.this.pInvariants;
/*      */                     } else {
/* 1089 */                       pInvariantSet = new PInvariantSet();
/*      */                     } 
/*      */                   } 
/* 1092 */                 } else if (InvariantComputationDialog.this.jRadioButtonTInvariants.isSelected() && 
/* 1093 */                   !InvariantComputationDialog.this.jRadioButtonPInvariants.isSelected()) {
/* 1094 */                   io.setComputeTInvariants(true);
/* 1095 */                   TInvariantSet tInvariantSet = new TInvariantSet();
/*      */                 } else {
/* 1097 */                   io.setComputeTInvariants(false);
/* 1098 */                   pInvariantSet = new PInvariantSet();
/*      */                 } 
/* 1100 */                 io.coverage = InvariantComputationDialog.this.checkCoverage.isSelected();
/* 1101 */                 io.extendedCoverage = InvariantComputationDialog.this.checkStrongCoverage.isSelected();
/* 1102 */                 io.deleteTrivial = InvariantComputationDialog.this.deleteTrivialInvariants.isSelected();
/* 1103 */                 io.exportFile = InvariantComputationDialog.this.invExportFileItem.isSelected() ? InvariantComputationDialog.this.invExportFileItem.getAbsoluteFileName() : null;
/* 1104 */                 io.setObjectToAnalyze(InvariantComputationDialog.this.getPN());
/* 1105 */                 io.setResultObject(pInvariantSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1117 */                 if (InvariantComputationDialog.this.jCheckBoxDependentSets.isSelected()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 1126 */                   String adsFile = InvariantComputationDialog.this.adsFileItem.isSelected() ? InvariantComputationDialog.this.adsFileItem.getAbsoluteFileName() : null;
/* 1127 */                   String sdsFile = InvariantComputationDialog.this.sdsFileItem.isSelected() ? InvariantComputationDialog.this.sdsFileItem.getAbsoluteFileName() : null;
/* 1128 */                   String adsConFile = InvariantComputationDialog.this.adsConFileItem.isSelected() ? InvariantComputationDialog.this.adsConFileItem.getAbsoluteFileName() : null;
/*      */                   
/* 1130 */                   io
/*      */ 
/*      */ 
/*      */                     
/* 1134 */                     .nextStage = (OptionSet)new DependentSetOptions(InvariantComputationDialog.this.abstractDependentSets.isSelected(), InvariantComputationDialog.this.strongDependentSets.isSelected(), InvariantComputationDialog.this.connectedADS.isSelected(), null, adsFile, sdsFile, adsConFile, io.isComputeTInvariants());
/* 1135 */                   io.nextStage.setResultObject(new DependentSet());
/*      */                   
/* 1137 */                   int answ = -1;
/*      */                   
/* 1139 */                   if (io.isComputeTInvariants() && InvariantComputationDialog.this.tInvariants != null) {
/*      */                     
/* 1141 */                     answ = JOptionPane.showConfirmDialog(null, "Use already computed T-Invariants for dependent set computation ?", "Question", 0);
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 1146 */                     if (answ == 0) {
/* 1147 */                       io.nextStage.setObjectToAnalyze(InvariantComputationDialog.this.tInvariants);
/* 1148 */                       target = io.nextStage.getResultObject();
/*      */                       
/* 1150 */                       optionSet = io.nextStage;
/*      */                     } 
/* 1152 */                   } else if (!io.isComputeTInvariants() && InvariantComputationDialog.this.pInvariants != null) {
/*      */                     
/* 1154 */                     answ = JOptionPane.showConfirmDialog(null, "Use already computed P-Invariants for dependent set computation ?", "Question", 0);
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/* 1159 */                     if (answ == 0) {
/* 1160 */                       io.nextStage.setObjectToAnalyze(InvariantComputationDialog.this.pInvariants);
/* 1161 */                       target = io.nextStage.getResultObject();
/*      */                       
/* 1163 */                       optionSet = io.nextStage;
/*      */                     } 
/*      */                   } 
/*      */                 } 
/* 1167 */                 if (!(optionSet instanceof DependentSetOptions)) {
/* 1168 */                   target = pInvariantSet;
/*      */                 } else {
/* 1170 */                   target = optionSet.getResultObject();
/*      */                 } 
/* 1172 */                 optionSet.initiator = InvariantComputationDialog.this.thisInitiator;
/* 1173 */                 DebugCounter.inc("InvariantComputationDialog: optionset\n" + optionSet);
/*      */                 
/* 1175 */                 if (target != null) {
/* 1176 */                   InvariantComputationDialog.this.compute(optionSet);
/*      */                 } else {
/* 1178 */                   DebugCounter.inc("InvariantComputationDialog no target for computation!");
/*      */                 } 
/* 1180 */               } else if (InvariantComputationDialog.this.jRadioButtonRankIncidence.isSelected()) {
/* 1181 */                 RankIncidenceMatrixOptionSet rankIncidenceMatrixOptionSet = new RankIncidenceMatrixOptionSet();
/* 1182 */                 rankIncidenceMatrixOptionSet.setObjectToAnalyze(InvariantComputationDialog.this.getPN());
/* 1183 */                 rankIncidenceMatrixOptionSet.setResultObject(new RankResultSet());
/* 1184 */                 rankIncidenceMatrixOptionSet.setInitiator(InvariantComputationDialog.this.thisInitiator);
/*      */                 
/* 1186 */                 InvariantComputationDialog.this.compute((OptionSet)rankIncidenceMatrixOptionSet);
/* 1187 */               } else if (InvariantComputationDialog.this.jRadioButtonStructurallyBounded.isSelected()) {
/* 1188 */                 computeOptionSet = new StructurallyBoundedOptionSet();
/* 1189 */                 computeOptionSet.setObjectToAnalyze(InvariantComputationDialog.this.getPN());
/* 1190 */                 computeOptionSet.setResultObject(new StructurallyBoundedResultSet());
/* 1191 */                 computeOptionSet.setInitiator(InvariantComputationDialog.this.thisInitiator);
/*      */                 
/* 1193 */                 InvariantComputationDialog.this.compute(computeOptionSet);
/*      */               } else {
/* 1195 */                 InvariantComputationDialog.LOG.error("Something has been forgotten to be implemented. Please check the source code.");
/*      */               } 
/*      */             } else {
/* 1198 */               InvariantComputationDialog.LOG.error("PN == null: please load a net before computing anything.");
/*      */             } 
/*      */           }
/*      */         });
/* 1202 */     this.jButtonCompute = compute;
/* 1203 */     return compute;
/*      */   }
/*      */   
/*      */   private void setDependentSetsEnabled(boolean _enabled) {
/* 1207 */     if (this.jRadioButtonPInvariants.isSelected() || this.jRadioButtonTInvariants.isSelected()) {
/* 1208 */       this.jCheckBoxDependentSets.setEnabled(_enabled);
/* 1209 */       this.jButtonLoadInvariants.setEnabled(_enabled);
/* 1210 */       this.invariantOptionsButton.setEnabled(_enabled);
/*      */     } else {
/* 1212 */       this.jCheckBoxDependentSets.setEnabled(false);
/* 1213 */       this.jButtonLoadInvariants.setEnabled(false);
/* 1214 */       this.invariantOptionsButton.setEnabled(false);
/*      */     } 
/*      */     
/* 1217 */     if (_enabled && this.jCheckBoxDependentSets.isSelected()) {
/* 1218 */       this.dependentSetOptionsButton.setEnabled(true);
/*      */     } else {
/* 1220 */       this.dependentSetOptionsButton.setEnabled(false);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void compute(OptionSet io) {
/* 1225 */     DebugCounter.inc("InvariantComputationDialog.compute()->AnalyzerManager.compute(...)");
/* 1226 */     if (!AnalyzerManagerFactory.getAnalyzerManager().compute(io)) {
/* 1227 */       DebugCounter.inc("AnalyzerManager.compute(...) returned false");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void handleResult(Object _resultObject, Results _results) {
/* 1233 */     if (_resultObject instanceof PInvariantSet) {
/* 1234 */       this.pInvariants = (PInvariantSet)_resultObject;
/* 1235 */     } else if (_resultObject instanceof TInvariantSet) {
/* 1236 */       this.tInvariants = (TInvariantSet)_resultObject;
/*      */     } 
/*      */     
/* 1239 */     DebugCounter.inc("InvariantComputationDialog.analyzerHasFinished: inform App about results");
/*      */   }
/*      */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_components/InvariantComputationDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */