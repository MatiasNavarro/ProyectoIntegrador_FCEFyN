/*     */ package GUI.rggui;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomFileChooser
/*     */   extends JFileChooser
/*     */ {
/*     */   private static final long serialVersionUID = 8177027894728308061L;
/*     */   
/*     */   public CustomFileChooser(String toFilter) {
/*  18 */     setFileFilter(new CustomFileFilter(toFilter));
/*     */   }
/*     */ 
/*     */   
/*     */   public CustomFileChooser(String[] toFilter) {
/*  23 */     for (int i = 0; i < toFilter.length; i++) {
/*  24 */       addChoosableFileFilter(new CustomFileFilter(toFilter[i]));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CustomFileChooser(File dir, String toFilter) {
/*  31 */     setFileFilter(new CustomFileFilter(toFilter));
/*  32 */     if (dir != null) {
/*  33 */       setCurrentDirectory(dir);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public CustomFileChooser(File dir, String[] filter) {
/*  39 */     for (int i = 0; i < filter.length; i++) {
/*  40 */       addChoosableFileFilter(new CustomFileFilter(filter[i]));
/*     */     }
/*     */     
/*  43 */     if (dir != null) {
/*  44 */       setCurrentDirectory(dir);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public CustomFileChooser(File dir) {
/*  50 */     if (dir != null) {
/*  51 */       setCurrentDirectory(dir);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CustomFileChooser() {}
/*     */ 
/*     */   
/*     */   public void cancelSelection() {
/*  61 */     setSelectedFile(null);
/*  62 */     super.cancelSelection();
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  66 */     if (getCurrentDirectory() == null || getSelectedFile() == null) {
/*  67 */       return null;
/*     */     }
/*  69 */     return getSelectedFile().getAbsolutePath();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFileFilter(String filter) {
/*  74 */     addChoosableFileFilter(new CustomFileFilter(filter));
/*     */   }
/*     */   
/*     */   class CustomFileFilter extends FileFilter {
/*     */     String toFilter;
/*     */     
/*     */     public CustomFileFilter(String toFilter) {
/*  81 */       this.toFilter = toFilter;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean accept(File f) {
/*  87 */       if (f.isDirectory()) {
/*  88 */         return true;
/*     */       }
/*  90 */       StringTokenizer str = new StringTokenizer(this.toFilter, ";");
/*  91 */       while (str.hasMoreTokens()) {
/*  92 */         if (f.getName().endsWith(str.nextToken())) {
/*  93 */           return true;
/*     */         }
/*     */       } 
/*  96 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDescription() {
/* 102 */       return this.toFilter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/CustomFileChooser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */