package GUI.rggui;

import GUI.IDirector;

public interface IRGDirector extends IDirector {
  public static final int START_RG_CONSTRUCTION = 1;
  
  public static final int STOP_RG_CONSTRUCTION = 2;
  
  public static final int NET_UPDATED = 3;
  
  public static final int NET_LOADED = 4;
  
  public static final int CONSTRUCTION_FINISHED = 5;
  
  public static final int ZOOM = 6;
  
  public static final int REPAINT = 7;
  
  public static final int BACK = 9;
  
  public static final int FORWARD = 10;
  
  public static final int LOAD_GRAPH = 11;
  
  public static final int SAVE_GRAPH = 12;
  
  public static final int LOAD_SESSION = 13;
  
  public static final int SAVE_SESSION = 14;
  
  public static final int ADD_FILTER = 15;
  
  public static final int REMOVE_FILTER = 16;
  
  public static final int UPDATE_RG_INFO = 17;
  
  public static final int EXPORT_MARKINGS = 18;
  
  public static final int EXPORT_TRANSITIONS = 19;
  
  public static final int DELETE_PATH = 20;
  
  public static final int SHOW_GUI = 21;
  
  public static final int ADD_VIEWER = 22;
  
  public static final int EXIT = 23;
  
  public static final int CHECK_FORMULA = 24;
  
  public static final int EDIT_FORMULA = 25;
  
  public static final int VIEW_RG = 26;
  
  public static final int START_PATH_CONSTRUCTION = 27;
  
  public static final int EXPORT_PARIKH_VECTOR = 28;
  
  public static final int SEQUENCES = 29;
  
  public static final int PRINT_GRAPH = 30;
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/IRGDirector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */