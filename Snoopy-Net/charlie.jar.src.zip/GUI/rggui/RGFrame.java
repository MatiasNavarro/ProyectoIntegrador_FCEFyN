/*     */ package GUI.rggui;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.Align;
/*     */ import GUI.util.MyButton;
/*     */ import GUI.util.ResourceLoader;
/*     */ import charlie.filter.BinFilter;
/*     */ import charlie.filter.Filter;
/*     */ import charlie.rg.Path;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.awt.event.WindowFocusListener;
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.util.Vector;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTabbedPane;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ 
/*     */ public class RGFrame
/*     */   extends JFrame
/*     */ {
/*     */   private static final long serialVersionUID = -7978754091560406041L;
/*     */   private static final double vGap = 3.0D;
/*     */   private static final double hGap = 3.0D;
/*  40 */   private JTabbedPane tabPanel = null;
/*  41 */   private ControlPanel controlPanel = null;
/*  42 */   private JFrame parentFrame = null;
/*  43 */   private IDirector director = null;
/*  44 */   private JFrame thisFrame = null;
/*  45 */   private Vector<Viewer> viewerVector = new Vector<>();
/*  46 */   private Viewer actualViewer = null;
/*     */   
/*     */   private boolean focusState = false;
/*     */   
/*     */   public RGFrame(IDirector director, JFrame parentFrame) {
/*  51 */     this.director = director;
/*  52 */     this.parentFrame = parentFrame;
/*  53 */     this.thisFrame = this;
/*     */   }
/*     */   
/*     */   public void setup() {
/*  57 */     double p = -2.0D;
/*     */     
/*  59 */     double[][] size = { { 3.0D, p, p, 6.0D }, { 3.0D, p, 3.0D } };
/*  60 */     TableLayout layout = new TableLayout(size);
/*  61 */     JPanel panel = new JPanel();
/*  62 */     panel.setSize(new Dimension(500, 500));
/*  63 */     panel.setLayout((LayoutManager)layout);
/*  64 */     this.controlPanel = new ControlPanel(this.director, this);
/*  65 */     this.tabPanel = new JTabbedPane();
/*  66 */     Dimension d = new Dimension(400, 400);
/*  67 */     this.tabPanel.setSize(d);
/*  68 */     this.tabPanel.setPreferredSize(d);
/*     */     
/*  70 */     panel.add(this.tabPanel, "1,1");
/*  71 */     panel.add(this.controlPanel, "2,1");
/*     */     
/*  73 */     setJMenuBar(RGMenu.getMenu(this.director));
/*  74 */     setTitle("Reachability Graph Utilities");
/*  75 */     setContentPane(panel);
/*  76 */     pack();
/*  77 */     addComponentListener(getStateListener());
/*  78 */     Align.alignToParentWindow(this, this.parentFrame);
/*  79 */     setDefaultCloseOperation(1);
/*     */ 
/*     */     
/*  82 */     addWindowFocusListener(new WindowFocusListener()
/*     */         {
/*     */           public void windowGainedFocus(WindowEvent e)
/*     */           {
/*  86 */             if (!RGFrame.this.focusState) {
/*  87 */               RGFrame.this.parentFrame.toFront();
/*  88 */               RGFrame.this.focusState = true;
/*  89 */               RGFrame.this.thisFrame.toFront();
/*     */             } else {
/*  91 */               RGFrame.this.focusState = false;
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void windowLostFocus(WindowEvent e) {}
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 104 */     DebugCounter.inc("RGFrame reset() called");
/* 105 */     this.actualViewer = null;
/* 106 */     this.tabPanel.removeAll();
/* 107 */     this.viewerVector.clear();
/* 108 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentListener getStateListener() {
/* 117 */     ComponentListener w = new ComponentListener()
/*     */       {
/*     */         public void componentHidden(ComponentEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void componentMoved(ComponentEvent e) {}
/*     */ 
/*     */ 
/*     */         
/*     */         public void componentResized(ComponentEvent e) {
/* 129 */           JFrame f = (JFrame)e.getSource();
/* 130 */           Dimension d = f.getSize();
/* 131 */           Insets i = f.getInsets();
/* 132 */           d.setSize(d.getWidth() - ControlPanel.getPanelWidth() - i.left - i.right, d.getHeight() - i.top - i.bottom - 5.0D);
/* 133 */           RGFrame.this.tabPanel.setSize(d);
/* 134 */           RGFrame.this.tabPanel.setPreferredSize(d);
/* 135 */           RGFrame.this.tabPanel.revalidate();
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void componentShown(ComponentEvent e) {}
/*     */       };
/* 142 */     return w;
/*     */   }
/*     */ 
/*     */   
/*     */   public Viewer getActualViewer() {
/* 147 */     this.actualViewer = (Viewer)this.tabPanel.getSelectedComponent();
/* 148 */     return this.actualViewer;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addFilter(File filterFile) {
/*     */     BinFilter binFilter;
/* 154 */     if (!filterFile.exists()) {
/* 155 */       return false;
/*     */     }
/*     */     
/* 158 */     Viewer viewer = getActualViewer();
/*     */     try {
/* 160 */       binFilter = new BinFilter(filterFile.getAbsolutePath(), viewer.session.vi.pn);
/* 161 */     } catch (Exception npe) {
/* 162 */       npe.printStackTrace();
/* 163 */       return false;
/*     */     } 
/* 165 */     viewer.vi.addFilter((Filter)binFilter);
/* 166 */     viewer.actualise();
/* 167 */     return true;
/*     */   }
/*     */   
/*     */   public void addViewer(Viewer v, Path p) {
/* 171 */     addViewer(v);
/*     */     
/* 173 */     this.actualViewer.getVisualisationViewer().repaint();
/* 174 */     this.controlPanel.switchToViewer(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addViewer(Viewer v) {
/* 179 */     if (this.viewerVector.indexOf(v) == -1) {
/*     */       
/* 181 */       this.viewerVector.addElement(v);
/* 182 */       String title = "net:" + v.getPn().getName();
/* 183 */       if (this.tabPanel.getTabCount() > 0) {
/* 184 */         if (this.tabPanel.getTitleAt(0).equals("erster tab")) {
/* 185 */           this.tabPanel.setComponentAt(0, v);
/* 186 */           this.tabPanel.setTabComponentAt(0, new TabComponent(title, v.netInfo(), this.tabPanel, 0));
/*     */         } else {
/* 188 */           this.tabPanel.add(v);
/* 189 */           int index = this.tabPanel.getTabCount() - 1;
/* 190 */           this.tabPanel.setTabComponentAt(index, new TabComponent(title, v.netInfo(), this.tabPanel, index));
/*     */         } 
/*     */       } else {
/* 193 */         this.tabPanel.add(v);
/* 194 */         int index = this.tabPanel.getTabCount() - 1;
/* 195 */         this.tabPanel.setTabComponentAt(index, new TabComponent(title, v.netInfo(), this.tabPanel, index));
/*     */       } 
/*     */     } 
/* 198 */     this.tabPanel.setSelectedComponent(v);
/* 199 */     this.controlPanel.switchToViewer(v);
/* 200 */     this.actualViewer = v;
/*     */   }
/*     */ 
/*     */   
/*     */   public Viewer removeActualViewer() {
/* 205 */     removeViewer(this.actualViewer);
/* 206 */     this.actualViewer = this.viewerVector.get(0);
/* 207 */     if (this.actualViewer != null) {
/* 208 */       this.tabPanel.setSelectedComponent(this.actualViewer);
/*     */     } else {
/* 210 */       this.controlPanel.enableControls(false);
/*     */     } 
/* 212 */     return this.actualViewer;
/*     */   }
/*     */   
/*     */   public void removeViewer(int index) {
/* 216 */     Viewer v = this.viewerVector.elementAt(index);
/* 217 */     removeViewer(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeViewer(Viewer v) {
/* 222 */     int index = this.viewerVector.indexOf(v);
/* 223 */     this.viewerVector.remove(v);
/* 224 */     this.tabPanel.removeTabAt(index);
/* 225 */     if (this.actualViewer == v) {
/* 226 */       int newIndex = this.tabPanel.getTabCount() - 1;
/* 227 */       if (newIndex >= 0) {
/* 228 */         this.actualViewer = (Viewer)this.tabPanel.getComponentAt(newIndex);
/*     */       } else {
/* 230 */         this.actualViewer = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void switchToViewer(int index) {
/* 236 */     Viewer v = this.viewerVector.elementAt(index);
/* 237 */     switchToViewer(v);
/*     */   }
/*     */   
/*     */   public void switchToViewer(Viewer v) {
/* 241 */     int index = this.tabPanel.indexOfComponent(v);
/*     */ 
/*     */     
/* 244 */     if (index < 0 && 
/* 245 */       this.tabPanel.getTabCount() > 0) {
/* 246 */       v = (Viewer)this.tabPanel.getComponentAt(0);
/*     */     }
/*     */     
/* 249 */     this.tabPanel.setSelectedComponent(v);
/* 250 */     this.controlPanel.switchToViewer(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public static JButton applyOptions(JButton b, String roIcon) {
/* 255 */     b.setMargin(new Insets(0, 0, 0, 0));
/* 256 */     b.setIconTextGap(0);
/* 257 */     b.setBorderPainted(false);
/* 258 */     b.setOpaque(false);
/* 259 */     b.setContentAreaFilled(false);
/* 260 */     b.setRolloverEnabled(true);
/* 261 */     b.setRolloverIcon(new ImageIcon(roIcon));
/* 262 */     b.setHideActionText(true);
/*     */     
/* 264 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   private class TabComponent
/*     */     extends JPanel
/*     */   {
/*     */     private static final long serialVersionUID = 7464316976426729543L;
/*     */     
/* 273 */     private String title = null;
/* 274 */     private String toolTip = null;
/* 275 */     private JTabbedPane tabPanel = null;
/* 276 */     private int tabIndex = -1;
/* 277 */     private TabComponent tabComponent = null;
/* 278 */     JLabel titleLabel = null;
/* 279 */     private Component thisComponent = null;
/*     */ 
/*     */     
/*     */     public TabComponent(String title, String toolTip, JTabbedPane tabPanel, int tabIndex) {
/* 283 */       this.tabComponent = this;
/* 284 */       this.title = title;
/* 285 */       this.toolTip = toolTip;
/* 286 */       this.tabPanel = tabPanel;
/* 287 */       this.tabIndex = tabIndex;
/* 288 */       this.thisComponent = tabPanel.getComponentAt(tabIndex);
/* 289 */       initialize();
/*     */     }
/*     */ 
/*     */     
/*     */     private void initialize() {
/* 294 */       double p = -2.0D;
/* 295 */       double[][] size = { { p, 4.0D, p }, { 2.0D, p, 2.0D } };
/* 296 */       TableLayout layout = new TableLayout(size);
/* 297 */       setOpaque(false);
/* 298 */       setLayout((LayoutManager)layout);
/*     */ 
/*     */ 
/*     */       
/* 302 */       MyButton b = new MyButton(ResourceLoader.getURL("resources/closeButton_small_red.png"), ResourceLoader.getURL("resources/closeButton_small_red_ro.png"), "close this tab")
/*     */         {
/*     */           public void mouseClicked(MouseEvent e) {
/* 305 */             RGFrame.TabComponent.this.tabIndex = RGFrame.TabComponent.this.tabPanel.indexOfComponent(RGFrame.TabComponent.this.thisComponent);
/* 306 */             RGFrame.TabComponent.this.tabPanel.removeTabAt(RGFrame.TabComponent.this.tabIndex);
/*     */           }
/*     */         };
/* 309 */       this.titleLabel = new JLabel(this.title + "  ");
/*     */       
/* 311 */       this.titleLabel.addMouseListener(new MouseAdapter()
/*     */           {
/*     */ 
/*     */ 
/*     */             
/*     */             public void mouseClicked(MouseEvent e)
/*     */             {
/* 318 */               RGFrame.TabComponent.this.tabIndex = RGFrame.TabComponent.this.tabPanel.indexOfComponent(RGFrame.TabComponent.this.thisComponent);
/* 319 */               if (RGFrame.TabComponent.this.tabIndex < 0) {
/* 320 */                 JOptionPane.showMessageDialog(null, "indexofComponent returned \n" + Integer.toString(RGFrame.TabComponent.this.tabPanel.indexOfComponent(RGFrame.TabComponent.this.tabComponent)));
/*     */                 return;
/*     */               } 
/* 323 */               if (e.getClickCount() == 1) {
/* 324 */                 RGFrame.this.switchToViewer(RGFrame.TabComponent.this.tabIndex);
/* 325 */               } else if (e.getClickCount() > 1) {
/* 326 */                 RGFrame.this.removeViewer(RGFrame.TabComponent.this.tabIndex);
/*     */               } 
/*     */             }
/*     */           });
/*     */ 
/*     */ 
/*     */       
/* 333 */       setToolTipText(this.toolTip);
/* 334 */       setToolTip(this.toolTip);
/* 335 */       add(this.titleLabel, "0,1");
/* 336 */       if (b == null) {
/* 337 */         JLabel closeLabel = new JLabel("| X");
/* 338 */         closeLabel.setOpaque(false);
/* 339 */         closeLabel.setToolTipText("close this tab");
/* 340 */         closeLabel.addMouseListener(new MouseAdapter()
/*     */             {
/*     */               
/*     */               public void mouseClicked(MouseEvent e)
/*     */               {
/* 345 */                 RGFrame.TabComponent.this.tabPanel.removeTabAt(RGFrame.TabComponent.this.tabIndex);
/*     */               }
/*     */             });
/*     */         
/* 349 */         add(closeLabel, "2,1");
/*     */       } else {
/* 351 */         add((Component)b, "2,1");
/*     */       } 
/*     */       
/* 354 */       setPreferredSize(layout.preferredLayoutSize(this));
/* 355 */       setSize(layout.preferredLayoutSize(this));
/*     */     }
/*     */     
/*     */     public void setToolTip(String text) {
/* 359 */       this.toolTip = text;
/* 360 */       this.titleLabel.setToolTipText(text);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/RGFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */