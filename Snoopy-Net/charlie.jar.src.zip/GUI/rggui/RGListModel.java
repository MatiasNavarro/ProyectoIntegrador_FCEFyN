/*    */ package GUI.rggui;
/*    */ 
/*    */ import javax.swing.DefaultListModel;
/*    */ import javax.swing.JList;
/*    */ import javax.swing.event.ListDataEvent;
/*    */ import javax.swing.event.ListDataListener;
/*    */ import javax.swing.event.ListSelectionEvent;
/*    */ import javax.swing.event.ListSelectionListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RGListModel
/*    */   extends DefaultListModel
/*    */   implements ListSelectionListener, ListDataListener
/*    */ {
/*    */   private static final long serialVersionUID = 5909639272355409935L;
/* 20 */   private Viewer viewer = null;
/*    */   
/*    */   public RGListModel(Viewer viewer) {
/* 23 */     this.viewer = viewer;
/* 24 */     addListDataListener(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public void valueChanged(ListSelectionEvent e) {
/* 29 */     JList src = (JList)e.getSource();
/* 30 */     int index = src.getSelectedIndex();
/* 31 */     if (index >= 0) {
/* 32 */       String name = src.getName();
/* 33 */       if (name.equals("filterList")) {
/* 34 */         this.viewer.vi.setFilter(index);
/* 35 */       } else if (name.equals("pathList")) {
/* 36 */         this.viewer.vi.setPath(index);
/*    */       } 
/* 38 */       this.viewer.actualise();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void intervalAdded(ListDataEvent e) {
/* 44 */     RGListModel model = (RGListModel)e.getSource();
/* 45 */     Object o = model.get(0);
/* 46 */     if (o instanceof charlie.rg.Path) {
/* 47 */       ControlPanel.pathList.setSelectedIndex(model.getSize() - 1);
/* 48 */     } else if (o instanceof charlie.filter.Filter) {
/* 49 */       ControlPanel.filterList.setSelectedIndex(model.getSize() - 1);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void intervalRemoved(ListDataEvent e) {}
/*    */ 
/*    */   
/*    */   public void contentsChanged(ListDataEvent e) {
/* 58 */     JList src = (JList)e.getSource();
/* 59 */     RGListModel model = (RGListModel)src.getModel();
/* 60 */     src.setSelectedIndex(model.getSize() - 1);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/RGListModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */