/*     */ package GUI.rggui;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.Align;
/*     */ import GUI.util.FileDisplayDialog;
/*     */ import GUI.util.TextFile;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerManagerFactory;
/*     */ import charlie.analyzer.Initiator;
/*     */ import charlie.analyzer.OptionSet;
/*     */ import charlie.analyzer.mc.MCAnalyzer;
/*     */ import charlie.analyzer.mc.MCOptions;
/*     */ import charlie.analyzer.path.PathComputationOptions;
/*     */ import charlie.analyzer.path.PathConstruction;
/*     */ import charlie.analyzer.rg.ConstructionOptions;
/*     */ import charlie.analyzer.rg.RGAnalyzer;
/*     */ import charlie.pn.Out;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.Results;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGraph;
/*     */ import charlie.util.DirectorManager;
/*     */ import charlie.vis.GraphReader;
/*     */ import charlie.vis.GraphWriter;
/*     */ import charlie.vis.Options;
/*     */ import charlie.vis.RGVisualisation;
/*     */ import charlie.vis.Session;
/*     */ import charlie.vis.ViewerInfo;
/*     */ import com.itextpdf.text.Document;
/*     */ import com.itextpdf.text.DocumentException;
/*     */ import com.itextpdf.text.Rectangle;
/*     */ import com.itextpdf.text.pdf.PdfContentByte;
/*     */ import com.itextpdf.text.pdf.PdfTemplate;
/*     */ import com.itextpdf.text.pdf.PdfWriter;
/*     */ import edu.uci.ics.jung.visualization.Coordinates;
/*     */ import edu.uci.ics.jung.visualization.Layout;
/*     */ import edu.uci.ics.jung.visualization.VisualizationViewer;
/*     */ import edu.uci.ics.jung.visualization.transform.MutableTransformer;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Point;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RGGui
/*     */   implements Initiator, IRGDirector
/*     */ {
/*  58 */   private static final Log LOG = LogFactory.getLog(RGGui.class);
/*     */   
/*  60 */   private JFrame parentFrame = null;
/*  61 */   private RGFrame rgFrame = null;
/*  62 */   private IDirector appDirector = null;
/*     */ 
/*     */   
/*  65 */   private ReachabilityGraphDialog externalDialog = null;
/*  66 */   private PathComputationDialog externalPathDialog = null;
/*  67 */   private ModelCheckingDialog externalFormulaDialog = null;
/*     */   
/*  69 */   private PlaceTransitionNet pn = null;
/*  70 */   private FormulaEditor fe = null;
/*     */   
/*  72 */   private RGraph rGraph = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ctlActive = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ltlActive = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public RGGui(IDirector appDirector) {
/*  85 */     this.appDirector = appDirector;
/*  86 */     initialize();
/*  87 */     register();
/*     */   }
/*     */   
/*     */   public RGGui(JFrame parentFrame, IDirector appDirector) {
/*  91 */     this.parentFrame = parentFrame;
/*  92 */     this.appDirector = appDirector;
/*     */     
/*  94 */     initialize();
/*  95 */     register();
/*     */   }
/*     */   
/*     */   private void register() {
/*  99 */     DirectorManager.registerDirector(this);
/*     */   }
/*     */   
/*     */   public void disableBoundednessCheck() {
/* 103 */     if (this.externalDialog != null) {
/* 104 */       this.externalDialog.disableBoundednesCheck();
/*     */     }
/*     */   }
/*     */   
/*     */   private void initialize() {
/* 109 */     DebugCounter.inc("RGGUI registering RGAnalyzer");
/* 110 */     RGAnalyzer.register();
/* 111 */     DebugCounter.inc("RGGUI registering MCAnalyzer");
/* 112 */     MCAnalyzer.register();
/* 113 */     DebugCounter.inc("RGGUI registering PathComputationAnalyzer");
/* 114 */     PathConstruction.register();
/* 115 */     this.rgFrame = new RGFrame(this, this.parentFrame);
/* 116 */     this.rgFrame.setup();
/*     */   }
/*     */   
/*     */   public void setPN(PlaceTransitionNet pnet) {
/* 120 */     if (pnet == null) {
/* 121 */       if (this.externalDialog != null) {
/* 122 */         this.externalDialog.enableControls(false);
/* 123 */         this.externalDialog.reset(true);
/*     */       } 
/* 125 */       if (this.rgFrame != null) {
/* 126 */         this.rgFrame.setVisible(false);
/* 127 */         this.rgFrame.reset();
/*     */       } 
/* 129 */       if (this.externalFormulaDialog != null);
/*     */ 
/*     */       
/* 132 */       if (this.externalPathDialog != null) {
/* 133 */         this.externalPathDialog.reset(true);
/*     */       }
/*     */       return;
/*     */     } 
/* 137 */     this.pn = pnet;
/* 138 */     if (this.pn.places() == 0) {
/* 139 */       JOptionPane.showMessageDialog(this.parentFrame, "PN set on rggui has no places!");
/*     */     }
/* 141 */     if (this.pn.transitions() == 0) {
/* 142 */       JOptionPane.showMessageDialog(this.parentFrame, "PN set on rggui has no transitions!");
/*     */     }
/* 144 */     this.rGraph = null;
/* 145 */     if (this.rgFrame != null) {
/* 146 */       this.rgFrame.reset();
/*     */     }
/* 148 */     if (this.externalDialog != null) {
/* 149 */       this.externalDialog.enableControls(true);
/* 150 */       this.externalDialog.reset(true);
/* 151 */       this.externalDialog.setPN(this.pn);
/*     */     } 
/* 153 */     if (this.externalPathDialog != null) {
/* 154 */       this.externalPathDialog.reset(true);
/* 155 */       this.externalPathDialog.enableControls(true);
/* 156 */       this.externalPathDialog.setPN(this.pn);
/*     */     } 
/*     */     
/* 159 */     if (this.externalFormulaDialog != null) {
/* 160 */       this.externalFormulaDialog.reset(true);
/* 161 */       this.externalFormulaDialog.enableControls(false);
/* 162 */       this.externalFormulaDialog.setPN(this.pn);
/*     */     }  } public synchronized boolean sendMessage(int messageType, Object source, Object object) { MutableTransformer mt; double factor;
/*     */     Integer layoutIndex;
/*     */     RGraph r;
/*     */     byte mode;
/*     */     MCOptions mco;
/* 168 */     boolean returnValue = true;
/* 169 */     Viewer viewer = null;
/* 170 */     File file = null;
/* 171 */     Path path = null;
/* 172 */     switch (messageType)
/*     */     { default:
/* 174 */         JOptionPane.showMessageDialog(this.parentFrame, "RGGui: unknown messagetype!");
/*     */       
/*     */       case 1:
/* 177 */         returnValue = startRGConstruction((OptionSet)object);
/*     */       
/*     */       case 27:
/* 180 */         returnValue = startPathConstruction((OptionSet)object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/* 353 */         return returnValue;case 4: DebugCounter.inc("RGGUi : message - > NET_LOADED !"); this.rgFrame.reset();case 3: case 5: return returnValue;case 6: viewer = this.rgFrame.getActualViewer(); mt = viewer.getVisualisationViewer().getViewTransformer(); factor = ((Double)object).doubleValue(); mt.scale(factor, factor, new Point(0, 0));case 7: viewer = this.rgFrame.getActualViewer(); if (viewer != null) viewer.actualise(); case 9: this.rgFrame.getActualViewer().back();case 10: this.rgFrame.getActualViewer().forward();case 11: DebugCounter.inc("RGGui sendmessage() case: LOAD_GRAPH( )"); returnValue = loadGraph((File)object);case 12: DebugCounter.inc("RGGui sendmessage() case: SAVE_GRAPH( )"); returnValue = saveGraph((File)object);case 30: DebugCounter.inc("RGGui sendmessage() case: PRINT_GRAPH( )"); returnValue = exportGraph();case 13: DebugCounter.inc("RGGui sendmessage() case: LOAD_SESSION( )"); returnValue = loadSession((File)object);case 14: DebugCounter.inc("RGGui sendmessage() case: SAVE_SESSION( )"); returnValue = saveSession((File)object);case 26: if (object instanceof RGraph && this.rgFrame != null) { viewRGraph((RGraph)object); returnValue = true; } else { DebugCounter.inc("RGGui.analyzerHasFinished ... no rgFrame (==null)"); returnValue = false; } case 17: return returnValue;case 18: file = (File)object; path = (this.rgFrame.getActualViewer()).vi.getPath(); returnValue = TextFile.writeToFile(file, path.toMarkingSequence(this.pn), true);case 19: file = (File)object; path = (this.rgFrame.getActualViewer()).vi.getPath(); returnValue = TextFile.writeToFile(file, path.toTransitionSequence(this.pn), true);case 28: file = (File)object; path = (this.rgFrame.getActualViewer()).vi.getPath(); returnValue = TextFile.writeToFile(file, path.toParikhVector(this.pn), true);case 22: layoutIndex = (Integer)object; viewer = getNewViewer(); viewer.actualise(); this.rgFrame.addViewer(viewer); returnValue = true;case 21: showGui((Boolean)object); returnValue = this.rgFrame.isVisible();case 25: returnValue = true; DebugCounter.inc("RGGUI. EDIT_FORMULA"); r = this.externalFormulaDialog.getSelectedRGraph(); mode = this.externalFormulaDialog.getMCMode(); if (r == null || this.pn == null) { JOptionPane.showMessageDialog(this.parentFrame, "no net loaded or no rg constructed"); DebugCounter.inc("No net or no rg"); returnValue = false; } else { if (object == null) { this.fe = FormulaEditor.getInstance(this, this.pn, r, mode); } else if (object instanceof File) { DebugCounter.inc("RGGUI.EDIT_FORMULA: object is a file"); this.fe = FormulaEditor.getInstance(this, this.pn, r, mode, (File)object); } else if (object instanceof String) { DebugCounter.inc("RGGUI.EDIT_FORMULA: object is a string"); this.fe = FormulaEditor.getInstance(this, this.pn, r, mode, (String)object); }  if (this.fe != null && returnValue) { this.fe.setVisible(true); if (this.parentFrame != null)
/*     */               Align.alignToParentWindow(this.fe, this.parentFrame);  returnValue = true; } else { if (!returnValue)
/*     */               DebugCounter.inc("RGGUI.EDIT_FORMULA: returnValue=false");  if (this.fe == null)
/*     */               DebugCounter.inc("RGGUI.EDIT_FORMULA: fe==null");  returnValue = false; }  } case 24: mco = (MCOptions)object; mco.initiator = this; mco.pn = this.pn; this.fe = FormulaEditor.getInstance(this, this.pn, mco.rg, mco.mode, mco.formula); if (this.fe != null) { if ((mco.mode == 0 && !this.ctlActive) || (mco.mode == 1 && !this.ltlActive))
/*     */             if (this.fe.checkSyntax(mco.formula)) { returnValue = AnalyzerManagerFactory.getAnalyzerManager().compute((OptionSet)mco); } else { returnValue = false; }   } else { returnValue = false; } case 29: reduceSequences(((Boolean)object).booleanValue());case 23: break; }  if (this.appDirector != null)
/* 358 */       showGui(false);  System.exit(1); } public Object externalMessage(int messageType, Object source, Object object) { return new Object(); }
/*     */ 
/*     */   
/*     */   private void showGui(Boolean b) {
/* 362 */     showGui(b.booleanValue());
/*     */   }
/*     */   
/*     */   private void showGui(boolean b) {
/* 366 */     DebugCounter.inc("RGGui.sendMessage(SHOW_GUI : " + Boolean.toString(b) + ")");
/*     */     
/* 368 */     if (this.rgFrame == null) {
/* 369 */       initialize();
/* 370 */       this.rgFrame.setVisible(true);
/* 371 */     } else if (b) {
/* 372 */       if (this.rgFrame.getExtendedState() == 1) {
/* 373 */         this.rgFrame.setExtendedState(0);
/*     */       }
/* 375 */       this.rgFrame.toFront();
/* 376 */       this.rgFrame.setVisible(b);
/* 377 */     } else if (!b) {
/* 378 */       this.rgFrame.setVisible(b);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean loadGraph(File loadFile) {
/* 383 */     Viewer viewer = getNewViewer();
/* 384 */     GraphReader gr = new GraphReader(loadFile, viewer.getRG(), viewer.vi().netInfo());
/* 385 */     Layout l = gr.readGraph(viewer.vi().visNodes());
/* 386 */     if (l != null) {
/* 387 */       viewer.session().clear();
/* 388 */       viewer.setSession(new Session(viewer.vi()));
/* 389 */       viewer.session().addEntry(l);
/* 390 */       viewer.getVisualisationViewer().setGraphLayout(l);
/* 391 */       viewer.getVisualisationViewer().repaint();
/*     */     } 
/* 393 */     this.rgFrame.addViewer(viewer);
/* 394 */     if (viewer != null) {
/* 395 */       return true;
/*     */     }
/* 397 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean saveGraph(File saveFile) {
/* 402 */     System.out.printf("saveFile : %s\n", new Object[] { saveFile.getAbsolutePath() });
/* 403 */     if (saveFile != null) {
/* 404 */       Viewer viewer = this.rgFrame.getActualViewer();
/* 405 */       GraphWriter gw = new GraphWriter(saveFile, viewer.vi().netInfo());
/* 406 */       gw.writeGraph(viewer.getVisualisationViewer().getGraphLayout());
/* 407 */       new FileDisplayDialog(100, 100, saveFile);
/* 408 */       if (viewer != null) {
/* 409 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 413 */     return false;
/*     */   }
/*     */   
/*     */   private boolean exportGraph() {
/* 417 */     JFileChooser fc = new JFileChooser();
/* 418 */     int returnVal = fc.showOpenDialog(this.parentFrame);
/*     */     
/* 420 */     if (returnVal == 0) {
/* 421 */       File file = fc.getSelectedFile();
/* 422 */       String pdfPath = file.getAbsolutePath();
/*     */       
/* 424 */       LOG.debug("exporting to " + pdfPath);
/*     */       
/* 426 */       if (!pdfPath.endsWith(".pdf")) {
/* 427 */         pdfPath = pdfPath + ".pdf";
/*     */         
/* 429 */         LOG.debug("changed path to " + pdfPath);
/*     */       } 
/*     */       
/* 432 */       int width = this.rgFrame.getActualViewer().getWidth();
/* 433 */       int height = this.rgFrame.getActualViewer().getHeight();
/*     */       
/* 435 */       Document document = new Document(new Rectangle((width + 10), (height + 10)));
/*     */       
/*     */       try {
/* 438 */         PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(pdfPath));
/* 439 */         document.open();
/*     */         
/* 441 */         PdfContentByte cb = writer.getDirectContent();
/*     */         
/* 443 */         PdfTemplate tp = cb.createTemplate(width, height);
/* 444 */         Graphics2D g2 = tp.createGraphicsShapes(width, height);
/*     */         
/* 446 */         VisualizationViewer viewer = this.rgFrame.getActualViewer().getVisualisationViewer();
/*     */         
/* 448 */         Color oldColor = viewer.getBackground();
/* 449 */         viewer.setBackground(Color.WHITE);
/* 450 */         viewer.setDoubleBuffered(false);
/* 451 */         viewer.paint(g2);
/*     */         
/* 453 */         g2.dispose();
/* 454 */         cb.addTemplate(tp, 30.0F, 30.0F);
/*     */         
/* 456 */         viewer.setBackground(oldColor);
/* 457 */         viewer.setDoubleBuffered(true);
/* 458 */       } catch (DocumentException e) {
/* 459 */         LOG.error(e.getMessage(), (Throwable)e);
/*     */         
/*     */         try {
/* 462 */           document.close();
/* 463 */         } catch (Exception e2) {
/* 464 */           LOG.error(e2.getMessage(), e2);
/* 465 */           return false;
/*     */         } 
/*     */         
/* 468 */         return false;
/* 469 */       } catch (FileNotFoundException e) {
/* 470 */         LOG.error(e.getMessage(), e);
/*     */         
/*     */         try {
/* 473 */           document.close();
/* 474 */         } catch (Exception e2) {
/* 475 */           LOG.error(e2.getMessage(), e2);
/* 476 */           return false;
/*     */         } 
/*     */         
/* 479 */         return false;
/* 480 */       } catch (Exception e) {
/* 481 */         LOG.error(e.getMessage(), e);
/*     */         
/*     */         try {
/* 484 */           document.close();
/* 485 */         } catch (Exception e2) {
/* 486 */           LOG.error(e2.getMessage(), e2);
/* 487 */           return false;
/*     */         } 
/*     */         
/* 490 */         return false;
/*     */       } 
/*     */       
/* 493 */       document.close();
/*     */       
/* 495 */       LOG.debug("exporting done");
/*     */       
/* 497 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 503 */     return true;
/*     */   }
/*     */   
/*     */   private boolean loadSession(File sessionFile) {
/* 507 */     Viewer viewer = getNewViewer();
/* 508 */     Session newSession = viewer.session.load(sessionFile.getAbsolutePath());
/* 509 */     if (newSession != null) {
/* 510 */       viewer.session().clear();
/* 511 */       viewer.setSession(newSession);
/* 512 */       Coordinates scale = new Coordinates(viewer.getVisualisationViewer().getViewTransformer().getScaleX(), viewer.getVisualisationViewer().getViewTransformer().getScaleY());
/* 513 */       viewer.vi().setPath(0);
/* 514 */       viewer.getVisualisationViewer().setGraphLayout(viewer.session().first());
/* 515 */       viewer.getVisualisationViewer().getViewTransformer().scale(scale.getX(), scale.getY(), null);
/* 516 */       viewer.getVisualisationViewer().repaint();
/* 517 */       this.rgFrame.addViewer(viewer);
/*     */       
/* 519 */       return true;
/*     */     } 
/*     */     
/* 522 */     return false;
/*     */   }
/*     */   
/*     */   private boolean saveSession(File sessionFile) {
/* 526 */     if (sessionFile != null) {
/* 527 */       Viewer viewer = this.rgFrame.getActualViewer();
/* 528 */       viewer.session().save(sessionFile.getAbsolutePath());
/* 529 */       return true;
/*     */     } 
/*     */     
/* 532 */     return false;
/*     */   }
/*     */   
/*     */   private boolean startRGConstruction(OptionSet options) {
/* 536 */     if (this.pn == null) {
/* 537 */       JOptionPane.showMessageDialog(this.parentFrame, " no place transition net set on rgfGui!");
/* 538 */       return false;
/*     */     } 
/*     */     
/* 541 */     if (this.pn.places() == 0 || this.pn.transitions() == 0) {
/* 542 */       DebugCounter.inc(" Something wrong with net set on RGGui #places:" + Integer.toString(this.pn.places()) + " # transitions:" + Integer.toString(this.pn.transitions()) + "!");
/* 543 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 549 */       if (options instanceof ConstructionOptions) {
/* 550 */         ((ConstructionOptions)options).m0 = this.pn.getNonTimedM0State();
/* 551 */         DebugCounter.inc("ConstructionOptions.m0 " + ((ConstructionOptions)options).m0);
/*     */       } 
/* 553 */     } catch (Exception e) {
/* 554 */       e.printStackTrace();
/* 555 */       DebugCounter.inc("Cannot copy initial marking set from place transition net, SortedPlaces.copy() throws Exception!");
/*     */       
/* 557 */       return false;
/*     */     } 
/* 559 */     options.setObjectToAnalyze(this.pn);
/* 560 */     this.rGraph = new RGraph(this.pn);
/* 561 */     DebugCounter.inc("Starting rg construction with " + options.getClass().getName());
/* 562 */     AnalyzerManagerFactory.getAnalyzerManager().compute(this.pn, this.rGraph, options, this);
/* 563 */     return true;
/*     */   }
/*     */   
/*     */   private boolean startPathConstruction(OptionSet options) {
/* 567 */     if (options instanceof PathComputationOptions) {
/*     */       
/* 569 */       DebugCounter.inc("RGGui path construction start called...\n" + ((PathComputationOptions)options).toString());
/* 570 */       options.initiator = this;
/* 571 */       AnalyzerManagerFactory.getAnalyzerManager().compute(options);
/* 572 */       return true;
/*     */     } 
/* 574 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean startFomulaCheck(MCOptions options) {
/* 579 */     options.initiator = this;
/* 580 */     if (options.mode == 0 && !this.ctlActive) {
/* 581 */       this.ctlActive = true;
/*     */     } else {
/* 583 */       JOptionPane.showMessageDialog(this.parentFrame, "There is an active CTL Analysis, can't start a second analysis!");
/* 584 */       return false;
/*     */     } 
/* 586 */     if (options.mode == 1 && !this.ltlActive) {
/* 587 */       this.ltlActive = true;
/*     */     } else {
/* 589 */       JOptionPane.showMessageDialog(this.parentFrame, "There is an active LTL Analysis, can't start a second analysis!");
/* 590 */       return false;
/*     */     } 
/* 592 */     return AnalyzerManagerFactory.getAnalyzerManager().compute((OptionSet)options);
/*     */   }
/*     */   
/*     */   private void viewRGraph(RGraph rGraph) {
/* 596 */     if (rGraph == null) {
/*     */       return;
/*     */     }
/* 599 */     this.rGraph = rGraph;
/*     */ 
/*     */     
/* 602 */     if (this.externalDialog != null && !rGraph.isTimedGraph()) {
/* 603 */       this.externalDialog.constructionFinished();
/*     */     }
/*     */     
/*     */     try {
/* 607 */       Viewer v = getNewViewer();
/* 608 */       this.rgFrame.addViewer(v);
/* 609 */       showGui(true);
/* 610 */       String title = "Reachability Graph";
/* 611 */       if (!this.pn.isBounded()) {
/* 612 */         title = "Coverability Graph";
/*     */       }
/* 614 */       this.rgFrame.setTitle(title + " Visualization - " + this.pn.getName() + " : " + rGraph.toString());
/* 615 */     } catch (Exception e) {
/* 616 */       System.out.printf("construction finished error: cannot display viewer in frame\n", new Object[0]);
/* 617 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void viewPath(RGraph rg, Path path) {
/* 622 */     DebugCounter.inc("viewPath, rg=" + rg.getNumberOfEdges() + " path = " + path.getName());
/*     */     
/* 624 */     ViewerInfo vi = new ViewerInfo(rg, rg.first, this.pn);
/* 625 */     RGVisualisation.visualizePath(vi, false, true, path);
/* 626 */     Viewer v = new Viewer(vi, "reachability graph", Options.maxLayer);
/* 627 */     vi.setViewer(v);
/* 628 */     vi.addPath(path);
/* 629 */     this.rgFrame.addViewer(v, path);
/* 630 */     showGui(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public JPanel getExternalDialog() {
/* 635 */     if (this.externalDialog == null) {
/* 636 */       this.externalDialog = new ReachabilityGraphDialog(this);
/* 637 */       this.externalDialog.initialize();
/*     */     } 
/*     */ 
/*     */     
/* 641 */     this.externalDialog.setPN(this.pn);
/*     */     
/* 643 */     return (JPanel)this.externalDialog;
/*     */   }
/*     */   
/*     */   public JPanel getExternalMCDialog() {
/* 647 */     ModelCheckingDialog mcD = new ModelCheckingDialog(this);
/* 648 */     mcD.initialize();
/* 649 */     if (this.externalFormulaDialog == null && mcD != null) {
/* 650 */       this.externalFormulaDialog = mcD;
/* 651 */     } else if (mcD == null) {
/* 652 */       DebugCounter.inc("constructpr ModelCheckingDialog returned null....");
/*     */     } 
/* 654 */     return (JPanel)this.externalFormulaDialog;
/*     */   }
/*     */   
/*     */   public JPanel getExternalPathDialog() {
/* 658 */     if (this.externalPathDialog == null) {
/* 659 */       this.externalPathDialog = new PathComputationDialog(this);
/*     */     }
/* 661 */     return this.externalPathDialog;
/*     */   }
/*     */   
/*     */   private Viewer getNewViewer() {
/* 665 */     if (this.rGraph != null) {
/* 666 */       ViewerInfo vi = new ViewerInfo(this.rGraph);
/* 667 */       RGVisualisation.visualizeRG(vi, false, true);
/* 668 */       String title = "reachability graph: ";
/* 669 */       if (!this.pn.isBounded()) {
/* 670 */         title = "coverability graph: ";
/*     */       }
/* 672 */       Viewer v = new Viewer(vi, title + vi.netInfo(), Options.maxLayer);
/* 673 */       vi.setViewer(v);
/* 674 */       return v;
/*     */     } 
/* 676 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void analyzerHasFinished(Analyzer finished) {
/* 681 */     DebugCounter.inc("RGGui.analyzerHasFinished() returned analyzer : " + finished.getName());
/* 682 */     OptionSet o = finished.getOptionSet();
/* 683 */     if (o instanceof ConstructionOptions) {
/*     */       
/* 685 */       Results r = finished.getResults();
/* 686 */       this.rGraph = (RGraph)finished.getResultObject();
/* 687 */       if (this.rGraph != null && finished.getStatus() == 3) {
/* 688 */         if (((ConstructionOptions)o).boundedness && !this.pn.isBounded()) {
/* 689 */           JOptionPane.showMessageDialog(null, "<html><center> The coverability graph has been constructed.<br>The net is not bounded</center></html>", "construction finished", 2);
/*     */         }
/*     */         
/* 692 */         DebugCounter.inc("RG Construction time:" + finished.getFormatedDuration());
/* 693 */         if (this.externalDialog != null) {
/* 694 */           this.externalDialog.addRGToPanel(this.rGraph);
/* 695 */           this.externalDialog.updateInfo(finished.getFormatedDuration(), Integer.valueOf(this.rGraph.getNumberOfNodes()), Integer.valueOf(this.rGraph.getNumberOfEdges()), Integer.valueOf(this.rGraph.getNumberOfScc()));
/*     */         } 
/* 697 */         if (this.externalPathDialog != null) {
/* 698 */           this.externalPathDialog.addRGToPanel(this.rGraph);
/*     */         }
/* 700 */         if (this.externalFormulaDialog != null) {
/* 701 */           this.externalFormulaDialog.addRGToPanel(this.rGraph);
/*     */         }
/* 703 */         this.appDirector.sendMessage(11, this, o);
/*     */       } 
/* 705 */     } else if (o instanceof MCOptions) {
/* 706 */       MCOptions mco = (MCOptions)o;
/* 707 */       if (mco.mode == 0) {
/* 708 */         this.ctlActive = false;
/* 709 */       } else if (mco.mode == 1) {
/* 710 */         if (!mco.formulaResult && mco.path != null) {
/* 711 */           int answ = JOptionPane.showConfirmDialog(this.rgFrame, "The formula was false, show counter example?", "Question", 0);
/*     */           
/* 713 */           if (answ == 0 && mco.path != null && mco.rg != null) {
/* 714 */             viewPath(mco.rg, mco.path);
/*     */           } else {
/* 716 */             DebugCounter.inc("RGGui: counter example not shown");
/*     */           } 
/*     */         } else {
/* 719 */           DebugCounter.inc("there was no path computed on LTLMCAnalyzer");
/*     */         } 
/* 721 */         this.ltlActive = false;
/*     */       } 
/* 723 */       if (finished.getStatus() == 3) {
/* 724 */         this.appDirector.sendMessage(11, this, o);
/*     */       }
/* 726 */     } else if (o instanceof PathComputationOptions) {
/* 727 */       if (finished.getStatus() == 3) {
/* 728 */         PathComputationOptions po = (PathComputationOptions)o;
/* 729 */         Path p = (Path)o.getResultObject();
/* 730 */         RGraph pathRGraph = ((PathComputationOptions)o).pathRGraph;
/* 731 */         if (p != null && p.last() != null && pathRGraph != null) {
/* 732 */           if (p.getInfinityState() == 0) {
/* 733 */             JOptionPane.showMessageDialog(null, "<html><center>path computed of length " + p.length() + "</center></html>", "", 1);
/* 734 */           } else if (po.computationType != 0) {
/* 735 */             if (p.getInfinityState() == 1) {
/* 736 */               JOptionPane.showMessageDialog(null, "<html><center>No longest path because there are cycles on a path to the node and so the path is infinite.</center></html>", "", 1);
/*     */ 
/*     */               
/* 739 */               Out.errPrintln("No longest path because there are cycles on a path to the node and so the path is infinite.");
/*     */             } else {
/* 741 */               JOptionPane.showMessageDialog(null, "<html><center>No longest path because there are infinite time transitions on a path to the node and so the path is infinite.</center></html>", "", 1);
/*     */ 
/*     */               
/* 744 */               Out.errPrintln("No longest path because there are infinite time transitions on a path to the node and so the path is infinite.");
/*     */             } 
/*     */           } else {
/* 747 */             int showCe = JOptionPane.showConfirmDialog(this.rgFrame, "<html><center>visualize computed path?</center></html>", "result", 1);
/* 748 */             if (showCe == 0) {
/* 749 */               viewPath(pathRGraph, p);
/*     */             }
/*     */           } 
/* 752 */         } else if (p == null) {
/*     */           
/* 754 */           JOptionPane.showMessageDialog(null, "Path construction did not return a path!");
/*     */         } 
/*     */       } 
/* 757 */       if (finished.getStatus() == 3) {
/* 758 */         this.appDirector.sendMessage(11, this, o);
/*     */       } else {
/* 760 */         JOptionPane.showMessageDialog(null, "Path construction was aborted:\n" + finished.getOutput());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean reduceSequences(boolean value) {
/* 767 */     Viewer v = this.rgFrame.getActualViewer();
/* 768 */     if (v == null) {
/* 769 */       return false;
/*     */     }
/* 771 */     RGraph oldGraph = this.rGraph;
/* 772 */     this.rGraph = v.getRG();
/*     */     try {
/* 774 */       if (this.rGraph != null) {
/* 775 */         if (value) {
/* 776 */           this.rGraph.reduceSequences();
/*     */         } else {
/* 778 */           this.rGraph.expandSequences();
/*     */         } 
/* 780 */         Viewer v2 = getNewViewer();
/* 781 */         this.rgFrame.addViewer(v2);
/* 782 */         this.rGraph = oldGraph;
/* 783 */         return true;
/*     */       } 
/* 785 */     } catch (Exception e) {
/* 786 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */     
/* 789 */     this.rGraph = oldGraph;
/*     */     
/* 791 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/RGGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */