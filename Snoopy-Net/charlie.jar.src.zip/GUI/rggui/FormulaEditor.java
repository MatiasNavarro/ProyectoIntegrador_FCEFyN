/*     */ package GUI.rggui;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.io.FileSaver;
/*     */ import GUI.util.TextFile;
/*     */ import charlie.analyzer.mc.Formula;
/*     */ import charlie.analyzer.mc.MCOptions;
/*     */ import charlie.ctl.Main;
/*     */ import charlie.ctl.NoPlaceException;
/*     */ import charlie.ltl.LTL_Main;
/*     */ import charlie.pn.Place;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.rg.RGraph;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ public class FormulaEditor
/*     */   extends JFrame
/*     */ {
/*     */   private static final long serialVersionUID = 7290131559078370378L;
/*  40 */   private static final Log LOG = LogFactory.getLog(FormulaEditor.class);
/*     */   
/*  42 */   public byte mode = 0;
/*  43 */   private IRGDirector director = null;
/*     */   private String filename;
/*  45 */   private JTextArea textArea = new JTextArea();
/*  46 */   private JButton save = new JButton("<html><center>save</center></html>");
/*  47 */   private JButton saveAs = new JButton("<html><center>save As</center></html>");
/*  48 */   private JButton checkSyntax = new JButton("<html><center>check syntax</center></html>");
/*  49 */   private JButton choose = new JButton("<html><center>choose placename</center></html>");
/*  50 */   private JButton checkFormula = new JButton("<html><center>check formula</center></html>");
/*     */   private JList placeList;
/*  52 */   private RGraph rGraph = null;
/*  53 */   private PlaceTransitionNet pn = null;
/*  54 */   private JPanel buttons = new JPanel();
/*  55 */   private static FormulaEditor formulaEditor = null;
/*     */   
/*     */   private FormulaEditor(IRGDirector d, PlaceTransitionNet pn, RGraph rg, byte mode) {
/*  58 */     super("formula editor");
/*  59 */     this.director = d;
/*  60 */     this.mode = mode;
/*  61 */     this.pn = pn;
/*  62 */     this.rGraph = rg;
/*     */   }
/*     */   
/*     */   public static FormulaEditor getInstance(IRGDirector d, PlaceTransitionNet pn, RGraph rg, byte mode, File file) {
/*  66 */     if (formulaEditor == null) {
/*  67 */       formulaEditor = new FormulaEditor(d, pn, rg, mode);
/*  68 */       formulaEditor.initialize();
/*     */     } else {
/*  70 */       formulaEditor.rGraph = rg;
/*  71 */       formulaEditor.pn = pn;
/*  72 */       formulaEditor.mode = mode;
/*     */     } 
/*  74 */     formulaEditor.setFilename(file.getAbsolutePath());
/*  75 */     return formulaEditor;
/*     */   }
/*     */   
/*     */   public static FormulaEditor getInstance(IRGDirector d, PlaceTransitionNet pn, RGraph rg, byte mode, String formula) {
/*  79 */     if (formulaEditor == null) {
/*  80 */       formulaEditor = new FormulaEditor(d, pn, rg, mode);
/*  81 */       formulaEditor.initialize();
/*     */     } else {
/*  83 */       formulaEditor.rGraph = rg;
/*  84 */       formulaEditor.pn = pn;
/*  85 */       formulaEditor.mode = mode;
/*     */     } 
/*  87 */     formulaEditor.setFormula(formula);
/*  88 */     return formulaEditor;
/*     */   }
/*     */ 
/*     */   
/*     */   public static FormulaEditor getInstance(IRGDirector d, PlaceTransitionNet pn, RGraph rg, byte mode) {
/*  93 */     if (formulaEditor == null) {
/*  94 */       formulaEditor = new FormulaEditor(d, pn, rg, mode);
/*  95 */       formulaEditor.initialize();
/*     */     } else {
/*  97 */       formulaEditor.rGraph = rg;
/*  98 */       formulaEditor.pn = pn;
/*  99 */       formulaEditor.mode = mode;
/*     */     } 
/*     */     
/* 102 */     return formulaEditor;
/*     */   }
/*     */   
/*     */   public void initialize() {
/* 106 */     setFilename(this.filename);
/* 107 */     this.placeList = new JList(this.pn.getPlaces().toArray());
/* 108 */     this.placeList.setSelectionMode(0);
/* 109 */     this.placeList.addMouseListener(new MouseAdapter()
/*     */         {
/*     */           public void mouseClicked(MouseEvent e)
/*     */           {
/* 113 */             if (e.getClickCount() == 2) {
/* 114 */               Place p = FormulaEditor.this.placeList.getSelectedValue();
/* 115 */               FormulaEditor.this.textArea.insert(p.getName(), FormulaEditor.this.textArea.getCaretPosition());
/*     */             } 
/*     */           }
/*     */         });
/* 119 */     getContentPane().setLayout(new BorderLayout());
/* 120 */     JPanel content = new JPanel();
/* 121 */     content.setLayout(new GridLayout(1, 2));
/* 122 */     JPanel placesPanel = new JPanel();
/* 123 */     placesPanel.setLayout(new BorderLayout());
/* 124 */     placesPanel.add(new JScrollPane(this.placeList), "Center");
/* 125 */     this.choose.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 127 */             if (FormulaEditor.this.placeList.getSelectedIndex() != -1) {
/* 128 */               Object value = FormulaEditor.this.placeList.getSelectedValue();
/* 129 */               String insertValue = "";
/* 130 */               if (value instanceof String) {
/* 131 */                 insertValue = (String)value;
/* 132 */               } else if (value instanceof Place) {
/* 133 */                 insertValue = ((Place)value).getName();
/*     */               } else {
/* 135 */                 throw new RuntimeException("The object is neither a string nor a place.");
/*     */               } 
/* 137 */               FormulaEditor.this.textArea.insert(insertValue, FormulaEditor.this.textArea.getCaretPosition());
/*     */             } 
/*     */           }
/*     */         });
/* 141 */     getContentPane().add(content, "Center");
/* 142 */     content.add(new JScrollPane(this.textArea));
/* 143 */     content.add(placesPanel);
/* 144 */     this.save.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/*     */             try {
/* 148 */               FileWriter fw = new FileWriter(FormulaEditor.this.getFilename());
/* 149 */               BufferedWriter bf = new BufferedWriter(fw);
/* 150 */               bf.write(FormulaEditor.this.getFormula(), 0, FormulaEditor.this.getFormula().length());
/* 151 */               bf.close();
/* 152 */               fw.close();
/* 153 */             } catch (IOException ioe) {
/* 154 */               FormulaEditor.LOG.error(ioe.getMessage(), ioe);
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 159 */     this.saveAs.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/*     */             try {
/* 162 */               String formula = FormulaEditor.this.textArea.getText();
/* 163 */               boolean so = false;
/* 164 */               so = FormulaEditor.this.checkSyntax(formula);
/* 165 */               if (!so) {
/*     */                 return;
/*     */               }
/*     */               
/* 169 */               CustomFileChooser fc = new CustomFileChooser(new File(FileSaver.lastSaveDir), FormulaEditor.this.getFilter());
/* 170 */               fc.showSaveDialog(null);
/* 171 */               String filename = fc.getFileName();
/* 172 */               if (filename == null) {
/*     */                 return;
/*     */               }
/* 175 */               if (FormulaEditor.this.mode() == 1 && !filename.endsWith(".ltl")) {
/* 176 */                 filename = filename + ".ltl";
/* 177 */               } else if (FormulaEditor.this.mode() == 0 && !filename.endsWith(".ctl")) {
/* 178 */                 filename = filename + ".ctl";
/*     */               } 
/*     */               
/* 181 */               FormulaEditor.this.setFilename(filename);
/* 182 */               FileWriter fw = new FileWriter(filename);
/* 183 */               BufferedWriter bf = new BufferedWriter(fw);
/* 184 */               bf.write(formula, 0, formula.length());
/* 185 */               bf.close();
/* 186 */               fw.close();
/* 187 */             } catch (IOException ioe) {
/* 188 */               FormulaEditor.LOG.error(ioe.getMessage(), ioe);
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 193 */     this.checkSyntax.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 195 */             String formula = FormulaEditor.this.textArea.getText();
/* 196 */             if (FormulaEditor.this.checkSyntax(formula)) {
/* 197 */               JOptionPane.showMessageDialog(null, "syntax ok", "", 1);
/*     */             }
/*     */           }
/*     */         });
/* 201 */     this.checkFormula.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 203 */             FormulaEditor.this.checkFormula(FormulaEditor.this.textArea.getText());
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 208 */     this.buttons.add(this.save);
/* 209 */     this.buttons.add(this.saveAs);
/* 210 */     this.buttons.add(this.checkSyntax);
/* 211 */     this.buttons.add(this.choose);
/* 212 */     this.buttons.add(this.checkFormula);
/* 213 */     getContentPane().add(this.buttons, "South");
/* 214 */     pack();
/*     */   }
/*     */   
/*     */   public byte mode() {
/* 218 */     return this.mode;
/*     */   }
/*     */   
/*     */   private boolean checkFormula(String formula) {
/* 222 */     if (this.rGraph != null && this.pn != null && formula != null && !formula.equals("")) {
/* 223 */       MCOptions mco = new MCOptions();
/* 224 */       mco.rg = this.rGraph;
/* 225 */       mco.pn = this.pn;
/* 226 */       mco.formula = formula;
/* 227 */       mco.setObjectToAnalyze(this.rGraph);
/* 228 */       mco.setResultObject(new Formula(formula, mode()));
/* 229 */       mco.mode = mode();
/* 230 */       if (!this.director.sendMessage(24, this, mco)) {
/* 231 */         JOptionPane.showMessageDialog(this, "AnalyzerManager could not start check formula.");
/*     */       }
/*     */     } 
/*     */     
/* 235 */     return false;
/*     */   }
/*     */   
/*     */   public boolean checkSyntax(String formula) {
/* 239 */     formula = formula.trim();
/* 240 */     if (formula == null || formula.equals("")) {
/* 241 */       return false;
/*     */     }
/*     */     try {
/* 244 */       if (mode() == 1) {
/* 245 */         DebugCounter.inc("FormulaEditor.checkSyntax() mode = ltl\n\tFormula: " + formula);
/* 246 */         LTL_Main.checkSyntax(new StringReader(formula));
/* 247 */       } else if (mode() == 0) {
/* 248 */         Main.rg = this.rGraph;
/* 249 */         DebugCounter.inc("FormulaEditor.checkSyntax() mode = ctl\n\tFormula: " + formula);
/* 250 */         Main.checkSyntax(new StringReader(formula));
/*     */       } 
/* 252 */       return true;
/* 253 */     } catch (NoPlaceException npe) {
/* 254 */       LOG.error(npe.getMessage(), (Throwable)npe);
/*     */       
/* 256 */       JOptionPane.showMessageDialog(this, "<html><center>FormulaEditor: parse-error!<p>" + npe.getMessage() + "</center></html>", "", 0);
/*     */       
/* 258 */       Main.resultText = new StringBuffer();
/* 259 */     } catch (IOException ioe) {
/* 260 */       LOG.error(ioe.getMessage(), ioe);
/* 261 */     } catch (Exception exc) {
/* 262 */       LOG.error(exc.getMessage(), exc);
/*     */       
/* 264 */       JOptionPane.showMessageDialog(this, "<html><p>FormulaEditor: syntax-error! check the formula</p><p>Message: " + exc.getMessage() + "</p></html>", "", 0);
/*     */       
/* 266 */       Main.resultText = new StringBuffer();
/*     */     } 
/* 268 */     return false;
/*     */   }
/*     */   
/*     */   public String getFormula() {
/* 272 */     return this.textArea.getText();
/*     */   }
/*     */   
/*     */   public String getFilename() {
/* 276 */     return this.filename;
/*     */   }
/*     */   
/*     */   public void setFormula(String formula) {
/* 280 */     if (!formula.equals("")) {
/* 281 */       this.textArea.setText(formula);
/* 282 */       this.save.setEnabled(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFilename(String filename) {
/* 288 */     this.filename = filename;
/* 289 */     this.save.setEnabled((filename != null));
/* 290 */     if (filename != null) {
/* 291 */       if (filename.endsWith("ltl")) {
/* 292 */         this.mode = 1;
/*     */       }
/* 294 */       if (filename.endsWith("ctl")) {
/* 295 */         this.mode = 0;
/*     */       }
/*     */ 
/*     */       
/* 299 */       setNewTitle(filename);
/* 300 */       String text = TextFile.readTextFile(new File(filename));
/* 301 */       this.textArea.setText(text);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setNewTitle(String filename) {
/* 306 */     String title = "ctl-";
/* 307 */     if (this.mode == 1) {
/* 308 */       title = "ltl-";
/*     */     }
/* 310 */     title = title + "editor";
/* 311 */     if (filename != null) {
/* 312 */       title = title + "  " + filename;
/*     */     }
/* 314 */     setTitle(title);
/*     */   }
/*     */   
/*     */   public String getFilter() {
/* 318 */     String filter = ".ctl";
/* 319 */     if (this.mode == 1) {
/* 320 */       filter = ".ltl";
/*     */     }
/* 322 */     return filter;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/FormulaEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */