/*     */ package GUI.rggui;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.io.FileSaver;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RGMenu
/*     */   extends JMenuBar
/*     */ {
/*     */   private static final long serialVersionUID = 9104361950262669389L;
/*  28 */   private File actualSession = null;
/*  29 */   private File actualGraph = null;
/*     */   private IDirector director;
/*     */   
/*     */   public RGMenu(IDirector director) {
/*  33 */     this.director = director;
/*     */   }
/*     */ 
/*     */   
/*     */   public static JMenuBar getMenu(IDirector director) {
/*  38 */     RGMenu menu = new RGMenu(director);
/*  39 */     menu.initialize();
/*  40 */     return menu;
/*     */   }
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  45 */     JMenu fileMenu = new JMenu("file");
/*  46 */     JMenuItem loadGraph = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/*  55 */             DebugCounter.inc("RGMenu JMenuItem.loadGraph( )");
/*  56 */             FileSaver fs = new FileSaver();
/*  57 */             File xmlFile = fs.showOpenDialog(RGMenu.this.actualGraph, new FileNameExtensionFilter("Graph File .graph", new String[] { "graph" }));
/*  58 */             if (xmlFile != null) {
/*  59 */               boolean b = RGMenu.this.director.sendMessage(11, this, xmlFile);
/*  60 */               if (!b) {
/*  61 */                 JOptionPane.showMessageDialog(null, "Could not load graph, check loaded net or constrcuted rg!");
/*     */               } else {
/*  63 */                 RGMenu.this.actualGraph = xmlFile;
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/*  69 */     JMenuItem saveGraph = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/*  78 */             DebugCounter.inc("RGMenu JMenuItem.saveGraph( )");
/*  79 */             File saveFile = (new FileSaver()).showSaveDialog(RGMenu.this.actualGraph, null, "graph");
/*  80 */             if (saveFile != null) {
/*  81 */               boolean b = RGMenu.this.director.sendMessage(12, this, saveFile);
/*  82 */               if (!b) {
/*  83 */                 JOptionPane.showMessageDialog(null, "could not store graph!");
/*     */               } else {
/*  85 */                 RGMenu.this.actualGraph = saveFile;
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*  92 */     JMenuItem exportGraph = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 101 */             DebugCounter.inc("RGMenu JMenuItem.printGraph( )");
/* 102 */             boolean b = RGMenu.this.director.sendMessage(30, this, null);
/* 103 */             if (!b) {
/* 104 */               JOptionPane.showMessageDialog(null, "could not export graph!");
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 109 */     JMenuItem loadSession = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 118 */             DebugCounter.inc("RGMenu JMenuItem.loadSession( )");
/* 119 */             FileSaver fs = new FileSaver();
/* 120 */             File xmlFile = fs.showOpenDialog(RGMenu.this.actualSession, new FileNameExtensionFilter("RG Session File .zip", new String[] { "zip" }));
/* 121 */             if (xmlFile != null) {
/* 122 */               boolean b = RGMenu.this.director.sendMessage(13, this, xmlFile);
/* 123 */               if (!b) {
/* 124 */                 JOptionPane.showMessageDialog(null, "Could not load session, check loaded net or constrcuted rg!");
/*     */               } else {
/* 126 */                 RGMenu.this.actualSession = xmlFile;
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 132 */     JMenuItem saveSession = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 141 */             DebugCounter.inc("RGMenu JMenuItem.saveSession( )");
/* 142 */             File saveFile = (new FileSaver()).showSaveDialog(RGMenu.this.actualSession, null, "zip");
/* 143 */             if (saveFile != null) {
/* 144 */               boolean b = RGMenu.this.director.sendMessage(14, this, saveFile);
/* 145 */               if (!b) {
/* 146 */                 JOptionPane.showMessageDialog(null, "Could not save session!");
/*     */               } else {
/* 148 */                 RGMenu.this.actualSession = saveFile;
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/* 153 */     JMenuItem hideWindow = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 163 */             DebugCounter.inc("RGMenu JMenuItem.exit-hide-Program( )");
/* 164 */             if (RGMenu.this.director != null)
/*     */             {
/*     */               
/* 167 */               RGMenu.this.director.sendMessage(23, this, new Boolean(false));
/*     */             }
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 174 */     fileMenu.add(loadGraph);
/* 175 */     fileMenu.add(saveGraph);
/* 176 */     fileMenu.add(exportGraph);
/* 177 */     fileMenu.add(loadSession);
/* 178 */     fileMenu.add(saveSession);
/* 179 */     fileMenu.add(hideWindow);
/* 180 */     add(fileMenu);
/* 181 */     JMenu sequencesMenu = new JMenu("sequences");
/* 182 */     JMenuItem reduceSequences = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 193 */             if (RGMenu.this.director != null)
/*     */             {
/*     */               
/* 196 */               RGMenu.this.director.sendMessage(29, this, new Boolean(true));
/*     */             }
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 202 */     JMenuItem expandSequences = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 212 */             if (RGMenu.this.director != null)
/*     */             {
/*     */               
/* 215 */               RGMenu.this.director.sendMessage(29, this, new Boolean(false));
/*     */             }
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 221 */     sequencesMenu.add(reduceSequences);
/* 222 */     sequencesMenu.add(expandSequences);
/* 223 */     add(sequencesMenu);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/RGMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */