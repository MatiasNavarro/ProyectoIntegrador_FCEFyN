/*     */ package GUI.rggui;
/*     */ import GUI.IDirector;
/*     */ import GUI.app_components.ComputationalDialog;
/*     */ import GUI.io.FileSaver;
/*     */ import charlie.analyzer.mc.Formula;
/*     */ import charlie.analyzer.mc.MCOptions;
/*     */ import charlie.rg.RGraph;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ public class ModelCheckingDialog extends ComputationalDialog {
/*  31 */   private JButton jButtonLoadFormula = null;
/*  32 */   private JButton jButtonFormulaEditor = null;
/*  33 */   private JButton jButtonCompute = null;
/*  34 */   private JRadioButton jRadioCTL = null;
/*  35 */   private JComboBox jComboRGraph = null;
/*  36 */   private JRadioButton jRadioLTL = null;
/*  37 */   private JComboBox jComboFormulaFile = null;
/*  38 */   private JRadioButton jRadioFileMode = null;
/*  39 */   private JRadioButton jRadioQuickMode = null;
/*  40 */   private JTextField jTextQuickFormula = null;
/*  41 */   private JPanel thisPanel = null;
/*  42 */   private HashMap<MyFile, JRadioButton> extensionFileMap = new HashMap<>();
/*     */   
/*     */   public ModelCheckingDialog(IDirector director) {
/*  45 */     super(director);
/*     */     
/*  47 */     this.thisPanel = (JPanel)this;
/*     */   }
/*     */   
/*     */   private JRadioButton getCTLButton() {
/*  51 */     this.jRadioCTL = new JRadioButton(new AbstractAction()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {}
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     return this.jRadioCTL;
/*     */   }
/*     */   
/*     */   private JRadioButton getLTLButton() {
/*  64 */     this.jRadioLTL = new JRadioButton("ltl");
/*  65 */     return this.jRadioLTL;
/*     */   }
/*     */   
/*     */   private JButton getLoadFormula() {
/*  69 */     this.jButtonLoadFormula = new JButton(new AbstractAction("load formula")
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/*  74 */             ModelCheckingDialog.MyFile formulaFile = null;
/*  75 */             FileSaver fs = new FileSaver();
/*  76 */             formulaFile = new ModelCheckingDialog.MyFile(fs.showOpenDialog(null, new FileNameExtensionFilter("fomula file (.ctl , .ltl)", new String[] { "ctl", "ltl" })));
/*  77 */             JRadioButton button = null;
/*  78 */             if (formulaFile.getExtension().equals("ctl")) {
/*  79 */               button = ModelCheckingDialog.this.jRadioCTL;
/*  80 */             } else if (formulaFile.getExtension().equals("ltl")) {
/*  81 */               button = ModelCheckingDialog.this.jRadioLTL;
/*  82 */             } else if (formulaFile.file != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*  87 */               String[] options = { "CTL", "LTL", "Cancel" };
/*  88 */               int answ = JOptionPane.showOptionDialog(ModelCheckingDialog.this.thisPanel, "<html><p>The extension of the loaded formula file, is unknown : " + formulaFile
/*  89 */                   .getExtension() + "</p><p> make sure it contain a valid formula!</p><p>Choose the type of the formulas:</p></html>", "Question, choose formulatype", -1, 3, null, (Object[])options, options[2]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*  97 */               switch (answ) { case 0:
/*  98 */                   button = ModelCheckingDialog.this.jRadioCTL; break;
/*  99 */                 case 1: button = ModelCheckingDialog.this.jRadioLTL; break;
/* 100 */                 case 2: button = null; break; }
/*     */             
/*     */             } 
/* 103 */             if (formulaFile.file != null && button != null) {
/* 104 */               ModelCheckingDialog.this.extensionFileMap.put(formulaFile, button);
/* 105 */               ModelCheckingDialog.this.jComboFormulaFile.addItem(formulaFile);
/* 106 */               ModelCheckingDialog.this.jComboFormulaFile.setSelectedItem(formulaFile);
/* 107 */               button.setSelected(true);
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 113 */     return this.jButtonLoadFormula;
/*     */   }
/*     */   
/*     */   private JButton getFormulaEditorButton() {
/* 117 */     this.jButtonFormulaEditor = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 127 */             ModelCheckingDialog.MyFile mf = (ModelCheckingDialog.MyFile)ModelCheckingDialog.this.jComboFormulaFile.getSelectedItem();
/* 128 */             if (mf != null) {
/* 129 */               if (!ModelCheckingDialog.this.getDirector().sendMessage(25, this, mf.file)) {
/* 130 */                 JOptionPane.showMessageDialog(ModelCheckingDialog.this.thisPanel, "Could not start editing of formula");
/*     */               }
/*     */             }
/* 133 */             else if (!ModelCheckingDialog.this.getDirector().sendMessage(25, this, null)) {
/* 134 */               JOptionPane.showMessageDialog(ModelCheckingDialog.this.thisPanel, "Could not start editing of formula");
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 140 */     return this.jButtonFormulaEditor;
/*     */   }
/*     */   
/*     */   private JComboBox getJComboRGraph() {
/* 144 */     this.jComboRGraph = new JComboBox(new DefaultComboBoxModel());
/* 145 */     this.jComboRGraph.setToolTipText("computed reachability graphs");
/* 146 */     return this.jComboRGraph;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize() {
/* 151 */     int line = 0;
/*     */     
/* 153 */     double h = 25.0D;
/* 154 */     double[][] size = { { 5.0D, 115.0D, 5.0D, 175.0D, 5.0D }, { 5.0D, 5.0D } };
/* 155 */     TableLayout layout = new TableLayout(size);
/* 156 */     setLayout((LayoutManager)layout);
/*     */ 
/*     */     
/* 159 */     layout.insertRow(++line, h);
/* 160 */     add(new JLabel("r-graph"), "1," + line);
/* 161 */     add(getJComboRGraph(), "3," + line);
/* 162 */     layout.insertRow(++line, h);
/* 163 */     add(new JLabel("mode"), "1," + line);
/* 164 */     add(getModePanel(), "3," + line);
/* 165 */     layout.insertRow(++line, h);
/* 166 */     this.jRadioFileMode = new JRadioButton("use file");
/* 167 */     this.jRadioFileMode.setSelected(true);
/* 168 */     add(this.jRadioFileMode, "1," + line);
/* 169 */     add(getJComboFormulaFile(), "3," + line);
/* 170 */     layout.insertRow(++line, h);
/* 171 */     add(getLoadFormula(), "3," + line);
/* 172 */     layout.insertRow(++line, h);
/* 173 */     add(getFormulaEditorButton(), "3," + line);
/* 174 */     layout.insertRow(++line, h);
/* 175 */     this.jRadioQuickMode = new JRadioButton("quick formula");
/* 176 */     this.jRadioQuickMode.setToolTipText("quick formula");
/* 177 */     add(this.jRadioQuickMode, "1," + line);
/* 178 */     this.jTextQuickFormula = new JTextField(30);
/* 179 */     this.jTextQuickFormula.setToolTipText("insert a short formula for instant checking");
/* 180 */     add(this.jTextQuickFormula, "3," + line);
/* 181 */     layout.insertRow(++line, h);
/* 182 */     this.jButtonCompute = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 188 */             ModelCheckingDialog.this.onCompute();
/*     */           }
/*     */         });
/* 191 */     add(this.jButtonCompute, "1," + line + ",3," + line);
/*     */     
/* 193 */     ButtonGroup bg = new ButtonGroup();
/* 194 */     bg.add(this.jRadioFileMode);
/* 195 */     bg.add(this.jRadioQuickMode);
/*     */     
/* 197 */     enableControls(false);
/* 198 */     Dimension d = layout.preferredLayoutSize((Container)this);
/* 199 */     setSize(d);
/* 200 */     setPreferredSize(d);
/*     */   }
/*     */   
/*     */   public byte getMCMode() {
/* 204 */     if (this.jRadioCTL.isSelected())
/* 205 */       return 0; 
/* 206 */     if (this.jRadioLTL.isSelected()) {
/* 207 */       return 1;
/*     */     }
/* 209 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private JPanel getModePanel() {
/* 214 */     double[][] size = { { 85.0D, 5.0D, 85.0D }, { 25.0D } };
/* 215 */     TableLayout layout = new TableLayout(size);
/* 216 */     JPanel p = new JPanel((LayoutManager)layout);
/* 217 */     p.add(getCTLButton(), "0,0");
/* 218 */     p.add(getLTLButton(), "2,0");
/* 219 */     ButtonGroup bg = new ButtonGroup();
/* 220 */     bg.add(this.jRadioCTL);
/* 221 */     bg.add(this.jRadioLTL);
/* 222 */     this.jRadioCTL.setSelected(true);
/* 223 */     return p;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addRGToPanel(RGraph rg) {
/* 228 */     DefaultComboBoxModel<RGraph> model = (DefaultComboBoxModel)this.jComboRGraph.getModel();
/* 229 */     if (model.getIndexOf(rg) < 0) {
/* 230 */       if (model.getSize() == 0) {
/* 231 */         enableControls(true);
/*     */       }
/* 233 */       model.addElement(rg);
/* 234 */       model.setSelectedItem(rg);
/*     */     } 
/*     */   }
/*     */   
/*     */   public RGraph getSelectedRGraph() {
/* 239 */     return (RGraph)this.jComboRGraph.getModel().getSelectedItem();
/*     */   }
/*     */   
/*     */   private JComboBox getJComboFormulaFile() {
/* 243 */     this.jComboFormulaFile = new JComboBox(new DefaultComboBoxModel());
/* 244 */     this.jComboFormulaFile.setToolTipText("previously loaded files");
/* 245 */     this.jComboFormulaFile.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent e) {
/* 247 */             ModelCheckingDialog.MyFile f = (ModelCheckingDialog.MyFile)((JComboBox)e.getSource()).getSelectedItem();
/* 248 */             if (f != null) {
/* 249 */               ((JRadioButton)ModelCheckingDialog.this.extensionFileMap.get(f)).setSelected(true);
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 254 */     return this.jComboFormulaFile;
/*     */   }
/*     */   
/*     */   public void enableControls(boolean b) {
/* 258 */     this.jButtonLoadFormula.setEnabled(b);
/* 259 */     this.jButtonFormulaEditor.setEnabled(b);
/* 260 */     this.jRadioCTL.setEnabled(b);
/* 261 */     this.jComboRGraph.setEnabled(b);
/* 262 */     this.jRadioLTL.setEnabled(b);
/* 263 */     this.jComboFormulaFile.setEnabled(b);
/* 264 */     this.jRadioFileMode.setEnabled(b);
/* 265 */     this.jRadioQuickMode.setEnabled(b);
/* 266 */     this.jTextQuickFormula.setEnabled(b);
/* 267 */     this.jButtonCompute.setEnabled(b);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(boolean b) {
/* 273 */     if (b) {
/* 274 */       this.jComboFormulaFile.removeAllItems();
/* 275 */       this.jComboRGraph.removeAllItems();
/*     */     } 
/* 277 */     enableControls(false);
/*     */   }
/*     */   
/*     */   public void onCompute() {
/* 281 */     MCOptions mco = new MCOptions();
/* 282 */     if (this.jComboRGraph.getSelectedItem() != null) {
/* 283 */       mco.rg = (RGraph)this.jComboRGraph.getSelectedItem();
/* 284 */       if (this.jRadioFileMode.isSelected() && this.jComboFormulaFile.getSelectedItem() != null) {
/* 285 */         mco.formula = TextFile.readTextFile(((MyFile)this.jComboFormulaFile.getSelectedItem()).file);
/* 286 */       } else if (this.jRadioQuickMode.isSelected() && !this.jTextQuickFormula.getText().equals("")) {
/* 287 */         mco.formula = this.jTextQuickFormula.getText();
/*     */       } else {
/* 289 */         JOptionPane.showMessageDialog((Component)this, "Please choose a file that contains a formula or type in a formula in the quick formula textfield!");
/*     */         return;
/*     */       } 
/* 292 */       mco.setObjectToAnalyze(mco.rg);
/* 293 */       mco.setResultObject(new Formula(mco.formula, getMCMode()));
/* 294 */       mco.mode = getMCMode();
/* 295 */       if (!getDirector().sendMessage(24, this, mco)) {
/* 296 */         JOptionPane.showMessageDialog((Component)this, "FormulaEditor: Cannot start model checking, please check formula or loaded file!");
/*     */       }
/*     */     } else {
/*     */       
/* 300 */       JOptionPane.showMessageDialog(this.thisPanel, "You need a constructed reachability graph to perform model checking!");
/*     */     } 
/*     */   }
/*     */   
/*     */   private class MyFile {
/* 305 */     public File file = null;
/*     */     
/*     */     public MyFile(File f) {
/* 308 */       this.file = f;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 313 */       if (this.file != null) {
/* 314 */         return this.file.getName();
/*     */       }
/* 316 */       return "No file";
/*     */     }
/*     */ 
/*     */     
/*     */     public String getExtension() {
/* 321 */       if (this.file != null && 
/* 322 */         this.file.getName().lastIndexOf(".") >= 0) {
/* 323 */         String s = this.file.getName().substring(this.file.getName().lastIndexOf(".") + 1);
/* 324 */         DebugCounter.inc("MyFile.getExtension() = " + s);
/* 325 */         return s;
/*     */       } 
/*     */       
/* 328 */       return "";
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/ModelCheckingDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */