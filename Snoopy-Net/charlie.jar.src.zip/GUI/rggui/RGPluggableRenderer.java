/*    */ package GUI.rggui;
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.vis.RGEdgePaintFunction;
/*    */ import charlie.vis.RGVertexShapeFunction;
/*    */ import charlie.vis.RGVertexSizeFunction;
/*    */ import charlie.vis.ViewerInfo;
/*    */ import edu.uci.ics.jung.graph.decorators.EdgePaintFunction;
/*    */ import edu.uci.ics.jung.graph.decorators.EdgeShape;
/*    */ import edu.uci.ics.jung.graph.decorators.EdgeShapeFunction;
/*    */ import edu.uci.ics.jung.graph.decorators.EdgeStringer;
/*    */ import edu.uci.ics.jung.graph.decorators.VertexPaintFunction;
/*    */ import edu.uci.ics.jung.graph.decorators.VertexStringer;
/*    */ import edu.uci.ics.jung.visualization.PluggableRenderer;
/*    */ 
/*    */ public class RGPluggableRenderer extends PluggableRenderer {
/* 16 */   private ViewerInfo vi = null;
/* 17 */   private PlaceTransitionNet pn = null;
/*    */ 
/*    */   
/*    */   public RGPluggableRenderer(ViewerInfo vi, PlaceTransitionNet pn) {
/* 21 */     this.vi = vi;
/* 22 */     this.pn = pn;
/* 23 */     initialize();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void initialize() {
/* 29 */     setEdgeShapeFunction((EdgeShapeFunction)new EdgeShape.QuadCurve());
/* 30 */     setEdgePaintFunction((EdgePaintFunction)new RGEdgePaintFunction(this.vi));
/* 31 */     setVertexStringer((VertexStringer)new SimpleVertexStringer(this.vi));
/* 32 */     setEdgeStringer((EdgeStringer)new SimpleEdgeStringer(this.pn));
/* 33 */     setVertexPaintFunction((VertexPaintFunction)new RGVertexPaintFunction(this.vi));
/* 34 */     setVertexShapeFunction((VertexShapeFunction)new RGVertexShapeFunction((VertexSizeFunction)new RGVertexSizeFunction(this.vi), (VertexAspectRatioFunction)new RGVertexAspectRatioFunction(), this.vi));
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/RGPluggableRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */