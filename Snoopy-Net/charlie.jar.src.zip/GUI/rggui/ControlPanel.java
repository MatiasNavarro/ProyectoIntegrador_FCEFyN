/*     */ package GUI.rggui;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.io.FileSaver;
/*     */ import GUI.util.ExportJCheckBoxMenuItem;
/*     */ import GUI.util.MyButton;
/*     */ import GUI.util.MyMouseWheelListener;
/*     */ import GUI.util.ResourceLoader;
/*     */ import GUI.util.TextFile;
/*     */ import charlie.rg.Path;
/*     */ import charlie.vis.Options;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.MouseInfo;
/*     */ import java.awt.Point;
/*     */ import java.awt.PointerInfo;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JColorChooser;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ public class ControlPanel extends JPanel {
/*     */   private static final long serialVersionUID = 4971257552810884219L;
/*  55 */   private Double zoomInFactor = new Double(1.1D);
/*  56 */   private Double zoomOutFactor = new Double(0.9D);
/*     */   
/*     */   private static final double vGap = 3.0D;
/*     */   
/*     */   private static final double hGap = 3.0D;
/*     */   
/*     */   private static final double width = 150.0D;
/*     */   
/*     */   private static final double lineHeight = 20.0D;
/*     */   
/*  66 */   public static JList pathList = null;
/*  67 */   public static JList filterList = null;
/*  68 */   private DefaultListModel dummyList = new DefaultListModel();
/*  69 */   private RGFrame rgFrame = null;
/*  70 */   private Component owner = null;
/*     */   String netInfo;
/*  72 */   private IDirector director = null;
/*  73 */   private Dimension buttonDimension = new Dimension(150, 25);
/*     */   
/*  75 */   private ExportJCheckBoxMenuItem mseqExportFileItem = null;
/*  76 */   private ExportJCheckBoxMenuItem tseqExportFileItem = null;
/*  77 */   private ExportJCheckBoxMenuItem parikhExportFileItem = null;
/*     */   
/*     */   public ControlPanel(IDirector director, RGFrame owner) {
/*  80 */     this.director = director;
/*  81 */     this.rgFrame = owner;
/*  82 */     initialize();
/*  83 */     enableControls(false);
/*     */   }
/*     */   
/*     */   public void initialize() {
/*  87 */     double p = -2.0D;
/*  88 */     double[][] size = { { 166.0D }, { 20.0D, p, p, p, p, p } };
/*     */     
/*  90 */     TableLayout layout = new TableLayout(size);
/*  91 */     setLayout((LayoutManager)layout);
/*     */     
/*  93 */     add(new JLabel("controls"), "0,0");
/*  94 */     add(getVisualizationPanel(), "0,1");
/*  95 */     add(getFilterPanel(), "0,2");
/*  96 */     add(getPathPanel(), "0,3");
/*     */     
/*  98 */     add(getVisOptionPanel(), "0,5");
/*  99 */     Dimension d = layout.preferredLayoutSize(this);
/*     */     
/* 101 */     setSize(d);
/* 102 */     setPreferredSize(d);
/*     */   }
/*     */ 
/*     */   
/*     */   private JPanel getPathPanel() {
/* 107 */     JPanel p = new JPanel();
/* 108 */     p.setBorder(BorderFactory.createTitledBorder("path"));
/* 109 */     double[][] size = { { 3.0D, 150.0D, 3.0D }, { 3.0D, 20.0D, 20.0D, -2.0D, 3.0D } };
/*     */     
/* 111 */     TableLayout layout = new TableLayout(size);
/* 112 */     p.setLayout((LayoutManager)layout);
/*     */     
/* 114 */     JButton deletePath = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 121 */             (ControlPanel.this.rgFrame.getActualViewer()).vi.clearPath();
/* 122 */             ControlPanel.this.rgFrame.getActualViewer().actualise();
/*     */           }
/*     */         });
/*     */     
/* 126 */     deletePath.setSize(this.buttonDimension);
/* 127 */     deletePath.setPreferredSize(this.buttonDimension);
/* 128 */     p.add(deletePath, "1,1");
/*     */     
/* 130 */     JButton exportOptions = new JButton("export");
/* 131 */     final JPopupMenu menu = new JPopupMenu();
/* 132 */     menu.add(new JMenuItem("export"));
/* 133 */     menu.addSeparator();
/*     */     
/* 135 */     this.mseqExportFileItem = new ExportJCheckBoxMenuItem("export marking sequence", "path.mseq", "export marking sequence to file:", FileSaver.lastSaveDir);
/*     */ 
/*     */     
/* 138 */     this.tseqExportFileItem = new ExportJCheckBoxMenuItem("export transition sequence", "path.tseq", "export transition sequence to file:", FileSaver.lastSaveDir);
/*     */ 
/*     */     
/* 141 */     this.parikhExportFileItem = new ExportJCheckBoxMenuItem("export parikh vector", "path_parikh.res", "export parikh vector to file:", FileSaver.lastSaveDir);
/*     */ 
/*     */     
/* 144 */     menu.add((JMenuItem)this.mseqExportFileItem);
/* 145 */     menu.addSeparator();
/* 146 */     menu.add((JMenuItem)this.tseqExportFileItem);
/* 147 */     menu.addSeparator();
/* 148 */     menu.add((JMenuItem)this.parikhExportFileItem);
/* 149 */     menu.addSeparator();
/*     */     
/* 151 */     menu.add(new JMenuItem(new AbstractAction("do export")
/*     */           {
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/*     */               try {
/* 156 */                 Viewer viewer = ControlPanel.this.rgFrame.getActualViewer();
/* 157 */                 Path path = viewer.vi.getPath();
/* 158 */                 if (ControlPanel.this.parikhExportFileItem.isSelected()) {
/* 159 */                   TextFile.writeToFile(ControlPanel.this.parikhExportFileItem.getFile(), path.toParikhVector(Viewer.pn), true);
/*     */                 }
/* 161 */                 if (ControlPanel.this.tseqExportFileItem.isSelected()) {
/* 162 */                   TextFile.writeToFile(ControlPanel.this.tseqExportFileItem.getFile(), path.toTransitionSequence(Viewer.pn), true);
/*     */                 }
/* 164 */                 if (ControlPanel.this.mseqExportFileItem.isSelected()) {
/* 165 */                   TextFile.writeToFile(ControlPanel.this.mseqExportFileItem.getFile(), path.toMarkingSequence(Viewer.pn), true);
/*     */                 }
/* 167 */               } catch (NullPointerException nullPointerException) {}
/*     */ 
/*     */ 
/*     */               
/* 171 */               menu.setVisible(false);
/*     */             }
/*     */           }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     menu.addSeparator();
/* 179 */     menu.add(new JMenuItem(new AbstractAction("cancel")
/*     */           {
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 183 */               menu.setVisible(false);
/*     */             }
/*     */           }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     menu.addFocusListener(new FocusListener()
/*     */         {
/*     */           public void focusGained(FocusEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void focusLost(FocusEvent e) {
/* 198 */             menu.setVisible(false);
/*     */           }
/*     */         });
/*     */     
/* 202 */     exportOptions.setComponentPopupMenu(menu);
/* 203 */     exportOptions.setAction(new AbstractAction("export options")
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 206 */             Viewer viewer = ControlPanel.this.rgFrame.getActualViewer();
/*     */             
/* 208 */             if (viewer == null) {
/*     */               return;
/*     */             }
/* 211 */             Path path = viewer.vi.getPath();
/* 212 */             if (path == null) {
/*     */               return;
/*     */             }
/*     */             
/* 216 */             ControlPanel.this.mseqExportFileItem.setFile(path.getName() + ".mseq", FileSaver.lastSaveDir);
/*     */             
/* 218 */             ControlPanel.this.tseqExportFileItem.setFile(path.getName() + ".tseq", FileSaver.lastSaveDir);
/*     */             
/* 220 */             ControlPanel.this.parikhExportFileItem.setFile(path.getName() + "_parikh.res", FileSaver.lastSaveDir);
/*     */             
/* 222 */             JButton b = (JButton)e.getSource();
/* 223 */             JPopupMenu m = b.getComponentPopupMenu();
/* 224 */             PointerInfo info = MouseInfo.getPointerInfo();
/* 225 */             Point p = info.getLocation();
/* 226 */             p.setLocation(p.getX() - 10.0D, p.getY() - 10.0D);
/* 227 */             if (m != null) {
/* 228 */               m.setLocation(p);
/* 229 */               m.pack();
/* 230 */               m.setVisible(true);
/* 231 */               m.grabFocus();
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 237 */     p.add(exportOptions, "1,2");
/* 238 */     p.add(getPathPane(), "1,3");
/*     */     
/* 240 */     Dimension d = layout.preferredLayoutSize(p);
/*     */     
/* 242 */     p.setSize(d);
/* 243 */     p.setPreferredSize(d);
/* 244 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JPanel getFilterPanel() {
/* 250 */     JPanel p = new JPanel();
/* 251 */     p.setBorder(BorderFactory.createTitledBorder("filter"));
/* 252 */     double[][] size = { { 3.0D, 150.0D, 3.0D }, { 3.0D, 20.0D, 20.0D, 20.0D, -2.0D, 3.0D } };
/*     */ 
/*     */ 
/*     */     
/* 256 */     TableLayout layout = new TableLayout(size);
/* 257 */     p.setLayout((LayoutManager)layout);
/*     */     
/* 259 */     JButton setFilter = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 268 */             FileSaver fs = new FileSaver();
/* 269 */             File file = fs.showOpenDialog(null, new FileNameExtensionFilter("Filterfile .filter ", new String[] { "filter" }));
/*     */ 
/*     */             
/* 272 */             if (file != null) {
/* 273 */               boolean b = ControlPanel.this.rgFrame.addFilter(file);
/* 274 */               System.out.printf("rgFrame.addFilter() returned %b \n", new Object[] { Boolean.valueOf(b) });
/*     */ 
/*     */               
/* 277 */               if (!b) {
/*     */ 
/*     */                 
/* 280 */                 JOptionPane.showMessageDialog(null, "filter could not be added !");
/*     */               } else {
/*     */                 
/* 283 */                 ControlPanel.filterList.setSelectedIndex(ControlPanel.filterList.getModel()
/* 284 */                     .getSize() - 1);
/*     */               } 
/*     */             } 
/*     */           }
/*     */         });
/* 289 */     p.add(setFilter, "1,1");
/* 290 */     JButton setFilterColor = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 299 */             Options.filterColor = JColorChooser.showDialog(ControlPanel.this
/* 300 */                 .owner, "filter color", Color.GREEN);
/*     */             
/* 302 */             ControlPanel.this.rgFrame.getActualViewer().actualise();
/*     */           }
/*     */         });
/*     */     
/* 306 */     p.add(setFilterColor, "1,2");
/* 307 */     JButton removeFilter = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 315 */             (ControlPanel.this.rgFrame.getActualViewer()).vi.removeFilter(ControlPanel.filterList
/* 316 */                 .getSelectedIndex());
/* 317 */             ControlPanel.this.rgFrame.getActualViewer().actualise();
/*     */           }
/*     */         });
/*     */     
/* 321 */     p.add(removeFilter, "1,3");
/* 322 */     p.add(getFilterPane(), "1,4");
/*     */     
/* 324 */     Dimension d = layout.preferredLayoutSize(p);
/*     */     
/* 326 */     p.setSize(d);
/* 327 */     p.setPreferredSize(d);
/* 328 */     return p;
/*     */   }
/*     */ 
/*     */   
/*     */   private JPanel getVisualizationPanel() {
/* 333 */     JPanel p = new JPanel();
/* 334 */     p.setBorder(BorderFactory.createTitledBorder("visualisation"));
/* 335 */     double[][] size = { { 3.0D, 75.0D, 75.0D, 3.0D }, { 3.0D, 20.0D, -2.0D, 3.0D } };
/*     */     
/* 337 */     TableLayout layout = new TableLayout(size);
/* 338 */     p.setLayout((LayoutManager)layout);
/*     */     
/* 340 */     JCheckBox nodeLabels = new JCheckBox(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 347 */             JCheckBox c = (JCheckBox)e.getSource();
/* 348 */             Options.vertexLabels = c.isSelected();
/* 349 */             ControlPanel.this.director.sendMessage(7, null, null);
/*     */           }
/*     */         });
/* 352 */     p.add(nodeLabels, "1,1");
/*     */     
/* 354 */     JCheckBox edgeLabels = new JCheckBox(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 361 */             JCheckBox c = (JCheckBox)e.getSource();
/* 362 */             Options.edgeLabels = c.isSelected();
/* 363 */             ControlPanel.this.director.sendMessage(7, null, null);
/*     */           }
/*     */         });
/* 366 */     p.add(edgeLabels, "2,1");
/*     */     
/* 368 */     double pf = -2.0D;
/* 369 */     double[][] size2 = { { pf, pf, pf, pf }, { pf } };
/* 370 */     TableLayout buttonLayout = new TableLayout(size2);
/* 371 */     JPanel pp = new JPanel((LayoutManager)buttonLayout);
/*     */ 
/*     */ 
/*     */     
/* 375 */     MyButton plus = new MyButton(ResourceLoader.getURL("resources/plus_small.png"), ResourceLoader.getURL("resources/plus_ro_small.png"), "zoom in")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e) {
/* 378 */           ControlPanel.this.director.sendMessage(6, null, ControlPanel.this.zoomInFactor);
/*     */         }
/*     */       };
/*     */     
/* 382 */     pp.add((Component)plus, "0,0");
/*     */ 
/*     */     
/* 385 */     MyButton minus = new MyButton(ResourceLoader.getURL("resources/minus_small.png"), ResourceLoader.getURL("resources/minus_ro_small.png"), "zoom out")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e) {
/* 388 */           ControlPanel.this.director.sendMessage(6, null, ControlPanel.this.zoomOutFactor);
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 393 */     pp.add((Component)minus, "1,0");
/*     */ 
/*     */     
/* 396 */     MyButton back = new MyButton(ResourceLoader.getURL("resources/up_small.png"), ResourceLoader.getURL("resources/up_ro_small.png"), "back up in history")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e)
/*     */         {
/* 400 */           ControlPanel.this.director.sendMessage(9, null, null);
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 405 */     pp.add((Component)back, "2,0");
/*     */ 
/*     */ 
/*     */     
/* 409 */     MyButton forward = new MyButton(ResourceLoader.getURL("resources/down_small.png"), ResourceLoader.getURL("resources/down_ro_small.png"), "forward: go down in history")
/*     */       {
/*     */         public void mouseClicked(MouseEvent e)
/*     */         {
/* 413 */           ControlPanel.this.director.sendMessage(10, null, ControlPanel.this.zoomOutFactor);
/*     */         }
/*     */       };
/* 416 */     pp.add((Component)forward, "3,0");
/* 417 */     pp.setPreferredSize(buttonLayout.preferredLayoutSize(pp));
/* 418 */     pp.setSize(buttonLayout.preferredLayoutSize(pp));
/* 419 */     p.add(pp, "1,2,2,2");
/* 420 */     Dimension d = layout.preferredLayoutSize(p);
/*     */     
/* 422 */     p.setSize(d);
/* 423 */     p.setPreferredSize(d);
/*     */ 
/*     */     
/* 426 */     edgeLabels.setSelected(Options.edgeLabels);
/* 427 */     nodeLabels.setSelected(Options.vertexLabels);
/* 428 */     return p;
/*     */   }
/*     */ 
/*     */   
/*     */   private JScrollPane getFilterPane() {
/* 433 */     filterList = new JList();
/*     */     
/* 435 */     filterList.setName("filterList");
/* 436 */     JScrollPane filterPane = new JScrollPane(filterList);
/* 437 */     Dimension d = new Dimension(150, 120);
/* 438 */     filterPane.setPreferredSize(d);
/* 439 */     filterPane.setMinimumSize(d);
/* 440 */     filterPane.setMaximumSize(d);
/* 441 */     return filterPane;
/*     */   }
/*     */   
/*     */   private JScrollPane getPathPane() {
/* 445 */     pathList = new JList(this.dummyList);
/*     */     
/* 447 */     pathList.setName("pathList");
/* 448 */     JScrollPane pathPane = new JScrollPane(pathList);
/* 449 */     Dimension d = new Dimension(150, 120);
/* 450 */     pathPane.setPreferredSize(d);
/* 451 */     pathPane.setMinimumSize(d);
/* 452 */     pathPane.setMaximumSize(d);
/* 453 */     return pathPane;
/*     */   }
/*     */ 
/*     */   
/*     */   private JPanel getVisOptionPanel() {
/* 458 */     JPanel p = new JPanel();
/* 459 */     p.setBorder(BorderFactory.createTitledBorder("visual options"));
/* 460 */     double pref = -2.0D;
/* 461 */     double[][] size = { { 3.0D, 75.0D, 75.0D, 3.0D }, { 3.0D, 20.0D, 20.0D, 20.0D, 20.0D, pref, pref, 20.0D, 3.0D } };
/*     */ 
/*     */ 
/*     */     
/* 465 */     TableLayout layout = new TableLayout(size);
/* 466 */     p.setLayout((LayoutManager)layout);
/*     */     
/* 468 */     final JComboBox<String> layouts = new JComboBox<>(Options.layouts);
/* 469 */     layouts.setSelectedIndex(Options.layoutO.intValue());
/* 470 */     layouts.addItemListener(new ItemListener() {
/*     */           public void itemStateChanged(ItemEvent e) {
/* 472 */             DebugCounter.inc("ControlPanel.VisOptions.LayoutCombo!");
/* 473 */             Options.layoutO.setValue(((JComboBox)e
/* 474 */                 .getSource()).getSelectedIndex());
/*     */             
/* 476 */             Options.layout = ((JComboBox)e.getSource()).getSelectedIndex();
/*     */           }
/*     */         });
/* 479 */     layouts.addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(1));
/* 480 */     p.add(layouts, "1,1,2,1");
/*     */     
/* 482 */     JCheckBox logicStates = new JCheckBox(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 491 */             Options.logicNodes = ((JCheckBox)e.getSource()).isSelected();
/*     */           }
/*     */         });
/* 494 */     logicStates.setSelected(Options.logicNodes);
/*     */     
/* 496 */     p.add(logicStates, "1,2");
/*     */     
/* 498 */     JCheckBox verticalCheck = new JCheckBox(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 506 */             Options.vertical = ((JCheckBox)e.getSource()).isSelected();
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 511 */     p.add(verticalCheck, "2,2");
/* 512 */     p.add(new JLabel("max nodes"), "1,3");
/* 513 */     JSpinner spinMaxNodes = new JSpinner(new SpinnerNumberModel(500, 0, 200000, 1));
/*     */     
/* 515 */     spinMaxNodes.setEditor(new JSpinner.NumberEditor(spinMaxNodes));
/* 516 */     spinMaxNodes.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent evt) {
/* 519 */             JSpinner s = (JSpinner)evt.getSource();
/* 520 */             Integer i = (Integer)s.getValue();
/* 521 */             Options.maxNodesO.setValue(i);
/*     */           }
/*     */         });
/*     */     
/* 525 */     spinMaxNodes.addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(10));
/* 526 */     p.add(spinMaxNodes, "2,3");
/* 527 */     p.add(new JLabel("layers"), "1,4");
/* 528 */     JSpinner spinLayers = new JSpinner(new SpinnerNumberModel(0, 0, 200000, 1));
/*     */     
/* 530 */     spinLayers.setEditor(new JSpinner.NumberEditor(spinLayers));
/* 531 */     spinLayers.addChangeListener(new ChangeListener()
/*     */         {
/*     */           public void stateChanged(ChangeEvent evt) {
/* 534 */             JSpinner s = (JSpinner)evt.getSource();
/* 535 */             Integer i = (Integer)s.getValue();
/* 536 */             Options.maxLayerO.setValue(i);
/*     */           }
/*     */         });
/*     */     
/* 540 */     spinLayers.addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(10));
/* 541 */     p.add(spinLayers, "2,4");
/* 542 */     p.add(new JLabel("X distance"), "1,5");
/*     */     
/* 544 */     final JSlider xDistance = new JSlider(50, 550, Options.hdO.intValue());
/* 545 */     xDistance.setLabelTable(xDistance.createStandardLabels(250, 50));
/* 546 */     xDistance.setPaintLabels(true);
/* 547 */     xDistance
/* 548 */       .setToolTipText("value: " + Options.hdO.toString());
/* 549 */     xDistance.addChangeListener(new ChangeListener() {
/*     */           public void stateChanged(ChangeEvent e) {
/* 551 */             Integer i = new Integer(xDistance.getValue());
/* 552 */             xDistance.setToolTipText("value: " + i.toString());
/* 553 */             Options.hdO.setValue(xDistance.getValue());
/*     */           }
/*     */         });
/* 556 */     xDistance.addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(10));
/* 557 */     p.add(xDistance, "2,5");
/* 558 */     p.add(new JLabel("Y distance"), "1,6");
/*     */     
/* 560 */     final JSlider yDistance = new JSlider(50, 550, Options.vdO.intValue());
/* 561 */     yDistance.setLabelTable(yDistance.createStandardLabels(250, 50));
/* 562 */     yDistance.setPaintLabels(true);
/* 563 */     yDistance
/* 564 */       .setToolTipText("value: " + Options.vdO.toString());
/* 565 */     yDistance.addChangeListener(new ChangeListener() {
/*     */           public void stateChanged(ChangeEvent e) {
/* 567 */             Integer i = new Integer(yDistance.getValue());
/* 568 */             yDistance.setToolTipText("value: " + i.toString());
/* 569 */             Options.vdO.setValue(yDistance.getValue());
/*     */           }
/*     */         });
/* 572 */     yDistance.addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(10));
/* 573 */     p.add(yDistance, "2,6");
/*     */     
/* 575 */     JButton addViewer = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 583 */             Integer layoutIndex = new Integer(layouts.getSelectedIndex());
/*     */             
/* 585 */             DebugCounter.inc("JButton addViewer: add view with layoutIndex :" + Options.layoutO
/* 586 */                 .getValue());
/* 587 */             ControlPanel.this.director.sendMessage(22, null, layoutIndex);
/*     */           }
/*     */         });
/* 590 */     p.add(addViewer, "1,7,2,7");
/* 591 */     return p;
/*     */   }
/*     */   
/*     */   public static double getPanelWidth() {
/* 595 */     return 166.0D;
/*     */   }
/*     */   
/*     */   public void switchToViewer(Viewer newViewer) {
/* 599 */     DefaultListModel filterModel = newViewer.vi.getFilter();
/* 600 */     DefaultListModel pathModel = newViewer.vi.getPaths();
/* 601 */     filterList.setModel(filterModel);
/* 602 */     pathList.setModel(pathModel);
/*     */ 
/*     */     
/* 605 */     ListSelectionListener[] listeners = filterList.getListSelectionListeners();
/* 606 */     for (ListSelectionListener l : listeners) {
/* 607 */       filterList.removeListSelectionListener(l);
/*     */     }
/* 609 */     filterList
/* 610 */       .addListSelectionListener((ListSelectionListener)filterModel);
/*     */     
/* 612 */     listeners = pathList.getListSelectionListeners();
/* 613 */     for (ListSelectionListener l : listeners) {
/* 614 */       pathList.removeListSelectionListener(l);
/*     */     }
/*     */     
/* 617 */     pathList.addListSelectionListener((ListSelectionListener)pathModel);
/*     */     
/* 619 */     filterList.revalidate();
/* 620 */     pathList.revalidate();
/* 621 */     enableControls(true);
/*     */   }
/*     */   
/*     */   public void enableControls(boolean b) {
/* 625 */     Component[] components = getComponents();
/* 626 */     for (Component k : components) {
/* 627 */       enableSubComponents(k, b);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableSubComponents(Component c, boolean b) {
/* 636 */     if (c instanceof Container) {
/* 637 */       Component[] components = ((Container)c).getComponents();
/* 638 */       for (Component k : components) {
/* 639 */         enableSubComponents(k, b);
/*     */       }
/*     */     } 
/* 642 */     c.setEnabled(b);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/ControlPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */