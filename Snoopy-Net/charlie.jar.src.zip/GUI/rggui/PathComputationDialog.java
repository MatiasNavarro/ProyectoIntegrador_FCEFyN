/*     */ package GUI.rggui;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.io.FileSaver;
/*     */ import GUI.util.ExportJCheckBoxMenuItem;
/*     */ import GUI.util.FileDisplayDialog;
/*     */ import GUI.util.MyMouseWheelListener;
/*     */ import GUI.util.ResourceLoader;
/*     */ import charlie.analyzer.path.PathComputationOptions;
/*     */ import charlie.filter.BinFilter;
/*     */ import charlie.filter.Filter;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.State;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGNode;
/*     */ import charlie.rg.RGraph;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.MouseInfo;
/*     */ import java.awt.Point;
/*     */ import java.awt.PointerInfo;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ public class PathComputationDialog extends JPanel {
/*     */   private static final long serialVersionUID = 7951084626357309223L;
/*  56 */   private final String iconPath = "resources/general.jpg";
/*     */   
/*  58 */   private IRGDirector director = null;
/*  59 */   private JComboBox jComboCompute = null;
/*  60 */   private JComboBox jComboRGraph = null;
/*  61 */   private JComboBox jComboSource = null;
/*  62 */   private JComboBox jComboTarget = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private JSpinner maxNumberConsideredStates = null;
/*  68 */   private JSpinner maxPathLength = null;
/*     */   
/*  70 */   private JCheckBox jCheckConsiderRG = null;
/*  71 */   private JCheckBox jCheckUseRGraph = null;
/*  72 */   private JRadioButton jRadioSubMarking = null;
/*  73 */   private JRadioButton jRadioFullMarking = null;
/*     */   
/*  75 */   private JTextField jTextStartId = null;
/*  76 */   private JTextField jTextTargetId = null;
/*     */   
/*  78 */   private JButton jButtonSourceFile = null;
/*  79 */   private JButton jButtonTargetFile = null;
/*  80 */   private File sourceFilterFile = null;
/*  81 */   private File targetFilterFile = null;
/*     */   
/*  83 */   private JButton showWindow = null;
/*  84 */   private JPanel targetIdPanel = null;
/*  85 */   private JPanel targetFilePanel = null;
/*  86 */   private JPanel sourceIdPanel = null;
/*  87 */   private JPanel sourceFilePanel = null;
/*     */ 
/*     */   
/*  90 */   private String helpString = "<html>the source state<ul><li><b>if \"starting in m0\" is selected<b>: m0 ist the source state</li><li>if a filter is specified and the reachable states are considered:<br>the first satisfying state is the source state</li><li>if a filter is specified and the reachable states are <b>not</b> considered:<br>the filter must specify a unique state* which is the source state</li></ul><br>the target state(s)<ul><li>if full state is selected, the filter specifies a unqiue state* which is the target.<br></li><li>if substate is selceted, the filter specifies a set of states which is the target set. <br>all places, which doe not appear in the filter do not care<br>the filter is allowed to contain any boolean operator and any comparison concering tokens on places</li></ul>* all places, which doe not appear in the filter are  set implicitly to 0<br>the filter is allowed to contain '*' and '=' only <br><br>the computation is performing a BFS <ul><li>reaching maximal states causes a break</li><li>reaching the maximal length (depth) causes a break</li></ul></html>";
/*     */   
/*  92 */   private JButton jButtonCompute = null;
/*  93 */   private JPanel thisPanel = null;
/*  94 */   private int[] depSourcePos = new int[4];
/*  95 */   private int[] depTargetPos = new int[4];
/*     */   
/*  97 */   private JButton exportOptionsButton = null;
/*  98 */   private ExportJCheckBoxMenuItem mseqExportFileItem = null;
/*  99 */   private ExportJCheckBoxMenuItem tseqExportFileItem = null;
/* 100 */   private ExportJCheckBoxMenuItem parikhExportFileItem = null;
/*     */ 
/*     */   
/* 103 */   private PlaceTransitionNet pn = null;
/*     */   
/*     */   public void setPN(PlaceTransitionNet pn) {
/* 106 */     this.pn = pn;
/* 107 */     this.mseqExportFileItem.setFile(pn.getName() + ".mseq", FileSaver.lastSaveDir);
/* 108 */     this.tseqExportFileItem.setFile(pn.getName() + ".tseq", FileSaver.lastSaveDir);
/* 109 */     this.parikhExportFileItem.setFile(pn.getName() + "_parikh.res", FileSaver.lastSaveDir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PathComputationDialog(IRGDirector director) {
/* 117 */     this.director = director;
/* 118 */     this.thisPanel = this;
/* 119 */     initialize();
/* 120 */     enableControls(false);
/*     */   }
/*     */   
/*     */   public void initialize() {
/* 124 */     double h = 25.0D;
/* 125 */     double vGap = 3.0D;
/* 126 */     double[][] size = { { 5.0D, 113.0D, 1.0D, 180.0D, 4.0D, 10.0D }, { 2.0D, 2.0D } };
/* 127 */     int line = 0;
/* 128 */     TableLayout layout = new TableLayout(size);
/*     */     
/* 130 */     setLayout((LayoutManager)layout);
/* 131 */     layout.insertRow(++line, h);
/* 132 */     add(new JLabel("compute"), "1," + line);
/* 133 */     String[] s = { "shortest path", "longest path" };
/* 134 */     this.jComboCompute = new JComboBox<>(s);
/* 135 */     add(this.jComboCompute, "3," + line);
/*     */     
/* 137 */     layout.insertRow(++line, h);
/* 138 */     add(new JLabel("max states"), "1," + line);
/* 139 */     add(getSpinnerMaxStates(), "3," + line);
/*     */     
/* 141 */     layout.insertRow(++line, h);
/* 142 */     add(new JLabel("max path length"), "1," + line);
/* 143 */     add(getSpinnerPathLength(), "3," + line);
/*     */ 
/*     */     
/* 146 */     layout.insertRow(++line, h);
/* 147 */     add(getRGraphPanel(), "1," + line + ",3," + line);
/* 148 */     addItemListener(this.jComboRGraph);
/*     */     
/* 150 */     layout.insertRow(++line, vGap);
/* 151 */     layout.insertRow(++line, 1.0D);
/* 152 */     addBorderPanel("1," + line + ",3," + line);
/* 153 */     layout.insertRow(++line, vGap);
/*     */     
/* 155 */     layout.insertRow(++line, h);
/* 156 */     JLabel pathLabel = new JLabel("source for path");
/* 157 */     pathLabel.setToolTipText("source for path");
/* 158 */     add(pathLabel, "1," + line);
/* 159 */     String[] s2 = { "use initial net marking", "choose filter file", "use state id from rg" };
/* 160 */     this.jComboSource = new JComboBox<>(s2);
/* 161 */     addItemListener(this.jComboSource);
/* 162 */     add(this.jComboSource, "3," + line);
/*     */ 
/*     */     
/* 165 */     this.sourceIdPanel = getSourceIdPanel();
/* 166 */     enableSubComponents(this.sourceIdPanel, false);
/* 167 */     this.sourceFilePanel = getSourceFilePanel();
/*     */     
/* 169 */     layout.insertRow(++line, h);
/* 170 */     this.depSourcePos[0] = 3; this.depSourcePos[1] = line; this.depSourcePos[2] = 3; this.depSourcePos[3] = line;
/*     */ 
/*     */     
/* 173 */     layout.insertRow(++line, h);
/* 174 */     this.jCheckConsiderRG = new JCheckBox("consider RG");
/* 175 */     this.jCheckConsiderRG.setToolTipText("<html><p>If a filter is specified and the reachable states are considered, the first satisfying state is the source state.</p><p>(Works currently only with non-timed graphs)</p></html>");
/* 176 */     add(this.jCheckConsiderRG, "3," + line);
/* 177 */     layout.insertRow(++line, vGap);
/* 178 */     layout.insertRow(++line, 1.0D);
/* 179 */     addBorderPanel("1," + line + ",3," + line);
/* 180 */     layout.insertRow(++line, vGap);
/*     */     
/* 182 */     layout.insertRow(++line, h);
/* 183 */     JLabel targetLabel = new JLabel("target for path");
/* 184 */     targetLabel.setToolTipText("target for path");
/* 185 */     add(targetLabel, "1," + line);
/* 186 */     String[] s3 = { "choose filter file", "use state id from rg" };
/* 187 */     this.jComboTarget = new JComboBox<>(s3);
/* 188 */     addItemListener(this.jComboTarget);
/* 189 */     add(this.jComboTarget, "3," + line);
/*     */     
/* 191 */     this.targetIdPanel = getTargetIdPanel();
/* 192 */     enableSubComponents(this.targetIdPanel, false);
/* 193 */     this.targetFilePanel = getTargetFilePanel();
/*     */ 
/*     */ 
/*     */     
/* 197 */     layout.insertRow(++line, h);
/* 198 */     this.depTargetPos[0] = 3; this.depTargetPos[1] = line; this.depTargetPos[2] = 3; this.depTargetPos[3] = line;
/*     */     
/* 200 */     add(this.targetFilePanel, getPosString(this.depTargetPos));
/* 201 */     layout.insertRow(++line, h);
/* 202 */     add(new JLabel("target type"), "1," + line);
/* 203 */     add(getMarkingTypePanel(), "3," + line);
/* 204 */     layout.insertRow(++line, vGap);
/* 205 */     layout.insertRow(++line, 1.0D);
/* 206 */     addBorderPanel("1," + line + ",3," + line);
/* 207 */     layout.insertRow(++line, vGap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     JButton jButtonHelp = new JButton(new AbstractAction() {
/*     */           public void actionPerformed(ActionEvent e) {
/* 217 */             PathComputationDialog.this.showHelp(); }
/*     */         });
/* 219 */     layout.insertRow(++line, h);
/* 220 */     add(getJButtonShow(), "3," + line);
/* 221 */     add(jButtonHelp, "1," + line);
/* 222 */     this.jButtonCompute = new JButton(new AbstractAction()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 225 */             if (!PathComputationDialog.this.onCompute()) {
/* 226 */               JOptionPane.showMessageDialog(PathComputationDialog.this.thisPanel, "Computation could not be started check parameters and loaded files");
/*     */             }
/*     */           }
/*     */         });
/*     */     
/* 231 */     getJButtonExportOptions();
/* 232 */     layout.insertRow(++line, h);
/* 233 */     add(this.exportOptionsButton, "1," + line + ",3," + line);
/*     */     
/* 235 */     layout.insertRow(++line, h);
/* 236 */     add(this.jButtonCompute, "1," + line + ",3," + line);
/*     */ 
/*     */     
/* 239 */     Dimension d = layout.preferredLayoutSize(this);
/*     */ 
/*     */ 
/*     */     
/* 243 */     setSize(d);
/* 244 */     setPreferredSize(d);
/*     */   }
/*     */ 
/*     */   
/*     */   private JButton getJButtonExportOptions() {
/* 249 */     JButton exportOptions = new JButton("export");
/* 250 */     final JPopupMenu menu = new JPopupMenu();
/* 251 */     menu.add(new JMenuItem("export options"));
/* 252 */     menu.addSeparator();
/*     */ 
/*     */ 
/*     */     
/* 256 */     this.mseqExportFileItem = new ExportJCheckBoxMenuItem("export marking sequence", "path.mseq", "export marking sequence to file:", FileSaver.lastSaveDir);
/* 257 */     menu.add((JMenuItem)this.mseqExportFileItem);
/* 258 */     menu.addSeparator();
/* 259 */     this.tseqExportFileItem = new ExportJCheckBoxMenuItem("export transition sequence", "path.tseq", "export transition sequence to file:", FileSaver.lastSaveDir);
/* 260 */     menu.add((JMenuItem)this.tseqExportFileItem);
/* 261 */     menu.addSeparator();
/* 262 */     this.parikhExportFileItem = new ExportJCheckBoxMenuItem("export parikh vector", "path_parikh.res", "export parikh vector to file:", FileSaver.lastSaveDir);
/* 263 */     menu.add((JMenuItem)this.parikhExportFileItem);
/* 264 */     menu.addSeparator();
/*     */     
/* 266 */     menu.add(new JMenuItem(new AbstractAction("close")
/*     */           {
/*     */             public void actionPerformed(ActionEvent e) {
/* 269 */               menu.setVisible(false);
/*     */             }
/*     */           }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     menu.addFocusListener(new FocusListener()
/*     */         {
/*     */           public void focusGained(FocusEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void focusLost(FocusEvent e) {
/* 285 */             menu.setVisible(false);
/*     */           }
/*     */         });
/*     */     
/* 289 */     exportOptions.setComponentPopupMenu(menu);
/* 290 */     exportOptions.setAction(new AbstractAction("export options")
/*     */         {
/*     */           public void actionPerformed(ActionEvent e) {
/* 293 */             JButton b = (JButton)e.getSource();
/* 294 */             JPopupMenu m = b.getComponentPopupMenu();
/* 295 */             PointerInfo info = MouseInfo.getPointerInfo();
/* 296 */             Point p = info.getLocation();
/* 297 */             p.setLocation(p.getX() - 10.0D, p.getY() - 10.0D);
/* 298 */             if (m != null) {
/* 299 */               m.setLocation(p);
/* 300 */               m.pack();
/* 301 */               m.setVisible(true);
/* 302 */               m.grabFocus();
/*     */             } 
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 310 */     this.exportOptionsButton = exportOptions;
/* 311 */     return exportOptions;
/*     */   }
/*     */ 
/*     */   
/*     */   private JPanel getRGraphPanel() {
/* 316 */     JPanel p = new JPanel();
/* 317 */     double[][] size = { { 100.0D, 1.0D, 180.0D }, { 25.0D } };
/* 318 */     TableLayout layout = new TableLayout(size);
/* 319 */     p.setLayout((LayoutManager)layout);
/* 320 */     this.jCheckUseRGraph = new JCheckBox("use rg");
/* 321 */     p.add(this.jCheckUseRGraph, "0,0");
/* 322 */     this.jComboRGraph = new JComboBox(new DefaultComboBoxModel());
/* 323 */     addItemListener(this.jComboRGraph);
/* 324 */     p.add(this.jComboRGraph, "2,0");
/* 325 */     return p;
/*     */   }
/*     */   
/*     */   private JPanel getSourceFilePanel() {
/* 329 */     JPanel p = new JPanel();
/* 330 */     double[][] size = { { 140.0D, 40.0D }, { 25.0D } };
/* 331 */     TableLayout layout = new TableLayout(size);
/* 332 */     p.setLayout((LayoutManager)layout);
/*     */     
/* 334 */     this.jButtonSourceFile = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 341 */             FileSaver fs = new FileSaver();
/* 342 */             File f = fs.showOpenDialog(PathComputationDialog.this.sourceFilterFile, new FileNameExtensionFilter("Filter file .filter", new String[] { "filter" }));
/* 343 */             if (f != null) {
/* 344 */               PathComputationDialog.this.sourceFilterFile = f;
/* 345 */               PathComputationDialog.this.jButtonSourceFile.setToolTipText("<html><p>Path:" + PathComputationDialog.this.sourceFilterFile.getParent() + "</p><p>" + PathComputationDialog.this.sourceFilterFile.getName() + "</p></html>");
/* 346 */               PathComputationDialog.MyFile mf = new PathComputationDialog.MyFile(f);
/* 347 */               PathComputationDialog.this.jComboSource.addItem(mf);
/* 348 */               PathComputationDialog.this.jComboSource.setSelectedItem(mf);
/*     */             } 
/*     */           }
/*     */         });
/* 352 */     p.add(this.jButtonSourceFile, "0,0");
/* 353 */     JButton showSourceFile = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 364 */             if (PathComputationDialog.this.sourceFilterFile != null) {
/* 365 */               FileDisplayDialog.getDialog(PathComputationDialog.this.sourceFilterFile);
/*     */             }
/*     */           }
/*     */         });
/* 369 */     p.add(showSourceFile, "1,0");
/* 370 */     return p;
/*     */   }
/*     */   
/*     */   private JPanel getTargetFilePanel() {
/* 374 */     JPanel p = new JPanel();
/* 375 */     double[][] size = { { 140.0D, 40.0D }, { 25.0D } };
/* 376 */     TableLayout layout = new TableLayout(size);
/* 377 */     p.setLayout((LayoutManager)layout);
/*     */     
/* 379 */     this.jButtonTargetFile = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 387 */             FileSaver fs = new FileSaver();
/* 388 */             File f = fs.showOpenDialog(PathComputationDialog.this.targetFilterFile, new FileNameExtensionFilter("Filter file .filter", new String[] { "filter" }));
/*     */             
/* 390 */             if (f != null) {
/* 391 */               PathComputationDialog.this.targetFilterFile = f;
/* 392 */               PathComputationDialog.this.jButtonTargetFile.setToolTipText("<html><p>Path:" + PathComputationDialog.this.targetFilterFile.getParent() + "</p><p>" + PathComputationDialog.this.targetFilterFile.getName() + "</p></html>");
/* 393 */               PathComputationDialog.MyFile mf = new PathComputationDialog.MyFile(f);
/* 394 */               PathComputationDialog.this.jComboTarget.addItem(mf);
/* 395 */               PathComputationDialog.this.jComboTarget.setSelectedItem(mf);
/*     */             } else {
/* 397 */               DebugCounter.inc("f == null");
/*     */             } 
/*     */           }
/*     */         });
/* 401 */     p.add(this.jButtonTargetFile, "0,0");
/* 402 */     JButton showTargetFile = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 413 */             if (PathComputationDialog.this.targetFilterFile != null) {
/* 414 */               FileDisplayDialog fileDisplayDialog = FileDisplayDialog.getDialog(PathComputationDialog.this.targetFilterFile);
/*     */             } else {
/* 416 */               DebugCounter.inc("Load a file before viewing ");
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 421 */     p.add(showTargetFile, "1,0");
/* 422 */     return p;
/*     */   }
/*     */   
/*     */   private JPanel getSourceIdPanel() {
/* 426 */     JPanel p = new JPanel();
/* 427 */     double[][] size = { { 100.0D, 80.0D }, { 25.0D } };
/* 428 */     TableLayout layout = new TableLayout(size);
/* 429 */     p.setLayout((LayoutManager)layout);
/* 430 */     this.jTextStartId = new JTextField(15);
/* 431 */     this.jTextStartId.setToolTipText("type in a state id which exists in the selected reachability graph,this state is used as start state");
/* 432 */     p.add(this.jTextStartId, "0,0");
/* 433 */     JButton checkStartId = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 440 */             int i = -1;
/*     */             try {
/* 442 */               i = Integer.parseInt(PathComputationDialog.this.jTextStartId.getText());
/* 443 */             } catch (NumberFormatException ne) {
/* 444 */               JOptionPane.showMessageDialog(PathComputationDialog.this.thisPanel, "Check the value of the input field for start id");
/*     */               return;
/*     */             } 
/* 447 */             if (PathComputationDialog.this.checkRGForId(i)) {
/* 448 */               PathComputationDialog.MyId id = new PathComputationDialog.MyId(i);
/* 449 */               PathComputationDialog.this.jComboSource.addItem(id);
/* 450 */               PathComputationDialog.this.jComboSource.setSelectedItem(id);
/*     */             } else {
/* 452 */               JOptionPane.showMessageDialog(PathComputationDialog.this.thisPanel, "The selected id could not be found in the selected reachability graph!");
/*     */             } 
/*     */           }
/*     */         });
/* 456 */     p.add(checkStartId, "1,0");
/* 457 */     return p;
/*     */   }
/*     */   
/*     */   private JPanel getTargetIdPanel() {
/* 461 */     JPanel p = new JPanel();
/* 462 */     double[][] size = { { 100.0D, 80.0D }, { 25.0D } };
/* 463 */     TableLayout layout = new TableLayout(size);
/* 464 */     p.setLayout((LayoutManager)layout);
/* 465 */     this.jTextTargetId = new JTextField(15);
/* 466 */     this.jTextTargetId.setToolTipText("type in a state id which exists in the selected reachability graph,this state is used as target state");
/* 467 */     p.add(this.jTextTargetId, "0,0");
/* 468 */     JButton checkTargetId = new JButton(new AbstractAction()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 473 */             int i = -1;
/*     */             try {
/* 475 */               i = Integer.parseInt(PathComputationDialog.this.jTextTargetId.getText());
/* 476 */             } catch (NumberFormatException ne) {
/* 477 */               JOptionPane.showMessageDialog(PathComputationDialog.this.thisPanel, "Check the value of the input field for start id");
/*     */               return;
/*     */             } 
/* 480 */             if (PathComputationDialog.this.checkRGForId(i)) {
/* 481 */               PathComputationDialog.MyId id = new PathComputationDialog.MyId(i);
/* 482 */               PathComputationDialog.this.jComboTarget.addItem(id);
/* 483 */               PathComputationDialog.this.jComboTarget.setSelectedItem(id);
/*     */             } else {
/* 485 */               JOptionPane.showMessageDialog(PathComputationDialog.this.thisPanel, "The selected id could not be found in the selected reachability graph!");
/*     */             } 
/*     */           }
/*     */         });
/* 489 */     p.add(checkTargetId, "1,0");
/* 490 */     return p;
/*     */   }
/*     */   
/*     */   private boolean checkRGForId(int id) {
/* 494 */     RGraph rg = (RGraph)this.jComboRGraph.getSelectedItem();
/* 495 */     if (rg != null) {
/* 496 */       RGNode n = rg.getNodeByNumber(id);
/* 497 */       if (n == null) {
/* 498 */         JOptionPane.showMessageDialog(this.thisPanel, "The reachability graph does not contain a state with id: " + id);
/* 499 */         return false;
/*     */       } 
/* 501 */       JOptionPane.showMessageDialog(this.thisPanel, "The reachability graph contains a state with id: " + id);
/* 502 */       return true;
/*     */     } 
/*     */     
/* 505 */     JOptionPane.showMessageDialog(this.thisPanel, "Please construct and select a reachability graph before usingthis option!");
/* 506 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void showHelp() {
/* 511 */     JOptionPane.showMessageDialog(this, this.helpString, "advise", 1);
/*     */   }
/*     */   private boolean onCompute() {
/*     */     Object o;
/* 515 */     RGraph rg = (RGraph)this.jComboRGraph.getSelectedItem();
/*     */     
/* 517 */     if (rg == null) {
/* 518 */       rg = new RGraph(this.pn);
/*     */     }
/*     */     
/* 521 */     PathComputationOptions po = new PathComputationOptions();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 526 */     if (this.parikhExportFileItem.isSelected()) {
/* 527 */       po.exportFileParikhVector = this.parikhExportFileItem.getFile();
/*     */     }
/* 529 */     if (this.tseqExportFileItem.isSelected()) {
/* 530 */       po.exportFileTransitionSequence = this.tseqExportFileItem.getFile();
/*     */     }
/* 532 */     if (this.mseqExportFileItem.isSelected()) {
/* 533 */       po.exportFileMarkingSequence = this.mseqExportFileItem.getFile();
/*     */     }
/*     */     
/* 536 */     po.setObjectToAnalyze(rg);
/* 537 */     po.rGraph = rg;
/* 538 */     Path p = new Path();
/* 539 */     p.setName("empty path");
/* 540 */     if (this.jComboCompute.getSelectedIndex() == 0) {
/* 541 */       po.computationType = 0;
/*     */     } else {
/* 543 */       po.computationType = 1;
/*     */     } 
/* 545 */     po.setResultObject(p);
/* 546 */     po.maximalConsideredStates = ((Integer)this.maxNumberConsideredStates.getValue()).intValue();
/* 547 */     po.maxPathLength = ((Integer)this.maxPathLength.getValue()).intValue();
/* 548 */     if (this.jRadioSubMarking.isSelected()) {
/* 549 */       po.markingType = 0;
/* 550 */     } else if (this.jRadioFullMarking.isSelected()) {
/* 551 */       po.markingType = 1;
/*     */     } 
/*     */     
/* 554 */     switch (this.jComboSource.getSelectedIndex()) {
/*     */       case 0:
/* 556 */         po.useM0 = true;
/* 557 */         if (rg != null) {
/* 558 */           if (!rg.isTimedGraph()) {
/* 559 */             po.startState = (State)rg.getNet().getNonTimedM0State();
/* 560 */             System.out.printf("startState: %s \n", new Object[] { po.startState }); break;
/*     */           } 
/* 562 */           System.out.printf("rg options: %d , %d , %d\n", new Object[] { Byte.valueOf(rg.clockHandling), Byte.valueOf(rg.timedNetType), Byte.valueOf(rg.timeDesignation) });
/* 563 */           po.startState = rg.getNet().getTimedM0State(rg.clockHandling, rg.timedNetType, rg.timeDesignation);
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 570 */         JOptionPane.showMessageDialog(this.thisPanel, "Please choose a filter file or select a state id for start of path!");
/*     */         break;
/*     */       
/*     */       case 2:
/* 574 */         JOptionPane.showMessageDialog(this.thisPanel, "Please choose a filter file or select a state id for start of path!");
/*     */         break;
/*     */       
/*     */       default:
/* 578 */         o = this.jComboSource.getSelectedItem();
/* 579 */         if (o instanceof MyId) {
/* 580 */           RGNode n = po.rGraph.getNodeByNumber(((MyId)o).id);
/*     */           
/* 582 */           if (n == null) {
/* 583 */             JOptionPane.showMessageDialog(this.thisPanel, "State with id " + ((MyId)o).id + "cannot be found in rg!");
/* 584 */             return false;
/*     */           } 
/* 586 */           po.startState = n.getMarking(); break;
/* 587 */         }  if (o instanceof MyFile) {
/*     */           try {
/* 589 */             po.startFilter = (Filter)new BinFilter(((MyFile)o).file.getAbsolutePath(), this.pn);
/* 590 */           } catch (Exception e) {
/* 591 */             JOptionPane.showMessageDialog(this.thisPanel, "The selected file does not contain a valid filter!");
/*     */           } 
/* 593 */           if (!this.jCheckConsiderRG.isSelected()) {
/*     */             try {
/* 595 */               po.startFilter.createMarking();
/* 596 */             } catch (Exception e) {
/* 597 */               JOptionPane.showMessageDialog(this.thisPanel, "Could not create marking on selected filter!");
/*     */             }  break;
/*     */           } 
/* 600 */           if (rg.getSatisfyingStates(po.startFilter).isEmpty()) {
/* 601 */             JOptionPane.showMessageDialog(this.thisPanel, "The reachability graph does not contain any states satisfying the specified filter!", "advice", 1);
/*     */           }
/*     */         } 
/*     */         break;
/*     */     } 
/*     */     
/* 607 */     switch (this.jComboTarget.getSelectedIndex()) {
/*     */       case 0:
/* 609 */         JOptionPane.showMessageDialog(this.thisPanel, "Please choose a filter file or select a state id for target of path!");
/*     */         break;
/*     */       case 1:
/* 612 */         JOptionPane.showMessageDialog(this.thisPanel, "Please choose a filter file or select a state id for target of path!");
/*     */         break;
/*     */       
/*     */       default:
/* 616 */         o = this.jComboTarget.getSelectedItem();
/* 617 */         if (o instanceof MyId) {
/* 618 */           RGNode n = po.rGraph.getNodeByNumber(((MyId)o).id);
/* 619 */           if (n == null) {
/* 620 */             JOptionPane.showMessageDialog(this.thisPanel, "State with id " + ((MyId)o).id + "cannot be found in rg!");
/* 621 */             return false;
/*     */           } 
/* 623 */           po.targetState = n.getMarking(); break;
/* 624 */         }  if (o instanceof MyFile) {
/*     */ 
/*     */           
/*     */           try {
/* 628 */             po.targetFilterFile = ((MyFile)o).file;
/* 629 */             po.targetFilter = (Filter)new BinFilter(((MyFile)o).file.getAbsolutePath(), this.pn);
/*     */           }
/* 631 */           catch (Exception e) {
/* 632 */             JOptionPane.showMessageDialog(this.thisPanel, "Could not create filter from filter file, make shure the file contains a valid filter!");
/*     */           }  break;
/*     */         } 
/* 635 */         JOptionPane.showMessageDialog(this.thisPanel, "unknown state of target combobox!" + o.getClass().getName());
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 640 */     if (po.targetState == null && po.targetFilter == null) {
/* 641 */       JOptionPane.showMessageDialog(this.thisPanel, "po.targetState == null && po.targetFilter==null!");
/* 642 */       return false;
/*     */     } 
/* 644 */     if (po.startState == null && po.startFilter == null && !po.useM0) {
/* 645 */       JOptionPane.showMessageDialog(this.thisPanel, "po.startState == null && po.startFilter == null!");
/* 646 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 651 */     return this.director.sendMessage(27, this, po);
/*     */   }
/*     */   
/*     */   public void addRGToPanel(RGraph rg) {
/* 655 */     if (rg != null) {
/* 656 */       DefaultComboBoxModel<RGraph> model = (DefaultComboBoxModel)this.jComboRGraph.getModel();
/* 657 */       if (model.getIndexOf(rg) < 0) {
/* 658 */         model.addElement(rg);
/* 659 */         model.setSelectedItem(rg);
/*     */       } 
/* 661 */       enableControls(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void enableControls(boolean b) {
/* 666 */     this.jComboCompute.setEnabled(b);
/* 667 */     this.jComboSource.setEnabled(b);
/* 668 */     this.jComboTarget.setEnabled(b);
/*     */     
/* 670 */     this.jComboRGraph.setEnabled(b);
/* 671 */     this.maxNumberConsideredStates.setEnabled(b);
/* 672 */     this.maxPathLength.setEnabled(b);
/* 673 */     this.jCheckUseRGraph.setEnabled(b);
/* 674 */     this.jCheckConsiderRG.setEnabled(b);
/* 675 */     this.jRadioSubMarking.setEnabled(b);
/* 676 */     this.jRadioFullMarking.setEnabled(b);
/*     */     
/* 678 */     enableSubComponents(this.targetFilePanel, b);
/* 679 */     enableSubComponents(this.targetIdPanel, b);
/* 680 */     enableSubComponents(this.sourceFilePanel, b);
/* 681 */     enableSubComponents(this.sourceIdPanel, b);
/*     */     
/* 683 */     this.jButtonCompute.setEnabled(b);
/*     */   }
/*     */   
/*     */   public void reset(boolean removeGraphs) {
/* 687 */     if (removeGraphs) {
/* 688 */       this.jComboRGraph.removeAllItems();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JPanel getSpinnerPathLength() {
/* 695 */     JSpinner spin = new JSpinner(new SpinnerNumberModel(0, 0, 200000, 1));
/* 696 */     spin.setEditor(new JSpinner.NumberEditor(spin));
/* 697 */     spin.addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(10));
/* 698 */     this.maxPathLength = spin;
/* 699 */     JPanel p = new JPanel();
/* 700 */     Dimension d = new Dimension(180, 25);
/* 701 */     p.setSize(d);
/* 702 */     p.setPreferredSize(d);
/* 703 */     p.add(spin);
/* 704 */     return p;
/*     */   }
/*     */   
/*     */   private JPanel getSpinnerMaxStates() {
/* 708 */     JSpinner spin = new JSpinner(new SpinnerNumberModel(0, 0, 200000, 1));
/* 709 */     spin.setEditor(new JSpinner.NumberEditor(spin));
/* 710 */     spin.addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(10));
/* 711 */     this.maxNumberConsideredStates = spin;
/* 712 */     JPanel p = new JPanel();
/* 713 */     Dimension d = new Dimension(180, 25);
/* 714 */     p.setSize(d);
/* 715 */     p.setPreferredSize(d);
/* 716 */     p.add(spin);
/* 717 */     return p;
/*     */   }
/*     */   
/*     */   private JPanel getMarkingTypePanel() {
/* 721 */     JPanel p = new JPanel();
/*     */     
/* 723 */     double[][] size = { { 88.0D, 4.0D, 88.0D }, { 25.0D } };
/* 724 */     p.setLayout((LayoutManager)new TableLayout(size));
/* 725 */     this.jRadioSubMarking = new JRadioButton("sub");
/* 726 */     this.jRadioSubMarking.setToolTipText("the target marking shall be a set of states");
/* 727 */     p.add(this.jRadioSubMarking, "0,0");
/* 728 */     this.jRadioFullMarking = new JRadioButton("full");
/* 729 */     this.jRadioFullMarking.setToolTipText("the target marking shall be an single state.");
/* 730 */     p.add(this.jRadioFullMarking, "2,0");
/* 731 */     ButtonGroup bg = new ButtonGroup();
/* 732 */     bg.add(this.jRadioSubMarking);
/* 733 */     bg.add(this.jRadioFullMarking);
/* 734 */     this.jRadioSubMarking.setSelected(true);
/* 735 */     return p;
/*     */   }
/*     */   
/*     */   private void addBorderPanel(String location) {
/* 739 */     JPanel p = new JPanel();
/* 740 */     p.setBorder(BorderFactory.createLineBorder(Color.GRAY.darker()));
/* 741 */     add(p, location);
/*     */   }
/*     */   
/*     */   private void addItemListener(JComboBox comboBox) {
/* 745 */     ItemListener iL = null;
/* 746 */     if (comboBox == this.jComboRGraph) {
/* 747 */       iL = new ItemListener()
/*     */         {
/*     */           
/*     */           public void itemStateChanged(ItemEvent e)
/*     */           {
/* 752 */             RGraph r = (RGraph)((JComboBox)e.getSource()).getSelectedItem();
/* 753 */             if (r != null) {
/* 754 */               PathComputationDialog.this.jCheckConsiderRG.setEnabled(!r.isTimedGraph());
/* 755 */               PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.sourceIdPanel, true);
/* 756 */               PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.targetIdPanel, true);
/*     */             } 
/* 758 */             PathComputationDialog.this.thisPanel.revalidate();
/*     */           }
/*     */         };
/* 761 */     } else if (comboBox == this.jComboSource) {
/* 762 */       iL = new ItemListener()
/*     */         {
/*     */           public void itemStateChanged(ItemEvent e)
/*     */           {
/* 766 */             int index = ((JComboBox)e.getSource()).getSelectedIndex();
/*     */             
/* 768 */             if (index > 2) {
/*     */               
/* 770 */               Object o = PathComputationDialog.this.jComboSource.getSelectedItem();
/* 771 */               if (o instanceof PathComputationDialog.MyFile) {
/* 772 */                 PathComputationDialog.this.sourceFilterFile = ((PathComputationDialog.MyFile)o).file;
/* 773 */                 index = 1;
/* 774 */               } else if (o instanceof PathComputationDialog.MyId) {
/* 775 */                 PathComputationDialog.this.jTextStartId.setText(Integer.toString(((PathComputationDialog.MyId)o).id));
/* 776 */                 index = 2;
/*     */               } 
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 783 */             switch (index) {
/*     */               case 0:
/* 785 */                 PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.sourceFilePanel, false);
/* 786 */                 PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.sourceIdPanel, false);
/* 787 */                 PathComputationDialog.this.thisPanel.remove(PathComputationDialog.this.sourceIdPanel);
/* 788 */                 PathComputationDialog.this.thisPanel.remove(PathComputationDialog.this.sourceFilePanel);
/*     */                 break;
/*     */               case 1:
/* 791 */                 PathComputationDialog.this.thisPanel.remove(PathComputationDialog.this.sourceIdPanel);
/* 792 */                 PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.sourceFilePanel, true);
/* 793 */                 PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.sourceIdPanel, false);
/*     */                 
/* 795 */                 PathComputationDialog.this.thisPanel.add(PathComputationDialog.this.sourceFilePanel, PathComputationDialog.this.getPosString(PathComputationDialog.this.depSourcePos));
/*     */                 break;
/*     */               case 2:
/* 798 */                 PathComputationDialog.this.thisPanel.remove(PathComputationDialog.this.sourceFilePanel);
/* 799 */                 PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.sourceFilePanel, false);
/* 800 */                 PathComputationDialog.this.thisPanel.add(PathComputationDialog.this.sourceIdPanel, PathComputationDialog.this.getPosString(PathComputationDialog.this.depSourcePos));
/* 801 */                 if (PathComputationDialog.this.jComboRGraph.getSelectedItem() != null) {
/* 802 */                   PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.sourceIdPanel, true);
/*     */                 }
/*     */                 break;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 810 */             PathComputationDialog.this.thisPanel.invalidate();
/* 811 */             PathComputationDialog.this.thisPanel.validate();
/*     */           }
/*     */         };
/*     */     
/*     */     }
/* 816 */     else if (comboBox == this.jComboTarget) {
/* 817 */       iL = new ItemListener()
/*     */         {
/*     */           public void itemStateChanged(ItemEvent e)
/*     */           {
/* 821 */             int index = ((JComboBox)e.getSource()).getSelectedIndex();
/*     */ 
/*     */             
/* 824 */             if (index > 1) {
/*     */               
/* 826 */               Object o = PathComputationDialog.this.jComboSource.getSelectedItem();
/* 827 */               if (o instanceof PathComputationDialog.MyFile) {
/* 828 */                 PathComputationDialog.this.targetFilterFile = ((PathComputationDialog.MyFile)o).file;
/* 829 */                 index = 0;
/* 830 */               } else if (o instanceof PathComputationDialog.MyId) {
/* 831 */                 PathComputationDialog.this.jTextTargetId.setText(Integer.toString(((PathComputationDialog.MyId)o).id));
/* 832 */                 index = 1;
/* 833 */                 PathComputationDialog.this.jRadioFullMarking.setSelected(true);
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/* 838 */             if (index == 0) {
/* 839 */               PathComputationDialog.this.thisPanel.remove(PathComputationDialog.this.targetIdPanel);
/* 840 */               PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.targetFilePanel, true);
/* 841 */               PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.targetIdPanel, false);
/* 842 */               PathComputationDialog.this.thisPanel.add(PathComputationDialog.this.targetFilePanel, PathComputationDialog.this.getPosString(PathComputationDialog.this.depTargetPos));
/*     */             }
/* 844 */             else if (index == 1) {
/* 845 */               PathComputationDialog.this.thisPanel.remove(PathComputationDialog.this.targetFilePanel);
/* 846 */               PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.targetFilePanel, false);
/* 847 */               PathComputationDialog.this.thisPanel.add(PathComputationDialog.this.targetIdPanel, PathComputationDialog.this.getPosString(PathComputationDialog.this.depTargetPos));
/* 848 */               if (PathComputationDialog.this.jComboRGraph.getSelectedItem() != null) {
/* 849 */                 PathComputationDialog.this.enableSubComponents(PathComputationDialog.this.targetIdPanel, true);
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 854 */             PathComputationDialog.this.thisPanel.revalidate();
/*     */           }
/*     */         };
/*     */     } else {
/* 858 */       iL = new ItemListener()
/*     */         {
/*     */           public void itemStateChanged(ItemEvent e) {
/* 861 */             System.out.printf("item state changed on unknown combobox ... ", new Object[0]);
/*     */           }
/*     */         };
/*     */     } 
/* 865 */     comboBox.addItemListener(iL);
/*     */   }
/*     */ 
/*     */   
/*     */   private String getPosString(int[] array) {
/* 870 */     StringBuilder sb = new StringBuilder();
/* 871 */     for (int i : array) {
/* 872 */       sb.append(i + ",");
/*     */     }
/*     */     
/* 875 */     return sb.substring(0, sb.length() - 1);
/*     */   }
/*     */   
/*     */   private void enableSubComponents(Container c, boolean enable) {
/* 879 */     for (Component subC : c.getComponents()) {
/* 880 */       if (subC instanceof JComponent) {
/* 881 */         ((JComponent)subC).setEnabled(enable);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private JButton getJButtonShow() {
/* 888 */     if (this.showWindow == null) {
/* 889 */       this.showWindow = new JButton();
/* 890 */       this.showWindow.setAction(new AbstractAction()
/*     */           {
/*     */ 
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 896 */               JButton b = (JButton)e.getSource();
/*     */ 
/*     */               
/* 899 */               boolean rev = PathComputationDialog.this.director.sendMessage(21, b, new Boolean(true));
/*     */             }
/*     */           });
/*     */     } 
/* 903 */     return this.showWindow;
/*     */   }
/*     */   
/*     */   private class MyFile
/*     */   {
/* 908 */     public File file = null;
/*     */     
/*     */     public MyFile(File f) {
/* 911 */       this.file = f;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 916 */       if (this.file != null) {
/* 917 */         return this.file.getName();
/*     */       }
/* 919 */       return "No file";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class MyId
/*     */   {
/* 926 */     public int id = -1;
/*     */     
/*     */     public MyId(int i) {
/* 929 */       this.id = i;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 933 */       return "State id: " + Integer.toString(this.id);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/PathComputationDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */