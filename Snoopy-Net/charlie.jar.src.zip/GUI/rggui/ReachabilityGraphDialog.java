/*     */ package GUI.rggui;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import GUI.app_components.ComputationalDialog;
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.MyMouseWheelListener;
/*     */ import charlie.analyzer.rg.ConstructionOptions;
/*     */ import charlie.rg.RGraph;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import layout.TableLayout;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReachabilityGraphDialog
/*     */   extends ComputationalDialog
/*     */ {
/*     */   private static final long serialVersionUID = 4641753974371944169L;
/*  39 */   private static final Log LOG = LogFactory.getLog(ReachabilityGraphDialog.class);
/*     */   
/*  41 */   private JLabel jLabelRGOptions = null;
/*  42 */   private JCheckBox jCheckBoxBackEdges = null;
/*  43 */   private JCheckBox jCheckBoxCheckBoundedness = null;
/*  44 */   private JCheckBox jCheckBoxStubbornReduction = null;
/*  45 */   private JSpinner jMaxConstDepthSpinner = null;
/*  46 */   private JLabel jLabelFireRules = null;
/*  47 */   private JComboBox jComboRGraph = null;
/*  48 */   private JRadioButton jRadioButtonSingleStep = null;
/*  49 */   private JRadioButton jRadioButtonMaximumStep = null;
/*  50 */   private JLabel jLabelMaxDepth = null;
/*  51 */   private JButton jButtonStart = null;
/*  52 */   private JButton jButtonHide = null;
/*  53 */   private JButton jButtonView = null;
/*  54 */   private JPanel constructionInfoPanel = null;
/*  55 */   int width = 300;
/*  56 */   int height = 185;
/*     */   
/*     */   public static JLabel states;
/*     */   
/*     */   public static JLabel edges;
/*     */   
/*     */   public static JLabel scc;
/*     */   
/*     */   public static JLabel time;
/*     */   
/*     */   public ReachabilityGraphDialog(IRGDirector director) {
/*  67 */     super(director);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() {
/*  78 */     int line = 0;
/*  79 */     double h = 25.0D;
/*  80 */     double[][] size = { { 5.0D, 147.0D, 147.0D, 5.0D }, { 5.0D, 5.0D } };
/*  81 */     TableLayout layout = new TableLayout(size);
/*  82 */     setLayout((LayoutManager)layout);
/*     */     
/*  84 */     layout.insertRow(++line, h);
/*  85 */     this.jLabelRGOptions = new JLabel("options");
/*  86 */     add(this.jLabelRGOptions, "1," + line);
/*  87 */     this.jLabelFireRules = new JLabel("fire rules");
/*  88 */     add(this.jLabelFireRules, "2," + line);
/*  89 */     layout.insertRow(++line, h);
/*  90 */     add(getJCheckBoxBackEdges(), "1," + line);
/*  91 */     add(getJRadioButtonSingleStep(), "2," + line);
/*  92 */     layout.insertRow(++line, h);
/*  93 */     add(getJCheckBoxCheckBoundedness(), "1," + line);
/*  94 */     add(getJRadioButtonMaximumStep(), "2," + line);
/*  95 */     layout.insertRow(++line, h);
/*  96 */     add(getJCheckBoxStubbornReduction(), "1," + line);
/*  97 */     this.jLabelMaxDepth = new JLabel("max depth");
/*  98 */     add(this.jLabelMaxDepth, "2," + line);
/*  99 */     layout.insertRow(++line, h);
/* 100 */     add(getSpinner(), "2,5");
/* 101 */     layout.insertRow(++line, -2.0D);
/* 102 */     this.constructionInfoPanel = getConstructionInfoPanel();
/* 103 */     add(this.constructionInfoPanel, "1," + line + ",2," + line);
/* 104 */     layout.insertRow(++line, h);
/*     */     
/* 106 */     add(getJComboRGraph(), "1," + line + ",2," + line);
/* 107 */     layout.insertRow(++line, h);
/* 108 */     add(getJButtonView(), "2," + line);
/* 109 */     add(getJButtonHide(), "1," + line);
/* 110 */     layout.insertRow(++line, h);
/* 111 */     add(getJButtonStart(), "1," + line + ",2," + line);
/*     */     
/* 113 */     ButtonGroup group = new ButtonGroup();
/* 114 */     group.add(this.jRadioButtonMaximumStep);
/* 115 */     group.add(this.jRadioButtonSingleStep);
/* 116 */     Dimension d = layout.preferredLayoutSize((Container)this);
/*     */     
/* 118 */     setPreferredSize(d);
/* 119 */     setSize(d);
/* 120 */     enableControls(false);
/*     */   }
/*     */   
/*     */   public void reset(boolean removeGraphs) {
/* 124 */     if (removeGraphs) {
/* 125 */       this.jComboRGraph.removeAllItems();
/*     */     }
/* 127 */     this.jCheckBoxCheckBoundedness.setSelected(true);
/* 128 */     time.setText("");
/* 129 */     scc.setText("");
/* 130 */     states.setText("");
/* 131 */     edges.setText("");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableControls(boolean b) {
/* 137 */     this.jLabelRGOptions.setEnabled(b);
/* 138 */     this.jCheckBoxBackEdges.setEnabled(b);
/* 139 */     this.jCheckBoxCheckBoundedness.setEnabled(b);
/* 140 */     this.jCheckBoxStubbornReduction.setEnabled(b);
/* 141 */     this.jMaxConstDepthSpinner.setEnabled(b);
/* 142 */     this.jLabelFireRules.setEnabled(b);
/* 143 */     this.jRadioButtonSingleStep.setEnabled(b);
/* 144 */     this.jRadioButtonMaximumStep.setEnabled(b);
/* 145 */     this.jLabelMaxDepth.setEnabled(b);
/* 146 */     this.jButtonStart.setEnabled(b);
/* 147 */     if (!b) {
/* 148 */       this.jButtonHide.setEnabled(b);
/* 149 */       this.jButtonView.setEnabled(b);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JCheckBox getJCheckBoxBackEdges() {
/* 160 */     if (this.jCheckBoxBackEdges == null) {
/* 161 */       this.jCheckBoxBackEdges = new JCheckBox("back edges");
/*     */     }
/* 163 */     return this.jCheckBoxBackEdges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JCheckBox getJCheckBoxCheckBoundedness() {
/* 172 */     if (this.jCheckBoxCheckBoundedness == null) {
/* 173 */       this.jCheckBoxCheckBoundedness = new JCheckBox("check boundedness");
/* 174 */       this.jCheckBoxCheckBoundedness.setToolTipText("check boundedness");
/*     */       
/* 176 */       this.jCheckBoxCheckBoundedness.setSelected(true);
/*     */     } 
/* 178 */     return this.jCheckBoxCheckBoundedness;
/*     */   }
/*     */   
/*     */   public void disableBoundednesCheck() {
/* 182 */     getJCheckBoxCheckBoundedness().setSelected(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JCheckBox getJCheckBoxStubbornReduction() {
/* 191 */     if (this.jCheckBoxStubbornReduction == null) {
/* 192 */       this.jCheckBoxStubbornReduction = new JCheckBox(new AbstractAction()
/*     */           {
/*     */             public void actionPerformed(ActionEvent e) {}
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 203 */       this.jCheckBoxStubbornReduction.setToolTipText("stubborn reduction");
/*     */     } 
/* 205 */     return this.jCheckBoxStubbornReduction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JRadioButton getJRadioButtonSingleStep() {
/* 214 */     if (this.jRadioButtonSingleStep == null) {
/* 215 */       this.jRadioButtonSingleStep = new JRadioButton("single step");
/* 216 */       this.jRadioButtonSingleStep.setSelected(true);
/*     */     } 
/* 218 */     return this.jRadioButtonSingleStep;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JRadioButton getJRadioButtonMaximumStep() {
/* 227 */     if (this.jRadioButtonMaximumStep == null) {
/* 228 */       this.jRadioButtonMaximumStep = new JRadioButton();
/* 229 */       this.jRadioButtonMaximumStep.setText("max step");
/*     */     } 
/* 231 */     return this.jRadioButtonMaximumStep;
/*     */   }
/*     */ 
/*     */   
/*     */   private JPanel getSpinner() {
/* 236 */     JSpinner spin = new JSpinner(new SpinnerNumberModel(0, 0, 200000, 1));
/* 237 */     spin.setEditor(new JSpinner.NumberEditor(spin));
/* 238 */     spin.addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(10));
/* 239 */     this.jMaxConstDepthSpinner = spin;
/* 240 */     JPanel p = new JPanel();
/* 241 */     Dimension d = new Dimension(100, 25);
/* 242 */     p.setSize(d);
/* 243 */     p.setPreferredSize(d);
/* 244 */     p.add(spin);
/* 245 */     return p;
/*     */   }
/*     */   
/*     */   public void setFrameState(boolean b) {
/* 249 */     this.jButtonHide.doClick();
/*     */   }
/*     */ 
/*     */   
/*     */   public void constructionFinished() {
/* 254 */     if (LOG.isDebugEnabled()) {
/* 255 */       LOG.debug("Reachability graph construction finished");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonStart() {
/* 265 */     if (this.jButtonStart == null) {
/* 266 */       this.jButtonStart = new JButton();
/* 267 */       this.jButtonStart.setAction(new AbstractAction()
/*     */           {
/*     */ 
/*     */             
/*     */             public void actionPerformed(ActionEvent evt)
/*     */             {
/* 273 */               ConstructionOptions co = new ConstructionOptions();
/* 274 */               co.rule = ReachabilityGraphDialog.this.jRadioButtonSingleStep.isSelected() ? 0 : 1;
/* 275 */               co.maxDepth = ((Integer)ReachabilityGraphDialog.this.jMaxConstDepthSpinner.getValue()).intValue();
/* 276 */               co.boundedness = ReachabilityGraphDialog.this.jCheckBoxCheckBoundedness.isSelected();
/* 277 */               co.stubborn = ReachabilityGraphDialog.this.jCheckBoxStubbornReduction.isSelected();
/* 278 */               co.backEdges = ReachabilityGraphDialog.this.jCheckBoxBackEdges.isSelected();
/*     */               
/* 280 */               co.pn = ReachabilityGraphDialog.this.getPN();
/* 281 */               if (!ReachabilityGraphDialog.this.getDirector().sendMessage(1, this, co)) {
/* 282 */                 JOptionPane.showMessageDialog(null, "Could not start rg construction \ncheck if a net is loaded!");
/*     */               }
/*     */             }
/*     */           });
/*     */     } 
/*     */     
/* 288 */     return this.jButtonStart;
/*     */   }
/*     */   
/*     */   private JButton getJButtonHide() {
/* 292 */     if (this.jButtonHide == null) {
/* 293 */       this.jButtonHide = new JButton();
/* 294 */       this.jButtonHide.setAction(new AbstractAction()
/*     */           {
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 299 */               JButton b = (JButton)e.getSource();
/*     */ 
/*     */               
/* 302 */               boolean rev = ReachabilityGraphDialog.this.getDirector().sendMessage(21, b, new Boolean(true));
/*     */             }
/*     */           });
/*     */     } 
/* 306 */     return this.jButtonHide;
/*     */   }
/*     */ 
/*     */   
/*     */   private JButton getJButtonView() {
/* 311 */     if (this.jButtonView == null) {
/* 312 */       this.jButtonView = new JButton();
/* 313 */       this.jButtonView.setAction(new AbstractAction()
/*     */           {
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 318 */               JButton b = (JButton)e.getSource();
/*     */ 
/*     */               
/* 321 */               if (ReachabilityGraphDialog.this.jComboRGraph != null) {
/* 322 */                 RGraph graph = (RGraph)ReachabilityGraphDialog.this.jComboRGraph.getSelectedItem();
/* 323 */                 DebugCounter.inc("index: " + ReachabilityGraphDialog.this.jComboRGraph.getSelectedIndex() + "sending rgraph to view: scc" + graph.getNumberOfScc() + " edges " + graph.getNumberOfEdges() + " nodes " + graph.getNumberOfNodes());
/* 324 */                 boolean rev = ReachabilityGraphDialog.this.getDirector().sendMessage(26, b, graph);
/* 325 */                 if (!rev) {
/* 326 */                   JOptionPane.showMessageDialog(b, "The Reachability Graph could not be visualized!");
/*     */                 }
/*     */               } 
/*     */             }
/*     */           });
/*     */     } 
/* 332 */     return this.jButtonView;
/*     */   }
/*     */ 
/*     */   
/*     */   private JPanel getConstructionInfoPanel() {
/* 337 */     JPanel p = new JPanel();
/* 338 */     double[][] size = { { 5.0D, 80.0D, 5.0D, 160.0D, 5.0D }, { 5.0D, 5.0D } };
/* 339 */     TableLayout layout = new TableLayout(size);
/* 340 */     p.setLayout((LayoutManager)layout);
/* 341 */     int height = 20;
/* 342 */     int line = 0;
/* 343 */     layout.insertRow(++line, height);
/* 344 */     p.add(new JLabel("edges:"), "1," + line);
/* 345 */     edges = new JLabel();
/* 346 */     p.add(edges, "3," + line);
/*     */     
/* 348 */     layout.insertRow(++line, height);
/* 349 */     p.add(new JLabel("states:"), "1," + line);
/* 350 */     states = new JLabel();
/* 351 */     p.add(states, "3," + line);
/*     */     
/* 353 */     layout.insertRow(++line, height);
/* 354 */     p.add(new JLabel("scc:"), "1," + line);
/* 355 */     scc = new JLabel();
/* 356 */     p.add(scc, "3," + line);
/*     */ 
/*     */     
/* 359 */     layout.insertRow(++line, height);
/* 360 */     p.add(new JLabel("time:"), "1," + line);
/* 361 */     time = new JLabel();
/* 362 */     p.add(time, "3," + line);
/*     */     
/* 364 */     p.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "rg info"));
/* 365 */     p.setVisible(true);
/* 366 */     Dimension d = layout.preferredLayoutSize(p);
/* 367 */     p.setSize(d);
/* 368 */     p.setPreferredSize(d);
/* 369 */     return p;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateInfo(RGraph rg) {
/* 374 */     if (rg == null) {
/* 375 */       time.setText("");
/* 376 */       time.setToolTipText("");
/* 377 */       states.setText("");
/* 378 */       edges.setText("");
/* 379 */       scc.setText("");
/*     */       
/*     */       return;
/*     */     } 
/* 383 */     updateInfo(rg.getConstructionTimeString(), Integer.valueOf(rg.getNumberOfNodes()), Integer.valueOf(rg.getNumberOfEdges()), Integer.valueOf(rg.getNumberOfScc()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateInfo(String timeS, Integer statesS, Integer edgesS, Integer sccS) {
/* 389 */     time.setText(timeS);
/* 390 */     time.setToolTipText(timeS);
/* 391 */     states.setText(statesS.toString());
/* 392 */     edges.setText(edgesS.toString());
/* 393 */     scc.setText(sccS.toString());
/* 394 */     if (!this.constructionInfoPanel.isVisible()) {
/* 395 */       TableLayout layout = (TableLayout)getLayout();
/*     */       
/* 397 */       layout.setRow(6, -2.0D);
/* 398 */       Dimension d = layout.preferredLayoutSize((Container)this);
/* 399 */       setSize(d);
/* 400 */       setPreferredSize(d);
/* 401 */       this.constructionInfoPanel.setVisible(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addRGToPanel(RGraph rg) {
/* 406 */     this.jButtonHide.setEnabled(true);
/* 407 */     this.jButtonView.setEnabled(true);
/* 408 */     DefaultComboBoxModel<RGraph> model = (DefaultComboBoxModel)this.jComboRGraph.getModel();
/* 409 */     if (model.getIndexOf(rg) < 0) {
/* 410 */       model.addElement(rg);
/* 411 */       model.setSelectedItem(rg);
/*     */     } 
/*     */   }
/*     */   
/*     */   public RGraph getSelectedRGraph() {
/* 416 */     return (RGraph)this.jComboRGraph.getModel().getSelectedItem();
/*     */   }
/*     */   
/*     */   public JComboBox getJComboRGraph() {
/* 420 */     this.jComboRGraph = new JComboBox(new DefaultComboBoxModel());
/* 421 */     this.jComboRGraph.setAction(new AbstractAction()
/*     */         {
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 427 */             JComboBox b = (JComboBox)e.getSource();
/* 428 */             RGraph r = (RGraph)b.getSelectedItem();
/* 429 */             ReachabilityGraphDialog.this.updateInfo(r);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 434 */     return this.jComboRGraph;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/ReachabilityGraphDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */