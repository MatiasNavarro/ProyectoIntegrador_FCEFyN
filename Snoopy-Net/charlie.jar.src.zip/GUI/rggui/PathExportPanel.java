/*    */ package GUI.rggui;
/*    */ 
/*    */ import GUI.io.FileSaver;
/*    */ import GUI.util.EnablingFilePanel;
/*    */ import GUI.util.TextFile;
/*    */ import charlie.pn.PlaceTransitionNet;
/*    */ import charlie.rg.Path;
/*    */ import java.awt.Component;
/*    */ import java.awt.GridBagConstraints;
/*    */ import java.awt.GridBagLayout;
/*    */ import java.awt.Insets;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.io.File;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JOptionPane;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathExportPanel
/*    */   extends JPanel
/*    */   implements ActionListener
/*    */ {
/*    */   private static final long serialVersionUID = -7571449541676241060L;
/*    */   Component owner;
/*    */   boolean computed = false;
/*    */   JButton export;
/*    */   JButton cancel;
/*    */   Path p;
/*    */   EnablingFilePanel markings;
/*    */   EnablingFilePanel transitions;
/*    */   EnablingFilePanel parikh;
/*    */   PlaceTransitionNet pn;
/*    */   String netName;
/*    */   
/*    */   public PathExportPanel(Component owner, Path p, PlaceTransitionNet net) {
/* 40 */     this.owner = owner;
/* 41 */     this.p = p;
/* 42 */     this.pn = net;
/* 43 */     this.netName = net.getName();
/* 44 */     GridBagLayout gbl = new GridBagLayout();
/* 45 */     setLayout(gbl);
/* 46 */     GridBagConstraints c = new GridBagConstraints();
/* 47 */     c.fill = 1;
/* 48 */     c.weightx = 1.0D;
/* 49 */     c.insets = new Insets(5, 5, 5, 5);
/* 50 */     c.gridwidth = 0;
/*    */     
/* 52 */     String dir = FileSaver.lastSaveDir;
/*    */     
/* 54 */     this.markings = new EnablingFilePanel(this, "", dir + File.separatorChar + this.netName + ".mseq", "export marking sequence", false);
/* 55 */     this.transitions = new EnablingFilePanel(this, "", dir + File.separatorChar + this.netName + ".tseq", "export transition sequence", false);
/* 56 */     this.parikh = new EnablingFilePanel(this, "", dir + File.separatorChar + this.netName + "_parikh.res", "export parikh vector", false);
/* 57 */     this.export = new JButton("export");
/* 58 */     this.export.addActionListener(this);
/* 59 */     gbl.setConstraints((Component)this.transitions, c);
/* 60 */     gbl.setConstraints((Component)this.markings, c);
/* 61 */     gbl.setConstraints((Component)this.parikh, c);
/* 62 */     add((Component)this.markings);
/* 63 */     add((Component)this.transitions);
/* 64 */     add((Component)this.parikh);
/* 65 */     this.cancel = new JButton("cancel");
/* 66 */     this.cancel.addActionListener(this);
/* 67 */     c.gridwidth = 1;
/* 68 */     gbl.setConstraints(this.export, c);
/* 69 */     add(this.export);
/*    */     
/* 71 */     c.gridwidth = 0;
/* 72 */     gbl.setConstraints(this.cancel, c);
/* 73 */     add(this.cancel);
/*    */   }
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 78 */     boolean b = false;
/* 79 */     if (e.getSource().equals(this.export)) {
/* 80 */       if (!this.markings.getPath().equals("")) {
/* 81 */         b = true;
/* 82 */         TextFile.writeToFile(new File(this.markings.getPath()), this.p.toMarkingSequence(this.pn), true);
/*    */       } 
/* 84 */       if (!this.transitions.getPath().equals("")) {
/* 85 */         b = true;
/* 86 */         TextFile.writeToFile(new File(this.transitions.getPath()), this.p.toTransitionSequence(this.pn), true);
/*    */       } 
/* 88 */       if (!this.parikh.getPath().equals("")) {
/* 89 */         b = true;
/* 90 */         TextFile.writeToFile(new File(this.parikh.getPath()), this.p.toParikhVector(this.pn), true);
/*    */       } 
/* 92 */       if (!b) {
/* 93 */         JOptionPane.showMessageDialog(this, "there is no export target!");
/*    */         return;
/*    */       } 
/* 96 */       this.owner.setVisible(false);
/*    */     }
/* 98 */     else if (e.getSource().equals(this.cancel)) {
/* 99 */       this.owner.setVisible(false);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/PathExportPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */