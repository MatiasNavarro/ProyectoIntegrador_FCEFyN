/*     */ package GUI.rggui;
/*     */ 
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.State;
/*     */ import charlie.rg.Path;
/*     */ import charlie.rg.RGraph;
/*     */ import charlie.vis.DiGraph;
/*     */ import charlie.vis.MyLayout;
/*     */ import charlie.vis.RGEdgePaintFunction;
/*     */ import charlie.vis.RGVertexAspectRatioFunction;
/*     */ import charlie.vis.RGVertexPaintFunction;
/*     */ import charlie.vis.RGVertexShapeFunction;
/*     */ import charlie.vis.RGVertexSizeFunction;
/*     */ import charlie.vis.RGVisualisation;
/*     */ import charlie.vis.Session;
/*     */ import charlie.vis.SimpleEdgeStringer;
/*     */ import charlie.vis.SimpleVertexStringer;
/*     */ import charlie.vis.ViewerInfo;
/*     */ import charlie.vis.VisEdge;
/*     */ import charlie.vis.VisNode;
/*     */ import edu.uci.ics.jung.graph.ArchetypeVertex;
/*     */ import edu.uci.ics.jung.graph.Edge;
/*     */ import edu.uci.ics.jung.graph.Graph;
/*     */ import edu.uci.ics.jung.graph.Vertex;
/*     */ import edu.uci.ics.jung.graph.decorators.EdgePaintFunction;
/*     */ import edu.uci.ics.jung.graph.decorators.EdgeShape;
/*     */ import edu.uci.ics.jung.graph.decorators.EdgeShapeFunction;
/*     */ import edu.uci.ics.jung.graph.decorators.EdgeStringer;
/*     */ import edu.uci.ics.jung.graph.decorators.VertexAspectRatioFunction;
/*     */ import edu.uci.ics.jung.graph.decorators.VertexPaintFunction;
/*     */ import edu.uci.ics.jung.graph.decorators.VertexShapeFunction;
/*     */ import edu.uci.ics.jung.graph.decorators.VertexSizeFunction;
/*     */ import edu.uci.ics.jung.graph.decorators.VertexStringer;
/*     */ import edu.uci.ics.jung.visualization.AbstractLayout;
/*     */ import edu.uci.ics.jung.visualization.Coordinates;
/*     */ import edu.uci.ics.jung.visualization.Layout;
/*     */ import edu.uci.ics.jung.visualization.PickSupport;
/*     */ import edu.uci.ics.jung.visualization.PickedState;
/*     */ import edu.uci.ics.jung.visualization.PluggableRenderer;
/*     */ import edu.uci.ics.jung.visualization.Renderer;
/*     */ import edu.uci.ics.jung.visualization.ShapePickSupport;
/*     */ import edu.uci.ics.jung.visualization.VisualizationViewer;
/*     */ import edu.uci.ics.jung.visualization.control.DefaultModalGraphMouse;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.datatransfer.Clipboard;
/*     */ import java.awt.datatransfer.ClipboardOwner;
/*     */ import java.awt.datatransfer.StringSelection;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.Stack;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ 
/*     */ public class Viewer extends JPanel {
/*     */   private static final long serialVersionUID = -7983022986376493411L;
/*     */   static PlaceTransitionNet pn;
/*     */   static Layout vg;
/*     */   RGraph rg;
/*     */   static Stack<Vertex> jumps;
/*     */   static Stack<Vertex> cuts;
/*     */   private VisualizationViewer vv;
/*     */   public Session session;
/*  74 */   String netInfo = "";
/*     */   
/*     */   public ViewerInfo vi;
/*     */   
/*     */   String title;
/*     */   
/*     */   boolean popup_allowed = true;
/*     */   
/*     */   private final int COND = 0;
/*     */   private final int PREV = 1;
/*     */   private final int NEXT = 2;
/*     */   private final int ENV = 3;
/*     */   
/*     */   private PluggableRenderer getRenderer() {
/*  88 */     if (this.vi != null && pn != null) {
/*  89 */       PluggableRenderer pr = new PluggableRenderer();
/*  90 */       pr.setEdgeShapeFunction((EdgeShapeFunction)new EdgeShape.QuadCurve());
/*  91 */       pr.setEdgePaintFunction((EdgePaintFunction)new RGEdgePaintFunction(this.vi));
/*  92 */       pr.setVertexStringer((VertexStringer)new SimpleVertexStringer(this.vi));
/*  93 */       pr.setEdgeStringer((EdgeStringer)new SimpleEdgeStringer(pn));
/*  94 */       pr.setVertexPaintFunction((VertexPaintFunction)new RGVertexPaintFunction(this.vi));
/*  95 */       pr.setVertexShapeFunction((VertexShapeFunction)new RGVertexShapeFunction((VertexSizeFunction)new RGVertexSizeFunction(this.vi), (VertexAspectRatioFunction)new RGVertexAspectRatioFunction(), this.vi));
/*  96 */       return pr;
/*     */     } 
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 103 */     this.rg = this.vi.rg;
/* 104 */     pn = this.vi.pn;
/* 105 */     setLayout(new BorderLayout());
/*     */     
/* 107 */     jumps = new Stack<>();
/* 108 */     cuts = new Stack<>();
/* 109 */     this.session = new Session(this.vi);
/* 110 */     this.session.addEntry(this.vi.layout);
/*     */ 
/*     */     
/* 113 */     this.vv = new VisualizationViewer(this.vi.layout, (Renderer)getRenderer());
/*     */     
/* 115 */     this.vv.setPickSupport((PickSupport)new ShapePickSupport());
/*     */ 
/*     */     
/* 118 */     getVisualisationViewer().addPostRenderPaintable(new VisualizationViewer.Paintable() {
/*     */           int x;
/*     */           int y;
/*     */           Font font;
/*     */           FontMetrics metrics;
/*     */           int swidth;
/*     */           int sheight;
/* 125 */           String str = "";
/*     */           
/*     */           public void paint(Graphics g) {
/* 128 */             Dimension d = Viewer.this.vv().getSize();
/* 129 */             if (this.font == null) {
/* 130 */               this.font = new Font(g.getFont().getName(), 0, 30);
/* 131 */               this.metrics = g.getFontMetrics(this.font);
/* 132 */               this.swidth = this.metrics.stringWidth(this.str);
/* 133 */               this.sheight = this.metrics.getMaxAscent() + this.metrics.getMaxDescent();
/* 134 */               this.x = (d.width - this.swidth) / 2;
/* 135 */               this.y = (int)(d.height - this.sheight * 1.5D);
/*     */             } 
/* 137 */             g.setFont(this.font);
/* 138 */             Color oldColor = g.getColor();
/*     */             
/* 140 */             g.setColor(Color.LIGHT_GRAY);
/* 141 */             g.drawString(this.str, this.x, this.y);
/* 142 */             g.setColor(oldColor);
/*     */           }
/*     */           public boolean useTransform() {
/* 145 */             return false;
/*     */           }
/*     */         });
/* 148 */     getVisualisationViewer().setGraphMouse((VisualizationViewer.GraphMouse)new TestGraphMouseListener());
/*     */ 
/*     */ 
/*     */     
/* 152 */     getVisualisationViewer().setToolTipListener(new VertexListener(this.vv, 20.0D, this.vi.layout.getGraph()));
/* 153 */     add((Component)this.vv, "Center");
/*     */ 
/*     */     
/* 156 */     if (RGVisualisation.condensed) {
/* 157 */       Cut initial = new Cut(new VisNode(this.rg.getFirst(), 0), 0);
/*     */     } else {
/* 159 */       Cut initial = new Cut(new VisNode(this.rg.getFirst(), 0), 2);
/* 160 */       initial.setCoord(getVisualisationViewer().getViewTransformer().getTranslateX(), 
/* 161 */           getVisualisationViewer().getViewTransformer().getTranslateY());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public VisualizationViewer vv() {
/* 174 */     return this.vv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VisualizationViewer getVisualisationViewer() {
/* 183 */     return this.vv;
/*     */   }
/*     */   
/*     */   public void setSession(Session s) {
/* 187 */     this.session = s;
/*     */   }
/*     */   
/*     */   public Session session() {
/* 191 */     return this.session;
/*     */   }
/*     */   
/*     */   public ViewerInfo vi() {
/* 195 */     return this.session.vi;
/*     */   }
/*     */   
/*     */   public RGraph getRG() {
/* 199 */     return this.rg;
/*     */   }
/*     */   
/*     */   public void enablePopup(boolean b) {
/* 203 */     this.popup_allowed = b;
/*     */   }
/*     */   
/*     */   public String netInfo() {
/* 207 */     return this.netInfo;
/*     */   }
/*     */   
/*     */   public PlaceTransitionNet getPn() {
/* 211 */     return pn;
/*     */   }
/*     */   public void forward() {
/* 214 */     Layout l = this.session.next();
/* 215 */     if (l != null) {
/*     */       
/* 217 */       Coordinates scale = new Coordinates(getVisualisationViewer().getViewTransformer().getScaleX(), getVisualisationViewer().getViewTransformer().getScaleY());
/* 218 */       getVisualisationViewer().setGraphLayout(l);
/* 219 */       getVisualisationViewer().getViewTransformer().scale(scale.getX(), scale.getY(), null);
/* 220 */       getVisualisationViewer().repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void back() {
/* 225 */     Layout l = this.session.back();
/* 226 */     if (l != null) {
/*     */       
/* 228 */       Coordinates scale = new Coordinates(getVisualisationViewer().getViewTransformer().getScaleX(), getVisualisationViewer().getViewTransformer().getScaleY());
/* 229 */       getVisualisationViewer().setGraphLayout(l);
/* 230 */       getVisualisationViewer().getViewTransformer().scale(scale.getX(), scale.getY(), null);
/* 231 */       getVisualisationViewer().repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void actualise(boolean repaint) {
/* 236 */     initialize();
/* 237 */     if (repaint) {
/* 238 */       actualise();
/*     */     }
/*     */   }
/*     */   
/*     */   public void actualise() {
/* 243 */     getVisualisationViewer().repaint();
/*     */   }
/*     */   
/*     */   private void analyseCut(Cut cut) {
/* 247 */     System.out.printf("analyze Cut\n", new Object[0]);
/*     */     
/* 249 */     Coordinates scale = new Coordinates(getVisualisationViewer().getViewTransformer().getScaleX(), getVisualisationViewer().getViewTransformer().getScaleY());
/* 250 */     this.vi.first = cut.root().getRGNode();
/* 251 */     this.vi.setLayout((Layout)new MyLayout((Graph)new DiGraph()));
/* 252 */     switch (cut.option()) {
/*     */       
/*     */       case 1:
/* 255 */         RGVisualisation.visualizeRG(vi(), false, false); break;
/*     */       case 2:
/* 257 */         RGVisualisation.visualizeRG(vi(), false, true); break;
/*     */       case 3:
/* 259 */         RGVisualisation.visualizeEnviroment(vi(), false);
/*     */         break;
/*     */     } 
/* 262 */     getVisualisationViewer().setGraphLayout((vi()).layout);
/* 263 */     this.session.addEntry((vi()).layout);
/* 264 */     vi().applyFilter();
/* 265 */     getVisualisationViewer().getViewTransformer().scale(scale.getX(), scale.getY(), null);
/* 266 */     double x = getVisualisationViewer().getLayoutTransformer().getTranslateX();
/* 267 */     double y = getVisualisationViewer().getLayoutTransformer().getTranslateY();
/* 268 */     if (x < 0.0D) {
/* 269 */       x *= -1.0D;
/*     */     }
/* 271 */     if (y < 0.0D) {
/* 272 */       y *= -1.0D;
/*     */     }
/* 274 */     getVisualisationViewer().getLayoutTransformer().translate(x, y);
/* 275 */     getVisualisationViewer().repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void next(Cut cut) {
/* 283 */     analyseCut(cut);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class VertexListener
/*     */     implements VisualizationViewer.ToolTipListener
/*     */   {
/*     */     double proximity;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     VisualizationViewer vv;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Graph g;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public VertexListener(VisualizationViewer vv, double proximity, Graph gn) {
/* 309 */       this.g = gn;
/* 310 */       this.vv = vv;
/* 311 */       this.proximity = proximity;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getToolTipText(MouseEvent event) {
/* 321 */       PickSupport pickSupport = this.vv.getPickSupport();
/* 322 */       if (pickSupport != null) {
/* 323 */         Point2D p = this.vv.transform(event.getPoint());
/* 324 */         Vertex v = pickSupport.getVertex(p.getX(), p.getY());
/* 325 */         Edge e = pickSupport.getEdge(p.getX(), p.getY());
/* 326 */         if (v != null) {
/* 327 */           return Viewer.pn.toLabel((State)((VisNode)v).getRGNode().getLabel());
/*     */         }
/* 329 */         if (e != null) {
/* 330 */           return ((VisEdge)e).getLabel();
/*     */         }
/*     */       } 
/* 333 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class TestGraphMouseListener
/*     */     extends DefaultModalGraphMouse
/*     */   {
/* 342 */     Vertex current = null;
/* 343 */     Vertex currentClicked = null;
/* 344 */     Color curColClicked = null;
/* 345 */     Vertex currentPressed = null;
/* 346 */     Color curColPressed = null;
/* 347 */     int count = 0;
/* 348 */     Vertex firstPressed = null;
/* 349 */     Vertex last = null;
/* 350 */     Object RG_Key = ((AbstractLayout)Viewer.this.vi.layout).getBaseKey();
/*     */     
/*     */     public TestGraphMouseListener() {
/* 353 */       setTransformingMode();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void jump(Vertex from, Vertex to) {
/* 360 */       Coordinates coord = (Coordinates)to.getUserDatum(((AbstractLayout)(Viewer.this.vi()).layout).getBaseKey());
/*     */       
/* 362 */       Coordinates coord2 = (Coordinates)from.getUserDatum(((AbstractLayout)(Viewer.this.vi()).layout).getBaseKey());
/*     */       
/* 364 */       Viewer.this.getVisualisationViewer().getViewTransformer().translate(coord2.getX() - coord.getX(), coord2.getY() - coord.getY());
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseReleased(MouseEvent me) {
/* 369 */       super.mouseReleased(me);
/* 370 */       setTransformingMode();
/*     */     }
/*     */ 
/*     */     
/*     */     public void mousePressed(MouseEvent me) {
/* 375 */       PickSupport pickSupport = Viewer.this.vv.getPickSupport();
/* 376 */       PickedState pickedState = Viewer.this.vv.getPickedState();
/* 377 */       Vertex v = null;
/* 378 */       if (pickSupport != null && pickedState != null) {
/* 379 */         Point2D p = me.getPoint();
/*     */         
/* 381 */         Point2D ip = Viewer.this.vv.inverseViewTransform(p);
/* 382 */         v = pickSupport.getVertex(ip.getX(), ip.getY());
/* 383 */         if (v != null && 
/* 384 */           !pickedState.isPicked((ArchetypeVertex)v)) {
/* 385 */           pickedState.clearPickedVertices();
/* 386 */           pickedState.pick((ArchetypeVertex)v, true);
/*     */         } 
/*     */       } 
/*     */       
/* 390 */       if (v != null) {
/* 391 */         setPickingMode();
/* 392 */         super.mousePressed(me);
/* 393 */         if (me.getButton() == 3) {
/* 394 */           checkPopupMenu(v, me);
/* 395 */           Viewer.this.getVisualisationViewer().repaint();
/*     */         }
/* 397 */         else if (me.getButton() == 1) {
/* 398 */           if (this.currentClicked != null)
/*     */           {
/* 400 */             if (((VisNode)this.currentClicked).equals(v)) {
/* 401 */               this.currentClicked = null;
/* 402 */               Viewer.this.vi().mark(null);
/*     */               
/*     */               return;
/*     */             } 
/*     */           }
/* 407 */           this.currentClicked = v;
/* 408 */           Viewer.this.vi().mark((VisNode)v);
/*     */         } 
/*     */       } 
/* 411 */       super.mousePressed(me);
/*     */     }
/*     */     
/*     */     private void checkPopupMenu(Vertex vertex, MouseEvent event) {
/* 415 */       final VisNode v = (VisNode)vertex;
/* 416 */       if (!Viewer.this.popup_allowed) {
/*     */         return;
/*     */       }
/*     */       
/* 420 */       JPopupMenu popup = new JPopupMenu();
/*     */       
/* 422 */       Path path = Viewer.this.vi().getPath();
/* 423 */       JMenuItem mi = new JMenuItem("copy marking");
/* 424 */       mi.addActionListener(new ActionListener() {
/*     */             public void actionPerformed(ActionEvent ae) {
/* 426 */               Clipboard clip = Viewer.this.getToolkit().getSystemClipboard();
/* 427 */               StringSelection selection = new StringSelection(Viewer.pn.toLabel((State)v.getRGNode().getLabel()));
/*     */               
/* 429 */               clip.setContents(selection, new ClipboardOwner() {
/*     */                     public void lostOwnership(Clipboard clip, Transferable cont) {}
/*     */                   });
/*     */             }
/*     */           });
/* 434 */       popup.add(mi);
/* 435 */       mi = new JMenuItem("create/copy filter");
/* 436 */       mi.addActionListener(new ActionListener() {
/*     */             public void actionPerformed(ActionEvent ae) {
/* 438 */               Clipboard clip = Viewer.this.getToolkit().getSystemClipboard();
/* 439 */               StringSelection selection = new StringSelection(Viewer.pn.toFilter(v.getRGNode().getLabel()));
/*     */               
/* 441 */               clip.setContents(selection, new ClipboardOwner() {
/*     */                     public void lostOwnership(Clipboard clip, Transferable cont) {}
/*     */                   });
/*     */             }
/*     */           });
/* 446 */       popup.add(mi);
/* 447 */       if (!RGVisualisation.condensed) {
/* 448 */         mi = new JMenuItem("start path");
/* 449 */         mi.addActionListener(new ActionListener() {
/*     */               public void actionPerformed(ActionEvent ae) {
/* 451 */                 String name = JOptionPane.showInputDialog(null, "Please enter a name for the path !", "path name?", 3);
/* 452 */                 Path p = new Path(v.getRGNode(), Viewer.this.rg);
/* 453 */                 p.setName(name);
/* 454 */                 Viewer.this.vi().addPath(p);
/*     */               }
/*     */             });
/*     */         
/* 458 */         popup.add(mi);
/*     */         
/* 460 */         if (Viewer.this.vi.getPath() != null && 
/* 461 */           !v.isLogic()) {
/* 462 */           short id = Viewer.this.vi.extendsPath(v);
/* 463 */           if (id >= 0) {
/* 464 */             mi = new JMenuItem("add to path");
/* 465 */             mi.addActionListener(new ActionListener() {
/*     */                   public void actionPerformed(ActionEvent ae) {
/* 467 */                     if (Viewer.this.vi.getPath() != null)
/* 468 */                       Viewer.this.vi.checkAndAddNode(v); 
/*     */                   }
/*     */                 });
/* 471 */             popup.add(mi);
/*     */           } 
/*     */           
/* 474 */           if (path.isLastNode(v.getRGNode())) {
/* 475 */             mi = new JMenuItem("delete from path");
/* 476 */             mi.addActionListener(new ActionListener() {
/*     */                   public void actionPerformed(ActionEvent ae) {
/* 478 */                     if (Viewer.this.vi.deleteLast() == 0) {
/* 479 */                       Viewer.this.vi.clearPath();
/*     */                     }
/*     */                   }
/*     */                 });
/* 483 */             popup.add(mi);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 491 */       if (v.isLogic()) {
/* 492 */         mi = new JMenuItem("jump");
/* 493 */         mi.addActionListener(new ActionListener() {
/*     */               public void actionPerformed(ActionEvent ae) {
/* 495 */                 Viewer.jumps.push(v);
/* 496 */                 Viewer.TestGraphMouseListener.this.currentClicked = (Vertex)Viewer.this.vi().visNodes().get(v.getRGNode());
/* 497 */                 Viewer.TestGraphMouseListener.this.jump((Vertex)v, Viewer.TestGraphMouseListener.this.currentClicked);
/* 498 */                 Viewer.this.vi().mark(v);
/*     */               }
/*     */             });
/* 501 */         popup.add(mi);
/*     */       } else {
/* 503 */         if (Viewer.this.vi().isMarked(v) && this.currentClicked != null && v.getRGNode().equals(((VisNode)this.currentClicked).getRGNode()) && !Viewer.jumps.isEmpty() && ((VisNode)Viewer.jumps.peek()).getRGNode().equals(v.getRGNode())) {
/* 504 */           mi = new JMenuItem("jump back");
/* 505 */           mi.addActionListener(new ActionListener() {
/*     */                 public void actionPerformed(ActionEvent ae) {
/* 507 */                   Vertex cur = Viewer.TestGraphMouseListener.this.currentClicked;
/* 508 */                   Viewer.TestGraphMouseListener.this.currentClicked = Viewer.jumps.pop();
/* 509 */                   Viewer.TestGraphMouseListener.this.jump(cur, Viewer.TestGraphMouseListener.this.currentClicked);
/*     */                 }
/*     */               });
/* 512 */           popup.add(mi);
/*     */         } 
/*     */         
/* 515 */         mi = new JMenuItem("show next states");
/* 516 */         mi.addActionListener(new ActionListener() {
/*     */               public void actionPerformed(ActionEvent ae) {
/* 518 */                 Viewer.this.next(new Viewer.Cut(v, 2));
/*     */               }
/*     */             });
/*     */         
/* 522 */         popup.add(mi);
/* 523 */         if (Viewer.this.rg.backEdges()) {
/* 524 */           mi = new JMenuItem("show previous states");
/* 525 */           mi.addActionListener(new ActionListener() {
/*     */                 public void actionPerformed(ActionEvent ae) {
/* 527 */                   Viewer.this.next(new Viewer.Cut(v, 1));
/*     */                 }
/*     */               });
/* 530 */           popup.add(mi);
/*     */         } 
/* 532 */         if (Viewer.this.rg.backEdges()) {
/* 533 */           mi = new JMenuItem("show enviroment");
/* 534 */           mi.addActionListener(new ActionListener() {
/*     */                 public void actionPerformed(ActionEvent ae) {
/* 536 */                   Viewer.this.next(new Viewer.Cut(v, 3));
/*     */                 }
/*     */               });
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 544 */       popup.show(event
/* 545 */           .getComponent(), event
/* 546 */           .getX(), event
/* 547 */           .getY());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Viewer(ViewerInfo vi, String title, int layer) {
/* 553 */     this.COND = 0;
/* 554 */     this.PREV = 1;
/* 555 */     this.NEXT = 2;
/* 556 */     this.ENV = 3;
/*     */     this.vi = vi;
/*     */     this.title = title;
/*     */     initialize();
/*     */   }
/*     */   class Cut { private VisNode root;
/*     */     
/*     */     public Cut(VisNode root, int option) {
/* 564 */       this.root = root;
/* 565 */       this.option = option;
/*     */     }
/*     */     private int option; private Coordinates coord;
/*     */     public int option() {
/* 569 */       return this.option;
/*     */     }
/*     */     
/*     */     public VisNode root() {
/* 573 */       return this.root;
/*     */     }
/*     */     
/*     */     public Coordinates coord() {
/* 577 */       return this.coord;
/*     */     }
/*     */     
/*     */     public void setCoord(double x, double y) {
/* 581 */       this.coord = new Coordinates(x, y);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/rggui/Viewer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */