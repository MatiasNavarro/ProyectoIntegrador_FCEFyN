/*    */ package GUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThreadTest
/*    */ {
/*    */   public static void main(String[] args) {
/* 19 */     ThreadText[] t1 = new ThreadText[10];
/* 20 */     Thread[] tArray = new Thread[10];
/* 21 */     int i = 0;
/* 22 */     for (i = 0; i < 10; i++) {
/* 23 */       t1[i] = new ThreadText("peter " + i);
/* 24 */       System.out.println("Adding thread " + i);
/* 25 */       tArray[i] = new Thread(t1[i]);
/*    */     } 
/* 27 */     System.out.println("starting all threads");
/* 28 */     for (i = 0; i < 10; i++)
/* 29 */       tArray[i].start(); 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/ThreadTest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */