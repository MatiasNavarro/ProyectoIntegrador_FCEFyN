package GUI.markingeditor2;

import GUI.IDirector;

public interface IMarkingDirector extends IDirector {
  public static final int NEW_MARKING = 1;
  
  public static final int COPY_MARKING = 2;
  
  public static final int DELETE_MARKING = 3;
  
  public static final int SWITCH_MARKING = 4;
  
  public static final int NET_LOADED = 5;
  
  public static final int NET_SWITCHED = 6;
  
  public static final int EXIT = 7;
  
  public static final int APNN_EXPORT = 8;
  
  public static final int FILTER = 9;
  
  public static final int GET_EXTERNAL_DIALOG = 10;
  
  public static final int SHOW_GUI = 11;
  
  public static final int SAVE_MARKINGS = 12;
  
  public static final int LOAD_MARKINGS = 13;
  
  public static final int UPDATE_MARKING = 14;
  
  public static final int APPEND_MARKING = 15;
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/IMarkingDirector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */