/*     */ package GUI.markingeditor2;
/*     */ 
/*     */ import GUI.markingeditor2.actions.ApnnExportAction;
/*     */ import GUI.markingeditor2.actions.LoadMarkingsAction;
/*     */ import GUI.markingeditor2.actions.SaveMarkingsAction;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ 
/*     */ public class MarkingEditorDialog
/*     */   extends JPanel
/*     */ {
/*  22 */   private MarkingEditorGui frame = null;
/*  23 */   private MarkingEditor director = null;
/*  24 */   private JButton buttonShowEditor = null;
/*  25 */   private JComboBox comboMarkings = null;
/*  26 */   private ComboBoxModel boxModel = null;
/*  27 */   private JButton loadMarkingsButton = null;
/*  28 */   private JButton saveMarkingsButton = null;
/*  29 */   private JLabel netName = null;
/*  30 */   private JLabel markingName = null;
/*  31 */   private JButton buttonSaveNet = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkingEditorDialog(MarkingEditor me, MarkingEditorGui frame, ComboBoxModel boxModel) {
/*  37 */     this.director = me;
/*  38 */     this.frame = frame;
/*  39 */     this.boxModel = boxModel;
/*  40 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  49 */     this.buttonShowEditor = new JButton(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/*  56 */             if (MarkingEditorDialog.this.frame.isVisible()) {
/*  57 */               MarkingEditorDialog.this.frame.toFront();
/*     */             } else {
/*  59 */               MarkingEditorDialog.this.frame.setVisible(true);
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/*  64 */     this.comboMarkings = new JComboBox();
/*  65 */     this.comboMarkings.setModel(this.boxModel);
/*     */ 
/*     */     
/*  68 */     this.netName = new JLabel("");
/*  69 */     this.markingName = new JLabel("");
/*     */ 
/*     */     
/*  72 */     this.buttonSaveNet = new JButton((Action)new ApnnExportAction(this.director, this.boxModel));
/*     */ 
/*     */     
/*  75 */     setSize(300, 160);
/*  76 */     setPreferredSize(new Dimension(300, 160));
/*     */     
/*  78 */     double[][] size = { { 5.0D, 147.0D, 147.0D, 5.0D }, { 5.0D, 25.0D, 25.0D, 25.0D, 25.0D, 25.0D, 25.0D, 5.0D } };
/*  79 */     TableLayout layout = new TableLayout(size);
/*  80 */     setLayout((LayoutManager)layout);
/*  81 */     add(this.buttonShowEditor, "1,1,2,1");
/*  82 */     add(new JLabel("markings"), "1,2");
/*  83 */     add(this.comboMarkings, "1,3,2,3");
/*  84 */     add(this.markingName, "1,4,2,4");
/*  85 */     add(this.buttonSaveNet, "1,5,2,5");
/*  86 */     this.loadMarkingsButton = new JButton((Action)new LoadMarkingsAction(this.director, false));
/*  87 */     this.saveMarkingsButton = new JButton((Action)new SaveMarkingsAction(this.director, false));
/*  88 */     add(this.loadMarkingsButton, "1,6");
/*  89 */     add(this.saveMarkingsButton, "2,6");
/*  90 */     enableControls(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableControls(boolean b) {
/*  96 */     this.buttonShowEditor.setEnabled(b);
/*  97 */     this.comboMarkings.setEnabled(b);
/*  98 */     this.buttonSaveNet.setEnabled(b);
/*  99 */     this.loadMarkingsButton.setEnabled(b);
/* 100 */     this.saveMarkingsButton.setEnabled(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNetName(String newName) {
/* 108 */     this.netName.setText(newName);
/* 109 */     if (newName != null && !newName.equals("net name : ")) {
/* 110 */       enableControls(true);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setMarkingName(String newName) {
/* 115 */     this.markingName.setText("current marking : " + newName);
/* 116 */     enableControls(true);
/*     */   }
/*     */   
/*     */   public void setComboBoxModel(ComboBoxModel boxModel) {
/* 120 */     this.boxModel.removeListDataListener(this.comboMarkings);
/* 121 */     this.comboMarkings.setModel(boxModel);
/*     */     
/* 123 */     this.buttonSaveNet.setAction((Action)new ApnnExportAction(this.director, boxModel));
/* 124 */     this.buttonSaveNet.setEnabled(true);
/*     */   }
/*     */   
/*     */   public void enableComboBox(boolean value) {
/* 128 */     this.comboMarkings.setEnabled(value);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/MarkingEditorDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */