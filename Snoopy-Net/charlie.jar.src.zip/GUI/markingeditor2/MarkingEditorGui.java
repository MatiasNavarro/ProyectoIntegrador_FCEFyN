/*    */ package GUI.markingeditor2;
/*    */ 
/*    */ import GUI.IDirector;
/*    */ import GUI.util.Align;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JScrollPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MarkingEditorGui
/*    */   extends JDialog
/*    */ {
/*    */   private static final long serialVersionUID = 4881009766324798996L;
/*    */   
/*    */   public MarkingEditorGui(IDirector _director) {
/* 21 */     JPanel cpane = (JPanel)getContentPane();
/* 22 */     cpane.setLayout(new BorderLayout());
/* 23 */     cpane.setSize(600, 400);
/* 24 */     cpane.setPreferredSize(new Dimension(600, 400));
/* 25 */     setName("markingeditor");
/*    */   }
/*    */   
/*    */   public void setToolBar(MarkingToolBar toolBar) {
/* 29 */     JPanel cpane = (JPanel)getContentPane();
/* 30 */     cpane.add(toolBar, "North");
/*    */   }
/*    */   
/*    */   public void setTable(MarkingTable table) {
/* 34 */     JPanel cpane = (JPanel)getContentPane();
/* 35 */     JScrollPane scroll = new JScrollPane(table);
/* 36 */     cpane.add(scroll, "Center");
/*    */   }
/*    */ 
/*    */   
/*    */   public void setVisible(boolean value) {
/* 41 */     if (value) {
/* 42 */       alignToParentWindow((JFrame)null);
/*    */     }
/* 44 */     super.setVisible(value);
/*    */   }
/*    */   
/*    */   public void alignToParentWindow(JFrame parent) {
/* 48 */     Align.alignToParentWindow(this, parent);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/MarkingEditorGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */