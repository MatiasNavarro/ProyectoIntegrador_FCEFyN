/*     */ package GUI.markingeditor2;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import GUI.markingeditor2.filter.FilterGetter;
/*     */ import GUI.markingeditor2.filter.SimpleFilter;
/*     */ import GUI.markingeditor2.table.ColoredTableCellRenderer;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import java.awt.Component;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.RowFilter;
/*     */ import javax.swing.ToolTipManager;
/*     */ import javax.swing.event.TableColumnModelListener;
/*     */ import javax.swing.table.DefaultTableColumnModel;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableRowSorter;
/*     */ 
/*     */ public class MarkingTable
/*     */   extends JTable
/*     */   implements TableColumnModelListener {
/*  27 */   int selectedColumn = -1;
/*     */   
/*  29 */   MyTableModel tableModel = null;
/*     */   
/*  31 */   TableRowSorter sorter = null;
/*  32 */   ColoredTableCellRenderer cellRenderer = new ColoredTableCellRenderer();
/*  33 */   MyCellEditor cellEditor = new MyCellEditor(new JTextField());
/*  34 */   PlaceTransitionNet pn = null;
/*  35 */   IDirector director = null;
/*     */   public MarkingTable(IDirector director) {
/*  37 */     this.director = director;
/*  38 */     init();
/*     */   }
/*     */   
/*     */   public void init() {
/*  42 */     setColumnSelectionAllowed(true);
/*  43 */     setFillsViewportHeight(true);
/*  44 */     setAutoResizeMode(0);
/*  45 */     if (this.tableModel != null) setDefaultRenderer(this.tableModel.getColumnClass(1), (TableCellRenderer)this.cellRenderer);
/*     */     
/*  47 */     ToolTipManager.sharedInstance().unregisterComponent(this);
/*  48 */     ToolTipManager.sharedInstance().unregisterComponent(getTableHeader());
/*  49 */     setDragEnabled(false);
/*  50 */     setColumnSelectionAllowed(false);
/*  51 */     setAutoCreateRowSorter(false);
/*  52 */     DefaultTableColumnModel colModel = (DefaultTableColumnModel)getColumnModel();
/*  53 */     colModel.addColumnModelListener(this);
/*  54 */     getTableHeader().setReorderingAllowed(false);
/*  55 */     setCellEditor(this.cellEditor);
/*  56 */     JTableHeader header = getTableHeader();
/*  57 */     header.setUpdateTableInRealTime(true);
/*  58 */     header.addMouseListener(new ColumnListener(this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModel(MyTableModel model) {
/*  66 */     this.tableModel = model;
/*  67 */     setModel(model);
/*  68 */     this.tableModel.addTableModelListener(this);
/*     */     
/*  70 */     this.sorter = new MyTableRowSorter(this.tableModel);
/*  71 */     setDefaultRenderer(this.tableModel.getColumnClass(1), (TableCellRenderer)this.cellRenderer);
/*  72 */     setRowSorter(this.sorter);
/*  73 */     setDefaultEditor(model.getColumnClass(1), this.cellEditor);
/*  74 */     this.tableModel.fireTableStructureChanged();
/*     */   }
/*     */   
/*     */   public PlaceTransitionNet getNet() {
/*  78 */     return this.pn;
/*     */   }
/*     */   
/*     */   public void setSelectedColumn(int index) {
/*  82 */     if (index > 0 && index < this.tableModel.getColumnCount()) {
/*  83 */       this.selectedColumn = index;
/*  84 */       this.cellRenderer.setSelectedColumn(index);
/*  85 */       this.tableModel.setMarkingToNet(index);
/*  86 */       this.tableModel.fireTableDataChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getSelectedColumn() {
/*  91 */     return this.selectedColumn;
/*     */   }
/*     */   
/*     */   public void selectMarking(String name) {
/*  95 */     if (this.tableModel != null) setSelectedColumn(this.tableModel.findColumn(name)); 
/*     */   }
/*     */   
/*     */   public void selectMarking(Marking m) {
/*  99 */     if (this.tableModel != null && m != null) {
/* 100 */       int index = this.tableModel.findColumn(m);
/*     */       
/* 102 */       if (index != -1) {
/* 103 */         setSelectedColumn(index + 1);
/*     */       } else {
/* 105 */         System.out.printf("MarkingTable: error during selectMarking: index = %d\n", new Object[] { Integer.valueOf(index) });
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void columnSelectionChanged(int toIndex) {
/* 111 */     this.director.sendMessage(4, this, new Integer(toIndex));
/*     */   }
/*     */ 
/*     */   
/*     */   public void filterPlaces(String filter) {
/* 116 */     RowFilter<MyTableModel, Object> rf = null;
/*     */     
/*     */     try {
/* 119 */       rf = RowFilter.regexFilter(filter, new int[] { 0 });
/* 120 */     } catch (PatternSyntaxException e) {
/*     */       return;
/*     */     } 
/* 123 */     this.sorter.setRowFilter((RowFilter)rf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void filterToken(SimpleFilter simpleFilter) {
/* 130 */     int filterType = simpleFilter.getType();
/* 131 */     int value = Integer.parseInt(simpleFilter.getValue());
/* 132 */     if (filterType != -1 && filterType != 0) {
/* 133 */       RowFilter<MyTableModel, Object> filter = FilterGetter.getRowFilter(filterType, value, this.selectedColumn);
/* 134 */       this.sorter.setRowFilter((RowFilter)filter);
/*     */     } else {
/* 136 */       this.sorter.setRowFilter(null);
/*     */     } 
/*     */   }
/*     */   
/*     */   class MyTableRowSorter
/*     */     extends TableRowSorter<MyTableModel> {
/*     */     public MyTableRowSorter(MyTableModel model) {
/* 143 */       super(model);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void toggleSortOrder(int column) {}
/*     */   }
/*     */ 
/*     */   
/*     */   class ColumnListener
/*     */     extends MouseAdapter
/*     */   {
/*     */     protected MarkingTable m_table;
/*     */ 
/*     */     
/*     */     public ColumnListener(MarkingTable table) {
/* 159 */       this.m_table = table;
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseClicked(MouseEvent e) {
/* 164 */       TableColumnModel colModel = this.m_table.getColumnModel();
/*     */       
/* 166 */       int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
/*     */ 
/*     */       
/* 169 */       int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();
/*     */       
/* 171 */       if (modelIndex < 0) {
/*     */         return;
/*     */       }
/*     */       
/* 175 */       this.m_table.columnSelectionChanged(modelIndex);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class MyCellEditor
/*     */     extends DefaultCellEditor
/*     */   {
/* 200 */     private JTextField component = new JTextField();
/*     */     
/*     */     public MyCellEditor(JTextField textfield) {
/* 203 */       super(textfield);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getCellEditorValue() {
/* 208 */       return Byte.decode(this.component.getText());
/*     */     }
/*     */ 
/*     */     
/*     */     public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
/* 213 */       this.component.setText("");
/* 214 */       return this.component;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/MarkingTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */