/*    */ package GUI.markingeditor2.filter;
/*    */ 
/*    */ import GUI.markingeditor2.MyTableModel;
/*    */ import javax.swing.RowFilter;
/*    */ 
/*    */ public class FilterGetter
/*    */ {
/*    */   public static RowFilter<MyTableModel, Object> getRowFilter(int type, int value, int column) {
/*  9 */     switch (type) { case 1:
/* 10 */         return (new FilterGetter()).getGTFilter(value, column);
/* 11 */       case 2: return (new FilterGetter()).getLTFilter(value, column);
/* 12 */       case 3: return (new FilterGetter()).getEQFilter(value, column);
/* 13 */       case 5: return (new FilterGetter()).getGTEQFilter(value, column);
/* 14 */       case 6: return (new FilterGetter()).getLTEQFilter(value, column);
/* 15 */       case 4: return (new FilterGetter()).getNEQFilter(value, column); }
/* 16 */      return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public RowFilter<MyTableModel, Object> getEQFilter(final int value, final int column) {
/* 21 */     RowFilter<MyTableModel, Object> filter = new RowFilter<MyTableModel, Object>() {
/*    */         public boolean include(RowFilter.Entry entry) {
/* 23 */           Integer population = (Integer)entry.getValue(column);
/* 24 */           return (population.intValue() == value);
/*    */         }
/*    */       };
/* 27 */     return filter;
/*    */   }
/*    */   
/*    */   public RowFilter<MyTableModel, Object> getGTFilter(final int value, final int column) {
/* 31 */     RowFilter<MyTableModel, Object> filter = new RowFilter<MyTableModel, Object>() {
/*    */         public boolean include(RowFilter.Entry entry) {
/* 33 */           Integer population = (Integer)entry.getValue(column);
/* 34 */           return (population.intValue() > value);
/*    */         }
/*    */       };
/* 37 */     return filter;
/*    */   }
/*    */   public RowFilter<MyTableModel, Object> getLTFilter(final int value, final int column) {
/* 40 */     RowFilter<MyTableModel, Object> filter = new RowFilter<MyTableModel, Object>() {
/*    */         public boolean include(RowFilter.Entry entry) {
/* 42 */           Integer population = (Integer)entry.getValue(column);
/* 43 */           return (population.intValue() < value);
/*    */         }
/*    */       };
/* 46 */     return filter;
/*    */   }
/*    */   public RowFilter<MyTableModel, Object> getGTEQFilter(final int value, final int column) {
/* 49 */     RowFilter<MyTableModel, Object> filter = new RowFilter<MyTableModel, Object>() {
/*    */         public boolean include(RowFilter.Entry entry) {
/* 51 */           Integer population = (Integer)entry.getValue(column);
/* 52 */           return (population.intValue() >= value);
/*    */         }
/*    */       };
/* 55 */     return filter;
/*    */   }
/*    */   public RowFilter<MyTableModel, Object> getLTEQFilter(final int value, final int column) {
/* 58 */     RowFilter<MyTableModel, Object> filter = new RowFilter<MyTableModel, Object>() {
/*    */         public boolean include(RowFilter.Entry entry) {
/* 60 */           Integer population = (Integer)entry.getValue(column);
/* 61 */           return (population.intValue() <= value);
/*    */         }
/*    */       };
/* 64 */     return filter;
/*    */   }
/*    */   public RowFilter<MyTableModel, Object> getNEQFilter(final int value, final int column) {
/* 67 */     RowFilter<MyTableModel, Object> filter = new RowFilter<MyTableModel, Object>() {
/*    */         public boolean include(RowFilter.Entry entry) {
/* 69 */           Integer population = (Integer)entry.getValue(column);
/* 70 */           return (population.intValue() != value);
/*    */         }
/*    */       };
/* 73 */     return filter;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/filter/FilterGetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */