/*    */ package GUI.markingeditor2.filter;
/*    */ 
/*    */ 
/*    */ public class SimpleFilter
/*    */ {
/*    */   public static final int NO_FILTER = -1;
/*    */   public static final int TEXT_FILTER = 0;
/*    */   public static final int GT_FILTER = 1;
/*    */   public static final int LT_FILTER = 2;
/*    */   public static final int EQ_FILTER = 3;
/*    */   public static final int NEQ_FILTER = 4;
/*    */   public static final int GTEQ_FILTER = 5;
/*    */   public static final int LTEQ_FILTER = 6;
/*    */   int type;
/*    */   String value;
/*    */   
/*    */   public SimpleFilter(int type, String value) {
/* 18 */     this.type = type;
/* 19 */     this.value = value;
/*    */   }
/*    */   
/*    */   public int getType() {
/* 23 */     return this.type;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 27 */     return this.value;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 31 */     switch (this.type) {
/*    */       case 0:
/* 33 */         return "\"" + this.value + "\"";
/*    */       
/*    */       case 1:
/* 36 */         return "\">\" " + this.value;
/*    */       
/*    */       case 2:
/* 39 */         return "\"<\" " + this.value;
/*    */       
/*    */       case 3:
/* 42 */         return "\"=\" " + this.value;
/*    */       
/*    */       case 4:
/* 45 */         return "\"!=\" " + this.value;
/*    */       
/*    */       case 5:
/* 48 */         return "\">=\" " + this.value;
/*    */       
/*    */       case 6:
/* 51 */         return "\"<= \" " + this.value;
/*    */     } 
/*    */     
/* 54 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getFilterType(String funcString) {
/* 61 */     if (funcString.equals("<"))
/* 62 */       return 2; 
/* 63 */     if (funcString.equals(">"))
/* 64 */       return 1; 
/* 65 */     if (funcString.equals("="))
/* 66 */       return 3; 
/* 67 */     if (funcString.equals("<="))
/* 68 */       return 6; 
/* 69 */     if (funcString.equals(">="))
/* 70 */       return 5; 
/* 71 */     if (funcString.equals("!="))
/* 72 */       return 4; 
/* 73 */     if (!funcString.equals(""))
/* 74 */       return 0; 
/* 75 */     return -1;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/filter/SimpleFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */