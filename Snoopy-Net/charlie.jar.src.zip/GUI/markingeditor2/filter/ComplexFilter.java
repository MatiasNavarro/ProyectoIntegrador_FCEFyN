/*    */ package GUI.markingeditor2.filter;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import javax.swing.RowSorter;
/*    */ import javax.swing.table.TableModel;
/*    */ 
/*    */ public class ComplexFilter {
/*  8 */   ArrayList<SimpleFilter> filterList = new ArrayList<>();
/*  9 */   TableModel model = null;
/*    */   public ComplexFilter(TableModel model) {
/* 11 */     this.model = model;
/*    */   }
/*    */   
/*    */   public void addFilter(SimpleFilter filter) {
/* 15 */     this.filterList.add(filter);
/*    */   }
/*    */   
/*    */   public void clearFilter() {
/* 19 */     this.filterList.clear();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 23 */     StringBuffer buf = new StringBuffer();
/*    */     
/* 25 */     for (int i = 0; i < this.filterList.size(); i++) {
/* 26 */       buf.append(((SimpleFilter)this.filterList.get(i)).toString());
/*    */     }
/* 28 */     return buf.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RowSorter getFilter() {
/* 44 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/filter/ComplexFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */