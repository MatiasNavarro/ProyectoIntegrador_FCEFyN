/*    */ package GUI.markingeditor2.actions;
/*    */ 
/*    */ import GUI.markingeditor2.IMarkingDirector;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JOptionPane;
/*    */ import javax.swing.KeyStroke;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewMarkingAction
/*    */   extends AbstractAction
/*    */ {
/* 17 */   private IMarkingDirector director = null;
/*    */   
/*    */   public NewMarkingAction(IMarkingDirector director) {
/* 20 */     this.director = director;
/* 21 */     putValue("Name", "new");
/* 22 */     putValue("ShortDescription", "add a new marking");
/* 23 */     putValue("MnemonicKey", Integer.valueOf(78));
/* 24 */     putValue("AcceleratorKey", KeyStroke.getKeyStroke(78, 128));
/*    */   }
/*    */   private JDialog dialog;
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 29 */     String name = JOptionPane.showInputDialog(null, "Enter a description or name for the new marking:", "new markings name", 3);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 34 */     if (name != null) {
/* 35 */       boolean b = this.director.sendMessage(1, this, name);
/* 36 */       if (!b) JOptionPane.showMessageDialog(null, "<html>Could not create Marking!<br>Name is already used.</html>"); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/actions/NewMarkingAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */