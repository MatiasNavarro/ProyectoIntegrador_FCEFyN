/*    */ package GUI.markingeditor2.actions;
/*    */ 
/*    */ import GUI.io.FileSaver;
/*    */ import GUI.markingeditor2.IMarkingDirector;
/*    */ import GUI.util.ResourceLoader;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.File;
/*    */ import java.net.URL;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.KeyStroke;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SaveMarkingsAction
/*    */   extends AbstractAction
/*    */ {
/* 18 */   private IMarkingDirector director = null;
/*    */   
/*    */   public SaveMarkingsAction(IMarkingDirector director, boolean useIcon) {
/* 21 */     this.director = director;
/* 22 */     if (useIcon) {
/* 23 */       URL url = ResourceLoader.getURL("resources/save.gif");
/* 24 */       if (url != null)
/* 25 */         putValue("SmallIcon", new ImageIcon(url)); 
/*    */     } else {
/* 27 */       putValue("Name", "save markings");
/*    */     } 
/*    */     
/* 30 */     putValue("ShortDescription", "saves the actual marking set");
/* 31 */     putValue("MnemonicKey", Integer.valueOf(83));
/* 32 */     putValue("AcceleratorKey", KeyStroke.getKeyStroke(83, 128));
/*    */   }
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 37 */     FileSaver fs = new FileSaver();
/* 38 */     File saveFile = fs.showSaveDialog(null, "Do you want to overwrite the file ?", "ms");
/* 39 */     if (saveFile != null)
/* 40 */       boolean bool = this.director.sendMessage(12, this, saveFile); 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/actions/SaveMarkingsAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */