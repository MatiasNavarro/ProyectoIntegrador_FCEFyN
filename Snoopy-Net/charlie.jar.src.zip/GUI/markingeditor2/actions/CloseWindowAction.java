/*    */ package GUI.markingeditor2.actions;
/*    */ 
/*    */ import GUI.markingeditor2.IMarkingDirector;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.KeyStroke;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CloseWindowAction
/*    */   extends AbstractAction
/*    */ {
/* 15 */   private IMarkingDirector director = null;
/*    */   
/*    */   public CloseWindowAction(IMarkingDirector director) {
/* 18 */     this.director = director;
/* 19 */     putValue("Name", "close window");
/* 20 */     putValue("ShortDescription", "closes the marking-editor window");
/* 21 */     putValue("MnemonicKey", Integer.valueOf(67));
/* 22 */     putValue("AcceleratorKey", KeyStroke.getKeyStroke(81, 128));
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 26 */     this.director.sendMessage(7, this, null);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/actions/CloseWindowAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */