/*    */ package GUI.markingeditor2.actions;
/*    */ 
/*    */ import GUI.markingeditor2.IMarkingDirector;
/*    */ import java.awt.event.ItemEvent;
/*    */ import java.awt.event.ItemListener;
/*    */ import javax.swing.JComboBox;
/*    */ 
/*    */ public class MarkingNamesAction
/*    */   implements ItemListener
/*    */ {
/*    */   IMarkingDirector director;
/*    */   
/*    */   public MarkingNamesAction(IMarkingDirector director) {
/* 14 */     this.director = director;
/*    */   }
/*    */   
/*    */   public void itemStateChanged(ItemEvent e) {
/* 18 */     if (e.getStateChange() == 1) {
/* 19 */       JComboBox markingNames = (JComboBox)e.getSource();
/* 20 */       if (markingNames.getSelectedItem() != null)
/*    */       {
/* 22 */         this.director.sendMessage(4, markingNames, markingNames.getSelectedItem());
/*    */       }
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/actions/MarkingNamesAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */