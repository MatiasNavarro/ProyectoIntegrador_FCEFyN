/*    */ package GUI.markingeditor2.actions;
/*    */ 
/*    */ import GUI.io.FileSaver;
/*    */ import GUI.markingeditor2.IMarkingDirector;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.File;
/*    */ import java.net.URL;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JOptionPane;
/*    */ import javax.swing.KeyStroke;
/*    */ import javax.swing.filechooser.FileNameExtensionFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadMarkingsAction
/*    */   extends AbstractAction
/*    */ {
/* 20 */   private IMarkingDirector director = null;
/*    */   
/*    */   public LoadMarkingsAction(IMarkingDirector director, boolean useIcon) {
/* 23 */     this.director = director;
/* 24 */     if (useIcon) {
/* 25 */       URL url = ClassLoader.getSystemResource("resources/load.gif");
/* 26 */       if (url != null)
/* 27 */         putValue("SmallIcon", new ImageIcon(url)); 
/*    */     } else {
/* 29 */       putValue("Name", "load markings");
/*    */     } 
/* 31 */     putValue("ShortDescription", "loads a markingset for the acutal loaded file");
/* 32 */     putValue("MnemonicKey", Integer.valueOf(76));
/* 33 */     putValue("AcceleratorKey", KeyStroke.getKeyStroke(76, 128));
/*    */   }
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 38 */     FileSaver fs = new FileSaver();
/* 39 */     File loadFile = fs.showOpenDialog(null, new FileNameExtensionFilter("ms Markingset", new String[] { "ms" }));
/* 40 */     if (loadFile != null) {
/* 41 */       boolean b = this.director.sendMessage(13, this, loadFile);
/* 42 */       if (!b) JOptionPane.showMessageDialog(null, "Could not load markingset check if the correct net was loaded!"); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/actions/LoadMarkingsAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */