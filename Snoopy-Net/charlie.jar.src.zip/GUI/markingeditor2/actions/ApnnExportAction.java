/*    */ package GUI.markingeditor2.actions;
/*    */ 
/*    */ import GUI.io.FileSaver;
/*    */ import GUI.markingeditor2.IMarkingDirector;
/*    */ import GUI.markingeditor2.MarkingComboBoxModel;
/*    */ import GUI.markingeditor2.MarkingEditor;
/*    */ import java.awt.LayoutManager;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.File;
/*    */ import java.net.URL;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.ComboBoxModel;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JComboBox;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.KeyStroke;
/*    */ import layout.TableLayout;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApnnExportAction
/*    */   extends AbstractAction
/*    */ {
/*    */   private static final long serialVersionUID = 7039456438254954379L;
/* 31 */   IMarkingDirector director = null;
/* 32 */   ComboBoxModel comboBoxModel = null;
/*    */   public ApnnExportAction(IMarkingDirector director, ComboBoxModel comboBoxModel) {
/* 34 */     this.director = director;
/* 35 */     this.comboBoxModel = comboBoxModel;
/*    */     
/* 37 */     putValue("Name", "export as apnn");
/* 38 */     putValue("ShortDescription", "saves the actual net as apnn file");
/* 39 */     putValue("MnemonicKey", Integer.valueOf(69));
/* 40 */     putValue("AcceleratorKey", KeyStroke.getKeyStroke(69, 128));
/* 41 */     URL url = ClassLoader.getSystemResource("resources/export24.gif");
/* 42 */     if (url != null)
/* 43 */       putValue("SmallIcon", new ImageIcon(url)); 
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 47 */     final JFrame f = new JFrame("apnn export");
/* 48 */     JPanel p = new JPanel();
/* 49 */     double[][] size = { { 5.0D, 300.0D, 5.0D }, { 5.0D, 25.0D, 25.0D, 25.0D, 5.0D } };
/* 50 */     TableLayout layout = new TableLayout(size);
/* 51 */     p.setLayout((LayoutManager)layout);
/* 52 */     p.add(new JLabel("choose marking to export"), "1,1");
/* 53 */     JComboBox comboBox = new JComboBox();
/* 54 */     MarkingComboBoxModel cm = ((MarkingEditor)this.director).markingComboModel;
/* 55 */     comboBox.setModel((ComboBoxModel)cm);
/* 56 */     cm.removeListDataListener(comboBox);
/*    */     
/* 58 */     ((MarkingComboBoxModel)this.comboBoxModel).update();
/* 59 */     p.add(comboBox, "1,2");
/* 60 */     p.add(new JButton(new AbstractAction()
/*    */           {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */             
/*    */             public void actionPerformed(ActionEvent e)
/*    */             {
/* 70 */               FileSaver fs = new FileSaver();
/* 71 */               File apnnFile = fs.showSaveDialog(null, "Overwrite this file?", "apnn");
/* 72 */               if (apnnFile != null)
/* 73 */                 f.setVisible(false); 
/* 74 */               f.dispose();
/* 75 */               ApnnExportAction.this.director.sendMessage(8, this, apnnFile);
/*    */             }
/*    */           }), "1,3");
/*    */     
/* 79 */     f.setContentPane(p);
/* 80 */     f.pack();
/* 81 */     f.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/actions/ApnnExportAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */