/*    */ package GUI.markingeditor2.actions;
/*    */ 
/*    */ import GUI.markingeditor2.IMarkingDirector;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.JOptionPane;
/*    */ import javax.swing.KeyStroke;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeleteMarkingAction
/*    */   extends AbstractAction
/*    */ {
/* 16 */   private IMarkingDirector director = null;
/*    */   public DeleteMarkingAction(IMarkingDirector director) {
/* 18 */     this.director = director;
/* 19 */     putValue("Name", "delete");
/* 20 */     putValue("ShortDescription", "delete actual marking");
/* 21 */     putValue("MnemonicKey", Integer.valueOf(68));
/* 22 */     putValue("AcceleratorKey", KeyStroke.getKeyStroke(68, 128));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 44 */     if (!this.director.sendMessage(3, this, null))
/*    */     {
/*    */ 
/*    */       
/* 48 */       JOptionPane.showMessageDialog(null, "<html><p>The initial marking of the net (m0) can't be removed !</p></html>");
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/actions/DeleteMarkingAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */