/*    */ package GUI.markingeditor2.actions;
/*    */ 
/*    */ import GUI.markingeditor2.IMarkingDirector;
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.JOptionPane;
/*    */ import javax.swing.KeyStroke;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyMarkingAction
/*    */   extends AbstractAction
/*    */ {
/* 16 */   private IMarkingDirector director = null;
/*    */   
/*    */   public CopyMarkingAction(IMarkingDirector director) {
/* 19 */     this.director = director;
/* 20 */     putValue("Name", "copy");
/* 21 */     putValue("ShortDescription", "copy actual marking");
/* 22 */     putValue("MnemonicKey", Integer.valueOf(67));
/* 23 */     putValue("AcceleratorKey", KeyStroke.getKeyStroke(67, 128));
/*    */   }
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 28 */     String newName = JOptionPane.showInputDialog(null, "Enter a description or name for the new marking:", "new markings name", 3);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 34 */     if (newName != null) {
/* 35 */       boolean b = this.director.sendMessage(2, this, newName);
/* 36 */       if (!b) JOptionPane.showMessageDialog(null, "<html>Could not create Marking!<br>Name is already used.</html>"); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/actions/CopyMarkingAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */