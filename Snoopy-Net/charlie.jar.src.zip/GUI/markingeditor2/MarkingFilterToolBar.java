/*     */ package GUI.markingeditor2;
/*     */ 
/*     */ import GUI.markingeditor2.filter.SimpleFilter;
/*     */ import GUI.util.JComboBoxDelete;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.JToolBar;
/*     */ 
/*     */ 
/*     */ public class MarkingFilterToolBar
/*     */   extends JToolBar
/*     */   implements ActionListener
/*     */ {
/*  17 */   private JComboBox filterBox = null;
/*     */   
/*  19 */   private IMarkingDirector director = null;
/*  20 */   private JCheckBox filterPlaces = null;
/*  21 */   private JCheckBox filterTokenCheck = null;
/*  22 */   private JComboBox equalityBox = null;
/*  23 */   private JTextField tokenValue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkingFilterToolBar(IMarkingDirector director) {
/*  31 */     super("Marking Filter Toolbar", 0);
/*  32 */     this.director = director;
/*     */     
/*  34 */     this.filterBox = (JComboBox)new JComboBoxDelete("Insert a regular expression as filter.", true, null);
/*  35 */     this.filterBox.setActionCommand("filter");
/*  36 */     this.filterBox.addActionListener(this);
/*     */ 
/*     */     
/*  39 */     this.filterPlaces = new JCheckBox("filter place names");
/*  40 */     this.filterPlaces.setOpaque(true);
/*  41 */     this.filterPlaces.setActionCommand("filterCheck");
/*  42 */     this.filterPlaces.addActionListener(this);
/*     */     
/*  44 */     this.filterTokenCheck = new JCheckBox("filter token count");
/*  45 */     this.filterTokenCheck.setActionCommand("filterTokenCheck");
/*  46 */     this.filterTokenCheck.setOpaque(true);
/*  47 */     this.filterTokenCheck.addActionListener(this);
/*  48 */     String[] filterStrings = { "<", "<=", "=", ">", ">=", "!=" };
/*     */ 
/*     */     
/*  51 */     this.equalityBox = new JComboBox<>(filterStrings);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  58 */     this.equalityBox.addActionListener(this);
/*  59 */     this.equalityBox.setActionCommand("equalityBox");
/*     */     
/*  61 */     this.tokenValue = new JTextField(20);
/*  62 */     this.tokenValue.addActionListener(this);
/*  63 */     this.tokenValue.setActionCommand("tokenValue");
/*     */     
/*  65 */     add(this.filterPlaces);
/*  66 */     add(this.filterBox);
/*  67 */     addSeparator();
/*  68 */     add(this.filterTokenCheck);
/*  69 */     addSeparator();
/*  70 */     add(this.equalityBox);
/*  71 */     add(this.tokenValue);
/*  72 */     addSeparator();
/*  73 */     enable(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void enable(boolean value) {
/*  79 */     this.filterBox.setEnabled(value);
/*  80 */     this.filterPlaces.setEnabled(value);
/*  81 */     this.filterTokenCheck.setEnabled(value);
/*  82 */     this.equalityBox.setEnabled(value);
/*  83 */     this.tokenValue.setEnabled(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/*  90 */     String cmd = e.getActionCommand();
/*  91 */     if (cmd.equals("filter")) {
/*     */ 
/*     */ 
/*     */       
/*  95 */       this.filterPlaces.setSelected(true);
/*  96 */       this.filterTokenCheck.setSelected(false);
/*  97 */       SimpleFilter filter = new SimpleFilter(0, (String)this.filterBox.getSelectedItem());
/*  98 */       this.director.sendMessage(9, this, filter);
/*     */     }
/* 100 */     else if (cmd.equals("comboBoxEdited")) {
/*     */       
/* 102 */       String newItem = (String)this.filterBox.getSelectedItem();
/* 103 */       int i = 0;
/* 104 */       SimpleFilter filter = new SimpleFilter(0, newItem);
/* 105 */       for (i = 0; i < this.filterBox.getItemCount(); i++) {
/*     */         
/* 107 */         if (newItem.equals(this.filterBox.getItemAt(i))) {
/* 108 */           this.filterBox.setSelectedIndex(i);
/*     */           
/* 110 */           this.filterPlaces.setSelected(true);
/* 111 */           this.director.sendMessage(9, this, filter);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/* 116 */       this.filterBox.addItem(newItem);
/* 117 */       this.filterBox.setSelectedItem(newItem);
/* 118 */       this.director.sendMessage(9, this, filter);
/*     */     }
/* 120 */     else if (cmd.equals("filterCheck")) {
/* 121 */       if (this.filterPlaces.isSelected()) {
/* 122 */         this.filterTokenCheck.setSelected(false);
/* 123 */         String newItem = (String)this.filterBox.getSelectedItem();
/* 124 */         if (newItem != null) {
/* 125 */           this.director.sendMessage(9, this, new SimpleFilter(0, newItem));
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 130 */         this.director.sendMessage(9, this, new SimpleFilter(-1, "places"));
/*     */       }
/*     */     
/*     */     }
/* 134 */     else if (cmd.equals("filterTokenCheck")) {
/* 135 */       if (this.filterTokenCheck.isSelected()) {
/* 136 */         this.filterPlaces.setSelected(false);
/* 137 */         String function = (String)this.equalityBox.getSelectedItem();
/*     */         
/* 139 */         if (function != null && !this.tokenValue.getText().equals(""))
/*     */         {
/* 141 */           this.director.sendMessage(9, this, new SimpleFilter(SimpleFilter.getFilterType(function), this.tokenValue.getText()));
/*     */         }
/*     */       } else {
/*     */         
/* 145 */         this.director.sendMessage(9, this, new SimpleFilter(-1, ""));
/*     */       }
/*     */     
/*     */     }
/* 149 */     else if (cmd.equals("tokenValue")) {
/*     */ 
/*     */       
/* 152 */       this.filterTokenCheck.setSelected(true);
/* 153 */       this.filterPlaces.setSelected(false);
/* 154 */       String function = (String)this.equalityBox.getSelectedItem();
/* 155 */       if (function != null && !this.tokenValue.getText().equals(""))
/*     */       {
/* 157 */         this.director.sendMessage(9, this, new SimpleFilter(SimpleFilter.getFilterType(function), this.tokenValue.getText()));
/*     */ 
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 163 */     else if (cmd.equals("equalityBox")) {
/* 164 */       if (!this.tokenValue.getText().equals("")) {
/* 165 */         this.filterTokenCheck.setSelected(true);
/* 166 */         this.filterPlaces.setSelected(false);
/* 167 */         String function = (String)this.equalityBox.getSelectedItem();
/*     */         
/* 169 */         this.director.sendMessage(9, this, new SimpleFilter(SimpleFilter.getFilterType(function), this.tokenValue.getText()));
/*     */       } 
/*     */     } else {
/*     */       
/* 173 */       System.out.printf("MarkingToolBar: Unknown ActionCommand %s \n", new Object[] { cmd });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/MarkingFilterToolBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */