/*    */ package GUI.markingeditor2.table;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.table.DefaultTableCellRenderer;
/*    */ 
/*    */ public class ColoredTableCellRenderer
/*    */   extends DefaultTableCellRenderer
/*    */ {
/* 11 */   int selectedColumn = 1;
/*    */ 
/*    */   
/*    */   public void setSelectedColumn(int index) {
/* 15 */     this.selectedColumn = index;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focused, int row, int column) {
/* 21 */     setEnabled((table == null || table.isEnabled()));
/*    */     
/* 23 */     if (column == this.selectedColumn) {
/* 24 */       setBackground(Color.green);
/*    */     } else {
/* 26 */       setBackground((Color)null);
/*    */     } 
/* 28 */     super.getTableCellRendererComponent(table, value, selected, focused, row, column);
/*    */     
/* 30 */     return this;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/table/ColoredTableCellRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */