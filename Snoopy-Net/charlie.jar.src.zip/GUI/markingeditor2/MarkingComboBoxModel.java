/*     */ package GUI.markingeditor2;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ 
/*     */ public class MarkingComboBoxModel
/*     */   extends DefaultComboBoxModel
/*     */ {
/*     */   Vector<Marking> markings;
/*  11 */   Marking selectedMarking = null;
/*     */   
/*     */   public MarkingComboBoxModel(Vector<Marking> markingVector) {
/*  14 */     this.markings = markingVector;
/*     */   }
/*     */   
/*     */   public void addMarking(Marking m) {
/*  18 */     this.markings.add(m);
/*     */     
/*  20 */     fireContentsChanged(this, 0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarking(int _index, Marking _m) {
/*  30 */     this.markings.set(_index, _m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Marking getMarking(int _index) {
/*  41 */     return this.markings.get(_index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Marking> getMarkingList() {
/*  50 */     return this.markings;
/*     */   }
/*     */   
/*     */   public void replaceLastMarking(Marking m) {
/*  54 */     this.markings.set(getSize() - 1, m);
/*  55 */     fireContentsChanged(this, this.markings.size() - 1, this.markings.size() - 1);
/*     */   }
/*     */   
/*     */   public void deleteMarking(int index) {
/*  59 */     if (index < this.markings.size() && index > 0) {
/*  60 */       this.markings.removeElementAt(index);
/*  61 */       this.selectedMarking = this.markings.get(0);
/*  62 */       fireContentsChanged(this, index, index);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteMarking(String name) {
/*  68 */     for (int i = 0; i < this.markings.size(); i++) {
/*  69 */       Marking m = this.markings.get(i);
/*  70 */       if (m.toString().equals(name)) {
/*  71 */         this.markings.removeElementAt(i);
/*  72 */         this.selectedMarking = this.markings.get(0);
/*  73 */         fireContentsChanged(this, i, i);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void deleteMarking(Marking m) {
/*  80 */     this.markings.removeElement(m);
/*  81 */     this.selectedMarking = this.markings.get(0);
/*  82 */     fireContentsChanged(this, 0, this.markings.size() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getElementAt(int index) {
/*  87 */     if (index < this.markings.size()) {
/*  88 */       return this.markings.get(index);
/*     */     }
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean existsMarking(String name) {
/*  95 */     int i = getMarkingIndex(name);
/*  96 */     if (i != -1) {
/*  97 */       return true;
/*     */     }
/*  99 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMarkingIndex(String name) {
/* 104 */     for (int i = 0; i < this.markings.size(); i++) {
/* 105 */       Marking temp = this.markings.get(i);
/* 106 */       if (temp.getName().equals(name)) {
/* 107 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 111 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIndexOf(Object anObject) {
/* 116 */     int i = 0;
/* 117 */     while (i < this.markings.size()) {
/* 118 */       if (this.markings.get(i) == (Marking)anObject) {
/* 119 */         return i;
/*     */       }
/* 121 */       i++;
/*     */     } 
/*     */     
/* 124 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addElement(Object anObject) {
/* 129 */     addMarking((Marking)anObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getSelectedItem() {
/* 134 */     return this.selectedMarking;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 139 */     return this.markings.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAllElements() {
/* 144 */     this.markings.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeElementAt(int index) {
/* 149 */     deleteMarking(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeElement(Object anObject) {
/* 154 */     Marking m = (Marking)anObject;
/* 155 */     int i = 0;
/* 156 */     while (i < this.markings.size()) {
/* 157 */       if (this.markings.get(i) == m) {
/* 158 */         this.markings.removeElementAt(i); continue;
/*     */       } 
/* 160 */       i++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectedItem(Object anObject) {
/* 167 */     this.selectedMarking = (Marking)anObject;
/* 168 */     fireContentsChanged(this, 0, this.markings.size() - 1);
/*     */   }
/*     */   
/*     */   public void update() {
/* 172 */     if (this.selectedMarking == null && this.markings.size() > 0) {
/* 173 */       this.selectedMarking = this.markings.get(0);
/*     */     }
/*     */     
/* 176 */     fireContentsChanged(this, 0, this.markings.size() - 1);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/MarkingComboBoxModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */