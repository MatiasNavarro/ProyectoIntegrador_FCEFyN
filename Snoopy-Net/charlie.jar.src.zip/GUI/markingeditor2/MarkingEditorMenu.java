/*     */ package GUI.markingeditor2;
/*     */ 
/*     */ import GUI.markingeditor2.actions.ApnnExportAction;
/*     */ import GUI.markingeditor2.actions.CloseWindowAction;
/*     */ import GUI.markingeditor2.actions.CopyMarkingAction;
/*     */ import GUI.markingeditor2.actions.DeleteMarkingAction;
/*     */ import GUI.markingeditor2.actions.LoadMarkingsAction;
/*     */ import GUI.markingeditor2.actions.NewMarkingAction;
/*     */ import GUI.markingeditor2.actions.SaveMarkingsAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkingEditorMenu
/*     */   extends JMenuBar
/*     */ {
/*     */   private JMenu fileMenu;
/*     */   private JMenuItem fileOpen;
/*     */   private JMenuItem fileSaveApnn;
/*     */   private JMenuItem closeWindow;
/*     */   private JMenu exportMenu;
/*     */   private JMenuItem exportMarking;
/*     */   private JMenuItem exportAllMarkings;
/*     */   private IMarkingDirector director;
/*     */   private JMenu operationsMenu;
/*     */   private JMenuItem newMarking;
/*     */   private JMenuItem deleteMarking;
/*     */   private JMenuItem copyMarking;
/*     */   private JMenuItem setMarking;
/*     */   private JMenuItem loadMarkings;
/*     */   private JMenuItem saveMarkings;
/*     */   private JMenu aboutMenu;
/*     */   private JMenuItem showAbout;
/*  44 */   private String lastDir = System.getProperty("user.dir");
/*     */   private MarkingComboBoxModel comboBoxModel;
/*     */   
/*     */   public MarkingEditorMenu(IMarkingDirector director, MarkingComboBoxModel comboBoxModel) {
/*  48 */     this.director = director;
/*  49 */     this.comboBoxModel = comboBoxModel;
/*     */   }
/*     */   
/*     */   public JMenuBar createMenu() {
/*  53 */     add(createFileMenu());
/*  54 */     this.operationsMenu = createOperationsMenu();
/*  55 */     add(this.operationsMenu);
/*     */     
/*  57 */     enable(false);
/*  58 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void enable(boolean value) {
/*  63 */     this.loadMarkings.setEnabled(value);
/*  64 */     this.saveMarkings.setEnabled(value);
/*  65 */     this.exportMenu.setEnabled(value);
/*  66 */     this.operationsMenu.setEnabled(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JMenu createFileMenu() {
/*  72 */     JMenu fileMenu = new JMenu("File");
/*  73 */     fileMenu.setMnemonic(70);
/*     */     
/*  75 */     this.loadMarkings = new JMenuItem((Action)new LoadMarkingsAction(this.director, false));
/*  76 */     fileMenu.add(this.loadMarkings);
/*  77 */     this.saveMarkings = new JMenuItem((Action)new SaveMarkingsAction(this.director, false));
/*  78 */     fileMenu.add(this.saveMarkings);
/*  79 */     this.exportMenu = createExportMenu();
/*  80 */     fileMenu.add(this.exportMenu);
/*     */     
/*  82 */     this.closeWindow = new JMenuItem((Action)new CloseWindowAction(this.director));
/*  83 */     fileMenu.add(this.closeWindow);
/*  84 */     return fileMenu;
/*     */   }
/*     */   
/*     */   private JMenu createOperationsMenu() {
/*  88 */     this.newMarking = new JMenuItem((Action)new NewMarkingAction(this.director));
/*  89 */     this.deleteMarking = new JMenuItem((Action)new DeleteMarkingAction(this.director));
/*  90 */     this.copyMarking = new JMenuItem((Action)new CopyMarkingAction(this.director));
/*  91 */     JMenu operations = new JMenu("operations");
/*  92 */     operations.setMnemonic(79);
/*  93 */     operations.add(this.newMarking);
/*  94 */     operations.add(this.deleteMarking);
/*  95 */     operations.add(this.copyMarking);
/*  96 */     return operations;
/*     */   }
/*     */   
/*     */   private JMenu createAboutMenu() {
/* 100 */     JMenu aboutMenu = new JMenu("about");
/* 101 */     JMenuItem aboutItem = new JMenuItem("about");
/* 102 */     aboutItem.setAccelerator(KeyStroke.getKeyStroke("F1"));
/* 103 */     aboutMenu.add(aboutItem);
/* 104 */     return aboutMenu;
/*     */   }
/*     */ 
/*     */   
/*     */   private JMenu createExportMenu() {
/* 109 */     JMenu exportMenu = new JMenu("export");
/*     */     
/* 111 */     JMenuItem apnnSave = new JMenuItem("apnn export");
/* 112 */     apnnSave.setAction((Action)new ApnnExportAction(this.director, this.comboBoxModel));
/* 113 */     exportMenu.add(apnnSave);
/* 114 */     return exportMenu;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/MarkingEditorMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */