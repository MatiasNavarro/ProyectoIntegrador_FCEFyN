/*     */ package GUI.markingeditor2;
/*     */ 
/*     */ import GUI.IDirector;
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.io.XMLReader;
/*     */ import GUI.io.XMLWriter;
/*     */ import GUI.markingeditor2.filter.SimpleFilter;
/*     */ import charlie.pn.MultipleMarkingsPlaceTransitionNet;
/*     */ import charlie.pn.Place;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import charlie.pn.export.APNNExport;
/*     */ import charlie.util.DirectorManager;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.File;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.event.ListDataListener;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class MarkingEditor
/*     */   implements IMarkingDirector
/*     */ {
/*  33 */   private static final Log LOG = LogFactory.getLog(MarkingEditor.class);
/*     */   
/*  35 */   private IDirector director = null;
/*  36 */   private PlaceTransitionNet pn = null;
/*     */   
/*     */   private MarkingEditorGui markingEditorGui;
/*  39 */   private String titleString = "marking editor v1.0 -";
/*  40 */   private MarkingTable markingTable = null;
/*  41 */   private MyTableModel markingTableModel = null;
/*  42 */   private MarkingToolBar toolBar = null;
/*  43 */   private MarkingEditorMenu markingMenu = null;
/*  44 */   public MarkingComboBoxModel markingComboModel = null;
/*  45 */   private MarkingEditorDialog externalDialog = null;
/*  46 */   private SimpleFilter filter = null;
/*  47 */   private File actualFile = null;
/*     */   
/*     */   public MarkingEditor(PlaceTransitionNet pn, IDirector director) {
/*  50 */     this.director = director;
/*  51 */     this.pn = pn;
/*     */     
/*  53 */     registerDirector();
/*     */   }
/*     */   
/*     */   public MarkingEditor(PlaceTransitionNet pn) {
/*  57 */     this.pn = pn;
/*     */     
/*  59 */     registerDirector();
/*     */   }
/*     */   
/*     */   public void registerDirector() {
/*  63 */     DirectorManager.registerDirector(this);
/*     */   }
/*     */   
/*     */   public void alignToParentWindow(JFrame parent) {
/*  67 */     this.markingEditorGui.alignToParentWindow(parent);
/*     */   }
/*     */   
/*     */   public void saveSession(File file) {
/*  71 */     sendMessage(12, this, file);
/*     */   }
/*     */   
/*     */   public void loadSession(File file) {
/*  75 */     sendMessage(13, this, file);
/*     */   }
/*     */   
/*     */   public Hashtable<String, String> getActualFiles() {
/*  79 */     if (this.actualFile != null) {
/*  80 */       Hashtable<String, String> table = new Hashtable<>();
/*  81 */       table.put("markingfile", this.actualFile.getAbsolutePath());
/*  82 */       return table;
/*     */     } 
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setActualFiles(Hashtable<String, String> table) {
/*  89 */     if (table.contains("markingfile")) {
/*  90 */       File temp = new File(table.get("markingfile"));
/*  91 */       if (temp.exists()) {
/*  92 */         sendMessage(13, this, temp);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() {
/* 116 */     Vector<Marking> markingVector = new Vector<>();
/*     */     
/* 118 */     this.markingComboModel = new MarkingComboBoxModel(markingVector);
/*     */     
/* 120 */     this.markingEditorGui = new MarkingEditorGui(this);
/* 121 */     this.markingEditorGui.setModal(true);
/*     */ 
/*     */     
/* 124 */     this.toolBar = new MarkingToolBar(this);
/* 125 */     this.toolBar.setComboModel("marking", this.markingComboModel);
/*     */ 
/*     */     
/* 128 */     this.markingEditorGui.setToolBar(this.toolBar);
/*     */ 
/*     */     
/* 131 */     this.markingTable = new MarkingTable(this);
/* 132 */     this.markingEditorGui.setTitle(this.titleString);
/* 133 */     if (this.pn != null) {
/* 134 */       this.markingTableModel = new MyTableModel(this.pn, markingVector);
/* 135 */       this.markingTable.setModel(this.markingTableModel);
/* 136 */       this.markingTable.setSelectedColumn(1);
/* 137 */       this.markingComboModel.update();
/* 138 */       this.markingEditorGui.setTitle(this.titleString + this.pn.getName());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     this.markingEditorGui.setTable(this.markingTable);
/* 145 */     this.markingEditorGui.addWindowListener(new WindowAdapter()
/*     */         {
/*     */           public void windowClosing(WindowEvent e)
/*     */           {
/* 149 */             MarkingEditor.this.sendMessage(14, null, MarkingEditor.this.getActualMarkingName());
/* 150 */             MarkingEditor.this.markingEditorGui.setVisible(false);
/* 151 */             MarkingEditor.this.markingEditorGui.dispose();
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 157 */     this.markingMenu = new MarkingEditorMenu(this, this.markingComboModel);
/*     */     
/* 159 */     this.markingEditorGui.setJMenuBar(this.markingMenu.createMenu());
/* 160 */     this.markingEditorGui.setDefaultCloseOperation(1);
/*     */     
/* 162 */     this.markingEditorGui.pack(); } public boolean sendMessage(int messageType, Object source, Object object) { Marking m; Marking selectedMarking; MyTableModel model;
/*     */     int markingCount;
/*     */     int i;
/*     */     File apnnFile;
/*     */     String fileName;
/*     */     int answ;
/* 168 */     switch (messageType) {
/*     */       case 13:
/* 170 */         if (LOG.isDebugEnabled()) {
/* 171 */           LOG.debug("loading marking: " + ((File)object).getAbsolutePath());
/*     */         }
/*     */         
/* 174 */         if (loadMarkings((File)object)) {
/* 175 */           this.actualFile = (File)object;
/* 176 */           return true;
/*     */         } 
/*     */         break;
/*     */       case 12:
/* 180 */         if (LOG.isDebugEnabled()) {
/* 181 */           LOG.debug("saving marking: " + ((File)object).getAbsolutePath());
/*     */         }
/*     */         
/* 184 */         storeMarkings((File)object);
/* 185 */         this.actualFile = (File)object;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 11:
/* 190 */         LOG.error("SHOW_GUI no break! Please report this message.");
/*     */       case 1:
/* 192 */         if (LOG.isDebugEnabled()) {
/* 193 */           LOG.debug("new marking: " + object);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 200 */         if (this.pn != null) {
/* 201 */           String name = (String)object;
/* 202 */           if (name.equals("m0")) {
/* 203 */             LOG.error("Marking m0 cannot be added to the net!");
/* 204 */             return false;
/*     */           } 
/* 206 */           if (!this.markingComboModel.existsMarking(name)) {
/* 207 */             Marking marking = new Marking(name, this.pn.getPlaces());
/* 208 */             this.markingComboModel.addMarking(marking);
/* 209 */             this.markingTableModel.update();
/* 210 */             this.markingTable.filterPlaces("");
/* 211 */             return true;
/*     */           } 
/* 213 */           return false;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 3:
/* 218 */         if (LOG.isDebugEnabled()) {
/* 219 */           LOG.debug("delete marking: " + object);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 226 */         if (this.pn != null) {
/* 227 */           Marking marking = (Marking)this.markingComboModel.getSelectedItem();
/* 228 */           int index = this.markingTableModel.findColumn(marking);
/* 229 */           if (index == 0) {
/*     */             break;
/*     */           }
/* 232 */           int n = JOptionPane.showConfirmDialog(null, "<html><p>Do you really want to delete this marking?</p><p>" + marking
/*     */               
/* 234 */               .toString() + "</p></html>", "Delete actual selected marking", 0);
/*     */ 
/*     */           
/* 237 */           if (n == 0) {
/* 238 */             this.markingComboModel.deleteMarking(marking);
/* 239 */             this.markingTable.selectMarking("m0");
/* 240 */             this.markingTableModel.update();
/*     */           } 
/* 242 */           return true;
/*     */         } 
/*     */         break;
/*     */       case 2:
/* 246 */         if (LOG.isDebugEnabled()) {
/* 247 */           LOG.debug("copy marking: " + object);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 254 */         if (this.pn != null) {
/* 255 */           String ma = (String)object;
/* 256 */           Marking marking = (Marking)this.markingComboModel.getSelectedItem();
/* 257 */           if (!this.markingComboModel.existsMarking(ma)) {
/* 258 */             Marking newMarking = Marking.copyMarking(marking, ma);
/* 259 */             if (newMarking != null) {
/*     */               
/* 261 */               this.markingComboModel.addMarking(newMarking);
/* 262 */               this.markingTableModel.update();
/* 263 */               return true;
/*     */             } 
/* 265 */             return false;
/*     */           } 
/*     */           
/* 268 */           return false;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 4:
/* 273 */         if (LOG.isDebugEnabled()) {
/* 274 */           LOG.debug("switch marking: " + object);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 281 */         selectedMarking = (Marking)this.markingComboModel.getSelectedItem();
/* 282 */         if (this.markingComboModel.getSize() == 1) {
/* 283 */           return true;
/*     */         }
/* 285 */         m = null;
/* 286 */         if (this.pn != null) {
/*     */ 
/*     */ 
/*     */           
/* 290 */           if (source instanceof MarkingTable) {
/*     */ 
/*     */             
/* 293 */             int index = ((Integer)object).intValue() - 1;
/* 294 */             m = this.markingTableModel.getMarking(index);
/* 295 */             if (m != null && !m.getName().equals(selectedMarking.getName())) {
/* 296 */               this.markingTable.selectMarking(m);
/* 297 */               this.markingComboModel.setSelectedItem(m);
/*     */             } else {
/* 299 */               LOG.warn(String.format("markingTableModel returned no marking on index %d\n", new Object[] { Integer.valueOf(index) }));
/* 300 */               return false;
/*     */             } 
/* 302 */           } else if (source instanceof javax.swing.JComboBox) {
/* 303 */             m = (Marking)this.markingComboModel.getSelectedItem();
/* 304 */             int selIndex = this.markingTable.getSelectedColumn();
/* 305 */             selectedMarking = this.markingTableModel.getMarking(selIndex - 1);
/* 306 */             if (!m.getName().equals(selectedMarking.getName())) {
/* 307 */               this.markingTable.selectMarking(m);
/*     */             }
/*     */           } else {
/*     */             
/* 311 */             LOG.warn("MarkingEditor:SWITCH_MARKING by unknown source.");
/*     */           } 
/*     */           
/* 314 */           if (m != null) {
/*     */             
/* 316 */             this.pn.setM0(m.getMarkingVector());
/* 317 */             if (this.externalDialog != null) {
/* 318 */               this.externalDialog.setMarkingName(m.getName());
/*     */             }
/*     */             
/* 321 */             if (this.filter != null) {
/* 322 */               sendMessage(9, this, this.filter);
/*     */             }
/*     */             
/* 325 */             if (!m.getName().equals(selectedMarking.getName())) {
/* 326 */               this.director.sendMessage(0, this, this.pn);
/*     */             }
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       case 14:
/* 332 */         if (LOG.isDebugEnabled()) {
/* 333 */           LOG.debug("update marking: " + object);
/*     */         }
/*     */         
/* 336 */         m = null;
/* 337 */         if (this.pn != null) {
/* 338 */           m = (Marking)this.markingComboModel.getSelectedItem();
/*     */           
/* 340 */           if (m != null) {
/*     */             
/* 342 */             this.pn.setM0(m.getMarkingVector());
/* 343 */             if (this.externalDialog != null) {
/* 344 */               this.externalDialog.setMarkingName(m.getName());
/*     */             }
/*     */             
/* 347 */             if (this.filter != null) {
/* 348 */               sendMessage(9, this, this.filter);
/*     */             }
/*     */             
/* 351 */             this.director.sendMessage(0, this, this.pn);
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       case 15:
/* 356 */         if (LOG.isDebugEnabled()) {
/* 357 */           LOG.debug("append marking: " + object);
/*     */         }
/*     */         
/* 360 */         if (this.pn != null) {
/* 361 */           m = (Marking)object;
/* 362 */           if (m != null) {
/* 363 */             this.markingComboModel.addMarking(m);
/* 364 */             this.markingTableModel.update();
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 6:
/* 370 */         if (LOG.isDebugEnabled()) {
/* 371 */           LOG.debug("net switched: " + object);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 376 */         model = (MyTableModel)object;
/* 377 */         this.markingComboModel.removeAllElements();
/*     */         
/* 379 */         markingCount = model.getColumnCount();
/*     */ 
/*     */         
/* 382 */         for (i = 1; i < markingCount; i++) {
/* 383 */           String columnName = model.getColumnName(i);
/* 384 */           this.markingComboModel.addMarking(model.getMarking(i));
/*     */         } 
/* 386 */         this.markingTable.setModel(model);
/*     */         break;
/*     */       case 7:
/* 389 */         if (LOG.isDebugEnabled()) {
/* 390 */           LOG.debug("exit called");
/*     */         }
/*     */         
/* 393 */         this.markingEditorGui.setVisible(false);
/* 394 */         this.markingEditorGui.dispose();
/*     */         break;
/*     */       case 8:
/* 397 */         if (LOG.isDebugEnabled()) {
/* 398 */           LOG.debug("apnn export: " + ((File)object).getAbsolutePath());
/*     */         }
/*     */         
/* 401 */         if (this.pn == null) {
/*     */           break;
/*     */         }
/* 404 */         apnnFile = (File)object;
/* 405 */         fileName = apnnFile.getName();
/*     */         
/* 407 */         if (!fileName.endsWith(".apnn")) {
/* 408 */           apnnFile = new File(fileName + ".apnn");
/*     */         }
/*     */         
/*     */         try {
/* 412 */           APNNExport ex = new APNNExport(this.pn, apnnFile);
/* 413 */           ex.doExport();
/* 414 */           return true;
/* 415 */         } catch (Exception e) {
/* 416 */           LOG.error(e.getMessage(), e);
/*     */           break;
/*     */         } 
/*     */       
/*     */       case 5:
/* 421 */         if (LOG.isDebugEnabled()) {
/* 422 */           LOG.debug("net loaded: " + ((File)object).getAbsolutePath());
/*     */         }
/*     */ 
/*     */         
/* 426 */         answ = JOptionPane.showConfirmDialog(null, "<html><p>Loading new Net.</p><p> All newly added markings will get lost !</p><p> Do you want to save your work ?</p></html>", "Question", 0);
/* 427 */         if (answ == 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 433 */         loadNet((File)object);
/* 434 */         this.markingMenu.enable(true);
/* 435 */         this.toolBar.enable(true);
/* 436 */         if (this.externalDialog != null) {
/* 437 */           this.externalDialog.enableControls(true);
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case 9:
/* 443 */         if (LOG.isDebugEnabled()) {
/* 444 */           LOG.debug("filter: " + object);
/*     */         }
/*     */         
/* 447 */         if (this.pn == null) {
/*     */           break;
/*     */         }
/* 450 */         this.filter = (SimpleFilter)object;
/* 451 */         if (this.filter.getType() == 0) {
/*     */           
/* 453 */           this.markingTable.filterPlaces(this.filter.getValue()); break;
/* 454 */         }  if (this.filter.getType() == -1) {
/* 455 */           if (this.filter.getValue().equals("places")) {
/* 456 */             this.markingTable.filterPlaces(""); break;
/* 457 */           }  if (this.filter.getValue().equals("")) {
/* 458 */             this.markingTable.filterToken(new SimpleFilter(-1, "0"));
/*     */             break;
/*     */           } 
/* 461 */           return false;
/*     */         } 
/*     */ 
/*     */         
/* 465 */         this.markingTable.filterToken(this.filter);
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 473 */     return false; }
/*     */ 
/*     */ 
/*     */   
/*     */   public String markingToText(int columns) {
/* 478 */     Marking m = (Marking)this.markingComboModel.getSelectedItem();
/* 479 */     List<Place> places = m.getPlaces();
/* 480 */     StringWriter sw = new StringWriter();
/* 481 */     PrintWriter pw = new PrintWriter(sw);
/* 482 */     int longestPlaceName = 0;
/* 483 */     for (int i = 0; i < places.size(); i++) {
/* 484 */       String name = ((Place)places.get(i)).getName();
/* 485 */       if (name.length() >= longestPlaceName) {
/* 486 */         longestPlaceName = name.length();
/*     */       }
/*     */     } 
/* 489 */     if (longestPlaceName < "placename".length()) {
/* 490 */       longestPlaceName = "placename".length();
/*     */     }
/* 492 */     int numberOfPlacesWithTokens = 0;
/* 493 */     int tempI = 0;
/* 494 */     for (tempI = 0; tempI < places.size(); tempI++) {
/* 495 */       if (m.getTokenCount(tempI).intValue() > 0) {
/* 496 */         numberOfPlacesWithTokens++;
/*     */       }
/*     */     } 
/*     */     
/* 500 */     int rowCount = numberOfPlacesWithTokens / 2 + numberOfPlacesWithTokens % 2;
/* 501 */     int div = numberOfPlacesWithTokens % 2;
/* 502 */     String[][] field = new String[rowCount][columns];
/* 503 */     String f = "%-" + Integer.toString(longestPlaceName) + "s : %5s ";
/* 504 */     int j = 0, k = 0; int n;
/* 505 */     for (n = 0; n < places.size(); n++) {
/* 506 */       if (m.getTokenCount(n).intValue() > 0) {
/* 507 */         field[k][j] = String.format(f, new Object[] { ((Place)places.get(n)).getName(), Integer.toString(m.getTokenCount(n).intValue()) });
/* 508 */         if (rowCount - k - 1 == 0) {
/* 509 */           if (columns - j - 1 == 0) {
/* 510 */             j = 0;
/*     */           } else {
/* 512 */             j++;
/*     */           } 
/* 514 */           k = 0;
/*     */         } else {
/* 516 */           k++;
/*     */         } 
/* 518 */         if (div > 0 && n + 1 == places.size())
/*     */         {
/* 520 */           field[k][j] = "";
/*     */         }
/*     */       } 
/*     */     } 
/* 524 */     j = 0;
/* 525 */     k = 0;
/*     */     
/* 527 */     for (n = 0; n < rowCount; n++) {
/* 528 */       if (n == 0) {
/* 529 */         pw.printf("markingName: %s\n", new Object[] { m.getName() });
/* 530 */         for (j = 0; j < columns; j++) {
/*     */           
/* 532 */           pw.printf(f, new Object[] { "placename", "token" });
/* 533 */           if (j != columns - 1) {
/* 534 */             pw.printf(" | ", new Object[0]);
/*     */           }
/*     */         } 
/* 537 */         pw.printf("\n", new Object[0]);
/*     */       } 
/*     */ 
/*     */       
/* 541 */       for (j = 0; j < columns; j++) {
/*     */         
/* 543 */         if (field[n][j] != null) {
/* 544 */           pw.printf("%s", new Object[] { field[n][j] });
/*     */         }
/* 546 */         if (j != columns - 1) {
/* 547 */           pw.printf(" | ", new Object[0]);
/*     */         }
/*     */       } 
/* 550 */       pw.printf("\n", new Object[0]);
/*     */     } 
/*     */     
/* 553 */     return sw.toString();
/*     */   }
/*     */   
/*     */   public Object externalMessage(int messageType, Object source, Object object) {
/*     */     PlaceTransitionNet newPN;
/* 558 */     switch (messageType) {
/*     */ 
/*     */       
/*     */       case 10:
/* 562 */         this.externalDialog = new MarkingEditorDialog(this, this.markingEditorGui, this.markingComboModel);
/* 563 */         if (this.pn != null) {
/* 564 */           this.externalDialog.setNetName("net name : " + this.pn.getName());
/*     */         } else {
/* 566 */           this.externalDialog.setNetName("net name : ");
/*     */         } 
/*     */         
/* 569 */         return this.externalDialog;
/*     */       
/*     */       case 5:
/* 572 */         newPN = (PlaceTransitionNet)object;
/*     */         
/* 574 */         reset((PlaceTransitionNet)object);
/*     */         
/* 576 */         if (newPN instanceof MultipleMarkingsPlaceTransitionNet) {
/* 577 */           MultipleMarkingsPlaceTransitionNet pn = (MultipleMarkingsPlaceTransitionNet)newPN;
/* 578 */           for (String markingName : pn.getMarkingNameList()) {
/* 579 */             Marking m = new Marking(markingName, pn.getPlaces());
/*     */ 
/*     */ 
/*     */             
/* 583 */             if (!"Main".equals(m.getName())) {
/* 584 */               int index = this.markingComboModel.getMarkingIndex(m.getName());
/* 585 */               if (index < 0) {
/*     */ 
/*     */                 
/* 588 */                 m.setTokenCount(pn.getMarking(markingName));
/*     */                 
/* 590 */                 this.markingComboModel.addMarking(m);
/* 591 */                 this.markingTableModel.update();
/*     */                 
/*     */                 continue;
/*     */               } 
/* 595 */               m.setTokenCount(pn.getMarking(markingName));
/*     */               
/* 597 */               this.markingComboModel.setMarking(index, m);
/* 598 */               this.markingTableModel.update();
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 604 */         return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 609 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadNet(File netFile) {
/* 614 */     reset(new PlaceTransitionNet(netFile.getName()));
/*     */   }
/*     */   
/*     */   public void reset(PlaceTransitionNet _pn) {
/* 618 */     DebugCounter.inc("reset marking editor\n");
/* 619 */     if (_pn == null) {
/* 620 */       if (this.markingEditorGui != null) {
/* 621 */         this.markingEditorGui.setVisible(false);
/*     */       }
/* 623 */       if (this.externalDialog != null) {
/* 624 */         this.externalDialog.enableControls(false);
/*     */       }
/*     */       return;
/*     */     } 
/* 628 */     DebugCounter.inc("pn.places.size() " + _pn.getPlaces().size());
/*     */ 
/*     */     
/* 631 */     if (this.pn == null || _pn == null || !_pn.getName().equals(this.pn.getName()) || _pn.places() != this.pn.places()) {
/* 632 */       Vector<Marking> markingVector = new Vector<>();
/* 633 */       for (ListDataListener listener : this.markingComboModel.getListDataListeners()) {
/* 634 */         this.markingComboModel.removeListDataListener(listener);
/*     */       }
/* 636 */       this.markingComboModel.removeAllElements();
/* 637 */       this.markingComboModel = new MarkingComboBoxModel(markingVector);
/* 638 */       this.toolBar.setComboModel("marking", this.markingComboModel);
/* 639 */       if (this.externalDialog != null) {
/* 640 */         this.externalDialog.setComboBoxModel(this.markingComboModel);
/* 641 */         this.externalDialog.enableControls(true);
/*     */       } 
/* 643 */       this.markingTableModel = new MyTableModel(_pn, markingVector);
/* 644 */       this.markingTable.setModel(this.markingTableModel);
/* 645 */       this.markingTable.setSelectedColumn(1);
/* 646 */       this.markingEditorGui.setTitle(this.titleString + _pn.getName());
/* 647 */       this.markingComboModel.update();
/* 648 */       this.markingMenu.enable(true);
/* 649 */       this.toolBar.enable(true);
/*     */     } 
/*     */     
/* 652 */     this.pn = _pn;
/*     */   }
/*     */   
/*     */   public boolean loadMarkings(File xmlFile) {
/* 656 */     if (this.pn == null) {
/* 657 */       return false;
/*     */     }
/* 659 */     reset(this.pn);
/* 660 */     Document document = XMLReader.readXmlFile(xmlFile);
/* 661 */     if (document == null) {
/* 662 */       return false;
/*     */     }
/*     */     
/* 665 */     NodeList nl = document.getElementsByTagName("markingset");
/* 666 */     if (nl.getLength() <= 0) {
/* 667 */       return false;
/*     */     }
/* 669 */     Element root = (Element)nl.item(0);
/* 670 */     String netName = root.getAttribute("netfile");
/*     */     
/* 672 */     List<Place> places = this.pn.getPlaces();
/* 673 */     if (this.pn.getName().equals(netName)) {
/* 674 */       NodeList markingList = root.getElementsByTagName("marking");
/*     */       
/* 676 */       for (int i = 0; i < markingList.getLength(); i++) {
/* 677 */         Element marking = (Element)markingList.item(i);
/* 678 */         String markingName = marking.getAttribute("name");
/*     */         
/* 680 */         if (!markingName.equals("m0")) {
/* 681 */           Marking newMarking = new Marking(markingName, places);
/* 682 */           NodeList placesList = marking.getElementsByTagName("place");
/* 683 */           if (placesList.getLength() != places.size()) {
/* 684 */             LOG.error("the number of places in your xml file is different to the number in the loaded petri net!");
/* 685 */             return false;
/*     */           } 
/* 687 */           for (int j = 0; j < placesList.getLength(); j++) {
/* 688 */             Element place = (Element)placesList.item(j);
/* 689 */             Integer id = Integer.decode(place.getAttribute("id"));
/* 690 */             String name = place.getAttribute("name");
/* 691 */             Integer token = Integer.decode(place.getAttribute("token"));
/* 692 */             if (id != null && name != null && token != null) {
/*     */               
/* 694 */               int index = findPlace(id, name);
/* 695 */               if (index >= 0) {
/* 696 */                 newMarking.setTokenCount(index, token.intValue());
/*     */               } else {
/* 698 */                 LOG.error(String.format("Could not find place : %s, id %d\n", new Object[] { name, Integer.valueOf(id.intValue()) }));
/*     */               } 
/*     */             } 
/*     */           } 
/* 702 */           this.markingComboModel.addMarking(newMarking);
/* 703 */           this.markingTableModel.update();
/*     */         } 
/*     */       } 
/* 706 */       return true;
/*     */     } 
/* 708 */     LOG.error("Netname in markingset is not equal to loaded net, please load the correct net before loading this markingset");
/* 709 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int findPlace(Integer id, String name) {
/* 714 */     List<Place> places = this.pn.getPlaces();
/* 715 */     for (int i = 0; i < places.size(); i++) {
/* 716 */       Place p = places.get(i);
/* 717 */       if (p.getId() == id.intValue() && p.getName().equals(name)) {
/* 718 */         return i;
/*     */       }
/*     */     } 
/* 721 */     return -1;
/*     */   }
/*     */   
/*     */   public void storeMarkings(File xmlFile) {
/* 725 */     if (this.pn == null) {
/*     */       return;
/*     */     }
/* 728 */     Document document = XMLReader.createNewXmlDocument();
/* 729 */     if (document == null) {
/*     */       return;
/*     */     }
/*     */     
/* 733 */     Element root = document.createElement("markingset");
/* 734 */     root.setAttribute("netfile", this.pn.getName());
/*     */     
/* 736 */     for (int i = 0; i < this.markingComboModel.getSize(); i++) {
/* 737 */       Marking m = (Marking)this.markingComboModel.getElementAt(i);
/* 738 */       if (!m.getName().equals("m0")) {
/* 739 */         Element markingElement = document.createElement("marking");
/* 740 */         markingElement.setAttribute("name", m.getName());
/* 741 */         List<Place> places = m.getPlaces();
/*     */         
/* 743 */         for (int j = 0; j < places.size(); j++) {
/* 744 */           Place p = places.get(j);
/* 745 */           Element place = document.createElement("place");
/*     */           
/* 747 */           place.setAttribute("name", p.getName());
/* 748 */           place.setAttribute("id", Integer.toString(p.getId()));
/* 749 */           place.setAttribute("token", Integer.toString(m.getTokenCount(j).intValue()));
/* 750 */           markingElement.appendChild(place);
/*     */         } 
/* 752 */         root.appendChild(markingElement);
/*     */       } 
/*     */     } 
/* 755 */     document.appendChild(root);
/*     */     
/* 757 */     XMLWriter.writeXmlFile(document, xmlFile);
/*     */   }
/*     */   
/*     */   public final String getActualMarkingName() {
/* 761 */     return ((Marking)this.markingComboModel.getSelectedItem()).getName();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/MarkingEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */