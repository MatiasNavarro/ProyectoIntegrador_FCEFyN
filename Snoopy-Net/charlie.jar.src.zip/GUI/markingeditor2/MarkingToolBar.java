/*     */ package GUI.markingeditor2;
/*     */ 
/*     */ import GUI.markingeditor2.actions.CopyMarkingAction;
/*     */ import GUI.markingeditor2.actions.DeleteMarkingAction;
/*     */ import GUI.markingeditor2.actions.LoadMarkingsAction;
/*     */ import GUI.markingeditor2.actions.MarkingNamesAction;
/*     */ import GUI.markingeditor2.actions.NewMarkingAction;
/*     */ import GUI.markingeditor2.actions.SaveMarkingsAction;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ItemListener;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JToolBar;
/*     */ 
/*     */ public class MarkingToolBar
/*     */   extends JPanel
/*     */ {
/*  23 */   private JComboBox loadedNets = null;
/*  24 */   private JComboBox markingNames = null;
/*  25 */   private IMarkingDirector director = null;
/*  26 */   private JButton newMarking = null;
/*  27 */   private JButton deleteMarking = null;
/*  28 */   private JButton copyMarking = null;
/*  29 */   private JButton setMarking = null;
/*  30 */   private JButton loadMarkings = null;
/*  31 */   private JButton saveMarkings = null;
/*  32 */   private MarkingFilterToolBar filterToolBar = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkingToolBar(IMarkingDirector director) {
/*  40 */     this.director = director;
/*  41 */     initialize();
/*     */   }
/*     */   
/*     */   public void initialize() {
/*  45 */     this.loadMarkings = new JButton((Action)new LoadMarkingsAction(this.director, true));
/*  46 */     this.saveMarkings = new JButton((Action)new SaveMarkingsAction(this.director, true));
/*     */     
/*  48 */     this.newMarking = new JButton("new");
/*  49 */     this.deleteMarking = new JButton("delete");
/*  50 */     this.copyMarking = new JButton("copy");
/*  51 */     this.setMarking = new JButton("set");
/*     */     
/*  53 */     this.markingNames = new JComboBox();
/*  54 */     this.markingNames.addItemListener((ItemListener)new MarkingNamesAction(this.director));
/*  55 */     this.markingNames.setEditable(false);
/*     */     
/*  57 */     this.filterToolBar = new MarkingFilterToolBar(this.director);
/*     */     
/*  59 */     this.newMarking.setAction((Action)new NewMarkingAction(this.director));
/*  60 */     this.deleteMarking.setAction((Action)new DeleteMarkingAction(this.director));
/*  61 */     this.copyMarking.setAction((Action)new CopyMarkingAction(this.director));
/*     */     
/*  63 */     JToolBar newBar = new JToolBar("Marking Editor Toolbar", 0);
/*     */ 
/*     */     
/*  66 */     newBar.addSeparator();
/*  67 */     JLabel l = new JLabel("markings");
/*  68 */     l.setOpaque(true);
/*  69 */     newBar.add(this.loadMarkings);
/*  70 */     newBar.add(this.saveMarkings);
/*  71 */     newBar.addSeparator();
/*  72 */     newBar.add(l);
/*  73 */     newBar.addSeparator();
/*  74 */     newBar.add(this.markingNames);
/*  75 */     newBar.add(this.newMarking);
/*  76 */     newBar.add(this.deleteMarking);
/*  77 */     newBar.add(this.copyMarking);
/*     */ 
/*     */ 
/*     */     
/*  81 */     setLayout(new GridLayout(2, 1));
/*  82 */     add(newBar);
/*  83 */     add(this.filterToolBar);
/*  84 */     enable(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enable(boolean value) {
/*  92 */     this.newMarking.setEnabled(value);
/*  93 */     this.deleteMarking.setEnabled(value);
/*  94 */     this.copyMarking.setEnabled(value);
/*  95 */     this.markingNames.setEnabled(value);
/*  96 */     this.filterToolBar.enable(value);
/*  97 */     this.loadMarkings.setEnabled(value);
/*  98 */     this.saveMarkings.setEnabled(value);
/*     */   }
/*     */   
/*     */   public void setComboModel(String comboBoxName, ComboBoxModel model) {
/* 102 */     if (comboBoxName.equals("marking")) {
/*     */       
/* 104 */       DefaultComboBoxModel oldModel = (DefaultComboBoxModel)this.markingNames.getModel();
/* 105 */       oldModel.removeListDataListener(this.markingNames);
/* 106 */       this.markingNames.setModel(model);
/* 107 */     } else if (comboBoxName.equals("file")) {
/* 108 */       model.addListDataListener(this.loadedNets);
/* 109 */       this.loadedNets.setModel(model);
/*     */     } 
/*     */   }
/*     */   
/*     */   public JComboBox getNamesCombo() {
/* 114 */     return this.markingNames;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTableModel(MyTableModel model) {
/* 120 */     this.loadedNets.setActionCommand("insert");
/*     */     
/* 122 */     this.loadedNets.addItem(model);
/* 123 */     this.loadedNets.setSelectedItem(model);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/MarkingToolBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */