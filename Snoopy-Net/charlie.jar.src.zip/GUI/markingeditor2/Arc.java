/*    */ package GUI.markingeditor2;
/*    */ 
/*    */ public class Arc {
/*  4 */   String startId = "";
/*  5 */   String endId = "";
/*  6 */   int weight = 1;
/*    */   
/*    */   public Arc(String id, String start, String end, int weight) {
/*  9 */     this.id = id;
/* 10 */     this.startId = start;
/* 11 */     this.endId = end;
/* 12 */     this.weight = weight;
/*    */   }
/*    */   String id;
/*    */   public boolean equals(Arc a) {
/* 16 */     if (this.startId.equals(a.getStart()) && this.endId.equals(a.getEnd()))
/* 17 */       return true; 
/* 18 */     return false;
/*    */   }
/*    */   
/*    */   public String getStart() {
/* 22 */     return this.startId;
/*    */   }
/*    */   public String getEnd() {
/* 25 */     return this.endId;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/Arc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */