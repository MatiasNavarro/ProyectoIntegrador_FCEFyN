/*     */ package GUI.markingeditor2;
/*     */ 
/*     */ import charlie.pn.Marking;
/*     */ import charlie.pn.Place;
/*     */ import charlie.pn.PlaceTransitionNet;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ 
/*     */ public class MyTableModel
/*     */   extends AbstractTableModel
/*     */ {
/*     */   PlaceTransitionNet pn;
/*  15 */   int rowCount = 0;
/*  16 */   int columnCount = 0;
/*     */   List<Place> places;
/*     */   List<Marking> markings;
/*     */   
/*     */   public MyTableModel(PlaceTransitionNet pn, Vector<Marking> markingVector) {
/*  21 */     this.pn = pn;
/*  22 */     this.places = pn.getPlaces();
/*  23 */     this.rowCount = this.places.size();
/*  24 */     this.markings = markingVector;
/*  25 */     Marking m = new Marking("m0", this.places);
/*     */     
/*  27 */     for (int i = 0; i < this.rowCount; i++) {
/*  28 */       m.setTokenCount(i, (new Integer(((Place)this.places.get(i)).getToken())).intValue());
/*     */     }
/*  30 */     this.markings.add(m);
/*  31 */     this.columnCount++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Marking getMarking(int index) {
/*  42 */     return this.markings.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarking(int _index, Marking _m) {
/*  52 */     this.markings.set(_index, _m);
/*     */   }
/*     */   
/*     */   public int getRowCount() {
/*  56 */     return this.rowCount;
/*     */   }
/*     */   
/*     */   public int getColumnCount() {
/*  60 */     return 1 + this.markings.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnName(int col) {
/*  65 */     if (col == 0) {
/*  66 */       return "place name";
/*     */     }
/*     */     
/*  69 */     return ((Marking)this.markings.get(col - 1)).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValueAt(int row, int col) {
/*  75 */     if (this.places.size() < row) {
/*  76 */       return null;
/*     */     }
/*  78 */     if (col == 0) {
/*  79 */       return ((Place)this.places.get(row)).getName();
/*     */     }
/*  81 */     if (col - 1 <= this.markings.size()) {
/*  82 */       Marking m = this.markings.get(col - 1);
/*  83 */       return m.getTokenCount(row);
/*     */     } 
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCellEditable(int row, int column) {
/*  94 */     if (column < 2)
/*     */     {
/*  96 */       return false;
/*     */     }
/*     */     
/*  99 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueAt(Object o, int rowIndex, int columnIndex) {
/* 106 */     if (columnIndex - 1 <= this.markings.size()) {
/* 107 */       Marking m = this.markings.get(columnIndex - 1);
/*     */ 
/*     */       
/* 110 */       Byte b = (Byte)o;
/* 111 */       Place p = this.places.get(rowIndex);
/* 112 */       int maxToken = p.getCapacity();
/* 113 */       m.setTokenCount(rowIndex, b.byteValue());
/*     */       
/* 115 */       fireTableCellUpdated(rowIndex, columnIndex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public PlaceTransitionNet setMarkingToNet(int index) {
/* 120 */     List<Place> places = this.pn.getPlaces();
/* 121 */     Marking m0 = this.pn.getM0();
/*     */ 
/*     */ 
/*     */     
/* 125 */     Marking marking = this.markings.get(index - 1);
/* 126 */     Vector<Integer> markingVector = new Vector<>();
/* 127 */     int i = 0;
/* 128 */     int j = 0;
/* 129 */     while (i < places.size()) {
/* 130 */       Place p = places.get(i);
/* 131 */       int id = p.getId();
/* 132 */       Integer value = marking.getTokenCount(i);
/* 133 */       if (value.intValue() <= Integer.MAX_VALUE) {
/* 134 */         if (value.intValue() > 0) {
/* 135 */           markingVector.add(new Integer(id));
/* 136 */           markingVector.add(new Integer(value.intValue()));
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 141 */         JOptionPane.showMessageDialog(null, "<html><p>The tokenvalue of place " + p.getName() + "</p><p>exceeds the maximal byte value.</p><p>Please correct</p></html>");
/*     */       } 
/* 143 */       i++;
/*     */     } 
/* 145 */     this.pn.setM0(markingVector);
/* 146 */     m0 = this.pn.getM0();
/*     */ 
/*     */     
/* 149 */     return this.pn;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class getColumnClass(int c) {
/* 154 */     return getValueAt(0, c).getClass();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 159 */     return this.pn.getName() + "/" + Integer.toString(this.pn.places()) + "/" + Integer.toString(this.markings.size());
/*     */   }
/*     */ 
/*     */   
/*     */   public int findColumn(String columnName) {
/* 164 */     if (columnName.equals("place name")) {
/* 165 */       return 0;
/*     */     }
/*     */     
/* 168 */     for (int i = 0; i < this.markings.size(); i++) {
/* 169 */       String s = ((Marking)this.markings.get(i)).toString();
/* 170 */       if (s.equals(columnName)) {
/* 171 */         return i + 1;
/*     */       }
/*     */     } 
/*     */     
/* 175 */     return -1;
/*     */   }
/*     */   
/*     */   public int findColumn(Marking m) {
/* 179 */     return this.markings.indexOf(m);
/*     */   }
/*     */   
/*     */   public void showNetInfo() {
/* 183 */     StringBuffer buf = new StringBuffer();
/* 184 */     buf.append("<html><table><tr><td>NET NAME</td><td>" + this.pn.getName() + "</td></tr><tr>");
/*     */     
/* 186 */     for (int i = 0; i < this.places.size(); i++) {
/* 187 */       Place p = this.places.get(i);
/* 188 */       buf.append("<tr><td>");
/* 189 */       buf.append(p.getName());
/* 190 */       buf.append("</td></td>");
/* 191 */       buf.append(Integer.toString(p.getToken()));
/* 192 */       buf.append("</td></tr>");
/*     */     } 
/* 194 */     buf.append("</html>");
/* 195 */     JOptionPane.showMessageDialog(null, buf.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOfMarking(String _name) {
/* 206 */     int index = 0;
/* 207 */     for (Marking m : this.markings) {
/* 208 */       if (m.getName().equals(_name)) {
/* 209 */         return index;
/*     */       }
/* 211 */       index++;
/*     */     } 
/* 213 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean update() {
/* 217 */     fireTableStructureChanged();
/* 218 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/MyTableModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */