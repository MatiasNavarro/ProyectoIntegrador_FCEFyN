/*     */ package GUI.markingeditor2;
/*     */ 
/*     */ import charlie.pn.Place;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Marking
/*     */ {
/*  14 */   private String name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  20 */   private final List<Integer> tokenList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<Place> placeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Marking(String name, List<Place> places) {
/*  34 */     this.name = name;
/*  35 */     this.placeList = places;
/*     */     
/*  37 */     for (int i = 0; i < this.placeList.size(); i++) {
/*  38 */       this.tokenList.add(new Integer("0"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Marking(String name, Marking m) {
/*  49 */     this.placeList = m.getPlaces();
/*  50 */     this.name = name;
/*  51 */     for (int i = 0; i < this.placeList.size(); i++) {
/*  52 */       this.tokenList.add(new Integer(m.getTokenCount(i).intValue()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTokenCount(int index, int count) {
/*  63 */     if (index < this.tokenList.size()) {
/*  64 */       this.tokenList.set(index, new Integer(count));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTokenCount(List<Integer> _tokenList) {
/*  74 */     this.tokenList.clear();
/*  75 */     this.tokenList.addAll(_tokenList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getTokenCount(int index) {
/*  86 */     if (index < this.tokenList.size()) {
/*  87 */       return Integer.valueOf(((Integer)this.tokenList.get(index)).intValue());
/*     */     }
/*     */     
/*  90 */     return new Integer("0");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  95 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  99 */     return this.name;
/*     */   }
/*     */   public List<Place> getPlaces() {
/* 102 */     return this.placeList;
/*     */   }
/*     */   
/*     */   public void addPlace(Place _p) {
/* 106 */     this.placeList.add(_p);
/* 107 */     this.tokenList.add(Integer.valueOf(0));
/*     */   }
/*     */   
/*     */   public void removePlace(Place _p) {
/* 111 */     this.placeList.remove(_p);
/* 112 */     this.tokenList.remove(_p);
/*     */   }
/*     */   
/*     */   public void removePlace(int _index) {
/* 116 */     this.placeList.remove(_index);
/* 117 */     this.tokenList.remove(_index);
/*     */   }
/*     */   
/*     */   public List<Integer> getMarkingVector() {
/* 121 */     List<Integer> vector = new Vector<>();
/*     */     
/* 123 */     for (int i = 0; i < this.placeList.size(); i++) {
/* 124 */       vector.add(new Integer(((Place)this.placeList.get(i)).getId()));
/* 125 */       vector.add(new Integer(((Integer)this.tokenList.get(i)).intValue()));
/*     */     } 
/* 127 */     return vector;
/*     */   }
/*     */   
/*     */   public static Marking copyMarking(Marking m, String newName) {
/* 131 */     Marking newMarking = new Marking(newName, m);
/* 132 */     return newMarking;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 137 */     int prime = 31;
/* 138 */     int result = 1;
/* 139 */     result = 31 * result + ((this.name == null) ? 0 : this.name.hashCode());
/* 140 */     result = 31 * result + ((this.placeList == null) ? 0 : this.placeList.hashCode());
/* 141 */     result = 31 * result + ((this.tokenList == null) ? 0 : this.tokenList.hashCode());
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 147 */     if (this == obj) {
/* 148 */       return true;
/*     */     }
/* 150 */     if (obj == null) {
/* 151 */       return false;
/*     */     }
/* 153 */     if (getClass() != obj.getClass()) {
/* 154 */       return false;
/*     */     }
/* 156 */     Marking other = (Marking)obj;
/* 157 */     if (this.name == null) {
/* 158 */       if (other.name != null) {
/* 159 */         return false;
/*     */       }
/* 161 */     } else if (!this.name.equals(other.name)) {
/* 162 */       return false;
/*     */     } 
/* 164 */     if (this.placeList == null) {
/* 165 */       if (other.placeList != null) {
/* 166 */         return false;
/*     */       }
/* 168 */     } else if (!this.placeList.equals(other.placeList)) {
/* 169 */       return false;
/*     */     } 
/* 171 */     if (this.tokenList == null) {
/* 172 */       if (other.tokenList != null) {
/* 173 */         return false;
/*     */       }
/* 175 */     } else if (!this.tokenList.equals(other.tokenList)) {
/* 176 */       return false;
/*     */     } 
/* 178 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/markingeditor2/Marking.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */