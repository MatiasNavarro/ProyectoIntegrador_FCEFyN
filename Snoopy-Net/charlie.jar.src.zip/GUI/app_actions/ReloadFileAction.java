/*    */ package GUI.app_actions;
/*    */ 
/*    */ import GUI.IDirector;
/*    */ import GUI.util.ResourceLoader;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.net.URL;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.ImageIcon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReloadFileAction
/*    */   extends AbstractAction
/*    */ {
/*    */   IDirector director;
/*    */   
/*    */   public ReloadFileAction(IDirector d) {
/* 19 */     super("Reload File");
/* 20 */     this.director = d;
/* 21 */     putValue("Name", "reload");
/* 22 */     putValue("ShortDescription", "reload the net from file");
/* 23 */     URL url = ResourceLoader.getURL("resources/refresh16.gif");
/*    */     
/* 25 */     if (url != null) {
/* 26 */       putValue("SmallIcon", new ImageIcon(url));
/*    */     }
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 31 */     this.director.sendMessage(13, this, "logFile");
/* 32 */     this.director.sendMessage(4, this, null);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_actions/ReloadFileAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */