/*    */ package GUI.app_actions;
/*    */ 
/*    */ import GUI.IDirector;
/*    */ import GUI.app_components.menu.LastFilesMenu;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.File;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.JOptionPane;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilesAction
/*    */   extends AbstractAction
/*    */ {
/*    */   private static final long serialVersionUID = -5840410129489693589L;
/* 24 */   private static final Log LOG = LogFactory.getLog(FilesAction.class);
/*    */   
/* 26 */   private IDirector director = null;
/* 27 */   private LastFilesMenu menu = null;
/*    */ 
/*    */ 
/*    */   
/*    */   public FilesAction(IDirector d, LastFilesMenu menu) {
/* 32 */     this.director = d;
/* 33 */     this.menu = menu;
/*    */   }
/*    */ 
/*    */   
/*    */   public FilesAction(String name, IDirector d, LastFilesMenu menu) {
/* 38 */     super(name);
/* 39 */     this.director = d;
/* 40 */     this.menu = menu;
/*    */   }
/*    */ 
/*    */   
/*    */   public FilesAction(String name, Icon icon, IDirector d, LastFilesMenu menu) {
/* 45 */     super(name, icon);
/* 46 */     this.director = d;
/* 47 */     this.menu = menu;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 51 */     String cmd = e.getActionCommand();
/*    */     
/* 53 */     if (LOG.isDebugEnabled()) {
/* 54 */       LOG.debug(String.format("Command %s", new Object[] { cmd }));
/*    */     }
/*    */     
/* 57 */     if (cmd.startsWith(LastFilesMenu.PREQUEL)) {
/* 58 */       String subString = cmd.substring(LastFilesMenu.PREQUEL.length(), cmd.length());
/* 59 */       LOG.debug(String.format("substring index= %s", new Object[] { subString }));
/* 60 */       int index = Integer.decode(subString).intValue();
/* 61 */       File f = this.menu.getFileByIndex(index);
/* 62 */       if (f != null) {
/* 63 */         if (LOG.isDebugEnabled()) {
/* 64 */           LOG.debug(String.format("FilesAction.actionPerformed : parent.getText() %s!", new Object[] { f.getName() }));
/*    */         }
/*    */         
/* 67 */         int answ = 0;
/* 68 */         if (this.director.sendMessage(15, this, null)) {
/* 69 */           answ = JOptionPane.showConfirmDialog(null, "All results will be lost! Continue?", "Message", 0);
/*    */         }
/*    */ 
/*    */         
/* 73 */         if (answ == 0) {
/* 74 */           this.director.sendMessage(1, this, f);
/*    */         }
/*    */       } else {
/* 77 */         LOG.warn("FilesAction.actionPerformed : LastFilesMenu.getFileByIndex(index) did not return a file !");
/*    */       } 
/*    */     } else {
/* 80 */       LOG.warn("FilesAction.actionPerformed : unknown parent!");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_actions/FilesAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */