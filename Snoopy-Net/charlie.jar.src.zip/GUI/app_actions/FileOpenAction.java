/*    */ package GUI.app_actions;
/*    */ 
/*    */ import GUI.IDirector;
/*    */ import GUI.app_components.menu.LastFilesMenu;
/*    */ import GUI.io.FileSaver;
/*    */ import GUI.util.ResourceLoader;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.File;
/*    */ import java.net.URL;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JOptionPane;
/*    */ import javax.swing.SwingWorker;
/*    */ import javax.swing.filechooser.FileNameExtensionFilter;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileOpenAction
/*    */   extends AbstractAction
/*    */ {
/*    */   private static final long serialVersionUID = 5338296540749951256L;
/* 28 */   private static final Log LOG = LogFactory.getLog(FileOpenAction.class);
/*    */   
/*    */   IDirector director;
/* 31 */   static LastFilesMenu lastFiles = null;
/*    */   
/*    */   public FileOpenAction(IDirector d, LastFilesMenu last) {
/* 34 */     super("open File");
/* 35 */     this.director = d;
/* 36 */     if (last != null) {
/* 37 */       lastFiles = last;
/*    */     }
/* 39 */     putValue("Name", "open ...");
/* 40 */     putValue("ShortDescription", "choose the net file to be opened");
/* 41 */     URL url = ResourceLoader.getURL("resources/new16.jpg");
/* 42 */     if (url != null) {
/* 43 */       putValue("SmallIcon", new ImageIcon(url));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 49 */     if (this.director.sendMessage(15, this, null)) {
/* 50 */       int answ = JOptionPane.showConfirmDialog(null, "All results will be lost! Continue?", "Message", 0);
/*    */       
/* 52 */       if (answ != 0) {
/*    */         return;
/*    */       }
/*    */     } 
/*    */     
/* 57 */     this.director.sendMessage(13, this, "logFile");
/* 58 */     FileSaver fs = new FileSaver();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 65 */     final File file = fs.showOpenDialog(null, new FileNameExtensionFilter("All petri net files (andl,apnn,pnt,cnt)", new String[] { "andl", "apnn", "pnt", "cnt", "*.*" }));
/*    */ 
/*    */ 
/*    */     
/* 69 */     if (file != null) {
/*    */       
/* 71 */       SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>()
/*    */         {
/*    */           public Void doInBackground() {
/* 74 */             boolean answer = FileOpenAction.this.director.sendMessage(1, this, file);
/* 75 */             FileSaver.lastSaveDir = file.getParent();
/* 76 */             if (FileOpenAction.lastFiles != null && answer) {
/* 77 */               FileOpenAction.lastFiles.addFile(file);
/*    */             } else {
/* 79 */               FileOpenAction.LOG.warn(String.format("Could not load file %s", new Object[] { this.val$file.getName() }));
/*    */             } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */             
/* 87 */             return null;
/*    */           }
/*    */         };
/*    */       
/* 91 */       worker.execute();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/app_actions/FileOpenAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */