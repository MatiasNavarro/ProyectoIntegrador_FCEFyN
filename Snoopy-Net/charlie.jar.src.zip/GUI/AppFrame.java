/*     */ package GUI;
/*     */ 
/*     */ import GUI.app_actions.FileOpenAction;
/*     */ import GUI.app_actions.ReloadFileAction;
/*     */ import GUI.app_components.menu.AppMenu;
/*     */ import GUI.dialog.DialogFrame;
/*     */ import GUI.dialog.DialogPanel;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.File;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.KeyStroke;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AppFrame
/*     */   extends DialogFrame
/*     */ {
/*     */   private static final long serialVersionUID = -7480873307390357720L;
/*  39 */   private static final Log LOG = LogFactory.getLog(AppFrame.class);
/*     */   
/*     */   private ConsoleWindow consoleWindow;
/*     */   private IDirector director;
/*  43 */   private AppMenu menu = null;
/*     */   
/*     */   private JButton reloadButton;
/*     */   
/*     */   public AppFrame(IDirector director) {
/*  48 */     this(310, "Center", director);
/*     */   }
/*     */   
/*     */   public AppFrame(int width, String location, IDirector director) {
/*  52 */     super(width, location);
/*     */     
/*  54 */     this.director = director;
/*     */ 
/*     */ 
/*     */     
/*  58 */     this.menu = AppMenu.createJMenu((JFrame)this, director);
/*     */     
/*  60 */     setDefaultCloseOperation(3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperties(Properties properties) {}
/*     */ 
/*     */   
/*     */   public void setup() {
/*  68 */     this.consoleWindow = new ConsoleWindow();
/*  69 */     this.consoleWindow.setup((JFrame)this);
/*  70 */     add(createToolBar(), "North");
/*  71 */     setTitle("Charlie");
/*  72 */     setVisible(true);
/*  73 */     setResizable(false);
/*     */     
/*  75 */     addWindowListener(new WindowAdapter()
/*     */         {
/*     */           public void windowClosing(WindowEvent evt) {
/*  78 */             AppFrame.this.director.sendMessage(3, this, null);
/*     */           }
/*     */         });
/*     */     
/*  82 */     setName("AppFrame");
/*  83 */     setJMenuBar((JMenuBar)this.menu);
/*  84 */     pack();
/*     */   }
/*     */   
/*     */   public void newNetLoaded(File file) {
/*  88 */     this.menu.enableReload();
/*  89 */     this.reloadButton.setEnabled(true);
/*     */   }
/*     */   
/*     */   public void addLastFile(File file) {
/*  93 */     if (this.menu != null) {
/*  94 */       this.menu.addLastFile(file);
/*     */     } else {
/*  96 */       LOG.warn(String.format("Could not add file '%s' to list of last files. Menu is null.", new Object[] { file
/*  97 */               .getAbsolutePath() }));
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<? extends File> getLastFileList() {
/* 102 */     return this.menu.getLastFileList();
/*     */   }
/*     */   
/*     */   private JToolBar createToolBar() {
/* 106 */     JToolBar t = new JToolBar("File Operations", 0);
/* 107 */     JButton open = new JButton((Action)new FileOpenAction(this.director, null));
/* 108 */     open.setText("");
/* 109 */     t.add(open);
/* 110 */     ReloadFileAction reloadFileAction = new ReloadFileAction(this.director);
/* 111 */     this.reloadButton = new JButton((Action)reloadFileAction);
/* 112 */     this.reloadButton.setEnabled(false);
/* 113 */     this.reloadButton.setText("");
/* 114 */     t.add(this.reloadButton);
/*     */ 
/*     */     
/* 117 */     this.reloadButton.getInputMap(2).put(KeyStroke.getKeyStroke(116, 0), AppFrame.class
/* 118 */         .getName() + ".reload");
/* 119 */     this.reloadButton.getActionMap().put(AppFrame.class.getName() + ".reload", (Action)reloadFileAction);
/*     */     
/* 121 */     Action consoleAction = new AbstractAction()
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/* 129 */           if (!AppFrame.this.consoleWindow.isVisible()) {
/* 130 */             AppFrame.this.consoleWindow.showWindow();
/*     */           } else {
/* 132 */             AppFrame.this.consoleWindow.hideWindow();
/*     */           } 
/*     */         }
/*     */       };
/* 136 */     JToggleButton consoleButton = new JToggleButton(consoleAction);
/* 137 */     this.consoleWindow.setToggleButton(consoleButton);
/* 138 */     t.add(consoleButton);
/* 139 */     JComboBox<String> combo = new JComboBox();
/* 140 */     int i = 0;
/* 141 */     for (i = 0; i < this.dialogPanel.getDialogCount(); i++) {
/* 142 */       combo.addItem(this.dialogPanel.getDialog(i).getDialogTitleText());
/*     */     }
/* 144 */     combo.addActionListener(new actionListenerComboMenu(this.dialogPanel, this.scroll));
/* 145 */     Dimension d = new Dimension(100, combo.getHeight());
/* 146 */     combo.setPreferredSize(d);
/* 147 */     combo.setSize(d);
/* 148 */     t.add(combo);
/* 149 */     return t;
/*     */   }
/*     */   
/*     */   class actionListenerComboMenu implements ActionListener {
/* 153 */     DialogPanel dialogPanel = null;
/* 154 */     JScrollPane scroll = null;
/*     */     
/*     */     public actionListenerComboMenu(DialogPanel dialogPanel, JScrollPane scroll) {
/* 157 */       if (dialogPanel != null) {
/* 158 */         this.dialogPanel = dialogPanel;
/*     */       }
/* 160 */       if (scroll != null) {
/* 161 */         this.scroll = scroll;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 167 */       JComboBox cb = (JComboBox)e.getSource();
/* 168 */       if (cb == null) {
/* 169 */         AppFrame.LOG.error("e.getSource() == null");
/*     */         return;
/*     */       } 
/* 172 */       this.dialogPanel.minimizeAllBut(cb.getSelectedIndex());
/* 173 */       this.dialogPanel.redraw();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/AppFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */