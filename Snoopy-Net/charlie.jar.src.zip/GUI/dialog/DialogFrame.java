/*     */ package GUI.dialog;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.DisplayMode;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Toolkit;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DialogFrame
/*     */   extends JFrame
/*     */   implements PropertyChangeListener
/*     */ {
/*     */   private static final long serialVersionUID = 7299787133449899034L;
/*  31 */   private static final Log LOG = LogFactory.getLog(DialogFrame.class);
/*     */   
/*  33 */   protected DialogPanel dialogPanel = null;
/*     */   private String dialogLocation;
/*     */   protected JScrollPane scroll;
/*  36 */   protected Component southComponent = null;
/*  37 */   protected Component northComponent = null;
/*  38 */   protected int titleHeight = 0;
/*     */   
/*  40 */   protected int scrollBarWidth = 15;
/*  41 */   protected int WIDTH = 0;
/*     */   
/*  43 */   private Dimension size = new Dimension(this.WIDTH, 0);
/*     */   
/*     */   public DialogFrame() {
/*  46 */     this.WIDTH = 600;
/*  47 */     this.dialogLocation = "Center";
/*  48 */     this.dialogPanel = new DialogPanel(this.WIDTH, this);
/*  49 */     this.scroll = new JScrollPane(this.dialogPanel, 20, 31);
/*  50 */     this.dialogPanel.setOwner(this.scroll);
/*  51 */     setLayout(new BorderLayout());
/*  52 */     getContentPane().add(this.scroll, this.dialogLocation);
/*  53 */     JScrollBar scrollBar = this.scroll.getVerticalScrollBar();
/*  54 */     scrollBar.setUnitIncrement(60);
/*  55 */     getContentPane().add(scrollBar, "East");
/*  56 */     pack();
/*     */   }
/*     */   
/*     */   public DialogFrame(int width, String layoutLocation) {
/*  60 */     this.dialogLocation = checkLocation(layoutLocation);
/*  61 */     pack();
/*  62 */     Insets inset = getInsets();
/*  63 */     this.titleHeight = inset.top + inset.bottom;
/*  64 */     this.dialogPanel = new DialogPanel(width, this);
/*  65 */     this.scroll = new JScrollPane(this.dialogPanel, 20, 31);
/*  66 */     this.dialogPanel.setOwner(this.scroll);
/*  67 */     this.WIDTH = width;
/*  68 */     setLayout(new BorderLayout());
/*  69 */     getContentPane().add(this.scroll, this.dialogLocation);
/*  70 */     JScrollBar scrollBar = this.scroll.getVerticalScrollBar();
/*  71 */     getContentPane().add(scrollBar, "East");
/*  72 */     pack();
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(Component c, String location) {
/*  77 */     String loc = checkLocation(location);
/*  78 */     if (loc.equals("North")) {
/*  79 */       if (this.northComponent != null) {
/*  80 */         getContentPane().remove(this.northComponent);
/*     */       }
/*  82 */       this.northComponent = c;
/*  83 */       getContentPane().add(this.northComponent, loc);
/*  84 */     } else if (loc.equals("South")) {
/*  85 */       if (this.southComponent != null) {
/*  86 */         getContentPane().remove(this.southComponent);
/*     */       }
/*  88 */       this.southComponent = c;
/*  89 */       getContentPane().add(this.southComponent, loc);
/*  90 */     } else if (loc.equals("Center")) {
/*  91 */       if (c instanceof DialogPanel) {
/*  92 */         switchDialogPanel((DialogPanel)c);
/*     */       } else {
/*  94 */         System.out.printf("DialogFrame.add(Component)Cannot add java.awt.Component to CENTER location of DialogFrame, choose a other location!\n", new Object[0]);
/*     */       } 
/*     */     } 
/*  97 */     pack();
/*     */   }
/*     */   
/*     */   public void switchDialogPanel(DialogPanel dp) {
/* 101 */     if (dp != null) {
/* 102 */       this.scroll.remove(this.dialogPanel);
/* 103 */       this.dialogPanel = dp;
/* 104 */       this.scroll.setViewportView(this.dialogPanel);
/* 105 */       this.dialogPanel.redraw();
/* 106 */       resize(0);
/*     */     } else {
/*     */       
/* 109 */       this.dialogPanel = new DialogPanel(this.WIDTH, this);
/* 110 */       this.dialogPanel.redraw();
/* 111 */       this.scroll.setViewportView(this.dialogPanel);
/* 112 */       resize(0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addDialog(JPanel dialog, String text) {
/* 117 */     if (this.dialogPanel != null) {
/* 118 */       this.dialogPanel.addDialog(dialog, text);
/*     */       
/* 120 */       resize(0);
/*     */     } else {
/* 122 */       LOG.error("DialogFrame: no DialogPanel");
/*     */     } 
/*     */   }
/*     */   
/*     */   public String checkLocation(String loc) {
/* 127 */     if (loc == null)
/* 128 */       return "Center"; 
/* 129 */     if (loc.equals(""))
/* 130 */       return "Center"; 
/* 131 */     if ("Center".equals(loc) || "center".equals(loc) || "CENTER".equals(loc))
/* 132 */       return "Center"; 
/* 133 */     if ("East".equals(loc) || "east".equals(loc) || "EAST".equals(loc))
/* 134 */       return "East"; 
/* 135 */     if ("North".equals(loc) || "north".equals(loc) || "NORTH".equals(loc))
/* 136 */       return "North"; 
/* 137 */     if ("South".equals(loc) || "south".equals(loc) || "SOUTH".equals(loc))
/* 138 */       return "South"; 
/* 139 */     if ("West".equals(loc) || "west".equals(loc) || "WEST".equals(loc)) {
/* 140 */       return "West";
/*     */     }
/*     */     
/* 143 */     return "Center";
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaximized(int index) {
/* 148 */     this.dialogPanel.setMaximized(index);
/*     */   }
/*     */   
/*     */   public int determineMaximalHeight() {
/* 152 */     Insets inset = Toolkit.getDefaultToolkit().getScreenInsets(getGraphicsConfiguration());
/* 153 */     return inset.bottom;
/*     */   }
/*     */   
/*     */   public int determineTaskBarHeight() {
/* 157 */     Insets inset = Toolkit.getDefaultToolkit().getScreenInsets(getGraphicsConfiguration());
/* 158 */     return inset.bottom;
/*     */   }
/*     */   
/*     */   public void resize(int change) {
/*     */     Point top;
/* 163 */     if (isVisible()) {
/*     */       
/* 165 */       top = getLocationOnScreen();
/*     */     }
/*     */     else {
/*     */       
/* 169 */       top = getLocation();
/*     */     } 
/* 171 */     GraphicsConfiguration gc = getGraphicsConfiguration();
/* 172 */     DisplayMode mode = getGraphicsConfiguration().getDevice().getDisplayMode();
/* 173 */     Rectangle bounds = gc.getBounds();
/* 174 */     top.x -= bounds.x;
/* 175 */     top.y -= bounds.y;
/*     */     
/* 177 */     int panelSpace = mode.getHeight() - top.y - determineTaskBarHeight() - getHeight() - this.scroll.getHeight();
/*     */     
/* 179 */     double panelHeight = this.dialogPanel.getPanelHeight();
/* 180 */     double windowWidth = getWidth();
/* 181 */     double windowHeight = getHeight();
/* 182 */     Dimension scrollSize = this.scroll.getPreferredSize();
/* 183 */     Dimension size = getSize();
/* 184 */     if (panelHeight > panelSpace) {
/*     */       
/* 186 */       scrollSize.setSize(this.WIDTH, panelSpace);
/* 187 */       size.setSize(windowWidth, (top.y - determineTaskBarHeight()));
/*     */     } else {
/*     */       
/* 190 */       scrollSize.setSize(this.WIDTH, panelHeight + 4.0D);
/* 191 */       size.setSize(windowWidth, windowHeight + change);
/*     */     } 
/* 193 */     this.scroll.setSize(scrollSize);
/* 194 */     this.scroll.setPreferredSize(scrollSize);
/* 195 */     setSize(size);
/* 196 */     pack();
/*     */   }
/*     */ 
/*     */   
/*     */   public void resizeOld(int change) {
/*     */     Point p;
/*     */     Dimension d;
/* 203 */     double width = this.WIDTH;
/* 204 */     if (width == 0.0D) {
/* 205 */       width = this.WIDTH;
/*     */     }
/* 207 */     int taskbarHeight = determineMaximalHeight();
/*     */ 
/*     */ 
/*     */     
/* 211 */     if (isVisible()) {
/* 212 */       p = getLocationOnScreen();
/*     */     } else {
/* 214 */       p = getLocation();
/*     */     } 
/* 216 */     GraphicsConfiguration gc = getGraphicsConfiguration();
/* 217 */     GraphicsDevice device = gc.getDevice();
/* 218 */     DisplayMode mode = device.getDisplayMode();
/* 219 */     LOG.debug(String.format("graphics device: %s, height:%d, width: %d", new Object[] { device.toString(), Integer.valueOf(mode.getHeight()), Integer.valueOf(mode.getWidth()) }));
/*     */     
/* 221 */     double dialogHeight = this.dialogPanel.getPanelHeight();
/* 222 */     double scrollHeight = this.scroll.getHeight();
/* 223 */     double windowHeight = getHeight();
/* 224 */     double restHeight = windowHeight + 4.0D - scrollHeight;
/*     */     
/* 226 */     double screenHeight = mode.getHeight() - p.getY() - taskbarHeight;
/* 227 */     double availableHeight = mode.getHeight() - p.getY() - restHeight;
/*     */     
/* 229 */     if (dialogHeight > availableHeight) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       d = new Dimension((int)width, (int)availableHeight);
/* 235 */       JScrollBar vBar = this.scroll.getVerticalScrollBar();
/* 236 */       vBar.setUnitIncrement(60);
/* 237 */       this.size.setSize(width, screenHeight);
/*     */     }
/*     */     else {
/*     */       
/* 241 */       this.size.setSize(width, restHeight + dialogHeight);
/* 242 */       d = new Dimension((int)width, (int)dialogHeight + 4);
/*     */     } 
/* 244 */     this.scroll.setSize(d);
/* 245 */     this.scroll.setPreferredSize(d);
/* 246 */     setSize(this.size);
/*     */     
/* 248 */     printSizes("After resize");
/*     */   }
/*     */ 
/*     */   
/*     */   private void printScrollbarInfo(String text) {
/* 253 */     JScrollBar vBar = this.scroll.getVerticalScrollBar();
/* 254 */     LOG.info(String.format("\n********* %s *********\n", new Object[] { text }));
/* 255 */     LOG.info(String.format("\nScrollbar.Maximum : %d\n", new Object[] { Integer.valueOf(vBar.getMaximum()) }));
/* 256 */     LOG.info(String.format("\nScrollbar.Minimum : %d\n", new Object[] { Integer.valueOf(vBar.getMinimum()) }));
/* 257 */     LOG.info(String.format("\nScrollbar.Value : %d\n", new Object[] { Integer.valueOf(vBar.getValue()) }));
/* 258 */     LOG.info(String.format("\nScrollbar.Visible Amount : %d\n", new Object[] { Integer.valueOf(vBar.getVisibleAmount()) }));
/* 259 */     LOG.info(String.format("\n**************************\n", new Object[0]));
/*     */   }
/*     */   
/*     */   private void printSizes(String text) {
/* 263 */     LOG.info(String.format("\n********* %s *********\n", new Object[] { text }));
/* 264 */     LOG.info(String.format("\nDialogPanel.height : %d\n", new Object[] { Integer.valueOf(this.dialogPanel.getPanelHeight()) }));
/* 265 */     LOG.info(String.format("Window.height      : %d\n", new Object[] { Integer.valueOf(getHeight()) }));
/* 266 */     LOG.info(String.format("Window.width       : %d\n", new Object[] { Integer.valueOf(getWidth()) }));
/* 267 */     LOG.info(String.format("ScrollPane.height  : %d\n", new Object[] { Integer.valueOf(this.scroll.getHeight()) }));
/* 268 */     LOG.info(String.format("ScrollPane.width   : %d\n", new Object[] { Integer.valueOf(this.scroll.getWidth()) }));
/* 269 */     LOG.info(String.format("\n**************************\n", new Object[0]));
/*     */   }
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent e) {
/* 273 */     Object o = e.getSource();
/* 274 */     Integer change = Integer.valueOf(((Integer)e.getNewValue()).intValue() - ((Integer)e.getOldValue()).intValue());
/* 275 */     if ("height".equals(e.getPropertyName())) {
/* 276 */       resize(change.intValue());
/* 277 */       if (o instanceof BaseDialog) {
/* 278 */         Rectangle p = ((JPanel)o).getBounds();
/* 279 */         this.dialogPanel.scrollRectToVisible(p);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/dialog/DialogFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */