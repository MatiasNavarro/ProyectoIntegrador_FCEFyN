/*     */ package GUI.dialog;
/*     */ 
/*     */ import GUI.util.MyMouseWheelListener;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import layout.TableLayout;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DialogPanel
/*     */   extends JPanel
/*     */ {
/*     */   private static final long serialVersionUID = -7330178202921208843L;
/*  24 */   private static final Log LOG = LogFactory.getLog(DialogPanel.class);
/*     */   
/*  26 */   private ArrayList<BaseDialog> dialogList = new ArrayList<>();
/*  27 */   int windowHeight = 0;
/*  28 */   int windowWidth = 0;
/*  29 */   int dialogCount = 0;
/*  30 */   Dimension panelSize = new Dimension(0, 0);
/*  31 */   public JScrollPane owner = null;
/*  32 */   TableLayout layout = null;
/*  33 */   private PropertyChangeListener changeListener = null;
/*  34 */   int maximizedIndex = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MAX = -1;
/*     */ 
/*     */   
/*     */   private static final int MIN = -2;
/*     */ 
/*     */ 
/*     */   
/*     */   public DialogPanel() {
/*  46 */     this.owner = null;
/*  47 */     double[][] size = { { 300.0D }, { -2.0D } };
/*  48 */     this.layout = new TableLayout(size);
/*  49 */     setLayout((LayoutManager)this.layout);
/*  50 */     addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(1));
/*     */   }
/*     */   
/*     */   public DialogPanel(int width, PropertyChangeListener _changeListener) {
/*  54 */     this.owner = null;
/*  55 */     this.changeListener = _changeListener;
/*  56 */     this.windowWidth = width;
/*  57 */     double[][] size = { { width }, { -2.0D } };
/*  58 */     this.layout = new TableLayout(size);
/*  59 */     setLayout((LayoutManager)this.layout);
/*  60 */     addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(1));
/*     */   }
/*     */   
/*     */   public DialogPanel(JScrollPane owner, int width) {
/*  64 */     this.owner = owner;
/*  65 */     this.windowWidth = width;
/*  66 */     double[][] size = { { this.windowWidth }, { -2.0D } };
/*  67 */     this.layout = new TableLayout(size);
/*  68 */     setLayout((LayoutManager)this.layout);
/*  69 */     addMouseWheelListener((MouseWheelListener)new MyMouseWheelListener(1));
/*     */   }
/*     */ 
/*     */   
/*     */   public int addDialog(JPanel dialog, String titleText) {
/*  74 */     BaseDialog baseDialog = new BaseDialog(dialog, titleText, this.changeListener, this.windowWidth);
/*  75 */     if (this.dialogList.size() == 0) {
/*  76 */       add(baseDialog, "0,0");
/*     */     } else {
/*  78 */       this.layout.insertRow(this.dialogList.size(), -2.0D);
/*  79 */       add(baseDialog, "0," + Integer.valueOf(this.dialogList.size()).toString());
/*     */     } 
/*  81 */     this.dialogList.add(baseDialog);
/*  82 */     this.windowHeight += baseDialog.getHeight();
/*  83 */     this.panelSize.setSize(this.windowWidth, this.windowHeight);
/*  84 */     setPreferredSize(this.panelSize);
/*  85 */     setSize(this.panelSize);
/*     */     
/*  87 */     return this.dialogList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertyChangeListener(PropertyChangeListener _changeListener) {
/*  96 */     this.changeListener = _changeListener;
/*     */   }
/*     */   
/*     */   public void setOwner(JScrollPane s) {
/* 100 */     this.owner = s;
/*     */   }
/*     */   
/*     */   public int setMaximized(int dialogNr) {
/* 104 */     this.maximizedIndex = setState(dialogNr, -1);
/* 105 */     return this.maximizedIndex;
/*     */   }
/*     */   
/*     */   public int setMinimized(int dialogNr) {
/* 109 */     return setState(dialogNr, -2);
/*     */   }
/*     */   
/*     */   public int setMaximized(String dialogTitle) {
/* 113 */     return setState(dialogTitle, -1);
/*     */   }
/*     */   
/*     */   public int setMinimized(String dialogTitle) {
/* 117 */     return setState(dialogTitle, -2);
/*     */   }
/*     */   
/*     */   public void minimizeAllBut(int dialogNr) {
/* 121 */     minimizeAll();
/* 122 */     setMaximized(dialogNr);
/*     */   }
/*     */   
/*     */   public void maximizeAll() {
/* 126 */     for (int i = 0; i < this.dialogList.size(); i++) {
/* 127 */       setMaximized(i);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void minimizeAll() {
/* 133 */     for (int i = 0; i < this.dialogList.size(); i++) {
/* 134 */       setMinimized(i);
/*     */     }
/*     */   }
/*     */   
/*     */   public BaseDialog getDialog(int dialogNr) {
/* 139 */     if (dialogNr >= 0 && dialogNr < this.dialogList.size()) {
/* 140 */       return this.dialogList.get(dialogNr);
/*     */     }
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaximizedIndex() {
/* 147 */     return this.maximizedIndex;
/*     */   }
/*     */   
/*     */   public int getDialogCount() {
/* 151 */     return this.dialogList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int setState(int dialogNr, int state) {
/* 164 */     if (dialogNr < this.dialogList.size() || dialogNr < 0) {
/* 165 */       BaseDialog b = this.dialogList.get(dialogNr);
/* 166 */       switch (state) {
/*     */         case -1:
/* 168 */           b.setMaximized();
/* 169 */           return dialogNr;
/*     */         
/*     */         case -2:
/* 172 */           b.setMinimized();
/* 173 */           return dialogNr;
/*     */       } 
/*     */       
/* 176 */       LOG.warn("DialogPanel.setState(int,int): Wrong Parameter state");
/* 177 */       return -1;
/*     */     } 
/*     */     
/* 180 */     LOG.warn("Index for dialogList out of range");
/* 181 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int setState(String dialogTitle, int state) {
/* 194 */     LOG.debug("SetState (String,int) called");
/*     */     
/* 196 */     for (int i = 0; i < this.dialogList.size(); i++) {
/*     */       
/* 198 */       BaseDialog b = this.dialogList.get(i);
/* 199 */       Dimension d = new Dimension();
/* 200 */       if (b.getDialogTitleText() == dialogTitle) {
/* 201 */         int newHeight; switch (state) {
/*     */           case -1:
/* 203 */             b.setMaximized();
/* 204 */             d.height = getHeight() + b.getHeight();
/* 205 */             d.width = getWidth();
/* 206 */             setPreferredSize(d);
/* 207 */             return i;
/*     */           case -2:
/* 209 */             newHeight = b.getHeight();
/* 210 */             b.setMinimized();
/*     */ 
/*     */             
/* 213 */             newHeight -= b.getHeight();
/*     */             
/* 215 */             d.height = getHeight() - newHeight;
/* 216 */             d.width = getWidth();
/* 217 */             setPreferredSize(d);
/* 218 */             return i;
/*     */         } 
/* 220 */         return -1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 225 */     return -1;
/*     */   }
/*     */   
/*     */   public void redraw() {
/* 229 */     invalidate();
/* 230 */     validate();
/* 231 */     if (this.owner != null) {
/* 232 */       this.owner.invalidate();
/* 233 */       this.owner.validate();
/*     */     } 
/*     */     
/* 236 */     if (this.changeListener != null) {
/* 237 */       this.changeListener.propertyChange(new PropertyChangeEvent(this, "height", Integer.valueOf(0), Integer.valueOf(0)));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPanelHeight() {
/* 243 */     int height = 0;
/* 244 */     for (int i = 0; i < this.dialogList.size(); i++) {
/* 245 */       height += ((BaseDialog)this.dialogList.get(i)).getHeight();
/*     */     }
/* 247 */     this.windowHeight = height;
/* 248 */     this.panelSize.setSize(this.windowWidth, this.windowHeight);
/* 249 */     setPreferredSize(this.panelSize);
/* 250 */     setSize(this.panelSize);
/* 251 */     return height;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/dialog/DialogPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */