/*     */ package GUI.dialog;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.border.Border;
/*     */ 
/*     */ public class DialogTitle
/*     */   extends JPanel {
/*     */   private int width;
/*     */   private int height;
/*     */   private static final long serialVersionUID = 1L;
/*  20 */   private JLabel jLabel = null;
/*     */   private String text;
/*  22 */   private JButton jButtonMinimize = null;
/*  23 */   private JButton jButtonMaximize = null;
/*  24 */   private MouseListener listener = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DialogTitle(String text, int width, int height, MouseListener listener) {
/*  31 */     this.width = width;
/*  32 */     this.height = height;
/*  33 */     this.text = text;
/*  34 */     initialize();
/*     */     
/*  36 */     this.listener = listener;
/*  37 */     addMouseListener(listener);
/*  38 */     if (this.jLabel != null) {
/*  39 */       this.jLabel.addMouseListener(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  49 */     this.jLabel = new JLabel();
/*  50 */     this.jLabel.setBounds(new Rectangle(6, 0, 194, this.height));
/*  51 */     this.jLabel.addMouseListener(this.listener);
/*  52 */     Border bd = BorderFactory.createEtchedBorder();
/*  53 */     setBorder(bd);
/*  54 */     this.jLabel.setText(this.text);
/*  55 */     setBackground(new Color(200, 200, 200));
/*     */     
/*  57 */     setSize(this.width, this.height);
/*  58 */     setPreferredSize(new Dimension(this.width, this.height));
/*  59 */     setLayout((LayoutManager)null);
/*  60 */     add(this.jLabel, (Object)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonMinimize() {
/*  69 */     if (this.jButtonMinimize == null) {
/*  70 */       this.jButtonMinimize = new JButton();
/*  71 */       this.jButtonMinimize.setBounds(new Rectangle(this.width - 102, 2, 50, this.height - 4));
/*  72 */       this.jButtonMinimize.setText("min");
/*  73 */       this.jButtonMinimize.setFont(new Font("Sans-Serif", 0, 8));
/*     */       
/*  75 */       this.jButtonMinimize.setActionCommand("Min");
/*  76 */       this.jButtonMinimize.setToolTipText("Minimieren");
/*     */     } 
/*     */     
/*  79 */     return this.jButtonMinimize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getJButtonMaximize() {
/*  88 */     if (this.jButtonMaximize == null) {
/*  89 */       this.jButtonMaximize = new JButton();
/*  90 */       this.jButtonMaximize.setBounds(new Rectangle(this.width - 52, 2, 50, this.height - 4));
/*  91 */       this.jButtonMaximize.setText("max");
/*  92 */       this.jButtonMaximize.setActionCommand("Max");
/*  93 */       this.jButtonMaximize.setFont(new Font("Sans-Serif", 0, 8));
/*  94 */       this.jButtonMaximize.setToolTipText("Maximieren");
/*     */     } 
/*  96 */     return this.jButtonMaximize;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getSize() {
/* 101 */     return new Dimension(this.width, this.height);
/*     */   }
/*     */   
/*     */   public String getDialogTitleText() {
/* 105 */     return this.text;
/*     */   }
/*     */   
/*     */   public void setDialogTitleText(String text) {
/* 109 */     this.text = text;
/* 110 */     this.jLabel.setText(this.text);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/dialog/DialogTitle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */