/*     */ package GUI.dialog;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.event.SwingPropertyChangeSupport;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseDialog
/*     */   extends JPanel
/*     */   implements ActionListener, MouseListener, PropertyChangeListener
/*     */ {
/*     */   private static final long serialVersionUID = 7442634200743439364L;
/*  33 */   private JPanel jPanelContent = null;
/*  34 */   private int minHeight = 25;
/*  35 */   private int minWidth = 400;
/*     */   private Dimension minDim;
/*     */   private Dimension maxDim;
/*     */   private String title;
/*  39 */   private JLabel titleLabel = null;
/*     */   private boolean isMinimized = true;
/*  41 */   private SwingPropertyChangeSupport changes = new SwingPropertyChangeSupport(this, true);
/*  42 */   private Image bgImage = null;
/*  43 */   public static Color minColor = new Color(178, 175, 255);
/*  44 */   public static Color maxColor = new Color(38, 31, 255);
/*     */ 
/*     */   
/*     */   public BaseDialog(JPanel content, String title, PropertyChangeListener l, int width) {
/*  48 */     this.minWidth = width;
/*  49 */     double titleWidth = (width - 8);
/*  50 */     double[][] size = { { 4.0D, titleWidth, 4.0D }, { 2.0D, 26.0D, 2.0D, -2.0D } };
/*  51 */     TableLayout layout = new TableLayout(size);
/*  52 */     setLayout((LayoutManager)layout);
/*     */     
/*  54 */     if (title != null) {
/*  55 */       setDialogTitleText(title);
/*     */     }
/*  57 */     add(content, "1,3");
/*  58 */     if (content instanceof PropertyChangePanel) {
/*  59 */       ((PropertyChangePanel)content).addPropertyChangeListener(this);
/*     */     }
/*  61 */     addPropertyChangeListener(l);
/*  62 */     this.jPanelContent = content;
/*  63 */     initialize2(content);
/*  64 */     this.jPanelContent.setVisible(true);
/*  65 */     this.jPanelContent.validate();
/*     */   }
/*     */   
/*     */   private void initialize2(JPanel content) {
/*  69 */     Dimension d = content.getPreferredSize();
/*  70 */     this.minWidth = (int)d.getWidth();
/*  71 */     this.minDim = new Dimension(this.minWidth, this.minHeight);
/*  72 */     this.maxDim = new Dimension(this.minWidth, (int)(this.minHeight + d.getHeight()));
/*  73 */     setMinimumSize(this.minDim);
/*  74 */     setMaximumSize(this.maxDim);
/*  75 */     setPreferredSize(this.minDim);
/*  76 */     setSize(this.minDim);
/*  77 */     setOpaque(false);
/*  78 */     setBackground(new Color(214, 223, 247));
/*     */     
/*  80 */     this.bgImage = Toolkit.getDefaultToolkit().getImage("resoures" + 
/*  81 */         System.getProperty("file.separator") + "bg_title.png");
/*  82 */     if (this.bgImage == null) {
/*  83 */       System.out.printf("kein bgimage on %s \n", new Object[] { this.title });
/*     */     }
/*     */   }
/*     */   
/*     */   public String getDialogTitleText() {
/*  88 */     return this.title;
/*     */   }
/*     */   
/*     */   public void setDialogTitleText(String text) {
/*  92 */     this.title = "  " + text;
/*  93 */     this.titleLabel = new JLabel(this.title);
/*  94 */     this.titleLabel.setOpaque(true);
/*  95 */     Border b = BorderFactory.createEtchedBorder();
/*  96 */     this.titleLabel.setBorder(b);
/*  97 */     add(this.titleLabel, "1,1");
/*  98 */     this.titleLabel.setBackground(minColor);
/*  99 */     this.titleLabel.setForeground(Color.BLACK);
/* 100 */     Font f = this.titleLabel.getFont();
/* 101 */     f = f.deriveFont(0);
/* 102 */     this.titleLabel.setFont(f);
/* 103 */     this.titleLabel.addMouseListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/* 114 */     String cmd = e.getActionCommand();
/* 115 */     if (cmd.equals("Max") && this.isMinimized) {
/* 116 */       setMaximized();
/* 117 */       this.changes.firePropertyChange("height", 0, this.jPanelContent.getHeight());
/*     */     } 
/* 119 */     if (cmd.equals("Min") && !this.isMinimized) {
/* 120 */       setMinimized();
/* 121 */       this.changes.firePropertyChange("height", this.jPanelContent.getHeight(), 0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setMinimized() {
/* 126 */     if (getHeight() > this.minHeight + 1) {
/* 127 */       this.jPanelContent.repaint();
/* 128 */       setPreferredSize(this.minDim);
/* 129 */       setSize(this.minDim);
/* 130 */       this.isMinimized = true;
/* 131 */       this.titleLabel.setBackground(minColor);
/* 132 */       this.titleLabel.setForeground(Color.BLACK);
/* 133 */       Font f = this.titleLabel.getFont();
/* 134 */       f = f.deriveFont(0);
/* 135 */       this.titleLabel.setFont(f);
/*     */       
/* 137 */       this.isMinimized = true;
/*     */     } 
/*     */     
/* 140 */     this.jPanelContent.setVisible(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent e) {
/* 145 */     setMaximized();
/*     */   }
/*     */   
/*     */   public void setMaximized() {
/* 149 */     if (getHeight() <= this.minHeight + 1) {
/* 150 */       LayoutManager l = this.jPanelContent.getLayout();
/* 151 */       if (l instanceof TableLayout) {
/* 152 */         Dimension d = ((TableLayout)l).preferredLayoutSize(this.jPanelContent);
/* 153 */         this.jPanelContent.setPreferredSize(d);
/* 154 */         this.jPanelContent.setSize(d);
/* 155 */         l = getLayout();
/* 156 */         d = ((TableLayout)l).preferredLayoutSize(this);
/* 157 */         setPreferredSize(d);
/* 158 */         setSize(d);
/* 159 */         this.titleLabel.setBackground(maxColor);
/* 160 */         this.titleLabel.setForeground(Color.WHITE);
/* 161 */         Font f = this.titleLabel.getFont();
/* 162 */         f = f.deriveFont(1);
/* 163 */         this.titleLabel.setFont(f);
/*     */       } 
/*     */       
/* 166 */       this.jPanelContent.repaint();
/* 167 */       this.isMinimized = false;
/*     */     } 
/* 169 */     this.jPanelContent.setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkComponentSize(JPanel c) {
/* 178 */     Dimension size = c.getSize();
/*     */     
/* 180 */     if (!c.isPreferredSizeSet() && size.getWidth() > 0.0D && size.getHeight() > 0.0D) {
/* 181 */       c.setPreferredSize(size);
/* 182 */       c.setMinimumSize(new Dimension(0, 0));
/* 183 */       c.setMaximumSize(size);
/* 184 */       c.validate();
/* 185 */       return true;
/*     */     } 
/*     */     
/* 188 */     if (c.isPreferredSizeSet() && size.getWidth() == 0.0D && size.getHeight() == 0.0D) {
/* 189 */       c.setSize(c.getPreferredSize());
/* 190 */       c.setMinimumSize(new Dimension(0, 0));
/* 191 */       c.setMaximumSize(size);
/* 192 */       c.validate();
/* 193 */       return true;
/*     */     } 
/* 195 */     if (c.isPreferredSizeSet() && size.getWidth() > 0.0D && size.getHeight() > 0.0D) {
/*     */       
/* 197 */       c.setMinimumSize(new Dimension(0, 0));
/* 198 */       c.setMaximumSize(size);
/* 199 */       return true;
/*     */     } 
/* 201 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 207 */     if (this.isMinimized) {
/* 208 */       return this.minHeight;
/*     */     }
/* 210 */     if (this.jPanelContent != null) {
/* 211 */       LayoutManager l = this.jPanelContent.getLayout();
/* 212 */       l.layoutContainer(this.jPanelContent);
/* 213 */       Dimension d = l.preferredLayoutSize(this.jPanelContent);
/* 214 */       this.jPanelContent.setMaximumSize(d);
/* 215 */       this.jPanelContent.setPreferredSize(d);
/* 216 */       int height = this.minHeight + (int)d.getHeight() + 4;
/* 217 */       TableLayout tL = (TableLayout)getLayout();
/* 218 */       tL.setRow(3, d.getHeight());
/* 219 */       return height;
/* 220 */     }  if (this.minDim != null) {
/* 221 */       return (int)this.minDim.getHeight();
/*     */     }
/*     */     
/* 224 */     return this.minHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener l) {
/* 230 */     this.changes.addPropertyChangeListener(l);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener l) {
/* 235 */     this.changes.addPropertyChangeListener(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {
/* 242 */     if (this.isMinimized) {
/* 243 */       setMaximized();
/* 244 */       this.changes.firePropertyChange("height", 0, this.jPanelContent.getHeight());
/*     */     } else {
/* 246 */       setMinimized();
/* 247 */       this.changes.firePropertyChange("height", this.jPanelContent.getHeight(), 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintComponent(Graphics g) {
/* 273 */     g.drawImage(this.bgImage, 0, 0, null);
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/dialog/BaseDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */