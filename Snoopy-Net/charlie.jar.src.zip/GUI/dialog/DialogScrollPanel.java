/*    */ package GUI.dialog;
/*    */ 
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DialogScrollPanel
/*    */   extends JPanel
/*    */ {
/*    */   private static final long serialVersionUID = 2886974508574548920L;
/* 13 */   DialogPanel dialogPanel = null;
/*    */   JLabel label;
/*    */   
/*    */   public DialogScrollPanel(int height, int width) {}
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/dialog/DialogScrollPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */