/*    */ package GUI.dialog;
/*    */ 
/*    */ import java.beans.PropertyChangeListener;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.event.SwingPropertyChangeSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyChangePanel
/*    */   extends JPanel
/*    */ {
/*    */   private static final long serialVersionUID = -655259827232895995L;
/* 15 */   private SwingPropertyChangeSupport changes = new SwingPropertyChangeSupport(this, true);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addPropertyChangeListener(PropertyChangeListener listener) {
/* 22 */     this.changes.addPropertyChangeListener(listener);
/*    */   }
/*    */ 
/*    */   
/*    */   public void removePropertyChangeListener(PropertyChangeListener listener) {
/* 27 */     this.changes.addPropertyChangeListener(listener);
/*    */   }
/*    */   
/*    */   public void propertyChanged(String propertyName, int fromValue, int toValue) {
/* 31 */     this.changes.firePropertyChange(propertyName, fromValue, toValue);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/dialog/PropertyChangePanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */