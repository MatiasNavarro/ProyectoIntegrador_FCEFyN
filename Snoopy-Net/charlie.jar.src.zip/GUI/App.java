/*      */ package GUI;
/*      */ import GUI.app_components.ComputationalDialog;
/*      */ import GUI.app_components.DeadlockTrapComputationDialog;
/*      */ import GUI.app_components.InvariantComputationDialog;
/*      */ import GUI.app_components.NetPropertiesDialog;
/*      */ import GUI.app_components.StartDialog;
/*      */ import GUI.debug.DebugCounter;
/*      */ import GUI.io.FileSaver;
/*      */ import GUI.markingeditor2.MarkingEditor;
/*      */ import GUI.preference.DeadlockFilterPanel;
/*      */ import GUI.preference.FilterFactory;
/*      */ import GUI.preference.FilterProperties;
/*      */ import GUI.preference.IFilterPreferenceDirector;
/*      */ import GUI.preference.InvariantFilterPanel;
/*      */ import GUI.preference.Preference;
/*      */ import GUI.preference.PreferenceFactory;
/*      */ import GUI.rggui.RGGui;
/*      */ import GUI.util.FileDisplayDialog;
/*      */ import GUI.util.FileLoadingProgressListener;
/*      */ import GUI.util.IProgressListener;
/*      */ import GUI.util.JOptionPaneConstantInterface;
/*      */ import GUI.util.PropertyIo;
/*      */ import GUI.util.ResourceLoader;
/*      */ import GUI.util.StackTracePrinter;
/*      */ import charlie.analyzer.AnalyzerManagerFactory;
/*      */ import charlie.analyzer.OptionSet;
/*      */ import charlie.plugin.Plugin;
/*      */ import charlie.plugin.PluginLoader;
/*      */ import charlie.plugin.analyzer.PluginAnalyzer;
/*      */ import charlie.plugin.analyzer.PluginResult;
/*      */ import charlie.plugin.analyzer.PluginRuleExtender;
/*      */ import charlie.plugin.director.PluginDirector;
/*      */ import charlie.plugin.director.PluginFilterPreferencePanel;
/*      */ import charlie.plugin.gui.PluginComputationalDialog;
/*      */ import charlie.plugin.io.PluginImportFactory;
/*      */ import charlie.plugin.io.PluginPlaceTransitionNetReader;
/*      */ import charlie.pn.ConstantInterface;
/*      */ import charlie.pn.Out;
/*      */ import charlie.pn.PetriNetReader;
/*      */ import charlie.pn.PetriNetReaderFactory;
/*      */ import charlie.pn.Place;
/*      */ import charlie.pn.PlaceTransitionNet;
/*      */ import charlie.pn.Result;
/*      */ import charlie.pn.ResultManager;
/*      */ import charlie.pn.Results;
/*      */ import charlie.pn.Transition;
/*      */ import charlie.pn.UnsupportedFormatException;
/*      */ import charlie.pn.rules.Rule;
/*      */ import charlie.util.ConsoleWindowProtocol;
/*      */ import charlie.util.DirectorManager;
/*      */ import charlie.util.IProtocol;
/*      */ import charlie.util.ReaderFileImportMessage;
/*      */ import charlie.vis.Session;
/*      */ import java.awt.Component;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.net.URL;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JMenu;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.ToolTipManager;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class App implements IAppDirector, IFilterPreferenceDirector {
/*   75 */   private static final Log LOG = LogFactory.getLog(App.class);
/*      */   
/*   77 */   private final String titleString = String.format(" Charlie (%s) - ", new Object[] { App.class
/*   78 */         .getPackage().getImplementationVersion() });
/*      */   
/*      */   boolean loadedOnce = false;
/*   81 */   private AppFrame application = null;
/*   82 */   private MarkingEditor markingEditor = null;
/*   83 */   private NetPropertiesDialog netPropertiesDialog = null;
/*   84 */   private InvariantComputationDialog invariantComputationDialog = null;
/*   85 */   private DeadlockTrapComputationDialog deadlockComputationDialog = null;
/*      */   
/*   87 */   private RGGui rgGui = null;
/*   88 */   private PlaceTransitionNet pn = null;
/*   89 */   private File netFile = null;
/*   90 */   private File tempFile = null;
/*   91 */   private File originalNetFile = null;
/*   92 */   private Properties properties = null;
/*   93 */   private URL propertiesURL = ResourceLoader.getURL("app_properties.xml");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   99 */   private PetriNetReader lastReader = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  104 */   private final List<String> analyzerList = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  109 */   private final HashMap<String, JPanel> analyzerFilterPanelMap = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   private final List<PluginComputationalDialog> pluginDialogList = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  119 */   private final List<PluginDirector> pluginDirectorList = new ArrayList<>();
/*      */   
/*  121 */   private IProgressListener<File> progressListener = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] argv) {
/*      */     try {
/*      */       String loadFile;
/*  132 */       Runtime r = Runtime.getRuntime();
/*  133 */       URL url = ResourceLoader.getURL("GUI/App.class");
/*  134 */       if (url != null) {
/*  135 */         LOG.debug(String.format("url: %s", new Object[] { url.toString() }));
/*      */       }
/*  137 */       LOG.debug(String.format("processors: %d", new Object[] { Integer.valueOf(r.availableProcessors()) }));
/*      */       
/*  139 */       App app = new App();
/*      */       
/*  141 */       if (argv.length > 0) {
/*  142 */         LOG.debug(String.format("Loading file: %s", new Object[] { argv[0] }));
/*  143 */         loadFile = argv[0];
/*      */       } else {
/*  145 */         loadFile = null;
/*      */       } 
/*      */       
/*  148 */       app.initialize(loadFile);
/*  149 */     } catch (Exception e) {
/*  150 */       LOG.error(e.getMessage(), e);
/*      */       
/*  152 */       int answ = JOptionPane.showConfirmDialog(new JFrame(), "The following exeption was thrown:\n" + e
/*      */           
/*  154 */           .getClass().getName() + "\nStacktrace can be found in charlieError.log.\n Do you want to continue working!", "An error occured!", 0, 0);
/*      */ 
/*      */       
/*  157 */       DebugCounter.inc(StackTracePrinter.getStackTrace(e));
/*  158 */       DebugCounter.writeLog(new File("charlieError.log"));
/*  159 */       if (answ != 0) {
/*  160 */         JOptionPane.showMessageDialog(null, "Exiting program... via System.exit()");
/*  161 */         System.exit(1);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void initialize(String _fileName) {
/*  168 */     StartDialog s = new StartDialog(false);
/*  169 */     URL url = ResourceLoader.getURL("help/about.html");
/*      */     
/*  171 */     if (url != null) {
/*      */       try {
/*  173 */         File htmlFile = new File(url.toURI());
/*  174 */         if (htmlFile == null) {
/*  175 */           LOG.error("htmlFile == null");
/*      */         }
/*  177 */         s.showStart(htmlFile, "Loading last session please wait!");
/*  178 */       } catch (Exception e) {
/*  179 */         LOG.error(e.getMessage(), e);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  184 */     ToolTipManager.sharedInstance().setInitialDelay(0);
/*  185 */     ToolTipManager.sharedInstance().setDismissDelay(2147483647);
/*      */ 
/*      */     
/*  188 */     DirectorManager.registerDirector(this);
/*      */     
/*  190 */     Out.setProtocol((IProtocol)new ConsoleWindowProtocol());
/*      */     
/*  192 */     FilterFactory.setFilterProperties(new FilterProperties());
/*      */     
/*  194 */     PetriNetReaderFactory.initReaders();
/*  195 */     this.application = new AppFrame(this);
/*      */     
/*  197 */     this.progressListener = (IProgressListener<File>)new FileLoadingProgressListener((JFrame)this.application);
/*      */ 
/*      */     
/*      */     try {
/*  201 */       if (this.propertiesURL != null) {
/*  202 */         File propertyFile = new File(this.propertiesURL.toURI());
/*  203 */         if (propertyFile != null) {
/*  204 */           loadProperties(propertyFile.toString());
/*  205 */           this.application.setProperties(this.properties);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  212 */       if (_fileName != null && !_fileName.trim().equals("")) {
/*  213 */         Thread.sleep(300L);
/*  214 */         sendMessage(1, this, new File(_fileName));
/*      */       } 
/*  216 */     } catch (Exception e) {
/*  217 */       DebugCounter.inc("Could not find app properties file!");
/*  218 */       LOG.error(e.getMessage(), e);
/*      */     } 
/*      */     
/*  221 */     if (Boolean.getBoolean(Preference.AUTO_CHECK_FOR_UPDATES.getKey())) {
/*  222 */       update(false);
/*      */     }
/*      */     
/*  225 */     this.markingEditor = new MarkingEditor(null, this);
/*  226 */     this.markingEditor.initialize();
/*  227 */     this.markingEditor.alignToParentWindow((JFrame)this.application);
/*  228 */     JPanel externalMarkingDialog = (JPanel)this.markingEditor.externalMessage(10, this, null);
/*      */     
/*  230 */     this.application.addDialog(externalMarkingDialog, "marking editor");
/*      */     
/*  232 */     this.invariantComputationDialog = new InvariantComputationDialog(this);
/*  233 */     this.invariantComputationDialog.initialize();
/*  234 */     this.application.addDialog((JPanel)this.invariantComputationDialog, "IM-based analysis");
/*  235 */     InvariantFilterPanel invariantPrefsPanel = new InvariantFilterPanel(this);
/*  236 */     invariantPrefsPanel.initialize();
/*  237 */     this.analyzerList.add(invariantPrefsPanel.getAnalyzerName());
/*  238 */     this.analyzerFilterPanelMap.put(invariantPrefsPanel.getAnalyzerName(), invariantPrefsPanel);
/*      */     
/*  240 */     this.deadlockComputationDialog = new DeadlockTrapComputationDialog(this);
/*  241 */     this.deadlockComputationDialog.initialize();
/*  242 */     this.application.addDialog((JPanel)this.deadlockComputationDialog, "siphon/trap computation");
/*  243 */     DeadlockFilterPanel deadlockPrefsPanel = new DeadlockFilterPanel(this);
/*  244 */     deadlockPrefsPanel.initialize();
/*  245 */     this.analyzerList.add(deadlockPrefsPanel.getAnalyzerName());
/*  246 */     this.analyzerFilterPanelMap.put(deadlockPrefsPanel.getAnalyzerName(), deadlockPrefsPanel);
/*      */     
/*  248 */     this.rgGui = new RGGui((JFrame)this.application, this);
/*  249 */     this.application.addDialog(this.rgGui.getExternalDialog(), "reachability/coverability graph");
/*  250 */     JPanel p = this.rgGui.getExternalMCDialog();
/*  251 */     if (p == null) {
/*  252 */       JOptionPane.showMessageDialog((Component)this.application, "could not initialze mc dialog");
/*      */     } else {
/*      */       
/*  255 */       this.application.addDialog(p, "model checking");
/*      */     } 
/*  257 */     this.application.addDialog(this.rgGui.getExternalPathDialog(), "path search");
/*      */ 
/*      */ 
/*      */     
/*  261 */     ResultManager.initialize();
/*      */ 
/*      */     
/*  264 */     PluginLoader pluginLoader = new PluginLoader();
/*  265 */     List<Plugin> pluginList = pluginLoader.getPluginList();
/*      */ 
/*      */     
/*  268 */     JMenu pluginAboutMenu = new JMenu("plugins");
/*      */     
/*  270 */     LOG.debug("initializing plugins");
/*      */     
/*  272 */     for (Plugin plugin : pluginList) {
/*      */ 
/*      */       
/*  275 */       if (plugin == null) {
/*  276 */         LOG.warn("plugin is null");
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  282 */       JMenuItem pluginItem = new JMenuItem(String.format("%s (%s)", new Object[] { plugin.getName(), plugin.getVersion() }));
/*  283 */       pluginItem.setEnabled(false);
/*  284 */       pluginAboutMenu.add(pluginItem);
/*      */       
/*  286 */       for (String clazzName : plugin.getAnalyzerClassNameList()) {
/*      */         try {
/*  288 */           if (LOG.isDebugEnabled()) {
/*  289 */             LOG.debug(String.format("Trying to add analyzer '%s'.", new Object[] { clazzName }));
/*      */           }
/*      */           
/*  292 */           PluginAnalyzer analyzer = plugin.getNewAnalyzer(clazzName);
/*  293 */           if (!analyzer.registerAnalyzer()) {
/*      */             
/*  295 */             LOG.error(String.format("The analyzer '%s' (%s) could not register itself.\n", new Object[] { analyzer
/*  296 */                     .getName(), analyzer
/*  297 */                     .getClass().getName() }));
/*  298 */             LOG.error("Stopped trying to load the plugin.");
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  303 */           if (LOG.isDebugEnabled()) {
/*  304 */             LOG.debug(String.format("Adding '%s' was successful.", new Object[] { clazzName }));
/*      */           }
/*  306 */         } catch (Exception e) {
/*  307 */           LOG.error(e.getMessage(), e);
/*  308 */         } catch (Error e) {
/*  309 */           LOG.fatal(e.getMessage(), e);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  314 */       for (String clazzName : plugin.getRuleEnhancerClassNameList()) {
/*      */         try {
/*  316 */           if (LOG.isDebugEnabled()) {
/*  317 */             LOG.debug(String.format("Trying to add rule enhancer '%s'.", new Object[] { clazzName }));
/*      */           }
/*      */           
/*  320 */           PluginRuleExtender ruleEnhancer = plugin.getNewRuleEnhancer(clazzName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  326 */           for (PluginResult result : ruleEnhancer.getAddionionalResults()) {
/*  327 */             if (!Results.addFurtherResults(result.getKey(), result.getAbbreviation(), result.getTooltip(), result
/*  328 */                 .getDescription(), result.isVisible())) {
/*  329 */               JOptionPane.showMessageDialog((Component)this.application, 
/*  330 */                   String.format("The further result %s could not be added.", new Object[] { result.toString() }), "Setup error", 0);
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  341 */           for (Rule rule : ruleEnhancer.getAdditionalRules()) {
/*  342 */             ResultManager.addRule(rule);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  349 */           if (LOG.isDebugEnabled()) {
/*  350 */             LOG.debug(String.format("Adding '%s' was successful.", new Object[] { clazzName }));
/*      */           }
/*  352 */         } catch (Exception e) {
/*  353 */           LOG.error(e.getMessage(), e);
/*  354 */         } catch (Error e) {
/*  355 */           LOG.fatal(e.getMessage(), e);
/*      */         } 
/*      */       } 
/*      */       
/*  359 */       for (String clazzName : plugin.getDialogClassNameList()) {
/*      */         try {
/*  361 */           if (LOG.isDebugEnabled()) {
/*  362 */             LOG.debug(String.format("Trying to add dialog '%s'.", new Object[] { clazzName }));
/*      */           }
/*      */           
/*  365 */           PluginComputationalDialog dialog = plugin.getNewDialog(this, clazzName);
/*  366 */           dialog.initialize();
/*      */           
/*  368 */           this.application.addDialog((JPanel)dialog, dialog.getDescription());
/*      */ 
/*      */ 
/*      */           
/*  372 */           this.pluginDialogList.add(dialog);
/*      */           
/*  374 */           if (LOG.isDebugEnabled()) {
/*  375 */             LOG.debug(String.format("Adding '%s' was successful.", new Object[] { clazzName }));
/*      */           }
/*  377 */         } catch (Exception e) {
/*  378 */           LOG.error(e.getMessage(), e);
/*  379 */         } catch (Error e) {
/*  380 */           LOG.fatal(e.getMessage(), e);
/*      */         } 
/*      */       } 
/*      */       
/*  384 */       for (String clazzName : plugin.getDirectorClassList()) {
/*      */         try {
/*  386 */           if (LOG.isDebugEnabled()) {
/*  387 */             LOG.debug(String.format("Trying to add director '%s'.", new Object[] { clazzName }));
/*      */           }
/*      */           
/*  390 */           PluginDirector director = plugin.getNewDirector(this, (JFrame)this.application, clazzName);
/*  391 */           director.initialize();
/*      */           
/*  393 */           this.application.addDialog(director.getExternalDialog(), director.getDescription());
/*      */           
/*  395 */           this.pluginDirectorList.add(director);
/*      */           
/*  397 */           if (LOG.isDebugEnabled()) {
/*  398 */             LOG.debug(String.format("Adding '%s' was successful.", new Object[] { clazzName }));
/*      */           }
/*  400 */         } catch (Exception e) {
/*  401 */           LOG.error(e.getMessage(), e);
/*  402 */         } catch (Error e) {
/*  403 */           LOG.fatal(e.getMessage(), e);
/*      */         } 
/*      */       } 
/*      */       
/*  407 */       for (String clazzName : plugin.getFilterPreferenceClassList()) {
/*      */         try {
/*  409 */           if (LOG.isDebugEnabled()) {
/*  410 */             LOG.debug(String.format("Trying to add filter preference '%s'.", new Object[] { clazzName }));
/*      */           }
/*      */           
/*  413 */           PluginFilterPreferencePanel panel = plugin.getNewFilterPreferencePanel(this, clazzName);
/*  414 */           panel.initialize();
/*      */           
/*  416 */           this.analyzerList.add(panel.getAnalyzerName());
/*  417 */           this.analyzerFilterPanelMap.put(panel.getAnalyzerName(), panel);
/*      */           
/*  419 */           if (LOG.isDebugEnabled()) {
/*  420 */             LOG.debug(String.format("Adding '%s' was successful.", new Object[] { clazzName }));
/*      */           }
/*  422 */         } catch (Exception e) {
/*  423 */           LOG.error(e.getMessage(), e);
/*  424 */         } catch (Error e) {
/*  425 */           LOG.fatal(e.getMessage(), e);
/*      */         } 
/*      */       } 
/*      */       
/*  429 */       for (String clazzName : plugin.getPlaceTransitionNetReaderClassList()) {
/*      */         try {
/*  431 */           if (LOG.isDebugEnabled()) {
/*  432 */             LOG.debug(String.format("Trying to add reader '%s'.", new Object[] { clazzName }));
/*      */           }
/*      */           
/*  435 */           PluginPlaceTransitionNetReader reader = plugin.getNewPlaceTransitionNetReader(clazzName);
/*      */           
/*  437 */           PluginImportFactory.getInstance().registerReader(reader);
/*      */           
/*  439 */           if (LOG.isDebugEnabled()) {
/*  440 */             LOG.debug(String.format("Adding '%s' was successful.", new Object[] { clazzName }));
/*      */           }
/*  442 */         } catch (Exception e) {
/*  443 */           LOG.error(e.getMessage(), e);
/*  444 */         } catch (Error e) {
/*  445 */           LOG.fatal(e.getMessage(), e);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  452 */     this.netPropertiesDialog = new NetPropertiesDialog();
/*  453 */     this.application.addDialog((JPanel)this.netPropertiesDialog, "net properties");
/*      */     
/*  455 */     this.application.setup();
/*  456 */     if (pluginAboutMenu.getMenuComponentCount() > 0) {
/*  457 */       this.application.getJMenuBar().getHelpMenu().add(pluginAboutMenu, 1);
/*  458 */       this.application.getJMenuBar().getHelpMenu().add(new JPopupMenu.Separator(), 1);
/*      */     } 
/*  460 */     this.application.setTitle(this.titleString);
/*  461 */     this.application.setVisible(true);
/*      */     
/*  463 */     Out.println(this.titleString + "\n");
/*      */     
/*  465 */     s.setVisible(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addLastFile(File _file) {
/*  477 */     if (_file.exists()) {
/*  478 */       this.application.addLastFile(_file);
/*      */       
/*  480 */       if (LOG.isDebugEnabled()) {
/*  481 */         LOG.debug(String.format("Adding file '%s' to the list of recently opened files.", new Object[] { _file
/*  482 */                 .getAbsolutePath() }));
/*      */       
/*      */       }
/*      */     }
/*  486 */     else if (LOG.isDebugEnabled()) {
/*  487 */       LOG.debug(String.format("File '%s' does not exist anymore. Thus it is not added to the list of recently opened files.", new Object[] { _file
/*      */               
/*  489 */               .getAbsolutePath() }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void update(boolean _informFail) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadProperties(String fileName) {
/*      */     try {
/*  553 */       this.properties = PropertyIo.loadProperties(fileName);
/*  554 */       if (this.properties != null) {
/*  555 */         String lastDir = this.properties.getProperty("lastdir");
/*  556 */         if (lastDir != null) {
/*  557 */           FileSaver.lastSaveDir = lastDir;
/*      */           
/*  559 */           LOG.debug(String.format("lastdir: %s", new Object[] { lastDir }));
/*      */         } 
/*      */         
/*  562 */         LOG.debug("loading preferences");
/*      */         
/*  564 */         String applyRules = this.properties.getProperty(Preference.APPLY_RULES_PROPERTY.getKey(), Preference.APPLY_RULES_PROPERTY
/*  565 */             .getDefault());
/*  566 */         LOG.debug(String.format("applyRules: " + applyRules, new Object[0]));
/*  567 */         PreferenceFactory.getPreferenceProperties().setProperty(Preference.APPLY_RULES_PROPERTY.getKey(), applyRules);
/*      */ 
/*      */         
/*  570 */         String writeLogFile = this.properties.getProperty(Preference.WRITE_LOG_FILE.getKey(), Preference.WRITE_LOG_FILE
/*  571 */             .getDefault());
/*  572 */         LOG.debug(String.format("writeLogFile: " + writeLogFile, new Object[0]));
/*  573 */         PreferenceFactory.getPreferenceProperties().setProperty(Preference.WRITE_LOG_FILE.getKey(), writeLogFile);
/*      */ 
/*      */         
/*  576 */         String autoCheckForUpdates = this.properties.getProperty(Preference.AUTO_CHECK_FOR_UPDATES.getKey(), Preference.AUTO_CHECK_FOR_UPDATES
/*  577 */             .getDefault());
/*  578 */         LOG.debug(String.format("autoCheckForUpdates: " + autoCheckForUpdates, new Object[0]));
/*  579 */         PreferenceFactory.getPreferenceProperties().setProperty(Preference.AUTO_CHECK_FOR_UPDATES.getKey(), autoCheckForUpdates);
/*      */ 
/*      */         
/*  582 */         String lastUsedIMFileFilter = this.properties.getProperty(Preference.IM_LAST_FILE_FORMAT_FILTER.getKey(), Preference.IM_LAST_FILE_FORMAT_FILTER
/*  583 */             .getDefault());
/*  584 */         LOG.debug(String.format("lastUsedIMFileFilter: " + lastUsedIMFileFilter, new Object[0]));
/*  585 */         PreferenceFactory.getPreferenceProperties().setProperty(Preference.IM_LAST_FILE_FORMAT_FILTER.getKey(), lastUsedIMFileFilter);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  590 */         String[] recentlyOpenedFiles = this.properties.getProperty(Preference.RECENT_FILES_PROPERTY.getKey(), Preference.RECENT_FILES_PROPERTY.getDefault()).split("§");
/*  591 */         for (String path : recentlyOpenedFiles) {
/*  592 */           File file = new File(path);
/*      */           
/*  594 */           LOG.debug(String.format("recentlyOpenedFiles: " + file.getAbsolutePath(), new Object[0]));
/*      */ 
/*      */           
/*  597 */           addLastFile(file);
/*      */         } 
/*      */       } 
/*      */       
/*  601 */       FilterFactory.setFilterProperties(new FilterProperties(PropertyIo.loadProperties((new File(fileName))
/*  602 */               .getParent() + File.separator + "filter_properties.xml")));
/*  603 */     } catch (Exception e) {
/*  604 */       LOG.error(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void saveProperties(File fileName) {
/*  619 */     if (this.properties == null) {
/*  620 */       this.properties = new Properties();
/*      */     }
/*      */     
/*  623 */     if (this.netFile != null) {
/*  624 */       this.properties.setProperty("lastdir", this.originalNetFile.getParent());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  629 */     this.properties.setProperty(Preference.APPLY_RULES_PROPERTY.getKey(), PreferenceFactory.getPreferenceProperties()
/*  630 */         .getProperty(Preference.APPLY_RULES_PROPERTY.getKey(), Preference.APPLY_RULES_PROPERTY.getDefault()));
/*      */ 
/*      */     
/*  633 */     this.properties.setProperty(Preference.AUTO_CHECK_FOR_UPDATES
/*  634 */         .getKey(), 
/*  635 */         PreferenceFactory.getPreferenceProperties().getProperty(Preference.AUTO_CHECK_FOR_UPDATES.getKey(), Preference.AUTO_CHECK_FOR_UPDATES
/*  636 */           .getDefault()));
/*      */ 
/*      */     
/*  639 */     this.properties.setProperty(Preference.WRITE_LOG_FILE.getKey(), PreferenceFactory.getPreferenceProperties()
/*  640 */         .getProperty(Preference.WRITE_LOG_FILE.getKey(), Preference.WRITE_LOG_FILE.getDefault()));
/*      */ 
/*      */     
/*  643 */     this.properties.setProperty(Preference.IM_LAST_FILE_FORMAT_FILTER
/*  644 */         .getKey(), 
/*  645 */         PreferenceFactory.getPreferenceProperties().getProperty(Preference.IM_LAST_FILE_FORMAT_FILTER.getKey(), Preference.IM_LAST_FILE_FORMAT_FILTER
/*  646 */           .getDefault()));
/*      */ 
/*      */     
/*  649 */     StringBuffer buffer = new StringBuffer();
/*      */ 
/*      */ 
/*      */     
/*  653 */     if (this.application.getLastFileList().size() > 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  659 */       for (int i = this.application.getLastFileList().size() - 1; i >= 0; i--) {
/*  660 */         File file = this.application.getLastFileList().get(i);
/*  661 */         buffer.append(file.getAbsolutePath()).append("§");
/*      */       } 
/*      */       
/*  664 */       buffer.deleteCharAt(buffer.length() - 1);
/*      */     } 
/*      */ 
/*      */     
/*  668 */     this.properties.setProperty(Preference.RECENT_FILES_PROPERTY.getKey(), buffer.toString());
/*      */     
/*      */     try {
/*  671 */       PropertyIo.storeProperties(this.properties, fileName, "charlieV2.0_properties");
/*  672 */       PropertyIo.storeProperties((Properties)FilterFactory.getFilterProperties(), fileName.getParent() + File.separator + "filter_properties.xml", "charlieV2.0_filter_properties");
/*      */     }
/*  674 */     catch (Exception e) {
/*  675 */       LOG.error("APP: storing of properties failed!", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadSession(File fileName) {
/*      */     try {
/*  687 */       Properties props = PropertyIo.loadProperties(fileName);
/*  688 */       String s = props.getProperty("netFile");
/*  689 */       if (s != null) {
/*  690 */         File net = new File(props.getProperty("netFile"));
/*  691 */         if (net.exists()) {
/*  692 */           sendMessage(1, this, net);
/*      */ 
/*      */ 
/*      */           
/*  696 */           addLastFile(net);
/*      */         } else {
/*  698 */           throw new Exception("could not load netfile");
/*      */         } 
/*      */       } else {
/*  701 */         throw new Exception("could not load netfile");
/*      */       } 
/*      */       
/*  704 */       s = props.getProperty("markingFile");
/*  705 */       if (s != null) {
/*  706 */         File markingFile = new File(props.getProperty("markingFile"));
/*  707 */         this.markingEditor.sendMessage(13, this, markingFile);
/*      */       } 
/*      */ 
/*      */       
/*  711 */       for (PluginDirector director : this.pluginDirectorList) {
/*  712 */         String sessionPropertyValue = props.getProperty(director.getSessionPropertyName());
/*      */         
/*  714 */         if (sessionPropertyValue != null) {
/*  715 */           File sessionFile = new File(sessionPropertyValue);
/*  716 */           director.externalMessage(9, this, sessionFile); continue;
/*      */         } 
/*  718 */         LOG.error(String.format("Could not load session. There is no entry for the property '%s'.", new Object[] { director
/*  719 */                 .getSessionPropertyName() }));
/*      */       }
/*      */     
/*  722 */     } catch (Exception e) {
/*  723 */       LOG.error("Could not load session.", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void saveSession(File fileName) {
/*  737 */     Properties props = new Properties();
/*  738 */     File markingFile = new File(fileName.getParent() + System.getProperty("file.separator") + fileName.getName() + ".markings");
/*      */     
/*  740 */     this.markingEditor.saveSession(markingFile);
/*  741 */     props.setProperty("markingFile", markingFile.getAbsolutePath());
/*  742 */     if (this.originalNetFile != null) {
/*  743 */       props.setProperty("netFile", this.originalNetFile.getAbsolutePath());
/*      */     }
/*      */     
/*  746 */     for (PluginDirector director : this.pluginDirectorList) {
/*      */       
/*  748 */       File sessionFile = new File(fileName.getParent() + File.separator + fileName.getName() + director.getSessionFileExtension());
/*  749 */       director.externalMessage(8, this, sessionFile);
/*      */       
/*  751 */       props.setProperty(director.getSessionPropertyName(), sessionFile.getAbsolutePath());
/*      */     } 
/*      */     
/*      */     try {
/*  755 */       PropertyIo.storeProperties(props, fileName, "charlie_v_1_1 session file");
/*  756 */     } catch (Exception e) {
/*  757 */       LOG.error("could not store session files", e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Object externalMessage(int _messageType, Object _source, Object _object) {
/*  768 */     switch (_messageType) {
/*      */       case 100:
/*  770 */         return this.analyzerList;
/*      */       case 101:
/*  772 */         return this.analyzerFilterPanelMap.get(_object);
/*      */     } 
/*      */     
/*  775 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized boolean sendMessage(int _messageType, Object _source, Object _object) {
/*      */     OptionSet options;
/*      */     String values[], snoopyPath;
/*      */     ReaderFileImportMessage message;
/*  783 */     LOG.debug("App.sendMessage ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  791 */     switch (_messageType) {
/*      */       case 12:
/*  793 */         debugNet();
/*      */         break;
/*      */       case 11:
/*  796 */         options = (OptionSet)_object;
/*  797 */         analyzeNet(options);
/*  798 */         checkBoundedness();
/*      */         break;
/*      */       case 7:
/*  801 */         values = (String[])_object;
/*  802 */         this.properties.setProperty(values[0], values[1]);
/*      */         
/*  804 */         sendToPluginDirectors(_messageType, _source, _object);
/*      */         break;
/*      */       case 6:
/*  807 */         LOG.debug("sendMessage. WINDOW_NORMALIZED");
/*  808 */         this.markingEditor.sendMessage(11, null, new Boolean(true));
/*      */         
/*  810 */         sendToPluginDirectors(_messageType, _source, _object);
/*      */         break;
/*      */       case 10:
/*  813 */         if (this.netFile == null) {
/*  814 */           return false;
/*      */         }
/*  816 */         snoopyPath = "";
/*  817 */         if (this.properties != null) {
/*  818 */           snoopyPath = this.properties.getProperty("snoopy_file");
/*      */         }
/*  820 */         if (snoopyPath == null || snoopyPath.equals("")) {
/*  821 */           return false;
/*      */         }
/*  823 */         snoopyPath = snoopyPath + " \"" + this.netFile.getPath() + "\"";
/*  824 */         DebugCounter.inc("snoopyPath: execution =" + snoopyPath);
/*      */         try {
/*  826 */           Runtime r = Runtime.getRuntime();
/*  827 */           r.exec(snoopyPath);
/*  828 */         } catch (IOException e) {
/*  829 */           LOG.error(String.format("could not start snoopy: %s" + snoopyPath, new Object[0]), e);
/*  830 */           return false;
/*      */         } 
/*  832 */         return true;
/*      */ 
/*      */       
/*      */       case 1:
/*  836 */         if (loadNet((File)_object)) {
/*  837 */           LOG.debug(" (NET LOADED ...");
/*  838 */           ConsoleWindow.clear();
/*  839 */           Out.println("Loaded: " + _object);
/*  840 */           Out.println(this.application.getTitle() + "\n");
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  845 */           addLastFile((File)_object);
/*  846 */           this.application.newNetLoaded((File)_object);
/*      */         } else {
/*  848 */           this.pn = null;
/*      */         } 
/*  850 */         this.markingEditor.externalMessage(5, this, this.pn);
/*  851 */         this.rgGui.setPN(this.pn);
/*  852 */         this.invariantComputationDialog.setPN(this.pn);
/*  853 */         this.deadlockComputationDialog.setPN(this.pn);
/*  854 */         this.netPropertiesDialog.setPN(this.pn);
/*  855 */         this.rgGui.setPN(this.pn);
/*      */ 
/*      */         
/*  858 */         for (ComputationalDialog cd : this.pluginDialogList) {
/*  859 */           cd.setPN(this.pn);
/*      */         }
/*      */         
/*  862 */         AnalyzerManagerFactory.getAnalyzerManager().resetAllAnalyzers();
/*      */ 
/*      */ 
/*      */         
/*  866 */         ResultManager.reset();
/*      */         
/*  868 */         checkBoundedness();
/*      */         
/*  870 */         sendToPluginDirectors(_messageType, _source, _object);
/*      */         
/*  872 */         return true;
/*      */       
/*      */       case 17:
/*  875 */         message = (ReaderFileImportMessage)_object;
/*  876 */         if (importNet(message.getFile(), message.getReaderId())) {
/*  877 */           LOG.debug(" (NET IMPORTED ...");
/*  878 */           ConsoleWindow.clear();
/*  879 */           Out.println(this.titleString + "\n");
/*      */         } else {
/*  881 */           this.pn = null;
/*      */         } 
/*      */         
/*  884 */         sendToPluginDirectors(_messageType, _source, _object);
/*      */ 
/*      */ 
/*      */         
/*  888 */         ResultManager.reset();
/*      */         
/*  890 */         sendMessage(14, this, this.pn);
/*      */         
/*  892 */         return true;
/*      */       case 14:
/*  894 */         this.pn = (PlaceTransitionNet)_object;
/*      */         
/*  896 */         this.markingEditor.externalMessage(5, this, this.pn);
/*  897 */         this.rgGui.setPN(this.pn);
/*  898 */         this.invariantComputationDialog.setPN(this.pn);
/*  899 */         this.deadlockComputationDialog.setPN(this.pn);
/*  900 */         this.netPropertiesDialog.setPN(this.pn);
/*      */ 
/*      */         
/*  903 */         for (ComputationalDialog cd : this.pluginDialogList) {
/*  904 */           cd.setPN(this.pn);
/*      */         }
/*      */         
/*  907 */         AnalyzerManagerFactory.getAnalyzerManager().resetAllAnalyzers();
/*  908 */         checkBoundedness();
/*      */         
/*  910 */         sendToPluginDirectors(_messageType, _source, _object);
/*      */         
/*  912 */         return true;
/*      */ 
/*      */       
/*      */       case 0:
/*  916 */         DebugCounter.inc("App.sendMessage(NET_UPDATED by " + _source.getClass().getName());
/*  917 */         if (_source instanceof MarkingEditor) {
/*      */           
/*  919 */           this.pn = (PlaceTransitionNet)_object;
/*  920 */           Out.println("marking changed (" + (new SimpleDateFormat()).format(new Date()) + "):");
/*  921 */           String m = this.markingEditor.getActualMarkingName();
/*  922 */           Out.println("marking set to: \n " + this.markingEditor.markingToText(2));
/*      */ 
/*      */ 
/*      */           
/*  926 */           this.netPropertiesDialog.netUpdated("marking set to: \n " + this.markingEditor.markingToText(2));
/*  927 */           checkBoundedness();
/*      */           
/*  929 */           sendToPluginDirectors(_messageType, _source, _object); break;
/*      */         } 
/*  931 */         DebugCounter.inc("AppDirector.sendMessage NET_UPDATE arrived from unknown source");
/*      */         break;
/*      */ 
/*      */       
/*      */       case 3:
/*  936 */         LOG.info("App gets message EXIT, cleaning up....");
/*  937 */         DebugCounter.inc("App gets message EXIT, cleaning up....");
/*  938 */         this.markingEditor.sendMessage(7, this, null);
/*      */         
/*  940 */         sendToPluginDirectors(_messageType, _source, _object);
/*      */         
/*  942 */         this.application.setVisible(false);
/*  943 */         this.application.dispose();
/*      */         
/*      */         try {
/*  946 */           DebugCounter.inc("storing program properties in: " + this.propertiesURL.toURI());
/*  947 */           saveProperties(new File(this.propertiesURL.toURI()));
/*  948 */         } catch (Exception e) {
/*  949 */           e.printStackTrace();
/*      */         } 
/*  951 */         if (this.tempFile != null && 
/*  952 */           this.tempFile.exists()) {
/*  953 */           this.tempFile.delete();
/*      */         }
/*      */         
/*  956 */         Session.removeTempDirs();
/*      */         
/*  958 */         writeLogFile();
/*  959 */         DebugCounter.writeLog(new File("charlie_log.txt"));
/*      */         
/*  961 */         System.exit(0);
/*      */         break;
/*      */       case 5:
/*  964 */         this.application.toFront();
/*      */         
/*  966 */         sendToPluginDirectors(_messageType, _source, _object);
/*      */         break;
/*      */       case 4:
/*  969 */         DebugCounter.inc("App.sendMessage() RELOAD_NET");
/*  970 */         if (this.originalNetFile != null) {
/*      */           
/*  972 */           loadNet(this.originalNetFile, this.lastReader);
/*  973 */           System.gc();
/*      */         } 
/*      */         
/*  976 */         sendToPluginDirectors(_messageType, _source, _object);
/*      */ 
/*      */ 
/*      */         
/*  980 */         ResultManager.reset();
/*      */         
/*  982 */         sendMessage(14, this, this.pn);
/*      */         break;
/*      */       
/*      */       case 8:
/*  986 */         saveSession((File)_object);
/*      */         break;
/*      */       case 9:
/*  989 */         loadSession((File)_object);
/*      */         break;
/*      */       case 15:
/*  992 */         return isNetLoaded();
/*      */       case 13:
/*  994 */         writeLogFile();
/*      */         break;
/*      */       case 16:
/*  997 */         update(true);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1003 */     checkBoundedness();
/*      */     
/* 1005 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<Object> sendToPluginDirectors(int _messageType, Object _source, Object _object) {
/* 1018 */     List<Object> answerList = new ArrayList();
/*      */     
/* 1020 */     for (PluginDirector d : this.pluginDirectorList) {
/* 1021 */       answerList.add(d.externalMessage(_messageType, _source, _object));
/*      */     }
/*      */     
/* 1024 */     return answerList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean importNet(File _file, String _readerId) {
/* 1040 */     PluginPlaceTransitionNetReader pluginPlaceTransitionNetReader = PluginImportFactory.getInstance().getReader(_readerId);
/*      */     
/* 1042 */     return loadNet(_file, (PetriNetReader)pluginPlaceTransitionNetReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean loadNet(File _file, PetriNetReader _reader) {
/* 1058 */     if (_file != null) {
/*      */       PlaceTransitionNet pNet;
/*      */       
/*      */       try {
/* 1062 */         this.progressListener.setInformation(_file);
/*      */         
/* 1064 */         _reader.init(_file.getAbsolutePath(), (ConstantInterface)new JOptionPaneConstantInterface());
/* 1065 */         _reader.readNet();
/* 1066 */         pNet = _reader.getPlaceTransitionNet();
/*      */ 
/*      */ 
/*      */         
/* 1070 */         this.lastReader = _reader;
/* 1071 */       } catch (Exception e) {
/*      */ 
/*      */         
/* 1074 */         JOptionPane.showMessageDialog(null, e.getMessage());
/* 1075 */         _reader.loadingFinished();
/* 1076 */         return false;
/*      */       } 
/*      */       
/* 1079 */       if (pNet != null && pNet.getPlaces().size() > 0) {
/* 1080 */         this.pn = pNet;
/* 1081 */         this.netFile = _file;
/* 1082 */         this.pn.setName(this.netFile.getName().substring(0, this.netFile.getName().lastIndexOf(".")));
/* 1083 */         this.originalNetFile = _file;
/* 1084 */         AnalyzerManagerFactory.getAnalyzerManager().resetAllAnalyzers();
/* 1085 */         this.application.setTitle(this.titleString + this.netFile.getName());
/*      */         
/* 1087 */         if (this.pn.containsNonStandardArcs()) {
/* 1088 */           JOptionPane.showMessageDialog((Component)this.application, "<html><center>The net contains non-standard arcs.<br>Analyses may provide wrong results!</center></html>", "notice", 0);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1093 */         _reader.loadingFinished();
/*      */         
/* 1095 */         return true;
/*      */       } 
/* 1097 */       JOptionPane.showMessageDialog((Component)this.application, "<html><p>Could not load place transition net from file </p><p>" + _file
/* 1098 */           .getName() + "</p><p> please check if the file contains a correct pt-net!</p></html>");
/*      */ 
/*      */       
/* 1101 */       _reader.loadingFinished();
/*      */       
/* 1103 */       return false;
/*      */     } 
/*      */     
/* 1106 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean loadNet(String _fileString) {
/* 1120 */     File f = new File(_fileString);
/* 1121 */     if (f.exists()) {
/* 1122 */       return loadNet(f);
/*      */     }
/* 1124 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean loadNet(File _file) {
/* 1137 */     if (_file != null) {
/* 1138 */       String fileName = _file.getName();
/* 1139 */       String extension = fileName.substring(fileName.lastIndexOf("."));
/*      */       
/*      */       try {
/* 1142 */         PetriNetReader pnr = PetriNetReaderFactory.getReader(extension);
/* 1143 */         pnr.addProgressListener(this.progressListener);
/* 1144 */         return loadNet(_file, pnr);
/* 1145 */       } catch (UnsupportedFormatException e) {
/* 1146 */         LOG.error(e.getMessage(), (Throwable)e);
/*      */       } 
/*      */     } 
/*      */     
/* 1150 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNetLoaded() {
/* 1159 */     return (this.pn != null);
/*      */   }
/*      */   
/*      */   public void setNet(PlaceTransitionNet net) {
/* 1163 */     this.pn = net;
/* 1164 */     AnalyzerManagerFactory.getAnalyzerManager().resetAllAnalyzers();
/* 1165 */     this.application.setTitle(this.titleString + this.netFile.getName());
/* 1166 */     DebugCounter.inc("loadNet(), PN = " + this.pn.getName() + " isTimed() " + this.pn.isTimedNet());
/* 1167 */     if (this.pn.containsNonStandardArcs())
/*      */     {
/* 1169 */       JOptionPane.showMessageDialog((Component)this.application, "<html><center>The net contains non-standard arcs.<br>Analyses may provide wrong results!</center></html>", "notice", 0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void analyzeNet(OptionSet options) {
/* 1177 */     LOG.debug("analyze " + options);
/* 1178 */     DebugCounter.inc("App.analyzeNet()");
/* 1179 */     if (options != null) {
/* 1180 */       int i = options.numberOfResults();
/* 1181 */       DebugCounter.inc("Number of results: " + i);
/* 1182 */       while (i > 0) {
/* 1183 */         i--;
/* 1184 */         Results results = options.getStageResult(i);
/* 1185 */         this.netPropertiesDialog.update(results);
/* 1186 */         if (!results.toString().equals("")) {
/* 1187 */           Out.println("Results from Analysis Stage " + i + " :\n" + results.toString());
/* 1188 */           Out.println("Output from Analyzers Stage " + i + " :\n" + results.getOutput());
/*      */         } 
/*      */       } 
/* 1191 */       this.netPropertiesDialog.update(options.getResults());
/*      */       
/* 1193 */       sendToPluginDirectors(11, this, options);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void checkBoundedness() {
/* 1198 */     LOG.debug(String.format("check B%n%s%n", new Object[] { this.netPropertiesDialog.getResults() }));
/*      */     
/* 1200 */     if (this.netPropertiesDialog.getResults().getResult(19) != null && this.netPropertiesDialog
/* 1201 */       .getResults().getResult(19).equals(new Result(new Boolean(true)))) {
/* 1202 */       this.rgGui.disableBoundednessCheck();
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeLogFile() {
/* 1207 */     if (this.pn == null) {
/* 1208 */       LOG.warn("PN = null");
/*      */       return;
/*      */     } 
/* 1211 */     String logContent = ConsoleWindow.getText();
/*      */     
/* 1213 */     logContent = logContent + "---------------FINAL RESULTS----------------------\n\n";
/* 1214 */     logContent = logContent + this.netPropertiesDialog.getResultTable();
/* 1215 */     logContent = logContent + "--------------------------------------------------\n";
/*      */     
/* 1217 */     String date = (new SimpleDateFormat()).format(new Date());
/* 1218 */     logContent = logContent + "Session finished: " + date + "\n";
/* 1219 */     StringTokenizer strt = new StringTokenizer(date, "/: .");
/* 1220 */     String logFile = FileSaver.lastSaveDir + File.separator + this.pn.getName();
/* 1221 */     while (strt.hasMoreTokens()) {
/* 1222 */       logFile = logFile + "_" + strt.nextToken();
/*      */     }
/* 1224 */     logFile = logFile + ".log";
/*      */     
/* 1226 */     if (Boolean.parseBoolean(PreferenceFactory.getPreferenceProperties().getProperty(Preference.WRITE_LOG_FILE
/* 1227 */           .getKey(), Preference.WRITE_LOG_FILE.getDefault()))) {
/* 1228 */       LOG.info(String.format("writing log file: %s", new Object[] { logFile }));
/*      */       
/* 1230 */       TextFile.writeToFile(new File(logFile), logContent, true);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void debugNet() {
/* 1235 */     if (this.pn != null) {
/* 1236 */       StringBuilder sb = new StringBuilder();
/* 1237 */       sb.append("Debugging Net\n");
/* 1238 */       sb.append("placeTransitionNet:" + this.pn.getName() + "\n File:" + this.netFile.getName() + "\n");
/* 1239 */       sb.append("Places:\n");
/* 1240 */       for (Place p : this.pn.getPlaces()) {
/* 1241 */         sb.append(String.format("id: %4d, name: %15s\t, token: %4d, pre: %20s, post: %20s\n", new Object[] { Integer.valueOf(p.getId()), p
/* 1242 */                 .getName(), Integer.valueOf(p.getToken()), p.preNodes().toString(), p.postNodes().toString() }));
/*      */       } 
/*      */       
/* 1245 */       sb.append("Transitions Vector:\n");
/* 1246 */       for (Transition t : this.pn.getTransitions()) {
/* 1247 */         sb.append(String.format("id: %4d, name: %15s\t, orgId: %4d, pre: %20s, post: %20s, prepost: %20s\n", new Object[] {
/* 1248 */                 Short.valueOf(t.getId()), t.getName(), Short.valueOf(t.getOrgId()), t.getPre(), t.getPost(), t.getPrePost() }));
/*      */       } 
/* 1250 */       sb.append("\nm0Places vector:\n " + this.pn.getM0().toString() + "\n");
/* 1251 */       sb.append("\ngetNonTimedM00State:\n" + this.pn.getNonTimedM0State() + "\n");
/* 1252 */       sb.append("m0State :\n" + this.pn.getM0State().toString() + "\n");
/* 1253 */       sb.append("translationTableTransitions:\n" + this.pn.translationTableTransitions.toString() + "\n");
/* 1254 */       sb.append("translationMapTransitions:\n" + PlaceTransitionNet.translationMapTransitions.toString() + "\n");
/*      */       
/* 1256 */       sb.append("\nIncidence matrix:\n");
/* 1257 */       sb.append(printIncidenceMatrix());
/*      */       
/* 1259 */       FileDisplayDialog fdd = new FileDisplayDialog(20, 20, sb.toString());
/* 1260 */       fdd.setTitle("PlaceTransitionNet debugging");
/*      */       
/* 1262 */       if (LOG.isDebugEnabled()) {
/* 1263 */         LOG.debug(sb.toString());
/*      */       }
/*      */ 
/*      */       
/* 1267 */       sendToPluginDirectors(12, this, this.pn);
/*      */     } 
/*      */   }
/*      */   
/*      */   private String printIncidenceMatrix() {
/* 1272 */     StringBuffer buffer = new StringBuffer();
/*      */     
/* 1274 */     int[] width = new int[this.pn.transitions()];
/* 1275 */     buffer.append("P\\T  "); int i;
/* 1276 */     for (i = 0; i < this.pn.transitions(); i++) {
/* 1277 */       String name = this.pn.getTransition((short)i).getName();
/* 1278 */       buffer.append(" ");
/* 1279 */       buffer.append(name);
/* 1280 */       buffer.append(" ");
/*      */       
/* 1282 */       width[i] = name.length() + 2;
/*      */     } 
/* 1284 */     buffer.append("\n");
/*      */     
/* 1286 */     for (i = 0; i < this.pn.places(); i++) {
/* 1287 */       String name = this.pn.getPlaceById(i).getName();
/* 1288 */       buffer.append(name);
/* 1289 */       for (int k = 0; k < 4 - name.length(); k++) {
/* 1290 */         buffer.append(" ");
/*      */       }
/*      */       
/* 1293 */       for (int j = 0; j < this.pn.transitions(); j++) {
/* 1294 */         int change = this.pn.changesTokenOn(this.pn.getPlaceByIndex(i), this.pn
/* 1295 */             .getTransition((short)j));
/*      */         
/* 1297 */         for (int m = 0; m < width[j] - Integer.toString(change).length(); m++) {
/* 1298 */           buffer.append(" ");
/*      */         }
/*      */         
/* 1301 */         buffer.append(change);
/*      */       } 
/* 1303 */       buffer.append("\n");
/*      */     } 
/*      */     
/* 1306 */     return buffer.toString();
/*      */   }
/*      */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/App.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */