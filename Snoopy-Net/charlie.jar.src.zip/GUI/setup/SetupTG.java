/*     */ package GUI.setup;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ public class SetupTG
/*     */   extends Setup
/*     */ {
/*  33 */   private static final Log LOG = LogFactory.getLog(SetupTG.class);
/*     */   
/*     */   private ZipEntry newManifest;
/*     */   
/*     */   public static void main(String[] args) {
/*  38 */     SetupTG app = new SetupTG();
/*  39 */     URL url = ClassLoader.getSystemResource("GUI/setup/SetupTG.class");
/*  40 */     String urlString = url.toString().substring("file:jar:/".length());
/*  41 */     urlString = urlString.substring(0, urlString.lastIndexOf("!"));
/*  42 */     File f = null;
/*     */     try {
/*  44 */       url = new URL("file:/" + urlString);
/*  45 */       LOG.debug(String.format("uri: %s", new Object[] { url.toURI().toString() }));
/*  46 */       f = new File(url.toURI());
/*  47 */       LOG.debug(String.format("file: %s", new Object[] { f.getPath() }));
/*  48 */     } catch (Exception e) {
/*  49 */       LOG.error("IO:Error cannot find setup file, try changing name or location", e);
/*  50 */       System.exit(1);
/*     */     } 
/*  52 */     if (f != null) {
/*  53 */       LOG.debug(String.format("fileString : %s\n", new Object[] { f.getPath() }));
/*     */       
/*  55 */       SetupApp app2 = new SetupApp();
/*  56 */       app2.readJarFile(f.getPath());
/*     */     } 
/*  58 */     app.createGui();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readJarFile(String fileName) {
/*  67 */     this.jarFileName = fileName;
/*     */     try {
/*  69 */       this.in = new ZipFile(fileName);
/*  70 */       Enumeration<? extends ZipEntry> entries = this.in.entries();
/*  71 */       while (entries.hasMoreElements()) {
/*  72 */         ZipEntry z = entries.nextElement();
/*  73 */         this.entryList.add(z);
/*  74 */         if (z != null && z.getName().equals("MANIFEST_TG.MF")) this.newManifest = z; 
/*  75 */         if (z != null && z.getName().equals("META-INF/MANIFEST.MF")) this.manifestEntry = z; 
/*     */       } 
/*  77 */     } catch (Exception e) {
/*  78 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   public void createGui() {
/*     */     URL imageURL;
/*  83 */     this.f = new JFrame("Gui generator setup program");
/*  84 */     JPanel p = new JPanel();
/*  85 */     this.f.setContentPane(p);
/*  86 */     p.setLayout(new BorderLayout());
/*     */     
/*     */     try {
/*  89 */       String urlString = "jar:" + (new File(this.jarFileName)).toURI().toURL().toString() + "!/resources/obenli.jpg";
/*  90 */       LOG.debug(String.format("urlstring: %s", new Object[] { urlString }));
/*     */       
/*  92 */       imageURL = ClassLoader.getSystemResource("resources/obenli.jpg");
/*  93 */     } catch (Exception e) {
/*  94 */       LOG.error(e.getMessage(), e);
/*     */       
/*     */       return;
/*     */     } 
/*  98 */     ImageIcon icon = null;
/*  99 */     if (imageURL != null) {
/* 100 */       icon = new ImageIcon(imageURL);
/* 101 */       if (icon != null) {
/* 102 */         JLabel l = new JLabel();
/* 103 */         l.setIcon(icon);
/* 104 */         p.add(l, "West");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 109 */     this.output = new JTextArea(12, 60);
/* 110 */     this.output.setEditable(false);
/* 111 */     this.output.setPreferredSize(new Dimension(300, 400));
/* 112 */     this.output.append("This programm does the setup for the GUI Generator v1.0\n");
/* 113 */     this.output.append("\n");
/* 114 */     this.output.append("It extracts all nessecary files from the setup_tg_v1.jar and\n");
/* 115 */     this.output.append("creates a new jar-file which you can use to start the gui generator!\n");
/* 116 */     this.output.append("\n");
/* 117 */     this.output.append("Use gui_gen_v1.jar to start the program!\n");
/* 118 */     this.output.append("You may delete the setup_tg_v1.jar file after you are convinced that the program works \n");
/* 119 */     this.output.append("Operating system : " + System.getProperty("os.name") + "\n");
/* 120 */     this.output.append("java version : " + System.getProperty("java.version") + "\n");
/* 121 */     this.output.append("Your java version should be newer than 1.6.\n");
/* 122 */     JScrollPane scroll = new JScrollPane(this.output);
/* 123 */     p.add(scroll, "Center");
/* 124 */     JButton startButton = new JButton("start");
/* 125 */     startButton.requestFocusInWindow();
/* 126 */     startButton.setAction(this.startAction);
/* 127 */     p.add(startButton, "South");
/* 128 */     Toolkit tk = Toolkit.getDefaultToolkit();
/* 129 */     Dimension d = tk.getScreenSize();
/*     */     
/* 131 */     this.f.pack();
/* 132 */     if (icon != null) {
/* 133 */       int height = icon.getIconHeight();
/* 134 */       Dimension dd = new Dimension(this.f.getWidth(), height);
/* 135 */       p.setSize(dd);
/* 136 */       p.setPreferredSize(dd);
/*     */     } 
/* 138 */     this.f.pack();
/* 139 */     Point point = new Point((int)(d.getWidth() / 2.0D - (this.f.getWidth() / 2)), (int)(d.getHeight() / 2.0D - (this.f.getHeight() / 2)));
/* 140 */     this.f.setLocation(point);
/* 141 */     this.f.setDefaultCloseOperation(3);
/* 142 */     this.f.setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setup() {
/* 149 */     File dir = new File(System.getProperty("user.dir"));
/* 150 */     LOG.info(String.format("directory = %s", new Object[] { dir.getAbsolutePath() }));
/*     */     
/* 152 */     JFileChooser fc = new JFileChooser(dir);
/* 153 */     fc.setDialogTitle("Choose your installation directory");
/* 154 */     fc.setMultiSelectionEnabled(false);
/* 155 */     fc.setFileSelectionMode(1);
/* 156 */     fc.setAcceptAllFileFilterUsed(false);
/*     */     
/* 158 */     int answ = fc.showDialog(this.f, "Set Installation Directory");
/* 159 */     if (answ != 1)
/*     */       return; 
/* 161 */     dir = fc.getSelectedFile();
/*     */     
/* 163 */     boolean retVal = false;
/* 164 */     if (!dir.exists()) {
/* 165 */       retVal = dir.mkdirs();
/*     */     } else {
/*     */       
/* 168 */       retVal = true;
/*     */     } 
/*     */     
/* 171 */     if (!retVal) {
/* 172 */       JOptionPane.showMessageDialog(this.f, "Could not create installation directory, Aborting installation !", "Alert!", 0);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 178 */     this.installDir = dir.getAbsolutePath() + File.separator;
/* 179 */     LOG.info(String.format("installDir: %s", new Object[] { this.installDir }));
/*     */     
/*     */     try {
/*     */       int i;
/* 183 */       for (i = 0; i < this.entryList.size(); i++) {
/* 184 */         ZipEntry z = this.entryList.get(i);
/* 185 */         if (z != null)
/*     */         {
/*     */           
/* 188 */           if (!createEntry(z)) {
/*     */             return;
/*     */           }
/*     */         }
/*     */       } 
/* 193 */       ZipOutputStream out = new ZipOutputStream(new FileOutputStream(this.installDir + "gui_gen_v1.jar", false));
/*     */       
/* 195 */       for (i = 0; i < this.entryList.size(); i++) {
/* 196 */         ZipEntry z = this.entryList.get(i);
/*     */ 
/*     */         
/* 199 */         if (z != null && (z.getName().startsWith("charlie") || z.getName().startsWith("GUI") || z.getName().equals("META-INF"))) {
/* 200 */           InputStream inputStream = this.in.getInputStream(z);
/* 201 */           out.putNextEntry(z);
/* 202 */           while ((this.read = inputStream.read(this.data, 0, 1024)) != -1) {
/* 203 */             out.write(this.data, 0, this.read);
/*     */           }
/* 205 */           out.closeEntry();
/*     */         } 
/*     */       } 
/*     */       
/* 209 */       InputStream input = this.in.getInputStream(this.newManifest);
/* 210 */       ZipEntry k = new ZipEntry("META-INF/MANIFEST.MF");
/* 211 */       out.putNextEntry(k);
/* 212 */       while ((this.read = input.read(this.data, 0, 1024)) != -1) {
/* 213 */         out.write(this.data, 0, this.read);
/*     */       }
/* 215 */       out.closeEntry();
/* 216 */       out.finish();
/* 217 */       out.close();
/* 218 */     } catch (Exception e) {
/* 219 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRights() {
/* 228 */     String os = System.getProperty("os.name");
/* 229 */     os = os.toLowerCase();
/* 230 */     LOG.info("os.name: " + os);
/* 231 */     if (!os.contains("windows")) {
/*     */       try {
/* 233 */         File iddmc = null;
/* 234 */         File zbddmc = null;
/* 235 */         String middle = "";
/* 236 */         if (os.contains("mac")) {
/* 237 */           middle = "mac";
/* 238 */           removeDirectory(this.installDir + "modelchecker/linux32");
/* 239 */           removeDirectory(this.installDir + "modelchecker/linux64");
/* 240 */           removeDirectory(this.installDir + "modelchecker/windows");
/*     */         }
/* 242 */         else if (os.contains("linux")) {
/* 243 */           Object[] options = { "32bit Linux", "64bit Linux", "Don't Know" };
/* 244 */           String message = "<html><p> What is the type of your operating System?</p></html>";
/* 245 */           int answ = JOptionPane.showOptionDialog(this.f, message, "Question ?", -1, 2, null, options, options[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 253 */           LOG.info(String.format("answ = %d", new Object[] { Integer.valueOf(answ) }));
/*     */           
/* 255 */           switch (answ) {
/*     */             
/*     */             case 0:
/* 258 */               middle = "linux32";
/* 259 */               removeDirectory(this.installDir + "modelchecker/mac");
/* 260 */               removeDirectory(this.installDir + "modelchecker/linux64");
/* 261 */               removeDirectory(this.installDir + "modelchecker/windows");
/*     */               break;
/*     */             
/*     */             case 1:
/* 265 */               middle = "linux64";
/* 266 */               removeDirectory(this.installDir + "modelchecker/mac");
/* 267 */               removeDirectory(this.installDir + "modelchecker/linux32");
/* 268 */               removeDirectory(this.installDir + "modelchecker/windows");
/*     */               break;
/*     */             
/*     */             default:
/* 272 */               middle = "linux32";
/* 273 */               removeDirectory(this.installDir + "modelchecker/mac");
/* 274 */               removeDirectory(this.installDir + "modelchecker/windows");
/*     */               break;
/*     */           } 
/*     */         } 
/* 278 */         iddmc = new File(this.installDir + "modelchecker/" + middle + "/bin/iddmc");
/* 279 */         if (iddmc.exists()) {
/* 280 */           iddmc.setExecutable(true);
/*     */         } else {
/* 282 */           LOG.error(String.format("modelchecker iddmc not found: %s", new Object[] { iddmc.getAbsolutePath() }));
/*     */         } 
/* 284 */         zbddmc = new File(this.installDir + "modelchecker/" + middle + "/bin/zbddmc");
/* 285 */         if (zbddmc.exists()) {
/* 286 */           zbddmc.setExecutable(true);
/*     */         } else {
/* 288 */           LOG.error(String.format("modelchecker zbddmc not found! : %s", new Object[] { zbddmc.getAbsolutePath() }));
/*     */         } 
/* 290 */         File runtg = new File(this.installDir + "run.sh");
/* 291 */         if (runtg.exists()) {
/* 292 */           runtg.setExecutable(true);
/*     */         }
/* 294 */       } catch (Exception e) {
/* 295 */         LOG.error("Could no set rights for modelchecker !");
/* 296 */         LOG.error("Please use modelchecker/make_executable.sh or set the correct rights manually.");
/*     */       } 
/*     */     } else {
/* 299 */       removeDirectory(this.installDir + "modelchecker/mac");
/* 300 */       removeDirectory(this.installDir + "modelchecker/linux64");
/* 301 */       removeDirectory(this.installDir + "modelchecker/linux32");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 309 */   public AbstractAction startAction = new AbstractAction("start")
/*     */     {
/*     */       private static final long serialVersionUID = 7716654373166317504L;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void actionPerformed(ActionEvent _ae) {
/* 317 */         SetupTG.this.setup();
/*     */         try {
/* 319 */           SetupTG.this.in.close();
/*     */           
/* 321 */           SetupTG.this.removeDirectory(SetupTG.this.installDir + "charlie");
/* 322 */           SetupTG.this.removeDirectory(SetupTG.this.installDir + "GUI");
/* 323 */           SetupTG.this.removeDirectory(SetupTG.this.installDir + "META-INF");
/* 324 */           SetupTG.this.removeDirectory(SetupTG.this.installDir + "MANIFEST_TG.MF");
/* 325 */           SetupTG.this.setRights();
/* 326 */         } catch (Exception e) {
/* 327 */           SetupTG.LOG.error(e.getMessage(), e);
/*     */         } finally {
/* 329 */           SetupTG.this.f.dispose();
/* 330 */           SetupTG.this.f.setVisible(false);
/*     */           
/* 332 */           System.exit(0);
/*     */         } 
/*     */       }
/*     */     };
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/setup/SetupTG.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */