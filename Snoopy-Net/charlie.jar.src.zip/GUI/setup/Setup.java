/*     */ package GUI.setup;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextArea;
/*     */ 
/*     */ 
/*     */ public abstract class Setup
/*     */ {
/*  25 */   private static final Logger LOG = Logger.getLogger(Setup.class.getName());
/*     */   
/*  27 */   ArrayList<ZipEntry> entryList = new ArrayList<>();
/*  28 */   ZipFile in = null;
/*  29 */   byte[] data = new byte[1024];
/*  30 */   int read = 0;
/*     */   protected String jarFileName;
/*  32 */   protected String installDir = "";
/*     */   
/*     */   protected JTextArea output;
/*     */   protected JFrame f;
/*     */   protected ZipEntry manifestEntry;
/*  37 */   private static int NO_OVERWRITE = 0;
/*  38 */   private static int YES_OVERWRITE = 1;
/*  39 */   private static int ALL_OVERWRITE = 2;
/*  40 */   private int overwriteStatus = NO_OVERWRITE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean createEntry(ZipEntry z) throws IOException {
/*  51 */     this.output.append(z.getName() + "\n");
/*  52 */     this.output.setCaretPosition(this.output.getText().length() - 1);
/*  53 */     String zName = this.installDir + z.getName();
/*  54 */     this.output.setRows(this.output.getLineCount());
/*  55 */     if (z.isDirectory()) {
/*     */ 
/*     */       
/*  58 */       File dir = new File(zName);
/*  59 */       if (dir.exists()) {
/*  60 */         int b = NO_OVERWRITE;
/*  61 */         if (this.overwriteStatus != ALL_OVERWRITE) {
/*  62 */           b = askOverwrite(zName);
/*     */         }
/*  64 */         if (b == ALL_OVERWRITE) {
/*  65 */           this.overwriteStatus = ALL_OVERWRITE;
/*     */         } else {
/*  67 */           b = ALL_OVERWRITE;
/*     */         } 
/*  69 */         if (b == YES_OVERWRITE || b == ALL_OVERWRITE) {
/*  70 */           dir.mkdir();
/*  71 */           return true;
/*     */         } 
/*  73 */         JOptionPane.showMessageDialog(this.f, "Aborting Setup!", "Abort", 0);
/*  74 */         return false;
/*     */       } 
/*     */       
/*  77 */       dir.mkdir();
/*  78 */       return true;
/*     */     } 
/*     */     
/*  81 */     File newFile = new File(zName);
/*  82 */     int writeFile = NO_OVERWRITE;
/*     */ 
/*     */ 
/*     */     
/*  86 */     if (newFile.exists() && this.overwriteStatus != ALL_OVERWRITE) {
/*  87 */       writeFile = askOverwrite(zName);
/*  88 */       if (writeFile == ALL_OVERWRITE) {
/*  89 */         this.overwriteStatus = ALL_OVERWRITE;
/*     */       }
/*     */     } else {
/*  92 */       writeFile = YES_OVERWRITE;
/*     */     } 
/*     */     
/*  95 */     if (writeFile == YES_OVERWRITE || writeFile == ALL_OVERWRITE) {
/*     */       
/*  97 */       FileOutputStream out = new FileOutputStream(zName);
/*     */       try {
/*  99 */         InputStream fileInput = this.in.getInputStream(z);
/*     */         
/* 101 */         while ((this.read = fileInput.read(this.data, 0, 1024)) != -1) {
/* 102 */           out.write(this.data, 0, this.read);
/*     */         }
/*     */       } finally {
/* 105 */         out.close();
/*     */       } 
/* 107 */       return true;
/*     */     } 
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int askOverwrite(String fileName) {
/* 118 */     Object[] options = { "YES", "YES TO ALL", "NO", "Abort Setup" };
/* 119 */     String message = "<html><p> The File/Directory : " + fileName + " does already exist. </p><p>Do you want to overwrite it?</p></html>";
/* 120 */     int answ = JOptionPane.showOptionDialog(this.f, message, "Warning!", -1, 2, null, options, options[2]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     LOG.info(String.format("answ = %d\n", new Object[] { Integer.valueOf(answ) }));
/* 129 */     switch (answ) {
/*     */       
/*     */       case 0:
/* 132 */         return YES_OVERWRITE;
/*     */       
/*     */       case 1:
/* 135 */         return ALL_OVERWRITE;
/*     */       
/*     */       case 2:
/* 138 */         return NO_OVERWRITE;
/*     */       
/*     */       case 3:
/* 141 */         System.exit(0);
/*     */         break;
/*     */     } 
/* 144 */     return NO_OVERWRITE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void switchManifest(ZipEntry z) throws IOException {
/* 157 */     createEntry(z);
/* 158 */     if (!(new File(z.getName())).exists()) {
/* 159 */       LOG.severe(String.format("File for the entry %s does not exist!", new Object[] { z.getName() }));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 165 */     InputStream fileInput = null;
/* 166 */     ZipOutputStream out = null;
/*     */     try {
/* 168 */       fileInput = this.in.getInputStream(z);
/* 169 */       out = new ZipOutputStream(new FileOutputStream(this.installDir + this.jarFileName, true));
/* 170 */       ZipEntry newManifest = this.in.getEntry("META-INF/MANIFEST.MF");
/* 171 */       out.putNextEntry(newManifest);
/* 172 */       while ((this.read = fileInput.read(this.data, 0, 1024)) != -1) {
/* 173 */         out.write(this.data, 0, this.read);
/*     */       }
/*     */     } finally {
/*     */       
/* 177 */       if (out != null) {
/* 178 */         out.closeEntry();
/*     */       }
/* 180 */       if (fileInput != null) {
/* 181 */         fileInput.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setup();
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeDirectory(String dirName) {
/* 194 */     File resource = new File(dirName);
/*     */     
/* 196 */     if (resource.isDirectory()) {
/* 197 */       File[] childFiles = resource.listFiles();
/* 198 */       for (File child : childFiles) {
/* 199 */         removeDirectory(child.getAbsolutePath());
/*     */       }
/*     */     } 
/* 202 */     resource.delete();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setRights();
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyDirectory(File sourceDir, File destDir) throws IOException {
/* 212 */     if (!destDir.exists()) {
/* 213 */       destDir.mkdir();
/*     */     }
/* 215 */     File[] children = sourceDir.listFiles();
/* 216 */     for (File sourceChild : children) {
/* 217 */       String name = sourceChild.getName();
/* 218 */       File destChild = new File(destDir, name);
/* 219 */       if (sourceChild.isDirectory()) {
/* 220 */         copyDirectory(sourceChild, destChild);
/*     */       } else {
/* 222 */         copyFile(sourceChild, destChild);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void copyFile(File source, File dest) throws IOException {
/* 229 */     if (!dest.exists()) {
/* 230 */       dest.createNewFile();
/*     */     }
/* 232 */     InputStream in = null;
/* 233 */     OutputStream out = null;
/*     */     try {
/* 235 */       in = new FileInputStream(source);
/* 236 */       out = new FileOutputStream(dest);
/* 237 */       byte[] buf = new byte[1024];
/*     */       int len;
/* 239 */       while ((len = in.read(buf)) > 0) {
/* 240 */         out.write(buf, 0, len);
/*     */       }
/*     */     } finally {
/*     */       
/* 244 */       in.close();
/* 245 */       out.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   class ImageRenderComponent
/*     */     extends JPanel
/*     */   {
/*     */     private static final long serialVersionUID = -4744487601624130965L;
/*     */     
/*     */     private BufferedImage image;
/*     */     
/*     */     private Dimension size;
/*     */     
/*     */     public ImageRenderComponent(BufferedImage image) {
/* 260 */       this.image = image;
/* 261 */       this.size = new Dimension(image.getWidth(), image.getHeight());
/*     */     }
/*     */ 
/*     */     
/*     */     protected void paintComponent(Graphics g) {
/* 266 */       super.paintComponent(g);
/* 267 */       int x = (getWidth() - this.size.width) / 2;
/* 268 */       int y = (getHeight() - this.size.height) / 2;
/* 269 */       g.drawImage(this.image, x, y, this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Dimension getPreferredSize() {
/* 274 */       return this.size;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/setup/Setup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */