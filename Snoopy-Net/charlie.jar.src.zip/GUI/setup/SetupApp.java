/*     */ package GUI.setup;
/*     */ 
/*     */ import GUI.App;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ 
/*     */ 
/*     */ public class SetupApp
/*     */   extends Setup
/*     */ {
/*  36 */   private static final Logger LOG = Logger.getLogger(SetupApp.class.getName());
/*     */   
/*  38 */   public JButton startButton = null;
/*  39 */   public File dir = null;
/*     */   
/*     */   public static void main(String[] args) {
/*  42 */     doSetup();
/*     */   }
/*     */   
/*     */   public static void doSetup() {
/*  46 */     URL url = ClassLoader.getSystemResource("charlie/Charlie.class");
/*  47 */     String urlString = url.toString().substring("file:jar:/".length());
/*  48 */     urlString = urlString.substring(0, urlString.lastIndexOf("!"));
/*  49 */     File f = null;
/*     */     try {
/*  51 */       url = new URL("file:/" + urlString);
/*  52 */       f = new File(url.toURI());
/*  53 */     } catch (Exception e) {
/*  54 */       LOG.severe("IO: Error cannot find setup file, try changing name or location.");
/*  55 */       System.exit(1);
/*     */     } 
/*     */     
/*  58 */     if (f != null) {
/*  59 */       SetupApp app = new SetupApp();
/*  60 */       app.readJarFile(f.getPath());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getProgramName() {
/*  71 */     return "charlie";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getMainClassName() {
/*  81 */     return App.class.getCanonicalName();
/*     */   }
/*     */   
/*     */   public void readJarFile(String fileName) {
/*  85 */     this.jarFileName = fileName;
/*     */     
/*     */     try {
/*  88 */       this.in = new ZipFile(fileName);
/*  89 */       Enumeration<? extends ZipEntry> entries = this.in.entries();
/*  90 */       while (entries.hasMoreElements()) {
/*  91 */         ZipEntry z = entries.nextElement();
/*  92 */         this.entryList.add(z);
/*  93 */         if (z != null && z.getName().equals("META-INF/MANIFEST.MF")) {
/*  94 */           this.manifestEntry = z;
/*     */         }
/*     */       } 
/*  97 */     } catch (Exception e) {
/*  98 */       LOG.severe(e.getMessage());
/*     */     } 
/*     */     
/* 101 */     createGui();
/*     */   }
/*     */   public void createGui() {
/*     */     URL imageURL;
/* 105 */     this.f = new JFrame(getProgramName() + " setup program");
/* 106 */     JPanel p = new JPanel();
/* 107 */     this.f.setContentPane(p);
/* 108 */     p.setLayout(new BorderLayout());
/*     */     
/*     */     try {
/* 111 */       imageURL = ClassLoader.getSystemResource("resources/obenli.jpg");
/* 112 */     } catch (Exception exp) {
/*     */       return;
/*     */     } 
/*     */     
/* 116 */     ImageIcon icon = null;
/* 117 */     if (imageURL != null) {
/* 118 */       icon = new ImageIcon(imageURL);
/* 119 */       if (icon != null) {
/* 120 */         JLabel l = new JLabel();
/* 121 */         l.setIcon(icon);
/* 122 */         p.add(l, "West");
/*     */       } 
/*     */     } 
/*     */     
/* 126 */     this.output = new JTextArea(12, 60);
/* 127 */     this.output.setEditable(false);
/* 128 */     this.output.setPreferredSize(new Dimension(300, 400));
/*     */     
/* 130 */     printInfo(this.output);
/*     */     
/* 132 */     JScrollPane scroll = new JScrollPane(this.output);
/* 133 */     p.add(scroll, "Center");
/* 134 */     this.startButton = new JButton("start");
/* 135 */     this.startButton.requestFocusInWindow();
/* 136 */     this.startButton.setAction(this.startAction);
/* 137 */     p.add(this.startButton, "South");
/* 138 */     Toolkit tk = Toolkit.getDefaultToolkit();
/* 139 */     Dimension d = tk.getScreenSize();
/*     */     
/* 141 */     this.f.pack();
/* 142 */     if (icon != null) {
/* 143 */       int height = icon.getIconHeight();
/* 144 */       Dimension dd = new Dimension(this.f.getWidth(), height);
/* 145 */       p.setSize(dd);
/* 146 */       p.setPreferredSize(dd);
/*     */     } 
/* 148 */     this.f.pack();
/*     */     
/* 150 */     Point point = new Point((int)(d.getWidth() / 2.0D - (this.f.getWidth() / 2)), (int)(d.getHeight() / 2.0D - (this.f.getHeight() / 2)));
/* 151 */     this.f.setLocation(point);
/* 152 */     this.f.setDefaultCloseOperation(3);
/* 153 */     this.f.setVisible(true);
/*     */   }
/*     */   
/*     */   protected void printInfo(JTextArea _output) {
/* 157 */     _output.append("This programm does the setup for charlie \n");
/* 158 */     _output.append("using setup file:\n " + this.jarFileName + "\n");
/* 159 */     _output.append("\n");
/* 160 */     _output.append("It extracts all nessecary files from the setup_charlie.jar and\n");
/* 161 */     _output.append("creates a new jar-file which you can use to start charlie!\n");
/* 162 */     _output.append("\n");
/* 163 */     _output.append("Use charlie.jar to start the program!\n");
/* 164 */     _output.append("You may delete the setup_charlieXXX.jar file after you are convinced that the program works \n");
/* 165 */     _output.append("Operating system : " + System.getProperty("os.name") + "\n");
/* 166 */     _output.append("java version : " + System.getProperty("java.version") + "\n");
/* 167 */     _output.append("Your java version should be newer than 1.6.\n");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setup() {
/* 173 */     this.dir = new File(System.getProperty("user.dir"));
/* 174 */     LOG.info(String.format("directory = %s\n", new Object[] { this.dir.getAbsolutePath() }));
/*     */     
/* 176 */     JFileChooser fc = new JFileChooser(this.dir);
/* 177 */     fc.setDialogTitle("Choose your installation directory");
/* 178 */     fc.setMultiSelectionEnabled(false);
/* 179 */     fc.setFileSelectionMode(1);
/* 180 */     fc.setAcceptAllFileFilterUsed(false);
/*     */     
/* 182 */     int answ = fc.showDialog(this.f, "Set Installation Directory");
/* 183 */     if (answ == 1) {
/* 184 */       JOptionPane.showMessageDialog(null, "File chooser canceled");
/*     */       return;
/*     */     } 
/* 187 */     this.dir = fc.getSelectedFile();
/*     */     
/* 189 */     boolean retVal = false;
/* 190 */     if (!this.dir.exists()) {
/* 191 */       JOptionPane.showMessageDialog(null, "Directory : " + this.dir.getAbsolutePath() + " doesn't exist, creating ...");
/*     */       
/* 193 */       retVal = this.dir.mkdirs();
/*     */     } else {
/*     */       
/* 196 */       retVal = true;
/*     */     } 
/*     */     
/* 199 */     if (!retVal) {
/* 200 */       JOptionPane.showMessageDialog(this.f, "Could not create installation directory, Aborting installation !", "Alert!", 0);
/*     */       
/*     */       return;
/*     */     } 
/* 204 */     this.installDir = this.dir.getAbsolutePath() + "/";
/* 205 */     this.output.append("installDir : " + this.installDir + "\n");
/* 206 */     LOG.info(String.format("installDir : %s", new Object[] { this.installDir }));
/*     */     
/* 208 */     File installDirFile = new File(this.installDir);
/*     */     try {
/* 210 */       if (!installDirFile.createNewFile() && !installDirFile.canWrite() && !installDirFile.setWritable(true)) {
/* 211 */         throw new IOException("Cannot write to the selected installation path. Please restart the installation and select another path.");
/*     */       }
/* 213 */     } catch (IOException ioe) {
/* 214 */       JOptionPane.showMessageDialog(this.f, "An error occurred during the installation with the following message:\n\n\"" + ioe
/* 215 */           .getLocalizedMessage() + "\"\n\nThe installation is aborted.", "error occurred during installation", 0);
/*     */ 
/*     */       
/* 218 */       System.exit(5);
/*     */     } 
/*     */     
/*     */     try {
/* 222 */       for (int i = 0; i < this.entryList.size(); i++) {
/* 223 */         ZipEntry z = this.entryList.get(i);
/* 224 */         if (z != null) {
/*     */           
/*     */           try {
/* 227 */             createEntry(z);
/* 228 */           } catch (IOException ioe) {
/*     */             
/* 230 */             JOptionPane.showMessageDialog(this.f, "An error occurred during the installation with the following message:\n\n" + ioe
/* 231 */                 .getLocalizedMessage() + "\n\nThe installation is aborted.", "error occurred during installation", 0);
/*     */ 
/*     */             
/* 234 */             System.exit(5);
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 239 */       ZipOutputStream out = new ZipOutputStream(new FileOutputStream(this.installDir + getProgramName() + ".jar", false));
/*     */       
/* 241 */       for (int j = 0; j < this.entryList.size(); j++) {
/* 242 */         ZipEntry z = this.entryList.get(j);
/* 243 */         if (z != null && (z
/* 244 */           .getName().startsWith("charlie") || z.getName().startsWith("GUI") || z
/* 245 */           .getName().equals("META-INF"))) {
/* 246 */           InputStream inputStream = this.in.getInputStream(z);
/* 247 */           out.putNextEntry(z);
/* 248 */           while ((this.read = inputStream.read(this.data, 0, 1024)) != -1) {
/* 249 */             out.write(this.data, 0, this.read);
/*     */           }
/* 251 */           out.closeEntry();
/*     */         } 
/*     */       } 
/*     */       
/* 255 */       BufferedReader input = new BufferedReader(new InputStreamReader(this.in.getInputStream(this.manifestEntry)));
/* 256 */       ZipEntry k = new ZipEntry("META-INF/MANIFEST.MF");
/* 257 */       out.putNextEntry(k);
/* 258 */       String line = null;
/* 259 */       while ((line = input.readLine()) != null) {
/* 260 */         if (line.startsWith("Main-Class")) {
/* 261 */           line = String.format("Main-Class: %s", new Object[] { getMainClassName() });
/*     */         }
/* 263 */         out.write(line.getBytes("us-ascii"));
/* 264 */         out.write("\r\n".getBytes("us-ascii"));
/*     */       } 
/* 266 */       out.closeEntry();
/* 267 */       out.finish();
/* 268 */       out.close();
/* 269 */     } catch (Exception e) {
/* 270 */       LOG.severe(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRights() {
/* 276 */     if (!System.getProperty("os.name").contains("Windows")) {
/* 277 */       LOG.info("Try to set executable rights on modelchecking binaries!");
/* 278 */       if (this.dir != null) {
/* 279 */         String path = this.dir.getAbsolutePath();
/* 280 */         makeExecutable(path + "/run.sh");
/* 281 */         makeExecutable(path + "/tCharlie.sh");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void makeExecutable(String filename) {
/* 287 */     File mc = new File(filename);
/* 288 */     boolean b = mc.setExecutable(true, true);
/* 289 */     if (b) {
/* 290 */       LOG.info(String.format("setExecutable on : %s succeeded!", new Object[] { filename }));
/*     */     } else {
/* 292 */       LOG.warning(String.format("setExecutable on : %s did not succeed, check permissions manually!", new Object[] { filename }));
/*     */     } 
/*     */   }
/*     */   
/* 296 */   public AbstractAction startAction = new AbstractAction("start")
/*     */     {
/*     */       private static final long serialVersionUID = -3554086699140520415L;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void actionPerformed(ActionEvent e) {
/* 304 */         SetupApp.this.startButton.setEnabled(false);
/* 305 */         this.thread.start();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 310 */       private Thread thread = new Thread()
/*     */         {
/*     */           public void run() {
/*     */             try {
/* 314 */               SetupApp.LOG.info("Starting setup");
/* 315 */               SetupApp.this.setup();
/* 316 */               SetupApp.LOG.info("setup finished cleaning up");
/* 317 */               SetupApp.this.in.close();
/* 318 */               SetupApp.this.removeDirectory(SetupApp.this.installDir + "charlie");
/* 319 */               SetupApp.this.removeDirectory(SetupApp.this.installDir + "GUI");
/* 320 */               SetupApp.this.removeDirectory(SetupApp.this.installDir + "META-INF");
/* 321 */               SetupApp.this.removeDirectory(SetupApp.this.installDir + "MANIFEST.MF");
/* 322 */               SetupApp.this.setRights();
/* 323 */             } catch (Exception e) {
/* 324 */               SetupApp.LOG.severe(e.getMessage());
/*     */             } finally {
/* 326 */               SetupApp.this.f.setVisible(false);
/* 327 */               SetupApp.this.f.dispose();
/*     */             } 
/*     */           }
/*     */         };
/*     */     };
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/setup/SetupApp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */