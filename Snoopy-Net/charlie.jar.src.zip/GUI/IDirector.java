package GUI;

public interface IDirector {
  boolean sendMessage(int paramInt, Object paramObject1, Object paramObject2);
  
  Object externalMessage(int paramInt, Object paramObject1, Object paramObject2);
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/IDirector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */