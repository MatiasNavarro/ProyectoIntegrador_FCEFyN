/*    */ package GUI.io;
/*    */ 
/*    */ import java.io.File;
/*    */ import javax.xml.transform.Result;
/*    */ import javax.xml.transform.Source;
/*    */ import javax.xml.transform.Transformer;
/*    */ import javax.xml.transform.TransformerConfigurationException;
/*    */ import javax.xml.transform.TransformerException;
/*    */ import javax.xml.transform.TransformerFactory;
/*    */ import javax.xml.transform.dom.DOMSource;
/*    */ import javax.xml.transform.stream.StreamResult;
/*    */ import org.w3c.dom.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLWriter
/*    */ {
/*    */   public static void writeXmlFile(Document doc, File file) {
/*    */     
/* 25 */     try { Source source = new DOMSource(doc);
/*    */ 
/*    */       
/* 28 */       Result result = new StreamResult(file);
/*    */ 
/*    */       
/* 31 */       Transformer xformer = TransformerFactory.newInstance().newTransformer();
/* 32 */       xformer.setOutputProperty("indent", "yes");
/* 33 */       xformer.transform(source, result); }
/* 34 */     catch (TransformerConfigurationException transformerConfigurationException) {  }
/* 35 */     catch (TransformerException transformerException) {}
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/io/XMLWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */