/*     */ package GUI.io;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import java.io.File;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ 
/*     */ public class FileSaver {
/*  10 */   public static String lastSaveDir = System.getProperty("user.dir");
/*  11 */   JFileChooser chooser = new JFileChooser();
/*     */   
/*     */   boolean visibility = false;
/*     */ 
/*     */   
/*     */   public FileSaver() {}
/*     */   
/*     */   public FileSaver(String directory) {
/*  19 */     lastSaveDir = directory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File showSaveDialog(File file, String overwriteText, String extension) {
/*  36 */     if (this.visibility) {
/*  37 */       DebugCounter.inc("Filesaver.showSave is visible");
/*  38 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  42 */     if (overwriteText == null)
/*  43 */       overwriteText = "Overwrite this file?"; 
/*  44 */     if (overwriteText.equals(""))
/*  45 */       overwriteText = "Overwrite this file?"; 
/*  46 */     if (file != null) {
/*  47 */       if (file.exists()) {
/*     */ 
/*     */         
/*  50 */         int overwrite = JOptionPane.showConfirmDialog(null, "<html><p>" + overwriteText + "</p><p>" + file
/*  51 */             .getName() + "</p></html>", "Question", 0);
/*     */         
/*  53 */         if (overwrite == 0) {
/*  54 */           lastSaveDir = file.getParent();
/*     */ 
/*     */           
/*  57 */           this.chooser.setSelectedFile(file);
/*  58 */           return file;
/*     */         } 
/*  60 */         File f = showSaveDialog(null, overwriteText, extension);
/*  61 */         if (f != null) {
/*  62 */           lastSaveDir = f.getParent();
/*     */           
/*  64 */           this.chooser.setSelectedFile(f);
/*     */         } 
/*  66 */         return f;
/*     */       } 
/*     */       
/*  69 */       lastSaveDir = file.getParent();
/*  70 */       this.chooser.setCurrentDirectory(file);
/*  71 */       return file;
/*     */     } 
/*     */ 
/*     */     
/*  75 */     if (lastSaveDir != null) {
/*  76 */       this.chooser.setCurrentDirectory(new File(lastSaveDir));
/*     */     } else {
/*  78 */       lastSaveDir = System.getProperty("user.dir");
/*  79 */       this.chooser.setCurrentDirectory(new File(lastSaveDir));
/*     */     } 
/*  81 */     this.chooser.setSelectedFile(file);
/*     */ 
/*     */ 
/*     */     
/*  85 */     if (extension != null && !extension.equals("")) {
/*  86 */       this.chooser.resetChoosableFileFilters();
/*  87 */       this.chooser.addChoosableFileFilter(new FileNameExtensionFilter(extension, new String[] { extension }));
/*     */     } 
/*     */     
/*  90 */     this.visibility = true;
/*  91 */     int answ = this.chooser.showSaveDialog(null);
/*  92 */     this.visibility = false;
/*  93 */     file = this.chooser.getSelectedFile();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     if (answ == 0) {
/*  99 */       if (!file.getName().endsWith("." + extension)) {
/* 100 */         file = new File(file.getAbsolutePath() + "." + extension);
/*     */       }
/* 102 */       File f = showSaveDialog(file, overwriteText, extension);
/* 103 */       lastSaveDir = f.getParent();
/* 104 */       this.chooser.setCurrentDirectory(f);
/* 105 */       return f;
/*     */     } 
/*     */     
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public File saveNewFile(File file, String overwrite) {
/* 114 */     this.chooser.setCurrentDirectory(file);
/* 115 */     if (overwrite == null || overwrite.equals(""))
/* 116 */       overwrite = "Do you want to overwrite the file?"; 
/* 117 */     int answ = 1;
/* 118 */     if (file != null && 
/* 119 */       file.exists()) {
/* 120 */       answ = JOptionPane.showConfirmDialog(null, "<html><p>" + overwrite + "</p><p>" + file
/* 121 */           .getName() + "</p></html>", "Question", 0);
/*     */     }
/*     */ 
/*     */     
/* 125 */     this.chooser.setMultiSelectionEnabled(false);
/* 126 */     if (file != null && answ == 0) {
/* 127 */       this.chooser.setSelectedFile(file);
/* 128 */       return file;
/*     */     } 
/* 130 */     if (file == null) {
/* 131 */       this.chooser.setCurrentDirectory(new File(lastSaveDir));
/*     */     } else {
/* 133 */       this.chooser.setSelectedFile(file);
/*     */     } 
/* 135 */     this.visibility = true;
/* 136 */     answ = this.chooser.showSaveDialog(null);
/* 137 */     this.visibility = false;
/* 138 */     if (answ == 0) {
/* 139 */       file = this.chooser.getSelectedFile();
/* 140 */       if (!file.isDirectory()) {
/* 141 */         return file;
/*     */       }
/*     */     } 
/* 144 */     return null;
/*     */   }
/*     */   
/*     */   public void addChoosableFileFilter(FileNameExtensionFilter filter) {
/* 148 */     if (filter != null)
/* 149 */       this.chooser.addChoosableFileFilter(filter); 
/*     */   }
/*     */   
/*     */   public void applyFilter(String extension) {
/* 153 */     this.chooser.addChoosableFileFilter(new FileNameExtensionFilter(extension, new String[] { extension }));
/*     */   }
/*     */ 
/*     */   
/*     */   public void applyFilters(String[] extensions) {
/* 158 */     if (extensions != null) {
/* 159 */       this.chooser.resetChoosableFileFilters();
/* 160 */       for (String s : extensions) {
/* 161 */         applyFilter(s);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public File showOpenDialog(File file, FileNameExtensionFilter filter) {
/* 169 */     if (filter != null)
/*     */     {
/*     */ 
/*     */       
/* 173 */       this.chooser.setFileFilter(filter);
/*     */     }
/* 175 */     if (file != null) {
/* 176 */       if (file.exists()) {
/* 177 */         this.chooser.setSelectedFile(file);
/*     */       } else {
/* 179 */         this.chooser.setCurrentDirectory(file);
/*     */       } 
/* 181 */     } else if (file == null && lastSaveDir != null) {
/* 182 */       this.chooser.setCurrentDirectory(new File(lastSaveDir));
/*     */     } 
/* 184 */     this.visibility = true;
/* 185 */     int answ = this.chooser.showOpenDialog(null);
/* 186 */     this.visibility = false;
/* 187 */     if (answ == 0) {
/* 188 */       File returnFile = this.chooser.getSelectedFile();
/* 189 */       if (!returnFile.exists()) {
/*     */         
/* 191 */         JOptionPane.showMessageDialog(null, "This file does not exist!");
/* 192 */         this.chooser.resetChoosableFileFilters();
/* 193 */         File f = showOpenDialog(file, filter);
/* 194 */         if (f != null) {
/* 195 */           lastSaveDir = f.getParent();
/* 196 */           this.chooser.setCurrentDirectory(f);
/*     */         } 
/* 198 */         return f;
/*     */       } 
/* 200 */       lastSaveDir = returnFile.getParent();
/* 201 */       this.chooser.setCurrentDirectory(returnFile);
/* 202 */       return returnFile;
/*     */     } 
/*     */ 
/*     */     
/* 206 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/* 211 */     return this.visibility;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/io/FileSaver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */