/*    */ package GUI.io;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import org.w3c.dom.Document;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLReader
/*    */ {
/*    */   public static Document readXmlFile(File xmlFile) {
/* 16 */     Document document = null;
/*    */     try {
/* 18 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 19 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 20 */       document = builder.parse(xmlFile);
/* 21 */       return document;
/* 22 */     } catch (IOException ioex) {
/* 23 */       System.out.printf("IOFehler : %s\n", new Object[] { ioex.toString() });
/* 24 */       ioex.printStackTrace();
/* 25 */       return null;
/* 26 */     } catch (SAXException saxe) {
/* 27 */       saxe.printStackTrace();
/* 28 */       return null;
/* 29 */     } catch (Exception e) {
/* 30 */       e.printStackTrace();
/* 31 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static Document createNewXmlDocument() {
/* 37 */     Document document = null;
/*    */     try {
/* 39 */       DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 40 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 41 */       document = builder.newDocument();
/* 42 */       return document;
/* 43 */     } catch (Exception e) {
/* 44 */       e.printStackTrace();
/* 45 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/io/XMLReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */