/*     */ package GUI;
/*     */ 
/*     */ import GUI.io.FileSaver;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextPane;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.text.AttributeSet;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.MutableAttributeSet;
/*     */ import javax.swing.text.SimpleAttributeSet;
/*     */ import javax.swing.text.StyleConstants;
/*     */ import javax.swing.text.StyledDocument;
/*     */ import layout.TableLayout;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConsoleWindow
/*     */ {
/*  42 */   private static final Log LOG = LogFactory.getLog(ConsoleWindow.class);
/*     */   
/*  44 */   public static int tabSize = 4;
/*     */   private JFrame frame;
/*  46 */   private JFrame parentWindow = null;
/*     */   
/*  48 */   private static final JTextPane output = new JTextPane();
/*  49 */   private static final StyledDocument document = output.getStyledDocument();
/*     */   
/*  51 */   private static final MutableAttributeSet normalTextAttribute = new SimpleAttributeSet();
/*  52 */   private static final MutableAttributeSet errorTextAttribute = new SimpleAttributeSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private JToggleButton consoleButton = null;
/*     */   
/*     */   static {
/*  62 */     output.setEditable(false);
/*     */     
/*  64 */     StyleConstants.setBold(normalTextAttribute, false);
/*  65 */     StyleConstants.setForeground(normalTextAttribute, Color.BLACK);
/*  66 */     StyleConstants.setFontFamily(normalTextAttribute, "Monospaced");
/*  67 */     StyleConstants.setFontSize(normalTextAttribute, 12);
/*     */     
/*  69 */     StyleConstants.setBold(errorTextAttribute, false);
/*  70 */     StyleConstants.setForeground(errorTextAttribute, Color.RED);
/*  71 */     StyleConstants.setFontFamily(errorTextAttribute, "Monospaced");
/*  72 */     StyleConstants.setFontSize(errorTextAttribute, 12);
/*     */     
/*  74 */     document.setCharacterAttributes(0, document.getLength() + 1, normalTextAttribute, true);
/*     */   }
/*     */   
/*  77 */   private Action saveAction = new AbstractAction("Save")
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*  86 */         FileSaver fs = new FileSaver();
/*  87 */         File file = fs.showSaveDialog(null, "Overwrite this file?", "txt");
/*     */         try {
/*  89 */           if (file != null) {
/*  90 */             FileWriter fileWriter = new FileWriter(file);
/*  91 */             String text = ConsoleWindow.output.getText();
/*  92 */             fileWriter.write(text, 0, text.length());
/*  93 */             fileWriter.flush();
/*  94 */             fileWriter.close();
/*     */           } 
/*  96 */         } catch (Exception ex) {
/*  97 */           ConsoleWindow.LOG.error("Protocol window : Save not possible");
/*  98 */           ConsoleWindow.LOG.error(ex.getMessage(), ex);
/*     */         } 
/*     */       }
/*     */     };
/*     */   
/* 103 */   private Action hideAction = new AbstractAction("Hide")
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/* 111 */         ConsoleWindow.this.hideWindow();
/*     */       }
/*     */     };
/*     */   
/*     */   public void setup(JFrame parent) {
/* 116 */     this.parentWindow = parent;
/* 117 */     this.frame = new JFrame("Protocol window");
/* 118 */     this.frame.setJMenuBar(createMenu());
/* 119 */     double[][] size = { { 600.0D, 50.0D, 50.0D }, { 25.0D, 25.0D, -2.0D } };
/* 120 */     TableLayout layout = new TableLayout(size);
/* 121 */     this.frame.getContentPane().setLayout((LayoutManager)layout);
/* 122 */     this.frame.getContentPane().add(createToolbar(), "0,0,2,0");
/* 123 */     this.frame.getContentPane().add(new JLabel("protocol"), "0,1");
/* 124 */     JScrollPane scroll = new JScrollPane(output);
/* 125 */     scroll.setPreferredSize(new Dimension(700, 600));
/*     */     
/* 127 */     this.frame.getContentPane().add(scroll, "0,2,2,2");
/* 128 */     Date d = new Date();
/* 129 */     SimpleDateFormat f = new SimpleDateFormat();
/*     */ 
/*     */ 
/*     */     
/* 133 */     append("Session started : " + f.format(d) + "\n");
/* 134 */     Rectangle r = this.parentWindow.getBounds();
/* 135 */     int posx = (int)(r.getX() + r.getWidth() + 1.0D);
/* 136 */     int posy = (int)r.getY();
/* 137 */     this.frame.setLocation(posx, posy);
/* 138 */     this.frame.setVisible(false);
/* 139 */     this.frame.setTitle("Protocol window");
/* 140 */     this.frame.setJMenuBar(createMenu());
/* 141 */     this.frame.pack();
/*     */     
/* 143 */     this.frame.addWindowListener(new WindowAdapter()
/*     */         {
/*     */           public void windowClosing(WindowEvent e) {
/* 146 */             ConsoleWindow.this.hideWindow();
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private JMenuBar createMenu() {
/* 152 */     JMenuBar menu = new JMenuBar();
/* 153 */     JMenu fileMenu = new JMenu("File");
/*     */     
/* 155 */     JMenuItem saveItem = new JMenuItem(this.saveAction);
/* 156 */     fileMenu.add(saveItem);
/*     */     
/* 158 */     JMenuItem hideItem = new JMenuItem(this.hideAction);
/* 159 */     fileMenu.add(hideItem);
/* 160 */     menu.add(fileMenu);
/* 161 */     return menu;
/*     */   }
/*     */   
/*     */   public JToolBar createToolbar() {
/* 165 */     JToolBar bar = new JToolBar();
/* 166 */     bar.add(new JButton(this.saveAction));
/* 167 */     bar.add(new JButton(this.hideAction));
/* 168 */     bar.add(new JButton(new AbstractAction("clear")
/*     */           {
/*     */             private static final long serialVersionUID = 1L;
/*     */ 
/*     */             
/*     */             public void actionPerformed(ActionEvent e) {
/* 174 */               ConsoleWindow.clear();
/*     */             }
/*     */           }));
/*     */     
/* 178 */     return bar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clear() {
/* 186 */     output.setCaretPosition(0);
/*     */     
/*     */     try {
/* 189 */       document.remove(0, document.getLength());
/* 190 */     } catch (BadLocationException e) {
/* 191 */       LOG.error(e.getMessage(), e);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 196 */     append("Session started: " + (new SimpleDateFormat()).format(new Date()) + "\n");
/* 197 */     output.revalidate();
/*     */   }
/*     */   
/*     */   public void hideWindow() {
/* 201 */     if (this.frame != null) {
/* 202 */       this.frame.setVisible(false);
/*     */       
/* 204 */       if (this.consoleButton != null) {
/* 205 */         this.consoleButton.setSelected(false);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void showWindow() {
/* 211 */     if (this.frame != null) {
/* 212 */       this.frame.setVisible(true);
/* 213 */       this.frame.toFront();
/*     */       
/* 215 */       if (this.consoleButton != null) {
/* 216 */         this.consoleButton.setSelected(true);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void append(String _text) {
/* 222 */     append(_text, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void append(String _text, boolean _normal) {
/* 236 */     AttributeSet attr = _normal ? normalTextAttribute : errorTextAttribute;
/*     */     try {
/* 238 */       document.insertString(document.getLength(), _text, attr);
/* 239 */     } catch (BadLocationException ble) {
/* 240 */       LOG.error(ble.getMessage(), ble);
/*     */     } 
/* 242 */     output.setCaretPosition(document.getLength());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void appendText(String _text) {
/* 250 */     append(_text, true);
/*     */   }
/*     */   
/*     */   public static String getText() {
/*     */     try {
/* 255 */       return document.getText(0, document.getLength());
/* 256 */     } catch (BadLocationException e) {
/* 257 */       LOG.error(e.getMessage(), e);
/*     */ 
/*     */       
/* 260 */       return null;
/*     */     } 
/*     */   }
/*     */   public boolean isVisible() {
/* 264 */     return this.frame.isVisible();
/*     */   }
/*     */   
/*     */   public void setToggleButton(JToggleButton _toggleButton) {
/* 268 */     this.consoleButton = _toggleButton;
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/ConsoleWindow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */