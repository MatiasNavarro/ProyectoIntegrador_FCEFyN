package GUI;

public interface IAppDirector extends IDirector {
  public static final int NET_UPDATED = 0;
  
  public static final int NET_LOADED = 1;
  
  public static final int SAVE_NET = 2;
  
  public static final int EXIT = 3;
  
  public static final int RELOAD_NET = 4;
  
  public static final int FOCUS = 5;
  
  public static final int WINDOW_NORMALIZED = 6;
  
  public static final int SET_PROPERTY = 7;
  
  public static final int SAVE_SESSION = 8;
  
  public static final int LOAD_SESSION = 9;
  
  public static final int SNOOPY = 10;
  
  public static final int ANALYZE_NET = 11;
  
  public static final int DEBUG_NET = 12;
  
  public static final int LOG_FILE = 13;
  
  public static final int SET_NET = 14;
  
  public static final int IS_NET_LOADED = 15;
  
  public static final int PERFORM_UPDATE = 16;
  
  public static final int NET_IMPORTED = 17;
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/IAppDirector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */