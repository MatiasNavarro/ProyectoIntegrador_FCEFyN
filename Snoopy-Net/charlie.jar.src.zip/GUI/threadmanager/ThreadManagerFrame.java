/*     */ package GUI.threadmanager;
/*     */ 
/*     */ import GUI.debug.DebugCounter;
/*     */ import GUI.util.Align;
/*     */ import charlie.analyzer.Analyzer;
/*     */ import charlie.analyzer.AnalyzerList;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JScrollPane;
/*     */ 
/*     */ public class ThreadManagerFrame
/*     */   extends JFrame {
/*  19 */   private AnalyzerDialog threadDialog = null;
/*     */   
/*  21 */   private AnalyzerList threadList = null;
/*     */   
/*  23 */   private int width = 300;
/*     */   public ThreadManagerFrame(AnalyzerList threadList) {
/*  25 */     initialize();
/*  26 */     this.threadList = threadList;
/*  27 */     this.threadDialog.setModel(this.threadList);
/*     */   }
/*     */   
/*     */   public void initialize() {
/*  31 */     DebugCounter.inc("ThreadManagerFrame initialize()");
/*  32 */     this.threadDialog = new AnalyzerDialog(295);
/*  33 */     JScrollPane scroll = new JScrollPane((Component)this.threadDialog);
/*  34 */     Dimension d = new Dimension(300, 500);
/*  35 */     scroll.setPreferredSize(d);
/*  36 */     scroll.setSize(d);
/*  37 */     add(scroll);
/*  38 */     generateMenu();
/*  39 */     setTitle("Analyzer-Thread-Manager");
/*  40 */     setVisible(true);
/*  41 */     pack();
/*     */   }
/*     */   
/*     */   public void removeFinishedAnalyzers() {
/*  45 */     int i = 0;
/*  46 */     DebugCounter.inc("analyzer.list size:" + Integer.toString(this.threadList.size()));
/*  47 */     i = this.threadList.size();
/*  48 */     while (i > 0) {
/*  49 */       i--;
/*  50 */       Analyzer a = this.threadList.get(i);
/*  51 */       DebugCounter.inc("analyzer index:" + Integer.toString(i) + " state: " + a.getStatus() + " name: " + a.getName());
/*  52 */       if (a.getStatus() == 3 || a.getStatus() == 4) {
/*  53 */         this.threadList.remove(a);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateMenu() {
/*  60 */     JMenuBar bar = new JMenuBar();
/*  61 */     JMenuItem clear = new JMenuItem(new AbstractAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/*  68 */             ThreadManagerFrame.this.removeFinishedAnalyzers();
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*  73 */     bar.add(clear);
/*  74 */     setJMenuBar(bar);
/*     */   }
/*     */ 
/*     */   
/*     */   public void showList(AnalyzerList list) {
/*  79 */     int i = 0;
/*  80 */     if (list != null) {
/*  81 */       for (i = 0; i < list.size(); i++) {
/*  82 */         Analyzer a = list.get(i);
/*  83 */         DebugCounter.inc(i + " : " + a.getName());
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void pack() {
/*  89 */     super.pack();
/*  90 */     Align.toTopRight(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateView() {
/* 101 */     this.threadDialog.update(this.threadList, 0, this.threadList.size() - 1);
/* 102 */     LayoutManager layout = getLayout();
/* 103 */     layout.layoutContainer(this);
/* 104 */     repaint();
/* 105 */     super.pack();
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/threadmanager/ThreadManagerFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */