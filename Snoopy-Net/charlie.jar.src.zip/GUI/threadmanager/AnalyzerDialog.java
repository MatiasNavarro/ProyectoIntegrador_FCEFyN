/*     */ package GUI.threadmanager;
/*     */ import GUI.analyzer.ThreadPanel;
/*     */ import charlie.analyzer.AnalyzerList;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.util.ArrayList;
/*     */ import layout.TableLayout;
/*     */ 
/*     */ public class AnalyzerDialog extends PropertyChangePanel {
/*  11 */   private AnalyzerList list = null;
/*  12 */   private ArrayList<ThreadPanel> panelList = null;
/*  13 */   private int width = 300;
/*  14 */   private TableLayout layout = null;
/*  15 */   private int size = 0;
/*     */   
/*     */   public AnalyzerDialog(AnalyzerList list) {
/*  18 */     this.list = list;
/*  19 */     setModel(this.list);
/*  20 */     this.size = list.size();
/*     */   }
/*     */   
/*     */   public AnalyzerDialog(int width) {
/*  24 */     this.width = width;
/*  25 */     initialize();
/*     */   }
/*     */ 
/*     */   
/*     */   public AnalyzerDialog() {}
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  33 */     double[][] size = { { this.width }, { 1.0D } };
/*  34 */     this.layout = new TableLayout(size);
/*  35 */     this.panelList = new ArrayList<>();
/*  36 */     setLayout((LayoutManager)this.layout);
/*  37 */     Dimension d = this.layout.preferredLayoutSize((Container)this);
/*  38 */     setSize(d);
/*  39 */     setPreferredSize(d);
/*  40 */     resize();
/*     */   }
/*     */   
/*     */   public void setModel(AnalyzerList list) {
/*  44 */     this.list = list;
/*  45 */     list.addToDialog(this);
/*  46 */     this.size = list.size();
/*     */   }
/*     */   
/*     */   public void add(AnalyzerList list, int index) {
/*  50 */     index++;
/*  51 */     this.layout.insertRow(index, ThreadPanel.height);
/*  52 */     ThreadPanel p = new ThreadPanel(list.get(index - 1));
/*  53 */     this.panelList.add(p);
/*  54 */     this.layout.addLayoutComponent((Component)p, "0," + Integer.toString(index));
/*  55 */     add((Component)p, "0," + Integer.toString(index));
/*     */     
/*  57 */     resize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(AnalyzerList list, int startIndex, int endIndex) {
/*  75 */     if (list.size() == this.panelList.size()) {
/*  76 */       int i = 0;
/*  77 */       for (i = 0; i < list.size(); i++) {
/*  78 */         ((ThreadPanel)this.panelList.get(i)).setStatus(list.get(i).getStatus());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(AnalyzerList list, int index) {
/*  85 */     if (list == this.list) {
/*     */       
/*  87 */       this.layout.deleteRow(index + 1);
/*  88 */       resize();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  94 */     removeAll();
/*  95 */     initialize();
/*     */   }
/*     */   
/*     */   public void resize() {
/*  99 */     double oldHeight = getHeight();
/* 100 */     this.layout.layoutContainer((Container)this);
/* 101 */     Dimension d = this.layout.preferredLayoutSize((Container)this);
/* 102 */     setPreferredSize(d);
/* 103 */     setSize(d);
/* 104 */     double newHeight = getHeight();
/*     */     
/* 106 */     repaint();
/* 107 */     if (oldHeight != newHeight)
/* 108 */       propertyChanged("height", (int)oldHeight, (int)newHeight); 
/*     */   }
/*     */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/threadmanager/AnalyzerDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */