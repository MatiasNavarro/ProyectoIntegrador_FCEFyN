/*    */ package GUI.preference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterFactory
/*    */ {
/* 11 */   private static FilterProperties filterProperties = null;
/*    */   
/*    */   public static synchronized FilterProperties getFilterProperties() {
/* 14 */     if (filterProperties == null) {
/* 15 */       filterProperties = new FilterProperties();
/*    */     }
/*    */     
/* 18 */     return filterProperties;
/*    */   }
/*    */   
/*    */   public static synchronized void setFilterProperties(FilterProperties _filterProperties) {
/* 22 */     filterProperties = _filterProperties;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/FilterFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */