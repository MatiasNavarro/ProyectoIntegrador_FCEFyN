/*    */ package GUI.preference;
/*    */ 
/*    */ import GUI.IDirector;
/*    */ import java.util.List;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTabbedPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterPreferenceDialog
/*    */   extends JDialog
/*    */ {
/* 23 */   private IDirector director = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FilterPreferenceDialog(JFrame _parent, IDirector _director) {
/* 32 */     super(_parent, "filter preferences", false);
/*    */     
/* 34 */     this.director = _director;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void initialize() {
/* 41 */     List<String> analyzerList = (List<String>)this.director.externalMessage(100, this, "");
/*    */     
/* 43 */     JTabbedPane tabbedPane = new JTabbedPane();
/* 44 */     for (String analyzer : analyzerList) {
/* 45 */       JPanel analyzerOutputFilterPanel = (JPanel)this.director.externalMessage(101, this, analyzer);
/* 46 */       tabbedPane.addTab(analyzer, analyzerOutputFilterPanel);
/*    */     } 
/* 48 */     add(tabbedPane);
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/FilterPreferenceDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */