/*    */ package GUI.preference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Preference
/*    */ {
/*  8 */   IM_LAST_FILE_FORMAT_FILTER("imLastFileFormatFilter", "0"),
/*    */ 
/*    */ 
/*    */   
/* 12 */   APPLY_RULES_PROPERTY("alwaysApplyRules", "false"),
/*    */ 
/*    */ 
/*    */   
/* 16 */   RECENT_FILES_PROPERTY("recentFiles", ""),
/*    */ 
/*    */ 
/*    */   
/* 20 */   AUTO_CHECK_FOR_UPDATES("autoUpdate", "false"),
/*    */ 
/*    */ 
/*    */   
/* 24 */   WRITE_LOG_FILE("writeLog", "true");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String key;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String defaultValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Preference(String _key, String _def) {
/* 42 */     this.key = _key;
/* 43 */     this.defaultValue = _def;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 52 */     return this.key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDefault() {
/* 61 */     return this.defaultValue;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/Preference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */