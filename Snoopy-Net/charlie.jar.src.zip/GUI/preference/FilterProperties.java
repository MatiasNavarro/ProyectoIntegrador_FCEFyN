/*    */ package GUI.preference;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterProperties
/*    */   extends Properties
/*    */ {
/*    */   private static final long serialVersionUID = -1845602203399314422L;
/*    */   
/*    */   public FilterProperties() {}
/*    */   
/*    */   public FilterProperties(Properties _props) {
/* 23 */     Enumeration<Object> e = _props.keys();
/*    */     
/* 25 */     while (e.hasMoreElements()) {
/* 26 */       String key = (String)e.nextElement();
/* 27 */       String value = _props.getProperty(key);
/* 28 */       setProperty(key, value);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isFiltered(String _key) {
/* 40 */     return Boolean.parseBoolean(getProperty(_key, "false"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFiletered(String _key, boolean _filtered) {
/* 50 */     setProperty(_key, Boolean.toString(_filtered));
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/FilterProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */