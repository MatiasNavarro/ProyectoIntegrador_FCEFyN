/*   */ package GUI.preference;
/*   */ 
/*   */ public class PreferenceFactory
/*   */ {
/* 5 */   private static final PreferenceProperties properties = new PreferenceProperties();
/*   */   
/*   */   public static PreferenceProperties getPreferenceProperties() {
/* 8 */     return properties;
/*   */   }
/*   */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/PreferenceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */