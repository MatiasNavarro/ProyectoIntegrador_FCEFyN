/*    */ package GUI.preference;
/*    */ 
/*    */ import GUI.IDirector;
/*    */ import charlie.plugin.director.PluginFilterPreferencePanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvariantFilterPanel
/*    */   extends PluginFilterPreferencePanel
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public InvariantFilterPanel(IDirector director) {
/* 14 */     super(director);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String[] getSettingLabels() {
/* 19 */     String[] names = { "rank theorem", "structural boundedness", "p-invariants", "t-invariants" };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 26 */     return names;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String[] getSettingKeys() {
/* 35 */     String[] keys = { IncidenceMatrixBasedFilterPreference.FILTER_IM_BASED_RANK_THEOREM.getKey(), IncidenceMatrixBasedFilterPreference.FILTER_IM_BASED_STRUCTURAL_BOUNDEDNESS.getKey(), IncidenceMatrixBasedFilterPreference.FILTER_IM_BASED_P_INVARIANTS.getKey(), IncidenceMatrixBasedFilterPreference.FILTER_IM_BASED_T_INVARIANTS.getKey() };
/*    */ 
/*    */     
/* 38 */     return keys;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAnalyzerName() {
/* 43 */     return "IM-based analysis";
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/InvariantFilterPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */