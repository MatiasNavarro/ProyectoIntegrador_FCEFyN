/*    */ package GUI.preference;
/*    */ 
/*    */ import GUI.IDirector;
/*    */ import charlie.plugin.director.PluginFilterPreferencePanel;
/*    */ 
/*    */ public class DeadlockFilterPanel
/*    */   extends PluginFilterPreferencePanel {
/*    */   public DeadlockFilterPanel(IDirector director) {
/*  9 */     super(director);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAnalyzerName() {
/* 14 */     return "siphon/trap computation";
/*    */   }
/*    */ 
/*    */   
/*    */   protected String[] getSettingKeys() {
/* 19 */     return new String[] { SiphonTrapFilterPreference.FILTER_SIPHON_TRAP_TRAP
/* 20 */         .getKey(), SiphonTrapFilterPreference.FILTER_SIPHON_TRAP_SIPHON
/* 21 */         .getKey(), SiphonTrapFilterPreference.FILTER_SIPHON_TRAP_STP
/* 22 */         .getKey() };
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String[] getSettingLabels() {
/* 28 */     return new String[] { "traps", "siphon", "stp" };
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/DeadlockFilterPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */