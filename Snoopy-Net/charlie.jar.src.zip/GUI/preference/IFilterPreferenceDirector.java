package GUI.preference;

import GUI.IDirector;

public interface IFilterPreferenceDirector extends IDirector {
  public static final int GET_ANALYZER_LIST = 100;
  
  public static final int GET_FILTER_PANEL = 101;
}


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/IFilterPreferenceDirector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */