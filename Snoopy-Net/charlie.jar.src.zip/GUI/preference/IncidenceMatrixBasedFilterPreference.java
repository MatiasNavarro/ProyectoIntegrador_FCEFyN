/*    */ package GUI.preference;
/*    */ 
/*    */ public enum IncidenceMatrixBasedFilterPreference
/*    */ {
/*  5 */   FILTER_IM_BASED_RANK_THEOREM("IncidenceMatrixBasedFilter.rankTheorem"),
/*  6 */   FILTER_IM_BASED_STRUCTURAL_BOUNDEDNESS("IncidenceMatrixBasedFilter.structuralBoundedness"),
/*  7 */   FILTER_IM_BASED_P_INVARIANTS("IncidenceMatrixBasedFilter.pinvariants"),
/*  8 */   FILTER_IM_BASED_T_INVARIANTS("IncidenceMatrixBasedFilter.tinvariants");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String key;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   IncidenceMatrixBasedFilterPreference(String _key) {
/* 21 */     this.key = _key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 30 */     return this.key;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/IncidenceMatrixBasedFilterPreference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */