/*    */ package GUI.preference;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ public class PreferenceProperties
/*    */   extends Properties
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public String getProperty(Preference pref) {
/* 14 */     return getProperty(pref.getKey(), pref.getDefault());
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/PreferenceProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */