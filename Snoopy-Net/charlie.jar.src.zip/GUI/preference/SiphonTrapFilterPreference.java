/*    */ package GUI.preference;
/*    */ 
/*    */ public enum SiphonTrapFilterPreference
/*    */ {
/*  5 */   FILTER_SIPHON_TRAP_TRAP("SiphonTrapFilter.traps"),
/*  6 */   FILTER_SIPHON_TRAP_SIPHON("SiphonTrapFilter.siphon"),
/*  7 */   FILTER_SIPHON_TRAP_STP("SiphonTrapFilter.stp");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String key;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   SiphonTrapFilterPreference(String _key) {
/* 20 */     this.key = _key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 29 */     return this.key;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/SiphonTrapFilterPreference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */