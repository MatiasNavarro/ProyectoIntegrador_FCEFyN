/*    */ package GUI.preference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharlieFilterProperties
/*    */   extends FilterProperties
/*    */ {
/*    */   private static final long serialVersionUID = 5571419563588568943L;
/*    */   
/*    */   public boolean isFiltered(String _key) {
/* 17 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/preference/CharlieFilterProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */