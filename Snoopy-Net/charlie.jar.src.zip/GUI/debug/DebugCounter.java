/*    */ package GUI.debug;
/*    */ 
/*    */ import GUI.util.TextFile;
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import javax.swing.JFrame;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugCounter
/*    */ {
/* 14 */   private static final Log LOG = LogFactory.getLog(DebugCounter.class);
/*    */   
/* 16 */   public static int maxLogFileSize = 10240;
/*    */   
/*    */   public static boolean printImmediately = true;
/* 19 */   private static int count = 0;
/* 20 */   private static ArrayList<String> buf = new ArrayList<>();
/*    */   private static boolean busy = false;
/*    */   
/*    */   public static synchronized int inc(String message) {
/* 24 */     LOG.debug(message);
/*    */     
/* 26 */     return count;
/*    */   }
/*    */   
/*    */   public static synchronized void reset() {
/* 30 */     enter();
/* 31 */     count = 0;
/* 32 */     buf.clear();
/* 33 */     leave();
/*    */   }
/*    */   
/*    */   public static synchronized void printLog(JFrame parent) {
/* 37 */     enter();
/* 38 */     int i = 0;
/* 39 */     for (i = 0; i < buf.size(); i++) {
/* 40 */       System.out.println(buf.get(i));
/*    */     }
/* 42 */     leave();
/*    */   }
/*    */   
/*    */   public static synchronized void writeLog(File logFile) {
/* 46 */     enter();
/* 47 */     StringBuffer buffer = new StringBuffer();
/* 48 */     for (String s : buf) {
/* 49 */       buffer.append(s + "\n");
/*    */     }
/*    */     try {
/* 52 */       if (logFile.exists() && 
/* 53 */         logFile.length() > maxLogFileSize) {
/* 54 */         logFile.delete();
/* 55 */         logFile.createNewFile();
/*    */       } 
/*    */ 
/*    */       
/* 59 */       TextFile.writeToFile(logFile, buffer, true);
/* 60 */       buf.clear();
/* 61 */     } catch (Exception ioe) {
/* 62 */       LOG.error(ioe.getMessage(), ioe);
/*    */     } 
/* 64 */     leave();
/*    */   }
/*    */   
/*    */   public static synchronized void enter() {
/*    */     try {
/* 69 */       while (busy) {
/* 70 */         Thread.yield();
/*    */       }
/* 72 */     } catch (Exception e) {
/* 73 */       LOG.error(String.format("DebugCounter: concurrency error message = %d", new Object[] { Integer.valueOf(count) }), e);
/*    */       return;
/*    */     } 
/*    */   }
/*    */   
/*    */   public static synchronized void leave() {
/* 79 */     busy = false;
/*    */   }
/*    */ }


/* Location:              /home/matiasnavarro/Facultad/2019/Tesis/Complementos/Charlie/charlie.jar!/GUI/debug/DebugCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */